<?php
/*
 * Plugin della Libreria di Casa.
 *
 * Un plugin e' uno ZIP con plugin.json (scheda), plugin.php (codice) ed eventuali altri file (css, js, immagini).
 * Si installa SOLO se e' firmato con la chiave dell'autore del sito (CONF/firma_autore.json, vedi inc/firma.php).
 * I file vanno in data/plugins/<id>/ (fuori dalla parte pubblica del sito). Ad ogni caricamento:
 *   - la firma dell'elenco dei file viene ricontrollata con la chiave dell'autore,
 *   - i file .php vengono confrontati con l'impronta firmata: un file modificato sul server spegne il plugin;
 * un plugin che va in errore viene spento da solo. Modalita' sicura: file data/plugins/MODALITA_SICURA (nessun plugin caricato).
 *
 * Il codice del plugin riceve $plugin (classe LibPlugin) e si aggancia ai "punti" del sito:
 *   $plugin->on('scheda_libro', function ($html, $libro) { return $html . '...'; });
 *   $plugin->admin_page('impostazioni', 'Il mio plugin', function ($p) { ... }, array('salva' => function ($p) { ... }));
 * Elenco dei punti: plugin_hooks_doc().
 */

define('PLUGIN_API', 1);

function plugins_dir()
{
    return DATA_DIR . '/plugins';
}

function plugins_ready()
{
    return (int)setting('db_version', '1') >= 11;
}

function plugins_safe_mode()
{
    return is_file(plugins_dir() . '/MODALITA_SICURA');
}

function plugin_id_ok($id)
{
    return is_string($id) && preg_match('/^[a-z0-9][a-z0-9\-]{1,39}$/', $id) === 1;
}

// Tipi di file ammessi in un plugin (niente eseguibili, niente .htaccess, niente SVG)
function plugin_file_types()
{
    return array(
        'php' => 'text/plain', 'json' => 'application/json', 'md' => 'text/plain', 'txt' => 'text/plain', 'sql' => 'text/plain', 'html' => 'text/plain',
        'css' => 'text/css; charset=utf-8', 'js' => 'text/javascript; charset=utf-8',
        'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp', 'gif' => 'image/gif', 'ico' => 'image/x-icon',
        'woff' => 'font/woff', 'woff2' => 'font/woff2',
    );
}

// File che il browser puo' scaricare (plugin_file.php)
function plugin_public_types()
{
    return array('css', 'js', 'png', 'jpg', 'jpeg', 'webp', 'gif', 'ico', 'woff', 'woff2', 'json');
}

function plugin_hooks_doc()
{
    return array(
        'html_testa'      => array('filtro', '$html', 'HTML aggiunto in fondo a <head> nelle pagine del sito (es. un foglio di stile)'),
        'html_fondo'      => array('filtro', '$html', 'HTML aggiunto in fondo alla pagina del sito (es. uno script)'),
        'admin_testa'     => array('filtro', '$html', 'Come html_testa, nel pannello di gestione'),
        'admin_fondo'     => array('filtro', '$html', 'Come html_fondo, nel pannello di gestione'),
        'pagina_libreria' => array('filtro', '$html, $ricerca', 'Riquadro in cima alla pagina Libreria, sotto il titolo'),
        'pagina_account'  => array('filtro', '$html', 'Riquadri nella pagina Il mio account, sotto il profilo'),
        'scheda_libro'    => array('filtro', '$html, $libro', 'Riquadro aggiunto nella scheda di un libro'),
        'bacheca'         => array('filtro', '$html', 'Riquadro aggiunto nella Bacheca del pannello'),
        'menu_sito'       => array('filtro', '$voci', 'Voci del menu ☰ del sito: array di array(indirizzo, testo)'),
        'libro_salvato'   => array('azione', '$id, $nuovo', 'Dopo che un libro è stato aggiunto o modificato'),
        'libro_eliminato' => array('azione', '$id', 'Dopo che un libro è stato spostato nel cestino o eliminato'),
        'lettura_terminata' => array('azione', '$utente_id, $lettura_id, $libro_id', 'Quando un utente segna un libro come finito (dalla scheda del libro)'),
        'avanzamento_salvato' => array('azione', '$utente_id, $libro_id', 'Quando un utente segna a che pagina è arrivato'),
        'lettura_valutata'  => array('azione', '$utente_id, $lettura_id, $libro_id', 'Quando un utente salva voto e recensione di una lettura'),
        'accesso'         => array('azione', '$utente', 'Dopo un accesso riuscito'),
        'ogni_giorno'     => array('azione', '', 'Una volta al giorno, con i lavori automatici del sito'),
    );
}

/* ---------------- Registro degli agganci ---------------- */

function plugins_hook_add($hook, $cb, $prio, $pid)
{
    static $seq = 0;
    $GLOBALS['LIB_HOOKS'][$hook][] = array((int)$prio, ++$seq, $cb, $pid);
}

function plugins_hooks_for($hook)
{
    if (empty($GLOBALS['LIB_HOOKS'][$hook])) {
        return array();
    }
    $l = $GLOBALS['LIB_HOOKS'][$hook];
    usort($l, function ($a, $b) {
        return $a[0] === $b[0] ? $a[1] - $b[1] : $a[0] - $b[0];
    });
    return $l;
}

// Esegue le "azioni" agganciate (i plugin che vanno in errore vengono spenti)
function lib_do($hook)
{
    $args = array_slice(func_get_args(), 1);
    foreach (plugins_hooks_for($hook) as $h) {
        if (!empty($GLOBALS['PLG_FAILED'][$h[3]])) {
            continue;
        }
        $GLOBALS['PLG_CURRENT'] = $h[3];
        try {
            call_user_func_array($h[2], $args);
        } catch (Throwable $e) {
            plugin_fail($h[3], $e);
        }
        $GLOBALS['PLG_CURRENT'] = null;
    }
}

// Passa un valore attraverso i "filtri" agganciati
function lib_filter($hook, $value)
{
    $args = array_slice(func_get_args(), 2);
    foreach (plugins_hooks_for($hook) as $h) {
        if (!empty($GLOBALS['PLG_FAILED'][$h[3]])) {
            continue;
        }
        $GLOBALS['PLG_CURRENT'] = $h[3];
        try {
            $value = call_user_func_array($h[2], array_merge(array($value), $args));
        } catch (Throwable $e) {
            plugin_fail($h[3], $e);
        }
        $GLOBALS['PLG_CURRENT'] = null;
    }
    return $value;
}

/* ---------------- La classe che ogni plugin riceve ---------------- */

class LibPlugin
{
    public $id;
    public $name;
    public $version;
    public $dir;
    public $info;

    public function __construct($row, $info)
    {
        $this->id = $row['id'];
        $this->name = $row['name'];
        $this->version = $row['version'];
        $this->dir = plugins_dir() . '/' . $row['id'];
        $this->info = $info;
    }

    // Aggancio a un punto del sito (vedi plugin_hooks_doc)
    public function on($hook, $callback, $priority = 10)
    {
        plugins_hook_add($hook, $callback, $priority, $this->id);
        return $this;
    }

    /*
     * Pagina nel pannello (gruppo "Plugin"). $render($plugin) stampa il contenuto.
     * $opts: 'salva' => function ($plugin) {...}  per i moduli (action "plg_salva", il token CSRF e' gia' controllato)
     *        'ruolo' => 'admin' (predefinito) oppure 'editore' (anche i Gestori)
     */
    public function admin_page($slug, $title, $render, $opts = array())
    {
        if (!preg_match('/^[a-z0-9\-]{1,30}$/', $slug)) {
            return $this;
        }
        $GLOBALS['PLG_PAGES']['plg-' . $this->id . '-' . $slug] = array('plugin' => $this, 'slug' => $slug, 'title' => (string)$title,
            'render' => $render, 'salva' => isset($opts['salva']) ? $opts['salva'] : null,
            'admin' => !(isset($opts['ruolo']) && $opts['ruolo'] === 'editore'));
        return $this;
    }

    /*
     * Pagina nel SITO (non nel pannello): plg.php?p=<id>&s=<slug>  (1.9.5)
     * $opts: 'ruolo' => 'utente' (predefinito: chi e' registrato, Registrati compresi) | 'tutti' (anche gli ospiti) | 'editore' | 'admin'
     *        'menu'  => true per metterla nel menu ☰ del sito, 'icona' => nome dell'icona
     *        'salva' => function ($plugin) {...} per i moduli (action "plg_salva", il token CSRF e' gia' controllato)
     */
    public function site_page($slug, $title, $render, $opts = array())
    {
        if (preg_match('/^[a-z0-9\-]{1,30}$/', $slug)) {
            $GLOBALS['PLG_SITE'][$this->id . '/' . $slug] = array('plugin' => $this, 'slug' => $slug, 'title' => (string)$title, 'render' => $render,
                'ruolo' => isset($opts['ruolo']) ? $opts['ruolo'] : 'utente', 'menu' => !empty($opts['menu']),
                'icona' => isset($opts['icona']) ? $opts['icona'] : 'page', 'salva' => isset($opts['salva']) ? $opts['salva'] : null,
                // 'pubblica' => true: visibile anche senza accesso (es. una pagina da aprire con un link segreto); niente menu, niente invio di moduli da chi non ha fatto l'accesso
                'pubblica' => !empty($opts['pubblica']),
                // 'grezza' => true: nessuna impaginazione del sito; la funzione manda da sola la risposta (es. un'immagine)
                'grezza' => !empty($opts['grezza']));
            if (!empty($opts['pubblica'])) {
                $GLOBALS['PLG_SITE'][$this->id . '/' . $slug]['menu'] = false;
            }
        }
        return $this;
    }

    /*
     * Avviso nella campanella (1.9.14), tipo "Dalle funzioni aggiuntive" (ognuno puo' spegnerlo in Il mio account).
     * $opts: to => array di id utenti (altrimenti tutti), actor => id di chi lo causa (non lo riceve), book, gruppo, testo_gruppo ({n}), sostituisci
     */
    public function notifica($testo, $link = '', $opts = array())
    {
        if (!is_file(APP_ROOT . '/inc/notifiche.php')) {
            return 0;
        }
        require_once APP_ROOT . '/inc/notifiche.php';
        if (isset($opts['gruppo'])) {
            $opts['gruppo'] = 'plg:' . $this->id . ':' . $opts['gruppo'];
        }
        return notif_invia('plugin', (string)$testo, (string)$link, $opts);
    }

    /*
     * Da chiamare quando qualcuno usa un link segreto sbagliato o scaduto (pagine 'pubblica'):
     * resta nel registro del firewall e, dopo 10 tentativi in 10 minuti, l'indirizzo IP viene bloccato.
     */
    public function tentativo_errato($dettaglio = '')
    {
        if (!function_exists('fw_event') || !function_exists('fw_enabled') || !fw_enabled()) {
            return;
        }
        $c = fw_client();
        fw_event('token', str_cut('Link di condivisione sbagliato (' . $this->id . ')' . ($dettaglio !== '' ? ': ' . $dettaglio : ''), 250));
        try {
            $st = db()->prepare("SELECT COALESCE(SUM(hits), 0) FROM fw_events WHERE ip = ? AND kind = 'token' AND last_at >= ?");
            $st->execute(array($c['ip'], date('Y-m-d H:i:s', time() - 600)));
            if ((int)$st->fetchColumn() >= 10) {
                fw_block_auto($c['ip'], 'token', 'Troppi link di condivisione sbagliati');
            }
        } catch (Exception $e) {
            // il registro non deve bloccare la pagina
        }
    }

    public function site_url($slug, $params = array())
    {
        return 'plg.php?' . http_build_query(array_merge(array('p' => $this->id, 's' => $slug), $params));
    }

    /*
     * Indirizzo per il JavaScript del plugin: api.php?action=plg&p=<id>&f=<nome>
     * $opts: 'metodo' => 'GET' o 'POST' (POST richiede il token CSRF, come le altre chiamate), 'ruolo' => 'utente' | 'editore' | 'admin'
     * $callback($plugin) restituisce un array (diventa JSON).
     */
    public function api($name, $callback, $opts = array())
    {
        if (preg_match('/^[a-z0-9_\-]{1,40}$/', $name)) {
            $GLOBALS['PLG_API'][$this->id][$name] = array($callback, isset($opts['metodo']) ? strtoupper($opts['metodo']) : 'GET',
                isset($opts['ruolo']) ? $opts['ruolo'] : 'utente');
        }
        return $this;
    }

    // Quando il plugin viene attivato (anche dopo un aggiornamento: riceve la versione precedente o '')
    public function on_activate($callback)
    {
        $GLOBALS['PLG_LIFE'][$this->id]['attiva'] = $callback;
        return $this;
    }

    // Quando il plugin viene rimosso: riceve true se l'Admin ha chiesto di cancellare anche i dati
    public function on_remove($callback)
    {
        $GLOBALS['PLG_LIFE'][$this->id]['rimuovi'] = $callback;
        return $this;
    }

    public function setting($key, $default = '')
    {
        $v = setting('plg.' . $this->id . '.' . $key, null);
        return $v === null ? $default : $v;
    }

    public function save_setting($key, $value)
    {
        setting_save('plg.' . $this->id . '.' . $key, (string)$value);
        load_settings(true);
    }

    // Nome di una tabella riservata al plugin (da creare in on_activate)
    public function table($name)
    {
        return 'plg_' . str_replace('-', '_', $this->id) . '_' . preg_replace('/[^a-z0-9_]/', '', strtolower($name));
    }

    public function db()
    {
        return db();
    }

    // Cartella dei dati del plugin (non pubblica)
    public function data_dir()
    {
        $d = DATA_DIR . '/plugin_dati/' . $this->id;
        if (!is_dir($d)) {
            @mkdir($d, 0775, true);
        }
        return $d;
    }

    // Indirizzo di un file pubblico del plugin (css, js, immagini, caratteri)
    public function url($file)
    {
        return 'plugin_file.php?p=' . rawurlencode($this->id) . '&f=' . rawurlencode($file) . '&v=' . rawurlencode($this->version);
    }

    public function css($file)
    {
        return '<link rel="stylesheet" href="' . h($this->url($file)) . '">';
    }

    public function js($file)
    {
        return '<script src="' . h($this->url($file)) . '"></script>';
    }

    // Apertura di un modulo per le pagine del pannello: invia a $opts['salva'] della pagina, con il token di sicurezza
    public function form_start($attrs = '')
    {
        return '<form method="post"' . ($attrs !== '' ? ' ' . $attrs : '') . '>' . csrf_field() . '<input type="hidden" name="action" value="plg_salva">';
    }

    public function admin_url($slug, $params = array())
    {
        return 'gestione.php?' . http_build_query(array_merge(array('sez' => 'plg-' . $this->id . '-' . $slug), $params));
    }

    public function log($text, $level = 'info')
    {
        app_log('plugin_' . $this->id, (string)$text, $level);
    }
}

/* ---------------- Caricamento ---------------- */

function plugins_rows($active_only = false)
{
    if (!plugins_ready()) {
        return array();
    }
    try {
        return db()->query('SELECT * FROM plugins' . ($active_only ? ' WHERE active = 1' : '') . ' ORDER BY name')->fetchAll();
    } catch (Exception $e) {
        return array();
    }
}

// Controlla firma e file di un plugin installato. Esito: '' se tutto a posto, altrimenti il motivo
function plugin_integrity($row, $all_files = false)
{
    require_once dirname(__FILE__) . '/firma.php';
    $pub = firma_chiave_pubblica();
    if (!$pub) {
        return 'Sul sito non c\'è più la chiave dell\'autore.';
    }
    if (!firma_disponibile()) {
        return 'Manca l\'estensione sodium di PHP.';
    }
    $m = json_decode((string)$row['manifest'], true);
    if (!is_array($m) || empty($m['files']) || empty($m['firma'])) {
        return 'Dati del plugin incompleti.';
    }
    $f = $m['firma'];
    $sig = base64_decode((string)$f['firma'], true);
    if (!hash_equals($pub['impronta'], (string)$f['impronta']) || $sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES
        || !sodium_crypto_sign_verify_detached($sig, firma_messaggio('plugin', $pub['impronta'], (string)$f['firmato_il'], $m['files']), $pub['pk'])) {
        return 'La firma del plugin non corrisponde alla chiave dell\'autore.';
    }
    $dir = plugins_dir() . '/' . $row['id'];
    foreach ($m['files'] as $path => $hash) {
        if (!$all_files && substr($path, -4) !== '.php') {
            continue;
        }
        $file = $dir . '/' . $path;
        if (!is_file($file) || !hash_equals($hash, hash_file('sha256', $file))) {
            return 'Il file ' . $path . ' è stato modificato o manca sul server.';
        }
    }
    if ($all_files) {
        // nessun file in piu' (per esempio codice aggiunto da qualcuno sul server)
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $fi) {
            $rel = str_replace('\\', '/', substr($fi->getPathname(), strlen($dir) + 1));
            if ($fi->isFile() && !isset($m['files'][$rel]) && $rel !== 'firma.json') {
                return 'Sul server c\'è un file in più non firmato: ' . $rel;
            }
        }
    }
    return '';
}

function plugin_set_status($id, $status, $error = '', $deactivate = true)
{
    try {
        db()->prepare('UPDATE plugins SET status = ?, error = ?' . ($deactivate ? ', active = 0' : '') . ', updated_at = ? WHERE id = ?')
            ->execute(array($status, str_cut((string)$error, 480), now(), $id));
    } catch (Exception $e) {
        // database non raggiungibile: si riprova al prossimo caricamento
    }
}

// Un plugin in errore viene spento (e lo si scrive nel log)
function plugin_fail($id, $e)
{
    $GLOBALS['PLG_FAILED'][$id] = true;
    $msg = $e instanceof Throwable ? get_class($e) . ': ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')' : (string)$e;
    $msg = str_replace(array(dirname(APP_ROOT) . '/', dirname(APP_ROOT)), '', $msg); // niente percorsi del server nel pannello
    plugin_set_status($id, 'errore', $msg);
    app_log('plugin_errore', 'Plugin "' . $id . '" spento per un errore: ' . $msg, 'alert', '');
}

function plugin_include($row, $info)
{
    $plugin = new LibPlugin($row, $info);
    $GLOBALS['PLG_OBJ'][$row['id']] = $plugin;
    $GLOBALS['PLG_CURRENT'] = $row['id'];
    $entry = plugins_dir() . '/' . $row['id'] . '/plugin.php';
    (function () use ($plugin, $entry) {
        include $entry;
    })();
    $GLOBALS['PLG_CURRENT'] = null;
    return $plugin;
}

function plugins_boot()
{
    if (!empty($GLOBALS['PLG_BOOTED']) || defined('NO_PLUGINS') || !plugins_ready() || plugins_safe_mode()) {
        return;
    }
    $GLOBALS['PLG_BOOTED'] = true;
    $rows = plugins_rows(true);
    if (!$rows) {
        return;
    }
    register_shutdown_function('plugins_shutdown');
    foreach ($rows as $row) {
        if (!plugin_id_ok($row['id'])) {
            continue;
        }
        $why = plugin_integrity($row);
        if ($why !== '') {
            plugin_set_status($row['id'], 'manomesso', $why);
            app_log('plugin_bloccato', 'Plugin "' . $row['id'] . '" spento: ' . $why, 'alert', '');
            continue;
        }
        $info = json_decode((string)@file_get_contents(plugins_dir() . '/' . $row['id'] . '/plugin.json'), true);
        if (!empty($info['richiede']) && version_compare(APP_VERSION, (string)$info['richiede'], '<')) {
            continue;
        }
        try {
            $p = plugin_include($row, is_array($info) ? $info : array());
            $pending = setting('plg_pending.' . $row['id'], null);
            if ($pending !== null) {
                db()->prepare('DELETE FROM settings WHERE setting_key = ?')->execute(array('plg_pending.' . $row['id']));
                load_settings(true);
                if (!empty($GLOBALS['PLG_LIFE'][$row['id']]['attiva'])) {
                    $GLOBALS['PLG_CURRENT'] = $row['id'];
                    call_user_func($GLOBALS['PLG_LIFE'][$row['id']]['attiva'], $p, (string)$pending);
                    $GLOBALS['PLG_CURRENT'] = null;
                }
            }
        } catch (Throwable $e) {
            plugin_fail($row['id'], $e);
        }
    }
}

// Errore grave dentro un plugin: il plugin viene spento, cosi' alla pagina successiva il sito funziona
function plugins_shutdown()
{
    $e = error_get_last();
    if (!$e || !in_array($e['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
        return;
    }
    $id = !empty($GLOBALS['PLG_CURRENT']) ? $GLOBALS['PLG_CURRENT'] : '';
    $base = plugins_dir() . '/';
    if ($id === '' && strpos(str_replace('\\', '/', $e['file']), str_replace('\\', '/', $base)) === 0) {
        $id = strtok(substr(str_replace('\\', '/', $e['file']), strlen($base)), '/');
    }
    if ($id !== '' && plugin_id_ok($id)) {
        plugin_fail($id, $e['message'] . ' (' . basename($e['file']) . ':' . $e['line'] . ')');
    }
}

/* ---------------- Pagine del pannello e API dei plugin ---------------- */

function plugins_admin_sections()
{
    $out = array();
    foreach (isset($GLOBALS['PLG_PAGES']) ? $GLOBALS['PLG_PAGES'] : array() as $k => $p) {
        $out[$k] = array('plugin', $p['title'], $p['admin'], 'a_plugin_pagina.php', true);
    }
    return $out;
}

// Chi puo' vedere una pagina del sito di un plugin
function plugin_site_allowed($pg)
{
    if (!empty($pg['pubblica'])) {
        return true;
    }
    $r = $pg['ruolo'];
    return $r === 'tutti' ? is_logged() : ($r === 'editore' ? can_edit() : ($r === 'admin' ? is_admin() : is_user()));
}

function plugins_api_call($pid, $name)
{
    if (!isset($GLOBALS['PLG_API'][$pid][$name]) || !empty($GLOBALS['PLG_FAILED'][$pid])) {
        return array('ok' => false, 'error' => 'Funzione del plugin non trovata.');
    }
    list($cb, $method, $role) = $GLOBALS['PLG_API'][$pid][$name];
    if ($method !== $_SERVER['REQUEST_METHOD']) {
        return array('ok' => false, 'error' => 'Metodo non ammesso.');
    }
    if (($role === 'admin' && !is_admin()) || ($role === 'editore' && !can_edit()) || !is_logged()) {
        return array('ok' => false, 'error' => 'Operazione non consentita.');
    }
    $GLOBALS['PLG_CURRENT'] = $pid;
    try {
        $r = call_user_func($cb, $GLOBALS['PLG_OBJ'][$pid]);
    } catch (Throwable $e) {
        plugin_fail($pid, $e);
        return array('ok' => false, 'error' => 'Il plugin è andato in errore ed è stato spento.');
    }
    $GLOBALS['PLG_CURRENT'] = null;
    return is_array($r) ? $r + array('ok' => true) : array('ok' => true, 'data' => $r);
}

/* ---------------- Installazione, aggiornamento, rimozione ---------------- */

/*
 * Controlla uno ZIP di plugin (firma compresa). Esito: array(errori, plugin.json, manifesto, firma)
 */
function plugin_inspect_zip($zip_path)
{
    require_once dirname(__FILE__) . '/firma.php';
    $err = array();
    if (!firma_chiave_pubblica()) {
        return array(array('Su questo sito non c\'è ancora la chiave dell\'autore: senza, nessun plugin può essere installato (vedi le istruzioni qui sotto).'), null, null, null);
    }
    $v = firma_verifica_zip($zip_path, 'plugin');
    if ($v['stato'] !== 'firmato') {
        return array(array($v['stato'] === 'non_firmato' ? 'Il plugin non è firmato: si installano solo plugin firmati dall\'autore del sito.' : $v['testo']), null, null, null);
    }
    $files = $v['files'];
    $zip = new ZipArchive();
    $zip->open($zip_path);
    $info = json_decode((string)$zip->getFromName('plugin.json'), true);
    $zip->close();
    if (!is_array($info)) {
        return array(array('plugin.json mancante o non valido.'), null, null, null);
    }
    if (!isset($info['id']) || !plugin_id_ok($info['id'])) {
        $err[] = 'Identificativo del plugin non valido (minuscole, numeri e trattini, 2-40 caratteri).';
    }
    if (empty($info['nome']) || !isset($info['versione']) || !preg_match('/^\d+\.\d+(\.\d+)?$/', (string)$info['versione'])) {
        $err[] = 'Nella scheda del plugin mancano il nome o la versione (es. 1.0.0).';
    }
    if (!isset($files['plugin.php'])) {
        $err[] = 'Manca il file plugin.php.';
    }
    if (!empty($info['richiede']) && version_compare(APP_VERSION, (string)$info['richiede'], '<')) {
        $err[] = 'Il plugin richiede la Libreria di Casa ' . $info['richiede'] . ' o successiva.';
    }
    if (!empty($info['php_min']) && version_compare(PHP_VERSION, (string)$info['php_min'], '<')) {
        $err[] = 'Il plugin richiede PHP ' . $info['php_min'] . ' o successivo.';
    }
    $types = plugin_file_types();
    foreach ($files as $p => $h) {
        $ext = strtolower(pathinfo($p, PATHINFO_EXTENSION));
        $base = basename($p);
        if (!isset($types[$ext]) || $base[0] === '.' || substr_count($p, '/') > 6) {
            $err[] = 'File non ammesso nel plugin: ' . $p;
        }
    }
    if (!empty($info['icona']) && (!is_string($info['icona']) || !isset($files[$info['icona']]) || !preg_match('/\.(png|jpg|jpeg|webp)$/i', $info['icona']))) {
        $err[] = 'L\'icona indicata in plugin.json non c\'è nel pacchetto (serve un file png, jpg o webp).';
    }
    if (count($files) > 500) {
        $err[] = 'Il plugin contiene troppi file.';
    }
    return array(array_slice($err, 0, 10), $info, $files, $v['info']);
}

// Estrae i file controllati in data/plugins/<id> (prima in una cartella nuova, poi lo scambio)
function plugin_extract($zip_path, $id, $files)
{
    $root = plugins_dir();
    if (!is_dir($root) && !@mkdir($root, 0775, true)) {
        throw new Exception('Impossibile creare la cartella data/plugins.');
    }
    if (!is_file($root . '/.htaccess')) {
        @file_put_contents($root . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    $new = $root . '/.nuovo_' . $id;
    plugin_rmdir($new);
    @mkdir($new, 0775, true);
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        throw new Exception('Pacchetto non leggibile.');
    }
    foreach (array_merge(array_keys($files), array('firma.json')) as $p) {
        $target = $new . '/' . $p;
        if (!is_dir(dirname($target))) {
            @mkdir(dirname($target), 0775, true);
        }
        $in = $zip->getStream($p);
        $out = @fopen($target, 'wb');
        if (!$in || !$out) {
            $zip->close();
            plugin_rmdir($new);
            throw new Exception('Impossibile scrivere il file ' . $p . ' (la cartella data/plugins è scrivibile?).');
        }
        stream_copy_to_stream($in, $out);
        fclose($in);
        fclose($out);
        if ($p !== 'firma.json' && !hash_equals($files[$p], hash_file('sha256', $target))) {
            $zip->close();
            plugin_rmdir($new);
            throw new Exception('Il file ' . $p . ' non corrisponde alla firma.');
        }
    }
    $zip->close();
    $dest = $root . '/' . $id;
    $old = $root . '/.vecchio_' . $id;
    plugin_rmdir($old);
    if (is_dir($dest) && !@rename($dest, $old)) {
        plugin_rmdir($new);
        throw new Exception('Impossibile sostituire la versione installata.');
    }
    if (!@rename($new, $dest)) {
        if (is_dir($old)) {
            @rename($old, $dest);
        }
        throw new Exception('Impossibile installare i file del plugin.');
    }
    plugin_rmdir($old);
}

function plugin_rmdir($d)
{
    if (!is_dir($d)) {
        return;
    }
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) {
        $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
    }
    @rmdir($d);
}

function plugin_get($id)
{
    $st = db()->prepare('SELECT * FROM plugins WHERE id = ?');
    $st->execute(array($id));
    $r = $st->fetch();
    return $r ? $r : null;
}

// Installa o aggiorna. Restituisce array(id, nuovo?, versione precedente)
function plugin_install($zip_path)
{
    list($err, $info, $files, $sig) = plugin_inspect_zip($zip_path);
    if ($err) {
        throw new Exception(implode(' ', $err));
    }
    $id = $info['id'];
    $old = plugin_get($id);
    plugin_extract($zip_path, $id, $files);
    $manifest = json_encode(array('files' => $files, 'firma' => $sig), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $vals = array(str_cut((string)$info['nome'], 100), (string)$info['versione'], str_cut(isset($info['autore']) ? (string)$info['autore'] : '', 100),
        str_cut(isset($info['descrizione']) ? (string)$info['descrizione'] : '', 500), $manifest, (string)$sig['impronta']);
    if ($old) {
        db()->prepare("UPDATE plugins SET name = ?, version = ?, author = ?, description = ?, manifest = ?, key_id = ?, status = 'ok', error = NULL, updated_at = ? WHERE id = ?")
            ->execute(array_merge($vals, array(now(), $id)));
    } else {
        db()->prepare("INSERT INTO plugins (name, version, author, description, manifest, key_id, id, active, status, installed_at, updated_at) VALUES (?,?,?,?,?,?,?,0,'ok',?,?)")
            ->execute(array_merge($vals, array($id, now(), now())));
    }
    // un plugin attivo aggiornato riparte con il nuovo codice alla prossima pagina, che esegue on_activate con la versione precedente
    if ($old && (int)$old['active'] === 1) {
        setting_save('plg_pending.' . $id, (string)$old['version']);
        load_settings(true);
    }
    return array($id, !$old, $old ? $old['version'] : '');
}

// Attiva: carica il codice, esegue on_activate. Se qualcosa va storto resta spento
function plugin_activate($id, $previous = '')
{
    $row = plugin_get($id);
    if (!$row) {
        throw new Exception('Plugin non trovato.');
    }
    $why = plugin_integrity($row, true);
    if ($why !== '') {
        plugin_set_status($id, 'manomesso', $why);
        throw new Exception($why);
    }
    $info = json_decode((string)@file_get_contents(plugins_dir() . '/' . $id . '/plugin.json'), true);
    try {
        $p = isset($GLOBALS['PLG_OBJ'][$id]) ? $GLOBALS['PLG_OBJ'][$id] : plugin_include($row, is_array($info) ? $info : array());
        if (!empty($GLOBALS['PLG_LIFE'][$id]['attiva'])) {
            $GLOBALS['PLG_CURRENT'] = $id;
            call_user_func($GLOBALS['PLG_LIFE'][$id]['attiva'], $p, $previous);
            $GLOBALS['PLG_CURRENT'] = null;
        }
    } catch (Throwable $e) {
        plugin_fail($id, $e);
        throw new Exception('Il plugin è andato in errore durante l\'attivazione: ' . $e->getMessage());
    }
    db()->prepare("UPDATE plugins SET active = 1, status = 'ok', error = NULL, updated_at = ? WHERE id = ?")->execute(array(now(), $id));
}

function plugin_deactivate($id)
{
    db()->prepare('UPDATE plugins SET active = 0, updated_at = ? WHERE id = ?')->execute(array(now(), $id));
}

function plugin_remove($id, $delete_data)
{
    $row = plugin_get($id);
    if (!$row) {
        return;
    }
    // il plugin puo' fare pulizia (tabelle sue): solo se il codice e' ancora integro
    if (plugin_integrity($row, true) === '') {
        try {
            $info = json_decode((string)@file_get_contents(plugins_dir() . '/' . $id . '/plugin.json'), true);
            $p = isset($GLOBALS['PLG_OBJ'][$id]) ? $GLOBALS['PLG_OBJ'][$id] : plugin_include($row, is_array($info) ? $info : array());
            if (!empty($GLOBALS['PLG_LIFE'][$id]['rimuovi'])) {
                call_user_func($GLOBALS['PLG_LIFE'][$id]['rimuovi'], $p, (bool)$delete_data);
            }
        } catch (Throwable $e) {
            app_log('plugin_errore', 'Errore nella pulizia del plugin "' . $id . '": ' . $e->getMessage(), 'warn');
        }
    }
    db()->prepare('DELETE FROM plugins WHERE id = ?')->execute(array($id));
    plugin_rmdir(plugins_dir() . '/' . $id);
    if ($delete_data) {
        db()->prepare('DELETE FROM settings WHERE setting_key LIKE ?')->execute(array('plg.' . $id . '.%'));
        plugin_rmdir(DATA_DIR . '/plugin_dati/' . $id);
    }
}

// Lavoro quotidiano dei plugin (chiamato dai lavori periodici)
function plugins_daily_due()
{
    return plugins_ready() && !empty($GLOBALS['LIB_HOOKS']['ogni_giorno']) && (int)setting('plg_daily_last', '0') < time() - 86400;
}

function plugins_daily_run()
{
    if (!plugins_daily_due()) {
        return;
    }
    setting_save('plg_daily_last', (string)time());
    lib_do('ogni_giorno');
}
