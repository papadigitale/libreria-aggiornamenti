<?php
/* Riquadro "Repository degli aggiornamenti" (Sistema → Aggiornamento) */
require_once APP_ROOT . '/inc/repo.php';
$r_url = (string)setting('repo_url', '');
$r_err = (string)setting('repo_error', '');
$r_when = (int)setting('repo_checked_at', '0');
$r_new = repo_aggiornamento();
$r_prop = repo_chiave_proposta();
$r_dati = repo_dati();
?>
<div class="card repo-card" id="repository">
  <div class="ct"><?= admin_icon('cloud', 18) ?> Repository degli aggiornamenti e dei plugin</div>
  <?php if ($r_new): ?>
  <div class="repo-new">
    <div class="repo-new-h"><b>È disponibile la versione <?= h($r_new['versione']) ?></b>
      <span class="muted">pubblicata il <?= h(date('d/m/Y', strtotime($r_new['data']))) ?> · installata: <?= h(APP_VERSION) ?></span></div>
    <?php foreach ($r_new['tutte_le_note'] ? $r_new['tutte_le_note'] : array(array('versione' => $r_new['versione'], 'note' => $r_new['note'])) as $nv): ?>
      <div class="repo-ver"><b><?= h($nv['versione']) ?></b><?php if (!empty($nv['note'])): ?><ul class="notes"><?php foreach ((array)$nv['note'] as $nt): ?><li><?= h($nt) ?></li><?php endforeach; ?></ul><?php endif; ?></div>
    <?php endforeach; ?>
    <?php if (IS_DOCKER): ?>
      <p class="hint">Con Docker scarica il nuovo pacchetto completo e ricostruisci l'immagine (istruzioni qui sotto).</p>
    <?php elseif (!$r_new['compatibile']): ?>
      <div class="alert error">Questa versione richiede la <?= h($r_new['richiede']) ?> della Libreria<?= $r_new['php_min'] !== '' ? ' e PHP ' . h($r_new['php_min']) : '' ?>.</div>
    <?php else: ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="repo_get_update">
        <button class="btn primary" type="submit"><?= admin_icon('upload', 16) ?> Scarica e controlla la versione <?= h($r_new['versione']) ?></button></form>
      <p class="hint">Il sito scarica il pacchetto, controlla che sia identico a quello del catalogo firmato e la firma del pacchetto, poi ti mostra il riepilogo: installi tu, con la password.</p>
    <?php endif; ?>
  </div>
  <?php elseif ($r_url !== '' && $r_dati && $r_err === ''): ?>
  <div class="sigline ok"><?= admin_icon('check', 16) ?><span>Il sito è aggiornato: nel repository non ci sono versioni più recenti della <?= h(APP_VERSION) ?>.</span></div>
  <?php endif; ?>

  <?php if ($r_err !== '' && !$r_prop): ?><div class="alert error"><?= h($r_err) ?></div><?php endif; ?>

  <?php if ($r_prop): ?>
  <div class="card inner repo-trust">
    <div class="ct"><?= admin_icon('shield', 16) ?> Fidarsi della chiave di questo repository?</div>
    <p class="sub">Il catalogo è firmato da <b><?= h($r_prop['autore']) ?></b> con la chiave di impronta</p>
    <p><code class="big-code"><?= h(firma_impronta_leggibile($r_prop['impronta'])) ?></code></p>
    <p class="hint">Confrontala con quella che ti ha dato chi pubblica gli aggiornamenti. Se la confermi diventa la <b>chiave dell'autore</b> di questo sito:
      da quel momento si installano solo aggiornamenti e plugin firmati con essa, e dal pannello non si potrà più cambiare.</p>
    <form method="post" class="row-btn"><?= csrf_field() ?><input type="hidden" name="action" value="repo_trust"><input type="hidden" name="impronta" value="<?= h($r_prop['impronta']) ?>">
      <input class="input" type="password" name="password" required autocomplete="current-password" placeholder="La tua password per confermare">
      <button class="btn primary small" type="submit">Mi fido di questa chiave</button></form>
  </div>
  <?php endif; ?>

  <form method="post" class="stack repo-form"><?= csrf_field() ?><input type="hidden" name="action" value="repo_save">
    <label class="lab" for="repo-url">Indirizzo del repository</label>
    <input class="input" id="repo-url" name="repo_url" value="<?= h($r_url) ?>" placeholder="https://raw.githubusercontent.com/utente/repository/main/" inputmode="url" autocomplete="off">
    <label class="check"><input type="checkbox" name="repo_check" value="1" <?= setting('repo_check', '1') === '1' ? 'checked' : '' ?>> Controlla da solo se ci sono novità (solo avviso: non installa niente da solo)</label>
    <div class="row-btn"><label class="lab" for="repo-int" style="margin:0">Ogni</label>
      <select class="input" id="repo-int" name="repo_intervallo" style="max-width:140px"><?php foreach (array(1 => '1 ora', 3 => '3 ore', 6 => '6 ore', 12 => '12 ore', 24 => '24 ore') as $hv => $ht): ?><option value="<?= $hv ?>" <?= repo_intervallo() === $hv ? 'selected' : '' ?>><?= $ht ?></option><?php endforeach; ?></select></div>
    <div class="row-btn"><button class="btn ghost small" type="submit">Salva</button>
      <?php if ($r_url !== ''): ?><button class="btn link small" type="submit" form="repo-check-form">Controlla adesso</button><?php endif; ?>
      <?php if ($r_when): ?><span class="muted small">Ultimo controllo: <?= h(date('d/m/Y H:i', $r_when)) ?></span><?php endif; ?></div>
  </form>
  <?php $cron = (int)setting('cron_last', '0'); $vis = (int)setting('visite_lavori_last', '0'); ?>
  <div class="fr row"><span>Prossimo controllo</span><span><?= $r_url === '' || setting('repo_check', '1') !== '1' ? '—' : ($r_when ? h(date('d/m/Y H:i', $r_when + repo_intervallo() * 3600)) : 'al prossimo giro dei lavori automatici') ?></span></div>
  <div class="fr row"><span>Lavori automatici del server (cron)</span><span><?= $cron && $cron > time() - 3 * 3600 ? '<span class="ok-text">attivi</span> · ultimo giro ' . h(date('d/m H:i', $cron))
      : ($cron ? '<span class="err-text">fermi dal ' . h(date('d/m H:i', $cron)) . '</span>' : '<span class="muted">non configurati: i controlli si fanno durante le visite al sito</span>') ?></span></div>
  <form method="post" id="repo-check-form"><?= csrf_field() ?><input type="hidden" name="action" value="repo_check"></form>
  <p class="hint">Il catalogo del repository è firmato: il sito lo accetta solo se la firma è della chiave dell'autore di questo sito, e non accetta cataloghi più vecchi dell'ultimo già visto.
    <?php if (!officina_attiva()): ?>I plugin del repository compaiono in <a class="link" href="gestione.php?sez=plugin#disponibili">Plugin → Disponibili</a>.<?php endif; ?></p>
</div>
