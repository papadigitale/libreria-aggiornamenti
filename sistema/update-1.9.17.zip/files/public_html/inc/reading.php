<?php
/*
 * Diario di lettura (come Goodreads): ogni lettura di un libro e' una "sessione" con inizio, fine, voto e recensione;
 * l'avanzamento (pagina o percentuale, con giorno e ora) appartiene alla sessione. Da qui nascono statistiche,
 * obiettivo dell'anno, trofei e classifica di famiglia.
 * La tabella user_books resta lo "stato attuale" (usato da ruota, filtri, righe della home) ed e' tenuta allineata qui.
 */
require_once dirname(__FILE__) . '/books.php';

function reading_ready()
{
    return (int)setting('db_version', '1') >= 8;
}

/* ================= Sessioni di lettura ================= */

function reading_sessions($uid, $book_id)
{
    $st = db()->prepare('SELECT * FROM reading_sessions WHERE user_id = ? AND book_id = ? ORDER BY COALESCE(started_at, finished_at, created_at) DESC, id DESC');
    $st->execute(array((int)$uid, (int)$book_id));
    return $st->fetchAll();
}

function reading_open_session($uid, $book_id)
{
    $st = db()->prepare("SELECT * FROM reading_sessions WHERE user_id = ? AND book_id = ? AND status = 'in_lettura' ORDER BY id DESC LIMIT 1");
    $st->execute(array((int)$uid, (int)$book_id));
    $r = $st->fetch();
    return $r ? $r : null;
}

function reading_session_get($uid, $sid)
{
    $st = db()->prepare('SELECT * FROM reading_sessions WHERE id = ? AND user_id = ?');
    $st->execute(array((int)$sid, (int)$uid));
    $r = $st->fetch();
    return $r ? $r : null;
}

function reading_session_add($uid, $book_id, $status, $started, $finished, $unknown = 0, $source = 'manuale')
{
    db()->prepare('INSERT INTO reading_sessions (user_id, book_id, status, started_at, finished_at, date_unknown, source, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
        ->execute(array((int)$uid, (int)$book_id, $status, $started, $finished, $unknown ? 1 : 0, $source, now(), now()));
    return (int)db()->lastInsertId();
}

function reading_progress_count($sid)
{
    $st = db()->prepare('SELECT COUNT(*) FROM reading_progress WHERE session_id = ?');
    $st->execute(array((int)$sid));
    return (int)$st->fetchColumn();
}

// Data e ora da un valore del modulo ('2026-11-03T09:30' o '2026-11-03'); null se non valida o nel futuro
function reading_parse_dt($s, $end_of_day = false)
{
    $s = trim((string)$s);
    if ($s === '') {
        return null;
    }
    $s = str_replace('T', ' ', $s);
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $s)) {
        $s .= $end_of_day ? ' 21:00:00' : ' 12:00:00';
    } elseif (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $s)) {
        $s .= ':00';
    }
    $t = strtotime($s);
    if ($t === false || $t > time() + 300 || $t < strtotime('1900-01-01')) {
        return null;
    }
    return date('Y-m-d H:i:s', $t);
}

/*
 * Cambia lo stato di lettura di un libro per un utente, tenendo la storia delle letture.
 * $opts: 'date' => data/ora (fine per "letto", inizio per "in lettura"), 'unknown' => data di fine sconosciuta,
 *        'source' => 'manuale' | 'multipla' | 'goodreads', 'new' => forza una nuova lettura (rilettura)
 * Restituisce true se e' cambiato qualcosa.
 */
function reading_set_status($uid, $book_id, $status, $opts = array())
{
    $uid = (int)$uid;
    $book_id = (int)$book_id;
    $statuses = reading_statuses();
    $status = isset($statuses[$status]) ? $status : '';
    $date = isset($opts['date']) && $opts['date'] ? $opts['date'] : now();
    $unknown = !empty($opts['unknown']);
    $source = isset($opts['source']) ? $opts['source'] : 'manuale';
    $cur = user_book_row($uid, $book_id);
    $open = reading_open_session($uid, $book_id);
    $changed = false;
    if ($status === 'in_lettura') {
        $all = $open ? array() : reading_sessions($uid, $book_id);
        if (!$open && $all && $all[0]['status'] === 'abbandonato' && empty($opts['new'])) {
            // si riprende un libro lasciato a meta': la lettura continua da dove era rimasta
            db()->prepare("UPDATE reading_sessions SET status = 'in_lettura', finished_at = NULL, date_unknown = 0, updated_at = ? WHERE id = ?")
                ->execute(array(now(), (int)$all[0]['id']));
            $changed = true;
        } elseif (!$open) {
            reading_session_add($uid, $book_id, 'in_lettura', $date, null, 0, $source);
            $changed = true;
        }
    } elseif ($status === 'letto' || $status === 'abbandonato') {
        if ($open) {
            db()->prepare('UPDATE reading_sessions SET status = ?, finished_at = ?, date_unknown = ?, updated_at = ? WHERE id = ?')
                ->execute(array($status, $unknown ? null : $date, $unknown ? 1 : 0, now(), (int)$open['id']));
            $changed = true;
        } elseif ($cur['status'] !== $status || !empty($opts['new'])) {
            reading_session_add($uid, $book_id, $status, null, $unknown ? null : $date, $unknown ? 1 : 0, $source);
            $changed = true;
        }
    } elseif ($open) {
        // tornato a "da leggere" o senza stato: la lettura in corso sparisce se e' vuota, altrimenti resta come abbandonata
        if (reading_progress_count($open['id']) === 0) {
            db()->prepare('DELETE FROM reading_sessions WHERE id = ?')->execute(array((int)$open['id']));
        } else {
            db()->prepare("UPDATE reading_sessions SET status = 'abbandonato', finished_at = ?, updated_at = ? WHERE id = ?")->execute(array(now(), now(), (int)$open['id']));
        }
        $changed = true;
    }
    if ($cur['status'] !== $status) {
        $changed = true;
    }
    reading_sync_user_book($uid, $book_id, $status);
    if ($cur['status'] !== $status && is_file(dirname(__FILE__) . '/notifiche.php')) {
        require_once dirname(__FILE__) . '/notifiche.php';
        notif_lettura($uid, $book_id, $status); // solo se lo fa l'utente stesso (non da importazioni o dal pannello)
    }
    return $changed;
}

// Allinea user_books (stato attuale e date) all'ultima lettura
function reading_sync_user_book($uid, $book_id, $status = null)
{
    $cur = user_book_row($uid, $book_id);
    $status = $status === null ? (string)$cur['status'] : $status;
    $started = null;
    $finished = null;
    if ($status === 'in_lettura' || $status === 'letto' || $status === 'abbandonato') {
        $last = reading_sessions($uid, $book_id);
        foreach ($last as $s) {
            if ($s['status'] === $status) {
                $started = $s['started_at'] ? substr($s['started_at'], 0, 10) : null;
                $finished = $s['finished_at'] ? substr($s['finished_at'], 0, 10) : null;
                break;
            }
        }
    }
    if (isset($cur['user_id'])) {
        db()->prepare('UPDATE user_books SET status = ?, started_at = ?, finished_at = ?, updated_at = ? WHERE user_id = ? AND book_id = ?')
            ->execute(array($status, $started, $finished, now(), (int)$uid, (int)$book_id));
    } else {
        db()->prepare('INSERT INTO user_books (user_id, book_id, status, wheel_excluded, started_at, finished_at, updated_at) VALUES (?,?,?,0,?,?,?)')
            ->execute(array((int)$uid, (int)$book_id, $status, $started, $finished, now()));
    }
}

// Rilettura: nuova lettura "in corso" anche se il libro e' gia' stato letto
function reading_start_reread($uid, $book_id)
{
    if (reading_open_session($uid, $book_id)) {
        return false;
    }
    reading_session_add($uid, $book_id, 'in_lettura', now(), null);
    reading_sync_user_book($uid, $book_id, 'in_lettura');
    return true;
}

// Modifica le date di una lettura
function reading_session_dates($uid, $sid, $started, $finished, $unknown)
{
    $s = reading_session_get($uid, $sid);
    if (!$s) {
        return 'Lettura non trovata.';
    }
    if ($started && $finished && $started > $finished) {
        return 'La data di inizio è dopo quella di fine.';
    }
    $fin = $s['status'] === 'in_lettura' ? null : ($unknown ? null : ($finished ? $finished : $s['finished_at']));
    db()->prepare('UPDATE reading_sessions SET started_at = ?, finished_at = ?, date_unknown = ?, updated_at = ? WHERE id = ?')
        ->execute(array($started, $fin, ($s['status'] !== 'in_lettura' && $unknown) ? 1 : 0, now(), (int)$sid));
    reading_sync_user_book($uid, $s['book_id']);
    return '';
}

function reading_session_delete($uid, $sid)
{
    $s = reading_session_get($uid, $sid);
    if (!$s) {
        return false;
    }
    db()->prepare('DELETE FROM reading_progress WHERE session_id = ?')->execute(array((int)$sid));
    db()->prepare('DELETE FROM reading_sessions WHERE id = ?')->execute(array((int)$sid));
    // lo stato attuale diventa quello dell'ultima lettura rimasta
    $left = reading_sessions($uid, $s['book_id']);
    $cur = user_book_row($uid, $s['book_id']);
    $status = $left ? $left[0]['status'] : ($cur['status'] === $s['status'] ? '' : (string)$cur['status']);
    reading_sync_user_book($uid, $s['book_id'], $status);
    return true;
}

// Voto (da 0,25 a 5, a quarti di stella; 0 = nessun voto) e recensione breve
function reading_rate($uid, $sid, $rating, $review)
{
    $s = reading_session_get($uid, $sid);
    if (!$s) {
        return false;
    }
    $r = round(((float)str_replace(',', '.', (string)$rating)) * 4) / 4;
    $r = $r <= 0 ? null : min(5, $r);
    $review = trim(str_replace("\r", '', (string)$review));
    db()->prepare('UPDATE reading_sessions SET rating = ?, review = ?, updated_at = ? WHERE id = ?')
        ->execute(array($r, $review === '' ? null : str_cut($review, 4000), now(), (int)$sid));
    if (($r !== null || $review !== '') && ((string)$s['rating'] !== (string)$r || (string)$s['review'] !== $review) && is_file(dirname(__FILE__) . '/notifiche.php')) {
        require_once dirname(__FILE__) . '/notifiche.php';
        notif_voto($uid, (int)$s['book_id'], $r, $review);
    }
    return true;
}

/* ================= Avanzamento ================= */

function reading_progress_list($sid)
{
    $st = db()->prepare('SELECT * FROM reading_progress WHERE session_id = ? ORDER BY read_at DESC, id DESC');
    $st->execute(array((int)$sid));
    return $st->fetchAll();
}

/*
 * Registra a che punto sei. $page oppure $percent (uno dei due). Apre la lettura se serve.
 * Restituisce array(ok, messaggio, finito)
 */
function reading_progress_add($uid, $book_id, $page, $percent, $read_at, $note)
{
    $b = book_get($book_id);
    if (!$b) {
        return array(false, 'Libro non trovato.', false);
    }
    $total = (int)$b['pages'];
    $page = $page === '' || $page === null ? null : (int)$page;
    $percent = $percent === '' || $percent === null ? null : (float)str_replace(',', '.', (string)$percent);
    if ($page === null && $percent === null) {
        return array(false, 'Scrivi la pagina a cui sei arrivato (o la percentuale).', false);
    }
    if ($page !== null) {
        if ($page < 0 || ($total > 0 && $page > $total) || $page > 100000) {
            return array(false, $total > 0 ? 'La pagina deve essere tra 0 e ' . $total . '.' : 'Pagina non valida.', false);
        }
        $percent = $total > 0 ? round($page / $total * 100, 2) : null;
    } else {
        if ($percent < 0 || $percent > 100) {
            return array(false, 'La percentuale deve essere tra 0 e 100.', false);
        }
        $page = $total > 0 ? (int)round($total * $percent / 100) : null;
    }
    $read_at = $read_at ? $read_at : now();
    $open = reading_open_session($uid, $book_id);
    if (!$open) {
        reading_set_status($uid, $book_id, 'in_lettura', array('date' => $read_at));
        $open = reading_open_session($uid, $book_id);
    } elseif ($open['started_at'] === null || $open['started_at'] > $read_at) {
        db()->prepare('UPDATE reading_sessions SET started_at = ? WHERE id = ?')->execute(array($read_at, (int)$open['id']));
    }
    $prima = reading_last_point($open['id']);
    db()->prepare('INSERT INTO reading_progress (session_id, user_id, book_id, page, percent, note, read_at, created_at) VALUES (?,?,?,?,?,?,?,?)')
        ->execute(array((int)$open['id'], (int)$uid, (int)$book_id, $page, $percent, str_cut(trim((string)$note), 500) ?: null, $read_at, now()));
    // avviso "a meta' libro" (una volta, quando si passa il 50%)
    $p_prima = $prima && $prima['percent'] !== null ? (float)$prima['percent'] : 0;
    if ($percent !== null && $p_prima < 50 && $percent >= 50 && $percent < 100 && is_file(dirname(__FILE__) . '/notifiche.php')) {
        require_once dirname(__FILE__) . '/notifiche.php';
        notif_meta($uid, $book_id);
    }
    db()->prepare('UPDATE reading_sessions SET updated_at = ? WHERE id = ?')->execute(array(now(), (int)$open['id']));
    $done = ($total > 0 && $page !== null && $page >= $total) || ($percent !== null && $percent >= 100);
    return array(true, 'Avanzamento salvato' . ($page !== null ? ': pagina ' . $page . ($total ? ' di ' . $total : '') : '') . ($percent !== null ? ' (' . rtrim(rtrim(number_format($percent, 1, ',', ''), '0'), ',') . '%)' : '') . '.', $done);
}

function reading_progress_delete($uid, $pid)
{
    $st = db()->prepare('DELETE FROM reading_progress WHERE id = ? AND user_id = ?');
    $st->execute(array((int)$pid, (int)$uid));
    return $st->rowCount() > 0;
}

// Ultimo punto raggiunto in una lettura: array(page, percent) o null
function reading_last_point($sid)
{
    $st = db()->prepare('SELECT page, percent, read_at FROM reading_progress WHERE session_id = ? ORDER BY read_at DESC, id DESC LIMIT 1');
    $st->execute(array((int)$sid));
    $r = $st->fetch();
    return $r ? $r : null;
}

/* ================= Pagine lette giorno per giorno ================= */

// Distribuisce $pages sui giorni da $from a $to (compresi), un po' per giorno
function reading_spread(&$days, $book_id, $pages, $from, $to)
{
    if ($pages <= 0) {
        return;
    }
    $a = strtotime(substr($from, 0, 10));
    $b = strtotime(substr($to, 0, 10));
    if ($a === false || $b === false || $a > $b) {
        $a = $b;
    }
    $n = (int)round(($b - $a) / 86400) + 1;
    if ($n > 366) {
        $a = $b - 365 * 86400;
        $n = 366;
    }
    $each = floor($pages / $n);
    $rest = $pages - $each * $n;
    for ($i = 0; $i < $n; $i++) {
        $p = $each + ($i < $rest ? 1 : 0);
        if ($p > 0) {
            $d = date('Y-m-d', $a + $i * 86400 + 3600);
            $days[] = array($d, $book_id, (int)$p);
        }
    }
}

/*
 * Tutte le letture di un utente, con le pagine lette giorno per giorno.
 * Le pagine contano dalle differenze tra un avanzamento e l'altro; le pagine mancanti alla fine di un libro letto
 * si distribuiscono tra l'ultimo avanzamento (o l'inizio) e la fine. Un libro segnato come letto senza avanzamenti
 * conta tutte le sue pagine sul giorno di fine (o tra inizio e fine se l'inizio e' noto).
 */
function reading_data($uid, $reset = false)
{
    static $cache = array();
    $uid = (int)$uid;
    if (isset($cache[$uid]) && !$reset) {
        return $cache[$uid];
    }
    $st = db()->prepare('SELECT s.*, b.title, b.authors, b.pages AS book_pages, b.category_id, b.cover_file, b.isbn13 FROM reading_sessions s '
        . 'INNER JOIN books b ON b.id = s.book_id WHERE s.user_id = ? ORDER BY s.id');
    $st->execute(array($uid));
    $sessions = array();
    foreach ($st->fetchAll() as $s) {
        $s['progress'] = array();
        $sessions[(int)$s['id']] = $s;
    }
    $st = db()->prepare('SELECT session_id, page, percent, read_at FROM reading_progress WHERE user_id = ? ORDER BY read_at, id');
    $st->execute(array($uid));
    foreach ($st->fetchAll() as $p) {
        if (isset($sessions[(int)$p['session_id']])) {
            $sessions[(int)$p['session_id']]['progress'][] = $p;
        }
    }
    $days = array();     // array(data, libro, pagine)
    $active = array();   // giorni con almeno un avanzamento (anche senza pagine)
    $unknown_pages = 0;  // pagine dei libri letti in data sconosciuta
    foreach ($sessions as $sid => $s) {
        $total = (int)$s['book_pages'];
        $prev = 0;
        $last_day = $s['started_at'];
        $first = true;
        foreach ($s['progress'] as $p) {
            $page = $p['page'] !== null ? (int)$p['page'] : ($total > 0 && $p['percent'] !== null ? (int)round($total * (float)$p['percent'] / 100) : null);
            $active[substr($p['read_at'], 0, 10)] = true;
            if ($page === null) {
                continue;
            }
            $delta = $page - $prev;
            if ($delta > 0) {
                if ($first && $s['started_at'] && substr($s['started_at'], 0, 10) < substr($p['read_at'], 0, 10)) {
                    reading_spread($days, (int)$s['book_id'], $delta, $s['started_at'], $p['read_at']);
                } else {
                    $days[] = array(substr($p['read_at'], 0, 10), (int)$s['book_id'], $delta);
                }
            }
            $prev = $page;
            $last_day = $p['read_at'];
            $first = false;
        }
        $sessions[$sid]['pages_read'] = $prev;
        if ($s['status'] === 'letto' && $total > 0 && $total > $prev) {
            if ((int)$s['date_unknown'] || !$s['finished_at']) {
                $unknown_pages += $total - $prev;
            } else {
                $from = $last_day ? $last_day : $s['finished_at'];
                if ($s['progress'] && $last_day && substr($last_day, 0, 10) < substr($s['finished_at'], 0, 10)) {
                    $from = date('Y-m-d', strtotime(substr($last_day, 0, 10)) + 86400 + 3600);
                }
                reading_spread($days, (int)$s['book_id'], $total - $prev, $from, $s['finished_at']);
            }
            $sessions[$sid]['pages_read'] = $total;
        }
        if ($s['status'] === 'letto' && $s['finished_at'] && !(int)$s['date_unknown']) {
            $active[substr($s['finished_at'], 0, 10)] = true;
        }
    }
    $daily = array();
    foreach ($days as $d) {
        $daily[$d[0]] = (isset($daily[$d[0]]) ? $daily[$d[0]] : 0) + $d[2];
        if ($d[2] > 0) {
            $active[$d[0]] = true;
        }
    }
    ksort($daily);
    ksort($active);
    return $cache[$uid] = array('sessions' => $sessions, 'days' => $days, 'daily' => $daily, 'active' => $active, 'unknown_pages' => $unknown_pages);
}

// Serie di giorni consecutivi: array(attuale, migliore, migliore nell'anno)
function reading_streaks($active, $year = null)
{
    $best = 0;
    $best_year = 0;
    $run = 0;
    $prev = null;
    foreach (array_keys($active) as $d) {
        $t = strtotime($d . ' 12:00:00');
        $run = ($prev !== null && abs($t - $prev - 86400) < 7200) ? $run + 1 : 1;
        $prev = $t;
        $best = max($best, $run);
        if ($year !== null && substr($d, 0, 4) === (string)$year) {
            // la serie si conta solo dentro l'anno
            $y_run = isset($y_prev) && abs($t - $y_prev - 86400) < 7200 ? $y_run + 1 : 1;
            $y_prev = $t;
            $best_year = max($best_year, $y_run);
        }
    }
    $current = 0;
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', time() - 86400);
    if (isset($active[$today]) || isset($active[$yesterday])) {
        $t = strtotime((isset($active[$today]) ? $today : $yesterday) . ' 12:00:00');
        while (isset($active[date('Y-m-d', $t)])) {
            $current++;
            $t -= 86400;
        }
    }
    return array($current, $best, $best_year);
}

/* ================= Statistiche ================= */

function reading_goal($uid, $year)
{
    $st = db()->prepare('SELECT books FROM reading_goals WHERE user_id = ? AND year = ?');
    $st->execute(array((int)$uid, (int)$year));
    return (int)$st->fetchColumn();
}

function reading_goal_save($uid, $year, $books)
{
    db()->prepare('DELETE FROM reading_goals WHERE user_id = ? AND year = ?')->execute(array((int)$uid, (int)$year));
    if ((int)$books > 0) {
        db()->prepare('INSERT INTO reading_goals (user_id, year, books) VALUES (?,?,?)')->execute(array((int)$uid, (int)$year, min(1000, (int)$books)));
    }
}

function reading_years($uid)
{
    $d = reading_data($uid);
    $years = array((int)date('Y') => true);
    foreach ($d['sessions'] as $s) {
        foreach (array('finished_at', 'started_at') as $k) {
            if ($s[$k]) {
                $years[(int)substr($s[$k], 0, 4)] = true;
            }
        }
    }
    foreach (array_keys($d['daily']) as $day) {
        $years[(int)substr($day, 0, 4)] = true;
    }
    krsort($years);
    return array_keys($years);
}

function reading_stats($uid, $year)
{
    $year = (int)$year;
    $y = (string)$year;
    $d = reading_data($uid);
    $finished = array();
    $all_finished = 0;
    $rated = array();
    foreach ($d['sessions'] as $s) {
        if ($s['status'] !== 'letto') {
            continue;
        }
        $all_finished++;
        if ($s['finished_at'] && !(int)$s['date_unknown'] && substr($s['finished_at'], 0, 4) === $y) {
            $finished[] = $s;
            if ($s['rating'] !== null) {
                $rated[] = $s;
            }
        }
    }
    usort($finished, function ($a, $b) { return strcmp($b['finished_at'], $a['finished_at']); });
    $months_pages = array_fill(1, 12, 0);
    $months_books = array_fill(1, 12, 0);
    $weeks = array();
    $heat = array();
    $by_book = array();
    $pages = 0;
    foreach ($d['days'] as $e) {
        if (substr($e[0], 0, 4) !== $y) {
            continue;
        }
        $pages += $e[2];
        $months_pages[(int)substr($e[0], 5, 2)] += $e[2];
        $t = strtotime($e[0] . ' 12:00:00');
        $wk = date('Y-m-d', $t - ((int)date('N', $t) - 1) * 86400); // lunedi' della settimana
        $weeks[$wk] = (isset($weeks[$wk]) ? $weeks[$wk] : 0) + $e[2];
        $heat[$e[0]] = (isset($heat[$e[0]]) ? $heat[$e[0]] : 0) + $e[2];
        $by_book[$e[1]] = (isset($by_book[$e[1]]) ? $by_book[$e[1]] : 0) + $e[2];
    }
    foreach ($finished as $s) {
        $months_books[(int)substr($s['finished_at'], 5, 2)]++;
    }
    $days_read = 0;
    foreach (array_keys($d['active']) as $day) {
        if (substr($day, 0, 4) === $y) {
            $days_read++;
        }
    }
    $best_week = null;
    if ($weeks) {
        arsort($weeks);
        $k = key($weeks);
        $best_week = array('from' => $k, 'to' => date('Y-m-d', strtotime($k . ' 12:00:00') + 6 * 86400), 'pages' => current($weeks));
    }
    $best_day = null;
    if ($heat) {
        $tmp = $heat;
        arsort($tmp);
        $best_day = array('day' => key($tmp), 'pages' => current($tmp));
    }
    $top_book = null;
    if ($by_book) {
        arsort($by_book);
        $bid = key($by_book);
        $top_book = array('book' => book_get($bid), 'pages' => current($by_book));
    }
    $longest = null;
    $fastest = null;
    $durations = array();
    foreach ($finished as $s) {
        if ((int)$s['book_pages'] > 0 && (!$longest || (int)$s['book_pages'] > (int)$longest['book_pages'])) {
            $longest = $s;
        }
        if ($s['started_at']) {
            $days = max(1, (int)round((strtotime(substr($s['finished_at'], 0, 10)) - strtotime(substr($s['started_at'], 0, 10))) / 86400) + 1);
            $durations[] = $days;
            if (!$fastest || $days < $fastest['days'] || ($days === $fastest['days'] && (int)$s['book_pages'] > (int)$fastest['book_pages'])) {
                $fastest = $s + array('days' => $days);
                $fastest['days'] = $days;
            }
        }
    }
    $genres = array();
    $authors = array();
    foreach ($finished as $s) {
        $g = $s['category_id'] ? category_name($s['category_id']) : '';
        if ($g !== '') {
            $genres[$g] = (isset($genres[$g]) ? $genres[$g] : 0) + 1;
        }
        foreach (array_filter(array_map('trim', preg_split('/[,;]| e /', (string)$s['authors']))) as $a) {
            $authors[$a] = (isset($authors[$a]) ? $authors[$a] : 0) + 1;
        }
    }
    arsort($genres);
    arsort($authors);
    usort($rated, function ($a, $b) { return $b['rating'] == $a['rating'] ? strcmp($b['finished_at'], $a['finished_at']) : ($b['rating'] > $a['rating'] ? 1 : -1); });
    $avg_rating = $rated ? array_sum(array_map(function ($s) { return (float)$s['rating']; }, $rated)) / count($rated) : 0;
    $elapsed = $year === (int)date('Y') ? (int)date('z') + 1 : ((int)date('L', mktime(0, 0, 0, 1, 1, $year)) ? 366 : 365);
    if ($year > (int)date('Y')) {
        $elapsed = 1;
    }
    $goal = reading_goal($uid, $year);
    $year_len = (int)date('L', mktime(0, 0, 0, 1, 1, $year)) ? 366 : 365;
    $expected = $goal ? $goal * $elapsed / $year_len : 0;
    $streaks = reading_streaks($d['active'], $year);
    $reading_now = array();
    foreach ($d['sessions'] as $s) {
        if ($s['status'] === 'in_lettura') {
            $reading_now[] = $s;
        }
    }
    return array(
        'year' => $year,
        'books' => count($finished),
        'pages' => $pages,
        'days_read' => $days_read,
        'avg_day' => $pages / max(1, $elapsed),
        'avg_reading_day' => $days_read ? $pages / $days_read : 0,
        'months_pages' => $months_pages,
        'months_books' => $months_books,
        'best_week' => $best_week,
        'best_day' => $best_day,
        'heat' => $heat,
        'top_book' => $top_book,
        'longest' => $longest,
        'fastest' => $fastest,
        'avg_days' => $durations ? array_sum($durations) / count($durations) : 0,
        'genres' => array_slice($genres, 0, 6, true),
        'authors' => array_slice($authors, 0, 6, true),
        'avg_rating' => $avg_rating,
        'top_rated' => array_slice($rated, 0, 5),
        'finished' => $finished,
        'goal' => $goal,
        'goal_diff' => $goal ? count($finished) - $expected : 0,
        'streak_now' => $streaks[0],
        'streak_best' => $streaks[1],
        'streak_best_year' => $streaks[2],
        'all_books' => $all_finished,
        'all_pages' => array_sum($d['daily']) + $d['unknown_pages'],
        'reading_now' => $reading_now,
    );
}

/* ================= Trofei ================= */

function reading_levels()
{
    return array(1 => 'Bronzo', 2 => 'Argento', 3 => 'Oro', 4 => 'Platino', 5 => 'Diamante');
}

// codice => array(nome, descrizione con %s per la soglia, soglie per livello)
function reading_trophy_defs()
{
    return array(
        'primo'       => array('Primo traguardo', 'Hai finito il tuo primo libro', array(1)),
        'libri_anno'  => array('Lettore dell\'anno', '%s libri letti in un anno', array(5, 12, 25, 50, 100)),
        'pagine'      => array('Macinapagine', '%s pagine lette in tutto', array(1000, 5000, 10000, 25000, 50000)),
        'serie'       => array('Costanza', '%s giorni di lettura di fila', array(7, 30, 100, 365)),
        'maratoneta'  => array('Maratoneta', 'Un libro di almeno %s pagine finito', array(800)),
        'divoratore'  => array('Divoratore', '%s pagine lette in un solo giorno', array(100)),
        'esploratore' => array('Esploratore', 'Libri di %s generi diversi in un anno', array(5)),
        'obiettivo'   => array('Obiettivo raggiunto', 'Hai raggiunto l\'obiettivo dell\'anno', array(1)),
        'ritorno'     => array('Ritorno', 'Hai riletto un libro', array(1)),
        'critico'     => array('Critico', '%s recensioni scritte', array(10)),
    );
}

// Valori raggiunti per ogni trofeo
function reading_trophy_values($uid)
{
    $d = reading_data($uid);
    $per_year = array();
    $genres_year = array();
    $max_book = 0;
    $reviews = 0;
    $read_count = array();
    $finished = 0;
    foreach ($d['sessions'] as $s) {
        if ($s['review'] !== null && trim($s['review']) !== '') {
            $reviews++;
        }
        if ($s['status'] !== 'letto') {
            continue;
        }
        $finished++;
        $read_count[$s['book_id']] = (isset($read_count[$s['book_id']]) ? $read_count[$s['book_id']] : 0) + 1;
        $max_book = max($max_book, (int)$s['book_pages']);
        if ($s['finished_at'] && !(int)$s['date_unknown']) {
            $yy = substr($s['finished_at'], 0, 4);
            $per_year[$yy] = (isset($per_year[$yy]) ? $per_year[$yy] : 0) + 1;
            if ($s['category_id']) {
                $genres_year[$yy][(int)$s['category_id']] = true;
            }
        }
    }
    $goal_hit = 0;
    $st = db()->prepare('SELECT year, books FROM reading_goals WHERE user_id = ?');
    $st->execute(array((int)$uid));
    foreach ($st->fetchAll() as $g) {
        if ((int)$g['books'] > 0 && isset($per_year[$g['year']]) && $per_year[$g['year']] >= (int)$g['books']) {
            $goal_hit = 1;
        }
    }
    $streaks = reading_streaks($d['active']);
    $gy = 0;
    foreach ($genres_year as $g) {
        $gy = max($gy, count($g));
    }
    return array(
        'primo' => $finished,
        'libri_anno' => $per_year ? max($per_year) : 0,
        'pagine' => array_sum($d['daily']) + $d['unknown_pages'],
        'serie' => $streaks[1],
        'maratoneta' => $max_book,
        'divoratore' => $d['daily'] ? max($d['daily']) : 0,
        'esploratore' => $gy,
        'obiettivo' => $goal_hit,
        'ritorno' => $read_count && max($read_count) > 1 ? 1 : 0,
        'critico' => $reviews,
    );
}

/*
 * Controlla i trofei e registra quelli nuovi. Restituisce i nuovi sbloccati: array(array(nome, livello))
 */
function reading_trophies_check($uid)
{
    if (!reading_ready()) {
        return array();
    }
    reading_data($uid, true);
    $vals = reading_trophy_values($uid);
    $have = array();
    $st = db()->prepare('SELECT code, level FROM user_trophies WHERE user_id = ?');
    $st->execute(array((int)$uid));
    foreach ($st->fetchAll() as $r) {
        $have[$r['code'] . ':' . $r['level']] = true;
    }
    $new = array();
    $levels = reading_levels();
    foreach (reading_trophy_defs() as $code => $t) {
        foreach ($t[2] as $i => $need) {
            if ($vals[$code] >= $need && !isset($have[$code . ':' . ($i + 1)])) {
                db()->prepare('INSERT INTO user_trophies (user_id, code, level, unlocked_at, seen) VALUES (?,?,?,?,0)')
                    ->execute(array((int)$uid, $code, $i + 1, now()));
                $new[] = array($t[0], count($t[2]) > 1 ? $levels[$i + 1] : '');
            }
        }
    }
    return $new;
}

// Messaggio con i trofei appena sbloccati (vuoto se nessuno)
function reading_trophies_flash($uid)
{
    $new = reading_trophies_check($uid);
    if (!$new) {
        return '';
    }
    $parts = array();
    foreach (array_slice($new, -3) as $n) {
        $parts[] = '"' . $n[0] . '"' . ($n[1] !== '' ? ' (' . $n[1] . ')' : '');
    }
    return (count($new) === 1 ? ' Nuovo trofeo: ' : ' Nuovi trofei: ') . implode(', ', $parts) . (count($new) > 3 ? ' e altri' : '') . '!';
}

// Tutti i trofei con lo stato per la pagina delle statistiche
function reading_trophies_board($uid)
{
    $vals = reading_trophy_values($uid);
    $got = array();
    $st = db()->prepare('SELECT code, level, unlocked_at FROM user_trophies WHERE user_id = ?');
    $st->execute(array((int)$uid));
    foreach ($st->fetchAll() as $r) {
        $got[$r['code']][(int)$r['level']] = $r['unlocked_at'];
    }
    $out = array();
    foreach (reading_trophy_defs() as $code => $t) {
        $level = isset($got[$code]) ? max(array_keys($got[$code])) : 0;
        $next = isset($t[2][$level]) ? $t[2][$level] : null;
        $shown = $next !== null ? $next : $t[2][count($t[2]) - 1];
        $out[$code] = array(
            'name' => $t[0],
            'text' => sprintf($t[1], number_format($shown, 0, ',', '.')),
            'level' => $level,
            'levels' => count($t[2]),
            'value' => $vals[$code],
            'next' => $next,
            'prev' => $level > 0 ? $t[2][$level - 1] : 0,
            'date' => $level > 0 ? $got[$code][$level] : null,
        );
    }
    return $out;
}

function reading_trophies_count($uid)
{
    $st = db()->prepare('SELECT COUNT(*) FROM user_trophies WHERE user_id = ?');
    $st->execute(array((int)$uid));
    return (int)$st->fetchColumn();
}

/* ================= Classifica di famiglia ================= */

function reading_leaderboard($year)
{
    $rows = array();
    require_once dirname(__FILE__) . '/notifiche.php';
    // chi ha scelto di non mostrare le sue letture non compare agli altri (a se stesso si')
    $st = db()->prepare("SELECT id, username, display_name FROM users WHERE active = 1 AND role IN ('admin','gestore','registrato')"
        . (notif_ready() ? ' AND (share_reading = 1 OR id = ?)' : ' AND id <> ?') . ' ORDER BY id');
    $st->execute(array(notif_ready() ? current_uid() : -1));
    foreach ($st->fetchAll() as $u) {
        $s = reading_stats($u['id'], $year);
        $rows[] = array(
            'uid' => (int)$u['id'],
            'name' => $u['display_name'] !== '' ? $u['display_name'] : $u['username'],
            'books' => $s['books'],
            'pages' => $s['pages'],
            'days' => $s['days_read'],
            'streak' => $s['streak_best_year'],
            'trophies' => reading_trophies_count($u['id']),
            'goal' => $s['goal'],
        );
    }
    return $rows;
}

/* ================= Stelle ================= */

/*
 * Stelle sotto le copertine della Libreria (impostazione lib_stars): 'off', 'mio' (il voto di chi guarda) o 'media'.
 * Ogni utente conta una volta per libro, con il voto della sua lettura più recente. Un'unica query per pagina.
 */
function lib_stars_mode()
{
    $m = setting('lib_stars');
    if (!in_array($m, array('off', 'mio', 'media'), true) || !reading_ready()) {
        return 'off';
    }
    return $m === 'mio' && !is_user() ? 'off' : $m;
}

function lib_stars_map()
{
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = array();
    $mode = lib_stars_mode();
    if ($mode === 'off') {
        return $map;
    }
    $sql = 'SELECT book_id, user_id, rating FROM reading_sessions WHERE rating IS NOT NULL AND rating > 0'
        . ($mode === 'mio' ? ' AND user_id = ?' : '') . ' ORDER BY COALESCE(finished_at, started_at, created_at), id';
    $st = db()->prepare($sql);
    $st->execute($mode === 'mio' ? array(current_uid()) : array());
    $per = array();
    foreach ($st->fetchAll() as $r) {
        $per[(int)$r['book_id']][(int)$r['user_id']] = (float)$r['rating']; // l'ultima lettura valutata vince
    }
    foreach ($per as $bid => $voti) {
        $map[$bid] = array(array_sum($voti) / count($voti), count($voti));
    }
    return $map;
}

// HTML delle stelle per la copertina di un libro ('' se non ci sono voti o l'opzione è spenta)
function lib_stars_html($book_id)
{
    $map = lib_stars_map();
    if (!isset($map[(int)$book_id])) {
        return '';
    }
    list($v, $n) = $map[(int)$book_id];
    $v = round($v * 4) / 4;
    $tip = lib_stars_mode() === 'media' ? rating_text($v) . ' su 5 · ' . $n . ($n === 1 ? ' voto' : ' voti') : 'Il tuo voto: ' . rating_text($v) . ' su 5';
    return '<span class="istars" title="' . h($tip) . '">' . stars_html($v, 'sm') . '</span>';
}

function stars_html($rating, $size = '')
{
    $r = (float)$rating;
    $label = rtrim(rtrim(number_format($r, 2, ',', ''), '0'), ',');
    return '<span class="stars' . ($size ? ' ' . $size : '') . '" role="img" aria-label="' . h($label) . ' stelle su 5" title="' . h($label) . ' su 5">'
        . '<span class="stars-on" style="width:' . round($r / 5 * 100, 2) . '%">★★★★★</span>★★★★★</span>';
}

function rating_text($r)
{
    return rtrim(rtrim(number_format((float)$r, 2, ',', ''), '0'), ',');
}
