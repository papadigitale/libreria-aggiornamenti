<?php
/* Il mio account → Notifiche sul telefono e suoni (1.9.16). Variabili da account.php: $full, $uid */
require_once APP_ROOT . '/inc/push.php';
if (!is_file(APP_ROOT . '/inc/notifiche.php') || !push_ready() || !in_array($full['role'], user_roles(), true) || officina_attiva()) {
    return;
}
require_once APP_ROOT . '/inc/notifiche.php';
$pp = push_prefs($full);
$np = notif_prefs($full);
$disp = push_dispositivi($uid);
$attivo = push_attivo();
?>
<form method="post" class="card stack" id="notifiche-push">
  <?= csrf_field() ?><input type="hidden" name="action" value="push_prefs">
  <div class="ct"><?= icon('bell', 18) ?> Notifiche sul telefono e suoni</div>
  <p class="sub">Gli avvisi della campanella arrivano anche come notifiche del telefono o del computer, con il loro suono, pure a sito chiuso.
    Si attivano su ogni dispositivo che usi.</p>

  <div class="push-box" data-push>
    <div class="lab">Questo dispositivo</div>
    <p class="push-stato" data-push-stato><?= $attivo ? 'Controllo…' : 'Le notifiche sul telefono sono spente per tutto il sito (le accende l\'amministratore).' ?></p>
    <div class="row-btn">
      <button class="btn primary small" type="button" data-push-attiva hidden><?= icon('bell', 16) ?> Attiva le notifiche</button>
      <button class="btn ghost small" type="button" data-push-prova hidden>Prova</button>
      <button class="btn link small" type="button" data-push-spegni hidden>Spegnile su questo dispositivo</button>
    </div>
    <div class="hint push-ios" data-push-ios hidden>
      <b>iPhone e iPad (iOS 16.4 o successivo):</b> apri il sito in Safari, tocca <b>Condividi</b> → <b>Aggiungi alla schermata Home</b>,
      poi apri la Libreria dall'icona sulla schermata Home e torna qui per attivare le notifiche.
    </div>
    <div class="alert" data-push-esito hidden></div>
  </div>

  <?php if ($disp): ?>
  <div class="lab">I tuoi dispositivi con le notifiche</div>
  <ul class="push-disp">
    <?php foreach ($disp as $d): ?>
    <li><span><b><?= h(push_nome_dispositivo($d['user_agent'])) ?></b>
      <small>dal <?= h(date('d/m/Y', strtotime($d['created_at']))) ?><?= $d['last_ok_at'] ? ' · ultima notifica ' . h(date('d/m/Y H:i', strtotime($d['last_ok_at']))) : '' ?><?= (int)$d['fails'] && $d['last_error'] ? ' · <span class="err-text">non arrivata: ' . h(str_cut($d['last_error'], 90)) . '</span>' : '' ?></small></span>
      <button class="btn link small" type="submit" form="push-togli-<?= (int)$d['id'] ?>">Togli</button></li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>

  <div class="lab">Cosa arriva come notifica</div>
  <?php foreach (notif_tipi() as $k => $t): if (!notif_tipo_per($k, $full['role'])) { continue; } $nella = !isset($np[$k]) || $np[$k]; ?>
  <label class="check"><input type="checkbox" name="p_<?= h($k) ?>" value="1" <?= !isset($pp['tipi'][$k]) || $pp['tipi'][$k] ? 'checked' : '' ?>>
    <span><b><?= h($t[0]) ?></b><?= $nella ? '' : ' <small class="muted">· spento nella campanella, quindi non arriva</small>' ?></span></label>
  <?php endforeach; ?>

  <div class="lab">Orario di silenzio</div>
  <label class="check switch"><input type="checkbox" name="silenzio" value="1" <?= $pp['silenzio']['on'] ? 'checked' : '' ?>><span>Niente notifiche sul telefono in queste ore</span></label>
  <div class="row2 push-ore">
    <div><label class="lab" for="ps-dal">Dalle</label><input class="input" id="ps-dal" type="time" name="dal" value="<?= h($pp['silenzio']['dal']) ?>"></div>
    <div><label class="lab" for="ps-al">Alle</label><input class="input" id="ps-al" type="time" name="al" value="<?= h($pp['silenzio']['al']) ?>"></div>
  </div>
  <p class="hint">Va anche a cavallo della mezzanotte (per esempio dalle 22:30 alle 07:30). Gli avvisi restano comunque nella campanella.</p>

  <div class="lab">Suono con il sito aperto</div>
  <div class="row-btn push-suono">
    <select class="input" name="suono" data-suono-scelta aria-label="Suono degli avvisi">
      <option value=""<?= $pp['suono'] === '' ? ' selected' : '' ?>>Nessun suono</option>
      <?php foreach (push_suoni() as $k => $n): ?><option value="<?= h($k) ?>"<?= $pp['suono'] === $k ? ' selected' : '' ?>><?= h($n) ?></option><?php endforeach; ?>
    </select>
    <button class="btn ghost small" type="button" data-suono-ascolta>▶ Ascolta</button>
  </div>
  <p class="hint">Suona quando arriva un avviso mentre stai usando il sito. A sito chiuso le notifiche hanno il suono scelto nelle impostazioni del telefono.</p>

  <button class="btn ghost" type="submit">Salva</button>
</form>
<?php foreach ($disp as $d): ?>
<form method="post" id="push-togli-<?= (int)$d['id'] ?>" data-confirm="Togliere le notifiche da questo dispositivo?"><?= csrf_field() ?><input type="hidden" name="action" value="push_togli_id"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"></form>
<?php endforeach; ?>
