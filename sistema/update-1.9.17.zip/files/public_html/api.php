<?php
/*
 * Servizi richiamati dalle pagine (risposte JSON).
 */
define('IS_API', true);
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/books.php';
require_once APP_ROOT . '/inc/lookup.php';
require_once APP_ROOT . '/inc/wheel.php';

function out($data, $code = 200)
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if ($code !== 200) {
        header('HTTP/1.1 ' . $code . ' Error');
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function need($ok, $msg = 'Operazione non consentita.')
{
    if (!$ok) {
        out(array('ok' => false, 'error' => $msg), 403);
    }
}

$action = isset($_REQUEST['action']) ? (string)$_REQUEST['action'] : '';

/* ---------- Accesso con chiave di accesso (passkey): prima del login ---------- */
if ($action === 'passkey_login_options' || $action === 'passkey_login_finish') {
    require_once APP_ROOT . '/inc/webauthn.php';
    require_once APP_ROOT . '/inc/auth.php';
    need(pk_enabled(), 'Le chiavi di accesso non sono attive su questo sito.');
    need($_SERVER['REQUEST_METHOD'] === 'POST');
    check_csrf();
    if (!pk_available_here()) {
        out(array('ok' => false, 'error' => 'Le chiavi di accesso funzionano solo aprendo il sito dal suo indirizzo https://, non dall\'indirizzo IP.'));
    }
    if ($action === 'passkey_login_options') {
        out(array('ok' => true, 'options' => pk_login_options()));
    }
    $ip = client_ip();
    $resp = json_decode((string)post('credential'), true);
    try {
        if (!is_array($resp)) {
            throw new Exception('Risposta del browser non valida.');
        }
        $u = pk_login_finish($resp);
    } catch (Exception $e) {
        record_attempt($ip, '', false);
        if (function_exists('fw_after_failed_login')) {
            fw_after_failed_login($ip, '', true);
        }
        app_log('passkey_fallita', 'Accesso con chiave non riuscito: ' . $e->getMessage(), 'warn', '');
        out(array('ok' => false, 'error' => $e->getMessage()));
    }
    unset($_SESSION['pending_uid'], $_SESSION['pending_time']);
    finish_login($u, false, 'con la chiave di accesso');
    if (post('remember') === '1') {
        require_once APP_ROOT . '/inc/remember.php';
        remember_create((int)$u['id']);
    }
    app_log('login_chiave', 'Accesso con la chiave di accesso "' . $u['_passkey_name'] . '"', 'info', $u['username']);
    out(array('ok' => true, 'redirect' => 'libreria.php'));
}

need(is_logged(), 'Sessione scaduta: accedi di nuovo.');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
}
$uid = current_uid();

switch ($action) {

    /* ---------- Media: elenco e caricamento per la finestra "Inserisci da Media" ---------- */
    /* ---------- Funzioni dei plugin: api.php?action=plg&p=<id>&f=<nome> ---------- */
    case 'plg':
        if (!function_exists('plugins_api_call')) {
            out(array('ok' => false, 'error' => 'Plugin non disponibili.'));
        }
        out(plugins_api_call((string)get('p'), (string)get('f')));
        break;

    case 'media_list':
        need(can_edit());
        session_write_close();
        require_once APP_ROOT . '/inc/media.php';
        need(media_ready(), 'Il database non è ancora aggiornato.');
        $items = array();
        require_once APP_ROOT . '/inc/icons.php';
        $kico = array('image' => 'image', 'pdf' => 'pdf', 'video' => 'film', 'audio' => 'music');
        foreach (media_list((string)get('folder', 'all'), str_cut(trim(get('q')), 80), (string)get('kind'), 300) as $m) {
            $it = media_public($m);
            $it['html'] = media_embed_code($m, 'html');
            $it['md'] = media_embed_code($m, 'md');
            $it['ico'] = icon($kico[$m['kind']], 34);
            $items[] = $it;
        }
        $fl = array();
        foreach (media_folders() as $f) {
            $fl[] = array('id' => (int)$f['id'], 'name' => $f['name'], 'n' => (int)$f['n']);
        }
        out(array('ok' => true, 'items' => $items, 'folders' => $fl));
        break;

    case 'media_upload':
        need(can_edit());
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        require_once APP_ROOT . '/inc/media.php';
        need(media_ready(), 'Il database non è ancora aggiornato.');
        $r = isset($_FILES['file']) ? media_store($_FILES['file'], (int)post('folder_id')) : array(false, 'Nessun file ricevuto.');
        if (!$r[0]) {
            out(array('ok' => false, 'error' => $r[1]));
        }
        $m = media_get($r[1]);
        app_log('media_caricati', '1 file caricato in Media dall\'editor delle pagine');
        $it = media_public($m);
        $it['html'] = media_embed_code($m, 'html');
        $it['md'] = media_embed_code($m, 'md');
        out(array('ok' => true, 'item' => $it));
        break;

    /* ---------- Avvisi (campanella, 1.9.14) ---------- */
    case 'notif_count':
        need(is_user());
        require_once APP_ROOT . '/inc/notifiche.php';
        session_write_close();
        out(array('ok' => true, 'n' => notif_non_lette(current_uid())));
        break;

    case 'notif_list':
        need(is_user());
        require_once APP_ROOT . '/inc/notifiche.php';
        $items = array();
        foreach (notif_elenco(current_uid(), 30) as $r) {
            $items[] = array('id' => (int)$r['id'], 'kind' => $r['kind'], 'text' => $r['text'], 'link' => notif_link_ok($r['link']) ? $r['link'] : '',
                'new' => $r['read_at'] === null, 'when' => notif_quando($r['updated_at']),
                'cover' => !empty($r['cover_file']) ? cover_url($r['cover_file']) : '', 'book' => $r['book_id'] ? (int)$r['book_id'] : 0);
        }
        out(array('ok' => true, 'items' => $items));
        break;

    /* ---------- Notifiche sul telefono (1.9.16) ---------- */
    case 'push_iscrivi':
    case 'push_togli':
    case 'push_prova':
        need(is_user() && $_SERVER['REQUEST_METHOD'] === 'POST');
        require_once APP_ROOT . '/inc/push.php';
        need(push_attivo(), 'Le notifiche sul telefono sono spente per questo sito.');
        if ($action === 'push_iscrivi') {
            try {
                $nuovo = push_iscrivi($uid, (string)post('endpoint'), (string)post('p256dh'), (string)post('auth'), isset($_SERVER['HTTP_USER_AGENT']) ? (string)$_SERVER['HTTP_USER_AGENT'] : '');
            } catch (Exception $e) {
                out(array('ok' => false, 'error' => $e->getMessage()));
            }
            if ($nuovo) {
                app_log('notifiche_dispositivo', 'Notifiche attivate su ' . push_nome_dispositivo(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''), 'info');
            }
            out(array('ok' => true, 'nuovo' => $nuovo));
        }
        if ($action === 'push_togli') {
            push_togli($uid, (string)post('endpoint'));
            out(array('ok' => true));
        }
        session_write_close();
        $esiti = array();
        foreach (push_prova($uid) as $e) {
            $esiti[] = array('nome' => $e[0], 'ok' => $e[1], 'errore' => $e[2]);
        }
        out($esiti ? array('ok' => true, 'esiti' => $esiti) : array('ok' => false, 'error' => 'Nessun dispositivo con le notifiche attive.'));
        break;

    case 'notif_read':
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        need(is_user());
        require_once APP_ROOT . '/inc/notifiche.php';
        notif_segna_lette(current_uid());
        out(array('ok' => true));
        break;

    /* ---------- Stato di lettura dalla Libreria (dito premuto sulla copertina, 1.9.13) ---------- */
    case 'book_status':
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        need(is_user());
        $bid = (int)post('id');
        $stato = (string)post('status');
        $tutti = reading_statuses();
        need($stato === '' || isset($tutti[$stato]), 'Stato non valido.');
        need($bid > 0 && book_get($bid), 'Libro non trovato.');
        require_once APP_ROOT . '/inc/reading.php';
        $uid = current_uid();
        $prima = (string)user_book_row($uid, $bid)['status'];
        user_book_save($uid, $bid, $stato, null);
        $msg = $stato === '' ? 'Etichetta tolta.' : 'Segnato come «' . $tutti[$stato] . '».';
        if (reading_ready()) {
            if ($stato === 'letto' && $prima !== 'letto' && function_exists('lib_do')) {
                $st = db()->prepare("SELECT id FROM reading_sessions WHERE user_id = ? AND book_id = ? AND status = 'letto' ORDER BY id DESC LIMIT 1");
                $st->execute(array($uid, $bid));
                $sid = (int)$st->fetchColumn();
                if ($sid) {
                    lib_do('lettura_terminata', $uid, $sid, $bid);
                }
            }
            $msg .= reading_trophies_flash($uid);
        }
        // eventuali messaggi dei plugin (es. una sfida completata) si mostrano qui invece che alla pagina dopo
        $extra = array();
        if (!empty($_SESSION['flash_more'])) {
            foreach ((array)$_SESSION['flash_more'] as $f) {
                $extra[] = is_array($f) ? (string)(isset($f['text']) ? $f['text'] : '') : (string)$f;
            }
            unset($_SESSION['flash_more']);
        }
        $now = (string)user_book_row($uid, $bid)['status'];
        out(array('ok' => true, 'status' => $now, 'label' => $now !== '' ? status_label($now) : '', 'message' => trim($msg . ' ' . implode(' ', $extra))));
        break;

    /* ---------- Ricerca nella libreria mentre si scrive (finestra "Cerca") ---------- */
    case 'search':
        session_write_close();
        require_once APP_ROOT . '/inc/search.php';
        $q = str_cut(trim(get('q')), 100);
        if (str_len($q) < 1) {
            out(array('ok' => true, 'total' => 0, 'html' => ''));
        }
        $res = book_search($q);
        $ids = array_slice($res['ids'], 0, 20);
        $html = '';
        if ($ids) {
            list($in, $ord) = search_sql_in($ids);
            $rows = db()->query('SELECT b.id, b.title, b.authors, b.pub_year, b.cover_file FROM books b WHERE ' . $in . ' ORDER BY ' . $ord)->fetchAll();
            foreach ($rows as $b) {
                $html .= '<a class="sov-item" href="libro.php?id=' . (int)$b['id'] . '">' . book_cover_html($b, 'cover mini')
                    . '<span><b>' . h($b['title']) . '</b><small>' . h($b['authors']) . ($b['pub_year'] ? ' · ' . (int)$b['pub_year'] : '') . '</small></span></a>';
            }
        }
        out(array('ok' => true, 'total' => count($res['ids']), 'exact' => $res['exact'], 'html' => $html));
        break;

    /* ---------- Ricerca online (Admin e Gestore) ---------- */
    case 'lookup_isbn':
        need(can_edit());
        session_write_close();
        $r = lookup_isbn(get('isbn'));
        $isbn = isbn_to13(get('isbn'));
        $r['duplicates'] = books_with_isbn($isbn);
        out($r);
        break;

    case 'lookup_title':
        need(can_edit());
        session_write_close();
        $r = lookup_title(get('q'));
        if (!empty($r['results'])) {
            foreach ($r['results'] as $i => $b) {
                $r['results'][$i]['duplicates'] = books_with_isbn($b['isbn13']);
            }
        }
        out($r);
        break;

    case 'cover_preview':
        need(can_edit());
        session_write_close();
        $u = get('u');
        $res = http_get($u, setting_int('lookup_timeout', 3, 30), 6291456, 'trusted');
        $info = $res['code'] === 200 ? @getimagesizefromstring($res['body']) : false;
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (!$info || $info[0] < 40) {
            header('HTTP/1.1 404 Not Found');
            exit;
        }
        header('Content-Type: ' . $info['mime']);
        header('Cache-Control: private, max-age=86400');
        header('X-Image-Size: ' . $info[0] . 'x' . $info[1]);
        echo $res['body'];
        exit;

    /* ---------- Chiavi di accesso: creazione (ogni utente registrato per se') ---------- */
    case 'passkey_reg_options':
    case 'passkey_reg_finish':
        require_once APP_ROOT . '/inc/webauthn.php';
        need(is_user());
        need(pk_enabled(), 'Le chiavi di accesso non sono attive su questo sito.');
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        if (!pk_available_here()) {
            out(array('ok' => false, 'error' => 'Apri il sito dal suo indirizzo https:// (non dall\'indirizzo IP) per creare una chiave di accesso.'));
        }
        $me = current_user();
        // da un dispositivo ricordato una chiave nuova si crea solo confermando la password
        if (is_file(APP_ROOT . '/inc/remember.php')) {
            require_once APP_ROOT . '/inc/remember.php';
            if ($action === 'passkey_reg_options' && remember_needs_reauth()) {
                $stp = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
                $stp->execute(array((int)$me['id']));
                if (!password_verify(isset($_POST['pw']) ? (string)$_POST['pw'] : '', (string)$stp->fetchColumn())) {
                    app_log('password_errata', 'Creazione chiave di accesso: password non confermata (dispositivo ricordato)', 'warn');
                    out(array('ok' => false, 'error' => 'Scrivi la tua password per creare una chiave da questo dispositivo.'));
                }
                $_SESSION['pw_ok_at'] = time();
            }
        }
        if ($action === 'passkey_reg_options') {
            out(array('ok' => true, 'options' => pk_register_options($me)));
        }
        try {
            $resp = json_decode((string)post('credential'), true);
            if (!is_array($resp)) {
                throw new Exception('Risposta del browser non valida.');
            }
            $pid = pk_register_finish($me, $resp, post('name'));
        } catch (Exception $e) {
            out(array('ok' => false, 'error' => 'Chiave non creata: ' . $e->getMessage()));
        }
        $st = db()->prepare('SELECT name FROM user_passkeys WHERE id = ?');
        $st->execute(array($pid));
        $pname = (string)$st->fetchColumn();
        app_log('passkey_creata', 'Nuova chiave di accesso "' . $pname . '"', 'warn');
        flash('Chiave di accesso "' . $pname . '" creata. Da ora puoi entrare con "Accedi con una chiave di accesso".');
        out(array('ok' => true));
        break;

    case 'book_refill':
        // un libro alla volta: la pagina "Tutti i libri" li manda in fila, cosi' nessuna richiesta dura troppo
        need(can_edit());
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        session_write_close();
        require_once APP_ROOT . '/inc/refill.php';
        @set_time_limit(120);
        $id = (int)post('id');
        $b = book_get($id);
        if (!$b) {
            out(array('ok' => false, 'error' => 'Libro non trovato.'));
        }
        $what = in_array(post('what'), array('cover', 'desc'), true) ? post('what') : 'all';
        $r = book_refill($id, $what);
        $nb = book_get($id);
        out(array('ok' => true, 'id' => $id, 'title' => $b['title'], 'changed' => $r['changed'], 'msg' => $r['msg'],
            'cover' => $nb && $nb['cover_file'] ? cover_url($nb['cover_file']) : ''));
        break;

    case 'fill_covers':
        need(can_edit());
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        session_write_close();
        $rows = db()->query("SELECT id, isbn13 FROM books WHERE (cover_file IS NULL OR cover_file = '') AND isbn13 IS NOT NULL AND isbn13 <> '' "
            . "AND (source IS NULL OR source <> 'senza-copertina') ORDER BY id LIMIT 3")->fetchAll();
        $done = 0;
        foreach ($rows as $r) {
            $l = lookup_isbn($r['isbn13']);
            $urls = isset($l['book']['covers']) ? $l['book']['covers'] : (isset($l['covers']) ? $l['covers'] : array());
            $ok = $urls ? cover_store_from_urls(array_slice($urls, 0, 4), $r['id'], 'trusted') : array(false, '');
            if ($ok[0]) {
                $done++;
            } else {
                // segna il libro per non riprovarlo all'infinito
                db()->prepare("UPDATE books SET source = 'senza-copertina' WHERE id = ?")->execute(array($r['id']));
            }
        }
        $left = (int)db()->query("SELECT COUNT(*) FROM books WHERE (cover_file IS NULL OR cover_file = '') AND isbn13 IS NOT NULL AND isbn13 <> '' "
            . "AND (source IS NULL OR source <> 'senza-copertina')")->fetchColumn();
        if ($done > 0) {
            app_log('copertine_completate', $done . ' copertine scaricate automaticamente');
        }
        out(array('ok' => true, 'done' => $done, 'checked' => count($rows), 'left' => $left));
        break;

    /* ---------- Ruota di lettura (personale) ---------- */
    case 'wheel_state':
        need(is_user());
        $ws = wheel_settings_get($uid);
        $pool = wheel_pool($uid, $ws);
        out(array('ok' => true, 'settings' => $ws, 'total' => count($pool), 'items' => wheel_display($pool)));
        break;

    case 'wheel_settings':
        need(is_user());
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        $ws = wheel_settings_save($uid, post('source'), post('category_id'), post('max_pages'));
        $pool = wheel_pool($uid, $ws);
        out(array('ok' => true, 'settings' => $ws, 'total' => count($pool), 'items' => wheel_display($pool)));
        break;

    case 'wheel_spin':
        need(is_user());
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        out(wheel_spin($uid));
        break;

    case 'wheel_outcome':
        need(is_user());
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        $r = wheel_outcome($uid, (int)post('spin_id'), post('outcome'));
        if ($r['ok']) {
            $ws = wheel_settings_get($uid);
            $pool = wheel_pool($uid, $ws);
            $r['total'] = count($pool);
            $r['items'] = wheel_display($pool);
        }
        out($r);
        break;

    case 'wheel_books':
        need(is_user());
        $rows = db()->prepare('SELECT b.id, b.title, b.authors, b.category_id, b.pages, ub.status AS my_status FROM books b '
            . 'LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = ? ORDER BY b.title');
        $rows->execute(array($uid));
        $list = array();
        foreach ($rows->fetchAll() as $b) {
            $list[] = array('id' => (int)$b['id'], 't' => $b['title'], 'a' => (string)$b['authors'], 'c' => (int)$b['category_id'],
                's' => (string)$b['my_status']);
        }
        out(array('ok' => true, 'books' => $list, 'selected' => wheel_item_ids($uid)));
        break;

    case 'wheel_items':
        need(is_user());
        need($_SERVER['REQUEST_METHOD'] === 'POST');
        $ids = isset($_POST['ids']) ? explode(',', (string)$_POST['ids']) : array();
        $n = wheel_items_save($uid, $ids);
        $ws = wheel_settings_save($uid, 'manual', wheel_settings_get($uid)['category_id'], wheel_settings_get($uid)['max_pages']);
        $pool = wheel_pool($uid, $ws);
        out(array('ok' => true, 'count' => $n, 'settings' => $ws, 'total' => count($pool), 'items' => wheel_display($pool)));
        break;

    default:
        out(array('ok' => false, 'error' => 'Azione sconosciuta.'), 400);
}
