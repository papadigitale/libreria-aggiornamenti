<?php
/*
 * "Sto leggendo" in cima alla Libreria (1.9.21): i libri in lettura con la barra di avanzamento
 * e la casella per scrivere a che pagina sei arrivato, senza aprire la scheda del libro.
 * Il salvataggio passa da api.php?action=progresso (js/sto_leggendo.js); senza JavaScript il modulo va alla scheda del libro.
 */
function sto_leggendo_html($uid)
{
    if (!function_exists('reading_ready') || !reading_ready() || setting('home_reading', '1') !== '1') {
        return '';
    }
    $libri = reading_current($uid, 4);
    if (!$libri) {
        return '';
    }
    // una riga sottile per libro; la freccia apre la casella della pagina (<details>: funziona anche senza JavaScript)
    $h = '<section class="sto-leggendo" aria-label="Sto leggendo">';
    foreach ($libri as $b) {
        $tot = (int)$b['pages'];
        $p = $b['_punto'];
        $perc = $p && $p['percent'] !== null ? max(0, min(100, (float)$p['percent'])) : 0;
        $pag = $p && $p['page'] !== null ? (int)$p['page'] : '';
        $id = (int)$b['id'];
        $breve = $p && $p['percent'] !== null ? rtrim(rtrim(number_format($perc, 1, ',', ''), '0'), ',') . '%' : '—';
        $h .= '<details class="slr" data-slr="' . $id . '"><summary>'
            . '<span class="slr-cop" aria-hidden="true">' . book_cover_html($b) . '</span>'
            . '<span class="slr-info"><span class="slr-lab">Sto leggendo</span><span class="slr-t">' . h($b['title']) . '</span>'
            . '<span class="progress slr-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int)round($perc) . '" aria-label="Avanzamento"><i style="width:' . round($perc, 1) . '%"></i></span></span>'
            . '<span class="slr-perc" data-slr-perc>' . h($breve) . '</span>'
            . '<span class="slr-freccia" aria-hidden="true">' . icon('chev', 16) . '</span><span class="sr-only">Aggiorna la pagina di ' . h($b['title']) . '</span></summary>'
            . '<div class="slr-corpo"><span class="slr-txt" data-slr-txt>' . h(reading_point_text($p, $tot)) . '</span>'
            . '<form class="slr-form" method="post" action="libro.php?id=' . $id . '" data-slr-form>' . csrf_field()
            . '<input type="hidden" name="action" value="progresso"><input type="hidden" name="mode" value="' . ($tot > 0 ? 'page' : 'percent') . '">'
            . '<input class="input" type="number" name="value" inputmode="numeric" min="0"' . ($tot > 0 ? ' max="' . $tot . '"' : ' max="100" step="0.1"')
            . ' value="' . h((string)$pag) . '" placeholder="' . ($tot > 0 ? 'Pagina' : '%') . '" aria-label="' . ($tot > 0 ? 'Pagina a cui sei arrivato' : 'Percentuale letta') . ' di ' . h($b['title']) . '">'
            . '<button class="btn primary small" type="submit">Salva</button>'
            . '<a class="slr-apri" href="libro.php?id=' . $id . '#lettura">Scheda</a></form>'
            . '<div class="slr-msg" data-slr-msg aria-live="polite"></div>'
            . '<form class="slr-fine" method="post" action="libro.php?id=' . $id . '" data-slr-fine' . ($perc >= 100 ? '' : ' hidden') . '>' . csrf_field()
            . '<input type="hidden" name="action" value="terminata"><button class="btn ghost small" type="submit">' . icon('check', 15) . ' L\'ho finito</button></form>'
            . '</div></details>';
    }
    return $h . '</section>';
}
