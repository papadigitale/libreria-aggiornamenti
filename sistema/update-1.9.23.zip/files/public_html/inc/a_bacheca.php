<?php
$pdo = db();
$tot = $pdo->query("SELECT COUNT(*) AS n, SUM(CASE WHEN cover_file IS NOT NULL AND cover_file <> '' THEN 1 ELSE 0 END) AS cov, "
    . "SUM(COALESCE(pages,0)) AS pg, COUNT(DISTINCT authors) AS au, COUNT(DISTINCT publisher) AS ed FROM books")->fetch();
$n = (int)$tot['n'];
$nocover = (int)$pdo->query("SELECT COUNT(*) FROM books WHERE cover_file IS NULL OR cover_file = ''")->fetchColumn();
$nocat = (int)$pdo->query('SELECT COUNT(*) FROM books WHERE category_id IS NULL')->fetchColumn();
$noisbn = (int)$pdo->query("SELECT COUNT(*) FROM books WHERE isbn13 IS NULL OR isbn13 = ''")->fetchColumn();
$nodesc = (int)$pdo->query("SELECT COUNT(*) FROM books WHERE description IS NULL OR description = ''")->fetchColumn();
$overdue = loans_overdue_count();
$lent = count(loans_open_map());
$dup_groups = count(dup_groups());
$in_trash = trash_count();
$dups = (int)$pdo->query("SELECT COUNT(*) FROM (SELECT isbn13 FROM books WHERE isbn13 IS NOT NULL AND isbn13 <> '' GROUP BY isbn13 HAVING COUNT(*) > 1) d")->fetchColumn();

// libri aggiunti negli ultimi 12 mesi
$months = array();
for ($i = 11; $i >= 0; $i--) {
    $months[date('Y-m', strtotime(date('Y-m-01') . " -$i months"))] = 0;
}
$st = $pdo->prepare('SELECT created_at FROM books WHERE created_at >= ?');
$st->execute(array(key($months) . '-01 00:00:00'));
foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $c) {
    $k = substr($c, 0, 7);
    if (isset($months[$k])) {
        $months[$k]++;
    }
}
$maxm = max(1, max($months));
$mesi = array('gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic');

$byCat = $pdo->query('SELECT COALESCE(c.name, \'Senza genere\') AS name, COUNT(b.id) AS n FROM books b LEFT JOIN categories c ON c.id = b.category_id '
    . 'GROUP BY c.name ORDER BY n DESC')->fetchAll();
$maxCat = 1;
foreach ($byCat as $c) {
    $maxCat = max($maxCat, (int)$c['n']);
}
$readers = $pdo->query("SELECT u.display_name, u.username, u.last_login_at, SUM(CASE WHEN ub.status = 'letto' THEN 1 ELSE 0 END) AS letti, "
    . "SUM(CASE WHEN ub.status = 'in_lettura' THEN 1 ELSE 0 END) AS inlett, SUM(CASE WHEN ub.status = 'da_leggere' THEN 1 ELSE 0 END) AS dalegg "
    . "FROM users u LEFT JOIN user_books ub ON ub.user_id = u.id WHERE u.active = 1 GROUP BY u.id, u.display_name, u.username, u.last_login_at ORDER BY letti DESC")->fetchAll();
$recent = $pdo->query('SELECT b.id, b.title, b.authors, b.cover_file, b.created_at FROM books b ORDER BY b.created_at DESC, b.id DESC LIMIT 8')->fetchAll();

require_once APP_ROOT . '/inc/data_tools.php';
$bk = backup_ultimo();

$alerts = array();
if (is_admin()) {
    if ((int)$pdo->query("SELECT COUNT(*) FROM users WHERE username = 'admin' AND must_change_pw = 1")->fetchColumn()) {
        $alerts[] = array('error', 'La password iniziale di "admin" non è ancora stata cambiata.', 'utenti');
    }
    if (!is_https()) {
        $alerts[] = array('warn', 'Il sito non usa HTTPS: le password viaggiano in chiaro sulla rete e dal telefono la fotocamera non si accende.', 'sicurezza');
    }
    require_once APP_ROOT . '/inc/security_check.php';
    $phps = php_support_status();
    if ($phps[0] !== 'ok') {
        $alerts[] = array($phps[0] === 'bad' ? 'error' : 'warn', $phps[1], 'controllo');
    }
    if (APP_DEBUG) {
        $alerts[] = array('warn', 'La modalità debug è attiva.', 'sistema');
    }
    if (setting('sec_ip_allow') === '') {
        $alerts[] = array('warn', 'Nessun elenco di IP ammessi: chiunque raggiunga il server può aprire la pagina di accesso.', 'sicurezza');
    }
    $nofa = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1 AND totp_enabled = 0")->fetchColumn();
    if ($nofa) {
        $alerts[] = array('warn', $nofa . ' amministratori senza verifica in due passaggi.', 'sicurezza');
    }
}
if ($overdue) {
    $alerts[] = array('error', $overdue === 1 ? 'Un libro prestato doveva già essere restituito.' : $overdue . ' libri prestati dovevano già essere restituiti.', 'prestiti');
}
if (!$bk['time'] || $bk['time'] < time() - 30 * 86400) {
    $chi = $bk['nome'] !== '' ? ' con ' . $bk['nome'] : '';
    $alerts[] = array('warn', $bk['time'] ? 'L\'ultimo backup' . $chi . ' ha più di 30 giorni (' . date('d/m/Y', $bk['time']) . ').' : 'Non hai ancora creato un backup' . $chi . '.', $bk['sez']);
}
$logs = is_admin() ? $pdo->query('SELECT created_at, level, action, username, detail FROM logs ORDER BY id DESC LIMIT 8')->fetchAll() : array();
?>
<div class="kpis">
  <a class="kpi" href="gestione.php?sez=libri"><b><?= number_format($n, 0, ',', '.') ?></b><span>libri</span></a>
  <div class="kpi"><b><?= number_format((int)$tot['au'], 0, ',', '.') ?></b><span>autori</span></div>
  <div class="kpi"><b><?= number_format((int)$tot['ed'], 0, ',', '.') ?></b><span>editori</span></div>
  <div class="kpi"><b><?= number_format((int)$tot['pg'], 0, ',', '.') ?></b><span>pagine in tutto</span></div>
  <div class="kpi"><b><?= $n ? round((int)$tot['cov'] / $n * 100) : 0 ?>%</b><span>con copertina</span></div>
</div>

<?php if ($alerts): ?>
<div class="card">
  <div class="ct"><?= admin_icon('warn', 18) ?> Da tenere d'occhio</div>
  <?php foreach ($alerts as $al): ?>
  <div class="todo <?= h($al[0]) ?>"><span><?= h($al[1]) ?></span><a class="link" href="gestione.php?sez=<?= h($al[2]) ?>">Apri</a></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="adm-grid2">
  <div class="card">
    <div class="ct">Libri aggiunti negli ultimi 12 mesi</div>
    <div class="vbars" role="img" aria-label="Libri aggiunti per mese">
      <?php foreach ($months as $k => $v): ?>
      <div class="vb" title="<?= h($mesi[(int)substr($k, 5) - 1] . ' ' . substr($k, 0, 4)) ?>: <?= (int)$v ?>">
        <b><?= $v ? (int)$v : '' ?></b><i style="height:<?= $v ? max(4, round($v / $maxm * 100)) : 1 ?>%"></i><span><?= h($mesi[(int)substr($k, 5) - 1]) ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="card">
    <div class="ct">Da sistemare</div>
    <a class="fixrow" href="gestione.php?sez=libri&amp;filtro=senzacopertina"><span>Senza copertina</span><b><?= $nocover ?></b></a>
    <a class="fixrow" href="gestione.php?sez=libri&amp;filtro=senzagenere"><span>Senza genere</span><b><?= $nocat ?></b></a>
    <a class="fixrow" href="gestione.php?sez=libri&amp;filtro=senzaisbn"><span>Senza ISBN</span><b><?= $noisbn ?></b></a>
    <a class="fixrow" href="gestione.php?sez=libri&amp;filtro=senzatrama"><span>Senza trama</span><b><?= $nodesc ?></b></a>
    <a class="fixrow" href="gestione.php?sez=doppioni"><span>Possibili doppioni</span><b><?= $dup_groups ?></b></a>
    <a class="fixrow" href="gestione.php?sez=prestiti"><span>In prestito<?= $overdue ? ' (' . $overdue . ' scaduti)' : '' ?></span><b><?= $lent ?></b></a>
    <a class="fixrow" href="gestione.php?sez=cestino"><span>Nel cestino</span><b><?= $in_trash ?></b></a>
  </div>
</div>

<div class="adm-grid2">
  <div class="card">
    <div class="ct">Libri per genere</div>
    <?php if (!$byCat): ?><p class="sub">Nessun libro ancora.</p><?php endif; ?>
    <?php foreach ($byCat as $c): ?>
    <div class="bar"><span><?= h($c['name']) ?></span><i style="width:<?= max(4, round((int)$c['n'] / $maxCat * 100)) ?>%"></i><b><?= (int)$c['n'] ?></b></div>
    <?php endforeach; ?>
  </div>
  <div class="card">
    <div class="ct">Lettori</div>
    <table class="tbl compact">
      <thead><tr><th>Utente</th><th class="num">Letti</th><th class="num">In lettura</th><th class="num">Da leggere</th><th>Ultimo accesso</th></tr></thead>
      <tbody>
      <?php foreach ($readers as $r): ?>
        <tr><td><?= h($r['display_name'] !== '' ? $r['display_name'] : $r['username']) ?></td><td class="num"><?= (int)$r['letti'] ?></td>
          <td class="num"><?= (int)$r['inlett'] ?></td><td class="num"><?= (int)$r['dalegg'] ?></td><td class="muted"><?= h(fmt_dt($r['last_login_at'])) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="adm-grid2">
  <div class="card">
    <div class="ct">Ultimi inserimenti</div>
    <?php foreach ($recent as $r): ?>
    <a class="mini-book" href="gestione.php?sez=libro&amp;id=<?= (int)$r['id'] ?>"><?= book_cover_html($r, 'cover xs') ?>
      <span><b><?= h($r['title']) ?></b><small><?= h($r['authors']) ?></small></span><em><?= h(date('d/m/Y', strtotime($r['created_at']))) ?></em></a>
    <?php endforeach; ?>
    <?php if (!$recent): ?><p class="sub">Nessun libro ancora: <a class="link" href="aggiungi.php">aggiungi il primo</a>.</p><?php endif; ?>
  </div>
  <div class="card">
    <div class="ct">Backup</div>
    <?php if ($bk['nome'] !== ''): ?>
    <p class="sub"><?= $bk['time'] ? 'Ultimo backup: <b>' . h(date('d/m/Y H:i', $bk['time'])) . '</b> · con ' . h($bk['nome']) : 'Nessun backup ancora con ' . h($bk['nome']) . '.' ?></p>
    <a class="btn primary small" href="gestione.php?sez=<?= h($bk['sez']) ?>">Apri <?= h($bk['nome']) ?></a>
    <?php else: ?>
    <p class="sub"><?= $bk['time'] ? 'Ultimo backup: <b>' . h(date('d/m/Y H:i', $bk['time'])) . '</b> · ' . count(array_filter(backup_list(), function ($b) { return strpos($b['name'], 'prima') === false; })) . ' salvati sul server' : 'Nessun backup ancora.' ?></p>
    <form method="post" action="gestione.php?sez=dati"><?= csrf_field() ?><input type="hidden" name="action" value="backup_create">
      <button class="btn primary small" type="submit">Crea un backup adesso</button></form>
    <?php endif; ?>
    <?php if (is_admin()): ?>
    <div class="ct sep">Attività recente</div>
    <?php foreach ($logs as $l): ?>
    <div class="logline lv-<?= h($l['level']) ?>"><span><?= h(date('d/m H:i', strtotime($l['created_at']))) ?></span><b><?= h($l['username']) ?></b>
      <em><?= h(str_replace('_', ' ', $l['action'])) ?></em><small><?= h(str_cut((string)$l['detail'], 90)) ?></small></div>
    <?php endforeach; ?>
    <a class="link" href="gestione.php?sez=log">Tutti i log</a>
    <?php endif; ?>
  </div>
</div>
<?php if (function_exists('lib_filter')) { echo (string)lib_filter('bacheca', ''); } ?>
