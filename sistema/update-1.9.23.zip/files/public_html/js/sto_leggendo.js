/* "Sto leggendo" in cima alla Libreria (1.9.21): salva la pagina senza lasciare la pagina */
(function () {
  'use strict';
  var box = document.querySelector('.sto-leggendo');
  if (!box || !window.fetch) { return; }
  var csrf = (window.App && window.App.csrf) || '';
  // aprendo una riga, il cursore va nella casella della pagina
  Array.prototype.forEach.call(box.querySelectorAll('details.slr'), function (d) {
    d.addEventListener('toggle', function () { if (d.open) { var i = d.querySelector('[name=value]'); if (i) { setTimeout(function () { i.focus(); i.select(); }, 60); } } });
  });
  Array.prototype.forEach.call(box.querySelectorAll('[data-slr-form]'), function (f) {
    var riga = f.closest('[data-slr]'), msg = riga.querySelector('[data-slr-msg]'), bar = riga.querySelector('.slr-bar i'), pb = riga.querySelector('.slr-bar');
    var txt = riga.querySelector('[data-slr-txt]'), perc = riga.querySelector('[data-slr-perc]'), fine = riga.querySelector('[data-slr-fine]'), btn = f.querySelector('button');
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = f.querySelector('[name=value]').value.trim();
      if (v === '') { f.querySelector('[name=value]').focus(); return; }
      var fd = new FormData();
      fd.append('csrf', csrf); fd.append('action', 'progresso'); fd.append('book', riga.getAttribute('data-slr'));
      fd.append('value', v); fd.append('mode', f.querySelector('[name=mode]').value);
      btn.disabled = true;
      fetch('api.php', { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
        btn.disabled = false;
        msg.className = 'slr-msg ' + (j.ok ? 'ok' : 'err');
        msg.textContent = j.ok ? j.messaggio : (j.error || 'Non salvato.');
        if (!j.ok) { return; }
        if (j.percent !== null && bar) { bar.style.width = Math.min(100, j.percent) + '%'; pb.setAttribute('aria-valuenow', Math.round(j.percent)); }
        if (txt) { txt.textContent = j.testo; }
        if (perc && j.percent !== null) { perc.textContent = String(Math.round(j.percent * 10) / 10).replace('.', ',') + '%'; }
        if (fine) { fine.hidden = !j.finito; }
        setTimeout(function () { if (msg.className.indexOf('ok') >= 0) { msg.textContent = ''; } }, 6000);
      }).catch(function () { btn.disabled = false; msg.className = 'slr-msg err'; msg.textContent = 'Connessione non riuscita: riprova.'; });
    });
  });
})();
