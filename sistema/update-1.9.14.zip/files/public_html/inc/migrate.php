<?php
/*
 * Aggiornamento automatico della struttura del database.
 * Ogni versione aggiunge solo tabelle/colonne nuove: i dati esistenti non vengono toccati,
 * e un ritorno alla versione precedente dei programmi resta possibile.
 * La versione attuale e' salvata in settings.db_version (assente = 1).
 */

// Converte un'istruzione scritta per MySQL nella forma accettata da SQLite (solo modalita' di prova)
function sql_for_driver($st, $driver = null)
{
    $driver = $driver === null ? DB_DRIVER : $driver;
    if ($driver !== 'sqlite') {
        return $st;
    }
    if (stripos($st, 'SET ') === 0) {
        return '';
    }
    $st = preg_replace('/\)\s*ENGINE=[^;]*$/s', ')', $st);
    $lines = array();
    foreach (explode("\n", $st) as $l) {
        if (preg_match('/^\s*KEY /', $l) || preg_match('/^\s*PRIMARY KEY \(id\)/', $l)) {
            continue;
        }
        $lines[] = $l;
    }
    $st = implode("\n", $lines);
    $st = preg_replace('/(\w+)\s+INT UNSIGNED NOT NULL AUTO_INCREMENT/', '$1 INTEGER PRIMARY KEY AUTOINCREMENT', $st);
    $st = preg_replace('/UNIQUE KEY \w+ /', 'UNIQUE ', $st);
    $st = preg_replace('/CONSTRAINT \w+ /', '', $st);
    $st = preg_replace('/,\s*\n\)/', "\n)", $st);
    return str_replace(array('NOW()', 'TINYINT(1)', 'UNSIGNED', 'MEDIUMTEXT'), array("datetime('now')", 'INTEGER', '', 'TEXT'), $st);
}

function db_migrations()
{
    $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    return array(
        // 1.1.0: etichette personalizzate, campi personalizzati, sezioni della home, pagine, disconnessione forzata
        2 => array(
            "CREATE TABLE IF NOT EXISTS taxonomies (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(80)  NOT NULL,
  multiple    TINYINT(1)   NOT NULL DEFAULT 1,
  in_filters  TINYINT(1)   NOT NULL DEFAULT 1,
  on_card     TINYINT(1)   NOT NULL DEFAULT 1,
  sort_order  INT          NOT NULL DEFAULT 0,
  created_at  DATETIME     NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_taxonomies_name (name)
)" . $tail,
            "CREATE TABLE IF NOT EXISTS terms (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  taxonomy_id  INT UNSIGNED NOT NULL,
  name         VARCHAR(100) NOT NULL,
  sort_order   INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_terms_name (taxonomy_id, name),
  CONSTRAINT fk_terms_tax FOREIGN KEY (taxonomy_id) REFERENCES taxonomies (id) ON DELETE CASCADE
)" . $tail,
            "CREATE TABLE IF NOT EXISTS book_terms (
  book_id  INT UNSIGNED NOT NULL,
  term_id  INT UNSIGNED NOT NULL,
  PRIMARY KEY (book_id, term_id),
  KEY idx_book_terms_term (term_id),
  CONSTRAINT fk_bt_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE,
  CONSTRAINT fk_bt_term FOREIGN KEY (term_id) REFERENCES terms (id) ON DELETE CASCADE
)" . $tail,
            "CREATE TABLE IF NOT EXISTS custom_fields (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(80)  NOT NULL,
  type        VARCHAR(10)  NOT NULL DEFAULT 'text',
  options     TEXT         NULL,
  on_card     TINYINT(1)   NOT NULL DEFAULT 1,
  in_csv      TINYINT(1)   NOT NULL DEFAULT 1,
  sort_order  INT          NOT NULL DEFAULT 0,
  created_at  DATETIME     NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_custom_fields_name (name)
)" . $tail,
            "CREATE TABLE IF NOT EXISTS book_field_values (
  book_id   INT UNSIGNED NOT NULL,
  field_id  INT UNSIGNED NOT NULL,
  value     TEXT         NULL,
  PRIMARY KEY (book_id, field_id),
  KEY idx_bfv_field (field_id),
  CONSTRAINT fk_bfv_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE,
  CONSTRAINT fk_bfv_field FOREIGN KEY (field_id) REFERENCES custom_fields (id) ON DELETE CASCADE
)" . $tail,
            "CREATE TABLE IF NOT EXISTS home_sections (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title       VARCHAR(100) NOT NULL,
  kind        VARCHAR(20)  NOT NULL,
  param       VARCHAR(100) NULL,
  max_items   INT          NOT NULL DEFAULT 12,
  active      TINYINT(1)   NOT NULL DEFAULT 1,
  sort_order  INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
)" . $tail,
            "CREATE TABLE IF NOT EXISTS pages (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug        VARCHAR(80)  NOT NULL,
  title       VARCHAR(150) NOT NULL,
  body        MEDIUMTEXT   NULL,
  in_menu     TINYINT(1)   NOT NULL DEFAULT 1,
  guests      TINYINT(1)   NOT NULL DEFAULT 1,
  active      TINYINT(1)   NOT NULL DEFAULT 1,
  sort_order  INT          NOT NULL DEFAULT 0,
  updated_at  DATETIME     NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_pages_slug (slug)
)" . $tail,
            "ALTER TABLE users ADD COLUMN session_version INT NOT NULL DEFAULT 0",
            function ($pdo) {
                if ((int)$pdo->query('SELECT COUNT(*) FROM home_sections')->fetchColumn() === 0) {
                    $ins = $pdo->prepare('INSERT INTO home_sections (title, kind, param, max_items, active, sort_order) VALUES (?,?,?,?,1,?)');
                    $ins->execute(array('Aggiunti di recente', 'recent', null, 12, 10));
                    $ins->execute(array('Tutti i libri per autore', 'authors', null, 0, 20));
                }
            },
        ),
        // 1.2.0: prestiti e cestino
        3 => array(
            "CREATE TABLE IF NOT EXISTS loans (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  book_id      INT UNSIGNED NOT NULL,
  borrower     VARCHAR(120) NOT NULL,
  contact      VARCHAR(120) NULL,
  lent_at      DATE         NOT NULL,
  due_at       DATE         NULL,
  returned_at  DATE         NULL,
  notes        TEXT         NULL,
  created_by   INT UNSIGNED NULL,
  created_at   DATETIME     NULL,
  PRIMARY KEY (id),
  KEY idx_loans_book (book_id),
  KEY idx_loans_open (returned_at),
  CONSTRAINT fk_loans_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
)" . $tail,
            "CREATE TABLE IF NOT EXISTS books_trash (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  book_id     INT UNSIGNED NOT NULL,
  title       VARCHAR(255) NOT NULL,
  authors     VARCHAR(255) NULL,
  cover_file  VARCHAR(100) NULL,
  data        MEDIUMTEXT   NOT NULL,
  deleted_by  VARCHAR(60)  NULL,
  deleted_at  DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_trash_deleted (deleted_at)
)" . $tail,
            function ($pdo) {
                // i backup fatti prima di un aggiornamento contengono gli account: il nome deve dirlo, cosi' li vede solo l'Admin
                foreach ((is_dir(BACKUP_DIR) ? scandir(BACKUP_DIR) : array()) as $f) {
                    if (preg_match('/^(libreria_\d{8}_\d{6}_prima-(aggiornamento|ritorno))(_[a-z0-9]{4})?\.(zip|json)$/', $f, $m)) {
                        @rename(BACKUP_DIR . '/' . $f, BACKUP_DIR . '/' . $m[1] . (isset($m[3]) ? $m[3] : '') . '_completo.' . $m[4]);
                    } elseif (preg_match('/^libreria_\d{8}_\d{6}_caricato_[a-z0-9]+\.zip$/', $f) && class_exists('ZipArchive')) {
                        // backup caricati a mano: si controlla il contenuto
                        $z = new ZipArchive();
                        if ($z->open(BACKUP_DIR . '/' . $f) === true) {
                            $j = json_decode((string)$z->getFromName('data.json'), true);
                            $z->close();
                            if (!empty($j['full'])) {
                                @rename(BACKUP_DIR . '/' . $f, BACKUP_DIR . '/' . substr($f, 0, -4) . '_completo.zip');
                            }
                        }
                    }
                }
            },
        ),
        // 1.3.0: pagine in HTML, con CSS proprio e titolo facoltativo
        4 => array(
            "ALTER TABLE pages ADD COLUMN format VARCHAR(10) NOT NULL DEFAULT 'md'",
            "ALTER TABLE pages ADD COLUMN css MEDIUMTEXT NULL",
            "ALTER TABLE pages ADD COLUMN show_title TINYINT(1) NOT NULL DEFAULT 1",
        ),
        // 1.4.0: destinazioni dei backup (cartella/SAMBA, SFTP, FTP, WebDAV, Google Drive, Dropbox)
        5 => array(
            "CREATE TABLE IF NOT EXISTS backup_targets (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name          VARCHAR(80)  NOT NULL,
  type          VARCHAR(10)  NOT NULL,
  config        TEXT         NULL,
  active        TINYINT(1)   NOT NULL DEFAULT 1,
  send_full     TINYINT(1)   NOT NULL DEFAULT 0,
  last_status   VARCHAR(10)  NULL,
  last_message  VARCHAR(500) NULL,
  last_at       DATETIME     NULL,
  created_at    DATETIME     NULL,
  PRIMARY KEY (id)
)" . $tail,
        ),
        // 1.4.1: "Aggiunti di recente" scorre con frecce e dito: si portano a 12 i libri della riga se era rimasta a 6
        6 => array(
            "UPDATE home_sections SET max_items = 12 WHERE kind = 'recent' AND max_items = 6",
        ),
        // 1.8.0: Media (immagini, PDF, video e audio per le pagine), in cartelle
        // 1.9.14: avvisi (campanella), preferenze degli avvisi e riservatezza delle letture
        14 => array(
            "CREATE TABLE IF NOT EXISTS notifications (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  kind        VARCHAR(30)  NOT NULL,
  actor_id    INT UNSIGNED NULL,
  book_id     INT UNSIGNED NULL,
  text        VARCHAR(400) NOT NULL,
  link        VARCHAR(255) NULL,
  group_key   VARCHAR(120) NULL,
  count       INT          NOT NULL DEFAULT 1,
  read_at     DATETIME     NULL,
  created_at  DATETIME     NOT NULL,
  updated_at  DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_notif_user (user_id, read_at),
  KEY idx_notif_group (user_id, group_key),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
)" . $tail,
            "ALTER TABLE users ADD COLUMN share_reading TINYINT(1) NOT NULL DEFAULT 1",
            "ALTER TABLE users ADD COLUMN notify_prefs TEXT NULL",
        ),
        // 1.9.3: dispositivi ricordati ("Ricorda questo dispositivo")
        13 => array(
            "CREATE TABLE IF NOT EXISTS user_devices (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id       INT UNSIGNED NOT NULL,
  selector      VARCHAR(24)  NOT NULL,
  token_hash    CHAR(64)     NOT NULL,
  prev_hash     CHAR(64)     NULL,
  rotated_at    DATETIME     NULL,
  name          VARCHAR(120) NULL,
  user_agent    VARCHAR(250) NULL,
  last_ip       VARCHAR(45)  NULL,
  created_at    DATETIME     NOT NULL,
  last_used_at  DATETIME     NOT NULL,
  expires_at    DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_device_selector (selector),
  KEY idx_device_user (user_id),
  CONSTRAINT fk_device_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
)" . $tail,
        ),
        // 1.9.2: indirizzo email degli utenti (per le notifiche) e consenso a ricevere email dal sito
        12 => array(
            "ALTER TABLE users ADD COLUMN email VARCHAR(190) NULL",
            "ALTER TABLE users ADD COLUMN email_notify TINYINT(1) NOT NULL DEFAULT 1",
        ),
        // 1.9.0: plugin firmati, verifica in due passaggi piu' robusta (codici non riutilizzabili, segreto cifrato)
        11 => array(
            "ALTER TABLE users ADD COLUMN totp_last_step INT NOT NULL DEFAULT 0",
            function ($pdo) {
                if (DB_DRIVER !== 'sqlite') {
                    $pdo->exec('ALTER TABLE users MODIFY totp_secret VARCHAR(255) NULL');
                }
            },
            "CREATE TABLE IF NOT EXISTS plugins (
  id            VARCHAR(40)  NOT NULL PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  version       VARCHAR(20)  NOT NULL,
  author        VARCHAR(100) NULL,
  description   VARCHAR(500) NULL,
  active        TINYINT(1)   NOT NULL DEFAULT 0,
  status        VARCHAR(20)  NOT NULL DEFAULT 'ok',
  error         VARCHAR(500) NULL,
  manifest      MEDIUMTEXT   NULL,
  key_id        VARCHAR(40)  NULL,
  installed_at  DATETIME     NOT NULL,
  updated_at    DATETIME     NOT NULL
)" . $tail,
            function ($pdo) {
                // i segreti della verifica in due passaggi gia' attivi vengono cifrati con la chiave del server
                require_once dirname(__FILE__) . '/crypto.php';
                try {
                    $up = $pdo->prepare('UPDATE users SET totp_secret = ? WHERE id = ?');
                    foreach ($pdo->query('SELECT id, totp_secret FROM users WHERE totp_secret IS NOT NULL')->fetchAll() as $u) {
                        if ($u['totp_secret'] !== '' && !sec_is_encrypted($u['totp_secret'])) {
                            $up->execute(array(sec_encrypt($u['totp_secret'], 'totp'), (int)$u['id']));
                        }
                    }
                } catch (Exception $e) {
                    // senza OpenSSL o senza chiave scrivibile restano come prima (si cifrano al prossimo accesso)
                }
            },
        ),
        10 => array(
            "CREATE TABLE IF NOT EXISTS media_folders (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(80)  NOT NULL,
  sort_order  INT          NOT NULL DEFAULT 0,
  created_at  DATETIME     NOT NULL,
  PRIMARY KEY (id)
)" . $tail,
            "CREATE TABLE IF NOT EXISTS media_files (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  folder_id      INT UNSIGNED NULL,
  filename       VARCHAR(100) NOT NULL,
  original_name  VARCHAR(200) NULL,
  title          VARCHAR(150) NOT NULL,
  alt            VARCHAR(250) NULL,
  mime           VARCHAR(40)  NOT NULL,
  kind           VARCHAR(10)  NOT NULL,
  size           INT UNSIGNED NOT NULL DEFAULT 0,
  width          INT          NULL,
  height         INT          NULL,
  has_thumb      TINYINT(1)   NOT NULL DEFAULT 0,
  uploaded_by    VARCHAR(60)  NULL,
  created_at     DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_media_file (filename),
  KEY idx_media_folder (folder_id, created_at),
  CONSTRAINT fk_media_folder FOREIGN KEY (folder_id) REFERENCES media_folders (id) ON DELETE SET NULL
)" . $tail,
            function ($pdo) {
                if ((int)$pdo->query('SELECT COUNT(*) FROM media_folders')->fetchColumn() === 0) {
                    $ins = $pdo->prepare('INSERT INTO media_folders (name, sort_order, created_at) VALUES (?,?,?)');
                    foreach (array('Immagini di sfondo', 'Icone', 'Pagine') as $i => $n) {
                        $ins->execute(array($n, $i + 1, date('Y-m-d H:i:s')));
                    }
                }
            },
        ),
        // 1.7.0: chiavi di accesso (passkey)
        9 => array(
            "CREATE TABLE IF NOT EXISTS user_passkeys (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id        INT UNSIGNED NOT NULL,
  credential_id  VARCHAR(255) NOT NULL,
  public_key     TEXT         NOT NULL,
  alg            INT          NOT NULL,
  sign_count     INT UNSIGNED NOT NULL DEFAULT 0,
  name           VARCHAR(80)  NOT NULL,
  aaguid         VARCHAR(32)  NULL,
  transports     VARCHAR(100) NULL,
  created_at     DATETIME     NOT NULL,
  last_used_at   DATETIME     NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_passkey_cred (credential_id),
  KEY idx_passkey_user (user_id),
  CONSTRAINT fk_pk_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
)" . $tail,
        ),
        // 1.6.0: diario di lettura (letture, avanzamento, voti, obiettivi, trofei)
        8 => array(
            "CREATE TABLE IF NOT EXISTS reading_sessions (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id       INT UNSIGNED NOT NULL,
  book_id       INT UNSIGNED NOT NULL,
  status        VARCHAR(12)  NOT NULL,
  started_at    DATETIME     NULL,
  finished_at   DATETIME     NULL,
  date_unknown  TINYINT(1)   NOT NULL DEFAULT 0,
  rating        DECIMAL(3,2) NULL,
  review        TEXT         NULL,
  source        VARCHAR(12)  NULL,
  created_at    DATETIME     NOT NULL,
  updated_at    DATETIME     NULL,
  PRIMARY KEY (id),
  KEY idx_rs_user_book (user_id, book_id),
  KEY idx_rs_user_finished (user_id, finished_at),
  CONSTRAINT fk_rs_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_rs_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
)" . $tail,
            "CREATE TABLE IF NOT EXISTS reading_progress (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id  INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  book_id     INT UNSIGNED NOT NULL,
  page        INT          NULL,
  percent     DECIMAL(5,2) NULL,
  note        VARCHAR(500) NULL,
  read_at     DATETIME     NOT NULL,
  created_at  DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_rp_session (session_id, read_at),
  KEY idx_rp_user (user_id, read_at),
  CONSTRAINT fk_rp_session FOREIGN KEY (session_id) REFERENCES reading_sessions (id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
)" . $tail,
            "CREATE TABLE IF NOT EXISTS reading_goals (
  user_id  INT UNSIGNED NOT NULL,
  year     INT          NOT NULL,
  books    INT          NOT NULL,
  PRIMARY KEY (user_id, year),
  CONSTRAINT fk_rg_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
)" . $tail,
            "CREATE TABLE IF NOT EXISTS user_trophies (
  user_id      INT UNSIGNED NOT NULL,
  code         VARCHAR(30)  NOT NULL,
  level        INT          NOT NULL,
  unlocked_at  DATETIME     NOT NULL,
  seen         TINYINT(1)   NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, code, level),
  CONSTRAINT fk_ut_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
)" . $tail,
            'reading_sessions_from_user_books',
        ),
        // 1.5.0: firewall (IP bloccati e registro degli eventi)
        7 => array(
            "CREATE TABLE IF NOT EXISTS fw_blocks (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ip          VARCHAR(64)  NOT NULL,
  is_range    TINYINT(1)   NOT NULL DEFAULT 0,
  country     VARCHAR(4)   NULL,
  reason      VARCHAR(20)  NOT NULL,
  detail      VARCHAR(255) NULL,
  source      VARCHAR(10)  NOT NULL DEFAULT 'auto',
  level       INT          NOT NULL DEFAULT 1,
  active      TINYINT(1)   NOT NULL DEFAULT 1,
  hits        INT          NOT NULL DEFAULT 0,
  last_hit    DATETIME     NULL,
  created_at  DATETIME     NOT NULL,
  expires_at  DATETIME     NULL,
  created_by  VARCHAR(60)  NULL,
  PRIMARY KEY (id),
  KEY idx_fw_blocks_ip (ip, active),
  KEY idx_fw_blocks_range (is_range, active)
)" . $tail,
            "CREATE TABLE IF NOT EXISTS fw_events (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ip          VARCHAR(45)  NOT NULL,
  country     VARCHAR(4)   NULL,
  kind        VARCHAR(20)  NOT NULL,
  detail      VARCHAR(255) NULL,
  path        VARCHAR(255) NULL,
  hits        INT          NOT NULL DEFAULT 1,
  created_at  DATETIME     NOT NULL,
  last_at     DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_fw_events_ip (ip, kind, last_at),
  KEY idx_fw_events_last (last_at)
)" . $tail,
        ),
    );
}

// Le letture gia' segnate (stato "letto" / "in lettura") diventano la prima voce del diario di lettura
function reading_sessions_from_user_books($pdo)
{
    $ins = $pdo->prepare("INSERT INTO reading_sessions (user_id, book_id, status, started_at, finished_at, date_unknown, source, created_at, updated_at) VALUES (?,?,?,?,?,?,'manuale',?,?)");
    $now = date('Y-m-d H:i:s');
    foreach ($pdo->query("SELECT user_id, book_id, status, started_at, finished_at FROM user_books WHERE status IN ('letto','in_lettura')")->fetchAll() as $r) {
        $chk = $pdo->prepare('SELECT COUNT(*) FROM reading_sessions WHERE user_id = ? AND book_id = ?');
        $chk->execute(array($r['user_id'], $r['book_id']));
        if ((int)$chk->fetchColumn()) {
            continue;
        }
        $start = $r['started_at'] ? substr($r['started_at'], 0, 10) . ' 12:00:00' : null;
        $end = $r['status'] === 'letto' && $r['finished_at'] ? substr($r['finished_at'], 0, 10) . ' 21:00:00' : null;
        $ins->execute(array($r['user_id'], $r['book_id'], $r['status'], $start, $end, $r['status'] === 'letto' && !$end ? 1 : 0, $now, $now));
    }
}

function db_version_get($pdo)
{
    try {
        $st = $pdo->prepare('SELECT setting_value FROM settings WHERE setting_key = ?');
        $st->execute(array('db_version'));
        $v = $st->fetchColumn();
        return $v === false || $v === null || $v === '' ? 1 : (int)$v;
    } catch (Exception $e) {
        return 1;
    }
}

function db_version_set($pdo, $v)
{
    $now = date('Y-m-d H:i:s');
    $up = $pdo->prepare('UPDATE settings SET setting_value = ?, updated_at = ? WHERE setting_key = ?');
    $up->execute(array((string)$v, $now, 'db_version'));
    if ($up->rowCount() === 0) {
        try {
            $pdo->prepare('INSERT INTO settings (setting_key, setting_value, updated_at) VALUES (?,?,?)')->execute(array('db_version', (string)$v, $now));
        } catch (Exception $e) {
            // gia' presente con lo stesso valore
        }
    }
}

function db_migrate_error_text($e)
{
    $m = $e->getMessage();
    if (stripos($m, 'command denied') !== false || stripos($m, 'Access denied') !== false) {
        return 'L\'utente del database non ha il permesso di creare tabelle. Concedigli i permessi completi sul database, ad esempio: '
             . 'GRANT ALL PRIVILEGES ON libreria.* TO \'utente\'@\'host\';  poi ricarica la pagina.';
    }
    return 'Aggiornamento del database non riuscito: ' . $m;
}

/*
 * Porta il database all'ultima versione. Ritorna array(ok, messaggio, versione_raggiunta).
 * $pdo: connessione (l'installazione guidata passa la sua).
 */
function db_migrate($pdo = null, $driver = null)
{
    $pdo = $pdo ? $pdo : db();
    $driver = $driver === null ? DB_DRIVER : $driver;
    $current = db_version_get($pdo);
    if ($current >= APP_DB_VERSION) {
        return array(true, '', $current);
    }
    $lock = null;
    if (is_dir(DATA_DIR) && is_writable(DATA_DIR)) {
        $lock = @fopen(DATA_DIR . '/migrate.lock', 'c');
        if ($lock) {
            flock($lock, LOCK_EX);
            $current = db_version_get($pdo); // un'altra richiesta potrebbe averlo appena fatto
        }
    }
    $done = array();
    try {
        $migs = db_migrations();
        ksort($migs); // sempre in ordine di versione
        foreach ($migs as $ver => $steps) {
            if ($ver <= $current || $ver > APP_DB_VERSION) {
                continue;
            }
            foreach ($steps as $step) {
                if (is_callable($step)) {
                    $step($pdo);
                    continue;
                }
                $sql = sql_for_driver($step, $driver);
                if ($sql === '') {
                    continue;
                }
                try {
                    $pdo->exec($sql);
                } catch (PDOException $e) {
                    $m = $e->getMessage();
                    // colonna o tabella gia' presenti: il passo era gia' stato fatto
                    if (stripos($m, 'Duplicate column') === false && stripos($m, 'duplicate column') === false && stripos($m, 'already exists') === false) {
                        throw $e;
                    }
                }
            }
            db_version_set($pdo, $ver);
            $current = $ver;
            $done[] = $ver;
        }
    } catch (Exception $e) {
        if ($lock) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
        return array(false, db_migrate_error_text($e), $current);
    }
    if ($lock) {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
    return array(true, $done ? 'Database aggiornato alla versione ' . $current . '.' : '', $current);
}
