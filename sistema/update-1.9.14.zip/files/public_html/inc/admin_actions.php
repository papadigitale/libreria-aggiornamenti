<?php
/*
 * Azioni (POST) delle sezioni nuove del pannello.
 * Chiamata da gestione.php dopo il controllo CSRF. Ogni ramo termina con un redirect.
 */
require_once dirname(__FILE__) . '/extras.php';
require_once dirname(__FILE__) . '/library_tools.php';
require_once dirname(__FILE__) . '/countries.php';

function admin_back($default)
{
    $b = post('back');
    // si torna solo a pagine della gestione (mai a indirizzi esterni)
    return preg_match('#^gestione\.php\?[A-Za-z0-9_=&%+.\-]*$#', $b) ? $b : $default;
}

function admin_flag($k)
{
    return post($k) === '1' ? 1 : 0;
}

function admin_is_dup($e)
{
    return stripos($e->getMessage(), 'Duplicate') !== false || stripos($e->getMessage(), 'UNIQUE') !== false;
}

function admin_lines($text, $max = 100)
{
    $out = array();
    foreach (preg_split('/\r?\n/', (string)$text) as $l) {
        $l = str_cut(trim(preg_replace('/\s+/', ' ', $l)), $max);
        if ($l !== '' && !in_array($l, $out, true)) {
            $out[] = $l;
        }
    }
    return $out;
}

function admin_handle_post($a, $sez)
{
    $pdo = db();
    /* --- Pulsanti della libreria (solo Admin) --- */
    if (in_array($a, array('chips_save', 'chips_add', 'chips_reset'), true)) {
        if (!is_admin()) {
            deny_page('Operazione non consentita.');
        }
        require_once dirname(__FILE__) . '/chips.php';
        $back = 'gestione.php?sez=pulsanti';
        if ($a === 'chips_reset') {
            setting_save('lib_chips', '');
            app_log('pulsanti_libreria', 'Pulsanti della libreria riportati a quelli predefiniti', 'info');
            flash('Pulsanti predefiniti ripristinati.');
            redirect($back);
        }
        $cfg = chips_config();
        if ($a === 'chips_add') {
            $w = post('what');
            $t = substr($w, 0, 1) === 'g' ? 'genere' : (substr($w, 0, 1) === 'e' ? 'etichetta' : '');
            $v = (int)substr($w, 1);
            $ok = $t === 'genere' ? category_name($v) !== '' : ($t === 'etichetta' ? (bool)term_get($v) : false);
            foreach ($cfg as $c) {
                if ($c['t'] === $t && (int)$c['v'] === $v) {
                    $ok = false;
                    flash('Questo pulsante c\'è già.', 'error');
                    redirect($back);
                }
            }
            if (!$ok) {
                flash('Scegli un genere o un valore.', 'error');
                redirect($back);
            }
            $cfg[] = array('t' => $t, 'n' => str_cut(trim(post('name')), 40), 'on' => 1, 'v' => $v);
            setting_save('lib_chips', json_encode($cfg, JSON_UNESCAPED_UNICODE));
            flash('Pulsante aggiunto in fondo: puoi spostarlo con «Posizione».');
            redirect($back);
        }
        // chips_save (e "Togli" per i pulsanti di generi ed etichette)
        $T = isset($_POST['t']) && is_array($_POST['t']) ? $_POST['t'] : array();
        $del = isset($_POST['del']) ? (int)$_POST['del'] : -1;
        $rows = array();
        $types = chip_types();
        foreach ($T as $i => $t) {
            $i = (int)$i;
            if (!isset($types[$t]) || $i === $del) {
                continue;
            }
            $rows[] = array(
                'pos' => isset($_POST['pos'][$i]) ? (int)$_POST['pos'][$i] : 99, 'old' => $i,
                'c' => array('t' => $t, 'n' => str_cut(trim(isset($_POST['n'][$i]) ? (string)$_POST['n'][$i] : ''), 40),
                    'on' => $t === 'tutti' || !empty($_POST['on'][$i]) ? 1 : 0, 'v' => isset($_POST['v'][$i]) ? (int)$_POST['v'][$i] : 0),
            );
        }
        // a parita' di posizione vince il pulsante appena spostato
        usort($rows, function ($x, $y) {
            if ($x['pos'] !== $y['pos']) {
                return $x['pos'] - $y['pos'];
            }
            $mx = $x['pos'] !== $x['old'] + 1 ? 0 : 1;
            $my = $y['pos'] !== $y['old'] + 1 ? 0 : 1;
            return $mx !== $my ? $mx - $my : $x['old'] - $y['old'];
        });
        setting_save('lib_chips', json_encode(array_map(function ($r) { return $r['c']; }, $rows), JSON_UNESCAPED_UNICODE));
        app_log('pulsanti_libreria', 'Pulsanti della libreria aggiornati', 'info');
        flash($del >= 0 ? 'Pulsante tolto.' : 'Pulsanti salvati.');
        redirect($back);
    }
    /* --- Pagine dei plugin: salvataggio dei loro moduli --- */
    if ($a === 'plg_salva' && strpos($sez, 'plg-') === 0) {
        $pg = isset($GLOBALS['PLG_PAGES'][$sez]) ? $GLOBALS['PLG_PAGES'][$sez] : null;
        if (!$pg || ($pg['admin'] && !is_admin()) || !can_edit() || !$pg['salva']) {
            deny_page('Operazione non consentita.');
        }
        $pid = $pg['plugin']->id;
        $GLOBALS['PLG_CURRENT'] = $pid;
        try {
            call_user_func($pg['salva'], $pg['plugin']);
        } catch (Throwable $e) {
            plugin_fail($pid, $e);
            flash('Il plugin è andato in errore ed è stato spento: ' . $e->getMessage(), 'error');
            redirect('gestione.php?sez=plugin');
        }
        $GLOBALS['PLG_CURRENT'] = null;
        $back = post('back');
        redirect(preg_match('#^gestione\.php\?sez=' . preg_quote($sez, '#') . '[A-Za-z0-9_=&%+.\-]*$#', $back) ? $back : 'gestione.php?sez=' . $sez);
    }
    /* --- Gestione dei plugin (solo Admin) --- */
    if (in_array($a, array('plg_upload', 'plg_on', 'plg_off', 'plg_del', 'plg_check', 'plg_sign', 'plg_safe'), true)) {
        if (!is_admin()) {
            deny_page('Operazione non consentita.');
        }
        require_once dirname(__FILE__) . '/plugins.php';
        require_once dirname(__FILE__) . '/firma.php';
        $back = 'gestione.php?sez=plugin';
        if (!plugins_ready()) {
            redirect($back);
        }
        if ($a === 'plg_safe') {
            $f = plugins_dir() . '/MODALITA_SICURA';
            if (post('on') === '1') {
                @mkdir(plugins_dir(), 0775, true);
                @file_put_contents($f, date('c') . " modalita' sicura dal pannello\n");
                app_log('plugin_modalita_sicura', 'Modalità sicura attivata: nessun plugin viene caricato', 'warn');
                flash('Modalità sicura attiva: nessun plugin viene caricato.');
            } else {
                @unlink($f);
                app_log('plugin_modalita_sicura', 'Modalità sicura disattivata', 'warn');
                flash('Modalità sicura disattivata: i plugin attivi tornano a funzionare.');
            }
            redirect($back);
        }
        if ($a === 'plg_upload' || $a === 'plg_sign') {
            $fk = $a === 'plg_upload' ? 'plugin_zip' : 'sign_zip';
            if (!isset($_FILES[$fk]) || $_FILES[$fk]['error'] !== UPLOAD_ERR_OK || $_FILES[$fk]['size'] > 50 * 1048576) {
                flash('Scegli il file .zip (al massimo 50 MB).', 'error');
                redirect($back);
            }
            $tmp = plugins_dir() . '/.arrivo_' . substr(random_token(4), 0, 8) . '.zip';
            @mkdir(plugins_dir(), 0775, true);
            if (!move_uploaded_file($_FILES[$fk]['tmp_name'], $tmp)) {
                flash('Caricamento non riuscito: la cartella data/plugins è scrivibile?', 'error');
                redirect($back);
            }
            if ($a === 'plg_sign') {
                // firma con la chiave privata salvata sul server, poi il pacchetto firmato si scarica
                if (firma_pass_bloccata()) {
                    @unlink($tmp);
                    flash('Troppe passphrase sbagliate: riprova tra 15 minuti.', 'error');
                    redirect($back);
                }
                try {
                    $tipo = firma_tipo_zip($tmp);
                    $k = firma_apri_privata(post('passphrase'));
                    $d = firma_firma_zip($tmp, $k, $tipo);
                } catch (Exception $e) {
                    if (strpos($e->getMessage(), 'Passphrase') !== false) {
                        firma_pass_errata();
                    }
                    @unlink($tmp);
                    flash('Firma non riuscita: ' . $e->getMessage(), 'error');
                    redirect($back);
                }
                app_log('pacchetto_firmato', 'Firmato dal pannello: ' . $tipo . ' "' . str_cut($_FILES[$fk]['name'], 80) . '" (' . $d['file'] . ' file)', 'warn');
                $name = preg_replace('/[^A-Za-z0-9._\-]/', '_', pathinfo($_FILES[$fk]['name'], PATHINFO_FILENAME));
                while (ob_get_level() > 0) {
                    ob_end_clean();
                }
                header('Content-Type: application/zip');
                header('Content-Disposition: attachment; filename="' . ($name !== '' ? $name : 'pacchetto') . (strpos($name, 'firmato') === false ? '-firmato' : '') . '.zip"');
                header('Content-Length: ' . filesize($tmp));
                readfile($tmp);
                @unlink($tmp);
                exit;
            }
            try {
                $r = plugin_install($tmp);
                @unlink($tmp);
                $row = plugin_get($r[0]);
                app_log('plugin_installato', 'Plugin "' . $row['name'] . '" ' . $row['version'] . ($r[1] ? ' installato' : ' aggiornato (da ' . $r[2] . ')'), 'warn');
                flash($r[1] ? 'Plugin "' . $row['name'] . '" installato: controlla la firma e attivalo.' : 'Plugin "' . $row['name'] . '" aggiornato alla versione ' . $row['version'] . '.');
            } catch (Exception $e) {
                @unlink($tmp);
                app_log('plugin_rifiutato', $e->getMessage(), 'warn');
                flash('Plugin non installato: ' . $e->getMessage(), 'error');
            }
            redirect($back);
        }
        $id = post('id');
        $row = plugin_id_ok($id) ? plugin_get($id) : null;
        if (!$row && $a !== 'plg_check') {
            redirect($back);
        }
        if ($a === 'plg_on') {
            try {
                plugin_activate($id);
                app_log('plugin_attivato', 'Plugin "' . $row['name'] . '" attivato', 'warn');
                flash('Plugin "' . $row['name'] . '" attivato.');
            } catch (Exception $e) {
                flash($e->getMessage(), 'error');
            }
        } elseif ($a === 'plg_off') {
            plugin_deactivate($id);
            app_log('plugin_disattivato', 'Plugin "' . $row['name'] . '" disattivato', 'warn');
            flash('Plugin "' . $row['name'] . '" disattivato.');
        } elseif ($a === 'plg_del') {
            plugin_remove($id, post('delete_data') === '1');
            app_log('plugin_rimosso', 'Plugin "' . $row['name'] . '" rimosso' . (post('delete_data') === '1' ? ' con i suoi dati' : ''), 'warn');
            flash('Plugin "' . $row['name'] . '" rimosso.');
        } elseif ($a === 'plg_check') {
            $bad = 0;
            foreach (plugins_rows() as $pr) {
                $why = plugin_integrity($pr, true);
                if ($why !== '') {
                    $bad++;
                    plugin_set_status($pr['id'], 'manomesso', $why);
                } elseif ($pr['status'] === 'manomesso') {
                    plugin_set_status($pr['id'], 'ok', '', false);
                }
            }
            flash($bad ? $bad . ' plugin con problemi di integrità: sono stati spenti.' : 'Tutti i plugin sono integri e firmati.', $bad ? 'error' : 'success');
        }
        redirect($back);
    }
    $needs_extras = array('books_bulk', 'book_save', 'tax_add', 'tax_save', 'tax_del', 'term_add', 'term_save', 'term_del', 'term_merge',
        'field_add', 'field_save', 'field_del', 'sec_add', 'sec_save', 'sec_move', 'sec_del', 'page_save', 'page_del');
    if (in_array($a, $needs_extras, true) && !extras_ready()) {
        flash('Il database non è ancora aggiornato: vedi il messaggio in alto o Sistema → Aggiornamento.', 'error');
        redirect('gestione.php?sez=' . $sez);
    }

    /* ---------------- Esportazione di tutta la libreria (Excel o PDF) ---------------- */
    if ($a === 'books_export') {
        require_once dirname(__FILE__) . '/export.php';
        export_send(null, post('ex_format') === 'pdf' ? 'pdf' : 'xlsx', post('ex_order'));
    }

    /* ---------------- Libri: modifica di più libri insieme ---------------- */
    if ($a === 'books_bulk') {
        $GLOBALS['NOTIF_SILENZIO'] = true; // operazioni su tanti libri: niente avvisi
        $back = admin_back('gestione.php?sez=libri');
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)(isset($_POST['ids']) ? $_POST['ids'] : array())))));
        $op = post('op');
        if (!$ids) {
            flash('Seleziona almeno un libro con le caselle a sinistra.', 'warn');
            redirect($back);
        }
        $n = count($ids);
        $in = implode(',', array_fill(0, $n, '?'));
        if ($op === 'genre') {
            $c = (int)post('category_id');
            $c = $c > 0 && category_name($c) !== '' ? $c : null;
            $pdo->prepare('UPDATE books SET category_id = ?, updated_at = ? WHERE id IN (' . $in . ')')->execute(array_merge(array($c, now()), $ids));
            $msg = 'Genere ' . ($c ? '"' . category_name($c) . '" assegnato' : 'tolto') . ' a ' . $n . ' libri.';
        } elseif ($op === 'term_add' || $op === 'term_remove') {
            $t = term_get((int)post('term_id'));
            if (!$t) {
                flash('Scegli il valore dell\'etichetta.', 'error');
                redirect($back);
            }
            $tax = taxonomy_get($t['taxonomy_id']);
            foreach ($ids as $bid) {
                if ($op === 'term_add' && !(int)$tax['multiple']) {
                    $pdo->prepare('DELETE FROM book_terms WHERE book_id = ? AND term_id IN (SELECT id FROM terms WHERE taxonomy_id = ?)')
                        ->execute(array($bid, (int)$tax['id']));
                }
                $pdo->prepare('DELETE FROM book_terms WHERE book_id = ? AND term_id = ?')->execute(array($bid, (int)$t['id']));
                if ($op === 'term_add') {
                    $pdo->prepare('INSERT INTO book_terms (book_id, term_id) VALUES (?, ?)')->execute(array($bid, (int)$t['id']));
                }
            }
            $msg = $t['taxonomy_name'] . ' "' . $t['name'] . '" ' . ($op === 'term_add' ? 'aggiunto a ' : 'tolto da ') . $n . ' libri.';
        } elseif ($op === 'shelf') {
            $pdo->prepare('UPDATE books SET shelf = ?, updated_at = ? WHERE id IN (' . $in . ')')->execute(array_merge(array(str_cut(post('shelf'), 100), now()), $ids));
            $msg = 'Posizione aggiornata per ' . $n . ' libri.';
        } elseif ($op === 'field') {
            $fields = custom_fields_all();
            $fid = (int)post('field_id');
            if (!isset($fields[$fid])) {
                flash('Scegli il campo da impostare.', 'error');
                redirect($back);
            }
            $val = custom_field_clean($fields[$fid], isset($_POST['field_value']) ? (string)$_POST['field_value'] : '');
            foreach ($ids as $bid) {
                book_field_set($bid, $fid, $val);
            }
            $msg = 'Campo "' . $fields[$fid]['name'] . '" ' . ($val === '' ? 'svuotato' : 'impostato') . ' per ' . $n . ' libri.';
        } elseif ($op === 'export') {
            require_once dirname(__FILE__) . '/export.php';
            export_send($ids, post('ex_format') === 'pdf' ? 'pdf' : 'xlsx', post('ex_order'));
        } elseif ($op === 'reading') {
            require_once dirname(__FILE__) . '/reading.php';
            if (!reading_ready()) {
                redirect($back);
            }
            $st = $pdo->prepare("SELECT id, username, display_name FROM users WHERE id = ? AND active = 1 AND role IN ('admin','gestore','registrato')");
            $st->execute(array((int)post('rd_user')));
            $who = $st->fetch();
            if (!$who) {
                flash('Scegli per chi segnare i libri.', 'error');
                redirect($back);
            }
            $status = post('rd_status');
            $status = isset(reading_statuses()[$status]) ? $status : '';
            $when = post('rd_when');
            $date = now();
            if ($when === 'date') {
                $date = reading_parse_dt(post('rd_date'), true);
                if ($date === null) {
                    flash('Scegli una data valida (non nel futuro).', 'error');
                    redirect($back);
                }
            }
            $opts = array('date' => $date, 'unknown' => $when === 'unknown' && in_array($status, array('letto', 'abbandonato'), true), 'source' => 'multipla');
            $done = 0;
            $same = 0;
            foreach ($ids as $bid) {
                if (!book_get($bid)) {
                    continue;
                }
                $cur = user_book_row((int)$who['id'], $bid);
                if ((string)$cur['status'] === $status) {
                    $same++;
                    continue;
                }
                reading_set_status((int)$who['id'], $bid, $status, $opts);
                $done++;
            }
            $wname = $who['display_name'] !== '' ? $who['display_name'] : $who['username'];
            $label = $status === '' ? 'senza stato' : 'come "' . strtolower(reading_statuses()[$status]) . '"';
            $msg = $done . ' ' . ($done === 1 ? 'libro segnato ' : 'libri segnati ') . $label . ' per ' . $wname
                . ($status === 'letto' && $done ? ($opts['unknown'] ? ' (data sconosciuta)' : ' (il ' . date('d/m/Y', strtotime($date)) . ')') : '')
                . ($same ? '; ' . $same . ' lo ' . ($same === 1 ? 'era' : 'erano') . ' già' : '') . '.';
            if ((int)$who['id'] === current_uid()) {
                $msg .= reading_trophies_flash(current_uid());
            } else {
                reading_trophies_check((int)$who['id']);
            }
        } elseif ($op === 'delete') {
            foreach ($ids as $bid) {
                book_trash($bid);
            }
            app_log('libri_eliminati', $n . ' libri ' . (v12_ready() ? 'spostati nel cestino' : 'eliminati') . ': #' . implode(', #', array_slice($ids, 0, 40)), 'warn');
            flash(v12_ready() ? ($n === 1 ? 'Libro spostato nel cestino.' : $n . ' libri spostati nel cestino.') . ' Puoi recuperarli da Libri → Cestino.' : $n . ' libri eliminati dalla libreria.');
            redirect($back);
        } else {
            flash('Scegli cosa fare con i libri selezionati.', 'warn');
            redirect($back);
        }
        app_log('libri_modificati', $msg);
        flash($msg);
        redirect($back);
    }

    /* ---------------- Libro: copertina e ricerca online dal pannello (si resta nel pannello) ---------------- */
    if (in_array($a, array('book_cover', 'book_cover_del', 'book_refill_one'), true)) {
        $id = (int)post('id');
        $b = book_get($id);
        if (!$b) {
            redirect('gestione.php?sez=libri');
        }
        $here = 'gestione.php?sez=libro&id=' . $id;
        if ($a === 'book_refill_one') {
            require_once dirname(__FILE__) . '/refill.php';
            $r = book_refill($id);
            flash($r['changed'] ? 'Aggiornato da internet: ' . implode(', ', $r['changed']) . '.' : $r['msg'], $r['changed'] ? 'success' : 'warn');
            redirect($here);
        }
        if ($a === 'book_cover_del') {
            cover_delete_file($b['cover_file']);
            $pdo->prepare('UPDATE books SET cover_file = NULL, updated_at = ? WHERE id = ?')->execute(array(now(), $id));
            app_log('copertina_cambiata', '#' . $id . ' "' . $b['title'] . '": copertina tolta (dal pannello)');
            flash('Copertina tolta.');
            redirect($here . '&cop=1#copertina');
        }
        $res = array(false, '');
        if (isset($_FILES['cover']) && $_FILES['cover']['error'] !== UPLOAD_ERR_NO_FILE) {
            $res = cover_store_upload($_FILES['cover'], $id);
        } elseif (post('cover_url') !== '') {
            $res = cover_store_from_urls(array(post('cover_url')), $id, 'public');
        } elseif (post('cover_pick') !== '') {
            $res = cover_store_from_urls(array(post('cover_pick')), $id, 'trusted');
        }
        if ($res[0]) {
            app_log('copertina_cambiata', '#' . $id . ' "' . $b['title'] . '" (dal pannello)');
            flash('Copertina aggiornata.');
            redirect($here);
        }
        flash($res[1] !== '' ? $res[1] : 'Scegli una copertina trovata online, un\'immagine dal computer o un indirizzo.', 'error');
        redirect($here . '&cop=1#copertina');
    }

    /* ---------------- Libro: salvataggio dal pannello ---------------- */
    if ($a === 'book_save') {
        $id = (int)post('id');
        if (!book_get($id)) {
            redirect('gestione.php?sez=libri');
        }
        $f = book_fields_from_input($_POST);
        $err = book_validate($f);
        if ($err !== '') {
            flash($err, 'error');
            redirect('gestione.php?sez=libro&id=' . $id);
        }
        book_update($id, $f);
        book_extras_save($id, $_POST);
        app_log('libro_modificato', '#' . $id . ' "' . $f['title'] . '" (dal pannello)');
        $dup = books_with_isbn($f['isbn13'], $id);
        flash('Modifiche salvate.' . ($dup ? ' Attenzione: c\'è già un altro libro con lo stesso ISBN.' : ''), $dup ? 'warn' : 'success');
        redirect(post('next') === 'lista' ? admin_back('gestione.php?sez=libri') : 'gestione.php?sez=libro&id=' . $id);
    }

    /* ---------------- Generi: unione e inserimento multiplo ---------------- */
    if ($a === 'cat_merge') {
        $from = (int)post('id');
        $to = (int)post('target');
        if ($from && $to && $from !== $to && category_name($from) !== '' && category_name($to) !== '') {
            $name = category_name($from);
            $pdo->prepare('UPDATE books SET category_id = ? WHERE category_id = ?')->execute(array($to, $from));
            $pdo->prepare('UPDATE wheel_settings SET category_id = ? WHERE category_id = ?')->execute(array($to, $from));
            if (extras_ready()) {
                $pdo->prepare("UPDATE home_sections SET param = ? WHERE kind = 'category' AND param = ?")->execute(array((string)$to, (string)$from));
            }
            $pdo->prepare('DELETE FROM categories WHERE id = ?')->execute(array($from));
            app_log('genere_unito', '"' . $name . '" unito a "' . category_name($to) . '"', 'warn');
            flash('"' . $name . '" unito a "' . category_name($to) . '": i libri sono stati spostati.');
        } else {
            flash('Scegli il genere in cui unire.', 'error');
        }
        redirect('gestione.php?sez=generi');
    }
    if ($a === 'cat_bulk') {
        $added = 0;
        $order = (int)$pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM categories')->fetchColumn();
        foreach (admin_lines(post('names')) as $name) {
            try {
                $order += 10;
                $pdo->prepare('INSERT INTO categories (name, sort_order) VALUES (?, ?)')->execute(array($name, $order));
                $added++;
            } catch (PDOException $e) {
                // gia' presente
            }
        }
        app_log('genere_aggiunto', $added . ' generi aggiunti');
        flash($added ? $added . ' generi aggiunti.' : 'Nessun genere nuovo (erano già presenti).', $added ? 'success' : 'warn');
        redirect('gestione.php?sez=generi');
    }

    /* ---------------- Etichette ---------------- */
    if ($a === 'tax_add' || $a === 'tax_save') {
        $name = str_cut(trim(post('name')), 80);
        if ($name === '') {
            flash('Scrivi il nome dell\'etichetta.', 'error');
            redirect('gestione.php?sez=etichette');
        }
        if (str_fold($name) === 'genere' || str_fold($name) === 'generi') {
            flash('"Genere" esiste già: lo trovi in Etichette → Generi.', 'error');
            redirect('gestione.php?sez=etichette');
        }
        try {
            if ($a === 'tax_add') {
                $order = (int)$pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM taxonomies')->fetchColumn() + 10;
                $pdo->prepare('INSERT INTO taxonomies (name, multiple, in_filters, on_card, sort_order, created_at) VALUES (?,?,?,?,?,?)')
                    ->execute(array($name, admin_flag('multiple'), admin_flag('in_filters'), admin_flag('on_card'), $order, now()));
                $tid = (int)$pdo->lastInsertId();
                $order = 0;
                foreach (admin_lines(post('values')) as $v) {
                    $order += 10;
                    try {
                        $pdo->prepare('INSERT INTO terms (taxonomy_id, name, sort_order) VALUES (?,?,?)')->execute(array($tid, $v, $order));
                    } catch (PDOException $e) {
                        // doppione
                    }
                }
                app_log('etichetta_creata', '"' . $name . '"');
                flash('Etichetta "' . $name . '" creata. Ora compare nel modulo di ogni libro.');
                redirect('gestione.php?sez=etichetta&id=' . $tid);
            }
            $tid = (int)post('id');
            $pdo->prepare('UPDATE taxonomies SET name = ?, multiple = ?, in_filters = ?, on_card = ?, sort_order = ? WHERE id = ?')
                ->execute(array($name, admin_flag('multiple'), admin_flag('in_filters'), admin_flag('on_card'), (int)post('sort_order'), $tid));
            app_log('etichetta_modificata', '"' . $name . '"');
            flash('Etichetta salvata.');
        } catch (PDOException $e) {
            flash(admin_is_dup($e) ? 'Esiste già un\'etichetta con questo nome.' : $e->getMessage(), 'error');
        }
        redirect(admin_back('gestione.php?sez=etichette'));
    }
    if ($a === 'tax_del') {
        $t = taxonomy_get((int)post('id'));
        if ($t) {
            if (extras_ready()) {
                $pdo->prepare("DELETE FROM home_sections WHERE kind = 'term' AND param IN (SELECT CAST(id AS CHAR) FROM terms WHERE taxonomy_id = ?)")
                    ->execute(array((int)$t['id']));
            }
            $pdo->prepare('DELETE FROM taxonomies WHERE id = ?')->execute(array((int)$t['id']));
            app_log('etichetta_eliminata', '"' . $t['name'] . '"', 'warn');
            flash('Etichetta "' . $t['name'] . '" eliminata (i libri restano).');
        }
        redirect('gestione.php?sez=etichette');
    }

    /* ---------------- Valori delle etichette ---------------- */
    if (in_array($a, array('term_add', 'term_save', 'term_del', 'term_merge'), true)) {
        $tid = (int)post('taxonomy_id');
        $back = 'gestione.php?sez=etichetta&id=' . $tid;
        if (!taxonomy_get($tid)) {
            redirect('gestione.php?sez=etichette');
        }
        if ($a === 'term_add') {
            $added = 0;
            $order = (int)$pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM terms WHERE taxonomy_id = ' . $tid)->fetchColumn();
            foreach (admin_lines(post('names')) as $name) {
                try {
                    $order += 10;
                    $pdo->prepare('INSERT INTO terms (taxonomy_id, name, sort_order) VALUES (?,?,?)')->execute(array($tid, $name, $order));
                    $added++;
                } catch (PDOException $e) {
                    // doppione
                }
            }
            flash($added ? $added . ' valori aggiunti.' : 'Nessun valore nuovo (erano già presenti).', $added ? 'success' : 'warn');
            redirect($back);
        }
        $term = term_get((int)post('id'));
        if (!$term || (int)$term['taxonomy_id'] !== $tid) {
            redirect($back);
        }
        if ($a === 'term_save') {
            $name = str_cut(trim(post('name')), 100);
            try {
                if ($name !== '') {
                    $pdo->prepare('UPDATE terms SET name = ?, sort_order = ? WHERE id = ?')->execute(array($name, (int)post('sort_order'), (int)$term['id']));
                    flash('Valore aggiornato.');
                }
            } catch (PDOException $e) {
                flash('Esiste già un valore con questo nome.', 'error');
            }
        } elseif ($a === 'term_del') {
            $pdo->prepare("DELETE FROM home_sections WHERE kind = 'term' AND param = ?")->execute(array((string)$term['id']));
            $pdo->prepare('DELETE FROM terms WHERE id = ?')->execute(array((int)$term['id']));
            app_log('etichetta_valore_eliminato', $term['taxonomy_name'] . ': "' . $term['name'] . '"', 'warn');
            flash('Valore "' . $term['name'] . '" eliminato (i libri restano).');
        } elseif ($a === 'term_merge') {
            $target = term_get((int)post('target'));
            if (!$target || (int)$target['taxonomy_id'] !== $tid || (int)$target['id'] === (int)$term['id']) {
                flash('Scegli il valore in cui unire.', 'error');
                redirect($back);
            }
            $st = $pdo->prepare('SELECT book_id FROM book_terms WHERE term_id = ?');
            $st->execute(array((int)$term['id']));
            $has = $pdo->prepare('SELECT COUNT(*) FROM book_terms WHERE book_id = ? AND term_id = ?');
            $ins = $pdo->prepare('INSERT INTO book_terms (book_id, term_id) VALUES (?, ?)');
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $bid) {
                $has->execute(array($bid, (int)$target['id']));
                if (!(int)$has->fetchColumn()) {
                    $ins->execute(array($bid, (int)$target['id']));
                }
            }
            $pdo->prepare("UPDATE home_sections SET param = ? WHERE kind = 'term' AND param = ?")->execute(array((string)$target['id'], (string)$term['id']));
            $pdo->prepare('DELETE FROM terms WHERE id = ?')->execute(array((int)$term['id']));
            app_log('etichetta_valori_uniti', $term['taxonomy_name'] . ': "' . $term['name'] . '" → "' . $target['name'] . '"', 'warn');
            flash('"' . $term['name'] . '" unito a "' . $target['name'] . '".');
        }
        redirect($back);
    }

    /* ---------------- Campi personalizzati ---------------- */
    if ($a === 'field_add' || $a === 'field_save') {
        $name = str_cut(trim(post('name')), 80);
        $type = post('type');
        $types = custom_field_types();
        if ($name === '' || !isset($types[$type])) {
            flash('Scrivi il nome e scegli il tipo del campo.', 'error');
            redirect('gestione.php?sez=campi');
        }
        $options = $type === 'select' ? implode("\n", admin_lines(post('options'), 100)) : null;
        if ($type === 'select' && $options === '') {
            flash('Per un elenco a scelta scrivi le voci, una per riga.', 'error');
            redirect('gestione.php?sez=campi');
        }
        try {
            if ($a === 'field_add') {
                $order = (int)$pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM custom_fields')->fetchColumn() + 10;
                $pdo->prepare('INSERT INTO custom_fields (name, type, options, on_card, in_csv, sort_order, created_at) VALUES (?,?,?,?,?,?,?)')
                    ->execute(array($name, $type, $options, admin_flag('on_card'), admin_flag('in_csv'), $order, now()));
                app_log('campo_creato', '"' . $name . '" (' . $types[$type] . ')');
                flash('Campo "' . $name . '" creato: lo trovi nel modulo di ogni libro.');
            } else {
                $pdo->prepare('UPDATE custom_fields SET name = ?, type = ?, options = ?, on_card = ?, in_csv = ?, sort_order = ? WHERE id = ?')
                    ->execute(array($name, $type, $options, admin_flag('on_card'), admin_flag('in_csv'), (int)post('sort_order'), (int)post('id')));
                app_log('campo_modificato', '"' . $name . '"');
                flash('Campo salvato.');
            }
        } catch (PDOException $e) {
            flash(admin_is_dup($e) ? 'Esiste già un campo con questo nome.' : $e->getMessage(), 'error');
        }
        redirect('gestione.php?sez=campi');
    }
    if ($a === 'field_del') {
        $fields = custom_fields_all();
        $fid = (int)post('id');
        if (isset($fields[$fid])) {
            $pdo->prepare('DELETE FROM custom_fields WHERE id = ?')->execute(array($fid));
            app_log('campo_eliminato', '"' . $fields[$fid]['name'] . '"', 'warn');
            flash('Campo "' . $fields[$fid]['name'] . '" eliminato con tutti i suoi valori.');
        }
        redirect('gestione.php?sez=campi');
    }

    /* ---------------- Stelle sotto le copertine (Admin e Gestore) ---------------- */
    if ($a === 'lib_stars_save') {
        $v = post('lib_stars');
        if (isset(setting_defaults()['lib_stars'][4][$v])) {
            setting_save('lib_stars', $v);
            app_log('impostazioni', 'Stelle sotto le copertine: ' . setting_defaults()['lib_stars'][4][$v]);
            flash($v === 'off' ? 'Stelle nascoste nella libreria.' : 'Stelle sotto le copertine aggiornate.');
        }
        redirect('gestione.php?sez=home');
    }

    /* ---------------- Righe della pagina iniziale ---------------- */
    if (in_array($a, array('sec_add', 'sec_save', 'sec_move', 'sec_del'), true)) {
        $kinds = home_section_kinds();
        $clean_param = function ($kind, $raw) use ($kinds) {
            $need = $kinds[$kind][1];
            if ($need === 'category') {
                return category_name((int)$raw) !== '' ? (string)(int)$raw : null;
            }
            if ($need === 'term') {
                return term_get((int)$raw) ? (string)(int)$raw : null;
            }
            if ($need === 'status') {
                return isset(reading_statuses()[$raw]) ? $raw : null;
            }
            if ($need === 'number') {
                return (int)$raw > 0 ? (string)(int)$raw : null;
            }
            return '';
        };
        if ($a === 'sec_add') {
            $kind = post('kind');
            if (!isset($kinds[$kind])) {
                redirect('gestione.php?sez=home');
            }
            $praw = post('param_' . $kinds[$kind][1]);
            $param = $clean_param($kind, $praw);
            if ($param === null) {
                flash('Completa la scelta per questo tipo di riga.', 'error');
                redirect('gestione.php?sez=home');
            }
            if ($kind === 'authors' && (int)$pdo->query("SELECT COUNT(*) FROM home_sections WHERE kind = 'authors'")->fetchColumn() > 0) {
                flash('La riga "Tutti i libri per autore" c\'è già: puoi attivarla o spostarla.', 'warn');
                redirect('gestione.php?sez=home');
            }
            $title = str_cut(trim(post('title')), 100);
            if ($title === '') {
                $title = $kinds[$kind][2] !== '' ? $kinds[$kind][2] : home_section_describe(array('kind' => $kind, 'param' => $param));
                if ($kind === 'category') {
                    $title = category_name((int)$param);
                } elseif ($kind === 'term') {
                    $tt = term_get((int)$param);
                    $title = $tt['name'];
                } elseif ($kind === 'status') {
                    $title = status_label($param);
                }
            }
            $order = (int)$pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM home_sections')->fetchColumn() + 10;
            $pdo->prepare('INSERT INTO home_sections (title, kind, param, max_items, active, sort_order) VALUES (?,?,?,?,1,?)')
                ->execute(array($title, $kind, $param === '' ? null : $param, max(1, min(30, (int)post('max_items', '12'))), $order));
            app_log('home_riga_aggiunta', '"' . $title . '"');
            flash('Riga "' . $title . '" aggiunta in fondo alla pagina iniziale.');
            redirect('gestione.php?sez=home');
        }
        $id = (int)post('id');
        $st = $pdo->prepare('SELECT * FROM home_sections WHERE id = ?');
        $st->execute(array($id));
        $sec = $st->fetch();
        if (!$sec) {
            redirect('gestione.php?sez=home');
        }
        if ($a === 'sec_save') {
            $title = str_cut(trim(post('title')), 100);
            $param = $sec['param'];
            $need = isset($kinds[$sec['kind']]) ? $kinds[$sec['kind']][1] : '';
            if ($need !== '' && isset($_POST['param'])) {
                $p = $clean_param($sec['kind'], post('param'));
                if ($p !== null) {
                    $param = $p;
                }
            }
            $pdo->prepare('UPDATE home_sections SET title = ?, param = ?, max_items = ?, active = ? WHERE id = ?')
                ->execute(array($title !== '' ? $title : $sec['title'], $param, max(1, min(30, (int)post('max_items', '12'))), admin_flag('active'), $id));
            flash('Riga salvata.');
        } elseif ($a === 'sec_del') {
            $pdo->prepare('DELETE FROM home_sections WHERE id = ?')->execute(array($id));
            app_log('home_riga_eliminata', '"' . $sec['title'] . '"');
            flash('Riga "' . $sec['title'] . '" eliminata.');
        } elseif ($a === 'sec_move') {
            $rows = $pdo->query('SELECT id FROM home_sections ORDER BY sort_order, id')->fetchAll(PDO::FETCH_COLUMN);
            $rows = array_map('intval', $rows);
            $i = array_search($id, $rows, true);
            $j = $i + (post('dir') === 'up' ? -1 : 1);
            if ($i !== false && $j >= 0 && $j < count($rows)) {
                $tmp = $rows[$i];
                $rows[$i] = $rows[$j];
                $rows[$j] = $tmp;
            }
            $upd = $pdo->prepare('UPDATE home_sections SET sort_order = ? WHERE id = ?');
            foreach ($rows as $k => $rid) {
                $upd->execute(array(($k + 1) * 10, $rid));
            }
        }
        redirect('gestione.php?sez=home');
    }

    /* ---------------- Pagine ---------------- */
    if ($a === 'page_save') {
        $id = (int)post('id');
        $title = str_cut(trim(post('title')), 150);
        if ($title === '') {
            flash('Il titolo della pagina è obbligatorio.', 'error');
            redirect('gestione.php?sez=pagina' . ($id ? '&id=' . $id : ''));
        }
        $slug = slugify(post('slug') !== '' ? post('slug') : $title);
        // indirizzo unico
        $base = $slug;
        $n = 2;
        while (true) {
            $st = $pdo->prepare('SELECT id FROM pages WHERE slug = ? AND id <> ?');
            $st->execute(array($slug, $id));
            if (!$st->fetchColumn()) {
                break;
            }
            $slug = $base . '-' . $n++;
        }
        $body = str_cut(isset($_POST['body']) ? (string)$_POST['body'] : '', 60000);
        $cols = array('slug' => $slug, 'title' => $title, 'body' => $body, 'in_menu' => admin_flag('in_menu'), 'guests' => admin_flag('guests'),
            'active' => admin_flag('active'), 'sort_order' => (int)post('sort_order'), 'updated_at' => now());
        if (pages_v4()) {
            $cols['format'] = post('format') === 'html' ? 'html' : 'md';
            $cols['show_title'] = admin_flag('show_title');
            if (is_admin() && isset($_POST['css'])) {
                $cols['css'] = page_css_clean($_POST['css']); // lo stile e' "aspetto": solo l'Admin
            }
        }
        if ($id) {
            $set = implode(' = ?, ', array_keys($cols)) . ' = ?';
            $pdo->prepare('UPDATE pages SET ' . $set . ' WHERE id = ?')->execute(array_merge(array_values($cols), array($id)));
        } else {
            $pdo->prepare('INSERT INTO pages (' . implode(',', array_keys($cols)) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')')
                ->execute(array_values($cols));
            $id = (int)$pdo->lastInsertId();
        }
        app_log('pagina_salvata', '"' . $title . '" (' . $slug . ')');
        flash('Pagina salvata.' . (admin_flag('active') ? '' : ' Non è ancora pubblicata.'));
        redirect('gestione.php?sez=pagina&id=' . $id);
    }
    if ($a === 'page_image') {
        $back = admin_back('gestione.php?sez=pagine');
        if (!isset($_FILES['image']) || $_FILES['image']['error'] === UPLOAD_ERR_NO_FILE) {
            flash('Scegli un\'immagine.', 'error');
            redirect($back);
        }
        $r = store_upload_image($_FILES['image'], 'pagina', 1600);
        if ($r[0]) {
            app_log('immagine_pagina', $r[1]);
            flash('Immagine caricata: premi "Inserisci" accanto all\'anteprima per metterla nel testo.');
        } else {
            flash($r[1], 'error');
        }
        redirect($back);
    }
    if ($a === 'page_del') {
        $st = $pdo->prepare('SELECT title FROM pages WHERE id = ?');
        $st->execute(array((int)post('id')));
        $t = $st->fetchColumn();
        if ($t !== false) {
            $pdo->prepare('DELETE FROM pages WHERE id = ?')->execute(array((int)post('id')));
            app_log('pagina_eliminata', '"' . $t . '"', 'warn');
            flash('Pagina "' . $t . '" eliminata.');
        }
        redirect('gestione.php?sez=pagine');
    }

    /* ---------------- Copertine: file non usati ---------------- */
    if ($a === 'covers_cleanup') {
        $used = array();
        foreach ($pdo->query("SELECT cover_file FROM books WHERE cover_file IS NOT NULL AND cover_file <> ''")->fetchAll(PDO::FETCH_COLUMN) as $f) {
            $used[$f] = 1;
        }
        $n = 0;
        $size = 0;
        foreach ((is_dir(COVERS_DIR) ? scandir(COVERS_DIR) : array()) as $f) {
            if (preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $f) && !isset($used[$f])) {
                $size += filesize(COVERS_DIR . '/' . $f);
                if (@unlink(COVERS_DIR . '/' . $f)) {
                    $n++;
                }
            }
        }
        app_log('copertine_pulite', $n . ' file non usati eliminati');
        flash($n ? $n . ' immagini non più usate eliminate (' . fmt_bytes($size) . ' liberati).' : 'Non c\'erano immagini da eliminare.');
        redirect('gestione.php?sez=copertine');
    }

    /* ---------------- Utenti: disconnessione forzata (solo Admin) ---------------- */
    if ($a === 'user_logout_all') {
        if (!is_admin() && (int)post('id') !== current_uid()) {
            deny_page('Operazione non consentita.');
        }
        $st = $pdo->prepare('SELECT username FROM users WHERE id = ?');
        $st->execute(array((int)post('id')));
        $un = $st->fetchColumn();
        if ($un !== false) {
            try {
                $pdo->prepare('UPDATE users SET session_version = session_version + 1 WHERE id = ?')->execute(array((int)post('id')));
                if ((int)setting('db_version', '1') >= 13) {
                    // anche i dispositivi ricordati: altrimenti rientrerebbero da soli
                    $pdo->prepare('DELETE FROM user_devices WHERE user_id = ?')->execute(array((int)post('id')));
                }
                app_log('sessioni_chiuse', 'Disconnesso "' . $un . '" da tutti i dispositivi', 'warn');
                flash('"' . $un . '" è stato disconnesso da tutti i dispositivi.');
            } catch (PDOException $e) {
                flash('Funzione disponibile dopo l\'aggiornamento del database.', 'error');
            }
        }
        redirect((int)post('id') === current_uid() ? 'index.php' : 'gestione.php?sez=utenti');
    }

    /* ---------------- Prestiti ---------------- */
    if (in_array($a, array('loan_add', 'loan_return', 'loan_extend', 'loan_del'), true)) {
        if (!v12_ready()) {
            flash('Il database non è ancora aggiornato.', 'error');
            redirect('gestione.php?sez=prestiti');
        }
        if ($a === 'loan_add') {
            $bid = (int)post('book_id');
            if (!$bid && preg_match('/\[#(\d+)\]\s*$/', post('book'), $m)) {
                $bid = (int)$m[1]; // scelto dall'elenco: "Titolo — Autore [#12]"
            }
            $err = $bid ? loan_create($bid, post('borrower'), post('contact'), post('lent_at'), post('due_at'), post('notes')) : 'Scegli il libro dall\'elenco che compare mentre scrivi.';
            if ($err === '') {
                $b = book_get($bid);
                app_log('prestito', '"' . $b['title'] . '" prestato a ' . post('borrower'));
                flash('Prestito registrato: "' . $b['title'] . '" a ' . post('borrower') . '.');
            } else {
                flash($err, 'error');
            }
            redirect('gestione.php?sez=prestiti');
        }
        $l = loan_get((int)post('id'));
        if (!$l) {
            redirect('gestione.php?sez=prestiti');
        }
        if ($a === 'loan_return') {
            $d = loan_date(post('date')) !== '' ? loan_date(post('date')) : date('Y-m-d');
            $pdo->prepare('UPDATE loans SET returned_at = ? WHERE id = ?')->execute(array($d, (int)$l['id']));
            app_log('prestito_restituito', '"' . $l['title'] . '" da ' . $l['borrower']);
            flash('"' . $l['title'] . '" segnato come restituito.');
        } elseif ($a === 'loan_extend') {
            $d = loan_date(post('due_at'));
            $pdo->prepare('UPDATE loans SET due_at = ? WHERE id = ?')->execute(array($d !== '' ? $d : null, (int)$l['id']));
            flash($d !== '' ? 'Nuova scadenza: ' . date('d/m/Y', strtotime($d)) . '.' : 'Scadenza tolta.');
        } elseif ($a === 'loan_del') {
            $pdo->prepare('DELETE FROM loans WHERE id = ?')->execute(array((int)$l['id']));
            app_log('prestito_eliminato', '"' . $l['title'] . '" a ' . $l['borrower'], 'warn');
            flash('Prestito eliminato dallo storico.');
        }
        redirect(admin_back('gestione.php?sez=prestiti'));
    }

    /* ---------------- Cestino ---------------- */
    if (in_array($a, array('trash_restore', 'trash_purge', 'trash_empty', 'trash_days'), true)) {
        if (!v12_ready()) {
            redirect('gestione.php?sez=cestino');
        }
        if ($a === 'trash_restore') {
            $r = trash_restore((int)post('id'));
            if (is_int($r)) {
                $b = book_get($r);
                app_log('libro_ripristinato', '#' . $r . ' "' . $b['title'] . '" dal cestino', 'warn');
                flash('"' . $b['title'] . '" è tornato in libreria.');
            } else {
                flash($r, 'error');
            }
        } elseif ($a === 'trash_purge') {
            if (trash_purge((int)post('id'))) {
                app_log('cestino', 'Un libro eliminato definitivamente', 'warn');
                flash('Libro eliminato definitivamente.');
            }
        } elseif ($a === 'trash_empty') {
            $n = 0;
            foreach (trash_list() as $t) {
                if (trash_purge($t['id'])) {
                    $n++;
                }
            }
            app_log('cestino_svuotato', $n . ' libri eliminati definitivamente', 'warn');
            flash('Cestino svuotato: ' . $n . ' libri eliminati definitivamente.');
        } elseif ($a === 'trash_days') {
            setting_save('trash_days', (string)max(1, min(365, (int)post('days'))));
            flash('Il cestino ora si svuota da solo dopo ' . trash_days() . ' giorni.');
        }
        redirect('gestione.php?sez=cestino');
    }

    /* ---------------- Doppioni ---------------- */
    if ($a === 'dup_merge' || $a === 'dup_ignore') {
        if ($a === 'dup_ignore') {
            $key = post('key');
            if (preg_match('/^[it]:[\d,]+$/', $key)) {
                $list = dup_ignored();
                $list[] = $key;
                setting_save('dup_ignore', json_encode(array_values(array_unique($list))));
                flash('Va bene: questo gruppo non verrà più proposto.');
            }
            redirect('gestione.php?sez=doppioni');
        }
        $keep = (int)post('keep');
        $ids = array_values(array_filter(array_map('intval', (array)(isset($_POST['ids']) ? $_POST['ids'] : array()))));
        if (!$keep || !in_array($keep, $ids, true) || count($ids) < 2) {
            flash('Scegli quale libro tenere.', 'error');
            redirect('gestione.php?sez=doppioni');
        }
        $kb = book_get($keep);
        $n = dup_merge($keep, $ids);
        app_log('doppioni_uniti', '"' . $kb['title'] . '" (#' . $keep . '): ' . $n . ' copie unite e spostate nel cestino', 'warn');
        flash('Uniti in "' . $kb['title'] . '": ' . $n . ($n === 1 ? ' copia spostata' : ' copie spostate') . ' nel cestino, i dati mancanti sono stati completati.');
        redirect('gestione.php?sez=doppioni');
    }

    /* ---------------- Backup automatici ---------------- */
    if ($a === 'autobackup_save') {
        $mode = post('auto_backup');
        $old_mode = setting('auto_backup', 'off');
        if (isset(auto_backup_options()[$mode])) {
            setting_save('auto_backup', $mode);
        }
        setting_save('auto_backup_keep', (string)max(1, min(30, (int)post('auto_backup_keep', '5'))));
        setting_save('auto_backup_hour', (string)max(0, min(23, (int)post('auto_backup_hour', '3'))));
        setting_save('auto_backup_weekday', (string)max(1, min(7, (int)post('auto_backup_weekday', '7'))));
        setting_save('auto_backup_monthday', (string)max(1, min(28, (int)post('auto_backup_monthday', '1'))));
        if ($old_mode !== $mode) {
            setting_save('auto_backup_last', (string)time()); // cambiando frequenza si riparte dalla prossima scadenza
        }
        if (is_admin()) {
            setting_save('auto_backup_full', post('auto_backup_full') === '1' ? '1' : '0');
        }
        load_settings(true);
        app_log('impostazioni', 'Backup automatici: ' . auto_backup_options()[setting('auto_backup', 'off')]);
        flash('Backup automatici: ' . strtolower(auto_backup_options()[setting('auto_backup', 'off')]) . '.');
        redirect('gestione.php?sez=dati');
    }

    /* ---------------- Media e cartelle ---------------- */
    if (in_array($a, array('media_upload', 'media_save', 'media_del', 'media_bulk', 'mfolder_add', 'mfolder_rename', 'mfolder_del'), true)) {
        require_once dirname(__FILE__) . '/media.php';
        if (!media_ready()) {
            redirect('gestione.php?sez=media');
        }
        $back = preg_match('#^gestione\.php\?sez=media[A-Za-z0-9_=&%+.\-]*$#', post('back')) ? post('back') : 'gestione.php?sez=media';
        if ($a === 'media_upload') {
            $ok = 0;
            $errs = array();
            $fd = (int)post('folder_id');
            $files = isset($_FILES['files']) ? $_FILES['files'] : null;
            if ($files && is_array($files['name'])) {
                foreach ($files['name'] as $i => $nm) {
                    if ($files['error'][$i] === UPLOAD_ERR_NO_FILE) {
                        continue;
                    }
                    $r = media_store(array('name' => $nm, 'tmp_name' => $files['tmp_name'][$i], 'error' => $files['error'][$i], 'size' => $files['size'][$i]), $fd);
                    if ($r[0]) {
                        $ok++;
                        $last = $r[1];
                    } else {
                        $errs[] = $r[1];
                    }
                }
            }
            if (!$ok && !$errs) {
                $errs[] = empty($_FILES) && !empty($_SERVER['CONTENT_LENGTH']) ? 'I file superano il limite del server.' : 'Scegli almeno un file.';
            }
            if ($ok) {
                app_log('media_caricati', $ok . ' file caricati in Media');
            }
            flash(($ok ? ($ok === 1 ? '1 file caricato.' : $ok . ' file caricati.') : '') . ($errs ? ' Non caricati: ' . implode(' ', array_slice($errs, 0, 5)) : ''), $errs ? ($ok ? 'warn' : 'error') : 'success');
            redirect($back . ($ok === 1 ? '&file=' . $last . '#dettaglio' : ''));
        }
        if ($a === 'media_save') {
            $m = media_get((int)post('id'));
            if ($m) {
                $fd = (int)post('folder_id');
                $pdo->prepare('UPDATE media_files SET title = ?, alt = ?, folder_id = ? WHERE id = ?')->execute(array(
                    str_cut(trim(post('title')) !== '' ? trim(post('title')) : $m['title'], 150), str_cut(trim(post('alt')), 250),
                    $fd && media_folder_get($fd) ? $fd : null, (int)$m['id']));
                flash('File aggiornato.');
            }
            redirect($back);
        }
        if ($a === 'media_del') {
            $m = media_get((int)post('id'));
            if ($m && media_delete($m['id'])) {
                app_log('media_eliminato', '"' . $m['title'] . '" (' . $m['filename'] . ')', 'warn');
                flash('"' . $m['title'] . '" eliminato.');
            }
            redirect($back);
        }
        if ($a === 'media_bulk') {
            $ids = array_values(array_unique(array_filter(array_map('intval', (array)(isset($_POST['ids']) ? $_POST['ids'] : array())))));
            if (!$ids) {
                flash('Seleziona almeno un file.', 'warn');
                redirect($back);
            }
            if (post('op') === 'delete') {
                foreach ($ids as $id) {
                    media_delete($id);
                }
                app_log('media_eliminato', count($ids) . ' file eliminati', 'warn');
                flash(count($ids) === 1 ? '1 file eliminato.' : count($ids) . ' file eliminati.');
            } else {
                $fd = (int)post('folder_id');
                $f = $fd ? media_folder_get($fd) : null;
                $pdo->prepare('UPDATE media_files SET folder_id = ? WHERE id IN (' . implode(',', $ids) . ')')->execute(array($f ? (int)$f['id'] : null));
                flash(count($ids) . ' file spostati in "' . ($f ? $f['name'] : 'Senza cartella') . '".');
            }
            redirect($back);
        }
        if ($a === 'mfolder_add' || $a === 'mfolder_rename') {
            $name = media_folder_name_ok(post('name'));
            if ($name === '') {
                flash('Scrivi il nome della cartella.', 'error');
                redirect($back);
            }
            $dup = $pdo->prepare('SELECT id FROM media_folders WHERE LOWER(name) = LOWER(?) AND id <> ?');
            $dup->execute(array($name, $a === 'mfolder_rename' ? (int)post('id') : 0));
            if ($dup->fetchColumn()) {
                flash('Esiste già una cartella "' . $name . '".', 'error');
                redirect($back);
            }
            if ($a === 'mfolder_add') {
                $ord = (int)$pdo->query('SELECT COALESCE(MAX(sort_order),0) FROM media_folders')->fetchColumn() + 1;
                $pdo->prepare('INSERT INTO media_folders (name, sort_order, created_at) VALUES (?,?,?)')->execute(array($name, $ord, now()));
                flash('Cartella "' . $name . '" creata.');
                redirect('gestione.php?sez=media&cartella=' . (int)$pdo->lastInsertId());
            }
            $f = media_folder_get((int)post('id'));
            if ($f) {
                $pdo->prepare('UPDATE media_folders SET name = ? WHERE id = ?')->execute(array($name, (int)$f['id']));
                flash('Cartella rinominata in "' . $name . '".');
            }
            redirect($back);
        }
        if ($a === 'mfolder_del') {
            $f = media_folder_get((int)post('id'));
            if ($f) {
                $to = (int)post('move_to');
                $to = $to && $to !== (int)$f['id'] && media_folder_get($to) ? $to : null;
                $pdo->prepare('UPDATE media_files SET folder_id = ? WHERE folder_id = ?')->execute(array($to, (int)$f['id']));
                $pdo->prepare('DELETE FROM media_folders WHERE id = ?')->execute(array((int)$f['id']));
                flash('Cartella "' . $f['name'] . '" eliminata; i suoi file sono in "' . ($to ? media_folder_get($to)['name'] : 'Senza cartella') . '".');
            }
            redirect('gestione.php?sez=media');
        }
    }

    /* ---------------- Firewall (solo Admin) ---------------- */
    if (strpos($a, 'fw_') === 0) {
        if (!is_admin()) {
            app_log('accesso_negato', 'Tentativo di modificare il firewall', 'alert');
            deny_page('Operazione non consentita.');
        }
        if (!fw_ready()) {
            redirect('gestione.php?sez=firewall');
        }
        fw_handle_post($a);
    }

    /* ---------------- Destinazioni dei backup (solo Admin: contengono credenziali) ---------------- */
    if (strpos($a, 'rt_') === 0) {
        if (!is_admin()) {
            app_log('accesso_negato', 'Tentativo di gestire le destinazioni dei backup', 'alert');
            deny_page('Operazione non consentita.');
        }
        require_once dirname(__FILE__) . '/remote_backup.php';
        require_once dirname(__FILE__) . '/data_tools.php';
        $id = (int)post('id');
        $back = 'gestione.php?sez=destinazioni' . ($id ? '&id=' . $id : '');
        if (!rb_ready()) {
            redirect($back);
        }
        if ($a === 'rt_save') {
            $types = rb_types();
            $type = post('type');
            $old = $id ? rb_target($id) : null;
            if ($old) {
                $type = $old['type'];
            }
            if (!isset($types[$type])) {
                redirect('gestione.php?sez=destinazioni');
            }
            $fields = array('folder' => array('path'), 'sftp' => array('host', 'port', 'dir', 'user', 'pass', 'key', 'passphrase', 'fingerprint'),
                'ftp' => array('host', 'port', 'dir', 'user', 'pass'), 'ftpes' => array('host', 'port', 'dir', 'user', 'pass', 'insecure'),
                'webdav' => array('url', 'user', 'pass', 'insecure'), 'gdrive' => array('client_id', 'client_secret', 'folder'),
                'dropbox' => array('app_key', 'app_secret', 'folder'));
            $in = isset($_POST['cfg']) && is_array($_POST['cfg']) ? $_POST['cfg'] : array();
            $cfg = $old ? $old['cfg'] : array();
            foreach ($fields[$type] as $k) {
                $v = isset($in[$k]) && is_string($in[$k]) ? ($k === 'key' ? trim($in[$k]) . "\n" : trim($in[$k])) : '';
                if ($k === 'insecure') {
                    $cfg[$k] = $v === '1' ? '1' : '0';
                } elseif (in_array($k, rb_secret_fields(), true)) {
                    if (trim($v) !== '') {
                        $cfg[$k] = rb_encrypt($v); // vuoto = si tiene quella salvata
                    }
                } else {
                    $cfg[$k] = str_cut($v, 500);
                }
            }
            if ($old && $type === 'gdrive' && isset($old['cfg']['client_id']) && $old['cfg']['client_id'] !== $cfg['client_id']) {
                unset($cfg['refresh_token'], $cfg['folder_id'], $cfg['account']); // altro client: va ricollegato
            }
            $name = str_cut(trim(post('name')), 80);
            if ($name === '') {
                $name = $types[$type];
            }
            if ($old) {
                $pdo->prepare('UPDATE backup_targets SET name = ?, config = ?, active = ?, send_full = ? WHERE id = ?')
                    ->execute(array($name, json_encode($cfg), admin_flag('active'), admin_flag('send_full'), $id));
            } else {
                $pdo->prepare('INSERT INTO backup_targets (name, type, config, active, send_full, created_at) VALUES (?,?,?,?,?,?)')
                    ->execute(array($name, $type, json_encode($cfg), admin_flag('active'), admin_flag('send_full'), now()));
                $id = (int)$pdo->lastInsertId();
            }
            app_log('destinazione_backup', 'Salvata "' . $name . '" (' . $types[$type] . ')', 'warn');
            flash('Destinazione salvata.' . (in_array($type, array('gdrive', 'dropbox'), true) && empty($cfg['refresh_token'])
                ? ' Ora collega l\'account con il pulsante a destra.' : ' Premi "Prova" per verificare il collegamento.'));
            redirect('gestione.php?sez=destinazioni&id=' . $id);
        }
        $t = rb_target($id);
        if (!$t) {
            redirect('gestione.php?sez=destinazioni');
        }
        try {
            if ($a === 'rt_del') {
                $pdo->prepare('DELETE FROM backup_targets WHERE id = ?')->execute(array($id));
                app_log('destinazione_backup', 'Eliminata "' . $t['name'] . '"', 'warn');
                flash('Destinazione eliminata.');
                redirect('gestione.php?sez=destinazioni');
            } elseif ($a === 'rt_test') {
                $n = rb_test($t);
                rb_set_status($id, true, 'Prova riuscita' . ($n ? ' · ' . $n . ' backup già presenti' : ''));
                flash('"' . $t['name'] . '": collegamento riuscito, il file di prova è stato scritto, ritrovato e cancellato.');
            } elseif ($a === 'rt_send') {
                $latest = '';
                foreach (backup_list() as $b) {
                    if (strpos($b['name'], '_prova') === false) {
                        $latest = $b['name'];
                        break;
                    }
                }
                if ($latest === '') {
                    throw new Exception('Non c\'è ancora nessun backup da inviare.');
                }
                if (strpos($latest, 'completo') !== false && !(int)$t['send_full']) {
                    throw new Exception('L\'ultimo backup è completo (contiene gli account) e questa destinazione non li accetta.');
                }
                $rm = rb_send($t, $latest, max(1, (int)setting('auto_backup_keep', '5')));
                rb_set_status($id, true, 'Inviato ' . $latest . ($rm ? ' · eliminati ' . $rm . ' backup più vecchi' : ''));
                app_log('backup_inviato', $t['name'] . ': ' . $latest);
                flash('Inviato ' . $latest . ' a "' . $t['name'] . '".');
            } elseif ($a === 'rt_gdrive_start') {
                rb_gdrive_start($t);
            } elseif ($a === 'rt_gdrive_finish') {
                rb_gdrive_finish($t);
                app_log('destinazione_backup', 'Google Drive collegato a "' . $t['name'] . '"', 'warn');
                flash('Account Google collegato. Premi "Prova" per verificare.');
            } elseif ($a === 'rt_dropbox_finish') {
                rb_dropbox_finish($t, post('code'));
                app_log('destinazione_backup', 'Dropbox collegato a "' . $t['name'] . '"', 'warn');
                flash('Account Dropbox collegato. Premi "Prova" per verificare.');
            }
        } catch (Exception $e) {
            rb_cleanup_tmp();
            if ($a === 'rt_test' || $a === 'rt_send') {
                rb_set_status($id, false, $e->getMessage());
            }
            flash('"' . $t['name'] . '": ' . $e->getMessage(), 'error');
        }
        redirect(in_array($a, array('rt_test', 'rt_send'), true) ? 'gestione.php?sez=destinazioni' : 'gestione.php?sez=destinazioni&id=' . $id);
    }

    /* ---------------- Repository, chiave dell'autore e officina (solo Admin, 1.9.8) ---------------- */
    if (preg_match('/^(repo_|key_|pub_)/', $a) || $a === 'plg_repo_install') {
        if (!is_admin()) {
            app_log('accesso_negato', 'Tentativo di usare repository o chiave da utente non Admin', 'alert');
            deny_page('Operazione non consentita.');
        }
        require_once dirname(__FILE__) . '/repo_actions.php';
        repo_handle_post($a);
    }

    /* ---------------- Aggiornamento e manutenzione (solo Admin) ---------------- */
    if (in_array($a, array('upd_upload', 'upd_apply', 'upd_cancel', 'upd_rollback', 'maint_on', 'maint_off'), true)) {
        if (!is_admin()) {
            app_log('accesso_negato', 'Tentativo di aggiornamento da utente non Admin', 'alert');
            deny_page('Operazione non consentita.');
        }
        require_once dirname(__FILE__) . '/updater.php';
        updater_handle_post($a);
    }
}

/* Azioni del firewall: ogni ramo termina con un redirect */
function fw_handle_post($a)
{
    $me = fw_client();
    if ($a === 'fw_save') {
        $defs = setting_defaults();
        $new = array();
        foreach (array('fw_proxy', 'fw_enabled', 'fw_lan_allow', 'fw_escalate', 'fw_permanent', 'fw_honeypot', 'fw_cf_only', 'fw_geo_tor') as $k) {
            $new[$k] = post($k) === '1' ? '1' : '0';
        }
        $new['fw_unknown_max'] = (string)max(0, min(50, (int)post('fw_unknown_max')));
        $new['fw_siege'] = (string)max(0, min(100000, (int)post('fw_siege')));
        $new['fw_events_days'] = (string)max(7, min(3650, (int)post('fw_events_days')));
        foreach (array('fw_geo_mode', 'fw_geo_scope', 'fw_geo_unknown') as $k) {
            $v = post($k);
            $new[$k] = isset($defs[$k][4][$v]) ? $v : $defs[$k][2];
        }
        // IP sempre consentiti: solo regole valide
        $rules = array();
        $bad = array();
        foreach (fw_lines(post('fw_whitelist')) as $r) {
            if (fw_rule_valid($r)) {
                $rules[] = $r;
            } else {
                $bad[] = $r;
            }
        }
        if (post('add_me') === '1' && $me['ip'] !== '' && !in_array($me['ip'], $rules, true)) {
            $rules[] = $me['ip'];
        }
        $new['fw_whitelist'] = implode("\n", array_unique($rules));
        $names = array();
        foreach (fw_lines(post('fw_banned_names')) as $n) {
            $names[] = str_cut(strtolower($n), 60);
        }
        $new['fw_banned_names'] = implode("\n", array_unique($names));
        $codes = array();
        $all = fw_countries();
        foreach ((array)(isset($_POST['geo']) ? $_POST['geo'] : array()) as $g) {
            if (is_string($g) && isset($all[$g])) {
                $codes[] = $g;
            }
        }
        $new['fw_geo_list'] = implode(',', array_unique($codes));
        $back = 'gestione.php?sez=firewall';
        if ($new['fw_geo_mode'] === 'allow' && !$codes) {
            flash('Con "Consenti solo le nazioni scelte" devi spuntare almeno una nazione (per esempio Italia).', 'error');
            redirect($back);
        }
        // l'Admin non deve chiudersi fuori da solo (con l'eventuale nuova impostazione del proxy)
        if (!TRUST_PROXY && $new['fw_proxy'] !== setting('fw_proxy', '0')) {
            setting_save('fw_proxy', $new['fw_proxy']);
            load_settings(true);
            $me = fw_client(true);
            fw_client_country(false, true);
        }
        if ($new['fw_enabled'] === '1' && !fw_whitelisted($me['ip'], $new['fw_lan_allow'] === '1', $new['fw_whitelist'])) {
            if ($new['fw_cf_only'] === '1' && !$me['via_cf'] && !ip_is_local($me['ip'])) {
                flash('Non salvato: stai entrando senza passare da Cloudflare, con "solo Cloudflare" verresti bloccato anche tu.', 'error');
                redirect($back);
            }
            $cfg = array('mode' => $new['fw_geo_mode'], 'list' => $codes, 'unknown' => $new['fw_geo_unknown'], 'tor' => $new['fw_geo_tor'] === '1');
            $cc = fw_client_country();
            if (fw_geo_denies($cc, $cfg)) {
                flash('Non salvato: con queste nazioni verresti bloccato anche tu (il sito ti vede in: ' . fw_country_name($cc)
                    . '). Spunta la tua nazione oppure aggiungi il tuo IP a quelli sempre consentiti.', 'error');
                redirect($back);
            }
        }
        $changed = array();
        foreach ($new as $k => $v) {
            if ($v !== setting($k)) {
                setting_save($k, $v);
                $changed[] = $k;
            }
        }
        load_settings(true);
        if ($changed) {
            app_log('firewall_impostazioni', 'Firewall modificato: ' . implode(', ', $changed) . ($new['fw_geo_mode'] !== 'off' ? ' · nazioni ' . $new['fw_geo_mode'] . ': ' . $new['fw_geo_list'] : ''), 'warn');
        }
        $msg = 'Firewall salvato.';
        if ($bad) {
            $msg .= ' Ignorati perché non sono IP validi: ' . implode(', ', array_slice($bad, 0, 5)) . '.';
        }
        if ($new['fw_geo_mode'] !== 'off' && !fw_geo_ok() && (int)setting('fw_cf_seen', '0') < time() - 7 * 86400) {
            $msg .= ' Attenzione: il sito non passa da Cloudflare e il database delle nazioni non è ancora scaricato, quindi per ora non conosce la nazione dei visitatori: scaricalo qui sotto.';
            flash($msg, 'warn');
        } else {
            flash($msg);
        }
        redirect($back);
    }
    if ($a === 'fw_geo_auto') {
        setting_save('fw_geo_auto', post('fw_geo_auto') === '1' ? '1' : '0');
        flash(post('fw_geo_auto') === '1' ? 'Il database delle nazioni si aggiornerà da solo ogni mese.' : 'Aggiornamento automatico del database delle nazioni spento.');
        redirect('gestione.php?sez=firewall');
    }
    if ($a === 'fw_geo_update') {
        $r = fw_geo_update();
        flash($r[0] ? 'Database delle nazioni aggiornato (' . $r[1] . ').' : 'Database delle nazioni non aggiornato: ' . $r[1], $r[0] ? 'success' : 'error');
        redirect('gestione.php?sez=firewall');
    }
    if ($a === 'fw_siege_end') {
        setting_save('fw_siege_until', '0');
        app_log('firewall_attacco', 'Protezione da attacco distribuito terminata a mano', 'warn');
        flash('Accessi di nuovo aperti a tutti i dispositivi.');
        redirect('gestione.php?sez=firewall');
    }
    if ($a === 'fw_block') {
        $ip = trim(post('ip'));
        $norm = strpos($ip, '/') === false && strpos($ip, '*') === false ? fw_norm_ip($ip) : $ip;
        if ($norm === '' || !fw_rule_valid($norm)) {
            flash('"' . str_cut($ip, 60) . '" non è un IP o una rete valida (es. 45.95.147.12 oppure 45.95.147.0/24).', 'error');
            redirect('gestione.php?sez=blocchi');
        }
        if (fw_rule_match($me['ip'], $norm)) {
            flash('Non puoi bloccare il tuo stesso indirizzo (' . $me['ip'] . ').', 'error');
            redirect('gestione.php?sez=blocchi');
        }
        $min = (int)post('minutes');
        $min = in_array($min, array(60, 1440, 10080, 43200, 0), true) ? $min : 0;
        $cc = strpos($norm, '/') === false && strpos($norm, '*') === false ? fw_geo_lookup($norm) : '';
        if ($cc === '') {
            $st = db()->prepare("SELECT country FROM fw_events WHERE ip = ? AND country <> '' ORDER BY id DESC LIMIT 1");
            $st->execute(array($norm));
            $cc = (string)$st->fetchColumn();
        }
        fw_block_add($norm, 'manual', str_cut(post('note'), 200), $min, 'manual', 1, $cc);
        $note = $min === 0 ? 'per sempre' : 'per ' . fw_duration_text($min);
        fw_event('manual', 'Bloccato a mano ' . $note . (post('note') !== '' ? ': ' . str_cut(post('note'), 120) : ''), $norm, $cc, false);
        app_log('firewall_blocco', 'IP ' . $norm . ' bloccato a mano ' . $note, 'warn');
        if (fw_whitelisted(strpos($norm, '/') === false ? $norm : explode('/', $norm)[0])) {
            flash('Blocco salvato, ma ' . $norm . ' è tra gli IP sempre consentiti: finché resta lì il blocco non ha effetto.', 'warn');
        } else {
            flash($norm . ' bloccato ' . $note . '.');
        }
        redirect('gestione.php?sez=blocchi');
    }
    if ($a === 'fw_unblock') {
        $st = db()->prepare('SELECT * FROM fw_blocks WHERE id = ?');
        $st->execute(array((int)post('id')));
        $b = $st->fetch();
        if ($b) {
            if ((int)$b['is_range']) {
                db()->prepare('UPDATE fw_blocks SET active = 0 WHERE id = ?')->execute(array($b['id']));
            } else {
                fw_unblock_ip($b['ip']);
            }
            app_log('firewall_sblocco', 'IP ' . $b['ip'] . ' sbloccato', 'warn');
            flash($b['ip'] . ' sbloccato.');
        }
        redirect('gestione.php?sez=blocchi');
    }
    if ($a === 'fw_events_clear') {
        db()->exec('DELETE FROM fw_events');
        app_log('firewall_registro', 'Registro del firewall svuotato', 'warn');
        flash('Registro del firewall svuotato.');
        redirect('gestione.php?sez=blocchi');
    }
    redirect('gestione.php?sez=firewall');
}
