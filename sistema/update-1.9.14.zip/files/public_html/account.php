<?php
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/auth.php';
require_once APP_ROOT . '/inc/webauthn.php';
require_user();

$u = current_user();
$uid = (int)$u['id'];
$full = db()->prepare('SELECT * FROM users WHERE id = ?');
$full->execute(array($uid));
$full = $full->fetch();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = post('action');
    if ($action === 'avvisi' && is_file(APP_ROOT . '/inc/notifiche.php')) {
        require_once APP_ROOT . '/inc/notifiche.php';
        if (notif_ready()) {
            $prefs = array();
            foreach (notif_tipi() as $k => $t) {
                if (notif_tipo_per($k, $full['role'])) {
                    $prefs[$k] = post('n_' . $k) === '1' ? 1 : 0;
                }
            }
            $share = post('share_reading') === '1' ? 1 : 0;
            db()->prepare('UPDATE users SET notify_prefs = ?, share_reading = ?, updated_at = ? WHERE id = ?')->execute(array(json_encode($prefs), $share, now(), $uid));
            if ($share !== (int)$full['share_reading']) {
                app_log('riservatezza', $share ? 'Letture e voti di nuovo visibili agli altri' : 'Letture e voti nascosti agli altri', 'info');
            }
            flash('Preferenze degli avvisi salvate.');
        }
        redirect('account.php#avvisi');
    }
    if ($action === 'profilo') {
        $name = str_cut(post('display_name'), 100);
        if (users_email_ready()) {
            $em = trim(post('email'));
            if (($ep = email_problem($em)) !== '') {
                flash($ep, 'error');
                redirect('account.php');
            }
            db()->prepare('UPDATE users SET display_name = ?, email = ?, email_notify = ?, updated_at = ? WHERE id = ?')
                ->execute(array($name, $em === '' ? null : $em, post('email_notify') === '1' ? 1 : 0, now(), $uid));
            if ($em !== (string)$full['email']) {
                app_log('email_modificata', 'Indirizzo email del profilo ' . ($em === '' ? 'tolto' : 'cambiato'), 'warn');
            }
            flash('Profilo aggiornato.');
        } else {
            db()->prepare('UPDATE users SET display_name = ?, updated_at = ? WHERE id = ?')->execute(array($name, now(), $uid));
            flash('Nome aggiornato.');
        }
        redirect('account.php');
    } elseif ($action === 'password') {
        $old = isset($_POST['old']) ? (string)$_POST['old'] : '';
        $new = isset($_POST['new']) ? (string)$_POST['new'] : '';
        $new2 = isset($_POST['new2']) ? (string)$_POST['new2'] : '';
        if (!password_verify($old, $full['password_hash'])) {
            $error = 'La password attuale non è corretta.';
            app_log('password_errata', 'Cambio password: password attuale errata', 'warn');
        } elseif ($new !== $new2) {
            $error = 'Le due nuove password non coincidono.';
        } elseif (($p = password_problem($new, $full['username'])) !== '') {
            $error = $p;
        } elseif (password_verify($new, $full['password_hash'])) {
            $error = 'La nuova password deve essere diversa da quella attuale.';
        } else {
            db()->prepare('UPDATE users SET password_hash = ?, must_change_pw = 0, updated_at = ? WHERE id = ?')
                ->execute(array(pw_hash($new), now(), $uid));
            session_regenerate_id(true);
            // con la password nuova gli altri dispositivi ricordati vanno riconfermati (questo resta)
            if ((int)setting('db_version', '1') >= 13) {
                db()->prepare('DELETE FROM user_devices WHERE user_id = ? AND id <> ?')->execute(array($uid, isset($_SESSION['device_id']) ? (int)$_SESSION['device_id'] : 0));
            }
            $_SESSION['pw_ok_at'] = time();
            app_log('password_cambiata', 'Password modificata dall\'utente');
            flash('Password cambiata.');
            redirect('account.php');
        }
    } elseif (($action === 'pk_del' || $action === 'pk_rename') && pk_ready()) {
        $st = db()->prepare('SELECT * FROM user_passkeys WHERE id = ? AND user_id = ?');
        $st->execute(array((int)post('pid'), $uid));
        $pk = $st->fetch();
        if ($pk && $action === 'pk_rename') {
            $nm = trim(str_cut(post('name'), 80));
            if ($nm !== '') {
                db()->prepare('UPDATE user_passkeys SET name = ? WHERE id = ?')->execute(array($nm, (int)$pk['id']));
                flash('Nome della chiave aggiornato.');
            }
            redirect('account.php#chiavi');
        }
        if ($pk && !password_verify(isset($_POST['pw']) ? (string)$_POST['pw'] : '', $full['password_hash'])) {
            $error = 'Password non corretta: la chiave non è stata eliminata.';
        } elseif ($pk) {
            db()->prepare('DELETE FROM user_passkeys WHERE id = ?')->execute(array((int)$pk['id']));
            app_log('passkey_eliminata', 'Chiave di accesso "' . $pk['name'] . '" eliminata', 'warn');
            flash('Chiave "' . $pk['name'] . '" eliminata dal sito. Puoi cancellarla anche da Bitwarden.');
            redirect('account.php#chiavi');
        }
    } elseif (($action === 'dev_forget' || $action === 'dev_forget_all') && (int)setting('db_version', '1') >= 13) {
        require_once APP_ROOT . '/inc/remember.php';
        if ($action === 'dev_forget_all') {
            remember_forget_user($uid);
            remember_clear_cookie();
            app_log('dispositivi_dimenticati', 'Tutti i dispositivi ricordati sono stati dimenticati', 'warn');
            flash('Tutti i dispositivi sono stati dimenticati: su ognuno servirà di nuovo la password (o la chiave di accesso).');
        } else {
            $did = (int)post('did');
            db()->prepare('DELETE FROM user_devices WHERE id = ? AND user_id = ?')->execute(array($did, $uid));
            if ($did === (isset($_SESSION['device_id']) ? (int)$_SESSION['device_id'] : -1)) {
                remember_clear_cookie();
            }
            app_log('dispositivo_dimenticato', 'Dispositivo ricordato dimenticato', 'info');
            flash('Dispositivo dimenticato.');
        }
        redirect('account.php#dispositivi');
    } elseif ($action === '2fa_start') {
        $_SESSION['totp_setup'] = totp_new_secret();
        redirect('account.php#due-passaggi');
    } elseif ($action === '2fa_confirm') {
        $secret = isset($_SESSION['totp_setup']) ? $_SESSION['totp_setup'] : '';
        $step = $secret !== '' ? totp_match_step($secret, post('code'), 0) : false;
        if ($step !== false) {
            $has_step = (int)setting('db_version', '1') >= 11;
            db()->prepare('UPDATE users SET totp_secret = ?, totp_enabled = 1' . ($has_step ? ', totp_last_step = ' . (int)$step : '') . ', updated_at = ? WHERE id = ?')
                ->execute(array($has_step ? totp_secret_store($secret) : $secret, now(), $uid));
            unset($_SESSION['totp_setup']);
            app_log('2fa_attivata', 'Verifica in due passaggi attivata');
            flash('Verifica in due passaggi attivata. Da ora all\'accesso ti verrà chiesto il codice.');
            redirect('account.php');
        }
        $error = 'Il codice non è corretto. Controlla che l\'orario del telefono sia giusto e riprova.';
    } elseif ($action === '2fa_off') {
        if (!password_verify(isset($_POST['pw']) ? (string)$_POST['pw'] : '', $full['password_hash'])) {
            $error = 'Password non corretta.';
        } elseif ($u['role'] === 'admin' && setting('sec_2fa_admin') === '1') {
            $error = 'Per gli Admin la verifica in due passaggi è obbligatoria (impostazione di sicurezza).';
        } else {
            db()->prepare('UPDATE users SET totp_secret = NULL, totp_enabled = 0, updated_at = ? WHERE id = ?')->execute(array(now(), $uid));
            app_log('2fa_disattivata', 'Verifica in due passaggi disattivata', 'warn');
            flash('Verifica in due passaggi disattivata.', 'warn');
            redirect('account.php');
        }
    }
}

$obbligo = get('obbligo');
$setup = isset($_SESSION['totp_setup']) ? $_SESSION['totp_setup'] : '';
$stats = db()->prepare("SELECT status, COUNT(*) AS n FROM user_books WHERE user_id = ? GROUP BY status");
$stats->execute(array($uid));
$my = array('in_lettura' => 0, 'letto' => 0);
foreach ($stats->fetchAll() as $r) {
    $my[$r['status']] = (int)$r['n'];
}

page_start('Il mio account', 'account', array('back' => 'libreria.php'));
?>
<?php if ($obbligo === 'password' || (int)$full['must_change_pw'] === 1): ?>
  <div class="alert warn">Per sicurezza devi scegliere una nuova password prima di continuare.</div>
<?php elseif ($obbligo === '2fa'): ?>
  <div class="alert warn">L'amministratore ha reso obbligatoria la verifica in due passaggi: attivala qui sotto per continuare.</div>
<?php endif; ?>
<?php if ($error !== ''): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>

<div class="card profile">
  <div class="avatar big"><?= h(user_initials()) ?></div>
  <div><b><?= h($full['display_name'] !== '' ? $full['display_name'] : $full['username']) ?></b>
    <small><?= h($full['username']) ?> · <?= $full['role'] === 'admin' ? 'Amministratore' : h(role_label($full['role'])) ?></small>
    <small>In lettura: <?= $my['in_lettura'] ?> · Letti: <?= $my['letto'] ?></small>
    <?php if ((int)setting('db_version', '1') >= 8): ?><small><a class="link" href="statistiche.php">Le mie letture: statistiche, trofei, classifica →</a></small><?php endif; ?></div>
</div>
<?php if (is_file(APP_ROOT . '/inc/notifiche.php')) { require_once APP_ROOT . '/inc/notifiche.php'; } ?>
<?php if (function_exists('notif_ready') && notif_ready() && in_array($full['role'], user_roles(), true)): $np = notif_prefs($full); ?>
<form method="post" class="card stack" id="avvisi">
  <?= csrf_field() ?><input type="hidden" name="action" value="avvisi">
  <div class="ct"><?= icon('bell', 18) ?> Avvisi e riservatezza</div>
  <label class="check switch"><input type="checkbox" name="share_reading" value="1" <?= (int)$full['share_reading'] === 1 ? 'checked' : '' ?>><span>Mostra le mie letture e i miei voti agli altri</span></label>
  <p class="hint">Se lo spegni, gli altri non ricevono avvisi su cosa leggi e non vedono i tuoi voti, le tue recensioni e il tuo nome nella classifica di famiglia. Tu continui a vedere tutto.</p>
  <div class="lab">Avvisi che ricevi nella campanella</div>
  <?php foreach (notif_tipi() as $k => $t): if (!notif_tipo_per($k, $full['role'])) { continue; } ?>
  <label class="check"><input type="checkbox" name="n_<?= h($k) ?>" value="1" <?= !isset($np[$k]) || $np[$k] ? 'checked' : '' ?>> <span><b><?= h($t[0]) ?></b> <small class="muted">· <?= h($t[1]) ?></small></span></label>
  <?php endforeach; ?>
  <button class="btn ghost" type="submit">Salva</button>
</form>
<?php endif; ?>
<?php if ((int)setting('db_version', '1') >= 8 && in_array($full['role'], user_roles(), true)): ?>
<div class="card stack" id="goodreads">
  <div class="ct"><?= icon('cloud', 18) ?> Importa da Goodreads</div>
  <p class="sub">Porta qui le tue letture da Goodreads: libri letti con data, voto e recensione, letture in corso e, se vuoi, i "da leggere".
    Su goodreads.com: <b>My Books → Import and export → Export Library</b>, poi carica il file <code>goodreads_library_export.csv</code>.</p>
  <a class="btn ghost" href="statistiche.php?v=goodreads">Importa da Goodreads</a>
</div>
<?php endif; ?>
<?= function_exists('lib_filter') ? (string)lib_filter('pagina_account', '') : '' ?>

<form method="post" class="card stack">
  <?= csrf_field() ?><input type="hidden" name="action" value="profilo">
  <div class="ct"><?= users_email_ready() ? 'Profilo' : 'Nome visualizzato' ?></div>
  <?php if (users_email_ready()): ?><label class="lab" for="pf-name">Nome visualizzato</label><?php endif; ?>
  <input class="input" id="pf-name" name="display_name" maxlength="100" value="<?= h($full['display_name']) ?>">
  <?php if (users_email_ready()): ?>
  <label class="lab" for="pf-email">Email</label>
  <input class="input" id="pf-email" type="email" name="email" maxlength="190" value="<?= h((string)$full['email']) ?>" placeholder="per ricevere i riepiloghi delle letture" autocomplete="email">
  <label class="check"><input type="checkbox" name="email_notify" value="1" <?= (int)$full['email_notify'] ? 'checked' : '' ?>> Ricevi le email del sito (per esempio il riepilogo quando finisci un libro)</label>
  <?php endif; ?>
  <button class="btn ghost" type="submit"><?= users_email_ready() ? 'Salva il profilo' : 'Salva nome' ?></button>
</form>

<form method="post" class="card stack" id="password">
  <?= csrf_field() ?><input type="hidden" name="action" value="password">
  <div class="ct">Cambia password</div>
  <label class="lab" for="pw-old">Password attuale</label>
  <input class="input" id="pw-old" type="password" name="old" autocomplete="current-password" required>
  <label class="lab" for="pw-new">Nuova password (almeno <?= setting_int('sec_min_password') ?> caratteri)</label>
  <input class="input" id="pw-new" type="password" name="new" autocomplete="new-password" minlength="<?= setting_int('sec_min_password', 6, 64) ?>" required>
  <label class="lab" for="pw-new2">Ripeti la nuova password</label>
  <input class="input" id="pw-new2" type="password" name="new2" autocomplete="new-password" required>
  <button class="btn primary" type="submit">Cambia password</button>
</form>

<div class="card stack" id="due-passaggi">
  <div class="ct"><?= icon('shield', 18) ?> Verifica in due passaggi</div>
  <?php if ((int)$full['totp_enabled'] === 1): ?>
    <p class="ok-text"><?= icon('check', 16) ?> Attiva: all'accesso ti viene chiesto il codice dell'app.</p>
    <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="2fa_off">
      <label class="lab" for="pw-2fa">Per disattivarla scrivi la password</label>
      <input class="input" id="pw-2fa" type="password" name="pw" autocomplete="current-password" required>
      <button class="btn ghost" type="submit">Disattiva</button></form>
  <?php elseif ($setup !== ''): ?>
    <ol class="steps">
      <li>Installa sul telefono un'app di autenticazione (Google Authenticator, Microsoft Authenticator, Aegis…).</li>
      <li>Tocca <a class="link" href="<?= h(totp_uri($setup, $full['username'], setting('brand_title'))) ?>">questo collegamento</a> dal telefono
        oppure nell'app scegli "inserisci chiave" e scrivi:<br><code class="secret"><?= h(trim(chunk_split($setup, 4, ' '))) ?></code></li>
      <li>Scrivi qui il codice di 6 cifre che compare nell'app.</li>
    </ol>
    <form method="post" class="stack" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="action" value="2fa_confirm">
      <input class="input big code" name="code" inputmode="numeric" maxlength="7" autocomplete="one-time-code" placeholder="123456" required>
      <button class="btn primary" type="submit">Conferma e attiva</button></form>
  <?php else: ?>
    <p class="sub">Oltre alla password, all'accesso servirà un codice che cambia ogni 30 secondi, generato da un'app sul tuo telefono.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="2fa_start">
      <button class="btn primary" type="submit">Attiva la verifica in due passaggi</button></form>
  <?php endif; ?>
</div>

<?php if ((int)setting('db_version', '1') >= 13): require_once APP_ROOT . '/inc/remember.php'; $devs = remember_list($uid); ?>
<div class="card stack" id="dispositivi">
  <div class="ct"><?= icon('check', 18) ?> Dispositivi ricordati</div>
  <p class="sub">Su questi dispositivi entri senza password per <?= (int)remember_days() ?> giorni dalla prima volta (casella «Ricorda questo dispositivo» nella pagina di accesso).
    Se ne perdi uno, dimenticalo da qui. «Esci» dimentica il dispositivo su cui lo premi.</p>
  <?php if (!$devs): ?><p class="hint">Nessun dispositivo ricordato.</p><?php endif; ?>
  <?php foreach ($devs as $dv): $this_dev = isset($_SESSION['device_id']) && (int)$_SESSION['device_id'] === (int)$dv['id']; ?>
  <div class="dev-row">
    <div><b><?= h($dv['name']) ?></b><?= $this_dev ? ' <span class="tag ok">questo dispositivo</span>' : '' ?>
      <small>Ultimo uso <?= h(date('d/m/Y H:i', strtotime($dv['last_used_at']))) ?> · fino al <?= h(date('d/m/Y', strtotime($dv['expires_at']))) ?></small></div>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="dev_forget"><input type="hidden" name="did" value="<?= (int)$dv['id'] ?>">
      <button class="btn ghost small" type="submit">Dimentica</button></form>
  </div>
  <?php endforeach; ?>
  <?php if (count($devs) > 1): ?>
  <form method="post" data-confirm="Dimenticare tutti i dispositivi? Su ognuno servirà di nuovo la password."><?= csrf_field() ?><input type="hidden" name="action" value="dev_forget_all">
    <button class="btn link small" type="submit">Dimentica tutti i dispositivi</button></form>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if (pk_enabled()): $pks = pk_list($uid); $pk_here = pk_available_here(); ?>
<div class="card stack" id="chiavi">
  <div class="ct"><?= icon('lock', 18) ?> Chiavi di accesso</div>
  <p class="sub" style="margin-top:0">Entra con un tocco usando Bitwarden (o Google, Apple, Windows Hello), senza password né codice:
    la chiave funziona solo su questo sito e si sblocca con impronta, volto o PIN. La password resta valida come riserva.</p>
  <?php foreach ($pks as $p): ?>
  <div class="pk-row">
    <div><b><?= h($p['name']) ?></b><small>creata il <?= h(date('d/m/Y', strtotime($p['created_at']))) ?> · <?= $p['last_used_at'] ? 'ultimo uso ' . h(date('d/m/Y H:i', strtotime($p['last_used_at']))) : 'mai usata' ?></small></div>
    <details><summary class="link">Modifica</summary>
      <form method="post" class="row-btn" style="margin-top:8px"><?= csrf_field() ?><input type="hidden" name="action" value="pk_rename"><input type="hidden" name="pid" value="<?= (int)$p['id'] ?>">
        <input class="input" name="name" maxlength="80" value="<?= h($p['name']) ?>" aria-label="Nome della chiave"><button class="btn ghost small" type="submit">Rinomina</button></form>
      <form method="post" class="row-btn" style="margin-top:8px"><?= csrf_field() ?><input type="hidden" name="action" value="pk_del"><input type="hidden" name="pid" value="<?= (int)$p['id'] ?>">
        <input class="input" type="password" name="pw" autocomplete="current-password" placeholder="La tua password" required aria-label="Password">
        <button class="btn danger-ghost small" type="submit">Elimina</button></form>
    </details>
  </div>
  <?php endforeach; ?>
  <?php if ($pk_here): ?>
  <form class="stack" data-pk-register>
    <div class="alert error" data-pk-msg hidden></div>
    <label class="lab" for="pk-name">Nome (facoltativo)</label>
    <input class="input" id="pk-name" name="pk_name" maxlength="80" placeholder="es. Bitwarden, telefono">
    <?php if (is_file(APP_ROOT . '/inc/remember.php')) { require_once APP_ROOT . '/inc/remember.php'; } ?>
    <?php if (function_exists('remember_needs_reauth') && remember_needs_reauth()): ?>
    <label class="lab" for="pk-pw">La tua password (sei entrato con un dispositivo ricordato)</label>
    <input class="input" id="pk-pw" type="password" name="pk_pw" required autocomplete="current-password">
    <?php endif; ?>
    <button class="btn primary" type="submit" data-pk-create><?= icon('plus', 18) ?> Crea una chiave di accesso</button>
  </form>
  <?php else: ?>
  <p class="alert warn">Per creare una chiave apri il sito dal suo indirizzo <b>https://</b> (per esempio quello pubblico), non dall'indirizzo IP:
    le chiavi sono legate al nome del sito.</p>
  <?php endif; ?>
</div>
<?php endif; ?>

<a class="btn ghost" href="logout.php?t=<?= h(csrf_token()) ?>"><?= icon('logout', 18) ?> Esci</a>
<?php page_end(pk_enabled() ? array('js/passkey.js') : array()); ?>
