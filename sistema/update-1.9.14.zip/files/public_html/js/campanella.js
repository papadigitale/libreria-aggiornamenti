// Campanella degli avvisi (1.9.14): pannello con gli ultimi avvisi e conteggio aggiornato ogni 2 minuti
(function () {
  'use strict';
  var bells = document.querySelectorAll('[data-bell]');
  if (!bells.length || !window.fetch) { return; }
  var cfg = {};
  try { cfg = JSON.parse(document.getElementById('app-config').textContent); } catch (e) { /* niente */ }
  var panel = null;
  var ICONE = { aggiornamenti: '⟳', sicurezza: '⚑', backup: '⛁', prestiti: '⇄', nuovi_libri: '✚', letture: '📖', meta: '½', voti: '★', plugin: '✦' };

  function el(t, c, x) { var e = document.createElement(t); if (c) { e.className = c; } if (x !== undefined) { e.textContent = x; } return e; }

  function badge(n) {
    document.querySelectorAll('[data-bell-n]').forEach(function (b) {
      b.hidden = !n; b.textContent = n > 99 ? '99+' : String(n);
    });
  }

  function conta() {
    if (document.hidden) { return; }
    fetch('api.php?action=notif_count', { credentials: 'same-origin' }).then(function (r) { return r.json(); })
      .then(function (j) { if (j.ok) { badge(j.n); } }).catch(function () { /* fuori linea */ });
  }

  function chiudi() {
    if (!panel) { return; }
    panel.classList.remove('open');
    var p = panel; panel = null;
    setTimeout(function () { p.remove(); }, 200);
    document.removeEventListener('keydown', esc);
  }
  function esc(e) { if (e.key === 'Escape') { chiudi(); } }

  function apri(bell) {
    if (panel) { chiudi(); return; }
    panel = el('div', 'bell-panel');
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Avvisi');
    var back = el('div', 'bp-back'); back.addEventListener('click', chiudi);
    var box = el('div', 'bp-box');
    var head = el('div', 'bp-head'); head.appendChild(el('b', '', 'Avvisi'));
    var all = el('a', 'link', 'Vedi tutti'); all.href = 'notifiche.php'; head.appendChild(all);
    box.appendChild(head);
    var list = el('div', 'bp-list'); list.appendChild(el('p', 'bp-wait', 'Carico…'));
    box.appendChild(list);
    var foot = el('a', 'bp-foot', 'Scegli quali avvisi ricevere'); foot.href = 'account.php#avvisi'; box.appendChild(foot);
    panel.appendChild(back); panel.appendChild(box);
    // sul computer il pannello si apre sotto la campanella
    var r = bell.getBoundingClientRect();
    if (window.innerWidth > 700) { box.style.top = (r.bottom + 8) + 'px'; box.style.right = Math.max(12, window.innerWidth - r.right - 8) + 'px'; }
    document.body.appendChild(panel);
    requestAnimationFrame(function () { panel && panel.classList.add('open'); });
    document.addEventListener('keydown', esc);
    fetch('api.php?action=notif_list', { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
      list.textContent = '';
      if (!j.ok || !j.items.length) {
        list.appendChild(el('p', 'bp-wait', 'Nessun avviso, per ora.'));
        return;
      }
      j.items.forEach(function (it) {
        var a = el(it.link ? 'a' : 'div', 'notif-i' + (it.new ? ' new' : ''));
        if (it.link) { a.href = it.link; }
        if (it.cover) { var im = el('img', 'notif-cov'); im.src = it.cover; im.alt = ''; im.loading = 'lazy'; a.appendChild(im); }
        else { a.appendChild(el('span', 'notif-ico k-' + it.kind, ICONE[it.kind] || '•')); }
        var t = el('span', 'notif-t', it.text); t.appendChild(el('small', '', it.when)); a.appendChild(t);
        list.appendChild(a);
      });
      // aperto il pannello, gli avvisi diventano letti (restano evidenziati finche' resta aperto)
      var fd = new FormData(); fd.append('csrf', cfg.csrf || '');
      fetch('api.php?action=notif_read', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf || '' } })
        .then(function () { badge(0); }).catch(function () { /* niente */ });
    }).catch(function () { list.textContent = ''; list.appendChild(el('p', 'bp-wait', 'Connessione non riuscita.')); });
  }

  bells.forEach(function (b) {
    b.addEventListener('click', function (e) { e.preventDefault(); apri(b); });
  });
  setInterval(conta, 120000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) { conta(); } });
})();
