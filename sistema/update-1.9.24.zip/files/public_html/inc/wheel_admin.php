<?php
/*
 * Ruota di lettura: controllo dal pannello di gestione.
 * Per ogni libro dice se e' sulla ruota di un utente e, se non lo e', PERCHE'
 * (escluso a mano, gia' letto, gia' estratto, in prestito, fuori dai filtri...).
 * Le regole sono le stesse di wheel_pool() in wheel.php: il numero dei libri "in ruota"
 * deve coincidere con quello della pagina Ruota.
 */
require_once dirname(__FILE__) . '/wheel.php';

// Motivi per cui un libro non e' sulla ruota: chiave => array(etichetta breve, classe)
function wheel_audit_reasons()
{
    return array(
        'ok'        => array('In ruota', 'ok'),
        'escluso'   => array('Escluso a mano', 'bad'),
        'letto'     => array('Già letto', 'st-letto'),
        'in_lettura' => array('In lettura', 'st-in_lettura'),
        'estratto'  => array('Già estratto', ''),
        'prestito'  => array('In prestito', ''),
        'non_scelto' => array('Non scelto a mano', ''),
        'genere'    => array('Altro genere', ''),
        'pagine'    => array('Troppo lungo', ''),
    );
}

// Utente di cui si gestisce la ruota: il proprio; l'Admin puo' scegliere un altro utente attivo
function wheel_admin_users()
{
    return db()->query('SELECT id, username, display_name FROM users WHERE active = 1 ORDER BY display_name, username')->fetchAll();
}

function wheel_admin_target($requested)
{
    $uid = (int)current_uid();
    if (is_admin() && (int)$requested > 0 && (int)$requested !== $uid) {
        $st = db()->prepare('SELECT id FROM users WHERE id = ? AND active = 1');
        $st->execute(array((int)$requested));
        if ($st->fetchColumn()) {
            return (int)$requested;
        }
    }
    return $uid;
}

/*
 * Elenco completo dei libri con lo stato rispetto alla ruota di $uid.
 * Ogni riga: dati del libro + 'reasons' (tutti i motivi di esclusione, in ordine di importanza)
 * + 'why' (il primo, o 'ok') + 'spin' (ultima estrazione: outcome e data, se c'e').
 */
function wheel_audit($uid, $ws)
{
    $pdo = db();
    $st = $pdo->prepare('SELECT b.id, b.title, b.authors, b.pages, b.cover_file, b.category_id, c.name AS cat, '
        . 'ub.status AS my_status, ub.wheel_excluded AS excl FROM books b '
        . 'LEFT JOIN categories c ON c.id = b.category_id '
        . 'LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = ? ORDER BY b.title');
    $st->execute(array((int)$uid));
    $books = $st->fetchAll();

    $spins = array();
    $st = $pdo->prepare('SELECT s.book_id, s.outcome, s.created_at FROM wheel_spins s '
        . 'WHERE s.user_id = ? AND s.id IN (SELECT MAX(id) FROM wheel_spins WHERE user_id = ? GROUP BY book_id)');
    $st->execute(array((int)$uid, (int)$uid));
    foreach ($st->fetchAll() as $r) {
        $spins[(int)$r['book_id']] = $r;
    }
    $loaned = array();
    if ((int)setting('db_version', '1') >= 3) {
        foreach ($pdo->query('SELECT book_id FROM loans WHERE returned_at IS NULL')->fetchAll(PDO::FETCH_COLUMN) as $bid) {
            $loaned[(int)$bid] = 1;
        }
    }
    $picked = array_flip(wheel_item_ids($uid));
    $manual = $ws['source'] === 'manual';
    $cat = !empty($ws['category_id']) ? (int)$ws['category_id'] : 0;
    $maxp = !empty($ws['max_pages']) ? (int)$ws['max_pages'] : 0;

    foreach ($books as &$b) {
        $id = (int)$b['id'];
        $r = array();
        // nella fonte "scelti da me" il segno "escludi" non conta (come in wheel_pool)
        if (!$manual && (int)$b['excl'] === 1) {
            $r[] = 'escluso';
        }
        if ($ws['source'] === 'unread') {
            if ($b['my_status'] === 'letto') {
                $r[] = 'letto';
            } elseif ($b['my_status'] === 'in_lettura') {
                $r[] = 'in_lettura';
            }
        }
        if (isset($spins[$id])) {
            $r[] = 'estratto';
        }
        if (isset($loaned[$id])) {
            $r[] = 'prestito';
        }
        if ($manual && !isset($picked[$id])) {
            $r[] = 'non_scelto';
        }
        if ($cat && (int)$b['category_id'] !== $cat) {
            $r[] = 'genere';
        }
        if ($maxp && (empty($b['pages']) || (int)$b['pages'] > $maxp)) {
            $r[] = 'pagine';
        }
        $b['reasons'] = $r;
        $b['why'] = $r ? $r[0] : 'ok';
        $b['spin'] = isset($spins[$id]) ? $spins[$id] : null;
        $b['picked'] = isset($picked[$id]);
    }
    unset($b);
    return $books;
}

// Quanti libri per ogni motivo (un libro con piu' motivi conta una volta sola, sul principale)
function wheel_audit_counts($rows)
{
    $c = array_fill_keys(array_keys(wheel_audit_reasons()), 0);
    foreach ($rows as $b) {
        $c[$b['why']]++;
    }
    return $c;
}

// Esclude un libro dalla ruota (come il segno "Escludi dalla ruota" della scheda libro)
function wheel_admin_exclude($uid, $book_id)
{
    $ws = wheel_settings_get($uid);
    if ($ws['source'] === 'manual') {
        db()->prepare('DELETE FROM wheel_items WHERE user_id = ? AND book_id = ?')->execute(array((int)$uid, (int)$book_id));
    }
    user_book_save($uid, $book_id, null, true);
}

/*
 * Rimette un libro tra quelli che possono uscire: toglie il segno "escludi" e lo toglie dalla lista delle estrazioni.
 * Lo stato di lettura NON si tocca (un libro "letto" resta fuori dalla fonte "Non ancora letti").
 */
function wheel_admin_reinclude($uid, $book_id)
{
    $ws = wheel_settings_get($uid);
    db()->prepare('DELETE FROM wheel_spins WHERE user_id = ? AND book_id = ?')->execute(array((int)$uid, (int)$book_id));
    user_book_save($uid, $book_id, null, false);
    if ($ws['source'] === 'manual') {
        $c = db()->prepare('SELECT COUNT(*) FROM wheel_items WHERE user_id = ? AND book_id = ?');
        $c->execute(array((int)$uid, (int)$book_id));
        if (!(int)$c->fetchColumn()) {
            db()->prepare('INSERT INTO wheel_items (user_id, book_id) VALUES (?,?)')->execute(array((int)$uid, (int)$book_id));
        }
    }
}

/*
 * Azioni (POST) della sezione Ruota di lettura. Chiamata da admin_actions.php solo per le azioni ruota_*:
 * ogni ramo termina con un redirect.
 */
function wheel_admin_handle_post($a)
{
    $wuid = wheel_admin_target(post('uid'));
    $back = admin_back('gestione.php?sez=ruota');
    if ($a === 'ruota_settings') {
        wheel_settings_save($wuid, post('source'), post('category_id'), post('max_pages'));
        app_log('ruota_impostazioni', 'Impostazioni della ruota aggiornate (utente #' . $wuid . ')', 'info');
        flash('Impostazioni della ruota salvate.');
        redirect($back);
    }
    if ($a === 'ruota_clear') {
        wheel_spins_clear($wuid);
        app_log('ruota_lista_svuotata', 'Lista delle estrazioni svuotata (utente #' . $wuid . ')', 'info');
        flash('Lista delle estrazioni svuotata: tutti i libri possono uscire di nuovo.');
        redirect($back);
    }
    // ruota_bulk: un solo libro (pulsante sulla riga, "op:id") oppure piu' libri selezionati
    $op = '';
    $ids = array();
    if (post('one') !== '' && preg_match('/^(include|exclude):(\d+)$/', post('one'), $m)) {
        $op = $m[1];
        $ids = array((int)$m[2]);
    } else {
        $op = post('op');
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)(isset($_POST['ids']) ? $_POST['ids'] : array())))));
    }
    if (!in_array($op, array('include', 'exclude'), true) || !$ids) {
        flash('Seleziona almeno un libro e scegli cosa fare.', 'error');
        redirect($back);
    }
    $ids = array_slice($ids, 0, 500);
    $exists = db()->query('SELECT id FROM books WHERE id IN (' . implode(',', $ids) . ')')->fetchAll(PDO::FETCH_COLUMN);
    $n = 0;
    foreach ($exists as $bid) {
        if ($op === 'exclude') {
            wheel_admin_exclude($wuid, (int)$bid);
        } else {
            wheel_admin_reinclude($wuid, (int)$bid);
        }
        $n++;
    }
    app_log($op === 'exclude' ? 'ruota_esclusi' : 'ruota_reinclusi', $n . ' libri (utente #' . $wuid . ')', 'info');
    flash($op === 'exclude'
        ? ($n === 1 ? 'Libro escluso dalla ruota.' : $n . ' libri esclusi dalla ruota.')
        : ($n === 1 ? 'Libro rimesso in ruota.' : $n . ' libri rimessi in ruota.'));
    redirect($back);
}
