<?php
require_once APP_ROOT . '/inc/wheel_admin.php';

$uid = wheel_admin_target(get('u'));
$users = is_admin() ? wheel_admin_users() : array();
$target_name = '';
foreach ($users as $uu) {
    if ((int)$uu['id'] === $uid) {
        $target_name = $uu['display_name'] !== '' ? $uu['display_name'] : $uu['username'];
    }
}
$ws = wheel_settings_get($uid);
$all = wheel_audit($uid, $ws);
$counts = wheel_audit_counts($all);
$reasons = wheel_audit_reasons();

// ---- filtri dell'elenco
$f = get('f');
if ($f !== '' && !isset($reasons[$f])) {
    $f = '';
}
$q = trim(get('q'));
$rows = array();
foreach ($all as $b) {
    if ($f !== '' && $b['why'] !== $f) {
        continue;
    }
    if ($q !== '' && stripos($b['title'] . ' ' . $b['authors'], $q) === false) {
        continue;
    }
    $rows[] = $b;
}
$per = 100;
$pages = max(1, (int)ceil(count($rows) / $per));
$p = min($pages, max(1, (int)get('p', '1')));
$show = array_slice($rows, ($p - 1) * $per, $per);

$base = array('sez' => 'ruota');
if ($uid !== (int)current_uid()) {
    $base['u'] = $uid;
}
$url = function ($extra = array()) use ($base) {
    return 'gestione.php?' . http_build_query(array_merge($base, $extra));
};
$back = 'gestione.php?' . http_build_query(array_merge($base, array_filter(array('f' => $f, 'q' => $q, 'p' => $p > 1 ? $p : ''), function ($v) { return $v !== ''; })));
$hidden = csrf_field() . '<input type="hidden" name="uid" value="' . (int)$uid . '"><input type="hidden" name="back" value="' . h($back) . '">';
$history = wheel_history($uid, 200);
$src = wheel_sources();
$not_ok = count($all) - $counts['ok'];
?>
<?php if ($users && count($users) > 1): ?>
<form method="get" class="card" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
  <input type="hidden" name="sez" value="ruota">
  <label class="lab" for="ru-user" style="margin:0">La ruota di</label>
  <select class="input" id="ru-user" name="u" style="max-width:260px" onchange="this.form.submit()">
    <?php foreach ($users as $uu): ?>
    <option value="<?= (int)$uu['id'] ?>" <?= (int)$uu['id'] === $uid ? 'selected' : '' ?>><?= h($uu['display_name'] !== '' ? $uu['display_name'] : $uu['username']) ?><?= (int)$uu['id'] === (int)current_uid() ? ' (io)' : '' ?></option>
    <?php endforeach; ?>
  </select>
  <noscript><button class="btn small" type="submit">Mostra</button></noscript>
</form>
<?php endif; ?>

<p class="sub" style="margin:14px 0 0">Ogni utente ha la <b>sua</b> ruota: gli stati di lettura e le esclusioni sono personali.
  <?= $uid !== (int)current_uid() ? 'Stai vedendo la ruota di <b>' . h($target_name) . '</b>.' : 'Questa è la tua ruota.' ?></p>

<div class="kpis">
  <div class="kpi"><b><?= (int)$counts['ok'] ?></b><span>libri in ruota (su <?= count($all) ?>)</span></div>
  <?php foreach (array('escluso', 'letto', 'in_lettura', 'estratto', 'prestito') as $k): ?>
    <?php if ($k === 'letto' && $ws['source'] !== 'unread') { continue; } ?>
    <?php if ($k === 'in_lettura' && $ws['source'] !== 'unread') { continue; } ?>
  <a class="kpi" href="<?= h($url(array('f' => $k))) ?>"><b><?= (int)$counts[$k] ?></b><span><?= h(strtolower($reasons[$k][0])) ?></span></a>
  <?php endforeach; ?>
  <?php if ($ws['source'] === 'manual'): ?><a class="kpi" href="<?= h($url(array('f' => 'non_scelto'))) ?>"><b><?= (int)$counts['non_scelto'] ?></b><span>non scelti a mano</span></a><?php endif; ?>
  <?php if ($counts['genere'] + $counts['pagine'] > 0): ?><div class="kpi"><b><?= (int)($counts['genere'] + $counts['pagine']) ?></b><span>fuori dai filtri</span></div><?php endif; ?>
</div>

<div class="adm-grid2">
  <form method="post" class="card stack">
    <?= $hidden ?><input type="hidden" name="action" value="ruota_settings">
    <div class="ct"><?= icon('gear', 18) ?> Cosa mettere sulla ruota</div>
    <label class="lab" for="ru-src">Libri sulla ruota</label>
    <select class="input" id="ru-src" name="source">
      <?php foreach ($src as $k => $lab): ?><option value="<?= h($k) ?>" <?= $ws['source'] === $k ? 'selected' : '' ?>><?= h($lab) ?></option><?php endforeach; ?>
    </select>
    <small class="muted">«Non ancora letti» lascia fuori da solo i libri letti o in lettura. «Tutta la libreria» li lascia dentro, ma esclude sempre quelli segnati «Escludi dalla ruota».</small>
    <div class="row2">
      <div><label class="lab" for="ru-cat">Genere</label>
        <select class="input" id="ru-cat" name="category_id"><option value="">Tutti i generi</option>
          <?php foreach (categories_all() as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$ws['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div><label class="lab" for="ru-pg">Lunghezza</label>
        <select class="input" id="ru-pg" name="max_pages"><option value="">Qualsiasi lunghezza</option>
          <?php foreach (array(150, 200, 300, 400, 500, 700) as $pg): ?><option value="<?= $pg ?>" <?= (int)$ws['max_pages'] === $pg ? 'selected' : '' ?>>Fino a <?= $pg ?> pagine</option><?php endforeach; ?>
        </select></div>
    </div>
    <div class="savebar"><button class="btn primary small" type="submit">Salva</button></div>
  </form>

  <div class="card">
    <div class="ct"><?= icon('spin', 18) ?> Estrazioni già fatte <span class="pill"><?= count($history) ?></span></div>
    <p class="sub" style="margin-top:0">I libri estratti non escono più finché non li togli dalla lista.</p>
    <?php if (!$history): ?><p class="sub">Nessuna estrazione per ora.</p><?php else: ?>
    <?php foreach (array_slice($history, 0, 6) as $hr): ?>
    <div class="fr row"><span><a class="rt" href="gestione.php?sez=libro&amp;id=<?= (int)$hr['book_id'] ?>"><?= h(str_cut($hr['title'], 46)) ?></a></span>
      <span class="sub"><?= h(date('d/m/Y', strtotime($hr['created_at']))) ?></span></div>
    <?php endforeach; ?>
    <?php if (count($history) > 6): ?><p class="sub">… e altri <?= count($history) - 6 ?>: filtra l'elenco qui sotto con «Già estratto».</p><?php endif; ?>
    <form method="post" class="inline" data-confirm="Svuotare la lista delle estrazioni? Tutti i libri estratti potranno uscire di nuovo."><?= $hidden ?><input type="hidden" name="action" value="ruota_clear">
      <button class="btn ghost small" type="submit">Svuota la lista</button></form>
    <?php endif; ?>
  </div>
</div>

<div class="card" style="margin-top:14px">
  <div class="ct">Tutti i libri e il loro stato sulla ruota</div>
  <div class="chips-prev">
    <a class="chip <?= $f === '' ? 'on' : '' ?>" href="<?= h($url(array('q' => $q))) ?>">Tutti (<?= count($all) ?>)</a>
    <?php foreach ($reasons as $k => $rs): if ($counts[$k] === 0 && $f !== $k) { continue; } ?>
    <a class="chip <?= $f === $k ? 'on' : '' ?>" href="<?= h($url(array('f' => $k, 'q' => $q))) ?>"><?= h($rs[0]) ?> (<?= (int)$counts[$k] ?>)</a>
    <?php endforeach; ?>
  </div>
  <form method="get" class="savebar" style="margin-top:6px">
    <input type="hidden" name="sez" value="ruota"><?php if ($uid !== (int)current_uid()): ?><input type="hidden" name="u" value="<?= (int)$uid ?>"><?php endif; ?>
    <?php if ($f !== ''): ?><input type="hidden" name="f" value="<?= h($f) ?>"><?php endif; ?>
    <input class="input" type="search" name="q" value="<?= h($q) ?>" placeholder="Cerca per titolo o autore" style="max-width:320px">
    <button class="btn ghost small" type="submit">Cerca</button>
  </form>
</div>

<?php if (!$rows): ?>
<div class="card center"><p class="sub">Nessun libro corrisponde.</p></div>
<?php else: ?>
<form method="post" data-bulk>
  <?= $hidden ?><input type="hidden" name="action" value="ruota_bulk">
  <div class="savebar" style="margin-top:14px">
    <span class="muted" data-bulk-count>Nessun libro selezionato</span>
    <select class="input" name="op" data-bulk-op style="max-width:260px">
      <option value="">Con i selezionati…</option>
      <option value="include">Rimetti in ruota</option>
      <option value="exclude">Escludi dalla ruota</option>
    </select>
    <button class="btn primary small" type="submit" data-bulk-go disabled>Applica</button>
  </div>
  <div class="tbl-wrap">
  <table class="tbl">
    <thead><tr>
      <th class="chk"><input type="checkbox" data-check-all aria-label="Seleziona tutti"></th>
      <th class="cv"></th><th>Libro</th><th>Stato sulla ruota</th><th>Lettura</th><th class="act"></th>
    </tr></thead>
    <tbody>
    <?php foreach ($show as $b): $why = $b['why']; ?>
    <tr>
      <td class="chk"><input type="checkbox" name="ids[]" value="<?= (int)$b['id'] ?>" data-row-check aria-label="Seleziona"></td>
      <td class="cv"><?= book_cover_html($b, 'cover xs') ?></td>
      <td><a class="rt" href="gestione.php?sez=libro&amp;id=<?= (int)$b['id'] ?>"><?= h($b['title']) ?></a><small class="muted"><?= h($b['authors']) ?><?= $b['pages'] ? ' · ' . (int)$b['pages'] . ' pag.' : '' ?></small></td>
      <td>
        <?php if ($why === 'ok'): ?><span class="pill ok">In ruota</span>
        <?php else: foreach ($b['reasons'] as $rk): ?><span class="pill <?= h($reasons[$rk][1]) ?>"><?= h($reasons[$rk][0]) ?></span><?php endforeach; endif; ?>
        <?php if ($b['spin']): ?><small class="muted">estratto il <?= h(date('d/m/Y', strtotime($b['spin']['created_at']))) ?><?= $b['spin']['outcome'] === 'in_lettura' ? ' · iniziato' : ($b['spin']['outcome'] === 'escluso' ? ' · escluso' : '') ?></small><?php endif; ?>
      </td>
      <td class="muted"><?= $b['my_status'] === 'letto' ? 'Letto' : ($b['my_status'] === 'in_lettura' ? 'In lettura' : ($b['my_status'] === 'da_leggere' ? 'Da leggere' : '—')) ?></td>
      <td class="act">
        <?php if ($why === 'ok'): ?>
          <button class="btn ghost small" type="submit" name="one" value="exclude:<?= (int)$b['id'] ?>">Escludi</button>
        <?php elseif (array_intersect($b['reasons'], array('escluso', 'estratto', 'non_scelto'))): ?>
          <button class="btn primary small" type="submit" name="one" value="include:<?= (int)$b['id'] ?>">Rimetti in ruota</button>
        <?php else: ?>
          <button class="btn ghost small" type="submit" name="one" value="exclude:<?= (int)$b['id'] ?>">Escludi</button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</form>
<?php if ($pages > 1): ?>
<div class="savebar">
  <?php if ($p > 1): ?><a class="btn ghost small" href="<?= h($url(array('f' => $f, 'q' => $q, 'p' => $p - 1))) ?>">← Precedenti</a><?php endif; ?>
  <span class="muted">Pagina <?= $p ?> di <?= $pages ?> · <?= count($rows) ?> libri</span>
  <?php if ($p < $pages): ?><a class="btn ghost small" href="<?= h($url(array('f' => $f, 'q' => $q, 'p' => $p + 1))) ?>">Successivi →</a><?php endif; ?>
</div>
<?php endif; ?>
<p class="sub">Per un libro «già letto» (fonte «Non ancora letti») o «in prestito» non c'è il pulsante «Rimetti in ruota»: cambia il suo stato di lettura dalla scheda del libro, oppure restituisci il prestito.</p>
<?php endif; ?>
