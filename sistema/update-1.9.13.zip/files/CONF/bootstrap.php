<?php
/*
 * Bootstrap comune: configurazione, sicurezza, sessione, funzioni di servizio.
 * Va incluso all'inizio di ogni pagina:  require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
 */
// Versione minima di PHP: 7.4 (le versioni precedenti non ricevono piu' aggiornamenti di sicurezza da anni)
if (PHP_VERSION_ID < 70400) {
    header('HTTP/1.1 500 Internal Server Error');
    header('Content-Type: text/html; charset=utf-8');
    exit('<!doctype html><meta charset="utf-8"><body style="font-family:Georgia,serif;background:#f3ebdd;padding:30px"><h2>PHP troppo vecchio</h2>'
        . '<p>Sul server c\'è PHP ' . htmlspecialchars(PHP_VERSION, ENT_QUOTES, 'UTF-8') . '. La Libreria di Casa richiede PHP 7.4 o successivo (consigliato 8.2, 8.3 o 8.4).</p></body>');
}
require_once dirname(__FILE__) . '/config.php';
require_once dirname(__FILE__) . '/defaults.php';
if (is_file(dirname(__FILE__) . '/version.php')) {
    require_once dirname(__FILE__) . '/version.php';
}
if (!defined('APP_VERSION')) { define('APP_VERSION', '1.0.0'); }
if (!defined('APP_DB_VERSION')) { define('APP_DB_VERSION', 1); }
// Installazione Docker: i programmi stanno nell'immagine (gli aggiornamenti si fanno aggiornando l'immagine)
if (!defined('IS_DOCKER')) { define('IS_DOCKER', getenv('LIBRERIA_DOCKER') === '1'); }
define('MAINTENANCE_FILE', DATA_DIR . '/maintenance.lock');
if (is_file(APP_ROOT . '/inc/firewall.php')) {
    require_once APP_ROOT . '/inc/firewall.php';
}

// Compatibilita' con un config.php di una versione precedente (installazione manuale)
if (!defined('LOCAL_CONFIG_FILE')) { define('LOCAL_CONFIG_FILE', DATA_DIR . '/config.local.php'); }
if (!defined('INSTALL_LOCK_FILE')) { define('INSTALL_LOCK_FILE', DATA_DIR . '/installed.lock'); }
if (!defined('CONFIG_SOURCE')) { define('CONFIG_SOURCE', 'manual'); }
if (!defined('TRUST_PROXY')) { define('TRUST_PROXY', false); }
if (!defined('INSTALL_TOKEN')) { define('INSTALL_TOKEN', ''); }

date_default_timezone_set(APP_TIMEZONE);
error_reporting(APP_DEBUG ? E_ALL : (E_ALL & ~E_NOTICE & ~E_DEPRECATED)); // in prova si vedono anche gli avvisi delle versioni future di PHP
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ob_start(); // evita errori "headers already sent" sui redirect

/* ---------- Compatibilita' con le versioni nuove di PHP (8.4, 8.5) ----------
 * imagedestroy() e curl_close() non servono piu' da PHP 8.0 e dalla 8.5 danno un avviso: si usano solo dove servono.
 */
function img_free($im)
{
    if (PHP_VERSION_ID < 80000 && $im) {
        imagedestroy($im);
    }
}

function curl_done($ch)
{
    if (PHP_VERSION_ID < 80000 && $ch) {
        curl_close($ch);
    }
}

/* ---------- Errori gravi: invece di una pagina tagliata a meta' si mostra un messaggio ---------- */
function app_shutdown_handler()
{
    $e = error_get_last();
    if (!$e || !in_array($e['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
        return;
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('HTTP/1.1 500 Internal Server Error');
        header('Content-Type: text/html; charset=utf-8');
    }
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<body style="font-family:Georgia,serif;background:#f3ebdd;color:#2b1d14;padding:24px"><div style="max-width:640px;margin:auto;background:#fbf6ec;'
       . 'border:1px solid #e2d5bf;border-radius:8px;padding:22px"><h2>Errore del server</h2>'
       . (strpos(str_replace('\\', '/', $e['file']), '/data/plugins/') !== false
           ? '<p>Un <b>plugin</b> ha causato un errore ed è stato spento. <a href="">Ricarica la pagina</a>: il sito funziona di nuovo. I dettagli sono in Gestione → Plugin.</p>'
           : '<p>Versione PHP in uso: <b>' . PHP_VERSION . '</b>. Il sito richiede PHP 7.4 o successivo (consigliato 8.2, 8.3 o 8.4).</p>')
       . '<p style="font-size:13px"><code>' . htmlspecialchars($e['message'] . ' — ' . basename($e['file']) . ':' . $e['line'], ENT_QUOTES, 'UTF-8') . '</code></p>'
       . '</div></body>';
}
register_shutdown_function('app_shutdown_handler');

/* ---------- Header di sicurezza (validi per tutte le pagine) ---------- */
function send_security_headers()
{
    if (headers_sent()) {
        return;
    }
    if (function_exists('header_remove')) {
        header_remove('X-Powered-By'); // non dice a nessuno quale versione di PHP c'e' sul server
    }
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: camera=(self), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=(), hid=(), midi=(), '
         . 'magnetometer=(), gyroscope=(), accelerometer=(), display-capture=(), browsing-topics=()');
    header('Cross-Origin-Opener-Policy: same-origin');      // le altre schede/finestre non possono controllare il sito
    header('Cross-Origin-Resource-Policy: same-origin');    // altri siti non possono incorporare file e immagini della libreria
    header('X-Permitted-Cross-Domain-Policies: none');
    header('Origin-Agent-Cluster: ?1');
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
         . "font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob:" . (defined('PAGE_EXTERNAL_IMAGES') ? ' https:' : '') . "; connect-src 'self'; media-src 'self' blob:; "
         . "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'; manifest-src 'self'; worker-src 'self'"
         . (is_https() ? '; upgrade-insecure-requests' : ''));
    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}

function is_https()
{
    if (TRUST_PROXY && isset($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
        return strtolower(trim(explode(',', $_SERVER['HTTP_X_FORWARDED_PROTO'])[0])) === 'https';
    }
    return (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
}

/* ---------- Gestione errori leggibile (niente "errore 500" muto) ---------- */
function app_exception_handler($e)
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('HTTP/1.1 500 Internal Server Error');
    }
    $msg = $e->getMessage();
    if (defined('IS_API')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('ok' => false, 'error' => APP_DEBUG ? $msg : 'Errore interno. Riprova.'));
        exit;
    }
    $hint = '';
    if (stripos($msg, "doesn't exist") !== false || stripos($msg, 'no such table') !== false || stripos($msg, 'Base table or view not found') !== false) {
        $hint = 'Le tabelle del database non esistono: importa il file <code>sql/libreria.sql</code> da phpMyAdmin.';
    } elseif (stripos($msg, 'Access denied') !== false || stripos($msg, 'Unknown database') !== false) {
        $hint = 'Controlla utente, password e nome del database in <code>CONF/config.php</code>.';
    } elseif (stripos($msg, 'Connection refused') !== false || stripos($msg, 'timed out') !== false
        || stripos($msg, 'No route') !== false || stripos($msg, 'getaddrinfo') !== false || stripos($msg, 'gone away') !== false) {
        $hint = 'Il server del database non risponde: verifica che sia acceso, l\'IP in <code>CONF/config.php</code> (DB_HOST) '
              . 'e che MySQL accetti connessioni dalla rete (bind-address) e dal firewall.';
    } elseif (stripos($msg, 'token') !== false) {
        $hint = h($msg);
    }
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>Errore</title><style>body{font-family:Georgia,serif;background:#f3ebdd;padding:24px;color:#2b1d14}'
       . '.b{max-width:640px;margin:auto;background:#fbf6ec;border:1px solid #e2d5bf;border-radius:8px;padding:22px}'
       . 'code{background:#efe2cb;padding:2px 5px;border-radius:4px}a{color:#7a1f2b}</style></head><body><div class="b">'
       . '<h2>Si è verificato un problema</h2>';
    if ($hint !== '') {
        echo '<p>' . $hint . '</p>';
    } else {
        echo '<p>Riprova tra poco. Se il problema continua avvisa l\'amministratore.</p>';
    }
    if (APP_DEBUG) {
        echo '<p><code>' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</code></p>'
           . '<p style="font-size:12px;color:#7a6552">' . htmlspecialchars($e->getFile() . ' : ' . $e->getLine(), ENT_QUOTES, 'UTF-8') . '</p>';
    }
    echo '<p><a href="index.php">Torna all\'inizio</a></p></div></body></html>';
    exit;
}
set_exception_handler('app_exception_handler');
send_security_headers();

/* ---------- Utilita' ---------- */
function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

function now()
{
    return date('Y-m-d H:i:s');
}

function client_ip()
{
    // IP reale del visitatore, anche dietro Nginx Proxy Manager e Cloudflare (vedi inc/firewall.php):
    // X-Forwarded-For viene letto solo attraverso i proxy fidati, quindi non si puo' falsificare.
    if (function_exists('fw_client')) {
        $c = fw_client();
        return substr($c['ip'], 0, 45);
    }
    return isset($_SERVER['REMOTE_ADDR']) ? substr($_SERVER['REMOTE_ADDR'], 0, 45) : '';
}

function post($key, $default = '')
{
    return isset($_POST[$key]) ? (is_string($_POST[$key]) ? trim($_POST[$key]) : $_POST[$key]) : $default;
}

function get($key, $default = '')
{
    return isset($_GET[$key]) && is_string($_GET[$key]) ? trim($_GET[$key]) : $default;
}

function str_len($s)
{
    return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s);
}

function str_cut($s, $len)
{
    $s = (string)$s;
    if (function_exists('mb_substr')) {
        return mb_substr($s, 0, $len, 'UTF-8');
    }
    return substr($s, 0, $len);
}

/* ---------- Ruoli degli utenti ---------- */
function user_roles()
{
    return array('admin', 'gestore', 'registrato');
}

function role_label($r)
{
    $l = array('admin' => 'Admin', 'gestore' => 'Gestore', 'registrato' => 'Registrato');
    return isset($l[$r]) ? $l[$r] : $r;
}

/* ---------- Email degli utenti (1.9.2) ---------- */
function users_email_ready()
{
    return (int)setting('db_version', '1') >= 12;
}

// '' se vuota o valida, altrimenti il messaggio d'errore
function email_problem($e)
{
    $e = trim((string)$e);
    if ($e === '') {
        return '';
    }
    return strlen($e) <= 190 && filter_var($e, FILTER_VALIDATE_EMAIL) !== false && !preg_match('/[\r\n<>,;]/', $e) ? '' : 'L\'indirizzo email non è valido.';
}

/* ---------- Password: Argon2id se il server lo offre, altrimenti bcrypt rinforzato ---------- */
function pw_algo()
{
    if (defined('PASSWORD_ARGON2ID')) {
        return array(PASSWORD_ARGON2ID, array('memory_cost' => 65536, 'time_cost' => 3, 'threads' => 1));
    }
    return array(PASSWORD_BCRYPT, array('cost' => 12));
}

function pw_hash($password)
{
    $a = pw_algo();
    return password_hash((string)$password, $a[0], $a[1]);
}

function pw_needs_rehash($hash)
{
    $a = pw_algo();
    return password_needs_rehash((string)$hash, $a[0], $a[1]);
}

function random_token($bytes = 16)
{
    return bin2hex(random_bytes($bytes));
}

/* ---------- Impostazioni personalizzabili ---------- */
function load_settings($reset = false)
{
    static $cache = null;
    if ($reset) {
        $cache = null;
    }
    if ($cache !== null) {
        return $cache;
    }
    $cache = array();
    $rows = db()->query('SELECT setting_key, setting_value FROM settings')->fetchAll();
    foreach ($rows as $r) {
        $cache[$r['setting_key']] = $r['setting_value'];
    }
    return $cache;
}

function setting($key, $fallback = '')
{
    $all = load_settings();
    if (isset($all[$key]) && $all[$key] !== null) {
        return (string)$all[$key];
    }
    $def = setting_defaults();
    if (isset($def[$key])) {
        return (string)$def[$key][2];
    }
    return $fallback;
}

function setting_int($key, $min = null, $max = null)
{
    $v = (int)setting($key);
    if ($min !== null && $v < $min) {
        $v = $min;
    }
    if ($max !== null && $v > $max) {
        $v = $max;
    }
    return $v;
}

function setting_save($key, $value)
{
    $pdo = db();
    $st = $pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key = ?');
    $st->execute(array($key));
    if ((int)$st->fetchColumn() > 0) {
        $pdo->prepare('UPDATE settings SET setting_value = ?, updated_at = ? WHERE setting_key = ?')->execute(array($value, now(), $key));
    } else {
        $pdo->prepare('INSERT INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?)')->execute(array($key, $value, now()));
    }
}

/* ---------- Log di sistema ---------- */
function app_log($action, $detail = '', $level = 'info', $username = null)
{
    try {
        $uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : null;
        if ($username === null) {
            $username = isset($_SESSION['username']) ? $_SESSION['username'] : (is_guest() ? 'ospite' : null);
        }
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? str_cut($_SERVER['HTTP_USER_AGENT'], 250) : '';
        db()->prepare('INSERT INTO logs (created_at, user_id, username, ip, level, action, detail, user_agent) VALUES (?,?,?,?,?,?,?,?)')
            ->execute(array(now(), $uid ? $uid : null, $username, client_ip(), $level, $action, str_cut($detail, 500), $ua));
        if (mt_rand(1, 200) === 1) { // pulizia periodica dei log vecchi
            $days = max(7, setting_int('log_retention'));
            db()->prepare('DELETE FROM logs WHERE created_at < ?')->execute(array(date('Y-m-d H:i:s', time() - $days * 86400)));
            db()->prepare('DELETE FROM login_attempts WHERE created_at < ?')->execute(array(date('Y-m-d H:i:s', time() - 30 * 86400)));
        }
    } catch (Exception $e) {
        // il log non deve mai bloccare il sito
    }
}

/* ---------- Ruoli ----------
 * admin   : controllo totale
 * gestore : tutto tranne aspetto/testi, utenti, sicurezza e controllo accessi, log
 * guest   : (facoltativo) solo consultazione della libreria
 */
function is_admin()   { return isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; }
function is_gestore() { return isset($_SESSION['role']) && $_SESSION['role'] === 'gestore'; }
// Modalita' officina (1.9.10): l'installazione serve solo a firmare e pubblicare (niente libreria, solo l'Admin)
function officina_attiva()
{
    return function_exists('setting') && setting('officina_modo', '0') === '1';
}

function is_registrato() { return isset($_SESSION['role']) && $_SESSION['role'] === 'registrato'; } // solo il sito: letture, ruota, sfide (1.9.5)
function is_guest()   { return isset($_SESSION['role']) && $_SESSION['role'] === 'guest'; }
function is_user()    { return is_admin() || is_gestore() || is_registrato(); } // utente registrato (ha la sua ruota e le sue letture)
function can_edit()   { return is_admin() || is_gestore(); }         // puo' modificare la libreria
function is_logged()  { return is_user() || is_guest(); }
function current_uid() { return isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0; }

function deny_page($text)
{
    header('HTTP/1.1 403 Forbidden');
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<body style="font-family:Georgia,serif;background:#f3ebdd;color:#2b1d14;padding:30px">'
       . '<h2>Accesso non consentito</h2><p>' . h($text) . '</p><p><a href="libreria.php" style="color:#7a1f2b">Torna alla libreria</a></p></body>';
    exit;
}

function require_login()
{
    if (!is_logged()) {
        redirect('index.php');
    }
}

function require_user()
{
    require_login();
    if (!is_user()) {
        deny_page('Questa sezione è riservata agli utenti registrati.');
    }
}

function require_editor()
{
    require_login();
    if (!can_edit()) {
        deny_page('Sezione non disponibile in sola consultazione.');
    }
}

function require_admin()
{
    require_login();
    if (!is_admin()) {
        app_log('accesso_negato', 'Pagina riservata all\'Admin: ' . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : ''), 'warn');
        deny_page('Questa sezione è riservata all\'amministratore.');
    }
}

/* ---------- CSRF ---------- */
function csrf_token()
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = random_token(16);
    }
    return $_SESSION['csrf'];
}

function csrf_field()
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

function check_csrf()
{
    // i browser moderni dicono da dove arriva la richiesta: un invio da un altro sito viene rifiutato subito
    $site = isset($_SERVER['HTTP_SEC_FETCH_SITE']) ? strtolower((string)$_SERVER['HTTP_SEC_FETCH_SITE']) : '';
    if ($site === 'cross-site') {
        throw new Exception('Richiesta proveniente da un altro sito: rifiutata.');
    }
    $token = '';
    if (isset($_POST['csrf'])) {
        $token = (string)$_POST['csrf'];
    } elseif (isset($_SERVER['HTTP_X_CSRF_TOKEN'])) {
        $token = (string)$_SERVER['HTTP_X_CSRF_TOKEN'];
    }
    $good = isset($_SESSION['csrf']) ? $_SESSION['csrf'] : '';
    if ($good === '' || !hash_equals($good, $token)) {
        throw new Exception('Sessione scaduta o token non valido. Ricarica la pagina e riprova.');
    }
}

/* ---------- Messaggi flash ---------- */
function flash($text, $type = 'success')
{
    $_SESSION['flash'] = array('text' => $text, 'type' => $type);
}

// Messaggio in piu' (per esempio di un plugin): si aggiunge a quello della pagina invece di sostituirlo (1.9.5)
function flash_add($text, $type = 'success')
{
    $_SESSION['flash_more'][] = array('text' => $text, 'type' => $type);
}

function flash_show()
{
    $all = array();
    if (!empty($_SESSION['flash'])) {
        $all[] = $_SESSION['flash'];
    }
    if (!empty($_SESSION['flash_more']) && is_array($_SESSION['flash_more'])) {
        $all = array_merge($all, array_slice($_SESSION['flash_more'], 0, 5));
    }
    unset($_SESSION['flash'], $_SESSION['flash_more']);
    $h = '';
    foreach ($all as $f) {
        $h .= '<div class="alert ' . h($f['type']) . '" role="status">' . h($f['text']) . '</div>';
    }
    return $h;
}

/* ---------- Controllo IP ammessi ---------- */
function ip_matches($ip, $rule)
{
    $rule = trim($rule);
    if ($rule === '' || $rule[0] === '#') {
        return false;
    }
    if ($rule === $ip) {
        return true;
    }
    if (substr($rule, -1) === '*' || substr($rule, -1) === '.') {   // es. 192.168.1.*  oppure 192.168.1.
        $prefix = rtrim($rule, '*');
        return strpos($ip, $prefix) === 0;
    }
    if (strpos($rule, '/') !== false && strpos($ip, ':') === false) { // CIDR IPv4, es. 192.168.1.0/24
        list($net, $bits) = explode('/', $rule, 2);
        $bits = (int)$bits;
        $ipl = ip2long($ip);
        $netl = ip2long($net);
        if ($ipl === false || $netl === false || $bits < 0 || $bits > 32) {
            return false;
        }
        $mask = $bits === 0 ? 0 : (~0 << (32 - $bits)) & 0xFFFFFFFF;
        return ($ipl & $mask) === ($netl & $mask);
    }
    return false;
}

function ip_allowed($ip, $rules_text)
{
    if (in_array($ip, array('127.0.0.1', '::1'), true)) {
        return true; // dal server stesso si entra sempre (per poter correggere un errore di configurazione)
    }
    $rules = preg_split('/[\r\n,;]+/', (string)$rules_text);
    $has = false;
    foreach ($rules as $r) {
        if (trim($r) === '' || substr(trim($r), 0, 1) === '#') {
            continue;
        }
        $has = true;
        if (ip_matches($ip, $r)) {
            return true;
        }
    }
    return !$has;
}

/* ---------- File caricati (copertine, logo, sfondo) ---------- */
function cover_url($file)
{
    return $file ? 'media.php?c=' . rawurlencode($file) : '';
}

function asset_url($file)
{
    return $file ? 'media.php?a=' . rawurlencode($file) : '';
}

/* ---------- Sessione ---------- */
if (session_id() === '' && PHP_SAPI !== 'cli') {
    ini_set('session.use_strict_mode', '1');      // non accetta identificativi di sessione inventati
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_cookies', '1');
    ini_set('session.cache_limiter', 'nocache');
    if (PHP_VERSION_ID < 80400) {
        ini_set('session.use_only_cookies', '1'); // da PHP 8.4 e' fisso (e l'impostazione e' deprecata)
    }
    session_set_cookie_params(array('lifetime' => 0, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax'));
    // con HTTPS il cookie ha il prefisso __Host-: il browser lo accetta solo sicuro, senza dominio e per tutto il sito
    session_name(is_https() ? '__Host-' . SESSION_NAME : SESSION_NAME);
    session_start();
}
if (PHP_SAPI === 'cli' && !isset($_SESSION)) {
    $_SESSION = array(); // strumenti da riga di comando: nessuna sessione vera
}
$__script = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '');

function logout_session($message = '')
{
    $_SESSION = array();
    if (PHP_SAPI !== 'cli') {
        session_regenerate_id(true);
    }
    if ($message !== '') {
        flash($message, 'warn');
    }
}

function current_user()
{
    global $CURRENT_USER;
    return $CURRENT_USER;
}

/* ---------- Installazione ----------
 * Se il sito non e' ancora installato si apre l'installazione guidata (install/).
 * Un'installazione esistente fatta a mano (es. UwAmp) viene riconosciuta da sola.
 */
function app_installed()
{
    static $state = null;
    if ($state !== null) {
        return $state;
    }
    if (is_file(INSTALL_LOCK_FILE)) {
        return $state = 'yes';
    }
    if (CONFIG_SOURCE === 'none' && DB_DRIVER !== 'sqlite') {
        return $state = 'no';
    }
    try {
        db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
        @file_put_contents(INSTALL_LOCK_FILE, date('c') . " installazione esistente riconosciuta\n");
        return $state = 'yes';
    } catch (Exception $e) {
        $msg = $e->getMessage();
        if (stripos($msg, "doesn't exist") !== false || stripos($msg, 'no such table') !== false || stripos($msg, 'Base table') !== false
            || stripos($msg, 'Unknown database') !== false) {
            return $state = 'no';
        }
        return $state = 'error'; // database non raggiungibile: si mostra l'errore, non l'installazione
    }
}

function install_url()
{
    $dir = isset($_SERVER['SCRIPT_NAME']) ? rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') : '';
    return $dir . '/install/';
}

if (PHP_SAPI !== 'cli' && !defined('IS_INSTALLER') && $__script !== 'health.php') {
    $inst = app_installed();
    if ($inst === 'no') {
        if (defined('IS_API')) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => 'Sito non ancora installato.'));
            exit;
        }
        redirect(install_url());
    }
}

// L'installazione guidata non deve toccare il database oltre questo punto
if (defined('IS_INSTALLER')) {
    return;
}

/* ---------- Struttura del database aggiornata in automatico dopo un aggiornamento ---------- */
$MIGRATION_ERROR = '';
if ((int)setting('db_version', '1') < APP_DB_VERSION) {
    require_once APP_ROOT . '/inc/migrate.php';
    $mig = db_migrate();
    load_settings(true);
    if (!$mig[0]) {
        $MIGRATION_ERROR = $mig[1];
    } elseif ($mig[1] !== '') {
        app_log('database_aggiornato', $mig[1] . ' Programmi versione ' . APP_VERSION, 'warn', '');
    }
}

// Funzioni nuove (etichette, campi, sezioni, pagine) disponibili solo con il database aggiornato
function extras_ready()
{
    return (int)setting('db_version', '1') >= 2;
}

/* ---------- Manutenzione (durante un aggiornamento) ---------- */
function maintenance_on()
{
    return is_file(MAINTENANCE_FILE) && filemtime(MAINTENANCE_FILE) > time() - 1800;
}
if (PHP_SAPI !== 'cli' && maintenance_on() && !is_admin() && !in_array($__script, array('index.php', 'media.php', 'health.php', 'icon.php', 'manifest.php'), true)) {
    header('HTTP/1.1 503 Service Unavailable');
    header('Retry-After: 120');
    if (defined('IS_API')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('ok' => false, 'error' => 'Sito in manutenzione, riprova tra qualche minuto.'));
        exit;
    }
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<body style="font-family:Georgia,serif;background:#f3ebdd;color:#2b1d14;padding:30px;text-align:center">'
       . '<h2>Torniamo subito</h2><p>' . h(setting('maintenance_text', 'Il sito è in manutenzione per un aggiornamento. Riprova tra qualche minuto.')) . '</p></body>';
    exit;
}

/* ---------- HTTPS obbligatorio (se attivato) ---------- */
if (PHP_SAPI !== 'cli' && setting('sec_force_https') === '1' && !is_https() && !in_array(client_ip(), array('127.0.0.1', '::1'), true)) {
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    if (preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $host)) {
        redirect('https://' . $host . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/'));
    }
}

/* ---------- Controllo accessi per indirizzo IP ---------- */
if (PHP_SAPI !== 'cli' && !ip_allowed(client_ip(), setting('sec_ip_allow'))) {
    if (empty($_SESSION['ip_denied_logged'])) {
        $_SESSION['ip_denied_logged'] = 1;
        app_log('ip_non_ammesso', 'Tentativo di accesso da IP non in elenco', 'alert', '');
    }
    deny_page('Il tuo dispositivo (' . client_ip() . ') non è autorizzato ad accedere a questo sito.');
}

/* ---------- Firewall: IP bloccati, nazioni, solo Cloudflare ---------- */
if (PHP_SAPI !== 'cli' && function_exists('fw_check_request')) {
    fw_check_request($__script);
}

/* ---------- Verifica utente in sessione e inattività ---------- */

if (is_logged()) {
    $idle = setting_int('sec_idle_minutes', 5, 10080) * 60;
    $max_age = setting_int('sec_session_max_hours', 1, 2160) * 3600;
    $ricordato = isset($_COOKIE['__Host-ldc_ricorda']); // dispositivo ricordato: rientra da solo, niente messaggio
    if (isset($_SESSION['last_seen']) && time() - (int)$_SESSION['last_seen'] > $idle) {
        app_log('sessione_scaduta', 'Disconnessione per inattività');
        logout_session($ricordato ? '' : 'Sei stato disconnesso per inattività. Accedi di nuovo.');
    } elseif (isset($_SESSION['login_at']) && time() - (int)$_SESSION['login_at'] > $max_age) {
        // durata massima di una sessione, anche se usata di continuo
        app_log('sessione_scaduta', 'Disconnessione per durata massima della sessione');
        logout_session($ricordato ? '' : 'Per sicurezza la sessione è scaduta: accedi di nuovo.');
    } else {
        if (!isset($_SESSION['login_at'])) {
            $_SESSION['login_at'] = time();
        }
        if (!isset($_SESSION['sid_at'])) {
            $_SESSION['sid_at'] = time();
        } elseif (time() - (int)$_SESSION['sid_at'] > 900 && PHP_SAPI !== 'cli' && !defined('IS_API')) {
            // ogni 15 minuti l'identificativo della sessione cambia (un identificativo rubato smette presto di funzionare)
            session_regenerate_id(false);
            $_SESSION['sid_at'] = time();
        }
        $_SESSION['last_seen'] = time();
    }
}

/* ---------- Dispositivo ricordato: rientro automatico (1.9.3, vedi inc/remember.php) ---------- */
if (PHP_SAPI !== 'cli' && !is_logged() && isset($_COOKIE['__Host-ldc_ricorda']) && is_file(APP_ROOT . '/inc/remember.php')) {
    require_once APP_ROOT . '/inc/remember.php';
    try {
        remember_try_login();
    } catch (Exception $e) {
        // database non pronto: si entra con la password come sempre
    }
}

$CURRENT_USER = null;
if (!empty($_SESSION['uid'])) {
    $st_chk = db()->prepare('SELECT * FROM users WHERE id = ?');
    $st_chk->execute(array((int)$_SESSION['uid']));
    $u_chk = $st_chk->fetch();
    if (!$u_chk || (int)$u_chk['active'] !== 1 || !in_array($u_chk['role'], user_roles(), true)) {
        logout_session('Il tuo account non è più attivo.');
    } elseif (isset($u_chk['session_version']) && (int)(isset($_SESSION['sv']) ? $_SESSION['sv'] : 0) !== (int)$u_chk['session_version']) {
        // "Disconnetti da tutti i dispositivi" premuto dall'Admin o dall'utente
        logout_session('La sessione è stata chiusa: accedi di nuovo.');
    } else {
        unset($u_chk['password_hash'], $u_chk['totp_secret']);
        $CURRENT_USER = $u_chk;
        $_SESSION['role'] = $u_chk['role'];
        $_SESSION['username'] = $u_chk['username'];
    }
} elseif (is_guest() && setting('guest_enabled') !== '1') {
    logout_session();
}


/* ---------- Obblighi sull'account: cambio password / verifica in due passaggi ---------- */
if ($CURRENT_USER && !in_array($__script, array('account.php', 'logout.php', 'media.php', 'manifest.php', 'icon.php'), true)) {
    if ((int)$CURRENT_USER['must_change_pw'] === 1) {
        if (defined('IS_API')) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => 'Devi prima cambiare la password.'));
            exit;
        }
        redirect('account.php?obbligo=password');
    }
    if ($CURRENT_USER['role'] === 'admin' && setting('sec_2fa_admin') === '1' && (int)$CURRENT_USER['totp_enabled'] !== 1) {
        if (defined('IS_API')) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => 'Devi prima attivare la verifica in due passaggi.'));
            exit;
        }
        redirect('account.php?obbligo=2fa');
    }
}

/* ---------- Modalita' officina: si va dritti alla pubblicazione, solo per l'Admin ---------- */
if (PHP_SAPI !== 'cli' && !defined('IS_INSTALLER') && officina_attiva() && is_logged()) {
    if (!$CURRENT_USER || $CURRENT_USER['role'] !== 'admin') {
        if (!in_array($__script, array('logout.php', 'media.php', 'manifest.php', 'icon.php'), true)) {
            logout_session('Questa installazione è un\'officina: si entra solo con un account Admin.');
            redirect('index.php');
        }
    } elseif (in_array($__script, array('index.php', 'libreria.php', 'libro.php', 'ruota.php', 'statistiche.php', 'page.php', 'aggiungi.php', 'plg.php'), true)) {
        redirect('gestione.php?sez=pubblica');
    }
}

/* ---------- Plugin firmati (vedi public_html/inc/plugins.php) ---------- */
if (is_file(APP_ROOT . '/inc/plugins.php') && !in_array($__script, array('media.php', 'health.php', 'manifest.php', 'icon.php', 'plugin_file.php'), true)
    && strpos(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '', '/install/') === false && (PHP_SAPI !== 'cli' || defined('CLI_PLUGINS'))) {
    require_once APP_ROOT . '/inc/plugins.php';
    plugins_boot();
}

/* ---------- Lavori periodici (backup automatici, pulizia del cestino) al termine della visita ---------- */
if (PHP_SAPI !== 'cli' && !in_array($__script, array('media.php', 'health.php', 'manifest.php', 'icon.php'), true)) {
    register_shutdown_function(function () {
        if (is_file(APP_ROOT . '/inc/library_tools.php')) {
            require_once APP_ROOT . '/inc/library_tools.php';
            periodic_tasks();
        }
    });
}
