<?php
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/books.php';
require_once APP_ROOT . '/inc/extras.php';
require_once APP_ROOT . '/inc/library_tools.php';
require_once APP_ROOT . '/inc/reading.php';
require_login();

$id = (int)get('id');
$b = book_get($id);
if (!$b) {
    flash('Libro non trovato.', 'error');
    redirect('libreria.php');
}
$uid = current_uid();
$edit_error = '';

// per i plugin: la lettura appena segnata come finita
function libro_lettura_finita($uid, $book_id)
{
    $st = db()->prepare("SELECT id FROM reading_sessions WHERE user_id = ? AND book_id = ? AND status = 'letto' ORDER BY id DESC LIMIT 1");
    $st->execute(array((int)$uid, (int)$book_id));
    $sid = (int)$st->fetchColumn();
    if ($sid) {
        lib_do('lettura_terminata', (int)$uid, $sid, (int)$book_id);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = post('action');
    if ($action === 'stato' && is_user()) {
        $prima = reading_ready() ? user_book_row($uid, $id)['status'] : '';
        user_book_save($uid, $id, post('status'), post('excluded') === '1');
        if (reading_ready() && post('status') === 'letto' && $prima !== 'letto' && function_exists('lib_do')) {
            libro_lettura_finita($uid, $id);
        }
        flash('Stato di lettura aggiornato.' . (reading_ready() ? reading_trophies_flash($uid) : ''));
        redirect('libro.php?id=' . $id . '#lettura');
    }
    if (is_user() && reading_ready() && in_array($action, array('progresso', 'progresso_del', 'finito', 'terminata', 'voto', 'rilettura', 'date_lettura', 'lettura_del', 'pagine_libro'), true)) {
        $back = 'libro.php?id=' . $id . '#lettura';
        if ($action === 'pagine_libro' && !can_edit()) {
            deny_page('Operazione non consentita.');
        }
        if ($action === 'pagine_libro') {
            $p = (int)post('pages');
            if ($p > 0 && $p < 100000 && can_edit()) {
                db()->prepare('UPDATE books SET pages = ?, updated_at = ? WHERE id = ?')->execute(array($p, now(), $id));
                flash('Numero di pagine salvato.');
            }
            redirect($back);
        }
        if ($action === 'progresso') {
            $when = post('read_at') !== '' ? reading_parse_dt(post('read_at')) : now();
            if ($when === null) {
                flash('Data e ora non valide (non possono essere nel futuro).', 'error');
                redirect($back);
            }
            $mode = post('mode') === 'percent' ? 'percent' : 'page';
            $r = reading_progress_add($uid, $id, $mode === 'page' ? post('value') : null, $mode === 'percent' ? post('value') : null, $when, post('note'));
            if ($r[0] && function_exists('lib_do')) {
                lib_do('avanzamento_salvato', (int)$uid, (int)$id);
            }
            flash($r[1] . ($r[0] ? reading_trophies_flash($uid) : ''), $r[0] ? 'success' : 'error');
            redirect($back);
        }
        if ($action === 'progresso_del') {
            reading_progress_delete($uid, (int)post('pid'));
            flash('Avanzamento cancellato.');
            redirect($back);
        }
        // "Lettura terminata" (1.9.12): finito senza scrivere l'ultima pagina; le pagine che mancano contano come lette adesso
        if ($action === 'terminata') {
            $open_t = reading_open_session($uid, $id);
            if ($open_t) {
                $lp = reading_last_point($open_t['id']);
                $tot = (int)$b['pages'];
                $alla_fine = $lp && (($tot > 0 && (int)$lp['page'] >= $tot) || ($lp['percent'] !== null && (float)$lp['percent'] >= 100));
                if ($lp && !$alla_fine) {
                    reading_progress_add($uid, $id, $tot > 0 ? $tot : null, $tot > 0 ? null : 100, now(), '');
                }
            }
            reading_set_status($uid, $id, 'letto', array('date' => now()));
            if (function_exists('lib_do')) {
                libro_lettura_finita($uid, $id);
            }
            flash('Complimenti, libro finito! Se vuoi, lascia un voto qui sotto.' . reading_trophies_flash($uid));
            redirect($back);
        }
        if ($action === 'finito') {
            $when = post('finished_at') !== '' ? reading_parse_dt(post('finished_at'), true) : now();
            reading_set_status($uid, $id, 'letto', array('date' => $when ? $when : now()));
            if (function_exists('lib_do')) {
                libro_lettura_finita($uid, $id);
            }
            flash('Complimenti, libro finito! Se vuoi, lascia un voto qui sotto.' . reading_trophies_flash($uid));
            redirect($back);
        }
        if ($action === 'voto') {
            if (reading_rate($uid, (int)post('sid'), post('rating'), post('review')) && function_exists('lib_do')) {
                lib_do('lettura_valutata', (int)$uid, (int)post('sid'), (int)$id);
            }
            flash('Voto salvato.' . reading_trophies_flash($uid));
            redirect($back);
        }
        if ($action === 'rilettura') {
            flash(reading_start_reread($uid, $id) ? 'Nuova lettura iniziata: buona rilettura!' : 'C\'è già una lettura in corso.');
            redirect($back);
        }
        if ($action === 'date_lettura') {
            $err = reading_session_dates($uid, (int)post('sid'), post('started_at') !== '' ? reading_parse_dt(post('started_at')) : null,
                post('finished_at') !== '' ? reading_parse_dt(post('finished_at'), true) : null, post('unknown') === '1');
            flash($err === '' ? 'Date della lettura aggiornate.' . reading_trophies_flash($uid) : $err, $err === '' ? 'success' : 'error');
            redirect($back);
        }
        if ($action === 'lettura_del') {
            reading_session_delete($uid, (int)post('sid'));
            flash('Lettura cancellata dal diario.');
            redirect($back);
        }
    }
    if (!can_edit()) {
        deny_page('Operazione non consentita.');
    }
    if ($action === 'salva') {
        $f = book_fields_from_input($_POST);
        $edit_error = book_validate($f);
        if ($edit_error === '') {
            book_update($id, $f);
            book_extras_save($id, $_POST);
            app_log('libro_modificato', '#' . $id . ' "' . $f['title'] . '"');
            $dup = books_with_isbn($f['isbn13'], $id);
            flash('Modifiche salvate.' . ($dup ? ' Attenzione: in libreria c\'è già un altro libro con lo stesso ISBN.' : ''), $dup ? 'warn' : 'success');
            redirect('libro.php?id=' . $id);
        }
    } elseif ($action === 'copertina') {
        $res = array(false, '');
        if (isset($_FILES['cover']) && $_FILES['cover']['error'] !== UPLOAD_ERR_NO_FILE) {
            $res = cover_store_upload($_FILES['cover'], $id);
        } elseif (post('cover_url') !== '') {
            $res = cover_store_from_urls(array(post('cover_url')), $id, 'public');
        } elseif (post('cover_pick') !== '') {
            $res = cover_store_from_urls(array(post('cover_pick')), $id, 'trusted');
        }
        if ($res[0]) {
            app_log('copertina_cambiata', '#' . $id . ' "' . $b['title'] . '"');
            flash('Copertina aggiornata.');
        } else {
            flash($res[1] !== '' ? $res[1] : 'Scegli un\'immagine, una foto o un indirizzo.', 'error');
        }
        redirect('libro.php?id=' . $id . '#copertina');
    } elseif ($action === 'ricarica') {
        // Completa da internet i campi vuoti, la trama (se manca o e' pubblicitaria) e la copertina (se manca)
        require_once APP_ROOT . '/inc/refill.php';
        $r = book_refill($id);
        flash($r['changed'] ? 'Aggiornato da internet: ' . implode(', ', $r['changed']) . '.' : $r['msg'], $r['changed'] ? 'success' : 'warn');
        redirect('libro.php?id=' . $id);
    } elseif ($action === 'togli_copertina') {
        cover_delete_file($b['cover_file']);
        db()->prepare('UPDATE books SET cover_file = NULL, updated_at = ? WHERE id = ?')->execute(array(now(), $id));
        flash('Copertina rimossa.');
        redirect('libro.php?id=' . $id);
    } elseif ($action === 'elimina') {
        book_trash($id);
        app_log('libro_eliminato', '#' . $id . ' "' . $b['title'] . '"' . (v12_ready() ? ' (nel cestino)' : ''), 'warn');
        flash('"' . $b['title'] . '" ' . (v12_ready() ? 'spostato nel cestino: si può recuperare da Gestione → Libri → Cestino per ' . trash_days() . ' giorni.' : 'eliminato dalla libreria.'));
        redirect('libreria.php');
    } elseif ($action === 'presta' && v12_ready()) {
        $err = loan_create($id, post('borrower'), post('contact'), post('lent_at'), post('due_at'), post('loan_notes'));
        if ($err === '') {
            app_log('prestito', '"' . $b['title'] . '" prestato a ' . post('borrower'));
            flash('Prestito registrato: "' . $b['title'] . '" a ' . post('borrower') . '.');
        } else {
            flash($err, 'error');
        }
        redirect('libro.php?id=' . $id . '#prestito');
    } elseif ($action === 'restituito' && v12_ready()) {
        $l = loan_open_for_book($id);
        if ($l) {
            db()->prepare('UPDATE loans SET returned_at = ? WHERE id = ?')->execute(array(date('Y-m-d'), (int)$l['id']));
            app_log('prestito_restituito', '"' . $b['title'] . '" da ' . $l['borrower']);
            flash('Bentornato a casa! "' . $b['title'] . '" segnato come restituito.');
        }
        redirect('libro.php?id=' . $id);
    }
}

$mine = is_user() ? user_book_row($uid, $id) : null;
$readers = db()->prepare("SELECT u.display_name, u.username, ub.status FROM user_books ub INNER JOIN users u ON u.id = ub.user_id "
    . "WHERE ub.book_id = ? AND ub.user_id <> ? AND ub.status IN ('in_lettura','letto') AND u.active = 1 ORDER BY u.display_name");
$readers->execute(array($id, $uid));
$readers = $readers->fetchAll();
$val = $edit_error !== '' ? array_merge($b, $_POST, array('isbn13' => post('isbn'))) : $b;

page_start($b['title'], 'libreria', array('back' => 'libreria.php'));
?>
<div class="book-hero">
  <?= book_cover_html($b, 'cover big') ?>
  <div class="book-head">
    <h1 class="h1 book-title"><?= h($b['title']) ?></h1>
    <?php if ($b['subtitle']): ?><div class="book-sub"><?= h($b['subtitle']) ?></div><?php endif; ?>
    <div class="book-author"><?= h($b['authors']) ?></div>
    <?php if ($mine && $mine['status'] !== ''): ?><span class="status-pill <?= h($mine['status']) ?>"><?= h(status_label($mine['status'])) ?></span><?php endif; ?>
  </div>
</div>

<?php $loan = is_user() ? loan_open_for_book($id) : null; if ($loan): $late = $loan['due_at'] && $loan['due_at'] < date('Y-m-d'); ?>
<div class="loan-box card <?= $late ? 'late' : '' ?>" id="prestito">
  <div><b>In prestito a <?= h($loan['borrower']) ?></b>
    <small>dal <?= h(date('d/m/Y', strtotime($loan['lent_at']))) ?> · <?= h(loan_status_text($loan)) ?></small></div>
  <?php if (can_edit()): ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="restituito">
    <button class="btn primary small" type="submit"><?= icon('check', 16) ?> Restituito</button></form>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="card fields">
  <?php
  $rows = array('Autore' => $b['authors'], 'Pagine' => $b['pages'], 'Editore' => $b['publisher'], 'Anno edizione' => $b['pub_year'],
      'ISBN' => $b['isbn13'] ? isbn_format($b['isbn13']) : '', 'Genere' => category_name($b['category_id']), 'Posizione' => $b['shelf'],
      'Lingua' => $b['language']);
  foreach ($rows as $k => $v): if ((string)$v === '') { continue; } ?>
    <div class="fr"><span class="fk"><?= h($k) ?></span><span class="fv"><?= h($v) ?></span></div>
  <?php endforeach; ?>
  <?php foreach (book_extras_display($id) as $x): ?>
    <div class="fr"><span class="fk"><?= h($x[0]) ?></span><span class="fv"><?= $x[1] ?></span></div>
  <?php endforeach; ?>
</div>

<?php if ($readers): ?>
<div class="readers sub"><?= icon('user', 14) ?>
  <?php $parts = array(); foreach ($readers as $r) { $parts[] = h($r['display_name'] !== '' ? $r['display_name'] : $r['username']) . ' <em>(' . h(strtolower(status_label($r['status']))) . ')</em>'; } echo implode(', ', $parts); ?>
</div>
<?php endif; ?>

<?php if ($b['description']): ?>
<details class="card desc"><summary>Trama e descrizione</summary><p><?= nl2br(h($b['description'])) ?></p></details>
<?php endif; ?>
<?php if ($b['notes']): ?>
<div class="card"><div class="fk">Note</div><p><?= nl2br(h($b['notes'])) ?></p></div>
<?php endif; ?>

<?php if (function_exists('lib_filter')) { echo (string)lib_filter('scheda_libro', '', $b); } ?>

<?php if ($mine): include APP_ROOT . '/inc/libro_lettura.php'; endif; ?>

<?php if (can_edit()): ?>
<details class="card" id="modifica" <?= $edit_error !== '' ? 'open' : '' ?>>
  <summary><?= icon('edit', 16) ?> Modifica dati</summary>
  <?php if ($edit_error !== ''): ?><div class="alert error"><?= h($edit_error) ?></div><?php endif; ?>
  <form method="post" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="salva">
    <?php include APP_ROOT . '/inc/book_form_fields.php'; ?>
    <button class="btn primary" type="submit">Salva modifiche</button>
  </form>
  <?php if (1): ?>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="action" value="ricarica">
    <button class="btn ghost" type="submit"><?= icon('cloud', 18) ?> Cerca online copertina, trama e dati mancanti</button>
  </form>
  <?php endif; ?>
</details>

<?php if (v12_ready() && !$loan): ?>
<details class="card" id="prestito">
  <summary><?= icon('user', 16) ?> Presta questo libro</summary>
  <form method="post" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="presta">
    <label class="lab" for="ln-who">A chi</label>
    <input class="input" id="ln-who" name="borrower" maxlength="120" required list="ln-people" placeholder="es. Marco">
    <datalist id="ln-people"><?php foreach (loan_borrowers() as $p): ?><option value="<?= h($p['borrower']) ?>"><?php endforeach; ?></datalist>
    <label class="lab" for="ln-contact">Telefono o email (facoltativo)</label>
    <input class="input" id="ln-contact" name="contact" maxlength="120">
    <div class="row2">
      <div><label class="lab" for="ln-from">Dal</label><input class="input" type="date" id="ln-from" name="lent_at" value="<?= h(date('Y-m-d')) ?>"></div>
      <div><label class="lab" for="ln-due">Da restituire entro</label><input class="input" type="date" id="ln-due" name="due_at" value="<?= h(date('Y-m-d', strtotime('+30 days'))) ?>"></div>
    </div>
    <button class="btn primary" type="submit">Registra il prestito</button>
  </form>
</details>
<?php endif; ?>

<details class="card" id="copertina">
  <summary><?= icon('image', 16) ?> Cambia copertina</summary>
  <form method="post" enctype="multipart/form-data" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="copertina">
    <?php if ($b['isbn13']): ?>
    <div class="cover-options" data-cover-options data-isbn="<?= h($b['isbn13']) ?>">
      <button class="btn ghost" type="button" data-find-covers><?= icon('cloud', 18) ?> Cerca copertine online</button>
      <div class="cover-picks"></div>
    </div>
    <?php endif; ?>
    <label class="lab" for="cv-file">Foto o immagine dal telefono</label>
    <input class="input" type="file" id="cv-file" name="cover" accept="image/*" capture="environment">
    <label class="lab" for="cv-url">Oppure indirizzo di un'immagine sul web</label>
    <input class="input" type="url" id="cv-url" name="cover_url" placeholder="https://…">
    <button class="btn primary" type="submit">Usa questa copertina</button>
  </form>
  <?php if ($b['cover_file']): ?>
  <form method="post" data-confirm="Rimuovere la copertina?"><?= csrf_field() ?><input type="hidden" name="action" value="togli_copertina">
    <button class="btn link" type="submit">Rimuovi la copertina attuale</button></form>
  <?php endif; ?>
</details>

<form method="post" class="danger-zone" data-confirm="<?= v12_ready() ? 'Spostare &quot;' . h($b['title']) . '&quot; nel cestino? Potrai recuperarlo per ' . trash_days() . ' giorni.' : 'Eliminare definitivamente &quot;' . h($b['title']) . '&quot; dalla libreria? L\'operazione vale per tutti gli utenti.' ?>">
  <?= csrf_field() ?><input type="hidden" name="action" value="elimina">
  <button class="btn danger-ghost" type="submit"><?= icon('trash', 16) ?> Elimina dalla libreria</button>
</form>
<?php endif; ?>
<p class="meta">Aggiunto il <?= h(date('d/m/Y', strtotime($b['created_at']))) ?><?= $b['source'] ? ' · fonte: ' . h($b['source']) : '' ?></p>
<?php page_end(array('js/libro.js')); ?>
