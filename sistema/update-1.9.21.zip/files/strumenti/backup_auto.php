<?php
/*
 * Backup automatico da riga di comando, da usare con il cron del server se preferisci un orario preciso
 * (altrimenti il sito lo fa da solo alla prima visita utile).
 *   php strumenti/backup_auto.php          crea il backup solo se e' il momento (Gestione → Backup → Backup automatici)
 *   php strumenti/backup_auto.php --ora    lo crea subito
 * Senza --ora fa tutti i lavori automatici del sito (vedi strumenti/lavori.php).
 */
if (PHP_SAPI !== 'cli') {
    exit("Da usare solo da riga di comando.\n");
}
$force = in_array('--ora', $argv, true);
if (!$force) {
    // dalla 1.9.15 il cron fa tutti i lavori automatici (aggiornamenti, avvisi, plugin...), non solo il backup:
    // le installazioni che chiamano ancora questo file ogni 15 minuti continuano a funzionare
    require dirname(__FILE__) . '/lavori.php';
    exit(0);
}
require dirname(dirname(__FILE__)) . '/CONF/bootstrap.php';
require_once APP_ROOT . '/inc/library_tools.php';
if (!$force && setting('auto_backup', 'off') === 'off') {
    echo "I backup automatici sono disattivati (Gestione → Strumenti → Backup). Usa --ora per crearne uno adesso.\n";
    exit(0);
}
$f = auto_backup_run($force);
echo $f !== '' ? "Backup creato: $f\n" : "Non è ancora il momento del prossimo backup.\n";
$n = trash_auto_purge();
if ($n) {
    echo "Cestino: $n libri eliminati definitivamente.\n";
}
if (function_exists('fw_geo_due') && fw_geo_due()) {
    $g = fw_geo_update();
    echo 'Database delle nazioni: ' . $g[1] . "\n";
}
