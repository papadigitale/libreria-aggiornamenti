<?php
/*
 * LAVORI AUTOMATICI del sito, da far partire con il cron del server ogni 15 minuti (1.9.15).
 * Fa tutto quello che il sito altrimenti fa "alla prima visita utile":
 *   backup automatico e copie esterne, controllo del repository degli aggiornamenti, avvisi giornalieri (prestiti scaduti),
 *   lavori giornalieri dei plugin, pulizia del cestino, database delle nazioni del firewall.
 * Ogni lavoro parte solo quando e' il suo momento: lanciarlo spesso non costa niente.
 *
 *   php strumenti/lavori.php            fa i lavori in scadenza
 *   php strumenti/lavori.php --repo     in piu' controlla subito il repository
 *
 * Proxmox/Debian (lo script di installazione lo configura da solo), file /etc/cron.d/libreria:
 *   (asterisco)/15 * * * * www-data php /var/www/libreria/strumenti/lavori.php >/dev/null 2>&1
 */
if (PHP_SAPI !== 'cli') {
    header('HTTP/1.1 403 Forbidden');
    exit("Da usare solo da riga di comando.\n");
}
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
define('CLI_PLUGINS', true); // anche i lavori giornalieri dei plugin
require dirname(dirname(__FILE__)) . '/CONF/bootstrap.php';
require_once APP_ROOT . '/inc/library_tools.php';
if (in_array('--repo', $argv, true) && is_file(APP_ROOT . '/inc/repo.php')) {
    require_once APP_ROOT . '/inc/repo.php';
    setting_save('repo_checked_at', '0');
    load_settings(true);
}
$fatto = periodic_tasks(true);
echo $fatto ? implode("\n", $fatto) . "\n" : "Niente da fare adesso.\n";
