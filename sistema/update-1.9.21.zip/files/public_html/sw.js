/*
 * Libreria di Casa: service worker per le notifiche sul telefono (1.9.16, icona piccola per Android 1.9.20).
 * Riceve le notifiche anche a sito chiuso e le mostra; se il sito e' aperto e in primo piano
 * non mostra niente: avvisa la pagina, che fa il suo suono e aggiorna la campanella.
 * Non mette niente in cache: il sito si apre sempre aggiornato.
 */
'use strict';

self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });

function assoluto(u) {
  try { return new URL(u || 'notifiche.php', self.registration.scope).href; } catch (e) { return self.registration.scope; }
}

self.addEventListener('push', function (e) {
  var d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { testo: e.data ? e.data.text() : '' }; }
  var titolo = d.titolo || 'Libreria di Casa';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (cl) {
    var davanti = cl.some(function (c) { return c.focused && c.visibilityState === 'visible'; });
    cl.forEach(function (c) { c.postMessage({ tipo: 'avviso', testo: d.testo || '', url: d.url || '', davanti: davanti }); });
    if (davanti && d.tipo !== 'prova') { return null; }
    return self.registration.showNotification(titolo, {
      body: d.testo || '',
      icon: assoluto(d.icona || 'icon.php?s=192'),
      badge: assoluto('img/badge-96.png'), // Android: figura bianca su fondo trasparente (1.9.20)
      tag: d.tag || undefined,
      renotify: !!d.tag,
      timestamp: Date.now(),
      data: { url: assoluto(d.url) }
    });
  }));
});

self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  var url = (e.notification.data && e.notification.data.url) || assoluto('notifiche.php');
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (cl) {
    for (var i = 0; i < cl.length; i++) {
      var c = cl[i];
      if (c.url.indexOf(self.registration.scope) === 0 && 'focus' in c) {
        return c.focus().then(function (f) { return f && 'navigate' in f ? f.navigate(url) : null; });
      }
    }
    return self.clients.openWindow ? self.clients.openWindow(url) : null;
  }));
});
