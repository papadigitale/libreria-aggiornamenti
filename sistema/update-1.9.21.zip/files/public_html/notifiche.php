<?php
/* Tutti gli avvisi (la campanella): aprendo la pagina diventano letti */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/notifiche.php';
require_user();
$uid = current_uid();
$items = notif_elenco($uid, 100);
notif_segna_lette($uid);
page_start('Avvisi', 'avvisi', array('back' => 'libreria.php'));
?>
<div class="notif-page">
  <div class="notif-top"><h1 class="h1">Avvisi</h1><a class="link" href="account.php#avvisi">Scegli quali ricevere</a></div>
  <?php if (!notif_ready()): ?>
    <div class="card"><p class="sub">Il database non è ancora aggiornato.</p></div>
  <?php elseif (!$items): ?>
    <div class="card notif-empty"><?= icon('bell', 28) ?><p class="sub">Nessun avviso. Qui arrivano le letture e i voti degli altri, i libri nuovi e, per l'Admin, aggiornamenti e problemi da sistemare.</p></div>
  <?php else: ?>
  <div class="card notif-list">
    <?php foreach ($items as $r): $link = notif_link_ok($r['link']) ? $r['link'] : ''; ?>
    <<?= $link !== '' ? 'a href="' . h($link) . '"' : 'div' ?> class="notif-i<?= $r['read_at'] === null ? ' new' : '' ?>">
      <?php if (!empty($r['cover_file'])): ?><img class="notif-cov" src="<?= h(cover_url($r['cover_file'])) ?>" alt="" loading="lazy">
      <?php else: ?><span class="notif-ico k-<?= h($r['kind']) ?>"><?= icon($r['kind'] === 'aggiornamenti' ? 'spin' : ($r['kind'] === 'sicurezza' ? 'shield' : ($r['kind'] === 'backup' ? 'data' : ($r['kind'] === 'prestiti' ? 'share' : ($r['kind'] === 'nuovi_libri' ? 'books' : 'bell')))), 18) ?></span><?php endif; ?>
      <span class="notif-t"><?= h($r['text']) ?><small><?= h(notif_quando($r['updated_at'])) ?></small></span>
    </<?= $link !== '' ? 'a' : 'div' ?>>
    <?php endforeach; ?>
  </div>
  <p class="hint">Gli avvisi restano 60 giorni.</p>
  <?php endif; ?>
</div>
<?php page_end(); ?>
