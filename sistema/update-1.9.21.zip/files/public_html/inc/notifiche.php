<?php
/*
 * Avvisi (la campanella, 1.9.14).
 * Ogni avviso e' una riga per destinatario. Avvisi simili non letti si raggruppano ("Marta ha finito 3 libri").
 * Ognuno sceglie in Il mio account quali tipi ricevere; chi spegne "Mostra le mie letture agli altri" non genera avvisi su di se'.
 * Gli avvisi restano 60 giorni.
 */

function notif_ready()
{
    return (int)setting('db_version', '1') >= 14;
}

// Tipi: chiave => array(nome, descrizione, a chi: tutti | editore | admin)
function notif_tipi()
{
    return array(
        'letture'       => array('Letture degli altri', 'Chi inizia, finisce o abbandona un libro', 'tutti'),
        'meta'          => array('A metà libro', 'Quando qualcuno arriva a metà di un libro', 'tutti'),
        'voti'          => array('Voti e recensioni', 'Le stelle e le recensioni degli altri', 'tutti'),
        'nuovi_libri'   => array('Nuovi libri in libreria', 'Quando arriva un libro nuovo', 'tutti'),
        'plugin'        => array('Dalle funzioni aggiuntive', 'Sfide completate, liste dei desideri condivise con te e simili', 'tutti'),
        'prestiti'      => array('Prestiti scaduti', 'Libri prestati che dovevano già tornare', 'editore'),
        'aggiornamenti' => array('Aggiornamenti', 'Nuova versione del sistema o dei plugin nel repository', 'admin'),
        'backup'        => array('Backup', 'Backup automatico o copia esterna non riusciti', 'admin'),
        'sicurezza'     => array('Sicurezza', 'Attacchi, accessi sospetti, blocchi, plugin bloccati', 'admin'),
    );
}

function notif_tipo_per($kind, $role)
{
    $t = notif_tipi();
    if (!isset($t[$kind])) {
        return false;
    }
    $a = $t[$kind][2];
    return $a === 'tutti' || ($a === 'editore' && in_array($role, array('admin', 'gestore'), true)) || ($a === 'admin' && $role === 'admin');
}

function notif_prefs($u)
{
    $p = isset($u['notify_prefs']) ? json_decode((string)$u['notify_prefs'], true) : null;
    return is_array($p) ? $p : array();
}

function notif_nome($u)
{
    return $u ? ((string)$u['display_name'] !== '' ? $u['display_name'] : $u['username']) : 'Qualcuno';
}

function notif_utente($uid)
{
    $st = db()->prepare('SELECT id, username, display_name, role, active, share_reading, notify_prefs FROM users WHERE id = ?');
    $st->execute(array((int)$uid));
    $u = $st->fetch();
    return $u ? $u : null;
}

// Le letture e i voti di questo utente si possono mostrare agli altri?
function notif_condivide($uid)
{
    if (!notif_ready()) {
        return true;
    }
    $u = notif_utente($uid);
    return $u && (int)$u['share_reading'] === 1;
}

// Pezzo di SQL per nascondere gli utenti che non condividono le letture (alias della tabella users)
function notif_sql_condivide($alias = 'u')
{
    return notif_ready() ? ' AND ' . $alias . '.share_reading = 1' : '';
}

/*
 * Crea un avviso.
 * $opts: actor (id di chi lo causa: non lo riceve e, per letture/voti, niente avviso se non condivide),
 *        book, to (elenco di id: solo loro), gruppo (chiave per raggruppare), testo_gruppo (con {n}), sostituisci (true: stessa chiave = stesso avviso aggiornato)
 */
function notif_invia($kind, $testo, $link = '', $opts = array())
{
    if (!notif_ready() || !empty($GLOBALS['NOTIF_SILENZIO'])) {
        return 0;
    }
    try {
        $actor = isset($opts['actor']) ? (int)$opts['actor'] : 0;
        if ($actor && in_array($kind, array('letture', 'meta', 'voti'), true) && !notif_condivide($actor)) {
            return 0;
        }
        $in = "'" . implode("','", user_roles()) . "'";
        if (is_file(APP_ROOT . '/inc/push.php')) {
            require_once APP_ROOT . '/inc/push.php';
        }
        $push = function_exists('push_attivo') && push_attivo();
        $users = db()->query('SELECT id, role, notify_prefs' . ($push ? ', push_prefs' : '') . ' FROM users WHERE active = 1 AND role IN (' . $in . ')')->fetchAll();
        $solo = isset($opts['to']) ? array_map('intval', (array)$opts['to']) : null;
        $now = now();
        $n = 0;
        foreach ($users as $u) {
            $id = (int)$u['id'];
            if (($actor && $id === $actor) || ($solo !== null && !in_array($id, $solo, true)) || !notif_tipo_per($kind, $u['role'])) {
                continue;
            }
            $p = notif_prefs($u);
            if (isset($p[$kind]) && !$p[$kind]) {
                continue;
            }
            $g = isset($opts['gruppo']) ? str_cut((string)$opts['gruppo'], 120) : '';
            if ($g !== '') {
                $st = db()->prepare('SELECT id, count FROM notifications WHERE user_id = ? AND group_key = ? AND read_at IS NULL AND updated_at >= ? ORDER BY id DESC LIMIT 1');
                $st->execute(array($id, $g, date('Y-m-d H:i:s', time() - 86400)));
                $old = $st->fetch();
                if ($old) {
                    $c = !empty($opts['sostituisci']) ? (int)$old['count'] : (int)$old['count'] + 1;
                    $t = !empty($opts['sostituisci']) || empty($opts['testo_gruppo']) ? $testo : str_replace('{n}', (string)$c, $opts['testo_gruppo']);
                    db()->prepare('UPDATE notifications SET count = ?, text = ?, link = ?, book_id = ?, updated_at = ? WHERE id = ?')
                        ->execute(array($c, str_cut($t, 400), str_cut($link, 255), isset($opts['book']) ? (int)$opts['book'] : null, $now, (int)$old['id']));
                    if ($push) {
                        push_accoda($u, $kind, $t, $link, $g); // anche sul telefono (1.9.16)
                    }
                    $n++;
                    continue;
                }
            }
            db()->prepare('INSERT INTO notifications (user_id, kind, actor_id, book_id, text, link, group_key, count, created_at, updated_at) VALUES (?,?,?,?,?,?,?,1,?,?)')
                ->execute(array($id, $kind, $actor ? $actor : null, isset($opts['book']) ? (int)$opts['book'] : null, str_cut($testo, 400), str_cut($link, 255), $g !== '' ? $g : null, $now, $now));
            if ($push) {
                push_accoda($u, $kind, $testo, $link, $g !== '' ? $g : 'n' . db()->lastInsertId());
            }
            $n++;
        }
        if (mt_rand(1, 100) === 1) {
            db()->prepare('DELETE FROM notifications WHERE updated_at < ?')->execute(array(date('Y-m-d H:i:s', time() - 60 * 86400)));
        }
        return $n;
    } catch (Exception $e) {
        return 0; // un avviso non deve mai bloccare il sito
    }
}

function notif_non_lette($uid)
{
    if (!notif_ready()) {
        return 0;
    }
    $st = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL');
    $st->execute(array((int)$uid));
    return (int)$st->fetchColumn();
}

function notif_elenco($uid, $quanti = 40)
{
    if (!notif_ready()) {
        return array();
    }
    $st = db()->prepare('SELECT n.id, n.kind, n.text, n.link, n.count, n.read_at, n.updated_at, n.book_id, b.cover_file, b.title, b.authors FROM notifications n '
        . 'LEFT JOIN books b ON b.id = n.book_id WHERE n.user_id = ? ORDER BY n.updated_at DESC, n.id DESC LIMIT ' . (int)$quanti);
    $st->execute(array((int)$uid));
    return $st->fetchAll();
}

function notif_segna_lette($uid)
{
    if (notif_ready()) {
        db()->prepare('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL')->execute(array(now(), (int)$uid));
    }
}

function notif_quando($dt)
{
    $s = time() - strtotime($dt);
    if ($s < 90) {
        return 'adesso';
    }
    if ($s < 3600) {
        return (int)round($s / 60) . ' min fa';
    }
    if ($s < 86400) {
        return (int)round($s / 3600) . ' h fa';
    }
    if ($s < 172800) {
        return 'ieri';
    }
    return date('d/m', strtotime($dt));
}

// Solo indirizzi interni del sito
function notif_link_ok($l)
{
    return (bool)preg_match('#^(?![a-z]+:)(?!//)[A-Za-z0-9_./?=&%\-\#]+$#i', (string)$l);
}

function notif_stelle($r)
{
    $r = round((float)$r * 2) / 2;
    return str_repeat('★', (int)floor($r)) . ($r - floor($r) >= .5 ? '½' : '');
}

/* ---------------- Eventi del sito ---------------- */

function notif_libro($book_id)
{
    $st = db()->prepare('SELECT id, title, authors FROM books WHERE id = ?');
    $st->execute(array((int)$book_id));
    $b = $st->fetch();
    return $b ? $b : null;
}

// Cambio di stato di lettura fatto dall'utente stesso
function notif_lettura($uid, $book_id, $stato)
{
    $verbi = array('in_lettura' => array('ha iniziato', 'ha iniziato {n} libri'), 'letto' => array('ha finito', 'ha finito {n} libri'),
        'abbandonato' => array('ha abbandonato', 'ha abbandonato {n} libri'));
    if (!isset($verbi[$stato]) || (int)$uid !== current_uid()) {
        return;
    }
    $b = notif_libro($book_id);
    $u = notif_utente($uid);
    if (!$b || !$u) {
        return;
    }
    $nome = notif_nome($u);
    notif_invia('letture', $nome . ' ' . $verbi[$stato][0] . ' «' . $b['title'] . '»', 'libro.php?id=' . (int)$b['id'], array(
        'actor' => (int)$uid, 'book' => (int)$b['id'], 'gruppo' => 'lett:' . (int)$uid . ':' . $stato . ':' . date('Y-m-d'),
        'testo_gruppo' => $nome . ' ' . $verbi[$stato][1] . ', l\'ultimo è «' . $b['title'] . '»'));
}

function notif_meta($uid, $book_id)
{
    if ((int)$uid !== current_uid()) {
        return;
    }
    $b = notif_libro($book_id);
    $u = notif_utente($uid);
    if ($b && $u) {
        notif_invia('meta', notif_nome($u) . ' è a metà di «' . $b['title'] . '»', 'libro.php?id=' . (int)$b['id'],
            array('actor' => (int)$uid, 'book' => (int)$b['id'], 'gruppo' => 'meta:' . (int)$uid . ':' . (int)$b['id'], 'sostituisci' => true));
    }
}

function notif_voto($uid, $book_id, $rating, $review)
{
    if ((int)$uid !== current_uid() || ((float)$rating <= 0 && trim((string)$review) === '')) {
        return;
    }
    $b = notif_libro($book_id);
    $u = notif_utente($uid);
    if (!$b || !$u) {
        return;
    }
    $t = notif_nome($u) . ((float)$rating > 0 ? ' ha dato ' . notif_stelle($rating) . ' a' : ' ha recensito') . ' «' . $b['title'] . '»';
    $rv = trim(preg_replace('/\s+/', ' ', (string)$review));
    if ($rv !== '') {
        $t .= ': “' . str_cut($rv, 120) . (mb_strlen($rv, 'UTF-8') > 120 ? '…' : '') . '”';
    }
    notif_invia('voti', $t, 'libro.php?id=' . (int)$b['id'] . '#lettura',
        array('actor' => (int)$uid, 'book' => (int)$b['id'], 'gruppo' => 'voto:' . (int)$uid . ':' . (int)$b['id'], 'sostituisci' => true));
}

function notif_nuovo_libro($book_id)
{
    $b = notif_libro($book_id);
    if (!$b) {
        return;
    }
    $a = trim(explode(',', (string)$b['authors'])[0]);
    notif_invia('nuovi_libri', 'Nuovo libro in libreria: «' . $b['title'] . '»' . ($a !== '' ? ' di ' . $a : ''), 'libro.php?id=' . (int)$b['id'], array(
        'actor' => current_uid(), 'book' => (int)$b['id'], 'gruppo' => 'nuovi:' . date('Y-m-d'),
        'testo_gruppo' => '{n} nuovi libri in libreria, l\'ultimo è «' . $b['title'] . '»'));
}

// Dal registro: gli eventi di sicurezza e i problemi importanti arrivano all'Admin
function notif_da_log($action, $detail, $level)
{
    static $mappa = array(
        'firewall_attacco' => 'Attacco in corso',
        'firewall_blocco' => null, // raggruppati: "N indirizzi bloccati oggi"
        'passkey_sospetta' => 'Chiave di accesso sospetta',
        'dispositivo_sospetto' => 'Dispositivo ricordato usato da un\'altra parte: dispositivi dimenticati',
        'blocco_attivato' => 'Account bloccato per troppi tentativi',
        'plugin_bloccato' => 'Plugin bloccato: file modificati',
        'plugin_errore' => 'Plugin spento per un errore',
        'repository' => 'Problema con il repository degli aggiornamenti',
        'aggiornamento_fallito' => 'Aggiornamento non riuscito',
        'firma_passphrase_errata' => 'Passphrase della chiave sbagliata',
        'chiave_autore' => 'Chiave dell\'autore impostata',
        'chiave_privata_importata' => 'Chiave privata importata',
        'chiave_privata_scaricata' => 'Copia della chiave privata scaricata',
        'chiave_privata_tolta' => 'Chiave privata tolta dal server',
        'aggiornamento_password_errata' => 'Password sbagliata alla conferma di un aggiornamento',
        'backup_invio_fallito' => 'Copia del backup non riuscita',
        'backup_automatico_fallito' => 'Backup automatico non riuscito',
        'aggiornamento_disponibile' => 'Aggiornamento disponibile',
    );
    if (!array_key_exists($action, $mappa) || !notif_ready()) {
        return;
    }
    $kind = strpos($action, 'backup') === 0 ? 'backup' : ($action === 'aggiornamento_disponibile' ? 'aggiornamenti' : 'sicurezza');
    $link = $kind === 'backup' ? 'gestione.php?sez=destinazioni' : ($kind === 'aggiornamenti' ? 'gestione.php?sez=aggiornamento#repository' : 'gestione.php?sez=log');
    if ($action === 'firewall_blocco') {
        notif_invia('sicurezza', 'Il firewall ha bloccato un indirizzo IP', 'gestione.php?sez=blocchi',
            array('gruppo' => 'fw:' . date('Y-m-d'), 'testo_gruppo' => 'Il firewall ha bloccato {n} indirizzi IP oggi'));
        return;
    }
    $t = $action === 'aggiornamento_disponibile' ? str_cut((string)$detail, 200) : $mappa[$action] . ($detail !== '' ? ': ' . str_cut((string)$detail, 160) : '');
    notif_invia($kind, $t, $link, array('gruppo' => 'log:' . $action . ':' . date('Y-m-d'), 'sostituisci' => true));
}

// Una volta al giorno: prestiti scaduti (ognuno avvisato una volta sola)
function notif_prestiti_scaduti()
{
    if (!notif_ready()) {
        return;
    }
    try {
        $visti = json_decode((string)setting('notif_prestiti_visti', '[]'), true);
        $visti = is_array($visti) ? $visti : array();
        $st = db()->prepare('SELECT l.id, l.borrower, l.due_at, b.id AS book_id, b.title FROM loans l JOIN books b ON b.id = l.book_id WHERE l.returned_at IS NULL AND l.due_at IS NOT NULL AND l.due_at < ?');
        $st->execute(array(date('Y-m-d')));
        $aperti = array();
        foreach ($st->fetchAll() as $l) {
            $aperti[] = (int)$l['id'];
            if (!in_array((int)$l['id'], $visti, true)) {
                notif_invia('prestiti', 'Prestito scaduto: «' . $l['title'] . '» a ' . $l['borrower'] . ' doveva tornare il ' . date('d/m/Y', strtotime($l['due_at'])),
                    'gestione.php?sez=prestiti', array('book' => (int)$l['book_id']));
            }
        }
        setting_save('notif_prestiti_visti', json_encode($aperti));
        load_settings(true);
    } catch (Exception $e) {
        // tabella dei prestiti assente su database vecchi
    }
}
