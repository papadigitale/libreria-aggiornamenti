<?php
/*
 * Notifiche sul telefono (Web Push, 1.9.16).
 *
 * Tutto quello che arriva nella campanella (inc/notifiche.php) puo' arrivare anche come notifica del telefono o del computer,
 * anche a sito chiuso. Ognuno la attiva sui propri dispositivi (Il mio account) e sceglie i tipi e un orario di silenzio;
 * l'Admin ha l'interruttore generale (Gestione → Sistema → Notifiche sul telefono).
 *
 * Standard usati, scritti qui senza librerie esterne (servono solo OpenSSL e cURL di PHP):
 *  - VAPID (RFC 8292): il sito si presenta ai servizi di notifica (Google, Apple, Mozilla, Microsoft) con una sua coppia di chiavi;
 *  - cifratura del messaggio (RFC 8291, aes128gcm): il servizio di notifica non puo' leggere il testo.
 * Gli invii partono dopo aver consegnato la pagina, per non rallentare chi naviga.
 */

define('PUSH_TTL', 86400);

function push_ready()
{
    return (int)setting('db_version', '1') >= 15;
}

// Interruttore generale dell'Admin (acceso se non e' mai stato toccato)
function push_acceso()
{
    return push_ready() && setting('push_on', '1') === '1' && !officina_attiva();
}

function push_supportato()
{
    return function_exists('openssl_pkey_new') && function_exists('openssl_pkey_derive') && function_exists('hash_hkdf')
        && in_array('aes-128-gcm', array_map('strtolower', openssl_get_cipher_methods()), true);
}

function push_attivo()
{
    if (!push_acceso() || !push_supportato()) {
        return false;
    }
    if (push_chiave_pubblica() === '') {
        try {
            push_crea_chiavi(); // la prima volta: il sito si crea le sue chiavi da solo
        } catch (Exception $e) {
            return false;
        }
    }
    return push_chiave_pubblica() !== '';
}

/* ---------------- Base64 per gli indirizzi (senza = + /) ---------------- */

function push_b64e($bin)
{
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

function push_b64d($s)
{
    $s = strtr((string)$s, '-_', '+/');
    $r = base64_decode($s . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
    return $r === false ? '' : $r;
}

/* ---------------- Chiavi VAPID del sito ---------------- */

// Chiave pubblica (65 byte, in base64url) da dare al browser; '' se non c'e' ancora
function push_chiave_pubblica()
{
    return (string)setting('push_vapid_pub', '');
}

function push_chiave_privata()
{
    $enc = (string)setting('push_vapid_priv', '');
    if ($enc === '') {
        return null;
    }
    $pem = sec_decrypt($enc, 'push-vapid');
    $k = $pem !== '' ? @openssl_pkey_get_private($pem) : false;
    return $k ? $k : null;
}

// Coppia di chiavi su curva P-256: array(pem_privata, pubblica_grezza_65_byte)
function push_ec_nuova()
{
    $k = openssl_pkey_new(array('curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC));
    if (!$k) {
        throw new Exception('OpenSSL non riesce a creare le chiavi (curva P-256 non disponibile).');
    }
    openssl_pkey_export($k, $pem);
    $d = openssl_pkey_get_details($k);
    return array($pem, push_ec_punto($d), $k);
}

function push_ec_punto($details)
{
    $x = str_pad($details['ec']['x'], 32, "\0", STR_PAD_LEFT);
    $y = str_pad($details['ec']['y'], 32, "\0", STR_PAD_LEFT);
    return "\x04" . $x . $y;
}

// Crea le chiavi del sito (la prima volta, o per cambiarle: i dispositivi gia' iscritti vanno riattivati)
function push_crea_chiavi()
{
    require_once APP_ROOT . '/inc/crypto.php';
    list($pem, $pub) = push_ec_nuova();
    setting_save('push_vapid_priv', sec_encrypt($pem, 'push-vapid'));
    setting_save('push_vapid_pub', push_b64e($pub));
    load_settings(true);
}

function push_chiavi_garantite()
{
    if (push_chiave_pubblica() === '' && push_supportato()) {
        push_crea_chiavi();
    }
    return push_chiave_pubblica() !== '';
}

// Chiave pubblica grezza (punto non compresso) -> chiave OpenSSL
function push_pub_da_punto($pt)
{
    if (strlen($pt) !== 65 || $pt[0] !== "\x04") {
        return false;
    }
    $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $pt;
    $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
    return @openssl_pkey_get_public($pem);
}

// Chiave privata grezza (32 byte) -> chiave OpenSSL (serve per le prove con i valori dell'RFC)
function push_priv_da_grezza($d)
{
    $der = hex2bin('30310201010420') . $d . hex2bin('a00a06082a8648ce3d030107');
    $pem = "-----BEGIN EC PRIVATE KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END EC PRIVATE KEY-----\n";
    return @openssl_pkey_get_private($pem);
}

/* ---------------- Cifratura del messaggio (RFC 8291) ---------------- */

/*
 * $ua_pub: chiave p256dh del browser (65 byte), $auth: segreto del browser (16 byte).
 * $prova: array('priv' => chiave OpenSSL, 'pub' => 65 byte, 'salt' => 16 byte) solo per le prove con i vettori dell'RFC.
 */
function push_cifra($testo, $ua_pub, $auth, $prova = null)
{
    $peer = push_pub_da_punto($ua_pub);
    if (!$peer || strlen($auth) < 16) {
        throw new Exception('Chiavi del dispositivo non valide.');
    }
    if ($prova) {
        $as_priv = $prova['priv'];
        $as_pub = $prova['pub'];
        $salt = $prova['salt'];
    } else {
        list(, $as_pub, $as_priv) = push_ec_nuova();
        $salt = random_bytes(16);
    }
    $ecdh = openssl_pkey_derive($peer, $as_priv, 32);
    if ($ecdh === false || strlen($ecdh) !== 32) {
        throw new Exception('Calcolo della chiave condivisa non riuscito.');
    }
    $ikm = hash_hkdf('sha256', $ecdh, 32, "WebPush: info\0" . $ua_pub . $as_pub, $auth);
    $cek = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\0", $salt);
    $nonce = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\0", $salt);
    $tag = '';
    $cifrato = openssl_encrypt($testo . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
    if ($cifrato === false) {
        throw new Exception('Cifratura non riuscita.');
    }
    return $salt . pack('N', 4096) . chr(65) . $as_pub . $cifrato . $tag;
}

/* ---------------- VAPID: il "biglietto da visita" del sito (RFC 8292) ---------------- */

function push_contatto()
{
    $c = trim((string)setting('push_contatto', ''));
    if ($c !== '' && filter_var($c, FILTER_VALIDATE_EMAIL)) {
        return 'mailto:' . $c;
    }
    if (preg_match('#^https://#', $c)) {
        return $c;
    }
    try {
        $e = db()->query("SELECT email FROM users WHERE role = 'admin' AND active = 1 AND email IS NOT NULL AND email <> '' ORDER BY id LIMIT 1")->fetchColumn();
        if ($e && filter_var($e, FILTER_VALIDATE_EMAIL)) {
            return 'mailto:' . $e;
        }
    } catch (Exception $e) {
        // colonna email non ancora presente
    }
    return 'mailto:libreria@example.org';
}

function push_jwt($endpoint, $priv)
{
    $p = parse_url($endpoint);
    $aud = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    $h = push_b64e(json_encode(array('typ' => 'JWT', 'alg' => 'ES256')));
    $c = push_b64e(json_encode(array('aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => push_contatto()), JSON_UNESCAPED_SLASHES));
    if (!openssl_sign($h . '.' . $c, $der, $priv, OPENSSL_ALGO_SHA256)) {
        throw new Exception('Firma VAPID non riuscita.');
    }
    return $h . '.' . $c . '.' . push_b64e(push_der_a_grezza($der));
}

// Firma ECDSA da DER (SEQUENCE di due INTEGER) a r||s di 64 byte
function push_der_a_grezza($der)
{
    $o = 2;
    if (ord($der[1]) & 0x80) {
        $o += ord($der[1]) & 0x7f;
    }
    $out = '';
    for ($i = 0; $i < 2; $i++) {
        $len = ord($der[$o + 1]);
        $v = ltrim(substr($der, $o + 2, $len), "\0");
        $out .= str_pad($v, 32, "\0", STR_PAD_LEFT);
        $o += 2 + $len;
    }
    return $out;
}

/* ---------------- Iscrizioni dei dispositivi ---------------- */

// Solo i servizi di notifica dei browser: il server non deve mai mandare richieste a indirizzi scelti da altri
function push_endpoint_ok($url)
{
    $p = parse_url((string)$url);
    if (!$p || !isset($p['scheme'], $p['host']) || strlen((string)$url) > 1000) {
        return false;
    }
    $host = strtolower($p['host']);
    if (getenv('LIBRERIA_PUSH_TEST') === '1' && $p['scheme'] === 'http' && $host === '127.0.0.1') {
        return true; // servizio di notifica finto delle prove
    }
    if ($p['scheme'] !== 'https' || isset($p['user']) || (isset($p['port']) && (int)$p['port'] !== 443)) {
        return false;
    }
    foreach (array('fcm.googleapis.com', 'android.googleapis.com', 'push.services.mozilla.com', 'push.apple.com', 'notify.windows.com') as $suf) {
        if ($host === $suf || substr($host, -strlen('.' . $suf)) === '.' . $suf) {
            return true;
        }
    }
    return false;
}

function push_iscrivi($uid, $endpoint, $p256dh, $auth, $ua)
{
    if (!push_endpoint_ok($endpoint)) {
        throw new Exception('Servizio di notifica non riconosciuto.');
    }
    if (strlen(push_b64d($p256dh)) !== 65 || strlen(push_b64d($auth)) < 16) {
        throw new Exception('Chiavi del dispositivo non valide.');
    }
    $hash = hash('sha256', $endpoint);
    $pdo = db();
    $st = $pdo->prepare('SELECT id FROM push_subscriptions WHERE endpoint_hash = ?');
    $st->execute(array($hash));
    $id = (int)$st->fetchColumn();
    if ($id) {
        // lo stesso dispositivo: passa all'utente che ha fatto l'accesso adesso
        $pdo->prepare('UPDATE push_subscriptions SET user_id = ?, p256dh = ?, auth = ?, user_agent = ?, fails = 0, last_error = NULL WHERE id = ?')
            ->execute(array((int)$uid, $p256dh, $auth, str_cut($ua, 250), $id));
        return false;
    }
    $n = $pdo->prepare('SELECT COUNT(*) FROM push_subscriptions WHERE user_id = ?');
    $n->execute(array((int)$uid));
    if ((int)$n->fetchColumn() >= 20) {
        // troppi dispositivi: si toglie il piu' vecchio
        $pdo->prepare('DELETE FROM push_subscriptions WHERE id = (SELECT id FROM (SELECT id FROM push_subscriptions WHERE user_id = ? ORDER BY COALESCE(last_ok_at, created_at) LIMIT 1) t)')
            ->execute(array((int)$uid));
    }
    $pdo->prepare('INSERT INTO push_subscriptions (user_id, endpoint, endpoint_hash, p256dh, auth, user_agent, created_at) VALUES (?,?,?,?,?,?,?)')
        ->execute(array((int)$uid, $endpoint, $hash, $p256dh, $auth, str_cut($ua, 250), now()));
    return true;
}

function push_togli($uid, $endpoint)
{
    db()->prepare('DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint_hash = ?')->execute(array((int)$uid, hash('sha256', (string)$endpoint)));
}

function push_dispositivi($uid)
{
    if (!push_ready()) {
        return array();
    }
    $st = db()->prepare('SELECT id, endpoint_hash, user_agent, created_at, last_ok_at, fails, last_error FROM push_subscriptions WHERE user_id = ? ORDER BY created_at DESC');
    $st->execute(array((int)$uid));
    return $st->fetchAll();
}

// Nome leggibile del dispositivo ("Chrome su Android")
function push_nome_dispositivo($ua)
{
    $ua = (string)$ua;
    $b = stripos($ua, 'Edg/') !== false ? 'Edge' : (stripos($ua, 'Firefox') !== false ? 'Firefox' : (stripos($ua, 'SamsungBrowser') !== false ? 'Samsung Internet'
        : (stripos($ua, 'Chrome') !== false || stripos($ua, 'CriOS') !== false ? 'Chrome' : (stripos($ua, 'Safari') !== false ? 'Safari' : 'Browser'))));
    $s = preg_match('/iPhone/i', $ua) ? 'iPhone' : (preg_match('/iPad/i', $ua) ? 'iPad' : (stripos($ua, 'Android') !== false ? 'Android'
        : (stripos($ua, 'Windows') !== false ? 'Windows' : (stripos($ua, 'Mac OS') !== false ? 'Mac' : (stripos($ua, 'Linux') !== false ? 'Linux' : '')))));
    return $b . ($s !== '' ? ' su ' . $s : '');
}

/* ---------------- Preferenze di ogni utente ---------------- */

function push_suoni()
{
    return array('campanello' => 'Campanello', 'goccia' => 'Goccia', 'arpa' => 'Arpa', 'pop' => 'Pop', 'carillon' => 'Carillon');
}

// tipi: kind => 0|1 (assente = acceso) · suono: nome o '' (spento) · silenzio: on, dal, al (HH:MM)
function push_prefs($u)
{
    $p = isset($u['push_prefs']) ? json_decode((string)$u['push_prefs'], true) : null;
    $p = is_array($p) ? $p : array();
    $sil = isset($p['silenzio']) && is_array($p['silenzio']) ? $p['silenzio'] : array();
    return array(
        'tipi' => isset($p['tipi']) && is_array($p['tipi']) ? $p['tipi'] : array(),
        'suono' => isset($p['suono']) && ($p['suono'] === '' || array_key_exists((string)$p['suono'], push_suoni())) ? $p['suono'] : 'campanello',
        'silenzio' => array(
            'on' => !empty($sil['on']),
            'dal' => isset($sil['dal']) && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $sil['dal']) ? $sil['dal'] : '22:30',
            'al' => isset($sil['al']) && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $sil['al']) ? $sil['al'] : '07:30',
        ),
    );
}

// E' l'orario di silenzio scelto dall'utente? (anche a cavallo della mezzanotte, es. 22:30 → 07:30)
function push_in_silenzio($prefs, $t = null)
{
    if (empty($prefs['silenzio']['on'])) {
        return false;
    }
    $t = $t === null ? time() : $t;
    $ora = (int)date('G', $t) * 60 + (int)date('i', $t);
    list($h1, $m1) = array_map('intval', explode(':', $prefs['silenzio']['dal']));
    list($h2, $m2) = array_map('intval', explode(':', $prefs['silenzio']['al']));
    $a = $h1 * 60 + $m1;
    $b = $h2 * 60 + $m2;
    if ($a === $b) {
        return false;
    }
    return $a < $b ? ($ora >= $a && $ora < $b) : ($ora >= $a || $ora < $b);
}

/* ---------------- Coda e invio ---------------- */

/*
 * Chiamata da notif_invia per ogni avviso creato o aggiornato. $u: riga dell'utente (con push_prefs).
 * L'invio vero parte alla fine della richiesta, dopo aver consegnato la pagina.
 */
function push_accoda($u, $kind, $testo, $link, $tag)
{
    if (!push_attivo()) {
        return;
    }
    $p = push_prefs($u);
    if ((isset($p['tipi'][$kind]) && !$p['tipi'][$kind]) || push_in_silenzio($p)) {
        return;
    }
    if (empty($GLOBALS['PUSH_CODA'])) {
        $GLOBALS['PUSH_CODA'] = array();
        register_shutdown_function('push_svuota_coda');
    }
    $GLOBALS['PUSH_CODA'][] = array((int)$u['id'], array(
        'titolo' => setting('brand_title'),
        'testo' => str_cut($testo, 300),
        'url' => $link !== '' ? $link : 'notifiche.php',
        'tag' => $tag !== '' ? str_cut($tag, 60) : 'n' . substr(md5($testo . microtime()), 0, 10),
        'tipo' => $kind,
        'icona' => 'icon.php?s=192',
    ));
}

// Consegna subito la pagina al browser e chiude la connessione; il lavoro continua dopo (Apache mod_php e PHP-FPM)
function risposta_rilascia()
{
    static $fatto = false;
    if ($fatto) {
        return;
    }
    $fatto = true;
    @ignore_user_abort(true);
    if (function_exists('set_time_limit')) {
        @set_time_limit(60);
    }
    if (function_exists('fastcgi_finish_request')) {
        @fastcgi_finish_request();
        return;
    }
    if (PHP_SAPI === 'cli' || headers_sent()) {
        return;
    }
    $buf = '';
    while (ob_get_level() > 0) {
        $buf = ob_get_clean() . $buf;
    }
    if (function_exists('apache_setenv')) {
        @apache_setenv('no-gzip', '1');
    }
    header('Connection: close');
    header('Content-Length: ' . strlen($buf));
    echo $buf;
    @flush();
}

function push_svuota_coda()
{
    $coda = isset($GLOBALS['PUSH_CODA']) ? $GLOBALS['PUSH_CODA'] : array();
    $GLOBALS['PUSH_CODA'] = array();
    if (!$coda) {
        return;
    }
    risposta_rilascia();
    try {
        $per = array();
        foreach ($coda as $x) {
            $per[$x[0]][] = $x[1];
        }
        foreach ($per as $uid => $msgs) {
            // piu' avvisi per la stessa persona nella stessa richiesta: si manda solo l'ultimo di ogni gruppo
            $ult = array();
            foreach ($msgs as $m) {
                $ult[$m['tag']] = $m;
            }
            foreach ($ult as $m) {
                push_invia_utente($uid, $m);
            }
        }
    } catch (Throwable $e) {
        app_log('push_errore', 'Invio delle notifiche non riuscito: ' . $e->getMessage(), 'warn');
    }
}

// Manda un messaggio a tutti i dispositivi di un utente. Esito: array di array(nome_dispositivo, ok, errore)
function push_invia_utente($uid, $msg)
{
    $priv = push_chiave_privata();
    if (!$priv) {
        return array();
    }
    $st = db()->prepare('SELECT * FROM push_subscriptions WHERE user_id = ?');
    $st->execute(array((int)$uid));
    $subs = $st->fetchAll();
    if (!$subs) {
        return array();
    }
    $json = json_encode($msg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $req = array();
    foreach ($subs as $s) {
        try {
            $corpo = push_cifra($json, push_b64d($s['p256dh']), push_b64d($s['auth']));
            $req[$s['id']] = array('url' => $s['endpoint'], 'corpo' => $corpo, 'headers' => array(
                'Content-Type: application/octet-stream',
                'Content-Encoding: aes128gcm',
                'TTL: ' . PUSH_TTL,
                // alta per tutte (1.9.20): con "normal" Android trattiene i messaggi finche' il telefono e' a riposo
                'Urgency: high',
                'Authorization: vapid t=' . push_jwt($s['endpoint'], $priv) . ', k=' . push_chiave_pubblica(),
            ));
        } catch (Exception $e) {
            $req[$s['id']] = array('errore' => $e->getMessage());
        }
    }
    $ris = push_http_post($req);
    $out = array();
    foreach ($subs as $s) {
        $r = isset($ris[$s['id']]) ? $ris[$s['id']] : array('code' => 0, 'error' => isset($req[$s['id']]['errore']) ? $req[$s['id']]['errore'] : 'non inviato');
        $nome = push_nome_dispositivo($s['user_agent']);
        if ($r['code'] >= 200 && $r['code'] < 300) {
            db()->prepare('UPDATE push_subscriptions SET last_ok_at = ?, fails = 0, last_error = NULL WHERE id = ?')->execute(array(now(), (int)$s['id']));
            $out[] = array($nome, true, '');
        } elseif (in_array($r['code'], array(404, 410), true)) {
            // il dispositivo ha tolto il permesso o l'iscrizione e' scaduta
            db()->prepare('DELETE FROM push_subscriptions WHERE id = ?')->execute(array((int)$s['id']));
            $out[] = array($nome, false, 'iscrizione scaduta: tolta (riattiva le notifiche su quel dispositivo)');
        } else {
            $err = $r['code'] ? 'risposta ' . $r['code'] . (trim($r['body']) !== '' ? ': ' . str_cut(trim(strip_tags($r['body'])), 160) : '') : $r['error'];
            $f = (int)$s['fails'] + 1;
            if ($f >= 30 && (!$s['last_ok_at'] || strtotime($s['last_ok_at']) < time() - 30 * 86400)) {
                db()->prepare('DELETE FROM push_subscriptions WHERE id = ?')->execute(array((int)$s['id']));
            } else {
                db()->prepare('UPDATE push_subscriptions SET fails = ?, last_error = ? WHERE id = ?')->execute(array($f, str_cut($err, 250), (int)$s['id']));
            }
            $out[] = array($nome, false, $err);
        }
    }
    return $out;
}

/*
 * POST in parallelo (cURL multi). $req: id => array(url, corpo, headers) oppure array(errore).
 * Esito: id => array(code, body, error)
 */
function push_http_post($req)
{
    require_once APP_ROOT . '/inc/http.php';
    $out = array();
    $validi = array();
    foreach ($req as $id => $r) {
        if (isset($r['url']) && push_endpoint_ok($r['url'])) {
            $validi[$id] = $r;
        } elseif (!isset($r['errore'])) {
            $out[$id] = array('code' => 0, 'body' => '', 'error' => 'servizio di notifica non ammesso');
        }
    }
    if (!$validi) {
        return $out;
    }
    if (function_exists('curl_multi_init')) {
        $mh = curl_multi_init();
        $hs = array();
        foreach ($validi as $id => $r) {
            $ch = curl_init($r['url']);
            curl_setopt_array($ch, array(
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $r['corpo'],
                CURLOPT_HTTPHEADER => $r['headers'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_USERAGENT => http_user_agent(),
                CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
                CURLOPT_SSL_VERIFYPEER => true,
            ));
            if (defined('HTTP_PROXY_URL') && HTTP_PROXY_URL !== '') {
                curl_setopt($ch, CURLOPT_PROXY, HTTP_PROXY_URL);
            }
            if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
                curl_setopt($ch, CURLOPT_CAINFO, CA_BUNDLE);
            }
            curl_multi_add_handle($mh, $ch);
            $hs[$id] = $ch;
        }
        do {
            $st = curl_multi_exec($mh, $attivi);
            if ($attivi) {
                curl_multi_select($mh, 1.0);
            }
        } while ($attivi && $st === CURLM_OK);
        foreach ($hs as $id => $ch) {
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $out[$id] = array('code' => $code, 'body' => (string)curl_multi_getcontent($ch),
                'error' => $code ? '' : http_error_text(curl_errno($ch), curl_error($ch)));
            curl_multi_remove_handle($mh, $ch);
            if (PHP_VERSION_ID < 80000) {
                curl_close($ch);
            }
        }
        curl_multi_close($mh);
        return $out;
    }
    foreach ($validi as $id => $r) {
        $opts = array('http' => array('method' => 'POST', 'timeout' => 10, 'ignore_errors' => true, 'follow_location' => 0,
            'header' => implode("\r\n", $r['headers']) . "\r\nUser-Agent: " . http_user_agent() . "\r\n", 'content' => $r['corpo']));
        if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
            $opts['ssl'] = array('cafile' => CA_BUNDLE, 'verify_peer' => true);
        }
        if (defined('HTTP_PROXY_URL') && HTTP_PROXY_URL !== '') {
            $opts['http']['proxy'] = HTTP_PROXY_URL;
            $opts['http']['request_fulluri'] = true;
        }
        $fp = @fopen($r['url'], 'rb', false, stream_context_create($opts));
        $code = 0;
        $body = '';
        if ($fp) {
            $meta = stream_get_meta_data($fp);
            foreach (isset($meta['wrapper_data']) ? (array)$meta['wrapper_data'] : array() as $hl) {
                if (preg_match('#^HTTP/\S+\s+(\d+)#', $hl, $m)) {
                    $code = (int)$m[1];
                }
            }
            $body = (string)stream_get_contents($fp, 4096);
            fclose($fp);
        }
        $out[$id] = array('code' => $code, 'body' => $body, 'error' => $code ? '' : 'Connessione non riuscita');
    }
    return $out;
}

// Prova: manda subito una notifica ai dispositivi dell'utente (senza orario di silenzio)
function push_prova($uid, $chiuso = false)
{
    return push_invia_utente($uid, array('titolo' => setting('brand_title'), 'testo' => $chiuso ? 'Prova a sito chiuso riuscita: le notifiche arrivano anche con l\'app chiusa.' : 'Prova riuscita: le notifiche arrivano su questo dispositivo.',
        'url' => 'account.php#notifiche-push', 'tag' => 'prova', 'tipo' => 'prova', 'icona' => 'icon.php?s=192'));
}
