<?php
/*
 * Importazione dal file che Goodreads fa scaricare (My Books → Import and export → Export Library):
 * goodreads_library_export.csv. Ogni utente importa le proprie letture: libri letti con data e voto,
 * recensioni, letture in corso, libri da leggere. I libri si riconoscono dall'ISBN o da titolo e autore.
 */
require_once dirname(__FILE__) . '/reading.php';
require_once dirname(__FILE__) . '/search.php';

function gr_clean_isbn($s)
{
    return strtoupper(preg_replace('/[^0-9Xx]/', '', (string)$s));
}

function gr_clean_title($t)
{
    $t = preg_replace('/\s*\([^()]*#\s*[\d.]+[^()]*\)\s*$/u', '', trim((string)$t)); // "(Serie, #2)"
    return trim($t);
}

function gr_title_keys($t)
{
    $t = gr_clean_title($t);
    $keys = array(search_norm($t));
    foreach (array(':', ' - ', '. ') as $sep) {
        $p = strpos($t, $sep);
        if ($p !== false && $p > 2) {
            $keys[] = search_norm(substr($t, 0, $p));
        }
    }
    return array_values(array_unique(array_filter($keys, 'strlen')));
}

function gr_tokens($s)
{
    return array_values(array_filter(explode(' ', search_norm($s)), function ($w) { return strlen($w) > 2; }));
}

/*
 * Legge il file. Restituisce array(righe, errore)
 */
function gr_parse($path)
{
    $f = @fopen($path, 'rb');
    if (!$f) {
        return array(array(), 'Non riesco ad aprire il file.');
    }
    $head = fgetcsv($f, 0, ',', '"', '\\');
    if (!$head) {
        fclose($f);
        return array(array(), 'Il file è vuoto.');
    }
    $head[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$head[0]);
    $idx = array_flip(array_map('trim', $head));
    foreach (array('Title', 'Author', 'Exclusive Shelf') as $need) {
        if (!isset($idx[$need])) {
            fclose($f);
            return array(array(), 'Questo non sembra il file esportato da Goodreads (manca la colonna "' . $need . '").');
        }
    }
    $g = function ($r, $k) use ($idx) {
        return isset($idx[$k], $r[$idx[$k]]) ? trim((string)$r[$idx[$k]]) : '';
    };
    $rows = array();
    while (($r = fgetcsv($f, 0, ',', '"', '\\')) !== false) {
        if (count($r) < 3 || $g($r, 'Title') === '') {
            continue;
        }
        $date = $g($r, 'Date Read');
        $dt = null;
        if (preg_match('#^(\d{4})[/-](\d{1,2})[/-](\d{1,2})#', $date, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
            $dt = sprintf('%04d-%02d-%02d', $m[1], $m[2], $m[3]);
        }
        $review = $g($r, 'My Review');
        $review = trim(html_entity_decode(strip_tags(preg_replace('#<br\s*/?>#i', "\n", $review)), ENT_QUOTES, 'UTF-8'));
        $rows[] = array(
            'title' => str_cut(gr_clean_title($g($r, 'Title')), 255),
            'author' => str_cut($g($r, 'Author'), 255),
            'more_authors' => $g($r, 'Additional Authors'),
            'isbn13' => gr_clean_isbn($g($r, 'ISBN13')),
            'isbn10' => gr_clean_isbn($g($r, 'ISBN')),
            'rating' => max(0, min(5, (int)$g($r, 'My Rating'))),
            'publisher' => str_cut($g($r, 'Publisher'), 255),
            'pages' => (int)$g($r, 'Number of Pages'),
            'year' => (int)($g($r, 'Year Published') !== '' ? $g($r, 'Year Published') : $g($r, 'Original Publication Year')),
            'date_read' => $dt,
            'shelf' => strtolower($g($r, 'Exclusive Shelf')),
            'review' => str_cut($review, 4000),
            'read_count' => max(0, min(20, (int)$g($r, 'Read Count'))),
        );
        if (count($rows) >= 10000) {
            break;
        }
    }
    fclose($f);
    if (!$rows) {
        return array(array(), 'Nel file non c\'è nessun libro.');
    }
    return array($rows, '');
}

// Cerca in libreria i libri del file: aggiunge 'book_id' e 'how' a ogni riga
function gr_match($rows)
{
    $by_isbn = array();
    $by_title = array();
    foreach (db()->query('SELECT id, title, authors, isbn13, isbn10 FROM books')->fetchAll() as $b) {
        if ($b['isbn13']) {
            $by_isbn[$b['isbn13']] = (int)$b['id'];
        }
        if ($b['isbn10']) {
            $by_isbn[strtoupper($b['isbn10'])] = (int)$b['id'];
        }
        foreach (gr_title_keys($b['title']) as $k) {
            $by_title[$k][] = array((int)$b['id'], gr_tokens($b['authors']));
        }
    }
    foreach ($rows as $i => $r) {
        $id = 0;
        $how = '';
        $i13 = $r['isbn13'] !== '' ? isbn_to13($r['isbn13']) : ($r['isbn10'] !== '' ? isbn_to13($r['isbn10']) : '');
        if ($i13 && isset($by_isbn[$i13])) {
            $id = $by_isbn[$i13];
            $how = 'ISBN';
        } elseif ($r['isbn10'] !== '' && isset($by_isbn[$r['isbn10']])) {
            $id = $by_isbn[$r['isbn10']];
            $how = 'ISBN';
        } else {
            $atoks = gr_tokens($r['author']);
            foreach (gr_title_keys($r['title']) as $k) {
                if (empty($by_title[$k])) {
                    continue;
                }
                foreach ($by_title[$k] as $c) {
                    if ($atoks && array_intersect($atoks, $c[1])) {
                        $id = $c[0];
                        $how = 'titolo e autore';
                        break 2;
                    }
                }
            }
        }
        $rows[$i]['book_id'] = $id;
        $rows[$i]['how'] = $how;
    }
    return $rows;
}

function gr_summary($rows)
{
    $s = array('read' => 0, 'read_dated' => 0, 'current' => 0, 'toread' => 0, 'other' => 0, 'found' => 0, 'missing' => 0, 'missing_list' => array(), 'rated' => 0, 'reviews' => 0);
    foreach ($rows as $r) {
        if ($r['shelf'] === 'read') {
            $s['read']++;
            if ($r['date_read']) {
                $s['read_dated']++;
            }
        } elseif ($r['shelf'] === 'currently-reading') {
            $s['current']++;
        } elseif ($r['shelf'] === 'to-read') {
            $s['toread']++;
        } else {
            $s['other']++;
        }
        if ($r['rating'] > 0) {
            $s['rated']++;
        }
        if ($r['review'] !== '') {
            $s['reviews']++;
        }
        if ($r['book_id']) {
            $s['found']++;
        } else {
            $s['missing']++;
            if (count($s['missing_list']) < 40) {
                $s['missing_list'][] = $r;
            }
        }
    }
    return $s;
}

/*
 * Importa. $opts: add_missing (crea in libreria i libri che mancano), toread (importa anche "da leggere")
 * Restituisce un riepilogo
 */
function gr_import($uid, $rows, $opts)
{
    $GLOBALS['NOTIF_SILENZIO'] = true; // un'importazione non riempie di avvisi la famiglia
    $res = array('reads' => 0, 'current' => 0, 'toread' => 0, 'created' => 0, 'skipped' => 0, 'already' => 0);
    foreach ($rows as $r) {
        if (!in_array($r['shelf'], array('read', 'currently-reading', 'to-read'), true)) {
            $res['skipped']++;
            continue;
        }
        if ($r['shelf'] === 'to-read' && empty($opts['toread'])) {
            continue;
        }
        $bid = (int)$r['book_id'];
        if (!$bid) {
            if (empty($opts['add_missing'])) {
                $res['skipped']++;
                continue;
            }
            $i13 = $r['isbn13'] !== '' ? isbn_to13($r['isbn13']) : ($r['isbn10'] !== '' ? isbn_to13($r['isbn10']) : '');
            $authors = $r['author'] . ($r['more_authors'] !== '' ? ', ' . $r['more_authors'] : '');
            $bid = book_insert(array(
                'isbn13' => $i13 ? $i13 : null, 'isbn10' => $i13 ? isbn13_to_10($i13) : null, 'title' => $r['title'], 'subtitle' => null,
                'authors' => str_cut($authors, 255), 'publisher' => $r['publisher'] !== '' ? $r['publisher'] : null,
                'pub_year' => $r['year'] > 0 ? $r['year'] : null, 'pages' => $r['pages'] > 0 ? $r['pages'] : null, 'language' => null,
                'category_id' => null, 'shelf' => null, 'description' => null, 'notes' => null,
            ), 'goodreads');
            $res['created']++;
        }
        $cur = user_book_row($uid, $bid);
        if ($r['shelf'] === 'to-read') {
            if ((string)$cur['status'] === '') {
                reading_sync_user_book($uid, $bid, 'da_leggere');
                $res['toread']++;
            } else {
                $res['already']++;
            }
            continue;
        }
        if ($r['shelf'] === 'currently-reading') {
            if (!reading_open_session($uid, $bid)) {
                reading_session_add($uid, $bid, 'in_lettura', null, null, 0, 'goodreads');
                reading_sync_user_book($uid, $bid, 'in_lettura');
                $res['current']++;
            } else {
                $res['already']++;
            }
            continue;
        }
        // letto
        $st = db()->prepare("SELECT * FROM reading_sessions WHERE user_id = ? AND book_id = ? AND status = 'letto' ORDER BY id");
        $st->execute(array((int)$uid, $bid));
        $done = $st->fetchAll();
        $target = null;
        foreach ($done as $s) {
            $same = $r['date_read'] ? ($s['finished_at'] && substr($s['finished_at'], 0, 10) === $r['date_read']) : (int)$s['date_unknown'] === 1;
            if ($same) {
                $target = $s;
                break;
            }
        }
        if ($target) {
            $res['already']++;
            $sid = (int)$target['id'];
        } else {
            $sid = reading_session_add($uid, $bid, 'letto', null, $r['date_read'] ? $r['date_read'] . ' 21:00:00' : null, $r['date_read'] ? 0 : 1, 'goodreads');
            $done[] = array('id' => $sid);
            $res['reads']++;
        }
        // voto (in stelle intere su Goodreads) e recensione, se non ci sono gia'
        $s = reading_session_get($uid, $sid);
        if ($s && (($r['rating'] > 0 && $s['rating'] === null) || ($r['review'] !== '' && (string)$s['review'] === ''))) {
            db()->prepare('UPDATE reading_sessions SET rating = ?, review = ?, updated_at = ? WHERE id = ?')->execute(array(
                $s['rating'] !== null ? $s['rating'] : ($r['rating'] > 0 ? $r['rating'] : null),
                (string)$s['review'] !== '' ? $s['review'] : ($r['review'] !== '' ? $r['review'] : null), now(), $sid));
        }
        // riletture indicate da Goodreads ("Read Count"), con data sconosciuta
        for ($n = count($done); $n < $r['read_count']; $n++) {
            reading_session_add($uid, $bid, 'letto', null, null, 1, 'goodreads');
            $res['reads']++;
        }
        if (!reading_open_session($uid, $bid)) {
            reading_sync_user_book($uid, $bid, 'letto');
        }
    }
    return $res;
}

function gr_temp_path($uid, $token)
{
    return DATA_DIR . '/uploads/goodreads_' . (int)$uid . '_' . preg_replace('/[^a-f0-9]/', '', $token) . '.json';
}
