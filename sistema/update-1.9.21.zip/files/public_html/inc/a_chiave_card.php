<?php
/* Riquadro "Chiave dell'autore" (Plugin e Officina): stato, importazione, copia, rimozione della chiave privata */
require_once APP_ROOT . '/inc/firma.php';
$fpub = firma_chiave_pubblica();
$sodium = firma_disponibile();
$base = dirname(APP_ROOT);
?>
  <div class="card" id="chiave">
    <div class="ct"><?= admin_icon('shield', 18) ?> Chiave dell'autore</div>
    <?php if (!$sodium): ?>
      <div class="alert error">Sul server manca l'estensione <b>sodium</b> di PHP: senza, le firme non si possono controllare e i plugin restano spenti.
        Su Debian: <code>apt install php-sodium</code> (di solito è già inclusa).</div>
    <?php elseif ($fpub): ?>
      <div class="sigline ok"><?= admin_icon('shield', 16) ?><span>Il sito accetta solo plugin e aggiornamenti firmati da <b><?= h($fpub['autore']) ?></b>.</span></div>
      <div class="fr row"><span>Impronta della chiave</span><code><?= h(firma_impronta_leggibile($fpub['impronta'])) ?></code></div>
      <div class="fr row"><span>Creata il</span><span><?= $fpub['creata'] ? h(date('d/m/Y', strtotime($fpub['creata']))) : '—' ?></span></div>
      <div class="fr row"><span>Chiave privata su questo server</span><span><?= firma_privata_presente() ? 'sì (cifrata con la passphrase)' : 'no' ?></span></div>
      <p class="hint">La chiave pubblica è in <code>CONF/firma_autore.json</code>: né il pannello né gli aggiornamenti possono cambiarla.
        Confronta l'impronta con quella che ti ha dato il comando <code>firma.php</code>.</p>
      <?php if (firma_privata_presente()): ?>
      <details class="key-tools"><summary>Copia o togli la chiave privata</summary>
        <p class="hint">La chiave privata serve solo a chi firma e pubblica (l'officina). Scaricane una copia (è cifrata con la passphrase) per portarla nell'officina,
          poi toglila da questo server: il sito continuerà a controllare le firme con la chiave pubblica.</p>
        <form method="post" class="row-btn"><?= csrf_field() ?><input type="hidden" name="action" value="key_export">
          <input class="input" type="password" name="password" required autocomplete="current-password" placeholder="La tua password">
          <button class="btn ghost small" type="submit">Scarica una copia</button></form>
        <form method="post" class="stack" data-confirm="Togliere la chiave privata da questo server? Hai una copia (e la passphrase)?"><?= csrf_field() ?><input type="hidden" name="action" value="key_remove">
          <div class="row-btn"><input class="input" type="password" name="password" required autocomplete="current-password" placeholder="La tua password">
          <input class="input" name="conferma" required placeholder="Scrivi TOGLI" autocomplete="off"></div>
          <button class="btn danger-ghost small" type="submit">Togli la chiave privata da questo server</button></form>
      </details>
      <?php endif; ?>
    <?php else: ?>
      <p class="sub">Nessuna chiave: per ora <b>non si può installare nessun plugin</b>. La chiave si crea una volta sola, dal server (non dal pannello, così nessuno che rubi una password può farlo al posto tuo):</p>
      <pre class="cmd">cd <?= h($base) ?>

php strumenti/firma.php crea-chiave "Nome Cognome"</pre>
      <p class="hint">Su Proxmox: entra nel container (<code>pct enter &lt;numero&gt;</code>) e lancia il comando. Ti chiede una passphrase di almeno 12 caratteri.
        Da quel momento il sito installa solo plugin e aggiornamenti firmati da te.</p>
      <p class="hint">Se la chiave l'hai già (per esempio da un altro tuo sito), importala qui sotto. Se usi un repository di aggiornamenti, puoi anche fidarti della sua chiave
        da <a class="link" href="gestione.php?sez=aggiornamento#repository">Sistema → Aggiornamento</a>.</p>
    <?php endif; ?>
    <?php if ($sodium && !firma_privata_presente()): ?>
      <details class="key-tools"<?= $fpub ? '' : ' open' ?>><summary>Importa la chiave privata (per firmare e pubblicare da qui)</summary>
        <form method="post" enctype="multipart/form-data" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="key_import">
          <label class="lab">File <code>chiave_privata.json</code></label><input class="input" type="file" name="key_file" accept=".json,application/json" required>
          <input class="input" type="password" name="passphrase" required autocomplete="off" placeholder="Passphrase della chiave">
          <input class="input" type="password" name="password" required autocomplete="current-password" placeholder="La tua password">
          <button class="btn primary small" type="submit">Importa</button></form>
        <p class="hint"><?= $fpub ? 'Deve essere la stessa chiave di questo sito (stessa impronta).' : 'La chiave pubblica di questo sito verrà presa da qui.' ?></p>
      </details>
    <?php endif; ?>
  </div>
