<?php
require_once dirname(__FILE__) . '/icons.php';
/*
 * Struttura HTML comune: tema grafico (dalle impostazioni dell'Admin), intestazione, menu in basso.
 */

function safe_color($value, $fallback)
{
    return preg_match('/^#[0-9a-fA-F]{6}$/', (string)$value) ? strtolower($value) : $fallback;
}

function hex_rgba($hex, $alpha)
{
    $hex = ltrim($hex, '#');
    return 'rgba(' . hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2)) . ',' . $alpha . ')';
}

function font_stack($key, $google_name)
{
    $fonts = font_options();
    if ($key === 'google') {
        $name = preg_replace('/[^A-Za-z0-9 ]/', '', $google_name);
        return $name !== '' ? '"' . $name . '", Georgia, serif' : $fonts['georgia'][1];
    }
    return isset($fonts[$key]) ? $fonts[$key][1] : $fonts['lora'][1];
}

function local_font_faces($keys)
{
    $faces = array(
        'pagella' => array(array('Libreria Pagella', 'pagella-regular.woff', '400', 'normal'), array('Libreria Pagella', 'pagella-bold.woff', '700', 'normal'),
                           array('Libreria Pagella', 'pagella-italic.woff', '400', 'italic')),
        'lora'    => array(array('Libreria Lora', 'lora.woff', '400 700', 'normal'), array('Libreria Lora', 'lora-italic.woff', '400 700', 'italic')),
        'inter'   => array(array('Libreria Inter', 'inter-regular.woff', '400', 'normal'), array('Libreria Inter', 'inter-medium.woff', '500', 'normal'),
                           array('Libreria Inter', 'inter-semibold.woff', '600', 'normal'), array('Libreria Inter', 'inter-bold.woff', '700', 'normal')),
        'poppins' => array(array('Libreria Poppins', 'poppins-regular.woff', '400', 'normal'), array('Libreria Poppins', 'poppins-medium.woff', '500', 'normal'),
                           array('Libreria Poppins', 'poppins-bold.woff', '600 700', 'normal')),
    );
    $css = '';
    $keys[] = 'inter'; // usato per etichette e numeri
    foreach (array_unique($keys) as $k) {
        if (!isset($faces[$k])) {
            continue;
        }
        foreach ($faces[$k] as $f) {
            $css .= '@font-face{font-family:"' . $f[0] . '";src:url(fonts/' . $f[1] . ') format("woff");font-weight:' . $f[2]
                  . ';font-style:' . $f[3] . ';font-display:swap}';
        }
    }
    return $css;
}

function theme_head()
{
    $d = setting_defaults();
    $c = array();
    foreach (array('primary', 'on_primary', 'accent', 'bg', 'panel', 'soft', 'ink', 'muted', 'line', 'ok', 'danger') as $k) {
        $c[$k] = safe_color(setting('color_' . $k), $d['color_' . $k][2]);
    }
    $fh = setting('font_head');
    $fb = setting('font_body');
    $out = '';
    $google = array();
    foreach (array(array($fh, 'font_head_google'), array($fb, 'font_body_google')) as $f) {
        if ($f[0] === 'google') {
            $n = trim(preg_replace('/[^A-Za-z0-9 ]/', '', setting($f[1])));
            if ($n !== '') {
                $google[] = 'family=' . str_replace(' ', '+', $n) . ':ital,wght@0,400;0,600;0,700;1,400';
            }
        }
    }
    if ($google) {
        $out .= '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?' . h(implode('&', array_unique($google))) . '&display=swap">';
    }
    $radius = setting_int('radius', 0, 32);
    $size = setting_int('font_size', 12, 20);
    $cols = setting_int('grid_cols', 2, 4);
    $css = local_font_faces(array($fh, $fb));
    $css .= ':root{--primary:' . $c['primary'] . ';--on-primary:' . $c['on_primary'] . ';--accent:' . $c['accent'] . ';--bg:' . $c['bg']
          . ';--panel:' . $c['panel'] . ';--soft:' . $c['soft'] . ';--ink:' . $c['ink'] . ';--muted:' . $c['muted'] . ';--line:' . $c['line']
          . ';--ok:' . $c['ok'] . ';--danger:' . $c['danger'] . ';--primary-shadow:' . hex_rgba($c['primary'], .35)
          . ';--radius:' . $radius . 'px;--radius-s:' . max(2, (int)round($radius * .6)) . 'px;--radius-pill:' . ($radius >= 12 ? '999px' : max(3, $radius) . 'px')
          . ';--fs:' . $size . 'px;--cols:' . $cols
          . ';--head:' . font_stack($fh, setting('font_head_google')) . ';--body:' . font_stack($fb, setting('font_body_google'))
          . ';--ui:"Libreria Inter",system-ui,-apple-system,"Segoe UI",Arial,sans-serif'
          . ';--cover-shadow:' . (setting('cover_shadow') === '1' ? '0 10px 18px -10px rgba(0,0,0,.55),0 1px 2px rgba(0,0,0,.18)' : 'none') . '}';
    // Sfondo
    $bg = setting('bg_type');
    if ($bg === 'gradient') {
        $css .= 'body{background:linear-gradient(170deg,' . $c['soft'] . ' 0%,' . $c['bg'] . ' 55%) fixed}';
    } elseif ($bg === 'pattern') {
        $css .= 'body{background:repeating-linear-gradient(45deg,' . $c['bg'] . ' 0 14px,' . hex_rgba($c['soft'], .7) . ' 14px 28px) fixed}';
    } elseif ($bg === 'paper') {
        $css .= 'body{background:radial-gradient(' . hex_rgba($c['ink'], .05) . ' 1px,transparent 1.2px) 0 0/7px 7px,' . $c['bg'] . '}';
    } elseif ($bg === 'image' && setting('bg_image') !== '') {
        $ov = setting_int('bg_overlay', 0, 90) / 100;
        $css .= 'body{background:linear-gradient(' . hex_rgba($c['bg'], $ov) . ',' . hex_rgba($c['bg'], $ov) . '),url("' . asset_url(setting('bg_image'))
              . '") center/cover fixed;}';
    }
    $css .= icon_style_css();
    $custom = setting('custom_css');
    if ($custom !== '') {
        $css .= "\n/* CSS personalizzato dall'Admin */\n" . str_ireplace('</style', '', $custom);
    }
    $out .= '<style>' . $css . '</style>';
    return $out;
}

function page_head($title, $body_class = '')
{
    $v = (int)@filemtime(APP_ROOT . '/css/style.css');
    echo '<!doctype html><html lang="it"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
       . '<meta name="theme-color" content="' . h(safe_color(setting('color_bg'), '#f3ebdd')) . '">'
       . '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'
       . '<meta name="apple-mobile-web-app-title" content="' . h(setting('brand_title')) . '">'
       . '<link rel="manifest" href="manifest.php"><link rel="icon" href="icon.php?s=192"><link rel="apple-touch-icon" href="icon.php?s=180">'
       . '<title>' . h($title) . ' · ' . h(setting('brand_title')) . '</title>'
       . '<link rel="stylesheet" href="css/style.css?v=' . $v . '">' . theme_head()
       . (function_exists('lib_filter') ? (string)lib_filter('html_testa', '') : '')
       . '</head><body' . ($body_class !== '' ? ' class="' . h($body_class) . '"' : '') . '>';
}

function brand_logo_html()
{
    $logo = setting('logo_file');
    if ($logo !== '') {
        return '<span class="logo img"><img src="' . h(asset_url($logo)) . '" alt=""></span>';
    }
    return '<span class="logo">' . icon('books', 18) . '</span>';
}

function user_initials()
{
    $u = current_user();
    $name = $u ? ($u['display_name'] !== '' ? $u['display_name'] : $u['username']) : 'Ospite';
    $parts = preg_split('/\s+/', trim($name));
    $ini = '';
    foreach ($parts as $p) {
        if ($p !== '') {
            $ini .= function_exists('mb_substr') ? mb_strtoupper(mb_substr($p, 0, 1, 'UTF-8'), 'UTF-8') : strtoupper($p[0]);
        }
        if (strlen($ini) >= 2) {
            break;
        }
    }
    return $ini;
}

// Menu in alto (accanto all'iniziale dell'utente): sezioni del sito e pagine create in Gestione
// Campanella degli avvisi (1.9.14): solo per chi ha un account
// Suono degli avvisi e dati per le notifiche sul telefono, per gli script della pagina (1.9.16)
function avvisi_config()
{
    if (!is_user() || !is_file(APP_ROOT . '/inc/push.php')) {
        return array();
    }
    require_once APP_ROOT . '/inc/push.php';
    if (!push_ready()) {
        return array();
    }
    static $c = null;
    if ($c === null) {
        $st = db()->prepare('SELECT id, push_prefs FROM users WHERE id = ?');
        $st->execute(array(current_uid()));
        $p = push_prefs($st->fetch());
        $c = array('suono' => $p['suono'], 'push' => array('attivo' => push_attivo(), 'chiave' => push_attivo() ? push_chiave_pubblica() : ''));
    }
    return $c;
}

function bell_html()
{
    if (!is_user() || !is_file(APP_ROOT . '/inc/notifiche.php')) {
        return '';
    }
    require_once APP_ROOT . '/inc/notifiche.php';
    if (!notif_ready()) {
        return '';
    }
    $n = notif_non_lette(current_uid());
    return '<a class="iconbtn bell" href="notifiche.php" data-bell aria-label="Avvisi' . ($n ? ': ' . $n . ' da leggere' : '') . '" title="Avvisi">' . icon('bell', 20)
        . '<em class="bell-n" data-bell-n' . ($n ? '' : ' hidden') . '>' . ($n > 99 ? '99+' : $n) . '</em></a>';
}

function site_menu_html()
{
    if (!is_logged()) {
        return '';
    }
    $items = officina_attiva() ? array(array('gestione.php?sez=pubblica', 'upload', 'Officina')) : array(array('libreria.php', 'books', 'Libreria'));
    if (is_user() && !officina_attiva()) {
        $items[] = array('ruota.php', 'wheel', 'Ruota di lettura');
        if ((int)setting('db_version', '1') >= 8) {
            $items[] = array('statistiche.php', 'chart', 'Le mie letture');
        }
    }
    if (can_edit() && !officina_attiva()) {
        $items[] = array('aggiungi.php', 'plus', 'Aggiungi un libro');
    }
    if (function_exists('lib_filter')) {
        // voci aggiunte dai plugin: array(indirizzo, testo) oppure array(indirizzo, icona, testo)
        foreach ((array)lib_filter('menu_sito', array()) as $pi) {
            if (is_array($pi) && count($pi) >= 2 && preg_match('#^(?![a-z]+:)[A-Za-z0-9_./?=&%\-]+$#i', (string)$pi[0])) {
                $items[] = count($pi) >= 3 ? array((string)$pi[0], (string)$pi[1], (string)$pi[2]) : array((string)$pi[0], 'page', (string)$pi[1]);
            }
        }
    }
    // pagine del sito dei plugin con 'menu' => true
    foreach (isset($GLOBALS['PLG_SITE']) ? $GLOBALS['PLG_SITE'] : array() as $k => $pg) {
        if ($pg['menu'] && empty($GLOBALS['PLG_FAILED'][$pg['plugin']->id]) && function_exists('plugin_site_allowed') && plugin_site_allowed($pg)) {
            $items[] = array($pg['plugin']->site_url($pg['slug']), $pg['icona'], $pg['title']);
        }
    }
    $pages = array();
    if (extras_ready()) {
        require_once APP_ROOT . '/inc/extras.php';
        $pages = pages_menu();
    }
    $cur = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '');
    $h = '<details class="sitemenu"><summary class="iconbtn" aria-label="Menu" title="Menu">' . icon('menu', 20) . '</summary><nav class="sitemenu-panel" aria-label="Menu del sito">';
    $u = current_user();
    $h .= '<div class="sm-head">' . h($u ? ($u['display_name'] !== '' ? $u['display_name'] : $u['username']) : 'Ospite')
        . (is_admin() ? ' <span class="role">ADMIN</span>' : (is_gestore() ? ' <span class="role">GESTORE</span>' : (is_registrato() ? ' <span class="role">REGISTRATO</span>' : ''))) . '</div>';
    foreach ($items as $it) {
        $h .= '<a href="' . h($it[0]) . '"' . ($cur === $it[0] ? ' class="on"' : '') . '>' . icon($it[1], 18) . h($it[2]) . '</a>';
    }
    if ($pages) {
        $h .= '<div class="sm-sep">Pagine</div>';
        foreach ($pages as $pg) {
            $on = $cur === 'page.php' && get('p') === $pg['slug'];
            $h .= '<a href="page.php?p=' . h(rawurlencode($pg['slug'])) . '"' . ($on ? ' class="on"' : '') . '>' . icon('page', 18) . h($pg['title']) . '</a>';
        }
    }
    $h .= '<div class="sm-sep"></div>';
    if (is_user()) {
        $h .= '<a href="account.php">' . icon('user', 18) . 'Il mio account</a>';
    }
    if (can_edit()) {
        $h .= '<a href="gestione.php">' . icon('gear', 18) . 'Gestione</a>';
    }
    $h .= '<a href="logout.php?t=' . h(csrf_token()) . '">' . icon('logout', 18) . 'Esci</a>';
    return $h . '</nav></details>';
}

/*
 * $active: libreria | cerca | aggiungi | ruota | gestione | account
 * $opts: back => URL per la freccia indietro (pagine secondarie), title_bar => titolo centrato
 */
function page_start($title, $active = '', $opts = array())
{
    $GLOBALS['PAGE_ACTIVE'] = $active;
    page_head($title, 'pg-' . $active);
    echo '<div class="app">';
    if (!empty($opts['back'])) {
        echo '<header class="top slim"><a class="iconbtn" href="' . h($opts['back']) . '" aria-label="Indietro">' . icon('back') . '</a>'
           . '<div class="toptitle">' . h($title) . '</div>';
        $menu = site_menu_html();
        echo $menu !== '' ? '<div class="topright">' . bell_html() . $menu . '</div>' : '<span class="iconbtn ghost"></span>';
        echo '</header>';
    } else {
        $pub = !empty($opts['pubblica']) && !is_logged(); // pagina aperta con un link, senza accesso: niente menu
        echo '<header class="top"><' . ($pub ? 'div' : 'a href="libreria.php"') . ' class="brandrow">' . brand_logo_html()
           . '<span class="brandtext"><span class="kick">' . h(setting('brand_kicker')) . '</span><span class="brandname">' . h(setting('brand_title')) . '</span></span></' . ($pub ? 'div' : 'a') . '>';
        if ($pub) {
            echo '</header><main class="pad">' . flash_show();
            return;
        }
        echo '<div class="topright">' . bell_html() . site_menu_html();
        if (is_user()) {
            echo '<a class="avatar" href="account.php" title="Il mio account">' . h(user_initials()) . '</a>';
        } else {
            echo '<a class="avatar" href="logout.php?t=' . h(csrf_token()) . '" title="Esci">' . icon('logout', 18) . '</a>';
        }
        echo '</div></header>';
    }
    echo '<main class="pad">' . flash_show();
}

function page_end($scripts = array(), $active = '')
{
    if ($active === '' && isset($GLOBALS['PAGE_ACTIVE'])) {
        $active = $GLOBALS['PAGE_ACTIVE'];
    }
    echo '</main>';
    if (is_logged() && function_exists('extras_ready') && extras_ready()) {
        require_once APP_ROOT . '/inc/extras.php';
        $pl = pages_menu();
        if ($pl) {
            echo '<nav class="pagelinks" aria-label="Pagine">';
            foreach ($pl as $pg) {
                echo '<a href="page.php?p=' . h(rawurlencode($pg['slug'])) . '"' . (get('p') === $pg['slug'] ? ' class="on"' : '') . '>' . h($pg['title']) . '</a>';
            }
            echo '</nav>';
        }
    }
    $foot = setting('footer_text');
    if ($foot !== '') {
        echo '<footer class="foot">' . h($foot) . '</footer>';
    }
    echo '</div>';
    if (is_logged() && officina_attiva()) {
        echo '<nav class="bnav" aria-label="Menu principale"><a class="bi" href="gestione.php?sez=pubblica">' . icon('upload', 21) . '<span>Officina</span></a></nav>';
    } elseif (is_logged()) {
        $items = array(array('libreria.php', 'libreria', 'books', 'Libreria'), array('libreria.php?cerca=1', 'cerca', 'search', 'Cerca'));
        echo '<nav class="bnav" aria-label="Menu principale">';
        foreach ($items as $it) {
            echo '<a class="bi' . ($active === $it[1] ? ' on' : '') . '" href="' . $it[0] . '">' . icon($it[2], 21) . '<span>' . $it[3] . '</span></a>';
        }
        if (can_edit()) {
            echo '<a class="fab' . ($active === 'aggiungi' ? ' on' : '') . '" href="aggiungi.php" aria-label="Aggiungi libro">' . icon('plus', 26) . '</a>';
        }
        if (is_user()) {
            echo '<a class="bi' . ($active === 'ruota' ? ' on' : '') . '" href="ruota.php">' . icon('wheel', 21) . '<span>Ruota</span></a>';
        }
        if (can_edit()) {
            echo '<a class="bi' . ($active === 'gestione' ? ' on' : '') . '" href="gestione.php">' . icon('gear', 21) . '<span>Gestione</span></a>';
        }
        echo '</nav>';
    }
    // dopo un accesso con la password: proposta di creare una chiave di accesso su questo dispositivo (una volta)
    if (is_user() && !empty($_SESSION['pk_proponi']) && is_file(APP_ROOT . '/inc/webauthn.php')) {
        unset($_SESSION['pk_proponi']);
        require_once APP_ROOT . '/inc/webauthn.php';
        if (pk_enabled() && pk_available_here()) {
            $n_pk = 0;
            try {
                $stp = db()->prepare('SELECT COUNT(*) FROM user_passkeys WHERE user_id = ?');
                $stp->execute(array(current_uid()));
                $n_pk = (int)$stp->fetchColumn();
            } catch (Exception $e) {
                $n_pk = 0;
            }
            echo '<div class="pk-propose" data-pk-propose hidden role="dialog" aria-label="Accesso più veloce">'
               . '<div class="pkp-ico">' . icon('lock', 22) . '</div><div class="pkp-body"><b>Entra più veloce su questo dispositivo</b>'
               . '<span>' . ($n_pk ? 'Hai già una chiave di accesso (per esempio in Bitwarden)? Usala con «Accedi con una chiave di accesso». Oppure creane una anche qui: '
                   : 'Crea una chiave di accesso: ') . 'la prossima volta entri con Face ID, l\'impronta o il PIN, senza password.</span>'
               . '<div class="alert error" data-pk-propose-msg hidden></div>'
               . '<div class="pkp-act"><button type="button" class="btn primary small" data-pk-propose-go>Crea la chiave</button>'
               . '<button type="button" class="btn ghost small" data-pk-propose-later>Non ora</button>'
               . '<button type="button" class="btn link small" data-pk-propose-never>Non chiedere più su questo dispositivo</button></div></div></div>';
            if (!in_array('js/passkey.js', $scripts, true)) {
                $scripts[] = 'js/passkey.js';
            }
        }
    }
    // configurazione per gli script (niente JavaScript in linea: lo vieta la Content-Security-Policy)
    echo '<script type="application/json" id="app-config">' . json_encode(array('csrf' => csrf_token()) + avvisi_config(), JSON_HEX_TAG | JSON_HEX_AMP) . '</script>';
    $v = (int)@filemtime(APP_ROOT . '/js/app.js');
    echo '<script src="js/app.js?v=' . $v . '"></script>';
    if (is_user() && is_file(APP_ROOT . '/js/campanella.js')) {
        echo '<script src="js/campanella.js?v=' . (int)@filemtime(APP_ROOT . '/js/campanella.js') . '"></script>';
        if (is_file(APP_ROOT . '/js/avvisi_push.js')) {
            echo '<script src="js/avvisi_push.js?v=' . (int)@filemtime(APP_ROOT . '/js/avvisi_push.js') . '"></script>';
        }
    }
    foreach ($scripts as $s) {
        echo '<script src="' . h($s) . '?v=' . (int)@filemtime(APP_ROOT . '/' . $s) . '"></script>';
    }
    if (function_exists('lib_filter')) {
        echo (string)lib_filter('html_fondo', '');
    }
    echo '</body></html>';
}

function json_attr($data)
{
    return h(json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
}
