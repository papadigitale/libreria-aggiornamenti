<?php
/*
 * "Sto leggendo" in cima alla Libreria (1.9.21): i libri in lettura con la barra di avanzamento
 * e la casella per scrivere a che pagina sei arrivato, senza aprire la scheda del libro.
 * Il salvataggio passa da api.php?action=progresso (js/sto_leggendo.js); senza JavaScript il modulo va alla scheda del libro.
 */
function sto_leggendo_html($uid)
{
    if (!function_exists('reading_ready') || !reading_ready() || setting('home_reading', '1') !== '1') {
        return '';
    }
    $libri = reading_current($uid, 4);
    if (!$libri) {
        return '';
    }
    $h = '<section class="card sto-leggendo" aria-labelledby="sl-tit"><div class="ct" id="sl-tit">' . icon('books', 18) . ' Sto leggendo</div>';
    foreach ($libri as $b) {
        $tot = (int)$b['pages'];
        $p = $b['_punto'];
        $perc = $p && $p['percent'] !== null ? max(0, min(100, (float)$p['percent'])) : 0;
        $pag = $p && $p['page'] !== null ? (int)$p['page'] : '';
        $id = (int)$b['id'];
        $h .= '<div class="slr" data-slr="' . $id . '">'
            . '<a class="slr-cop" href="libro.php?id=' . $id . '#lettura" aria-hidden="true" tabindex="-1">' . book_cover_html($b) . '</a>'
            . '<div class="slr-info"><a class="slr-t" href="libro.php?id=' . $id . '#lettura">' . h($b['title']) . '</a>'
            . ($b['authors'] !== '' ? '<span class="slr-a">' . h($b['authors']) . '</span>' : '')
            . '<div class="progress slr-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int)round($perc) . '" aria-label="Avanzamento"><i style="width:' . round($perc, 1) . '%"></i></div>'
            . '<span class="slr-txt" data-slr-txt>' . h(reading_point_text($p, $tot)) . '</span>'
            . '<form class="slr-form" method="post" action="libro.php?id=' . $id . '" data-slr-form>' . csrf_field()
            . '<input type="hidden" name="action" value="progresso"><input type="hidden" name="mode" value="' . ($tot > 0 ? 'page' : 'percent') . '">'
            . '<input class="input" type="number" name="value" inputmode="numeric" min="0"' . ($tot > 0 ? ' max="' . $tot . '"' : ' max="100" step="0.1"')
            . ' value="' . h((string)$pag) . '" placeholder="' . ($tot > 0 ? 'Pagina' : '%') . '" aria-label="' . ($tot > 0 ? 'Pagina a cui sei arrivato' : 'Percentuale letta') . ' di ' . h($b['title']) . '">'
            . '<button class="btn primary small" type="submit">Salva</button></form>'
            . '<div class="slr-msg" data-slr-msg aria-live="polite"></div>'
            . '<form class="slr-fine" method="post" action="libro.php?id=' . $id . '" data-slr-fine' . ($perc >= 100 ? '' : ' hidden') . '>' . csrf_field()
            . '<input type="hidden" name="action" value="terminata"><button class="btn ghost small" type="submit">' . icon('check', 15) . ' L\'ho finito</button></form>'
            . '</div></div>';
    }
    return $h . '</section>';
}
