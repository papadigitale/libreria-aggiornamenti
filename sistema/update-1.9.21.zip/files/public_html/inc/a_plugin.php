<?php
require_once APP_ROOT . '/inc/plugins.php';
require_once APP_ROOT . '/inc/firma.php';
$fpub = firma_chiave_pubblica();
$sodium = firma_disponibile();
$rows = plugins_rows();
$safe = plugins_safe_mode();
$base = dirname(APP_ROOT);
$labels = array('ok' => array('Integro', 'ok'), 'errore' => array('Spento per un errore', 'bad'), 'manomesso' => array('Bloccato: file modificati', 'bad'));
?>
<?php if (!plugins_ready()): ?>
<div class="alert error">Il database non è ancora aggiornato: apri Sistema → Stato del sistema.</div>
<?php return; endif; ?>

<?php if ($safe): ?>
<div class="alert warn"><b>Modalità sicura attiva:</b> nessun plugin viene caricato.
  <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="plg_safe"><input type="hidden" name="on" value="0">
    <button class="btn link small" type="submit">Disattiva la modalità sicura</button></form></div>
<?php endif; ?>

<div class="adm-grid2">
  <?php require APP_ROOT . '/inc/a_chiave_card.php'; ?>

  <div class="card">
    <div class="ct"><?= admin_icon('upload', 18) ?> Installa o aggiorna un plugin</div>
    <form method="post" enctype="multipart/form-data" class="stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="plg_upload">
      <input class="input" type="file" name="plugin_zip" accept=".zip,application/zip" required <?= $fpub && $sodium ? '' : 'disabled' ?>>
      <button class="btn primary small" type="submit" <?= $fpub && $sodium ? '' : 'disabled' ?>>Carica e controlla la firma</button>
    </form>
    <p class="hint">Il sito controlla la firma e ogni file. Un plugin nuovo resta spento finché non lo attivi; uno già attivo viene aggiornato senza spegnerlo.
      Se lo stesso plugin c'è già, viene sostituito dalla versione caricata.</p>
  </div>
</div>

<div class="card">
  <div class="ct"><?= admin_icon('plug', 18) ?> Plugin installati</div>
  <?php if (!$rows): ?>
    <p class="sub">Nessun plugin installato.</p>
  <?php else: ?>
  <div class="plg-list">
    <?php foreach ($rows as $r): $st = isset($labels[$r['status']]) ? $labels[$r['status']] : array($r['status'], 'warn'); ?>
    <div class="plg-item <?= (int)$r['active'] ? 'on' : '' ?>">
      <?php
      // icona del plugin (plugin.json → "icona": "file/icona.png")
      $pinfo = json_decode((string)@file_get_contents(plugins_dir() . '/' . $r['id'] . '/plugin.json'), true);
      $pico = is_array($pinfo) && isset($pinfo['icona']) && preg_match('#^[A-Za-z0-9._\-/]{1,120}\.(png|jpg|jpeg|webp)$#', (string)$pinfo['icona']) ? (string)$pinfo['icona'] : '';
      ?>
      <div class="plg-ico"><?php if ($pico !== ''): ?><img src="plugin_file.php?p=<?= h(rawurlencode($r['id'])) ?>&amp;f=<?= h(rawurlencode($pico)) ?>&amp;icona=1&amp;v=<?= h(rawurlencode($r['version'])) ?>" alt="" width="44" height="44"><?php else: ?><?= admin_icon('plug', 22) ?><?php endif; ?></div>
      <div class="plg-main">
        <b><?= h($r['name']) ?></b> <span class="muted">versione <?= h($r['version']) ?><?= $r['author'] ? ' · di ' . h($r['author']) : '' ?></span>
        <?php if ($r['description']): ?><p class="sub"><?= h($r['description']) ?></p><?php endif; ?>
        <div class="plg-tags">
          <span class="ptag <?= (int)$r['active'] ? 'ok' : '' ?>"><?= (int)$r['active'] ? 'Attivo' : 'Spento' ?></span>
          <span class="ptag <?= h($st[1]) ?>"><?= h($st[0]) ?></span>
          <span class="ptag">firma <?= h(firma_impronta_leggibile(substr((string)$r['key_id'], 0, 8))) ?>…</span>
        </div>
        <?php if ($r['error']): ?><p class="err-text small"><?= h($r['error']) ?></p><?php endif; ?>
        <?php
        $pages = array();
        foreach (isset($GLOBALS['PLG_PAGES']) ? $GLOBALS['PLG_PAGES'] : array() as $k => $pg) {
            if ($pg['plugin']->id === $r['id']) {
                $pages[$k] = $pg['title'];
            }
        }
        ?>
        <?php if ($pages): ?><div class="plg-links"><?php foreach ($pages as $k => $t): ?><a class="link" href="gestione.php?sez=<?= h($k) ?>"><?= h($t) ?></a><?php endforeach; ?></div><?php endif; ?>
      </div>
      <div class="plg-act">
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= h($r['id']) ?>">
          <?php if ((int)$r['active']): ?>
            <input type="hidden" name="action" value="plg_off"><button class="btn ghost small" type="submit">Disattiva</button>
          <?php else: ?>
            <input type="hidden" name="action" value="plg_on"><button class="btn primary small" type="submit" <?= $fpub && $sodium ? '' : 'disabled' ?>>Attiva</button>
          <?php endif; ?>
        </form>
        <details class="plg-del"><summary class="btn link small">Rimuovi…</summary>
          <form method="post" class="stack" data-confirm="Rimuovere il plugin &quot;<?= h($r['name']) ?>&quot;?">
            <?= csrf_field() ?><input type="hidden" name="action" value="plg_del"><input type="hidden" name="id" value="<?= h($r['id']) ?>">
            <label class="check"><input type="checkbox" name="delete_data" value="1"> Cancella anche le sue impostazioni e i suoi dati</label>
            <button class="btn danger-ghost small" type="submit">Rimuovi il plugin</button></form>
        </details>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="row-btn" style="margin-top:12px">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="plg_check"><button class="btn ghost small" type="submit"><?= admin_icon('shield', 15) ?> Ricontrolla firma e file di tutti i plugin</button></form>
    <?php if (!$safe): ?>
    <form method="post" data-confirm="Attivare la modalità sicura? Nessun plugin verrà caricato finché non la disattivi.">
      <?= csrf_field() ?><input type="hidden" name="action" value="plg_safe"><input type="hidden" name="on" value="1"><button class="btn link small" type="submit">Modalità sicura</button></form>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<?php require APP_ROOT . '/inc/a_plugin_repo.php'; ?>

<?php if ($fpub && $sodium && firma_privata_presente()): ?>
<div class="card">
  <div class="ct"><?= admin_icon('edit', 18) ?> Firma un pacchetto</div>
  <p class="sub">Carica un plugin o un aggiornamento non firmato: viene firmato con la tua chiave e lo scarichi pronto da installare (qui o su altri siti con la tua chiave pubblica).</p>
  <form method="post" enctype="multipart/form-data" class="sign-form">
    <?= csrf_field() ?><input type="hidden" name="action" value="plg_sign">
    <input class="input" type="file" name="sign_zip" accept=".zip,application/zip" required>
    <input class="input" type="password" name="passphrase" required autocomplete="off" placeholder="Passphrase della chiave">
    <button class="btn primary small" type="submit">Firma e scarica</button>
  </form>
  <p class="hint">Dopo 5 passphrase sbagliate la firma si blocca per 15 minuti e il tentativo finisce nel log.</p>
</div>
<?php endif; ?>

<details class="card">
  <summary><b>Come si crea un plugin</b></summary>
  <p class="sub">Un plugin è una cartella con <code>plugin.json</code> e <code>plugin.php</code>. Lo scheletro pronto si crea con:</p>
  <pre class="cmd">php strumenti/crea_plugin.php nuovo mio-plugin "Il mio plugin"
php strumenti/crea_plugin.php pacchetto mio-plugin      (crea lo ZIP e lo firma)</pre>
  <p class="sub">Nel codice ricevi <code>$plugin</code> e ti agganci ai punti del sito:</p>
  <table class="tbl compact">
    <thead><tr><th>Punto</th><th>Tipo</th><th>Riceve</th><th>Quando</th></tr></thead>
    <tbody><?php foreach (plugin_hooks_doc() as $k => $d): ?><tr><td><code><?= h($k) ?></code></td><td><?= h($d[0]) ?></td><td><code><?= h($d[1]) ?></code></td><td><?= h($d[2]) ?></td></tr><?php endforeach; ?></tbody>
  </table>
  <p class="hint">In più: <code>$plugin-&gt;admin_page()</code> (pagine qui nel pannello), <code>$plugin-&gt;api()</code> (chiamate dal JavaScript),
    <code>$plugin-&gt;setting()</code> / <code>save_setting()</code>, <code>$plugin-&gt;table()</code>, <code>$plugin-&gt;url()</code> per css, js e immagini.
    Gli script vanno in file .js (il sito non esegue JavaScript scritto dentro la pagina). La guida completa ha un esempio commentato.</p>
</details>
