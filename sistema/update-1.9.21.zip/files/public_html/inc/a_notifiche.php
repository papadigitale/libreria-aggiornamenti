<?php
/* Sistema → Notifiche sul telefono (1.9.16): interruttore generale, stato, prova */
require_once APP_ROOT . '/inc/push.php';
$pronto = push_ready();
$supp = push_supportato();
$on = setting('push_on', '1') === '1';
$https = is_https();
$curl = function_exists('curl_init');
$nd = $nu = 0;
$errori = array();
if ($pronto) {
    $nd = (int)db()->query('SELECT COUNT(*) FROM push_subscriptions')->fetchColumn();
    $nu = (int)db()->query('SELECT COUNT(DISTINCT user_id) FROM push_subscriptions')->fetchColumn();
    $errori = db()->query('SELECT p.user_agent, p.last_error, p.fails, u.username, u.display_name FROM push_subscriptions p JOIN users u ON u.id = p.user_id WHERE p.fails > 0 ORDER BY p.fails DESC LIMIT 10')->fetchAll();
}
$mie = $pronto ? count(push_dispositivi(current_uid())) : 0;
$riga = function ($nome, $ok, $testo) {
    return '<div class="fr row"><span>' . h($nome) . '</span><span class="' . ($ok ? 'ok-text' : 'err-text') . '">' . ($ok ? admin_icon('check', 14) . ' ' : '') . h($testo) . '</span></div>';
};
?>
<?php if (!$pronto): ?>
<div class="alert warn">Il database non è ancora aggiornato: apri Sistema → Aggiornamento.</div>
<?php return; endif; ?>
<div class="adm-grid2">
  <form method="post" class="card stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="push_admin_salva">
    <div class="ct"><?= admin_icon('bell', 18) ?> Notifiche sul telefono</div>
    <p class="sub">Gli avvisi della campanella arrivano anche come notifiche del telefono o del computer, a sito chiuso.
      Ognuno le attiva sui suoi dispositivi in <b>Il mio account</b>, dove sceglie anche i tipi, l'orario di silenzio e il suono.</p>
    <label class="check switch"><input type="checkbox" name="push_on" value="1" <?= $on ? 'checked' : '' ?>><span><b>Notifiche sul telefono attive per tutto il sito</b></span></label>
    <p class="hint">Spente: nessuno riceve notifiche e il pulsante per attivarle sparisce; gli avvisi restano nella campanella. I dispositivi già attivati restano registrati e riprendono quando le riaccendi.</p>
    <label class="lab" for="push-c">Email di contatto per i servizi di notifica</label>
    <input class="input" id="push-c" type="email" name="push_contatto" maxlength="190" value="<?= h(setting('push_contatto', '')) ?>" placeholder="facoltativa: altrimenti quella del primo Admin">
    <p class="hint">Google, Apple e Mozilla la usano solo per contattarti se ci fossero problemi con gli invii del sito.</p>
    <button class="btn primary small" type="submit">Salva</button>
  </form>

  <div class="card">
    <div class="ct"><?= admin_icon('check', 18) ?> Requisiti</div>
    <?= $riga('Indirizzo https://', $https, $https ? 'sì' : 'no: aprendo il sito dall\'indirizzo IP le notifiche non si attivano') ?>
    <?= $riga('OpenSSL con curva P-256 e AES-GCM', $supp, $supp ? 'presente' : 'mancante: aggiorna PHP o OpenSSL') ?>
    <?= $riga('cURL', $curl, $curl ? 'presente (invii in parallelo)' : 'assente: si usa il metodo lento') ?>
    <?= $riga('Chiavi del sito (VAPID)', push_chiave_pubblica() !== '', push_chiave_pubblica() !== '' ? 'pronte' : 'si creano quando le notifiche sono attive') ?>
    <div class="fr row"><span>Dispositivi registrati</span><span><?= $nd ?> (<?= $nu === 1 ? '1 persona' : $nu . ' persone' ?>)</span></div>
    <p class="hint">Il server deve poter uscire su internet verso i servizi di notifica (fcm.googleapis.com, web.push.apple.com, push.services.mozilla.com).
      Su iPhone e iPad le notifiche arrivano solo all'app aggiunta alla schermata Home (iOS 16.4 o successivo).</p>
    <form method="post" class="row-btn"><?= csrf_field() ?><input type="hidden" name="action" value="push_admin_prova">
      <button class="btn ghost small" type="submit" <?= $mie && push_attivo() ? '' : 'disabled' ?>>Manda una prova ai miei dispositivi</button></form>
    <?php if (!$mie): ?><p class="hint">Per la prova attiva prima le notifiche su un tuo dispositivo, in <a class="link" href="account.php#notifiche-push">Il mio account</a>.</p><?php endif; ?>
  </div>
</div>

<?php if ($errori): ?>
<div class="card">
  <div class="ct"><?= admin_icon('warn', 18) ?> Notifiche non arrivate</div>
  <table class="tbl compact"><thead><tr><th>Utente</th><th>Dispositivo</th><th>Tentativi falliti</th><th>Ultimo errore</th></tr></thead><tbody>
  <?php foreach ($errori as $e): ?>
    <tr><td><?= h($e['display_name'] !== '' ? $e['display_name'] : $e['username']) ?></td><td><?= h(push_nome_dispositivo($e['user_agent'])) ?></td><td><?= (int)$e['fails'] ?></td><td><?= h((string)$e['last_error']) ?></td></tr>
  <?php endforeach; ?></tbody></table>
  <p class="hint">Un dispositivo che non risponde per 30 tentativi e 30 giorni viene tolto da solo; se il permesso è stato tolto sul telefono, sparisce subito.</p>
</div>
<?php endif; ?>

<details class="card">
  <summary><b>Rinnova le chiavi del sito</b></summary>
  <p class="sub">Da fare solo se pensi che la chiave privata sia uscita dal server (per esempio un backup completo finito nelle mani sbagliate).
    I dispositivi si riattivano da soli alla prossima apertura del sito.</p>
  <form method="post" data-confirm="Rinnovare le chiavi delle notifiche? Tutti i dispositivi andranno riattivati."><?= csrf_field() ?><input type="hidden" name="action" value="push_admin_chiavi">
    <button class="btn danger-ghost small" type="submit">Rinnova le chiavi</button></form>
</details>
