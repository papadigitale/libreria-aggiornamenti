<?php
/*
 * Repository degli aggiornamenti e dei plugin (1.9.8).
 *
 * Il repository e' una cartella di file statici raggiungibile in HTTPS (es. un repository GitHub letto da raw.githubusercontent.com):
 *   indice.json          catalogo FIRMATO con la chiave dell'autore (versione del sistema, plugin disponibili, impronte dei file)
 *   sistema/update-X.zip  aggiornamenti (gia' firmati)
 *   plugin/<id>-X.zip     plugin (gia' firmati) e plugin/<id>.png (icone)
 *
 * Il sito controlla una volta al giorno (o con "Controlla adesso"), verifica la firma del catalogo con la chiave pubblica
 * dell'autore, non accetta cataloghi piu' vecchi dell'ultimo visto e AVVISA soltanto: installa l'Admin, con i controlli di sempre
 * (impronta SHA-256 del file scaricato = quella del catalogo firmato, poi la firma del pacchetto stesso).
 */
require_once dirname(__FILE__) . '/firma.php';
require_once dirname(__FILE__) . '/http.php'; // anche nei lavori periodici e da riga di comando

define('REPO_MAX_INDEX', 2 * 1048576);
define('REPO_MAX_FILE', 100 * 1048576);

function repo_url()
{
    $u = trim((string)setting('repo_url', ''));
    return repo_url_valida($u) ? rtrim($u, '/') . '/' : '';
}

function repo_url_valida($u)
{
    return (bool)preg_match('#^https://[A-Za-z0-9.\-]+(:\d+)?(/[A-Za-z0-9._~%\-/]*)?$#', (string)$u) && strlen($u) <= 300;
}

function repo_attivo()
{
    return repo_url() !== '' && setting('repo_check', '1') === '1';
}

function repo_dir()
{
    $d = DATA_DIR . '/repo';
    if (!is_dir($d)) {
        @mkdir($d, 0775, true);
        @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return $d;
}

/* ---------------- Firma del catalogo ---------------- */

function repo_messaggio($contenuto)
{
    return "libreria-di-casa/indice/v1\n" . $contenuto;
}

// Crea il file indice.json firmato (usato dall'officina). $priv = firma_apri_privata()
function repo_firma_indice($dati, $priv)
{
    $contenuto = json_encode($dati, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    $sig = sodium_crypto_sign_detached(repo_messaggio($contenuto), $priv[0]);
    return json_encode(array('formato' => 1, 'tipo' => 'indice-libreria-di-casa', 'autore' => $priv[2], 'impronta' => $priv[1],
        'chiave' => base64_encode(substr($priv[0], 32)), 'contenuto' => $contenuto, 'firma' => base64_encode($sig)),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n";
}

/*
 * Controlla un indice.json. $pk = chiave pubblica con cui verificarlo (null = la chiave contenuta nel file, solo per proporla).
 * Restituisce array(dati, intestazione) oppure lancia un'eccezione.
 */
function repo_verifica_indice($raw, $pk = null)
{
    $d = json_decode((string)$raw, true);
    if (!is_array($d) || (int)(isset($d['formato']) ? $d['formato'] : 0) !== 1 || !isset($d['tipo'], $d['contenuto'], $d['firma'], $d['impronta'], $d['chiave'])
        || $d['tipo'] !== 'indice-libreria-di-casa') {
        throw new Exception('Il file indice.json non è un catalogo della Libreria di Casa.');
    }
    $chiave = base64_decode((string)$d['chiave'], true);
    if ($chiave === false || strlen($chiave) !== 32 || !hash_equals(firma_impronta($chiave), (string)$d['impronta'])) {
        throw new Exception('Il catalogo contiene una chiave non valida.');
    }
    $pk = $pk === null ? $chiave : $pk;
    $sig = base64_decode((string)$d['firma'], true);
    if (!firma_disponibile() || $sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES
        || !sodium_crypto_sign_verify_detached($sig, repo_messaggio((string)$d['contenuto']), $pk)) {
        throw new Exception('Firma del catalogo NON valida: il repository è stato modificato oppure non è firmato con la chiave di questo sito.');
    }
    $dati = json_decode((string)$d['contenuto'], true);
    if (!is_array($dati) || !isset($dati['app'], $dati['seq']) || $dati['app'] !== 'libreria-di-casa') {
        throw new Exception('Catalogo non valido.');
    }
    return array($dati, array('autore' => (string)(isset($d['autore']) ? $d['autore'] : ''), 'impronta' => (string)$d['impronta'], 'chiave' => $chiave));
}

/* ---------------- Controllo del repository ---------------- */

// Scarica e verifica il catalogo. Restituisce array(ok, messaggio)
function repo_controlla()
{
    $url = repo_url();
    if ($url === '') {
        return array(false, 'Indirizzo del repository non impostato.');
    }
    setting_save('repo_checked_at', (string)time());
    $r = http_get($url . 'indice.json?t=' . time(), 15, REPO_MAX_INDEX, 'public');
    if ((int)$r['code'] !== 200) {
        $msg = $r['code'] === 404 ? 'Nel repository non c\'è ancora il catalogo (indice.json): pubblica il primo pacchetto dall\'officina.'
            : 'Repository non raggiungibile' . ($r['error'] !== '' ? ': ' . $r['error'] : ' (risposta ' . (int)$r['code'] . ')') . '.';
        setting_save('repo_error', $msg);
        return array(false, $msg);
    }
    $pub = firma_chiave_pubblica();
    try {
        if (!$pub) {
            // nessuna chiave su questo sito: si controlla che il catalogo sia coerente e si propone la sua chiave all'Admin
            list($dati, $int) = repo_verifica_indice($r['body'], null);
            setting_save('repo_chiave_proposta', json_encode(array('autore' => $int['autore'], 'impronta' => $int['impronta'], 'chiave' => base64_encode($int['chiave']))));
            $msg = 'Il catalogo è firmato da «' . $int['autore'] . '» (impronta ' . firma_impronta_leggibile($int['impronta']) . '), ma su questo sito non c\'è ancora una chiave dell\'autore.';
            setting_save('repo_error', $msg);
            return array(false, $msg);
        }
        list($dati, $int) = repo_verifica_indice($r['body'], $pub['pk']);
    } catch (Exception $e) {
        setting_save('repo_error', $e->getMessage());
        app_log('repository', $e->getMessage(), 'alert', '');
        return array(false, $e->getMessage());
    }
    $visto = (int)setting('repo_seq', '0');
    if ((int)$dati['seq'] < $visto) {
        $msg = 'Il repository ha mandato un catalogo più vecchio di quello già visto: ignorato (può succedere per qualche minuto subito dopo una pubblicazione; se continua, qualcuno sta ripresentando una versione vecchia).';
        setting_save('repo_error', $msg);
        app_log('repository', $msg, 'alert', '');
        return array(false, $msg);
    }
    setting_save('repo_seq', (string)(int)$dati['seq']);
    setting_save('repo_cache', json_encode($dati, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    setting_save('repo_error', '');
    setting_save('repo_chiave_proposta', '');
    load_settings(true);
    repo_scarica_icone($dati);
    $nuova = repo_aggiornamento();
    if ($nuova && setting('repo_annunciata', '') !== $nuova['versione']) {
        setting_save('repo_annunciata', $nuova['versione']);
        app_log('aggiornamento_disponibile', 'È disponibile la versione ' . $nuova['versione'] . ' (installata: ' . APP_VERSION . ')', 'warn', '');
    }
    // nuove versioni dei plugin installati: un avviso all'Admin per ogni versione
    if (function_exists('plugins_rows') && is_file(dirname(__FILE__) . '/notifiche.php')) {
        require_once dirname(__FILE__) . '/notifiche.php';
        $visti = json_decode((string)setting('repo_plg_annunciati', '{}'), true);
        $visti = is_array($visti) ? $visti : array();
        foreach (plugins_rows() as $pr) {
            $pv = isset($dati['plugin'][$pr['id']]) ? $dati['plugin'][$pr['id']] : null;
            if ($pv && version_compare((string)$pv['versione'], (string)$pr['version'], '>') && (!isset($visti[$pr['id']]) || $visti[$pr['id']] !== $pv['versione'])) {
                $visti[$pr['id']] = (string)$pv['versione'];
                notif_invia('aggiornamenti', 'Aggiornamento per il plugin «' . $pr['name'] . '»: versione ' . $pv['versione'] . ' (installata ' . $pr['version'] . ')', 'gestione.php?sez=plugin#disponibili');
            }
        }
        setting_save('repo_plg_annunciati', json_encode($visti));
    }
    return array(true, 'Catalogo aggiornato (' . count(isset($dati['plugin']) ? (array)$dati['plugin'] : array()) . ' plugin' . ($nuova ? ', nuova versione ' . $nuova['versione'] : ', il sito è aggiornato') . ').');
}

// Ogni quante ore controllare (Sistema → Aggiornamento): 1, 3, 6 (predefinito), 12 o 24
function repo_intervallo()
{
    $h = (int)setting('repo_intervallo', '6');
    return in_array($h, array(1, 3, 6, 12, 24), true) ? $h : 6;
}

// Con i lavori periodici (cron del server ogni 15 minuti, oppure alla prima visita utile)
function repo_due()
{
    return repo_attivo() && (int)setting('repo_checked_at', '0') < time() - repo_intervallo() * 3600 + 120;
}

function repo_dati()
{
    $d = json_decode((string)setting('repo_cache', ''), true);
    return is_array($d) ? $d : null;
}

function repo_compatibile($voce)
{
    $req = isset($voce['richiede']) ? (string)$voce['richiede'] : '';
    $php = isset($voce['php_min']) ? (string)$voce['php_min'] : '';
    return ($req === '' || version_compare(APP_VERSION, $req, '>=')) && ($php === '' || version_compare(PHP_VERSION, $php, '>='));
}

// Versione del sistema piu' recente di quella installata (con le note di tutte le versioni saltate), oppure null
function repo_aggiornamento()
{
    $d = repo_dati();
    if (!$d || empty($d['sistema']['versione']) || !version_compare((string)$d['sistema']['versione'], APP_VERSION, '>')) {
        return null;
    }
    $s = $d['sistema'];
    $note = array();
    foreach (isset($s['storico']) ? (array)$s['storico'] : array() as $v) {
        if (isset($v['versione']) && version_compare((string)$v['versione'], APP_VERSION, '>')) {
            $note[] = $v;
        }
    }
    usort($note, function ($a, $b) { return version_compare($b['versione'], $a['versione']); });
    $s['tutte_le_note'] = $note;
    $s['compatibile'] = repo_compatibile($s);
    return $s;
}

/* ---------------- Download ---------------- */

function repo_percorso_ok($rel)
{
    return (bool)preg_match('#^(sistema|plugin)/[A-Za-z0-9._\-]{1,120}\.(zip|png|jpg|webp)$#', (string)$rel);
}

// Scarica un file del catalogo e controlla dimensione e impronta. Restituisce il contenuto o lancia un'eccezione.
function repo_scarica($rel, $sha256, $dim)
{
    $url = repo_url();
    if ($url === '' || !repo_percorso_ok($rel) || !preg_match('/^[a-f0-9]{64}$/', (string)$sha256) || (int)$dim < 1 || (int)$dim > REPO_MAX_FILE) {
        throw new Exception('Voce del catalogo non valida.');
    }
    $r = http_get($url . $rel, 120, (int)$dim + 1, 'public');
    if ((int)$r['code'] !== 200) {
        throw new Exception('Download non riuscito' . ($r['error'] !== '' ? ': ' . $r['error'] : ' (risposta ' . (int)$r['code'] . ')') . '.');
    }
    if (strlen($r['body']) !== (int)$dim || !hash_equals((string)$sha256, hash('sha256', $r['body']))) {
        throw new Exception('Il file scaricato non corrisponde al catalogo firmato (impronta diversa): installazione annullata.');
    }
    return $r['body'];
}

// Icone dei plugin: si scaricano una volta e si tengono in data/repo (il browser non le chiede a siti esterni)
function repo_scarica_icone($dati)
{
    foreach (isset($dati['plugin']) ? (array)$dati['plugin'] : array() as $id => $p) {
        if (!plugin_id_ok_repo($id) || empty($p['icona']['file'])) {
            continue;
        }
        $f = repo_dir() . '/icona-' . $id . '.png';
        if (is_file($f) && hash_equals((string)$p['icona']['sha256'], hash_file('sha256', $f))) {
            continue;
        }
        try {
            $bin = repo_scarica($p['icona']['file'], $p['icona']['sha256'], $p['icona']['dim']);
            if (@getimagesizefromstring($bin)) {
                @file_put_contents($f, $bin);
            }
        } catch (Exception $e) {
            // senza icona si mostra quella predefinita
        }
    }
}

function plugin_id_ok_repo($id)
{
    return (bool)preg_match('/^[a-z0-9][a-z0-9\-]{1,40}$/', (string)$id);
}

function repo_icona_data_uri($id)
{
    $f = repo_dir() . '/icona-' . $id . '.png';
    if (!plugin_id_ok_repo($id) || !is_file($f) || filesize($f) > 512000) {
        return '';
    }
    $info = @getimagesize($f);
    return $info ? 'data:' . $info['mime'] . ';base64,' . base64_encode((string)file_get_contents($f)) : '';
}

/* ---------------- Fidarsi della chiave del repository (solo se il sito non ne ha una) ---------------- */

function repo_chiave_proposta()
{
    $p = json_decode((string)setting('repo_chiave_proposta', ''), true);
    return is_array($p) && isset($p['chiave'], $p['impronta'], $p['autore']) && !firma_chiave_pubblica() ? $p : null;
}

function repo_fidati_chiave($impronta_confermata)
{
    $p = repo_chiave_proposta();
    if (!$p || !hash_equals($p['impronta'], strtoupper(str_replace(' ', '', (string)$impronta_confermata)))) {
        throw new Exception('Chiave non disponibile o impronta diversa.');
    }
    if (is_file(firma_pub_file())) {
        throw new Exception('Su questo sito c\'è già una chiave dell\'autore.');
    }
    $pk = base64_decode($p['chiave'], true);
    if ($pk === false || strlen($pk) !== 32 || firma_impronta($pk) !== $p['impronta']) {
        throw new Exception('Chiave non valida.');
    }
    firma_scrivi_pubblica($p['autore'], $pk);
    setting_save('repo_chiave_proposta', '');
}
