// Notifiche sul telefono e suoni degli avvisi (1.9.16)
//  - suono quando arriva un avviso con il sito aperto (5 suoni disegnati qui, senza file audio)
//  - registrazione del service worker e iscrizione del dispositivo alle notifiche (Il mio account)
(function () {
  'use strict';
  var cfg = {};
  try { cfg = JSON.parse(document.getElementById('app-config').textContent); } catch (e) { /* niente */ }

  /* ---------------- Suoni ---------------- */
  var ctx = null;
  function audio() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { return null; }
      try { ctx = new AC(); } catch (e) { return null; }
    }
    if (ctx.state === 'suspended') { ctx.resume().catch(function () {}); }
    return ctx;
  }
  // i browser fanno suonare una pagina solo dopo un tocco o un tasto: si "sblocca" l'audio al primo gesto
  ['pointerdown', 'keydown', 'touchstart'].forEach(function (ev) {
    document.addEventListener(ev, function sblocca() { audio(); document.removeEventListener(ev, sblocca, true); }, true);
  });

  function nota(c, t, freq, dur, vol, tipo, scivola) {
    var o = c.createOscillator(), g = c.createGain();
    o.type = tipo || 'sine';
    o.frequency.setValueAtTime(freq, t);
    if (scivola) { o.frequency.exponentialRampToValueAtTime(scivola, t + dur * 0.8); }
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(c.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }
  var SUONI = {
    campanello: function (c, t) { nota(c, t, 1318.5, 0.5, 0.22); nota(c, t, 2637, 0.25, 0.05); nota(c, t + 0.16, 987.8, 0.7, 0.2); nota(c, t + 0.16, 1975.5, 0.3, 0.04); },
    goccia: function (c, t) { nota(c, t, 1500, 0.16, 0.3, 'sine', 480); nota(c, t + 0.12, 900, 0.12, 0.1, 'sine', 600); },
    arpa: function (c, t) { [1046.5, 1318.5, 1568, 2093].forEach(function (f, i) { nota(c, t + i * 0.075, f, 0.55, 0.13, 'triangle'); }); },
    pop: function (c, t) { nota(c, t, 720, 0.09, 0.35, 'sine', 180); nota(c, t + 0.1, 960, 0.08, 0.2, 'sine', 300); },
    carillon: function (c, t) { [1568, 1318.5, 1046.5].forEach(function (f, i) { nota(c, t + i * 0.18, f, 0.9, 0.14); nota(c, t + i * 0.18, f * 3, 0.35, 0.025); }); }
  };
  var ultimoSuono = 0;
  function suona(nome, forza) {
    nome = nome === undefined ? cfg.suono : nome;
    if (!nome || !SUONI[nome]) { return; }
    var ora = Date.now();
    if (!forza && ora - ultimoSuono < 2500) { return; } // un avviso solo, anche se arriva da due strade
    ultimoSuono = ora;
    var c = audio();
    if (c) { SUONI[nome](c, c.currentTime + 0.02); }
    try { if (navigator.vibrate && document.visibilityState === 'visible') { navigator.vibrate(60); } } catch (e) { /* niente */ }
  }
  window.LibSuono = { suona: suona, nomi: Object.keys(SUONI) };
  document.addEventListener('lib:nuovo-avviso', function () { suona(); });

  /* ---------------- Service worker e notifiche ---------------- */
  var push = cfg.push || {};
  var puoPush = !!(push.attivo && push.chiave && window.isSecureContext && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window);
  var registrazione = null;

  function api(azione, dati) {
    var fd = new FormData();
    fd.append('csrf', cfg.csrf || '');
    Object.keys(dati || {}).forEach(function (k) { fd.append(k, dati[k]); });
    return fetch('api.php?action=' + azione, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf || '' } })
      .then(function (r) { return r.json(); });
  }
  function chiaveBin(b64) {
    var s = String(b64).replace(/[^A-Za-z0-9\-_]/g, '').replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) { s += '='; }
    var raw = atob(s), out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) { out[i] = raw.charCodeAt(i); }
    return out;
  }
  function b64u(buf) {
    var s = '', b = new Uint8Array(buf);
    for (var i = 0; i < b.length; i++) { s += String.fromCharCode(b[i]); }
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function iscrivi(sub) {
    var j = sub.toJSON();
    return api('push_iscrivi', { endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth });
  }
  function stessaChiave(sub) {
    try { return b64u(sub.options.applicationServerKey) === push.chiave; } catch (e) { return true; }
  }

  if (puoPush) {
    navigator.serviceWorker.register('sw.js').then(function (reg) {
      registrazione = reg;
      if (Notification.permission !== 'granted') { return null; }
      return reg.pushManager.getSubscription().then(function (sub) {
        if (!sub) { return null; }
        if (!stessaChiave(sub)) {
          // il sito ha cambiato le sue chiavi: si rifa' l'iscrizione da solo
          return sub.unsubscribe().then(function () {
            return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: chiaveBin(push.chiave) });
          }).then(iscrivi);
        }
        // una volta al giorno si ricorda al sito questo dispositivo (l'iscrizione puo' essere cambiata)
        var k = 'lib-push-' + sub.endpoint.slice(-24), oggi = new Date().toDateString();
        var fatto = null;
        try { fatto = localStorage.getItem(k); } catch (e) { /* niente */ }
        if (fatto === oggi) { return null; }
        return iscrivi(sub).then(function () { try { localStorage.setItem(k, oggi); } catch (e) { /* niente */ } });
      });
    }).catch(function () { /* niente */ }).then(aggiornaRiquadro);
    navigator.serviceWorker.addEventListener('message', function (e) {
      if (e.data && e.data.tipo === 'avviso') {
        if (e.data.davanti) { suona(); }
        document.dispatchEvent(new CustomEvent('lib:aggiorna-avvisi'));
      }
    });
  }

  /* ---------------- Riquadro in Il mio account ---------------- */
  var box = document.querySelector('[data-push]');
  var scelta = document.querySelector('[data-suono-scelta]');
  var ascolta = document.querySelector('[data-suono-ascolta]');
  if (ascolta && scelta) {
    ascolta.addEventListener('click', function () { suona(scelta.value, true); });
    scelta.addEventListener('change', function () { suona(scelta.value, true); });
  }

  function stato(testo, tipo) {
    var s = box && box.querySelector('[data-push-stato]');
    if (s) { s.textContent = testo; s.className = 'push-stato ' + (tipo || ''); }
  }
  function mostra(sel, si) { var e = box && box.querySelector(sel); if (e) { e.hidden = !si; } }

  function aggiornaRiquadro() {
    if (!box) { return; }
    var ios = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    var app = window.matchMedia && (window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true);
    mostra('[data-push-attiva]', false); mostra('[data-push-spegni]', false); mostra('[data-push-prova]', false); mostra('[data-push-prova-chiuso]', false); mostra('[data-push-ios]', false); mostra('[data-push-android]', /Android/i.test(navigator.userAgent));
    if (!push.attivo) { stato('Le notifiche sul telefono sono spente per tutto il sito (le accende l\'amministratore).', 'off'); return; }
    if (!window.isSecureContext) { stato('Le notifiche funzionano solo aprendo il sito dal suo indirizzo https://.', 'off'); return; }
    if (ios && !app) { stato('Su iPhone e iPad le notifiche arrivano solo all\'app sulla schermata Home.', 'off'); mostra('[data-push-ios]', true); return; }
    if (!puoPush) { stato('Questo browser non riceve notifiche dai siti.', 'off'); return; }
    if (Notification.permission === 'denied') { stato('Hai bloccato le notifiche di questo sito: riattivale dalle impostazioni del browser (lucchetto accanto all\'indirizzo) o del telefono.', 'off'); return; }
    var reg = registrazione ? Promise.resolve(registrazione) : navigator.serviceWorker.ready;
    reg.then(function (r) { return r.pushManager.getSubscription(); }).then(function (sub) {
      if (sub && Notification.permission === 'granted') {
        stato('Attive su questo dispositivo.', 'on');
        mostra('[data-push-spegni]', true); mostra('[data-push-prova]', true); mostra('[data-push-prova-chiuso]', true);
      } else {
        stato('Non attive su questo dispositivo.', '');
        mostra('[data-push-attiva]', true);
      }
    }).catch(function () { stato('Non attive su questo dispositivo.', ''); mostra('[data-push-attiva]', true); });
  }

  if (box) {
    aggiornaRiquadro();
    var bA = box.querySelector('[data-push-attiva]'), bS = box.querySelector('[data-push-spegni]'), bP = box.querySelector('[data-push-prova]');
    var esito = box.querySelector('[data-push-esito]');
    var avvisa = function (t, err) { if (esito) { esito.hidden = false; esito.textContent = t; esito.className = 'alert ' + (err ? 'error' : 'success'); } };
    if (bA) {
      bA.addEventListener('click', function () {
        bA.disabled = true;
        audio(); // gia' che c'e' un tocco: sblocca anche il suono
        Notification.requestPermission().then(function (perm) {
          if (perm !== 'granted') { throw new Error('Permesso non concesso: senza il tuo consenso il browser non mostra notifiche.'); }
          return (registrazione ? Promise.resolve(registrazione) : navigator.serviceWorker.register('sw.js')).then(function (r) { registrazione = r; return navigator.serviceWorker.ready; });
        }).then(function (r) {
          return r.pushManager.getSubscription().then(function (s) {
            return s || r.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: chiaveBin(push.chiave) });
          });
        }).then(iscrivi).then(function (j) {
          if (!j || !j.ok) { throw new Error(j && j.error ? j.error : 'Il sito non ha registrato il dispositivo.'); }
          avvisa('Notifiche attivate su questo dispositivo. Premi «Prova» per riceverne una.');
          setTimeout(function () { location.reload(); }, 1600);
        }).catch(function (e) { avvisa(e && e.message ? e.message : 'Attivazione non riuscita.', true); bA.disabled = false; aggiornaRiquadro(); });
      });
    }
    if (bS) {
      bS.addEventListener('click', function () {
        bS.disabled = true;
        navigator.serviceWorker.ready.then(function (r) { return r.pushManager.getSubscription(); }).then(function (sub) {
          if (!sub) { return null; }
          var ep = sub.endpoint;
          return sub.unsubscribe().then(function () { return api('push_togli', { endpoint: ep }); });
        }).then(function () { avvisa('Notifiche spente su questo dispositivo.'); setTimeout(function () { location.reload(); }, 1200); })
          .catch(function () { avvisa('Non sono riuscito a spegnerle: riprova.', true); bS.disabled = false; });
      });
    }
    var bC = box.querySelector('[data-push-prova-chiuso]');
    if (bC) {
      bC.addEventListener('click', function () {
        bC.disabled = true;
        api('push_prova', { ritardo: '1' }).then(function (j) {
          if (!j.ok) { bC.disabled = false; avvisa(j.error || 'Prova non riuscita.', true); return; }
          avvisa('Ora chiudi l\'app (anche dall\'elenco delle app recenti) e blocca lo schermo: tra 20 secondi arriva la notifica. Se non arriva, segui i consigli per Android qui sotto.');
          setTimeout(function () { bC.disabled = false; }, 25000);
        }).catch(function () { bC.disabled = false; avvisa('Connessione non riuscita.', true); });
      });
    }
    if (bP) {
      bP.addEventListener('click', function () {
        bP.disabled = true;
        api('push_prova', {}).then(function (j) {
          bP.disabled = false;
          if (!j.ok) { avvisa(j.error || 'Prova non riuscita.', true); return; }
          var ok = j.esiti.filter(function (x) { return x.ok; }).length;
          avvisa(ok ? 'Notifica mandata a ' + ok + (ok === 1 ? ' dispositivo' : ' dispositivi') + (j.esiti.length > ok ? ' (non arrivata a: ' + j.esiti.filter(function (x) { return !x.ok; }).map(function (x) { return x.nome + ' – ' + x.errore; }).join('; ') + ')' : '') + '.'
            : 'Non è partita: ' + j.esiti.map(function (x) { return x.nome + ' – ' + x.errore; }).join('; '), !ok);
        }).catch(function () { bP.disabled = false; avvisa('Connessione non riuscita.', true); });
      });
    }
  }
})();
