// Libreria: tieni premuto il dito su una copertina (o clic destro sul computer) per cambiare lo stato di lettura (1.9.13)
(function () {
  'use strict';
  var cfg = {};
  try { cfg = JSON.parse(document.getElementById('app-config').textContent); } catch (e) { /* niente */ }
  var STATI = [['da_leggere', 'Da leggere'], ['in_lettura', 'In lettura'], ['letto', 'Letto'], ['abbandonato', 'Abbandonato'], ['', 'Nessuna etichetta']];
  var sheet = null, current = null, blockClick = false;

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) { e.className = cls; } if (text !== undefined) { e.textContent = text; } return e; }

  function chiudi() {
    if (!sheet) { return; }
    sheet.classList.remove('open');
    var s = sheet; sheet = null;
    setTimeout(function () { s.remove(); }, 200);
    document.removeEventListener('keydown', esc);
  }
  function esc(e) { if (e.key === 'Escape') { chiudi(); } }

  function avviso(testo, errore) {
    var t = el('div', 'quick-toast' + (errore ? ' err' : ''), testo);
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 300); }, 3200);
  }

  function aggiorna(id, stato, etichetta) {
    document.querySelectorAll('.item[data-book="' + id + '"]').forEach(function (a) {
      a.setAttribute('data-status', stato);
      var r = a.querySelector('.ribbon');
      if (!stato) { if (r) { r.remove(); } return; }
      if (!r) { r = el('span'); var cov = a.querySelector('.cover'); if (cov && cov.nextSibling) { a.insertBefore(r, cov.nextSibling); } else { a.appendChild(r); } }
      r.className = 'ribbon ' + stato;
      r.textContent = etichetta;
    });
  }

  function scegli(stato) {
    var a = current;
    if (!a) { return; }
    var id = a.getAttribute('data-book');
    var fd = new FormData();
    fd.append('id', id); fd.append('status', stato); fd.append('csrf', cfg.csrf || '');
    sheet && sheet.querySelectorAll('button').forEach(function (b) { b.disabled = true; });
    fetch('api.php?action=book_status', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf || '' } })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        chiudi();
        if (!j.ok) { avviso(j.error || 'Non è stato possibile salvare.', true); return; }
        aggiorna(id, j.status, j.label);
        avviso(j.message || 'Salvato.');
      })
      .catch(function () { chiudi(); avviso('Connessione non riuscita: riprova.', true); });
  }

  function apri(a) {
    chiudi();
    current = a;
    var stato = a.getAttribute('data-status') || '';
    sheet = el('div', 'quick-sheet');
    sheet.setAttribute('role', 'dialog');
    sheet.setAttribute('aria-modal', 'true');
    var back = el('div', 'qs-back');
    back.addEventListener('click', chiudi);
    var box = el('div', 'qs-box');
    box.appendChild(el('div', 'qs-grip'));
    var tit = el('div', 'qs-title', a.getAttribute('data-title') || '');
    box.appendChild(tit);
    box.appendChild(el('div', 'qs-sub', 'La mia lettura'));
    STATI.forEach(function (s) {
      if (s[0] === '' && stato === '') { return; }
      var b = el('button', 'qs-opt' + (s[0] === stato ? ' on' : ''));
      b.type = 'button';
      if (s[0]) { b.appendChild(el('i', 'qs-dot ' + s[0])); }
      b.appendChild(el('span', '', s[1]));
      if (s[0] === stato) { b.appendChild(el('b', 'qs-check', '✓')); }
      b.addEventListener('click', function () { if (s[0] !== stato) { scegli(s[0]); } else { chiudi(); } });
      box.appendChild(b);
    });
    var open = el('a', 'qs-link', 'Apri la scheda del libro');
    open.href = a.getAttribute('href');
    box.appendChild(open);
    var no = el('button', 'qs-cancel', 'Annulla');
    no.type = 'button';
    no.addEventListener('click', chiudi);
    box.appendChild(no);
    sheet.appendChild(back);
    sheet.appendChild(box);
    document.body.appendChild(sheet);
    requestAnimationFrame(function () { sheet && sheet.classList.add('open'); });
    document.addEventListener('keydown', esc);
    if (navigator.vibrate) { try { navigator.vibrate(12); } catch (e) { /* niente */ } }
  }

  // pressione lunga (dito o mouse): 500 ms senza muoversi
  var timer = null, startX = 0, startY = 0, target = null;
  function annulla() { clearTimeout(timer); timer = null; target = null; }
  document.addEventListener('pointerdown', function (e) {
    var a = e.target.closest && e.target.closest('.item[data-book]');
    if (!a || (e.pointerType === 'mouse' && e.button !== 0)) { return; }
    target = a; startX = e.clientX; startY = e.clientY;
    clearTimeout(timer);
    timer = setTimeout(function () { if (target) { blockClick = true; apri(target); } timer = null; }, 500);
  }, { passive: true });
  document.addEventListener('pointermove', function (e) {
    if (timer && (Math.abs(e.clientX - startX) > 10 || Math.abs(e.clientY - startY) > 10)) { annulla(); }
  }, { passive: true });
  ['pointerup', 'pointercancel', 'scroll'].forEach(function (ev) { document.addEventListener(ev, function () { if (timer) { annulla(); } }, { passive: true, capture: true }); });
  // dopo la pressione lunga il "clic" non deve aprire la scheda
  document.addEventListener('click', function (e) {
    if (blockClick && e.target.closest && e.target.closest('.item[data-book]')) { e.preventDefault(); e.stopPropagation(); }
    blockClick = false;
  }, true);
  // clic destro sul computer e menu del browser sul telefono
  document.addEventListener('contextmenu', function (e) {
    var a = e.target.closest && e.target.closest('.item[data-book]');
    if (!a) { return; }
    e.preventDefault();
    if (!sheet) { annulla(); blockClick = true; apri(a); }
  });
})();
