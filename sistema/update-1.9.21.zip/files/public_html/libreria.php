<?php
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/books.php';
require_once APP_ROOT . '/inc/extras.php';
require_once APP_ROOT . '/inc/search.php';
require_once APP_ROOT . '/inc/chips.php';
require_once APP_ROOT . '/inc/reading.php';
require_login();

$uid = current_uid();
$q = str_cut(get('q'), 100);
$cat = (int)get('cat');
$stato = get('stato');
$et = (int)get('et');           // valore di un'etichetta personalizzata
$et_row = $et > 0 ? term_get($et) : null;
if (!$et_row) {
    $et = 0;
}
$maxpag = max(0, (int)get('maxpag'));
$dal = max(0, (int)get('dal'));
$sort = get('ordine', 'recenti');
$per = 30;
$page = max(1, min(20, (int)get('p', '1')));
$focus = get('cerca') === '1';

$sorts = array('recenti' => 'Aggiunti di recente', 'titolo' => 'Titolo (A-Z)', 'autore' => 'Autore (A-Z)', 'anno' => 'Anno di edizione', 'pagine' => 'Numero di pagine');
if (!isset($sorts[$sort])) {
    $sort = 'recenti';
}
// pulsanti sotto la ricerca: scelti dall'Admin (Gestione → Sezioni → Pulsanti della libreria)
$chips = chips_visible();
$stati = array();
foreach ($chips as $ch) {
    if ($ch['t'] !== 'genere' && $ch['t'] !== 'etichetta') {
        $stati[$ch['k']] = $ch['n'];
    }
}
if ($stato === '' || !isset($stati[$stato])) {
    $stato = '';
}

$where = array('1=1');
$params = array($uid);
$search = null;
$relevance_order = '';
if ($q !== '') {
    // ricerca per parole chiave (pezzi di parola, senza accenti, con piccoli errori): vedi inc/search.php
    $search = book_search($q);
    list($cond, $relevance_order) = search_sql_in($search['ids']);
    $where[] = $cond;
}
if ($cat > 0) {
    $where[] = 'b.category_id = ?';
    $params[] = $cat;
}
if ($et > 0) {
    $where[] = 'b.id IN (SELECT book_id FROM book_terms WHERE term_id = ?)';
    $params[] = $et;
}
if ($maxpag > 0) {
    $where[] = 'b.pages > 0 AND b.pages <= ?';
    $params[] = $maxpag;
}
if ($dal > 0) {
    $where[] = 'b.pub_year >= ?';
    $params[] = $dal;
}
if ($stato !== '') {
    $cw = chip_where($stato, $uid, $params);
    if ($cw !== '') {
        $where[] = $cw;
    }
}
$order = array('recenti' => ($q !== '' && in_array(get('ordine'), array('', 'recenti'), true) && $relevance_order !== '' ? $relevance_order . ', ' : '') . 'b.created_at DESC, b.id DESC', 'titolo' => 'b.title ASC', 'autore' => 'b.authors ASC, b.title ASC',
    'anno' => 'b.pub_year DESC, b.title ASC', 'pagine' => 'b.pages ASC, b.title ASC');
$base = 'FROM books b LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = ? WHERE ' . implode(' AND ', $where);

$st = db()->prepare('SELECT COUNT(*) ' . $base);
$st->execute($params);
$found = (int)$st->fetchColumn();

$st = db()->prepare('SELECT b.id, b.title, b.authors, b.cover_file, b.pub_year, ub.status AS my_status ' . $base
    . ' ORDER BY ' . $order[$sort] . ' LIMIT ' . (int)($per * $page));
$st->execute($params);
$books = $st->fetchAll();

$tot = db()->query('SELECT COUNT(*) AS n, COUNT(DISTINCT authors) AS a, COUNT(DISTINCT publisher) AS e FROM books')->fetch();
$filtered = $q !== '' || $cat > 0 || $stato !== '' || $et > 0 || $maxpag > 0 || $dal > 0;

/* Pagina iniziale (nessuna ricerca/filtro): riga "aggiunti di recente" + tutti i libri per autore con indice alfabetico */
$home = !$filtered && $sort === 'recenti' && get('p') === '';
$byLetter = array();
// Righe della pagina iniziale decise in Gestione → Sezioni (senza database aggiornato: le due righe predefinite)
$sections = extras_ready() ? home_sections_all() : array(
    array('id' => 0, 'title' => 'Aggiunti di recente', 'kind' => 'recent', 'param' => '', 'max_items' => 6),
    array('id' => 0, 'title' => 'Tutti i libri per autore', 'kind' => 'authors', 'param' => '', 'max_items' => 0),
);
if ($home && !$sections) {
    $home = false; // nessuna riga attiva: elenco semplice
}
$has_authors = false;
foreach ($sections as $sec) {
    if ($sec['kind'] === 'authors') {
        $has_authors = true;
    }
}
if ($home && (int)$tot['n'] > 0 && $has_authors) {
    $st = db()->prepare('SELECT b.id, b.title, b.authors, b.cover_file, ub.status AS my_status FROM books b '
        . 'LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = ?');
    $st->execute(array($uid));
    $all = $st->fetchAll();
    foreach ($all as $i => $b) {
        $info = author_sort_info($b['authors']);
        $all[$i]['_key'] = $info[0] . '|' . str_fold($b['title']);
        $all[$i]['_letter'] = $info[1];
    }
    usort($all, function ($a, $b) {
        return strcmp($a['_key'], $b['_key']);
    });
    foreach ($all as $b) {
        $byLetter[$b['_letter']][] = $b;
    }
    if (isset($byLetter['#'])) { // senza autore in fondo
        $tmp = $byLetter['#'];
        unset($byLetter['#']);
        $byLetter['#'] = $tmp;
    }
}

function lib_item($b, $extra = '')
{
    $h = '<a class="item' . $extra . '" href="libro.php?id=' . (int)$b['id'] . '"' . (is_user() ? ' data-book="' . (int)$b['id'] . '" data-title="' . h($b['title']) . '" data-status="' . h((string)$b['my_status']) . '"' : '') . '>' . book_cover_html($b);
    if (is_user() && $b['my_status']) {
        $h .= '<span class="ribbon ' . h($b['my_status']) . '">' . h(status_label($b['my_status'])) . '</span>';
    }
    return $h . '<span class="it">' . h($b['title']) . '</span><span class="ia">' . h($b['authors']) . '</span>' . lib_stars_html($b['id']) . '</a>';
}

function lib_url($over)
{
    global $q, $cat, $stato, $sort;
    global $et, $maxpag, $dal;
    $p = array_merge(array('q' => $q, 'cat' => $cat ? $cat : '', 'et' => $et ? $et : '', 'maxpag' => $maxpag ? $maxpag : '', 'dal' => $dal ? $dal : '',
        'stato' => $stato, 'ordine' => $sort === 'recenti' ? '' : $sort), $over);
    $p = array_filter($p, function ($v) { return $v !== '' && $v !== null; });
    return 'libreria.php' . ($p ? '?' . http_build_query($p) : '');
}

page_start(setting('lib_title'), $focus ? 'cerca' : 'libreria');
?>
<h1 class="h1"><?= h(setting('lib_title')) ?></h1>
<div class="sub"><?= (int)$tot['n'] ?> volumi · <?= (int)$tot['a'] ?> autori · <?= (int)$tot['e'] ?> editori</div>
<?php if (is_user() && $q === '' && !$cat && !$et && $stato === '' && is_file(APP_ROOT . '/inc/sto_leggendo.php')) {
    require_once APP_ROOT . '/inc/sto_leggendo.php';
    echo sto_leggendo_html(current_uid()); // 1.9.21: i libri in lettura, con la pagina da aggiornare al volo
} ?>
<?php if (function_exists('lib_filter')) { echo (string)lib_filter('pagina_libreria', '', $q); } ?>

<form class="searchform" method="get" action="libreria.php" role="search" data-live-search>
  <div class="searchbox">
    <?= icon('search', 18) ?>
    <input type="search" name="q" value="<?= h($q) ?>" placeholder="Cerca titolo, autore, ISBN…" aria-label="Cerca" <?= $focus ? 'autofocus' : '' ?> enterkeyhint="search">
    <button class="sfilter" type="button" data-toggle="#filters" aria-label="Filtri e ordinamento"><?= icon('filter', 16) ?></button>
  </div>
  <?php if ($stato !== ''): ?><input type="hidden" name="stato" value="<?= h($stato) ?>"><?php endif; ?>
  <div class="filters card <?= ($cat || $et || $sort !== 'recenti') ? 'open' : '' ?>" id="filters">
    <label class="lab" for="f-cat">Genere</label>
    <select class="input" id="f-cat" name="cat">
      <option value="">Tutti i generi</option>
      <?php foreach (categories_all() as $c): ?>
      <option value="<?= (int)$c['id'] ?>" <?= $cat === (int)$c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <?php $ftax = array_filter(taxonomies_all(), function ($t) { return (int)$t['in_filters'] === 1; }); $fterms = terms_by_taxonomy(); ?>
    <?php if ($ftax): ?>
    <label class="lab" for="f-et">Etichetta</label>
    <select class="input" id="f-et" name="et">
      <option value="">Tutte</option>
      <?php foreach ($ftax as $tid => $t): if (empty($fterms[$tid])) { continue; } ?>
      <optgroup label="<?= h($t['name']) ?>">
        <?php foreach ($fterms[$tid] as $term): ?>
        <option value="<?= (int)$term['id'] ?>" <?= $et === (int)$term['id'] ? 'selected' : '' ?>><?= h($term['name']) ?></option>
        <?php endforeach; ?>
      </optgroup>
      <?php endforeach; ?>
    </select>
    <?php endif; ?>
    <label class="lab" for="f-ord">Ordina per</label>
    <select class="input" id="f-ord" name="ordine">
      <?php foreach ($sorts as $k => $v): ?><option value="<?= h($k) ?>" <?= $sort === $k ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?>
    </select>
    <div class="row2"><a class="btn ghost" href="libreria.php">Azzera</a><button class="btn primary" type="submit">Applica</button></div>
  </div>
</form>

<div id="lib-results" data-live-results>
<div class="chips" role="tablist">
  <?php $cat_chip = false; $et_chip = false; foreach ($chips as $ch): ?>
    <?php if ($ch['t'] === 'genere'): $on = $cat === (int)$ch['v']; $cat_chip = $cat_chip || $on; ?>
  <a class="chip <?= $on ? 'on' : '' ?>" href="<?= h(lib_url(array('cat' => $on ? '' : (int)$ch['v']))) ?>"><?= h($ch['n']) ?></a>
    <?php elseif ($ch['t'] === 'etichetta'): $on = $et === (int)$ch['v']; $et_chip = $et_chip || $on; ?>
  <a class="chip <?= $on ? 'on' : '' ?>" href="<?= h(lib_url(array('et' => $on ? '' : (int)$ch['v']))) ?>"><?= h($ch['n']) ?></a>
    <?php else: ?>
  <a class="chip <?= $stato === $ch['k'] ? 'on' : '' ?>" href="<?= h(lib_url(array('stato' => $ch['k']))) ?>"><?= h($ch['n']) ?></a>
    <?php endif; ?>
  <?php endforeach; ?>
  <?php if ($cat > 0 && !$cat_chip): ?><a class="chip on" href="<?= h(lib_url(array('cat' => ''))) ?>"><?= h(category_name($cat)) ?> ✕</a><?php endif; ?>
  <?php if ($et_row && !$et_chip): ?><a class="chip on" href="<?= h(lib_url(array('et' => ''))) ?>"><?= h($et_row['taxonomy_name'] . ': ' . $et_row['name']) ?> ✕</a><?php endif; ?>
  <?php if ($maxpag > 0): ?><a class="chip on" href="<?= h(lib_url(array('maxpag' => ''))) ?>">Fino a <?= (int)$maxpag ?> pagine ✕</a><?php endif; ?>
  <?php if ($dal > 0): ?><a class="chip on" href="<?= h(lib_url(array('dal' => ''))) ?>">Dal <?= (int)$dal ?> ✕</a><?php endif; ?>
</div>

<?php if ((int)$tot['n'] === 0): ?>
  <div class="empty card">
    <div class="empty-ico"><?= icon('books', 34) ?></div>
    <h2 class="h2">La libreria è ancora vuota</h2>
    <p class="sub">Aggiungi il primo libro con il codice ISBN o cercandolo per titolo: copertina e dati arrivano da soli.</p>
    <?php if (can_edit()): ?><a class="btn primary" href="aggiungi.php"><?= icon('plus', 18) ?> Aggiungi il primo libro</a><?php endif; ?>
  </div>
<?php elseif ($home): ?>
  <?php foreach ($sections as $sec): ?>
    <?php if ($sec['kind'] === 'authors'): ?>
  <section class="home-authors" aria-label="<?= h($sec['title']) ?>">
    <div class="sechead"><span><?= h($sec['title']) ?></span><span class="sub"><?= (int)$tot['n'] ?></span></div>
    <nav class="alpha" aria-label="Vai alla lettera">
      <?php foreach (array_merge(range('A', 'Z'), array('#')) as $L): ?>
        <?php if (isset($byLetter[$L])): ?>
          <a href="#lettera-<?= $L === '#' ? 'altri' : $L ?>"><?= h($L) ?></a>
        <?php else: ?>
          <span aria-hidden="true"><?= h($L) ?></span>
        <?php endif; ?>
      <?php endforeach; ?>
    </nav>
    <?php foreach ($byLetter as $L => $list): ?>
    <div class="letter-sec" id="lettera-<?= $L === '#' ? 'altri' : h($L) ?>">
      <div class="letter-head"><span><?= $L === '#' ? 'Altri' : h($L) ?></span><i></i><small><?= count($list) ?></small></div>
      <div class="grid">
        <?php foreach ($list as $b) { echo lib_item($b); } ?>
      </div>
    </div>
    <?php endforeach; ?>
  </section>
    <?php else: $row = extras_ready() ? home_section_books($sec, $uid) : array(); ?>
    <?php if (!extras_ready() && $sec['kind'] === 'recent') {
        $st = db()->prepare('SELECT b.id, b.title, b.authors, b.cover_file, ub.status AS my_status FROM books b '
            . 'LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = ? ORDER BY b.created_at DESC, b.id DESC LIMIT 6');
        $st->execute(array($uid));
        $row = $st->fetchAll();
    } ?>
    <?php if ($row): $link = extras_ready() ? home_section_link($sec) : 'libreria.php?ordine=recenti&p=1'; ?>
  <section class="home-recent" aria-label="<?= h($sec['title']) ?>">
    <div class="sechead"><span><?= h($sec['title']) ?></span>
      <?php if ($link !== ''): ?><a class="link" href="<?= h($link) ?>"><?= $sec['kind'] === 'recent' ? 'Vedi in ordine di arrivo' : 'Vedi tutti' ?></a><?php endif; ?></div>
    <div class="carousel" data-carousel>
      <button class="car-btn prev" type="button" aria-label="Precedenti" data-dir="-1"><?= icon('back', 20) ?></button>
      <div class="car-track">
        <?php foreach ($row as $b) { echo lib_item($b, ' car-item'); } ?>
      </div>
      <button class="car-btn next" type="button" aria-label="Successivi" data-dir="1"><?= icon('back', 20) ?></button>
    </div>
  </section>
    <?php endif; ?>
    <?php endif; ?>
  <?php endforeach; ?>
<?php else: ?>
  <div class="sechead"><span><?= $filtered ? $found . ($found === 1 ? ' libro trovato' : ' libri trovati') : h($sorts[$sort]) ?></span>
    <?php if ($filtered): ?><a class="link" href="libreria.php">Mostra tutti</a><?php endif; ?></div>
  <?php if ($search && !$search['exact'] && $books): ?>
    <p class="sub search-note">Nessun libro contiene tutte le parole cercate: ecco i più simili.</p>
  <?php endif; ?>
  <?php if (!$books): ?>
    <div class="empty card"><p class="sub">Nessun libro corrisponde alla ricerca.</p>
      <?php if (can_edit() && $q !== ''): ?><a class="btn ghost" href="aggiungi.php?<?= isbn_to13($q) !== '' ? 'isbn=' . h(rawurlencode($q)) : 'titolo=' . h(rawurlencode($q)) ?>">Cercalo online e aggiungilo</a><?php endif; ?>
    </div>
  <?php endif; ?>
  <div class="grid">
    <?php foreach ($books as $n => $b): ?>
    <a class="item" id="n<?= $n ?>" href="libro.php?id=<?= (int)$b['id'] ?>"<?php if (is_user()): ?> data-book="<?= (int)$b['id'] ?>" data-title="<?= h($b['title']) ?>" data-status="<?= h((string)$b['my_status']) ?>"<?php endif; ?>>
      <?= book_cover_html($b) ?>
      <?php if (is_user() && $b['my_status']): ?>
        <span class="ribbon <?= h($b['my_status']) ?>"><?= h(status_label($b['my_status'])) ?></span>
      <?php endif; ?>
      <span class="it"><?= h($b['title']) ?></span>
      <span class="ia"><?= h($b['authors']) ?></span>
      <?= lib_stars_html($b['id']) ?>
    </a>
    <?php endforeach; ?>
  </div>
  <?php if (count($books) < $found && $page < 20): ?>
    <a class="btn ghost more" href="<?= h(lib_url(array('p' => $page + 1))) ?>#n<?= count($books) ?>">Mostra altri libri (<?= $found - count($books) ?>)</a>
  <?php endif; ?>
<?php endif; ?>
</div>
<?php page_end(is_user() ? array('js/stato_rapido.js', 'js/sto_leggendo.js') : array()); ?>
