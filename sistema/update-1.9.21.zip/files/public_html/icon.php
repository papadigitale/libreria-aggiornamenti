<?php
/*
 * Icona dell'app per la schermata Home (Android, iPhone, Firefox, Chrome).
 * L'icona riempie tutto il quadrato (niente trasparenze), cosi' il telefono non aggiunge la cornice bianca.
 * Con un logo personalizzato (Aspetto → Logo) l'icona si costruisce dal logo, su uno sfondo pieno:
 * il colore del bordo del logo se e' pieno, altrimenti il colore principale del sito.
 *   icon.php?s=192        icona normale      icon.php?s=512&m=1   icona "maskable" (logo piu' piccolo, al centro)
 */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';

$size = in_array((int)get('s'), array(96, 180, 192, 512), true) ? (int)get('s') : 192;
$mask = get('m') === '1';
$logo = setting('logo_file');
$default = APP_ROOT . '/img/icon-' . ($size === 512 ? '512' : '192') . '.png';

function icon_send($file)
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: image/png');
    header('Cache-Control: public, max-age=604800');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}

$custom = setting('app_icon_file');
if ($custom !== '' && preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $custom) && is_file(UPLOADS_DIR . '/' . $custom)) {
    // icona caricata apposta (Aspetto → Icona dell'app): si usa intera, a tutto riquadro
    $logo = $custom;
    $full_icon = true;
} else {
    $full_icon = false;
}
$src_file = $logo !== '' && preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $logo) ? UPLOADS_DIR . '/' . $logo : '';
if ($src_file === '' || !is_file($src_file) || !function_exists('imagecreatefromstring')) {
    icon_send($default);
}
$bg_set = safe_color(setting('color_primary'), '#7a1f2b');
$key = md5($logo . '|' . filemtime($src_file) . '|' . $bg_set . '|' . $size . '|' . ($mask ? 1 : 0) . '|' . ($full_icon ? 1 : 0) . '|v3');
$cache = UPLOADS_DIR . '/appicon_' . substr($key, 0, 16) . '.png';
if (is_file($cache)) {
    icon_send($cache);
}
$src = @imagecreatefromstring(file_get_contents($src_file));
if (!$src) {
    icon_send($default);
}
$sw = imagesx($src);
$sh = imagesy($src);
// sfondo: il colore dell'angolo del logo se e' pieno (logo con il suo sfondo), altrimenti il colore principale
$px = imagecolorsforindex($src, imagecolorat($src, 0, 0));
$opaque_logo = $px['alpha'] < 10;
if ($opaque_logo) {
    $rgb = array($px['red'], $px['green'], $px['blue']);
} else {
    $h = ltrim($bg_set, '#');
    $rgb = array(hexdec(substr($h, 0, 2)), hexdec(substr($h, 2, 2)), hexdec(substr($h, 4, 2)));
}
$dst = imagecreatetruecolor($size, $size);
imagealphablending($dst, true);
imagefill($dst, 0, 0, imagecolorallocate($dst, $rgb[0], $rgb[1], $rgb[2]));
// un logo pieno e quadrato riempie l'icona; altrimenti resta al centro, dentro la zona sicura
if ($full_icon) {
    // ritaglio quadrato centrale, poi a tutto riquadro (anche per l'icona "maskable": il disegno deve stare al centro)
    $side = min($sw, $sh);
    $tmp = imagecreatetruecolor($side, $side);
    imagefill($tmp, 0, 0, imagecolorallocate($tmp, $rgb[0], $rgb[1], $rgb[2]));
    imagecopy($tmp, $src, 0, 0, (int)(($sw - $side) / 2), (int)(($sh - $side) / 2), $side, $side);
    img_free($src);
    $src = $tmp;
    $sw = $sh = $side;
    $box = 1.0;
} elseif ($opaque_logo && abs($sw - $sh) <= max($sw, $sh) * 0.04) {
    $box = $mask ? 0.80 : 1.0;
} else {
    $box = $mask ? 0.60 : 0.74;
}
$scale = min($size * $box / $sw, $size * $box / $sh);
$w = max(1, (int)round($sw * $scale));
$hgt = max(1, (int)round($sh * $scale));
imagecopyresampled($dst, $src, (int)(($size - $w) / 2), (int)(($size - $hgt) / 2), 0, 0, $w, $hgt, $sw, $sh);
if (is_dir(UPLOADS_DIR) && is_writable(UPLOADS_DIR)) {
    foreach (glob(UPLOADS_DIR . '/appicon_*.png') ?: array() as $old) {
        if (filemtime($old) < time() - 86400 * 30) {
            @unlink($old);
        }
    }
    imagepng($dst, $cache, 9);
    icon_send($cache);
}
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: image/png');
header('Cache-Control: public, max-age=86400');
imagepng($dst);
