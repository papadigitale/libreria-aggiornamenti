<?php
/*
 * Versione dei programmi e della struttura del database.
 * Il file viene sostituito da ogni aggiornamento: non modificarlo a mano.
 */
define('APP_VERSION', '1.9.21');
define('APP_DB_VERSION', 15);
