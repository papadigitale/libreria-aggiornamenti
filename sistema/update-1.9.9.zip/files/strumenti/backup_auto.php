<?php
/*
 * Backup automatico da riga di comando, da usare con il cron del server se preferisci un orario preciso
 * (altrimenti il sito lo fa da solo alla prima visita utile).
 *   php strumenti/backup_auto.php          crea il backup solo se e' il momento (Gestione → Backup → Backup automatici)
 *   php strumenti/backup_auto.php --ora    lo crea subito
 * Esempio di cron (ogni notte alle 3:15):  15 3 * * *  www-data  php /var/www/libreria/strumenti/backup_auto.php
 */
if (PHP_SAPI !== 'cli') {
    exit("Da usare solo da riga di comando.\n");
}
require dirname(dirname(__FILE__)) . '/CONF/bootstrap.php';
require_once APP_ROOT . '/inc/library_tools.php';
$force = in_array('--ora', $argv, true);
if (!$force && setting('auto_backup', 'off') === 'off') {
    echo "I backup automatici sono disattivati (Gestione → Strumenti → Backup). Usa --ora per crearne uno adesso.\n";
    exit(0);
}
$f = auto_backup_run($force);
echo $f !== '' ? "Backup creato: $f\n" : "Non è ancora il momento del prossimo backup.\n";
$n = trash_auto_purge();
if ($n) {
    echo "Cestino: $n libri eliminati definitivamente.\n";
}
if (function_exists('fw_geo_due') && fw_geo_due()) {
    $g = fw_geo_update();
    echo 'Database delle nazioni: ' . $g[1] . "\n";
}
