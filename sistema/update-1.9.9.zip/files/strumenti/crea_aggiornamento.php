<?php
/*
 * Crea il pacchetto update.zip con i programmi di questa cartella, da caricare in
 * Gestione → Sistema → Aggiornamento su un'altra installazione.
 *
 * Uso (dalla cartella del sito):
 *   php strumenti/crea_aggiornamento.php [file_di_uscita.zip] [--richiede 1.1.0] [--nota "testo"]... [--rimuovi percorso]... [--firma]
 * Con --firma il pacchetto viene firmato con la chiave dell'autore (chiede la passphrase; --privata percorso per una chiave altrove).
 * La versione e' quella scritta in CONF/version.php.
 */
if (PHP_SAPI !== 'cli') {
    exit("Da usare solo da riga di comando.\n");
}
$base = dirname(dirname(__FILE__));
define('APP_ROOT', $base . '/public_html');
require $base . '/CONF/version.php';
require APP_ROOT . '/inc/updater.php';

$out = '';
$notes = array();
$remove = array();
$requires = '';
$sign = false;
$privf = null;
$args = array_slice($argv, 1);
for ($i = 0; $i < count($args); $i++) {
    if ($args[$i] === '--nota' && isset($args[$i + 1])) {
        $notes[] = $args[++$i];
    } elseif ($args[$i] === '--rimuovi' && isset($args[$i + 1])) {
        $remove[] = $args[++$i];
    } elseif ($args[$i] === '--firma') {
        $sign = true;
    } elseif ($args[$i] === '--privata' && isset($args[$i + 1])) {
        $privf = $args[++$i];
    } elseif ($args[$i] === '--richiede' && isset($args[$i + 1])) {
        $requires = $args[++$i];
    } elseif ($out === '') {
        $out = $args[$i];
    }
}
if ($out === '') {
    $out = getcwd() . '/update-' . APP_VERSION . '.zip';
}
foreach ($remove as $r) {
    if (!updater_path_ok($r)) {
        fwrite(STDERR, "Percorso da rimuovere non ammesso: $r\n");
        exit(1);
    }
}
$m = updater_build_package($base, $out, APP_VERSION, $notes, $remove, $requires, APP_DB_VERSION);
echo "Creato $out\n  versione " . APP_VERSION . ", database " . APP_DB_VERSION . ", " . count($m['files']) . " file"
   . ($remove ? ', ' . count($remove) . ' da rimuovere' : '') . "\n";
if ($sign) {
    $cmd = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg(dirname(__FILE__) . '/firma.php') . ' firma ' . escapeshellarg($out)
        . ($privf !== null ? ' --privata ' . escapeshellarg($privf) : '');
    passthru($cmd, $rc);
    exit($rc);
}
