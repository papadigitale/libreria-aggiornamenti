<?php
/*
 * PLUGIN: scheletro e pacchetto (solo da riga di comando).
 *
 *   php strumenti/crea_plugin.php nuovo mio-plugin "Il mio plugin"
 *        crea la cartella plugin_sorgenti/mio-plugin con plugin.json, plugin.php e file/stile.css da modificare
 *   php strumenti/crea_plugin.php pacchetto mio-plugin [--senza-firma] [--privata percorso]
 *        crea plugin_sorgenti/mio-plugin-<versione>.zip e lo firma con la chiave dell'autore (chiede la passphrase)
 *   php strumenti/crea_plugin.php pacchetto percorso/della/cartella
 *        come sopra, per una cartella che si trova altrove (es. esempi/citazione-del-giorno)
 */
if (PHP_SAPI !== 'cli') {
    header('HTTP/1.1 403 Forbidden');
    exit('Solo da riga di comando.');
}
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
define('NO_PLUGINS', true);
require dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/plugins.php';

function cp_fail($m)
{
    fwrite(STDERR, "ERRORE: $m\n");
    exit(1);
}

$base = dirname(APP_ROOT);
$src_root = $base . '/plugin_sorgenti';
$args = array_slice($argv, 1);
$cmd = array_shift($args);

if ($cmd === 'nuovo') {
    $id = isset($args[0]) ? $args[0] : '';
    $nome = isset($args[1]) ? $args[1] : $id;
    if (!plugin_id_ok($id)) {
        cp_fail('identificativo non valido: minuscole, numeri e trattini (es. mio-plugin).');
    }
    $dir = $src_root . '/' . $id;
    if (is_dir($dir)) {
        cp_fail("la cartella $dir esiste già.");
    }
    @mkdir($dir . '/file', 0775, true);
    $pub = is_file($base . '/CONF/firma_autore.json') ? json_decode(file_get_contents($base . '/CONF/firma_autore.json'), true) : array();
    file_put_contents($dir . '/plugin.json', json_encode(array(
        'id' => $id, 'nome' => $nome, 'versione' => '1.0.0', 'autore' => isset($pub['autore']) ? $pub['autore'] : '',
        'descrizione' => 'Descrivi qui cosa fa il plugin.', 'richiede' => APP_VERSION, 'php_min' => '7.4',
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
    $fn = str_replace('-', '_', $id);
    file_put_contents($dir . '/plugin.php', "<?php\n/*\n * " . $nome . "\n * \$plugin e' l'oggetto di questo plugin (LibPlugin): vedi la guida, capitolo Plugin.\n"
        . " * Dai alle tue funzioni un prefisso (es. {$fn}_...) per non scontrarti con altri plugin.\n */\n\n"
        . "// foglio di stile nelle pagine del sito\n\$plugin->on('html_testa', function (\$html) use (\$plugin) {\n    return \$html . \$plugin->css('file/stile.css');\n});\n\n"
        . "// un riquadro nella scheda di ogni libro\n\$plugin->on('scheda_libro', function (\$html, \$libro) use (\$plugin) {\n"
        . "    return \$html . '<div class=\"card {$id}\">' . h(\$plugin->setting('messaggio', 'Ciao dal plugin!')) . ' — ' . h(\$libro['title']) . '</div>';\n});\n\n"
        . "// pagina nel pannello (gruppo Plugin)\n\$plugin->admin_page('impostazioni', " . var_export($nome, true) . ", function (\$plugin) {\n"
        . "    echo '<div class=\"card\">' . \$plugin->form_start('class=\"stack\"')\n"
        . "        . '<label class=\"lab\">Messaggio</label><input class=\"input\" name=\"messaggio\" value=\"' . h(\$plugin->setting('messaggio', 'Ciao dal plugin!')) . '\">'\n"
        . "        . '<div class=\"savebar\"><button class=\"btn primary small\" type=\"submit\">Salva</button></div></form></div>';\n"
        . "}, array('salva' => function (\$plugin) {\n    \$plugin->save_setting('messaggio', str_cut(post('messaggio'), 200));\n    flash('Salvato.');\n}));\n");
    file_put_contents($dir . '/file/stile.css', ".{$id}{border-left:3px solid var(--accent)}\n");
    echo "Creato $dir\n  modifica plugin.php, poi: php strumenti/crea_plugin.php pacchetto $id\n";
    exit(0);
}

if ($cmd === 'pacchetto') {
    $what = isset($args[0]) ? $args[0] : '';
    $nosign = in_array('--senza-firma', $args, true);
    $priv = null;
    foreach ($args as $i => $a) {
        if ($a === '--privata' && isset($args[$i + 1])) {
            $priv = $args[$i + 1];
        }
    }
    $dir = is_dir($what) ? rtrim($what, '/') : $src_root . '/' . $what;
    if ($what === '' || !is_file($dir . '/plugin.json')) {
        cp_fail("non trovo plugin.json in $dir");
    }
    $info = json_decode(file_get_contents($dir . '/plugin.json'), true);
    if (!is_array($info) || !plugin_id_ok(isset($info['id']) ? $info['id'] : '') || empty($info['versione'])) {
        cp_fail('plugin.json non valido (servono id, nome, versione).');
    }
    if (!is_file($dir . '/plugin.php')) {
        cp_fail('manca plugin.php');
    }
    $lint = shell_exec(escapeshellarg(PHP_BINARY) . ' -l ' . escapeshellarg($dir . '/plugin.php') . ' 2>&1');
    if (strpos((string)$lint, 'No syntax errors') === false) {
        cp_fail("errore di sintassi in plugin.php:\n$lint");
    }
    @mkdir($src_root, 0775, true);
    $out = $src_root . '/' . $info['id'] . '-' . $info['versione'] . '.zip';
    @unlink($out);
    $zip = new ZipArchive();
    if ($zip->open($out, ZipArchive::CREATE) !== true) {
        cp_fail("impossibile creare $out");
    }
    $types = plugin_file_types();
    $n = 0;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($dir) + 1));
        if (!$f->isFile() || $rel === 'firma.json' || basename($rel)[0] === '.') {
            continue;
        }
        if (!isset($types[strtolower(pathinfo($rel, PATHINFO_EXTENSION))])) {
            fwrite(STDERR, "  saltato (tipo non ammesso): $rel\n");
            continue;
        }
        $zip->addFile($f->getPathname(), $rel);
        $n++;
    }
    $zip->close();
    echo "Creato $out ($n file)\n";
    if ($nosign) {
        echo "Non firmato: firmalo con  php strumenti/firma.php firma " . $out . "  oppure dal pannello (Plugin → Firma un pacchetto).\n";
        exit(0);
    }
    passthru(escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg(dirname(__FILE__) . '/firma.php') . ' firma ' . escapeshellarg($out)
        . ($priv !== null ? ' --privata ' . escapeshellarg($priv) : ''), $rc);
    exit($rc);
}

fwrite(STDERR, "Uso:\n  php strumenti/crea_plugin.php nuovo mio-plugin \"Il mio plugin\"\n  php strumenti/crea_plugin.php pacchetto mio-plugin [--senza-firma] [--privata file]\n");
exit(1);
