<?php
/*
 * SBLOCCO DEL FIREWALL (solo da riga di comando, sul server).
 * Da usare se il firewall ti ha chiuso fuori (IP bloccato, nazione sbagliata, "solo Cloudflare").
 *
 *   php strumenti/sblocca_firewall.php            toglie tutti i blocchi e spegne nazioni e "solo Cloudflare"
 *   php strumenti/sblocca_firewall.php 1.2.3.4    sblocca solo quell'IP
 */
if (PHP_SAPI !== 'cli') {
    header('HTTP/1.1 403 Forbidden');
    exit('Solo da riga di comando.');
}
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
require dirname(__FILE__) . '/../CONF/bootstrap.php';
if (!function_exists('fw_ready') || !fw_ready()) {
    echo "Il firewall non è ancora installato (serve la versione 1.5).\n";
    exit(0);
}
if ($argc > 1) {
    fw_unblock_ip($argv[1]);
    app_log('firewall_sblocco', 'IP ' . $argv[1] . ' sbloccato da riga di comando', 'alert', 'sistema');
    echo "Fatto: l'IP {$argv[1]} è sbloccato.\n";
    exit(0);
}
db()->exec('UPDATE fw_blocks SET active = 0');
db()->exec('DELETE FROM login_attempts WHERE success = 0');
setting_save('fw_geo_mode', 'off');
setting_save('fw_cf_only', '0');
setting_save('fw_siege_until', '0');
app_log('firewall_sblocco', 'Tutti i blocchi del firewall tolti da riga di comando', 'alert', 'sistema');
echo "Fatto: tutti gli IP sono sbloccati, il blocco per nazione e \"solo Cloudflare\" sono spenti.\n";
echo "Controlla le impostazioni in Gestione → Sicurezza → Firewall.\n";
