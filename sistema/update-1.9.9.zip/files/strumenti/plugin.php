<?php
/*
 * PLUGIN: comandi di emergenza (solo da riga di comando, sul server).
 *
 *   php strumenti/plugin.php elenco                    plugin installati e stato
 *   php strumenti/plugin.php disattiva <id>            spegne un plugin
 *   php strumenti/plugin.php disattiva-tutti           spegne tutti i plugin
 *   php strumenti/plugin.php modalita-sicura on|off    con "on" nessun plugin viene caricato (anche se il pannello non si apre)
 *   php strumenti/plugin.php verifica                  ricontrolla firma e file di ogni plugin
 */
if (PHP_SAPI !== 'cli') {
    header('HTTP/1.1 403 Forbidden');
    exit('Solo da riga di comando.');
}
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
define('NO_PLUGINS', true);
require dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/plugins.php';

$cmd = isset($argv[1]) ? $argv[1] : '';
$arg = isset($argv[2]) ? $argv[2] : '';
if (!plugins_ready()) {
    fwrite(STDERR, "Il database non è ancora aggiornato alla versione 1.9.\n");
    exit(1);
}
if ($cmd === 'elenco') {
    $rows = plugins_rows();
    if (!$rows) {
        echo "Nessun plugin installato.\n";
    }
    foreach ($rows as $r) {
        printf("%-28s %-8s %-7s %s%s\n", $r['id'], $r['version'], (int)$r['active'] ? 'attivo' : 'spento', $r['status'], $r['error'] ? ' — ' . $r['error'] : '');
    }
    echo plugins_safe_mode() ? "\nMODALITA' SICURA ATTIVA: nessun plugin viene caricato.\n" : '';
    exit(0);
}
if ($cmd === 'disattiva' && plugin_id_ok($arg)) {
    plugin_deactivate($arg);
    app_log('plugin_disattivato', 'Plugin "' . $arg . '" disattivato da riga di comando', 'warn', '');
    echo "Plugin $arg spento.\n";
    exit(0);
}
if ($cmd === 'disattiva-tutti') {
    db()->exec('UPDATE plugins SET active = 0');
    app_log('plugin_disattivato', 'Tutti i plugin disattivati da riga di comando', 'warn', '');
    echo "Tutti i plugin sono spenti.\n";
    exit(0);
}
if ($cmd === 'modalita-sicura' && in_array($arg, array('on', 'off'), true)) {
    $f = plugins_dir() . '/MODALITA_SICURA';
    if ($arg === 'on') {
        @mkdir(plugins_dir(), 0775, true);
        file_put_contents($f, date('c') . " da riga di comando\n");
    } else {
        @unlink($f);
    }
    echo $arg === 'on' ? "Modalità sicura attiva.\n" : "Modalità sicura disattivata.\n";
    exit(0);
}
if ($cmd === 'verifica') {
    $bad = 0;
    foreach (plugins_rows() as $r) {
        $why = plugin_integrity($r, true);
        echo str_pad($r['id'], 28) . ($why === '' ? "OK\n" : "PROBLEMA: $why\n");
        if ($why !== '') {
            $bad++;
            plugin_set_status($r['id'], 'manomesso', $why);
        }
    }
    exit($bad ? 2 : 0);
}
fwrite(STDERR, "Uso: php strumenti/plugin.php elenco | disattiva <id> | disattiva-tutti | modalita-sicura on|off | verifica\n");
exit(1);
