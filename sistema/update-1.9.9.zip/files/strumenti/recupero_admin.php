<?php
/*
 * RECUPERO ACCESSO (solo da riga di comando, sul server).
 * Da usare se l'unico Admin ha dimenticato la password o ha perso il telefono con l'app di verifica.
 *
 *   php strumenti/recupero_admin.php admin NuovaPasswordTemporanea
 *
 * Imposta la password indicata (da cambiare al primo accesso), toglie la verifica in due passaggi,
 * riattiva l'account, gli assegna il ruolo Admin e cancella i blocchi per tentativi errati.
 */
if (PHP_SAPI !== 'cli') {
    header('HTTP/1.1 403 Forbidden');
    exit('Solo da riga di comando.');
}
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
require dirname(__FILE__) . '/../CONF/bootstrap.php';

if ($argc < 3) {
    fwrite(STDERR, "Uso: php strumenti/recupero_admin.php <utente> <nuova-password>\n");
    exit(1);
}
$user = $argv[1];
$pw = $argv[2];
if (strlen($pw) < 8) {
    fwrite(STDERR, "La password deve avere almeno 8 caratteri.\n");
    exit(1);
}
$st = db()->prepare('SELECT id FROM users WHERE username = ?');
$st->execute(array($user));
$id = $st->fetchColumn();
if ($id) {
    db()->prepare("UPDATE users SET password_hash = ?, must_change_pw = 1, totp_enabled = 0, totp_secret = NULL, active = 1, role = 'admin', updated_at = ? WHERE id = ?")
        ->execute(array(pw_hash($pw), now(), $id));
} else {
    db()->prepare("INSERT INTO users (username, display_name, password_hash, role, active, must_change_pw, created_at, updated_at) VALUES (?, ?, ?, 'admin', 1, 1, ?, ?)")
        ->execute(array($user, $user, pw_hash($pw), now(), now()));
}
db()->prepare('DELETE FROM login_attempts WHERE username = ?')->execute(array($user));
if ((int)setting('db_version', '1') >= 9) {
    // le chiavi di accesso potrebbero essere finite in mani sbagliate: si tolgono, l'utente le ricreera'
    $uidr = db()->prepare('SELECT id FROM users WHERE username = ?');
    $uidr->execute(array($user));
    db()->prepare('DELETE FROM user_passkeys WHERE user_id = ?')->execute(array((int)$uidr->fetchColumn()));
}
db()->exec("DELETE FROM settings WHERE setting_key = 'sec_ip_allow'");
if (function_exists('fw_ready') && fw_ready()) {
    // anche il firewall potrebbe tenerti fuori: blocchi tolti, nazioni e "solo Cloudflare" spenti
    db()->exec('UPDATE fw_blocks SET active = 0');
    setting_save('fw_geo_mode', 'off');
    setting_save('fw_cf_only', '0');
    setting_save('fw_siege_until', '0');
}
app_log('recupero_admin', 'Accesso ripristinato da riga di comando per "' . $user . '"', 'alert', 'sistema');
echo "Fatto: \"$user\" può accedere con la password indicata (gli verrà chiesto di cambiarla).\n";
echo "Per sicurezza è stato svuotato anche l'elenco degli IP ammessi e sono stati tolti i blocchi del firewall.\n";
