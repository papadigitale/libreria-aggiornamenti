<?php
/*
 * FIRMA DELL'AUTORE (solo da riga di comando, sul server o sul tuo computer con PHP).
 *
 *   php strumenti/firma.php crea-chiave "Nome Cognome" [--privata percorso/chiave_privata.json]
 *        crea la tua coppia di chiavi: la pubblica in CONF/firma_autore.json, la privata (cifrata con la passphrase)
 *        in data/firma/chiave_privata.json. Da questo momento il sito accetta solo plugin e aggiornamenti firmati da te.
 *   php strumenti/firma.php firma pacchetto.zip [--privata percorso]     firma un plugin o un aggiornamento
 *   php strumenti/firma.php verifica pacchetto.zip                      controlla la firma di un pacchetto
 *   php strumenti/firma.php impronta                                     mostra autore e impronta della chiave
 *
 * La passphrase viene chiesta a schermo (senza mostrarla). Per gli script si puo' usare la variabile LIBRERIA_PASSPHRASE.
 */
if (PHP_SAPI !== 'cli') {
    header('HTTP/1.1 403 Forbidden');
    exit('Solo da riga di comando.');
}
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
define('NO_PLUGINS', true);
require dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/firma.php';

function cli_fail($m)
{
    fwrite(STDERR, "ERRORE: $m\n");
    exit(1);
}

function cli_pass($prompt)
{
    $env = getenv('LIBRERIA_PASSPHRASE');
    if ($env !== false && $env !== '') {
        return $env;
    }
    fwrite(STDOUT, $prompt);
    $tty = function_exists('posix_isatty') && posix_isatty(STDIN);
    if ($tty) {
        @shell_exec('stty -echo');
    }
    $p = rtrim((string)fgets(STDIN), "\r\n");
    if ($tty) {
        @shell_exec('stty echo');
    }
    fwrite(STDOUT, "\n");
    return $p;
}

// i file creati da root devono restare leggibili dal web server (proprietario della cartella data)
function cli_own($file)
{
    if (function_exists('posix_geteuid') && posix_geteuid() === 0 && is_file($file)) {
        $o = @fileowner(DATA_DIR);
        $g = @filegroup(DATA_DIR);
        if ($o !== false) {
            @chown($file, $o);
            @chgrp($file, $g);
            @chown(dirname($file), $o);
            @chgrp(dirname($file), $g);
        }
    }
}

if (!firma_disponibile()) {
    cli_fail("serve l'estensione sodium di PHP (e zip).");
}
$args = array_slice($argv, 1);
$cmd = array_shift($args);
$priv = null;
$rest = array();
for ($i = 0; $i < count($args); $i++) {
    if ($args[$i] === '--privata' && isset($args[$i + 1])) {
        $priv = $args[++$i];
    } else {
        $rest[] = $args[$i];
    }
}

if ($cmd === 'crea-chiave') {
    $autore = isset($rest[0]) ? $rest[0] : '';
    if ($autore === '') {
        cli_fail('scrivi il nome dell\'autore: php strumenti/firma.php crea-chiave "Nome Cognome"');
    }
    echo "Crea la chiave dell'autore per: $autore\n";
    echo "Scegli una passphrase lunga (almeno 12 caratteri, meglio 4-5 parole). Senza passphrase la chiave non si apre: conservala bene.\n";
    $p1 = cli_pass('Passphrase: ');
    $p2 = getenv('LIBRERIA_PASSPHRASE') ? $p1 : cli_pass('Ripeti la passphrase: ');
    if ($p1 !== $p2) {
        cli_fail('le due passphrase non coincidono.');
    }
    try {
        $imp = firma_crea_chiavi($autore, $p1, $priv);
    } catch (Exception $e) {
        cli_fail($e->getMessage());
    }
    $pf = $priv === null ? firma_priv_file() : $priv;
    cli_own($pf);
    cli_own(firma_pub_file());
    app_log('firma_chiave_creata', 'Creata la chiave dell\'autore "' . $autore . '" (impronta ' . $imp . ')', 'alert', '');
    echo "\nFatto.\n  Autore:          $autore\n  Impronta:        " . firma_impronta_leggibile($imp) . "\n";
    echo "  Chiave pubblica: " . firma_pub_file() . "\n  Chiave privata:  $pf\n\n";
    echo "IMPORTANTE: copia la chiave privata sul tuo computer o in una chiavetta (insieme alla passphrase, in un posto sicuro).\n";
    echo "Se la tieni anche qui, dal pannello (Plugin → Firma un pacchetto) puoi firmare inserendo la passphrase.\n";
    echo "Da ora il sito installa solo plugin e aggiornamenti firmati con questa chiave.\n";
    exit(0);
}

if ($cmd === 'firma') {
    $zip = isset($rest[0]) ? $rest[0] : '';
    if ($zip === '' || !is_file($zip)) {
        cli_fail('indica il file .zip da firmare.');
    }
    $tipo = firma_tipo_zip($zip);
    if ($tipo === '') {
        cli_fail('il file non è né un plugin (plugin.json) né un aggiornamento (libreria-update.json).');
    }
    $pf = $priv === null ? firma_priv_file() : $priv;
    if (!is_file($pf)) {
        cli_fail("chiave privata non trovata ($pf). Usa --privata percorso.");
    }
    try {
        $k = firma_apri_privata(cli_pass('Passphrase della chiave: '), $pf);
        $pub = firma_chiave_pubblica();
        if ($pub && !hash_equals($pub['impronta'], $k[1])) {
            fwrite(STDERR, "ATTENZIONE: questa chiave privata non corrisponde alla chiave pubblica di questo sito.\n");
        }
        $d = firma_firma_zip($zip, $k, $tipo);
    } catch (Exception $e) {
        cli_fail($e->getMessage());
    }
    echo "Firmato ($tipo, " . $d['file'] . " file) da " . $d['autore'] . ", impronta " . firma_impronta_leggibile($d['impronta']) . "\n";
    exit(0);
}

if ($cmd === 'verifica') {
    $zip = isset($rest[0]) ? $rest[0] : '';
    if ($zip === '' || !is_file($zip)) {
        cli_fail('indica il file .zip da controllare.');
    }
    $tipo = firma_tipo_zip($zip);
    $r = firma_verifica_zip($zip, $tipo);
    echo ($r['stato'] === 'firmato' ? 'OK: ' : 'NO: ') . $r['testo'] . "\n";
    exit($r['stato'] === 'firmato' ? 0 : 2);
}

if ($cmd === 'impronta') {
    $pub = firma_chiave_pubblica();
    if (!$pub) {
        echo "Nessuna chiave dell'autore su questo sito. Creala con: php strumenti/firma.php crea-chiave \"Nome Cognome\"\n";
        exit(1);
    }
    echo "Autore:   " . $pub['autore'] . "\nImpronta: " . firma_impronta_leggibile($pub['impronta']) . "\nCreata:   " . $pub['creata'] . "\n";
    echo "Chiave privata sul server: " . (firma_privata_presente() ? 'sì (' . firma_priv_file() . ')' : 'no') . "\n";
    exit(0);
}

fwrite(STDERR, "Uso:\n  php strumenti/firma.php crea-chiave \"Nome Cognome\" [--privata file]\n  php strumenti/firma.php firma pacchetto.zip [--privata file]\n"
    . "  php strumenti/firma.php verifica pacchetto.zip\n  php strumenti/firma.php impronta\n");
exit(1);
