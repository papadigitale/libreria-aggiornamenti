<?php
/*
 * Elenco di TUTTE le voci personalizzabili dal pannello Gestione.
 * Formato: chiave => array(gruppo, etichetta, valore predefinito, tipo [, opzioni])
 *   gruppi:  aspetto | testi | sicurezza   -> solo Admin
 *            ricerca                       -> Admin e Gestore
 *   tipi:    text | textarea | color | number | bool | select | font | code
 * I valori salvati (tabella settings) sovrascrivono questi predefiniti.
 */
function setting_defaults()
{
    return array(
        // --- Aspetto: colori (predefinito = stile "Biblioteca Classica")
        'theme_preset'     => array('aspetto', 'Stile di partenza', 'classica', 'text'),
        'color_primary'    => array('aspetto', 'Colore principale (pulsanti, evidenze)', '#7a1f2b', 'color'),
        'color_on_primary' => array('aspetto', 'Testo sopra il colore principale', '#fbf6ec', 'color'),
        'color_accent'     => array('aspetto', 'Colore di accento (dettagli, ruota)', '#b8893b', 'color'),
        'color_bg'         => array('aspetto', 'Sfondo pagina', '#f3ebdd', 'color'),
        'color_panel'      => array('aspetto', 'Sfondo riquadri', '#fbf6ec', 'color'),
        'color_soft'       => array('aspetto', 'Sfondo tenue (selezioni)', '#efe2cb', 'color'),
        'color_ink'        => array('aspetto', 'Testo principale', '#2b1d14', 'color'),
        'color_muted'      => array('aspetto', 'Testo secondario', '#7a6552', 'color'),
        'color_line'       => array('aspetto', 'Bordi e linee', '#e2d5bf', 'color'),
        'color_ok'         => array('aspetto', 'Colore conferme', '#2e7d4f', 'color'),
        'color_danger'     => array('aspetto', 'Colore avvisi/errori', '#b3261e', 'color'),

        // --- Aspetto: sfondo
        'bg_type'          => array('aspetto', 'Tipo di sfondo', 'solid', 'select', array(
                                  'solid' => 'Tinta unita', 'gradient' => 'Sfumatura', 'pattern' => 'Motivo a righe', 'paper' => 'Carta', 'image' => 'Immagine caricata')),
        'bg_image'         => array('aspetto', 'Immagine di sfondo', '', 'hidden'),
        'bg_overlay'       => array('aspetto', 'Velatura sopra l\'immagine (0-90%)', '70', 'number'),

        // --- Aspetto: caratteri e forme
        'font_head'        => array('aspetto', 'Carattere dei titoli', 'pagella', 'font'),
        'font_body'        => array('aspetto', 'Carattere del testo', 'lora', 'font'),
        'font_head_google' => array('aspetto', 'Titoli: nome Google Font (se scelto "Google Fonts")', '', 'text'),
        'font_body_google' => array('aspetto', 'Testo: nome Google Font (se scelto "Google Fonts")', '', 'text'),
        'font_size'        => array('aspetto', 'Dimensione testo (px)', '15', 'number'),
        'radius'           => array('aspetto', 'Arrotondamento angoli (px)', '6', 'number'),
        'grid_cols'        => array('aspetto', 'Copertine per riga su smartphone', '3', 'select', array('2' => '2', '3' => '3', '4' => '4')),
        'cover_shadow'     => array('aspetto', 'Ombra sotto le copertine', '1', 'bool'),
        'logo_file'        => array('aspetto', 'Logo', '', 'hidden'),
        'icon_style'       => array('aspetto', 'Stile delle icone', 'classiche', 'hidden'),
        'icon_accent'      => array('aspetto', 'Icone nel colore di accento', '0', 'hidden'),
        'app_icon_file'    => array('aspetto', 'Icona dell\'app', '', 'hidden'),
        'custom_css'       => array('aspetto', 'CSS personalizzato (avanzato)', '', 'code'),

        // --- Testi
        'brand_kicker'     => array('testi', 'Sopratitolo del marchio', 'La mia', 'text'),
        'brand_title'      => array('testi', 'Nome del sito', 'Libreria di Casa', 'text'),
        'login_title'      => array('testi', 'Titolo pagina di accesso', 'Bentornato in biblioteca', 'text'),
        'login_intro'      => array('testi', 'Testo pagina di accesso', 'Accedi per consultare e gestire la tua raccolta di libri.', 'textarea'),
        'btn_guest'        => array('testi', 'Tasto accesso ospite', 'Sfoglia come ospite', 'text'),
        'lib_title'        => array('testi', 'Titolo pagina Libreria', 'I miei libri', 'text'),
        'add_title'        => array('testi', 'Titolo pagina Aggiungi', 'Aggiungi libro', 'text'),
        // --- Libreria: stelle sotto le copertine (Gestione → Sezioni → Pagina iniziale)
        'lib_stars'        => array('libreria', 'Stelle sotto le copertine', 'mio', 'select', array(
                                  'off' => 'Non mostrare le stelle', 'mio' => 'Il voto di chi guarda (solo i libri che ha valutato)',
                                  'media' => 'La media dei voti di tutti gli utenti')),
        'wheel_title'      => array('testi', 'Titolo pagina Ruota', 'Ruota di lettura', 'text'),
        'wheel_intro'      => array('testi', 'Sottotitolo pagina Ruota', 'Non sai cosa leggere? Lascia scegliere alla ruota.', 'text'),
        'wheel_spin_btn'   => array('testi', 'Tasto gira la ruota', 'Gira la ruota', 'text'),
        'footer_text'      => array('testi', 'Testo a piè di pagina', '', 'text'),

        // --- Ricerca online (Admin e Gestore)
        'lookup_google'    => array('ricerca', 'Google Books (catalogo mondiale, buona copertura italiana)', '1', 'bool'),
        'lookup_shops'     => array('ricerca', 'La Feltrinelli e IBS (schede e copertine delle edizioni italiane)', '1', 'bool'),
        'lookup_sbn'       => array('ricerca', 'OPAC SBN – catalogo delle biblioteche italiane (tutte le edizioni pubblicate in Italia)', '1', 'bool'),
        'lookup_goodreads' => array('ricerca', 'Goodreads (scheda pubblica del libro: non è un servizio ufficiale, può essere bloccato)', '0', 'bool'),
        'lookup_openlib'   => array('ricerca', 'Open Library (catalogo internazionale con copertine)', '1', 'bool'),
        'lookup_amazon'    => array('ricerca', 'Copertine di riserva da Amazon', '1', 'bool'),
        'google_api_key'   => array('ricerca', 'Chiave API Google Books (facoltativa)', '', 'text'),
        'lookup_lang'      => array('ricerca', 'Lingua preferita nei risultati', 'it', 'select', array('it' => 'Italiano', '' => 'Tutte')),
        'lookup_timeout'   => array('ricerca', 'Tempo massimo di attesa (secondi)', '8', 'number'),

        // --- Sicurezza e controllo accessi (solo Admin)
        'sec_max_attempts' => array('sicurezza', 'Tentativi di accesso errati prima del blocco', '5', 'number'),
        'sec_lock_minutes' => array('sicurezza', 'Durata del blocco (minuti)', '15', 'number'),
        'sec_idle_minutes' => array('sicurezza', 'Disconnessione automatica dopo inattività (minuti)', '120', 'number'),
        'sec_remember_on' => array('sicurezza', 'Permetti "Ricorda questo dispositivo" nella pagina di accesso', '1', 'bool'),
        'sec_remember_days' => array('sicurezza', 'Per quanti giorni un dispositivo resta ricordato (da 7 a 90)', '30', 'number'),
        'sec_session_max_hours' => array('sicurezza', 'Durata massima di una sessione, anche se attiva (ore)', '168', 'number'),
        'sec_min_password' => array('sicurezza', 'Lunghezza minima password', '10', 'number'),
        'sec_passkeys'     => array('sicurezza', 'Consenti l\'accesso con le chiavi di accesso (passkey, es. Bitwarden)', '1', 'bool'),
        'sec_2fa_admin'    => array('sicurezza', 'Obbliga la verifica in due passaggi per gli Admin', '0', 'bool'),
        'sec_force_https'  => array('sicurezza', 'Forza HTTPS (solo se il server ha un certificato)', '0', 'bool'),
        'sec_ip_allow'     => array('sicurezza', 'Indirizzi IP ammessi (uno per riga, vuoto = tutti)', '', 'textarea'),
        'guest_enabled'    => array('sicurezza', 'Consenti accesso ospite in sola lettura', '0', 'bool'),
        'log_retention'    => array('sicurezza', 'Conserva i log per (giorni)', '365', 'number'),

        // --- Firewall (solo Admin, Sicurezza → Firewall)
        'fw_enabled'       => array('firewall', 'Firewall attivo', '1', 'bool'),
        'fw_lan_allow'     => array('firewall', 'La rete di casa (indirizzi privati 192.168.x.x, 10.x.x.x…) non viene mai bloccata', '1', 'bool'),
        'fw_proxy'         => array('firewall', 'Il sito è dietro un reverse proxy della rete di casa (Nginx Proxy Manager, Traefik, Caddy…)', '0', 'bool'),
        'fw_whitelist'     => array('firewall', 'IP sempre consentiti (uno per riga)', '', 'textarea'),
        'fw_escalate'      => array('firewall', 'Blocchi sempre più lunghi per chi ci riprova', '1', 'bool'),
        'fw_permanent'     => array('firewall', 'Dopo 4 blocchi l\'IP resta bloccato per sempre', '0', 'bool'),
        'fw_unknown_max'   => array('firewall', 'Tentativi con nomi utente inesistenti prima del blocco (0 = non bloccare)', '3', 'number'),
        'fw_banned_names'  => array('firewall', 'Nomi utente vietati: chi li prova viene bloccato subito', "admin\nadministrator\nroot\ntest\nuser\nguest\nwordpress\nwp-admin\nsupport\ninfo", 'textarea'),
        'fw_siege'         => array('firewall', 'Accessi errati in 10 minuti (da tutti gli IP) che fanno scattare la protezione da attacco distribuito (0 = spenta)', '40', 'number'),
        'fw_siege_until'   => array('firewall', '', '0', 'hidden'),
        'fw_honeypot'      => array('firewall', 'Trappola per i programmi che cercano falle (wp-login.php, .env, phpmyadmin…)', '1', 'bool'),
        'fw_cf_only'       => array('firewall', 'Accetta solo il traffico che passa da Cloudflare', '0', 'bool'),
        'fw_cf_seen'       => array('firewall', '', '0', 'hidden'),
        'fw_geo_mode'      => array('firewall', 'Blocco per nazione', 'off', 'select', array('off' => 'Spento', 'block' => 'Blocca le nazioni scelte', 'allow' => 'Consenti solo le nazioni scelte')),
        'fw_geo_scope'     => array('firewall', 'Dove si applica', 'site', 'select', array('site' => 'A tutto il sito', 'login' => 'Solo alla pagina di accesso')),
        'fw_geo_list'      => array('firewall', '', '', 'hidden'),
        'fw_geo_unknown'   => array('firewall', 'Visitatori di nazione sconosciuta', 'allow', 'select', array('allow' => 'Lasciali entrare', 'block' => 'Bloccali')),
        'fw_geo_tor'       => array('firewall', 'Blocca anche la rete anonima Tor', '0', 'bool'),
        'fw_geo_auto'      => array('firewall', 'Aggiorna da solo ogni mese il database delle nazioni', '1', 'bool'),
        'fw_geo_db_date'   => array('firewall', '', '', 'hidden'),
        'fw_geo_try'       => array('firewall', '', '0', 'hidden'),
        'fw_events_days'   => array('firewall', 'Conserva il registro del firewall per (giorni)', '90', 'number'),
    );
}

// Caratteri disponibili. "local" = inclusi nel sito (funzionano anche senza internet).
function font_options()
{
    return array(
        'pagella' => array('Palatino (classico)',  '"Libreria Pagella", "Palatino Linotype", Palatino, Georgia, serif', true),
        'lora'    => array('Lora (libro)',          '"Libreria Lora", Georgia, serif', true),
        'inter'   => array('Inter (moderno)',       '"Libreria Inter", system-ui, -apple-system, "Segoe UI", Arial, sans-serif', true),
        'poppins' => array('Poppins (arrotondato)', '"Libreria Poppins", system-ui, -apple-system, "Segoe UI", Arial, sans-serif', true),
        'georgia' => array('Georgia (di sistema)',  'Georgia, "Times New Roman", serif', false),
        'system'  => array('Carattere del telefono', 'system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif', false),
        'google'  => array('Google Fonts (richiede internet)…', '', false),
    );
}

// Stili preimpostati (le 4 proposte grafiche). L'Admin puo' applicarli e poi ritoccare tutto.
function theme_presets()
{
    return array(
        'classica' => array('Biblioteca Classica', array(
            'color_primary' => '#7a1f2b', 'color_on_primary' => '#fbf6ec', 'color_accent' => '#b8893b',
            'color_bg' => '#f3ebdd', 'color_panel' => '#fbf6ec', 'color_soft' => '#efe2cb', 'color_ink' => '#2b1d14',
            'color_muted' => '#7a6552', 'color_line' => '#e2d5bf', 'color_ok' => '#2e7d4f', 'color_danger' => '#b3261e',
            'font_head' => 'pagella', 'font_body' => 'lora', 'radius' => '6', 'grid_cols' => '3', 'bg_type' => 'solid')),
        'minimal' => array('Minimal Bianco', array(
            'color_primary' => '#111111', 'color_on_primary' => '#ffffff', 'color_accent' => '#ff5a36',
            'color_bg' => '#ffffff', 'color_panel' => '#f5f5f4', 'color_soft' => '#efeeec', 'color_ink' => '#111111',
            'color_muted' => '#77746f', 'color_line' => '#e7e5e2', 'color_ok' => '#1f7a4a', 'color_danger' => '#c62828',
            'font_head' => 'inter', 'font_body' => 'inter', 'radius' => '14', 'grid_cols' => '2', 'bg_type' => 'solid')),
        'notte' => array('Notte in Biblioteca', array(
            'color_primary' => '#8ea6ff', 'color_on_primary' => '#0d1016', 'color_accent' => '#5eead4',
            'color_bg' => '#0d1016', 'color_panel' => '#161b25', 'color_soft' => '#1f2533', 'color_ink' => '#e8ecf3',
            'color_muted' => '#8a93a6', 'color_line' => '#262d3b', 'color_ok' => '#5eead4', 'color_danger' => '#ff8a80',
            'font_head' => 'poppins', 'font_body' => 'inter', 'radius' => '18', 'grid_cols' => '3', 'bg_type' => 'solid')),
        'giardino' => array('Giardino di Carta', array(
            'color_primary' => '#2f6b4f', 'color_on_primary' => '#ffffff', 'color_accent' => '#f2a65a',
            'color_bg' => '#eaf0e6', 'color_panel' => '#ffffff', 'color_soft' => '#f6e7d3', 'color_ink' => '#1f3a2c',
            'color_muted' => '#5f7a69', 'color_line' => '#d6e2d2', 'color_ok' => '#2f6b4f', 'color_danger' => '#c0392b',
            'font_head' => 'poppins', 'font_body' => 'poppins', 'radius' => '22', 'grid_cols' => '3', 'bg_type' => 'solid')),
    );
}

// Stati di lettura personali (facoltativi: un libro puo' anche non avere nessuna etichetta)
function reading_statuses()
{
    return array(
        'da_leggere' => 'Da leggere',
        'in_lettura' => 'In lettura',
        'letto'      => 'Letto',
        'abbandonato' => 'Abbandonato',
    );
}
