-- ============================================================================
--  LIBRERIA DI CASA - struttura database
--  Compatibile con MySQL 5.6+ / MariaDB 10.1+  (UwAmp, XAMPP, NAS Synology/QNAP...)
--
--  COME USARLO (phpMyAdmin sul server database della rete locale):
--   1) Crea il database "libreria" con confronto utf8mb4_unicode_ci
--   2) Selezionalo nel menu a sinistra, poi scheda "Importa" (oppure "SQL" e incolla)
--
--  ATTENZIONE: le istruzioni DROP TABLE qui sotto cancellano i dati esistenti.
--  Reimportare il file = azzerare il database.
--
--  Utente MySQL dedicato (da eseguire come root sul server database).
--  Sostituisci 192.168.1.20 con l'IP del computer che fa da WEB SERVER,
--  cosi' il database accetta connessioni solo da li':
--     CREATE USER 'libreria_app'@'192.168.1.20' IDENTIFIED BY 'una-password-lunga';
--     GRANT ALL PRIVILEGES ON libreria.* TO 'libreria_app'@'192.168.1.20';   (servono anche per gli aggiornamenti)
--     FLUSH PRIVILEGES;
--  (se web server e database sono sullo stesso computer usa 'localhost' al posto dell'IP)
--
--  Accesso iniziale al sito: admin / admin123  -> al primo accesso viene chiesto di cambiarla.
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS wheel_spins;
DROP TABLE IF EXISTS wheel_items;
DROP TABLE IF EXISTS wheel_settings;
DROP TABLE IF EXISTS user_books;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS logs;
DROP TABLE IF EXISTS settings;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- Utenti della piattaforma. role: 'admin' (controllo totale) | 'gestore'
CREATE TABLE users (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username        VARCHAR(60)  NOT NULL,
  display_name    VARCHAR(100) NOT NULL DEFAULT '',
  password_hash   VARCHAR(255) NOT NULL,
  role            VARCHAR(20)  NOT NULL DEFAULT 'gestore',
  active          TINYINT(1)   NOT NULL DEFAULT 1,
  must_change_pw  TINYINT(1)   NOT NULL DEFAULT 0,
  totp_secret     VARCHAR(255) NULL,
  totp_enabled    TINYINT(1)   NOT NULL DEFAULT 0,
  last_login_at   DATETIME     NULL,
  last_login_ip   VARCHAR(45)  NULL,
  created_at      DATETIME     NULL,
  updated_at      DATETIME     NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Impostazioni modificabili dal pannello Gestione (aspetto, testi, sicurezza...)
CREATE TABLE settings (
  setting_key    VARCHAR(100) NOT NULL,
  setting_value  MEDIUMTEXT   NULL,
  updated_at     DATETIME     NULL,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Generi / categorie dei libri
CREATE TABLE categories (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(100) NOT NULL,
  sort_order  INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categories_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La libreria (unica, condivisa da tutti gli utenti)
CREATE TABLE books (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  isbn13       VARCHAR(13)  NULL,
  isbn10       VARCHAR(10)  NULL,
  title        VARCHAR(255) NOT NULL,
  subtitle     VARCHAR(255) NULL,
  authors      VARCHAR(255) NULL,
  publisher    VARCHAR(150) NULL,
  pub_year     SMALLINT     NULL,
  pages        INT          NULL,
  language     VARCHAR(10)  NULL,
  category_id  INT UNSIGNED NULL,
  shelf        VARCHAR(100) NULL,
  cover_file   VARCHAR(100) NULL,
  description  TEXT         NULL,
  notes        TEXT         NULL,
  source       VARCHAR(30)  NULL,
  created_by   INT UNSIGNED NULL,
  created_at   DATETIME     NULL,
  updated_at   DATETIME     NULL,
  PRIMARY KEY (id),
  KEY idx_books_isbn13 (isbn13),
  KEY idx_books_title (title(191)),
  KEY idx_books_authors (authors(191)),
  KEY idx_books_category (category_id),
  CONSTRAINT fk_books_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Stato di lettura PERSONALE di ogni utente per ogni libro.
-- Nessuna riga o status vuoto = nessuna etichetta. status: '' | da_leggere | in_lettura | letto
CREATE TABLE user_books (
  user_id         INT UNSIGNED NOT NULL,
  book_id         INT UNSIGNED NOT NULL,
  status          VARCHAR(12)  NOT NULL DEFAULT '',
  wheel_excluded  TINYINT(1)   NOT NULL DEFAULT 0,
  started_at      DATE         NULL,
  finished_at     DATE         NULL,
  updated_at      DATETIME     NULL,
  PRIMARY KEY (user_id, book_id),
  KEY idx_user_books_book (book_id),
  CONSTRAINT fk_ub_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_ub_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ruota di lettura: impostazioni personali. source: unread | library | manual
CREATE TABLE wheel_settings (
  user_id      INT UNSIGNED NOT NULL,
  source       VARCHAR(10)  NOT NULL DEFAULT 'unread',
  category_id  INT UNSIGNED NULL,
  max_pages    INT          NULL,
  updated_at   DATETIME     NULL,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_ws_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ruota di lettura: libri scelti a mano da ciascun utente (fonte "manual")
CREATE TABLE wheel_items (
  user_id  INT UNSIGNED NOT NULL,
  book_id  INT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, book_id),
  KEY idx_wheel_items_book (book_id),
  CONSTRAINT fk_wi_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_wi_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ruota di lettura: storico estrazioni personali
-- outcome: NULL (nessuna scelta) | in_lettura | escluso | rigirata
CREATE TABLE wheel_spins (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  book_id     INT UNSIGNED NOT NULL,
  source      VARCHAR(10)  NULL,
  outcome     VARCHAR(12)  NULL,
  created_at  DATETIME     NULL,
  PRIMARY KEY (id),
  KEY idx_spins_user (user_id, created_at),
  CONSTRAINT fk_sp_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_sp_book FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Log di sistema (visibili solo all'Admin). level: info | warn | alert
CREATE TABLE logs (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  created_at  DATETIME     NOT NULL,
  user_id     INT UNSIGNED NULL,
  username    VARCHAR(60)  NULL,
  ip          VARCHAR(45)  NULL,
  level       VARCHAR(10)  NOT NULL DEFAULT 'info',
  action      VARCHAR(50)  NOT NULL,
  detail      VARCHAR(500) NULL,
  user_agent  VARCHAR(255) NULL,
  PRIMARY KEY (id),
  KEY idx_logs_created (created_at),
  KEY idx_logs_action (action),
  KEY idx_logs_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tentativi di accesso (per il blocco automatico dopo troppi errori)
CREATE TABLE login_attempts (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ip          VARCHAR(45)  NOT NULL,
  username    VARCHAR(60)  NULL,
  success     TINYINT(1)   NOT NULL DEFAULT 0,
  created_at  DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_attempts_ip (ip, created_at),
  KEY idx_attempts_user (username, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Dati iniziali
-- ---------------------------------------------------------------------------
INSERT INTO users (username, display_name, password_hash, role, active, must_change_pw, created_at, updated_at) VALUES
('admin', 'Amministratore', '$2y$10$B3qiS7m3lnyxu9/mKmGHue62goaoX8OA63rR4uff4RpJqQynigTce', 'admin', 1, 1, NOW(), NOW());

INSERT INTO categories (name, sort_order) VALUES
('Romanzo', 10), ('Giallo e thriller', 20), ('Fantascienza e fantasy', 30), ('Classici', 40),
('Saggistica', 50), ('Storia', 60), ('Biografie', 70), ('Poesia', 80), ('Ragazzi', 90), ('Fumetti', 100);
