# Libreria di Casa — guida all'installazione

Sito per catalogare la tua raccolta di libri, pensato per lo smartphone.
Stessa impostazione del progetto "Staging Area": PHP + MySQL, cartelle private fuori dalla radice web.

```
libreria/
├── public_html/   <- UNICA cartella esposta dal web server (pagine, css, js, caratteri, icone)
├── CONF/          <- configurazione e password del database (privata)
├── data/          <- copertine, logo/sfondo caricati, backup (privata, deve essere SCRIVIBILE)
├── sql/           <- libreria.sql (serve solo per installare)
└── strumenti/     <- recupero_admin.php, firma.php, crea_plugin.php, plugin.php (si usano solo da riga di comando)
```

Requisiti: PHP 7.4 o successivo (consigliati 8.2, 8.3 o 8.4; in UwAmp si sceglie dal pannello) con le estensioni `pdo_mysql`, `curl`, `gd`,
`zip`, `mbstring`, `openssl` e `sodium` (per le firme e i plugin), più MySQL 5.6+ o MariaDB 10.1+. Il caricamento dei file deve essere attivo.

> **Con Docker?** Usa il pacchetto Docker e la sua guida `GUIDA-INSTALLAZIONE-DOCKER.md`: lì è tutto automatico.

**Modo più semplice: installazione guidata.** Crea solo un database vuoto e un utente (punto 1, passi 1 e 3), copia il sito
(punto 2) e apri l'indirizzo del sito: parte da sola la procedura passo passo (database, nome del sito, stile, amministratore,
ripristino da backup). Non serve importare il file SQL né modificare `CONF/config.php`.

---

## 1. Database (anche su un altro computer della rete)

1. Sul computer che ospita MySQL/MariaDB (NAS, PC, Raspberry…) crea il database `libreria`
   con confronto `utf8mb4_unicode_ci`.
2. Selezionalo in phpMyAdmin → **Importa** → `sql/libreria.sql`. Attenzione: reimportare il file azzera i dati.
3. Crea un utente dedicato che accetti connessioni **solo dal web server**. Sostituisci l'IP con quello del
   computer dove gira il sito:
   ```sql
   CREATE USER 'libreria_app'@'192.168.1.20' IDENTIFIED BY 'una-password-lunga';
   GRANT ALL PRIVILEGES ON libreria.* TO 'libreria_app'@'192.168.1.20';
   FLUSH PRIVILEGES;
   ```
   Se database e sito sono sullo stesso computer, usa `'localhost'` al posto dell'IP.
   I permessi completi sul solo database `libreria` servono perché gli aggiornamenti del sito
   aggiungono da soli le tabelle nuove.
4. **Solo se il database è su un altro computer:**
   - nel file di configurazione di MySQL (`my.cnf` / `my.ini`) imposta `bind-address = 0.0.0.0`,
     oppure l'IP di rete del server database, poi riavvia MySQL;
   - nel firewall di quel computer apri la porta **3306 solo verso l'IP del web server**.
5. Apri `CONF/config.php` e scrivi `DB_HOST` (es. `'192.168.1.50'`), `DB_USER` e `DB_PASS`.

## 2. Sito su UwAmp

- **Prova rapida:** copia la cartella `libreria` in `C:\UwAmp\www\` e apri
  `http://localhost/libreria/public_html/`.
- **Consigliato:** crea un virtual host la cui radice web sia `…\libreria\public_html`. In questo modo `CONF`,
  `data`, `sql` e `strumenti` restano davvero fuori dal web. Ogni cartella contiene comunque un `.htaccess`
  che ne blocca l'accesso.
- Dagli smartphone della rete apri `http://IP-DEL-COMPUTER/` (es. `http://192.168.1.20/`). Ricorda di
  aprire la porta 80 (e la 443 se usi HTTPS) nel firewall di Windows.
- La cartella `data/` e le sue sottocartelle devono essere scrivibili dal web server. Su Windows lo sono già.

## 3. Primo accesso

- Con l'installazione guidata: entri con l'utente e la password scelti al passo "Amministratore".
- Se invece hai importato a mano `sql/libreria.sql`: utente **admin**, password **admin123**; al primo accesso il sito ti obbliga a cambiarla.
- In **Gestione → Sistema** trovi il controllo di estensioni PHP, cartelle, database e HTTPS.
- In **Gestione → Ricerca online → Prova adesso** verifichi che il server raggiunga internet.

## 4. Ricerca dei libri

Inserendo l'ISBN o il titolo, il sito interroga **Google Books**, che copre molto bene le edizioni italiane,
e **Open Library**. Goodreads ha chiuso le sue API pubbliche nel 2020, quindi non si può usare.

- Il **web server** deve poter uscire su internet. Il database invece può restare isolato.
- Se la rete usa un proxy, impostalo in `CONF/config.php` (`HTTP_PROXY_URL`).
- Le copertine vengono scaricate e salvate in `data/covers`: dopo l'inserimento la libreria funziona anche
  senza internet.
- Se un libro non viene trovato, lo inserisci a mano e scatti una foto alla copertina.
- Hai importato un elenco CSV? In **Gestione → Panoramica** il pulsante "Cerca le copertine mancanti"
  le scarica tutte, un libro alla volta.

## 5. Fotocamera e codice a barre (HTTPS)

I browser permettono l'uso della fotocamera solo su siti **HTTPS** (oppure su `localhost`).
Senza HTTPS puoi comunque digitare l'ISBN a mano.

Per attivare HTTPS in rete locale:
1. crea un certificato per l'IP o il nome del server, ad esempio con *mkcert*
   (`mkcert 192.168.1.20 libreria.casa`);
2. attiva SSL in UwAmp/Apache con quei file;
3. installa il certificato "root" di mkcert sui telefoni, così il browser non mostra avvisi;
4. solo a questo punto attiva **Gestione → Sicurezza → Forza HTTPS**.

Su Android/Chrome la lettura usa il lettore integrato del browser. Su iPhone usa il decodificatore incluso
nel sito: inquadra il codice a barre ben illuminato e riempi il riquadro.

## 6. Il pannello di gestione

Si apre da **Gestione** ed è pensato per il computer: menu a sinistra con i gruppi che si aprono e si chiudono
(con "Riduci il menu" resta solo la colonna di icone), contenuto a destra.

- **Bacheca**: numeri della libreria, libri aggiunti per mese, cosa c'è da sistemare (senza copertina, genere,
  ISBN, trama, doppioni), lettori, backup, avvisi di sicurezza e attività recente.
- **Libri**: tabella con ricerca, filtri e ordinamento; selezionando più righe (anche con Maiusc) puoi assegnare
  il genere o un'etichetta, impostare la posizione o un campo, eliminare. Ogni libro si modifica in una pagina a due colonne.
- **Etichette**: oltre al Genere crei le tue etichette (es. Collana, Formato, Scaffale, Temi), con uno o più valori
  per libro. I valori si aggiungono, rinominano, ordinano e uniscono; compaiono nel modulo del libro, nei filtri e nella scheda.
- **Campi personalizzati**: campi in più nella scheda (testo, numero, data, sì/no, elenco, indirizzo web), anche nel CSV.
- **Sezioni**: le righe della pagina iniziale (recenti, per autore, un genere, un'etichetta, i miei "in lettura",
  libri brevi, a caso…) nell'ordine che vuoi, e le **pagine** del sito (es. "Regole per i prestiti"), scritte in testo
  semplice o in **codice HTML**, con CSS aggiuntivo (solo Admin) e immagini caricate dal pannello. Le pagine compaiono nel
  **menu in alto** del sito (pulsante accanto all'iniziale dell'utente) e in fondo a ogni pagina.
- **Prestiti** (dalla 1.2): a chi hai prestato un libro, da quando e fino a quando; i ritardi compaiono in Bacheca e
  accanto alla voce del menu. Si presta e si segna la restituzione anche dalla scheda del libro sul telefono.
  I libri prestati escono dalla ruota di lettura finché non tornano.
- **Cestino** (Libri → Cestino): i libri eliminati restano recuperabili per 30 giorni (modificabile), con etichette,
  stati di lettura e prestiti.
- **Doppioni** (Libri → Doppioni): libri con lo stesso ISBN o con stesso titolo e autore; scegli quale tenere e il sito
  unisce gli altri completando i dati mancanti.
- **Backup automatici** (Strumenti → Backup): ogni giorno, settimana o mese, all'ora scelta, tenendo solo gli ultimi N.
  Il sito li fa da solo alla prima visita utile; per l'ora esatta aggiungi al cron del server `php strumenti/backup_auto.php`
  ogni 15 minuti.
- **Destinazioni dei backup** (Strumenti, solo Admin): copia automatica su cartella o NAS con SAMBA, SFTP, FTP/FTPES,
  Nextcloud/WebDAV, Google Drive, Dropbox, con pulsante "Prova" ed esito dell'ultimo invio. Su ogni destinazione restano solo
  gli ultimi N backup. Password e token sono cifrati con la chiave `data/secret.key` (non va nei backup: dopo un trasloco su
  un altro server le destinazioni si reinseriscono).
- **Aspetto**, **Utenti** (anche "Disconnetti da tutti i dispositivi"), **Sicurezza**, **Strumenti** (backup, CSV,
  ricerca online), **Sistema** (stato, log, aggiornamento): come prima.

## 7. Aggiornare il sito dal pannello

Da **Gestione → Sistema → Aggiornamento** carichi il file `update.zip` di una nuova versione. Il sito controlla
che il pacchetto sia integro e più recente, chiede la tua password, salva un backup completo e una copia dei
programmi attuali, sostituisce i programmi e aggiorna il database. Se qualcosa va storto torna da solo alla
versione di prima, e dalla stessa pagina puoi sempre tornare a una versione precedente. Non vengono mai toccati
la cartella `data` e `CONF/config.php`.

Serve che il web server possa scrivere nella cartella del sito (su UwAmp/Windows è già così).
Per creare un pacchetto: `php strumenti/crea_aggiornamento.php update.zip --nota "Novità"`.

## 8. Ruoli

| | Admin | Gestore |
|---|---|---|
| Libri: aggiungere, modificare, eliminare, copertine | ✅ | ✅ |
| Generi, etichette, campi personalizzati, righe della home e pagine | ✅ | ✅ |
| Backup e ripristino, CSV, ricerca online | ✅ | ✅ |
| Aspetto (colori, sfondo, caratteri, logo, CSS) e testi | ✅ | ❌ |
| Utenti e ruoli | ✅ | ❌ |
| Sicurezza e controllo accessi (IP, blocchi, 2FA, ospiti) | ✅ | ❌ |
| Log, stato del sistema, aggiornamenti, manutenzione | ✅ | ❌ |

I permessi sono controllati dal server: un Gestore che prova ad aprire una pagina riservata viene
bloccato, e il tentativo finisce nel log.

La **libreria è unica** e condivisa. **Stato di lettura** (da leggere / in lettura / letto) e **Ruota di
lettura** sono invece **personali**: ogni utente ha i propri.
Si può attivare anche un accesso **ospite** in sola lettura, che non ha la ruota.

## 9. Ruota di lettura

Ogni utente sceglie da dove pescare i libri:
- **Da leggere**: solo i libri che lui non ha ancora letto;
- **Tutta la libreria**;
- **Scelti da me**: una selezione fatta a mano.

Puoi aggiungere filtri per genere e per numero massimo di pagine. L'estrazione è fatta dal server ed è
equa su tutti i libri della fonte. La ruota ne disegna al massimo 24: se sono di più ne mostra 24 a caso,
ma il vincitore può essere uno qualsiasi.

## 10. Sicurezza inclusa

- Password cifrate (bcrypt) e lunghezza minima configurabile.
- Cambio password obbligatorio per le password temporanee.
- **Blocco automatico** dopo N tentativi errati, per IP e per utente; l'Admin può sbloccare.
- **Verifica in due passaggi** (app tipo Google Authenticator), facoltativa o obbligatoria per gli Admin.
- **Elenco IP ammessi** (es. `192.168.1.*`). Dal server stesso (localhost) si entra sempre.
- Disconnessione automatica per inattività.
- Protezione CSRF su tutti i moduli e Content-Security-Policy.
- Cookie di sessione `HttpOnly`/`SameSite`.
- Le immagini caricate vengono ricodificate; il download di copertine da indirizzi della rete locale è vietato.
- **Log** di accessi, modifiche e tentativi negati, con filtri ed esportazione CSV.

## 11. Backup

Da **Gestione → Dati e backup** crei un file ZIP con libri, copertine, generi, stati di lettura e ruote.
Prima di ogni ripristino il sito salva in automatico una copia dello stato attuale.
I backup restano in `data/backup`: scaricane una copia su un altro dispositivo ogni tanto.
Fai anche un backup del database da phpMyAdmin (Esporta).

## 12. Se l'Admin resta chiuso fuori

Hai dimenticato la password o perso il telefono con l'app di verifica? Esegui sul server:
```
php strumenti/recupero_admin.php admin NuovaPasswordTemporanea
```
(su UwAmp: `C:\UwAmp\bin\php\php-7.x\php.exe strumenti\recupero_admin.php admin NuovaPassword`)

## 13. Sul telefono come un'app

Apri il sito → menu del browser → **Aggiungi a schermata Home**. Si apre a tutto schermo, con la sua icona.

## Prima di usarlo davvero

- [ ] password dell'utente MySQL cambiata in `CONF/config.php`
- [ ] password di admin cambiata (te lo chiede il sito)
- [ ] `APP_DEBUG` a `false` (è già così)
- [ ] elenco IP ammessi impostato sulla rete di casa (Gestione → Sicurezza)
- [ ] primo backup creato
