<?php
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/auth.php';
require_once APP_ROOT . '/inc/webauthn.php';
$pk_on = pk_enabled() && pk_available_here();
require_once APP_ROOT . '/inc/remember.php';
$remember_on = remember_ready();

if (is_logged()) {
    redirect('libreria.php');
}

$error = '';
$step = !empty($_SESSION['pending_uid']) ? '2fa' : 'login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = post('action');
    if ($action === 'login') {
        $r = do_login(post('username'), isset($_POST['password']) ? (string)$_POST['password'] : '');
        if ($r['ok']) {
            if ($remember_on && post('remember') === '1') {
                remember_create(current_uid());
            }
            redirect('libreria.php');
        }
        if ($r['need_2fa']) {
            $_SESSION['remember_req'] = $remember_on && post('remember') === '1' ? 1 : 0;
            redirect('index.php');
        }
        $error = $r['error'];
        $step = 'login';
    } elseif ($action === '2fa') {
        $want = !empty($_SESSION['remember_req']);
        $r = verify_pending_2fa(post('code'));
        if ($r['ok']) {
            if ($want && $remember_on) {
                remember_create(current_uid());
            }
            redirect('libreria.php');
        }
        $error = $r['error'];
        $step = $r['restart'] ? 'login' : '2fa';
    } elseif ($action === 'annulla') {
        unset($_SESSION['pending_uid'], $_SESSION['pending_time']);
        redirect('index.php');
    } elseif ($action === 'ospite' && setting('guest_enabled') === '1') {
        session_regenerate_id(true);
        $_SESSION = array('role' => 'guest', 'last_seen' => time());
        app_log('login_ospite', 'Accesso come ospite (sola lettura)');
        redirect('libreria.php');
    }
}

page_head('Accesso', 'pg-login');
?>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-brand"><?= brand_logo_html() ?>
      <div><div class="kick"><?= h(setting('brand_kicker')) ?></div><div class="brandname"><?= h(setting('brand_title')) ?></div></div>
    </div>
    <?= flash_show() ?>
<?php if ($step === '2fa'): ?>
    <h1 class="h1">Verifica in due passaggi</h1>
    <p class="sub">Apri l'app di autenticazione sul telefono e scrivi il codice di 6 cifre.</p>
    <?php if ($error !== ''): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
    <form method="post" class="stack" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="2fa">
      <label class="lab" for="code">Codice</label>
      <input class="input big code" id="code" name="code" inputmode="numeric" pattern="[0-9 ]*" maxlength="7" autocomplete="one-time-code" autofocus required>
      <button class="btn primary" type="submit">Verifica</button>
    </form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="annulla"><button class="btn link" type="submit">Annulla</button></form>
<?php else: ?>
    <h1 class="h1"><?= h(setting('login_title')) ?></h1>
    <p class="sub"><?= h(setting('login_intro')) ?></p>
    <?php if ($error !== ''): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
    <form method="post" class="stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="login">
      <label class="lab" for="username">Nome utente</label>
      <input class="input" id="username" name="username" autocomplete="<?= $pk_on ? 'username webauthn' : 'username' ?>" autocapitalize="none" spellcheck="false" required value="<?= h(post('username')) ?>">
      <label class="lab" for="password">Password</label>
      <div class="pwrow"><input class="input" id="password" name="password" type="password" autocomplete="current-password" required>
        <button class="iconbtn" type="button" data-toggle-pw="password" aria-label="Mostra password"><?= icon('eye', 18) ?></button></div>
      <?php if ($remember_on): ?>
      <label class="check remember"><input type="checkbox" name="remember" value="1" data-remember> <span>Ricorda questo dispositivo per <?= (int)remember_days() ?> giorni
        <small>Non usarlo su computer condivisi o pubblici.</small></span></label>
      <?php endif; ?>
      <button class="btn primary" type="submit">Accedi</button>
    </form>
    <?php if ($pk_on): ?>
    <div class="pk-login">
      <div class="or"><span>oppure</span></div>
      <div class="alert error" data-pk-login-msg hidden></div>
      <button class="btn ghost" type="button" data-pk-login hidden><?= icon('lock', 18) ?> Accedi con una chiave di accesso</button>
    </div>
    <?php endif; ?>
    <?php if (setting('guest_enabled') === '1'): ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="ospite">
      <button class="btn ghost" type="submit"><?= h(setting('btn_guest')) ?></button></form>
    <?php endif; ?>
<?php endif; ?>
  </div>
</div>
<script type="application/json" id="app-config"><?= json_encode(array('csrf' => csrf_token())) ?></script>
<script src="js/app.js?v=<?= (int)@filemtime(APP_ROOT . '/js/app.js') ?>"></script>
<?php if ($pk_on && $step === 'login'): ?><script src="js/passkey.js?v=<?= (int)@filemtime(APP_ROOT . '/js/passkey.js') ?>"></script><?php endif; ?>
</body></html>
