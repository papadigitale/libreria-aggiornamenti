<?php
/*
 * Trappola per i programmi automatici che cercano falle (wp-login.php, .env, phpmyadmin...).
 * Il sito non e' WordPress e non ha questi file: chi li cerca e' un programma di attacco.
 * Il file .htaccess manda qui quelle richieste; l'IP viene bloccato (tranne la rete di casa e gli IP consentiti).
 */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
if (function_exists('fw_enabled') && fw_enabled() && setting('fw_honeypot', '1') === '1') {
    $uri = isset($_SERVER['REQUEST_URI']) ? preg_replace('/[\x00-\x1F\x7F]/', '', $_SERVER['REQUEST_URI']) : '';
    fw_block_auto(client_ip(), 'scanner', 'Ha cercato ' . str_cut($uri, 120));
}
if (ob_get_level()) {
    @ob_end_clean();
}
header('HTTP/1.1 404 Not Found');
header('Content-Type: text/plain; charset=utf-8');
echo 'Pagina non trovata.';
