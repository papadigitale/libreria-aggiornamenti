<?php
/* Pagine del sito create dai plugin ($plugin->site_page): plg.php?p=<id>&s=<slug> */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/books.php';
require_once APP_ROOT . '/inc/extras.php';

$key = (string)get('p') . '/' . (string)get('s');
$pg = isset($GLOBALS['PLG_SITE'][$key]) && function_exists('plugin_site_allowed') ? $GLOBALS['PLG_SITE'][$key] : null;
$pubblica = $pg && !empty($pg['pubblica']);
if (!$pubblica) {
    require_login();
}
if (!$pg || !empty($GLOBALS['PLG_FAILED'][$pg['plugin']->id])) {
    if (!is_logged()) {
        header('HTTP/1.1 404 Not Found');
        exit('Pagina non disponibile.');
    }
    flash('Pagina non disponibile.', 'error');
    redirect('libreria.php');
}
if ($pubblica) {
    // pagine aperte con un link: niente motori di ricerca, il link non passa ad altri siti, nessuna copia nelle cache
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: private, no-store');
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !is_logged()) {
        header('HTTP/1.1 403 Forbidden');
        exit('Operazione non consentita.');
    }
}
if (!plugin_site_allowed($pg)) {
    deny_page('Questa pagina non è disponibile per il tuo account.');
}
$pid = $pg['plugin']->id;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    if (post('action') === 'plg_salva' && $pg['salva']) {
        $GLOBALS['PLG_CURRENT'] = $pid;
        try {
            call_user_func($pg['salva'], $pg['plugin']);
        } catch (Throwable $e) {
            plugin_fail($pid, $e);
            flash('Si è verificato un errore: la funzione è stata spenta. L\'amministratore trova i dettagli in Gestione → Plugin.', 'error');
            redirect('libreria.php');
        }
        $GLOBALS['PLG_CURRENT'] = null;
    }
    $back = post('back');
    redirect(preg_match('#^plg\.php\?[A-Za-z0-9_=&%+.\-]*$#', $back) ? $back : $pg['plugin']->site_url($pg['slug']));
}
$GLOBALS['PLG_CURRENT'] = $pid;
if (!empty($pg['grezza'])) {
    // la funzione del plugin risponde da sola (immagine, file, testo); in caso di errore: 404
    try {
        call_user_func($pg['render'], $pg['plugin']);
    } catch (Throwable $e) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        plugin_fail($pid, $e);
        header('HTTP/1.1 404 Not Found');
    }
    exit;
}
ob_start();
try {
    call_user_func($pg['render'], $pg['plugin']);
    $html = ob_get_clean();
} catch (Throwable $e) {
    ob_end_clean();
    plugin_fail($pid, $e);
    $html = '<div class="alert error">Si è verificato un errore: la funzione è stata spenta.</div>';
}
$GLOBALS['PLG_CURRENT'] = null;
page_start($pg['title'], 'plg-' . preg_replace('/[^a-z0-9\-]/', '', $pid), $pubblica ? array('pubblica' => true) : array());
echo $html;
page_end();
