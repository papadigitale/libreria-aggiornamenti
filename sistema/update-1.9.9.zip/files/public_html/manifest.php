<?php
/* Manifest per installare il sito come app sulla schermata Home dello smartphone */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';

while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/manifest+json; charset=utf-8');
echo json_encode(array(
    'name' => setting('brand_title'),
    'short_name' => str_cut(setting('brand_title'), 14),
    'id' => 'libreria.php',
    'start_url' => 'libreria.php',
    'scope' => './',
    'display' => 'standalone',
    'background_color' => safe_color(setting('color_bg'), '#f3ebdd'),
    'theme_color' => safe_color(setting('color_bg'), '#f3ebdd'),
    'icons' => array(
        // icone piene (senza trasparenze) e "maskable": Android le usa a tutto tondo, senza la cornice bianca
        array('src' => 'icon.php?s=192', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'),
        array('src' => 'icon.php?s=512', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'),
        array('src' => 'icon.php?s=192&m=1', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'maskable'),
        array('src' => 'icon.php?s=512&m=1', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'),
    ),
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
