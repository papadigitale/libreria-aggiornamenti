<?php
/*
 * Serve le immagini salvate fuori dalla cartella web (data/covers e data/uploads).
 *  ?c=nomefile  copertina (solo utenti collegati o ospiti)
 *  ?a=nomefile  logo / sfondo (pubblici: servono anche nella pagina di accesso)
 */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';

/* ---------- Media (immagini, PDF, video, audio delle pagine): ?m=nomefile, &t=1 per la miniatura ---------- */
if (isset($_GET['m'])) {
    require_once APP_ROOT . '/inc/media.php';
    $mn = (string)$_GET['m'];
    if (!is_logged()) {
        header('HTTP/1.1 403 Forbidden');
        exit;
    }
    if (!media_valid_name($mn)) {
        header('HTTP/1.1 404 Not Found');
        exit;
    }
    $path = MEDIA_DIR . '/' . $mn;
    $ext = strtolower(pathinfo($mn, PATHINFO_EXTENSION));
    $types = media_types();
    $type = $types[$ext][0];
    if (get('t') === '1') {
        $tp = media_thumb_path($mn);
        if ($tp !== '') {
            $path = $tp;
            $type = substr($tp, -4) === '.png' ? 'image/png' : 'image/jpeg';
        }
    }
    if (!is_file($path)) {
        header('HTTP/1.1 404 Not Found');
        exit;
    }
    session_write_close();
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    $size = filesize($path);
    $etag = '"' . md5($path . filemtime($path) . $size) . '"';
    header('Content-Type: ' . $type);
    header('Cache-Control: private, max-age=2592000');
    header('ETag: ' . $etag);
    header('Accept-Ranges: bytes');
    header('X-Content-Type-Options: nosniff');
    if ($ext === 'pdf') {
        header('Content-Disposition: inline; filename="' . $mn . '"');
    }
    if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim($_SERVER['HTTP_IF_NONE_MATCH']) === $etag) {
        header('HTTP/1.1 304 Not Modified');
        exit;
    }
    // richieste parziali: servono per far partire e scorrere i video (soprattutto su iPhone)
    $start = 0;
    $end = $size - 1;
    if (isset($_SERVER['HTTP_RANGE']) && preg_match('/^bytes=(\d*)-(\d*)$/', trim($_SERVER['HTTP_RANGE']), $r)) {
        if ($r[1] === '' && $r[2] !== '') {
            $start = max(0, $size - (int)$r[2]);
        } else {
            $start = (int)$r[1];
            if ($r[2] !== '') {
                $end = min($end, (int)$r[2]);
            }
        }
        if ($start > $end || $start >= $size) {
            header('HTTP/1.1 416 Range Not Satisfiable');
            header('Content-Range: bytes */' . $size);
            exit;
        }
        header('HTTP/1.1 206 Partial Content');
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    }
    header('Content-Length: ' . ($end - $start + 1));
    if ($_SERVER['REQUEST_METHOD'] === 'HEAD') {
        exit;
    }
    $fh = fopen($path, 'rb');
    fseek($fh, $start);
    $left = $end - $start + 1;
    @set_time_limit(0);
    while ($left > 0 && !feof($fh)) {
        $chunk = fread($fh, min(262144, $left));
        echo $chunk;
        $left -= strlen($chunk);
        flush();
    }
    fclose($fh);
    exit;
}

$dir = '';
$name = '';
if (isset($_GET['c'])) {
    if (!is_logged()) {
        header('HTTP/1.1 403 Forbidden');
        exit;
    }
    $dir = COVERS_DIR;
    $name = (string)$_GET['c'];
} elseif (isset($_GET['a'])) {
    $dir = UPLOADS_DIR;
    $name = (string)$_GET['a'];
}
if ($dir === '' || !preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $name, $m) || !is_file($dir . '/' . $name)) {
    header('HTTP/1.1 404 Not Found');
    exit;
}
$path = $dir . '/' . $name;
$types = array('jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp');
$etag = '"' . md5($name . filemtime($path) . filesize($path)) . '"';
session_write_close();
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: ' . $types[$m[1]]);
header('Cache-Control: private, max-age=2592000, immutable');
header('ETag: ' . $etag);
if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim($_SERVER['HTTP_IF_NONE_MATCH']) === $etag) {
    header('HTTP/1.1 304 Not Modified');
    exit;
}
header('Content-Length: ' . filesize($path));
readfile($path);
