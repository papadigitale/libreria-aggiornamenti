<?php
/*
 * File pubblici dei plugin (css, js, immagini, caratteri): plugin_file.php?p=<id>&f=<percorso>
 * Solo plugin attivi, solo file elencati nella firma e ancora identici a quelli firmati.
 */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/plugins.php';

function plg_file_404()
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('HTTP/1.1 404 Not Found');
    exit;
}

$id = (string)get('p');
$f = (string)get('f');
if (!plugins_ready() || plugins_safe_mode() || !plugin_id_ok($id) || !preg_match('#^[A-Za-z0-9._\-/]{1,200}$#', $f) || strpos($f, '..') !== false) {
    plg_file_404();
}
$ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
$types = plugin_file_types();
if (!in_array($ext, plugin_public_types(), true)) {
    plg_file_404();
}
$row = plugin_get($id);
$m = $row ? json_decode((string)$row['manifest'], true) : null;
// l'icona dichiarata in plugin.json si vede nel pannello anche a plugin spento (sempre controllata con la firma)
$is_icon = false;
if ($row && get('icona') === '1' && is_admin() && in_array($ext, array('png', 'jpg', 'jpeg', 'webp'), true) && $row['status'] !== 'manomesso') {
    $pj = json_decode((string)@file_get_contents(plugins_dir() . '/' . $id . '/plugin.json'), true);
    $is_icon = is_array($pj) && isset($pj['icona']) && (string)$pj['icona'] === $f && isset($m['files']['plugin.json'])
        && hash_equals($m['files']['plugin.json'], (string)@hash_file('sha256', plugins_dir() . '/' . $id . '/plugin.json'));
}
if (!$row || (!$is_icon && ((int)$row['active'] !== 1 || $row['status'] !== 'ok'))) {
    plg_file_404();
}
$path = plugins_dir() . '/' . $id . '/' . $f;
if (!isset($m['files'][$f]) || !is_file($path)) {
    plg_file_404();
}
$data = file_get_contents($path);
if (!hash_equals($m['files'][$f], hash('sha256', $data))) {
    plugin_set_status($id, 'manomesso', 'Il file ' . $f . ' è stato modificato sul server.');
    app_log('plugin_bloccato', 'Plugin "' . $id . '" spento: il file ' . $f . ' è stato modificato', 'alert', '');
    plg_file_404();
}
session_write_close();
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: ' . $types[$ext]);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: ' . (get('v') !== '' ? 'public, max-age=604800' : 'no-cache'));
header('Content-Length: ' . strlen($data));
echo $data;
