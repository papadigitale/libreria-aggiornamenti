<?php
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/books.php';
require_once APP_ROOT . '/inc/extras.php';
require_editor();

$error = '';
$val = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $f = book_fields_from_input($_POST);
    $error = book_validate($f);
    if ($error === '') {
        $source = str_cut(post('source'), 30);
        $id = book_insert($f, $source !== '' ? $source : 'Manuale');
        book_extras_save($id, $_POST);
        $cover_msg = '';
        if (isset($_FILES['cover']) && $_FILES['cover']['error'] !== UPLOAD_ERR_NO_FILE) {
            $r = cover_store_upload($_FILES['cover'], $id);
            if (!$r[0]) {
                $cover_msg = ' (copertina non salvata: ' . $r[1] . ')';
            }
        } else {
            $urls = array();
            if (post('cover_choice') !== '') {
                $urls[] = post('cover_choice');
            }
            foreach ((array)(isset($_POST['cover_urls']) ? $_POST['cover_urls'] : array()) as $u) {
                if (is_string($u) && !in_array($u, $urls, true)) {
                    $urls[] = $u;
                }
            }
            if ($urls && post('no_cover') !== '1') {
                $r = cover_store_from_urls(array_slice($urls, 0, 6), $id, 'trusted');
                if (!$r[0]) {
                    $cover_msg = ' (copertina non scaricata: potrai aggiungerla dalla scheda del libro)';
                }
            }
        }
        $my = post('my_status');
        if ($my !== '') { // l'etichetta e' facoltativa
            user_book_save(current_uid(), $id, $my);
        }
        app_log('libro_aggiunto', '#' . $id . ' "' . $f['title'] . '"' . ($f['isbn13'] ? ' ISBN ' . $f['isbn13'] : ''));
        flash('"' . $f['title'] . '" aggiunto alla libreria' . $cover_msg . '.', $cover_msg === '' ? 'success' : 'warn');
        redirect('aggiungi.php?ok=' . $id . (post('mode') !== '' ? '&modo=' . rawurlencode(post('mode')) : ''));
    }
    $val = $_POST;
}

$ok_book = get('ok') !== '' ? book_get((int)get('ok')) : null;
$mode = in_array(get('modo'), array('isbn', 'titolo', 'scan', 'mano'), true) ? get('modo') : 'isbn';
if (get('titolo') !== '') {
    $mode = 'titolo';
}
if ($error !== '') {
    $mode = 'mano';
}

page_start(setting('add_title'), 'aggiungi', array('back' => 'libreria.php'));
?>
<?php if ($ok_book): ?>
  <a class="added card" href="libro.php?id=<?= (int)$ok_book['id'] ?>">
    <?= book_cover_html($ok_book, 'cover mini') ?>
    <span><b><?= h($ok_book['title']) ?></b><small>Appena aggiunto · tocca per aprire la scheda</small></span><?= icon('check', 20) ?>
  </a>
<?php endif; ?>

<div class="seg tabs4" data-tabs>
  <button type="button" data-tab="isbn" class="<?= $mode === 'isbn' ? 'on' : '' ?>">ISBN</button>
  <button type="button" data-tab="titolo" class="<?= $mode === 'titolo' ? 'on' : '' ?>">Titolo</button>
  <button type="button" data-tab="scan" class="<?= $mode === 'scan' ? 'on' : '' ?>"><?= icon('scan', 15) ?> Scansiona</button>
  <button type="button" data-tab="mano" class="<?= $mode === 'mano' ? 'on' : '' ?>">A mano</button>
</div>

<section class="tabpane" data-pane="isbn" <?= $mode !== 'isbn' ? 'hidden' : '' ?>>
  <form class="lookup" data-lookup="isbn" autocomplete="off">
    <label class="lab" for="isbn-in">Codice ISBN</label>
    <div class="inputrow">
      <input class="input big" id="isbn-in" name="isbn" inputmode="numeric" placeholder="978-88-…" value="<?= h(get('isbn')) ?>" enterkeyhint="search">
      <button class="gobtn" type="submit" aria-label="Cerca"><?= icon('search', 20) ?></button>
    </div>
    <p class="hint">Lo trovi sul retro del libro, sopra o sotto il codice a barre (10 o 13 cifre).</p>
  </form>
</section>

<section class="tabpane" data-pane="titolo" <?= $mode !== 'titolo' ? 'hidden' : '' ?>>
  <form class="lookup" data-lookup="titolo" autocomplete="off">
    <label class="lab" for="title-in">Titolo (ed eventualmente autore)</label>
    <div class="inputrow">
      <input class="input big" id="title-in" name="q" placeholder="es. Il nome della rosa Eco" value="<?= h(get('titolo')) ?>" enterkeyhint="search">
      <button class="gobtn" type="submit" aria-label="Cerca"><?= icon('search', 20) ?></button>
    </div>
  </form>
  <div class="results" data-results></div>
</section>

<section class="tabpane" data-pane="scan" <?= $mode !== 'scan' ? 'hidden' : '' ?>>
  <div class="scanner" data-scanner>
    <video playsinline muted></video>
    <div class="scan-frame"><span></span></div>
    <div class="scan-msg">Inquadra il codice a barre sul retro del libro</div>
  </div>
  <div class="row2 scan-actions"><button class="btn primary" type="button" data-scan-start><?= icon('camera', 18) ?> Avvia fotocamera</button>
    <button class="btn ghost" type="button" data-scan-stop hidden>Ferma</button></div>
  <label class="btn ghost photo-btn"><?= icon('image', 18) ?> Leggi il codice da una foto
    <input type="file" accept="image/*" capture="environment" data-scan-photo hidden></label>
  <p class="hint" data-scan-hint>Consigli: buona luce, codice dritto e che riempia il riquadro. Le webcam dei PC spesso non mettono a fuoco da vicino:
    tieni il libro a 20–30 cm oppure fotografa il codice con il telefono e usa "Leggi il codice da una foto".
    La fotocamera dal vivo funziona solo con il sito in HTTPS o aperto dal computer stesso.</p>
</section>

<div class="lookup-status" data-status hidden></div>

<!-- Risultato trovato + modulo di salvataggio (anche per l'inserimento a mano) -->
<form method="post" enctype="multipart/form-data" class="save-form" data-save-form <?= $mode === 'mano' ? '' : 'hidden' ?>>
  <?= csrf_field() ?>
  <input type="hidden" name="source" value="<?= h(isset($val['source']) ? $val['source'] : '') ?>">
  <input type="hidden" name="cover_choice" value="">
  <input type="hidden" name="mode" value="<?= h($mode) ?>">
  <div data-cover-urls></div>

  <div class="result card" data-result-card hidden>
    <div class="rcover" data-rcover></div>
    <div class="fields" data-rfields></div>
  </div>
  <div class="dup alert warn" data-dup hidden></div>
  <div class="cover-picks" data-cover-picks hidden></div>

  <details class="card" data-edit-fields <?= $mode === 'mano' ? 'open' : '' ?>>
    <summary><?= icon('edit', 16) ?> <span data-edit-label><?= $mode === 'mano' ? 'Dati del libro' : 'Correggi o completa i dati' ?></span></summary>
    <?php if ($error !== ''): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
    <div class="stack"><?php include APP_ROOT . '/inc/book_form_fields.php'; ?>
      <label class="lab" for="add-cover">Copertina: foto o immagine (facoltativa)</label>
      <input class="input" type="file" id="add-cover" name="cover" accept="image/*" capture="environment">
    </div>
  </details>

  <div class="card mine">
    <div class="ct">La mia etichetta <span class="sub">(facoltativa)</span></div>
    <div class="seg seg4">
      <label><input type="radio" name="my_status" value="" checked><span>Nessuna</span></label>
      <?php foreach (reading_statuses() as $k => $lab): ?>
      <label><input type="radio" name="my_status" value="<?= h($k) ?>"><span><?= h($lab) ?></span></label>
      <?php endforeach; ?>
    </div>
  </div>
  <p class="hint">Puoi correggere ogni campo prima di salvare.</p>
  <button class="btn primary" type="submit">Salva nella libreria</button>
</form>
<?php page_end(array('js/scanner.js', 'js/aggiungi.js')); ?>
