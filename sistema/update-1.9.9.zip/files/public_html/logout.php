<?php
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';

// Il token impedisce che un link esterno possa disconnetterti
if (is_logged() && isset($_GET['t']) && hash_equals(csrf_token(), (string)$_GET['t'])) {
    app_log('logout', 'Uscita dal sito');
    if (is_file(APP_ROOT . '/inc/remember.php')) {
        require_once APP_ROOT . '/inc/remember.php';
        remember_forget_current(); // altrimenti il dispositivo rientrerebbe da solo
    }
    logout_session();
    flash('Sei uscito correttamente.', 'success');
}
redirect('index.php');
