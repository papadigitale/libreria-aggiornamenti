/* Pannello di gestione: menu laterale, modifica di più libri, piccoli aiuti nei moduli */
(function () {
  'use strict';
  var store = {
    get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* memoria del browser non disponibile */ } }
  };
  var shell = document.querySelector('[data-adm-shell]');

  // ---- Gruppi del menu: si aprono e si chiudono, e il browser se lo ricorda
  var open = {};
  try { open = JSON.parse(store.get('adm_open') || '{}') || {}; } catch (e) { open = {}; }
  document.querySelectorAll('.ag[data-group]').forEach(function (g) {
    var key = g.getAttribute('data-group');
    var btn = g.querySelector('.ag-h');
    if (open[key] === 1 && !g.classList.contains('open')) { g.classList.add('open'); }
    if (open[key] === 0 && !g.classList.contains('cur')) { g.classList.remove('open'); }
    btn.setAttribute('aria-expanded', g.classList.contains('open') ? 'true' : 'false');
    btn.addEventListener('click', function () {
      if (shell && shell.classList.contains('mini')) { return; } // nel menu ridotto i gruppi si aprono al passaggio del mouse
      var isOpen = g.classList.toggle('open');
      btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      open[key] = isOpen ? 1 : 0;
      store.set('adm_open', JSON.stringify(open));
    });
  });

  // ---- Menu ridotto alle sole icone
  var mini = document.querySelector('[data-adm-mini]');
  if (shell && store.get('adm_mini') === '1') { shell.classList.add('mini'); }
  if (mini) {
    mini.addEventListener('click', function () {
      var on = shell.classList.toggle('mini');
      store.set('adm_mini', on ? '1' : '0');
      mini.querySelector('span').textContent = on ? 'Espandi il menu' : 'Riduci il menu';
    });
    if (shell.classList.contains('mini')) { mini.querySelector('span').textContent = 'Espandi il menu'; }
  }
  var burger = document.querySelector('[data-adm-burger]');
  if (burger) {
    burger.addEventListener('click', function () { shell.classList.toggle('nav-open'); });
  }

  // ---- Menu utente: si chiude cliccando fuori
  document.addEventListener('click', function (e) {
    document.querySelectorAll('.adm-user[open]').forEach(function (d) {
      if (!d.contains(e.target)) { d.removeAttribute('open'); }
    });
    if (shell && shell.classList.contains('nav-open') && !e.target.closest('.adm-side') && !e.target.closest('[data-adm-burger]')) {
      shell.classList.remove('nav-open');
    }
  });

  // ---- Elenco libri: selezione e azioni su più libri
  var bulk = document.querySelector('[data-bulk]');
  if (bulk) {
    var all = bulk.querySelector('[data-check-all]');
    var boxes = bulk.querySelectorAll('[data-row-check]');
    var count = bulk.querySelector('[data-bulk-count]');
    var op = bulk.querySelector('[data-bulk-op]');
    var go = bulk.querySelector('[data-bulk-go]');
    var refresh = function () {
      var n = 0;
      boxes.forEach(function (b) { if (b.checked) { n++; } b.closest('tr').classList.toggle('sel', b.checked); });
      count.textContent = n === 0 ? 'Nessun libro selezionato' : (n === 1 ? '1 libro selezionato' : n + ' libri selezionati');
      go.disabled = n === 0 || op.value === '';
      if (all) { all.checked = n > 0 && n === boxes.length; all.indeterminate = n > 0 && n < boxes.length; }
      bulk.querySelectorAll('[data-bulk-for]').forEach(function (el) {
        el.hidden = (' ' + el.getAttribute('data-bulk-for') + ' ').indexOf(' ' + op.value + ' ') < 0;
      });
      if (op.value === 'delete') {
        bulk.setAttribute('data-confirm', 'Spostare nel cestino ' + (n === 1 ? 'il libro selezionato' : 'i ' + n + ' libri selezionati') + '? Potrai recuperarli da Libri → Cestino.');
      } else {
        bulk.removeAttribute('data-confirm');
      }
    };
    if (all) {
      all.addEventListener('change', function () { boxes.forEach(function (b) { b.checked = all.checked; }); refresh(); });
    }
    var last = null;
    boxes.forEach(function (b, i) {
      b.addEventListener('click', function (e) {
        // con il tasto Maiusc si seleziona un intervallo di righe
        if (e.shiftKey && last !== null) {
          var from = Math.min(last, i), to = Math.max(last, i);
          for (var k = from; k <= to; k++) { boxes[k].checked = b.checked; }
        }
        last = i;
        refresh();
      });
    });
    op.addEventListener('change', refresh);
    refresh();

    // "Seleziona tutti i N libri trovati" (anche quelli delle altre pagine)
    var selall = bulk.querySelector('[data-selall]'), allIds = null;
    var selGo = bulk.querySelector('[data-selall-go]');
    var extra = document.createElement('div');
    extra.hidden = true;
    bulk.appendChild(extra);
    var clearAll = function () {
      allIds = null; extra.innerHTML = '';
      if (selGo) { selGo.textContent = selGo.getAttribute('data-label'); }
    };
    if (selall && selGo) {
      selGo.setAttribute('data-label', selGo.textContent);
      var upd = function () { selall.hidden = !(all && all.checked); if (!all.checked) { clearAll(); } };
      all.addEventListener('change', upd);
      boxes.forEach(function (b) { b.addEventListener('click', function () { setTimeout(upd, 0); }); });
      selGo.addEventListener('click', function () {
        if (allIds) { clearAll(); refresh(); return; }
        allIds = JSON.parse(selGo.getAttribute('data-ids'));
        var onPage = {};
        boxes.forEach(function (b) { onPage[b.value] = 1; });
        extra.innerHTML = allIds.filter(function (id) { return !onPage[id]; }).map(function (id) { return '<input type="hidden" name="ids[]" value="' + id + '">'; }).join('');
        count.textContent = 'Tutti i ' + allIds.length + ' libri trovati sono selezionati';
        selGo.textContent = 'Seleziona solo questa pagina';
      });
    }
    op.addEventListener('change', function () { if (allIds) { count.textContent = 'Tutti i ' + allIds.length + ' libri trovati sono selezionati'; } });

    // Ricerca online di copertine, trame e dati mancanti: un libro alla volta, con l'avanzamento
    var rbox = document.querySelector('[data-refill]');
    var stop = false;
    bulk.addEventListener('submit', function (e) {
      if (op.value !== 'refill' || !rbox) { return; }
      e.preventDefault();
      var ids = [];
      bulk.querySelectorAll('input[name="ids[]"]').forEach(function (i) { if (i.type === 'hidden' || i.checked) { ids.push(i.value); } });
      ids = ids.filter(function (v, i, a) { return a.indexOf(v) === i; });
      if (!ids.length) { return; }
      if (ids.length > 30 && !window.confirm('Cercare online ' + ids.length + ' libri? Ci vorranno alcuni minuti: lascia aperta questa pagina.')) { return; }
      var what = bulk.querySelector('[name=refill_what]').value;
      var bar = rbox.querySelector('.progress i'), log = rbox.querySelector('[data-refill-log]'), cnt = rbox.querySelector('[data-refill-count]');
      var title = rbox.querySelector('[data-refill-title]'), sum = rbox.querySelector('[data-refill-sum]');
      var stopBtn = rbox.querySelector('[data-refill-stop]'), doneBtn = rbox.querySelector('[data-refill-done]');
      var n = 0, found = 0, covers = 0, descs = 0, errs = 0;
      stop = false;
      rbox.hidden = false; doneBtn.hidden = true; stopBtn.hidden = false; log.innerHTML = '';
      go.disabled = true;
      rbox.scrollIntoView({ behavior: 'smooth', block: 'start' });
      stopBtn.onclick = function () { stop = true; stopBtn.disabled = true; title.textContent = 'Mi fermo dopo questo libro…'; };
      var esc = window.App.esc;
      var finish = function () {
        title.textContent = stop ? 'Ricerca fermata' : 'Ricerca completata';
        stopBtn.hidden = true; doneBtn.hidden = false; go.disabled = false;
      };
      var step = function () {
        if (stop || n >= ids.length) { finish(); return; }
        var id = ids[n];
        title.textContent = 'Cerco online… (' + (n + 1) + ' di ' + ids.length + ')';
        window.App.post('book_refill', { id: id, what: what }).then(function (r) {
          var li = document.createElement('li');
          if (r.ok) {
            if (r.changed && r.changed.length) {
              found++;
              if (r.changed.indexOf('copertina') >= 0) { covers++; }
              if (r.changed.indexOf('trama') >= 0) { descs++; }
              li.innerHTML = '<b>' + esc(r.title) + '</b> · <span class="ok">' + esc(r.msg) + '</span>';
            } else {
              li.innerHTML = '<b>' + esc(r.title) + '</b> · <span class="no">' + esc(r.msg) + '</span>';
            }
          } else {
            errs++;
            li.innerHTML = '<span class="err">#' + esc(id) + ': ' + esc(r.error || 'errore') + '</span>';
          }
          log.insertBefore(li, log.firstChild);
        }).catch(function () {
          errs++;
          var li = document.createElement('li');
          li.innerHTML = '<span class="err">#' + esc(id) + ': connessione interrotta</span>';
          log.insertBefore(li, log.firstChild);
        }).then(function () {
          n++;
          bar.style.width = Math.round(n / ids.length * 100) + '%';
          cnt.textContent = n + ' / ' + ids.length;
          sum.textContent = 'Completati ' + found + ' libri · copertine trovate: ' + covers + ' · trame trovate: ' + descs + (errs ? ' · errori: ' + errs : '');
          setTimeout(step, 400); // una piccola pausa tra un libro e l'altro, per non farsi bloccare dalle fonti online
        });
      };
      step();
    });
  }

  // ---- Campi personalizzati: le voci servono solo per "Elenco a scelta"
  document.querySelectorAll('[data-field-type]').forEach(function (s) {
    var box = s.closest('form').querySelector('[data-options-box]');
    var upd = function () { if (box) { box.hidden = s.value !== 'select'; } };
    s.addEventListener('change', upd);
    upd();
  });

  // ---- Nuova riga della home: mostra solo la scelta che serve
  var secKind = document.querySelector('[data-sec-kind]');
  if (secKind) {
    var form = secKind.closest('form');
    var updK = function () {
      var opt = secKind.options[secKind.selectedIndex];
      var need = opt ? opt.getAttribute('data-need') : '';
      form.querySelectorAll('[data-need-box]').forEach(function (b) { b.hidden = b.getAttribute('data-need-box') !== need; });
      var lab = form.querySelector('[data-number-label]');
      if (lab) { lab.textContent = secKind.value === 'year' ? 'Dall\'anno (es. 2015)' : 'Numero massimo di pagine (es. 200)'; }
    };
    secKind.addEventListener('change', updK);
    updK();
  }

  // ---- Pagine: pulsanti di formattazione
  var md = document.querySelector('[data-md-text]');
  var bar = document.querySelector('[data-md-bar]');
  if (md && bar) {
    var wrap = function (before, after) {
      var s = md.selectionStart, e = md.selectionEnd, v = md.value;
      var sel = v.slice(s, e) || 'testo';
      md.value = v.slice(0, s) + before + sel + after + v.slice(e);
      md.focus();
      md.setSelectionRange(s + before.length, s + before.length + sel.length);
    };
    bar.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b) { return; }
      if (b.hasAttribute('data-md')) { wrap(b.getAttribute('data-md'), b.getAttribute('data-md')); }
      if (b.hasAttribute('data-md-line')) {
        var s = md.selectionStart, v = md.value;
        var ls = v.lastIndexOf('\n', s - 1) + 1;
        md.value = v.slice(0, ls) + b.getAttribute('data-md-line') + v.slice(ls);
        md.focus();
      }
      if (b.hasAttribute('data-md-link')) { wrap('[', '](https://)'); }
    });
  }
})();

/* Pagine: testo semplice o HTML, barra degli strumenti, immagini */
(function () {
  'use strict';
  var area = document.querySelector('[data-md-text]');
  if (!area) { return; }
  var fmt = function () {
    var r = document.querySelector('[data-fmt]:checked');
    return r ? r.value : 'md';
  };
  var applyFmt = function () {
    var f = fmt();
    document.querySelectorAll('[data-for-fmt]').forEach(function (el) { el.hidden = el.getAttribute('data-for-fmt') !== f; });
    area.spellcheck = f !== 'html';
  };
  document.querySelectorAll('[data-fmt]').forEach(function (r) { r.addEventListener('change', applyFmt); });
  applyFmt();
  var insert = function (text, selectFrom, selectLen) {
    var s = area.selectionStart, e = area.selectionEnd, v = area.value;
    area.value = v.slice(0, s) + text + v.slice(e);
    area.focus();
    if (selectFrom !== undefined) { area.setSelectionRange(s + selectFrom, s + selectFrom + selectLen); }
    else { area.setSelectionRange(s + text.length, s + text.length); }
  };
  var hb = document.querySelector('[data-html-bar]');
  if (hb) {
    hb.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b) { return; }
      if (b.hasAttribute('data-tag')) {
        var t = b.getAttribute('data-tag');
        var sel = area.value.slice(area.selectionStart, area.selectionEnd) || 'testo';
        insert('<' + t + '>' + sel + '</' + t + '>', t.length + 2, sel.length);
      } else if (b.hasAttribute('data-snippet')) {
        insert(b.getAttribute('data-snippet'));
      }
    });
  }
  // ---- "Da Media": scegli (o carica) un file e mettilo nel testo dove si trova il cursore
  var pickBox = null, pickPos = null;
  var openPicker = function () {
    pickPos = [area.selectionStart, area.selectionEnd];
    if (!pickBox) {
      pickBox = document.createElement('div');
      pickBox.className = 'mpick';
      pickBox.innerHTML = '<div class="mpick-box" role="dialog" aria-modal="true" aria-label="Inserisci da Media">'
        + '<div class="mpick-head"><b>Inserisci da Media</b>'
        + '<select class="input" data-pf><option value="all">Tutte le cartelle</option><option value="none">Senza cartella</option></select>'
        + '<select class="input" data-pk><option value="">Tutti i tipi</option><option value="image">Immagini</option><option value="pdf">PDF</option><option value="video">Video</option><option value="audio">Audio</option></select>'
        + '<input class="input" type="search" placeholder="Cerca…" data-pq>'
        + '<label class="btn ghost small">Carica un file<input type="file" hidden accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.mp4,.mp3" data-pu></label>'
        + '<button type="button" class="btn link small" data-px aria-label="Chiudi" title="Chiudi">×</button></div>'
        + '<div class="mpick-body"><div class="media-grid" data-pg></div></div>'
        + '<div class="mpick-foot" data-pmsg>Tocca un file per inserirlo nel testo. Le cartelle si gestiscono in Media.</div></div>';
      document.body.appendChild(pickBox);
      var grid = pickBox.querySelector('[data-pg]'), msg = pickBox.querySelector('[data-pmsg]');
      var pf = pickBox.querySelector('[data-pf]'), pk = pickBox.querySelector('[data-pk]'), pq = pickBox.querySelector('[data-pq]');
      var esc = window.App.esc, items = [], foldersLoaded = false, timer = null;
      var icons = { pdf: 'PDF', video: 'VIDEO', audio: 'AUDIO', image: 'IMG' };
      var load = function () {
        grid.innerHTML = '<p class="sub">Carico…</p>';
        window.App.get({ action: 'media_list', folder: pf.value, kind: pk.value, q: pq.value }).then(function (r) {
          if (!r.ok) { grid.innerHTML = '<p class="sub">' + esc(r.error || 'Errore') + '</p>'; return; }
          if (!foldersLoaded) {
            r.folders.forEach(function (f) { var o = document.createElement('option'); o.value = f.id; o.textContent = f.name + ' (' + f.n + ')'; pf.appendChild(o); });
            foldersLoaded = true;
          }
          items = r.items;
          grid.innerHTML = items.length ? items.map(function (it, i) {
            return '<div class="mtile" data-i="' + i + '"><a><span class="mthumb k-' + it.kind + '">'
              + (it.thumb ? '<img src="' + esc(it.thumb) + '" alt="" loading="lazy">' : (it.ico || '<b>' + icons[it.kind] + '</b>'))
              + '</span><span class="mname">' + esc(it.title) + '</span><small>' + esc(it.size) + '</small></a></div>';
          }).join('') : '<p class="sub">Nessun file. Usa "Carica un file" qui sopra.</p>';
        });
      };
      var put = function (it) {
        area.focus();
        area.setSelectionRange(pickPos[0], pickPos[1]);
        insert((fmt() === 'html' ? it.html : it.md) + '\n');
        pickBox.hidden = true;
      };
      grid.addEventListener('click', function (e) {
        var t = e.target.closest('[data-i]');
        if (t) { put(items[+t.getAttribute('data-i')]); }
      });
      pf.addEventListener('change', load);
      pk.addEventListener('change', load);
      pq.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(load, 250); });
      pickBox.querySelector('[data-px]').addEventListener('click', function () { pickBox.hidden = true; });
      pickBox.addEventListener('click', function (e) { if (e.target === pickBox) { pickBox.hidden = true; } });
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && pickBox && !pickBox.hidden) { pickBox.hidden = true; } });
      pickBox.querySelector('[data-pu]').addEventListener('change', function () {
        var f = this.files[0];
        if (!f) { return; }
        if (f.size > 50 * 1048576) { msg.textContent = 'Il file supera i 50 MB.'; return; }
        msg.textContent = 'Carico "' + f.name + '"…';
        var fd = new FormData();
        fd.append('csrf', window.App.csrf || ''); fd.append('action', 'media_upload'); fd.append('file', f);
        fd.append('folder_id', /^\d+$/.test(pf.value) ? pf.value : '0');
        fetch('api.php', { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
          if (!r.ok) { msg.textContent = r.error || 'Caricamento non riuscito.'; return; }
          msg.textContent = '"' + r.item.title + '" caricato e inserito nel testo.';
          put(r.item);
          load();
        }).catch(function () { msg.textContent = 'Caricamento non riuscito (file troppo grande per il server?).'; });
        this.value = '';
      });
    }
    pickBox.hidden = false;
    pickBox.querySelector('[data-pf]').dispatchEvent(new Event('change'));
  };
  document.querySelectorAll('[data-media-pick]').forEach(function (b) { b.addEventListener('click', openPicker); });

  document.querySelectorAll('[data-insert-img]').forEach(function (b) {
    b.addEventListener('click', function () {
      var u = b.getAttribute('data-insert-img');
      insert(fmt() === 'html' ? '<img src="' + u + '" alt="">' : '![](' + u + ')');
    });
  });
})();

/* Destinazioni dei backup: si vedono (e si inviano) solo i campi del tipo scelto; programmazione dei backup */
(function () {
  'use strict';
  var form = document.querySelector('[data-rt-form]');
  if (form) {
    var sel = form.querySelector('[data-rt-type]');
    var hidden = form.querySelector('input[type=hidden][name=type]');
    var upd = function () {
      var type = hidden ? hidden.value : sel.value;
      form.querySelectorAll('[data-rt]').forEach(function (box) {
        var on = (' ' + box.getAttribute('data-rt') + ' ').indexOf(' ' + type + ' ') >= 0;
        box.hidden = !on;
        box.querySelectorAll('input,textarea,select').forEach(function (el) {
          // un campo dentro un blocco nascosto non deve essere inviato
          var visible = true, p = el.parentElement;
          while (p && p !== form) { if (p.hasAttribute('data-rt') && (' ' + p.getAttribute('data-rt') + ' ').indexOf(' ' + type + ' ') < 0) { visible = false; } p = p.parentElement; }
          el.disabled = !visible;
        });
      });
    };
    if (sel) { sel.addEventListener('change', upd); }
    upd();
  }
  var sched = document.querySelector('[data-sched]');
  if (sched) {
    var mode = sched.querySelector('[data-sched-mode]');
    var u2 = function () {
      sched.querySelectorAll('[data-sched-for]').forEach(function (b) {
        b.hidden = (' ' + b.getAttribute('data-sched-for') + ' ').indexOf(' ' + mode.value + ' ') < 0;
      });
    };
    mode.addEventListener('change', u2);
    u2();
  }
  // Firewall: ricerca tra le nazioni, contatore, "solo le scelte"
  var cp = document.querySelector('[data-cpick]');
  if (cp) {
    var boxes = cp.querySelectorAll('.cgrid .check');
    var search = cp.querySelector('[data-cpick-search]');
    var count = cp.querySelector('[data-cpick-count]');
    var onlyBtn = cp.querySelector('[data-cpick-only]');
    var only = false;
    var modeSel = document.querySelector('select[name=fw_geo_mode]');
    var norm = function (t) { return t.toLowerCase().normalize ? t.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '') : t.toLowerCase(); };
    var refresh = function () {
      var q = norm(search.value.trim()), n = 0;
      boxes.forEach(function (b) {
        var cb = b.querySelector('input');
        if (cb.checked) { n++; }
        var show = (!q || norm(b.textContent).indexOf(q) >= 0) && (!only || cb.checked);
        b.classList.toggle('hide', !show);
      });
      count.textContent = n === 0 ? 'nessuna nazione scelta' : (n === 1 ? '1 nazione scelta' : n + ' nazioni scelte');
      if (modeSel) { cp.classList.toggle('off', modeSel.value === 'off'); }
    };
    search.addEventListener('input', refresh);
    search.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); } });
    cp.addEventListener('change', refresh);
    if (modeSel) { modeSel.addEventListener('change', refresh); }
    onlyBtn.addEventListener('click', function () { only = !only; onlyBtn.textContent = only ? 'Mostra tutte' : 'Mostra solo le scelte'; refresh(); });
    cp.querySelector('[data-cpick-none]').addEventListener('click', function () { boxes.forEach(function (b) { b.querySelector('input').checked = false; }); refresh(); });
    refresh();
  }
  document.querySelectorAll('[data-autosubmit]').forEach(function (el) {
    el.addEventListener('change', function () { if (el.form) { el.form.submit(); } });
  });
  // Azione multipla "Segna come…": la data serve solo per "letto"/"abbandonato" e solo con "il giorno…"
  var rdS = document.querySelector('[data-rd-status]');
  if (rdS) {
    var rdW = document.querySelector('[data-rd-when]'), rdD = document.querySelector('[data-rd-date]'), opSel = document.querySelector('[data-bulk-op]');
    var rdUpd = function () {
      var on = opSel.value === 'reading', fin = rdS.value === 'letto' || rdS.value === 'abbandonato';
      rdW.hidden = !(on && fin);
      rdD.hidden = !(on && fin && rdW.value === 'date');
    };
    [rdS, rdW, opSel].forEach(function (el) { el.addEventListener('change', function () { setTimeout(rdUpd, 0); }); });
    rdUpd();
  }
})();

/* Media: trascina e carica, selezione, copia degli indirizzi */
(function () {
  'use strict';
  var MAX = 50 * 1048576;
  var drop = document.querySelector('[data-media-drop]');
  if (drop) {
    var area = drop.querySelector('[data-drop-area]'), input = drop.querySelector('[data-drop-input]');
    var list = drop.querySelector('[data-drop-list]'), go = drop.querySelector('[data-drop-go]');
    var show = function () {
      var fs = input.files, big = [], names = [];
      for (var i = 0; i < fs.length; i++) { names.push(fs[i].name); if (fs[i].size > MAX) { big.push(fs[i].name); } }
      list.textContent = fs.length ? (fs.length === 1 ? names[0] : fs.length + ' file scelti') + (big.length ? ' · troppo grandi (oltre 50 MB): ' + big.join(', ') : '') : '';
      go.disabled = !fs.length || big.length > 0;
    };
    input.addEventListener('change', show);
    ['dragenter', 'dragover'].forEach(function (ev) { area.addEventListener(ev, function (e) { e.preventDefault(); area.classList.add('over'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { area.addEventListener(ev, function (e) { e.preventDefault(); area.classList.remove('over'); }); });
    area.addEventListener('drop', function (e) {
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
        try { input.files = e.dataTransfer.files; } catch (err) {}
        show();
        if (!go.disabled) { drop.submit(); }
      }
    });
  }
  var mb = document.querySelector('[data-mbulk]');
  if (mb) {
    var checks = mb.querySelectorAll('[data-mcheck]'), all = mb.querySelector('[data-mcheck-all]');
    var cnt = mb.querySelector('[data-mcount]'), mgo = mb.querySelector('[data-mgo]');
    var op = mb.querySelector('select[name=op]'), fsel = mb.querySelector('select[name=folder_id]');
    var upd = function () {
      var n = 0;
      checks.forEach(function (c) { if (c.checked) { n++; } });
      if (cnt) { cnt.textContent = n ? (n === 1 ? '1 selezionato' : n + ' selezionati') : 'Seleziona tutti'; }
      if (mgo) { mgo.disabled = n === 0; }
      if (fsel && op) { fsel.hidden = op.value !== 'move'; }
      if (op && op.value === 'delete') { mb.setAttribute('data-confirm', 'Eliminare definitivamente ' + (n === 1 ? 'il file selezionato' : 'i ' + n + ' file selezionati') + '?'); }
      else { mb.removeAttribute('data-confirm'); }
    };
    checks.forEach(function (c) { c.addEventListener('change', upd); });
    if (all) { all.addEventListener('change', function () { checks.forEach(function (c) { c.checked = all.checked; }); upd(); }); }
    if (op) { op.addEventListener('change', upd); }
    upd();
  }
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var src = b.parentNode.querySelector('[data-copy-src]');
      src.select();
      var done = function () { var t = b.textContent; b.textContent = 'Copiato'; setTimeout(function () { b.textContent = t; }, 1500); };
      if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(src.value).then(done); } else { try { document.execCommand('copy'); done(); } catch (e) {} }
    });
  });
})();
