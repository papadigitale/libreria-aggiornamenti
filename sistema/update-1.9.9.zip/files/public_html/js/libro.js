/* Scheda libro: ricerca copertine alternative per ISBN */
(function () {
  'use strict';
  var box = document.querySelector('[data-cover-options]');
  if (!box) { return; }
  var btn = box.querySelector('[data-find-covers]');
  var picks = box.querySelector('.cover-picks');
  var form = box.closest('form');
  var hidden = document.createElement('input');
  hidden.type = 'hidden'; hidden.name = 'cover_pick'; form.appendChild(hidden);
  btn.addEventListener('click', function () {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Cerco…';
    window.App.get({ action: 'lookup_isbn', isbn: box.getAttribute('data-isbn') }).then(function (r) {
      var covers = r.ok ? r.book.covers : (r.covers || []);
      btn.hidden = true;
      if (!covers.length) { picks.innerHTML = '<p class="sub">Nessuna copertina trovata online.</p>'; return; }
      covers.forEach(function (u) {
        var b = document.createElement('button');
        b.type = 'button';
        b.innerHTML = '<img alt="" src="api.php?action=cover_preview&amp;u=' + encodeURIComponent(u) + '">';
        b.querySelector('img').onerror = function () { b.remove(); };
        b.onclick = function () {
          picks.querySelectorAll('button').forEach(function (x) { x.classList.remove('sel'); });
          b.classList.add('sel');
          hidden.value = u;
        };
        picks.appendChild(b);
      });
    }).catch(function () { btn.disabled = false; btn.textContent = 'Riprova'; });
  });
})();
