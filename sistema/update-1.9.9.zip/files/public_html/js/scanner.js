/*
 * Lettore di codici a barre EAN-13 (ISBN) con la fotocamera del telefono.
 * - Usa il lettore integrato del browser (BarcodeDetector) quando c'e' (Chrome/Android).
 * - Altrimenti (es. iPhone) usa il decodificatore qui sotto, scritto senza librerie esterne:
 *   legge alcune righe dell'immagine, misura la larghezza di barre e spazi e le confronta con le tabelle EAN-13.
 */
(function () {
  'use strict';
  // indirizzo di questo file (serve per avviare il worker), letto subito al caricamento
  var SCRIPT_URL = (typeof document !== 'undefined' && document.currentScript && document.currentScript.src) ? document.currentScript.src : 'js/scanner.js';

  // Larghezze (in moduli) delle cifre in codifica L: spazio, barra, spazio, barra
  var L = [[3, 2, 1, 1], [2, 2, 2, 1], [2, 1, 2, 2], [1, 4, 1, 1], [1, 1, 3, 2], [1, 2, 3, 1], [1, 1, 1, 4], [1, 3, 1, 2], [1, 2, 1, 3], [3, 1, 1, 2]];
  var G = L.map(function (p) { return p.slice().reverse(); });
  var FIRST = { 'LLLLLL': 0, 'LLGLGG': 1, 'LLGGLG': 2, 'LLGGGL': 3, 'LGLLGG': 4, 'LGGLLG': 5, 'LGGGLL': 6, 'LGLGLG': 7, 'LGLGGL': 8, 'LGGLGL': 9 };

  function checksumOk(code) {
    var s = 0;
    for (var i = 0; i < 12; i++) { s += (+code[i]) * (i % 2 ? 3 : 1); }
    return (10 - s % 10) % 10 === +code[12];
  }

  function matchDigit(runs, tables) {
    var tot = runs[0] + runs[1] + runs[2] + runs[3];
    var best = null;
    for (var t = 0; t < tables.length; t++) {
      for (var d = 0; d < 10; d++) {
        var p = tables[t][d], err = 0;
        for (var k = 0; k < 4; k++) { err += Math.abs(runs[k] * 7 / tot - p[k]); }
        if (!best || err < best.err) { best = { d: d, t: t, err: err }; }
      }
    }
    return best && best.err < 1.6 ? best : null;
  }

  // Converte una riga di luminosita' in sequenze di barre/spazi.
  // mode: 0 = soglia locale, 1 = soglia locale stretta, 2 = soglia globale
  function toRuns(lum, mode) {
    var n = lum.length, i;
    var sm = new Float32Array(n);
    for (i = 0; i < n; i++) { sm[i] = (lum[Math.max(0, i - 1)] + 2 * lum[i] + lum[Math.min(n - 1, i + 1)]) / 4; }
    var min = 255, max = 0;
    for (i = 0; i < n; i++) { if (sm[i] < min) { min = sm[i]; } if (sm[i] > max) { max = sm[i]; } }
    if (max - min < 30) { return null; }
    var mid = (min + max) / 2;
    var win = Math.max(6, Math.round(n / (mode === 1 ? 48 : 24)));
    var pref = new Float64Array(n + 1);
    for (i = 0; i < n; i++) { pref[i + 1] = pref[i] + sm[i]; }
    var bits = new Uint8Array(n);
    for (i = 0; i < n; i++) {
      var thr = mid;
      if (mode !== 2) {
        var a = Math.max(0, i - win), b = Math.min(n, i + win);
        thr = ((pref[b] - pref[a]) / (b - a)) * 0.6 + mid * 0.4;
      }
      bits[i] = sm[i] < thr ? 1 : 0; // 1 = barra (scuro)
    }
    var runs = [], colors = [], cur = bits[0], len = 0;
    for (i = 0; i < n; i++) {
      if (bits[i] === cur) { len++; } else { runs.push(len); colors.push(cur); cur = bits[i]; len = 1; }
    }
    runs.push(len); colors.push(cur);
    return { runs: runs, colors: colors };
  }

  function near(v, m, tol) { return v > m * (1 - tol) && v < m * (1 + tol); }

  function decodeRuns(r) {
    var raw = r.runs, colors = r.colors;
    for (var s = 1; s + 59 <= raw.length; s++) {
      if (colors[s] !== 1) { continue; }
      // larghezza del modulo calcolata sull'intero codice (95 moduli): molto piu' stabile delle singole barre
      var span = 0, k;
      for (k = 0; k < 59; k++) { span += raw[s + k]; }
      var m = span / 95;
      if (m < 0.9) { continue; }
      if (raw[s - 1] < m * 1.5 && s - 1 !== 0) { continue; } // zona bianca prima del codice
      // Le barre stampate/fotografate risultano piu' larghe (o strette) degli spazi: lo si misura sulle
      // barre di guardia (tutte larghe 1 modulo) e si corregge ogni elemento prima del confronto.
      var gb = [s, s + 2, s + 28, s + 30, s + 56, s + 58], gs = [s + 1, s + 27, s + 29, s + 31, s + 57], sb = 0, ss = 0;
      gb.forEach(function (x) { sb += raw[x]; });
      gs.forEach(function (x) { ss += raw[x]; });
      var gain = (sb / gb.length - ss / gs.length) / 2;
      if (Math.abs(gain) > m * 0.7) { continue; }
      var runs = raw.slice();
      for (k = s; k < s + 59; k++) { runs[k] = Math.max(0.2, raw[k] + (colors[k] === 1 ? -gain : gain)); }
      if (!near(runs[s] + runs[s + 1] + runs[s + 2], 3 * m, 0.5)) { continue; }
      var digits = [], parity = '', ok = true, i;
      for (i = 0; i < 6 && ok; i++) {
        var o = s + 3 + i * 4, seg = [runs[o], runs[o + 1], runs[o + 2], runs[o + 3]];
        var w = seg[0] + seg[1] + seg[2] + seg[3];
        if (w < m * 5 || w > m * 9) { ok = false; break; }
        var md = matchDigit(seg, [L, G]);
        if (!md) { ok = false; break; }
        digits.push(md.d); parity += md.t === 0 ? 'L' : 'G';
      }
      if (!ok || !(parity in FIRST)) { continue; }
      var mid = s + 27, mw = 0;
      for (k = 0; k < 5; k++) { mw += runs[mid + k]; }
      if (!near(mw, 5 * m, 0.45)) { continue; }
      for (i = 0; i < 6 && ok; i++) {
        var o2 = s + 32 + i * 4, seg2 = [runs[o2], runs[o2 + 1], runs[o2 + 2], runs[o2 + 3]];
        var w2 = seg2[0] + seg2[1] + seg2[2] + seg2[3];
        if (w2 < m * 5 || w2 > m * 9) { ok = false; break; }
        var md2 = matchDigit(seg2, [L]);
        if (!md2) { ok = false; break; }
        digits.push(md2.d);
      }
      if (!ok) { continue; }
      var code = String(FIRST[parity]) + digits.join('');
      if (code.length === 13 && checksumOk(code)) { return code; }
    }
    return null;
  }

  // Bordi delle barre ricavati dalla variazione di luminosita' (regge meglio le immagini sfocate delle webcam)
  function toRunsEdges(lum) {
    var n = lum.length, i;
    if (n < 60) { return null; }
    var sm = new Float32Array(n);
    for (i = 0; i < n; i++) {
      var a2 = lum[Math.max(0, i - 2)], a1 = lum[Math.max(0, i - 1)], b1 = lum[Math.min(n - 1, i + 1)], b2 = lum[Math.min(n - 1, i + 2)];
      sm[i] = (a2 + 4 * a1 + 6 * lum[i] + 4 * b1 + b2) / 16;
    }
    var d = new Float32Array(n), maxd = 0;
    for (i = 1; i < n - 1; i++) { d[i] = (sm[i + 1] - sm[i - 1]) / 2; if (Math.abs(d[i]) > maxd) { maxd = Math.abs(d[i]); } }
    if (maxd < 4) { return null; }
    var thr = maxd * 0.12, edges = [];
    for (i = 2; i < n - 2; i++) {
      var v = d[i];
      if (Math.abs(v) < thr) { continue; }
      if ((v > 0 && v >= d[i - 1] && v > d[i + 1]) || (v < 0 && v <= d[i - 1] && v < d[i + 1])) {
        // posizione al decimo di pixel (interpolazione parabolica)
        var den = d[i - 1] - 2 * v + d[i + 1];
        var off = den !== 0 ? 0.5 * (d[i - 1] - d[i + 1]) / den : 0;
        var e = { p: i + Math.max(-0.5, Math.min(0.5, off)), s: v < 0 ? 1 : 0, m: Math.abs(v) }; // s=1: inizia una barra scura
        var last = edges[edges.length - 1];
        if (last && last.s === e.s) { if (e.m > last.m) { edges[edges.length - 1] = e; } } else { edges.push(e); }
      }
    }
    if (edges.length < 60) { return null; }
    var runs = [edges[0].p], colors = [edges[0].s ? 0 : 1];
    for (i = 1; i < edges.length; i++) { runs.push(edges[i].p - edges[i - 1].p); colors.push(edges[i - 1].s); }
    runs.push(n - edges[edges.length - 1].p); colors.push(edges[edges.length - 1].s);
    return { runs: runs, colors: colors };
  }

  /*
   * Lettura "a modello" per immagini sfocate (webcam a fuoco fisso): invece di cercare i bordi delle barre,
   * confronta l'andamento della luminosita' di ogni cifra con quello atteso per ciascuna delle 20 codifiche,
   * tenendo conto della sfocatura misurata sulle barre di guardia. Il risultato deve superare la cifra di controllo.
   */
  var BITS_L = ['0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011'];
  var BITS_G = BITS_L.map(function (p) { return p.split('').map(function (c) { return c === '0' ? '1' : '0'; }).reverse().join(''); });
  var BITS_R = BITS_L.map(function (p) { return p.split('').map(function (c) { return c === '0' ? '1' : '0'; }).join(''); });

  function barcodeSpan(sm, white, dark) {
    var n = sm.length, mid = (white + dark) / 2, segs = [], i = 0;
    while (i < n) {
      if (sm[i] < mid) { var a = i; while (i < n && sm[i] < mid) { i++; } segs.push([a, i]); } else { i++; }
    }
    var best = null;
    [n / 45, n / 28].forEach(function (G) {
      var st = 0;
      for (var k = 1; k <= segs.length; k++) {
        if (k === segs.length || segs[k][0] - segs[k - 1][1] > G) {
          var cnt = k - st;
          if (cnt >= 10 && (!best || cnt > best.cnt)) { best = { a: segs[st][0], b: segs[k - 1][1], cnt: cnt }; }
          st = k;
        }
      }
    });
    return best;
  }

  function decodeTemplate(lum) {
    var n = lum.length, i;
    if (n < 100) { return null; }
    var sm = new Float32Array(n);
    for (i = 0; i < n; i++) { sm[i] = (lum[Math.max(0, i - 1)] + 2 * lum[i] + lum[Math.min(n - 1, i + 1)]) / 4; }
    var sorted = Array.prototype.slice.call(sm).sort(function (x, y) { return x - y; });
    var dark0 = sorted[Math.floor(n * 0.03)], white0 = sorted[Math.floor(n * 0.97)];
    if (white0 - dark0 < 25) { return null; }
    var span = barcodeSpan(sm, white0, dark0);
    if (!span) { return null; }
    var m0 = (span.b - span.a) / 95;
    if (m0 < 1.2) { return null; }
    // livelli di bianco (zona libera a sinistra/destra) e di nero (barre) locali
    var qa = Math.max(0, Math.floor(span.a - 6 * m0)), qb = Math.min(n, Math.ceil(span.b + 6 * m0));
    var wl = 0, wc = 0;
    for (i = qa; i < span.a - m0; i++) { wl += sm[i]; wc++; }
    for (i = Math.ceil(span.b + m0); i < qb; i++) { wl += sm[i]; wc++; }
    var white = wc ? wl / wc : white0;
    var inside = Array.prototype.slice.call(sm, span.a, span.b).sort(function (x, y) { return x - y; });
    var dark = inside[Math.floor(inside.length * 0.04)];
    if (white - dark < 20) { return null; }
    var val = function (x) { // "quanto e' scuro" in x, interpolato (0 = bianco, 1 = nero)
      if (x <= 0) { x = 0; } if (x >= n - 1) { x = n - 1.001; }
      var i0 = Math.floor(x), f = x - i0, v = sm[i0] * (1 - f) + sm[i0 + 1] * f;
      return Math.max(-0.2, Math.min(1.2, (white - v) / (white - dark)));
    };
    var bestCode = null, bestErr = 1e9;
    for (var da = -0.75; da <= 0.751; da += 0.25) {
      for (var db = -0.75; db <= 0.751; db += 0.25) {
        var left = span.a + da * m0, m = (span.b + db * m0 - left) / 95;
        var smp = new Float32Array(97); // campione medio di ogni modulo (piu' uno di margine per lato)
        for (var k = -1; k <= 95; k++) {
          var acc = 0;
          for (var q = 0; q < 5; q++) { acc += val(left + (k + 0.1 + q * 0.2) * m); }
          smp[k + 1] = acc / 5;
        }
        var S = function (k) { return smp[k + 1]; };
        // sfocatura stimata sulle guardie: barra isolata -> 1-2a, spazio tra due barre -> 2a
        var a = ((1 - S(0)) / 2 + S(1) / 2 + (1 - S(2)) / 2 + (1 - S(94)) / 2 + S(93) / 2 + (1 - S(92)) / 2) / 6;
        a = Math.max(0, Math.min(0.4, a));
        var expect = function (bits, lb, rb) {
          var b = [lb].concat(bits.split('').map(Number), [rb]), e = [];
          for (var j = 1; j <= 7; j++) { e.push(a * b[j - 1] + (1 - 2 * a) * b[j] + a * b[j + 1]); }
          return e;
        };
        var digitChoices = [], total = 0;
        for (var d = 0; d < 12; d++) {
          var base = d < 6 ? 3 + d * 7 : 50 + (d - 6) * 7;
          var obs = [];
          for (var j = 0; j < 7; j++) { obs.push(S(base + j)); }
          var cands = [];
          var tables = d < 6 ? [['L', BITS_L], ['G', BITS_G]] : [['R', BITS_R]];
          tables.forEach(function (tb) {
            for (var v = 0; v < 10; v++) {
              var e = d < 6 ? expect(tb[1][v], 1, 0) : expect(tb[1][v], 0, 1), err = 0;
              for (var j2 = 0; j2 < 7; j2++) { var df = obs[j2] - e[j2]; err += df * df; }
              cands.push({ v: v, t: tb[0], err: err });
            }
          });
          cands.sort(function (x, y) { return x.err - y.err; });
          digitChoices.push(cands.slice(0, 3));
          total += cands[0].err;
        }
        // guardia centrale e finale coerenti?
        var gErr = 0, gBits = { 45: 0, 46: 1, 47: 0, 48: 1, 49: 0, 92: 1, 93: 0, 94: 1 };
        Object.keys(gBits).forEach(function (kk) { var df = S(+kk) - (gBits[kk] ? 1 - 2 * a : 2 * a); gErr += df * df; });
        if (gErr > 2.2) { continue; }
        var build = function (ch) {
          var par = '', digs = [];
          for (var x = 0; x < 6; x++) { par += ch[x].t; digs.push(ch[x].v); }
          if (!(par in FIRST)) { return null; }
          for (x = 6; x < 12; x++) { digs.push(ch[x].v); }
          var code = String(FIRST[par]) + digs.join('');
          return checksumOk(code) ? code : null;
        };
        var pick = digitChoices.map(function (c) { return c[0]; });
        var code = build(pick), err = total + gErr;
        if (!code) { // si prova a cambiare una sola cifra con la seconda scelta piu' vicina
          var alts = [];
          for (var p2 = 0; p2 < 12; p2++) {
            for (var c2 = 1; c2 < digitChoices[p2].length; c2++) { alts.push({ p: p2, c: digitChoices[p2][c2], extra: digitChoices[p2][c2].err - digitChoices[p2][0].err }); }
          }
          alts.sort(function (x, y) { return x.extra - y.extra; });
          for (var z = 0; z < alts.length && z < 12 && !code; z++) {
            var trial = pick.slice(); trial[alts[z].p] = alts[z].c;
            code = build(trial);
            if (code) { err += alts[z].extra + 0.15; }
          }
        }
        if (code && err < bestErr && err < 5.5) { bestErr = err; bestCode = code; }
      }
    }
    return bestCode;
  }

  function decodeRow(lum) {
    var rev = null, r, c;
    for (var mode = 0; mode < 4; mode++) {
      r = mode === 3 ? toRunsEdges(lum) : toRuns(lum, mode);
      if (!r) { if (mode < 3) { continue; } else { break; } }
      c = decodeRuns(r);
      if (c) { return c; }
      rev = rev || Array.prototype.slice.call(lum).reverse();
      r = mode === 3 ? toRunsEdges(rev) : toRuns(rev, mode);
      c = r ? decodeRuns(r) : null;
      if (c) { return c; }
    }
    // immagine sfocata: confronto con i modelli (in entrambi i versi). Lettura "debole": va confermata.
    c = decodeTemplate(lum) || decodeTemplate(rev || Array.prototype.slice.call(lum).reverse());
    return c ? { code: c, weak: true } : null;
  }

  function lumAt(d, p) { return d[p] * 0.299 + d[p + 1] * 0.587 + d[p + 2] * 0.114; }

  /*
   * Analizza un'immagine: tante righe orizzontali (media di 3 righe vicine per ridurre il rumore)
   * e, se non trova nulla, anche colonne verticali (libro tenuto in verticale).
   * Basta una lettura: il codice ha la cifra di controllo e deve iniziare per 978/979.
   */
  function decodeImageData(img, opts) {
    var w = img.width, h = img.height, d = img.data, k, x, y, votes = {};
    // una lettura sicura vale subito; una lettura "a modello" deve ripetersi su due righe
    var accept = function (r) {
      if (!r) { return null; }
      var code = typeof r === 'string' ? r : r.code;
      if (!/^97[89]/.test(code)) { return null; }
      if (typeof r === 'string' || !r.weak) { return code; }
      votes[code] = (votes[code] || 0) + 1;
      return votes[code] >= 2 ? code : null;
    };
    var rows = (opts && opts.rows) || 21;
    for (k = 0; k < rows; k++) {
      var t = 0.5 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) / (rows + 1); // dal centro verso i bordi
      y = Math.max(1, Math.min(h - 2, Math.round(h * t)));
      var lum = new Float32Array(w);
      for (x = 0; x < w; x++) {
        lum[x] = (lumAt(d, ((y - 1) * w + x) * 4) + lumAt(d, (y * w + x) * 4) + lumAt(d, ((y + 1) * w + x) * 4)) / 3;
      }
      var c = accept(decodeRow(lum));
      if (c) { return c; }
    }
    if (opts && opts.vertical) {
      for (k = 0; k < 15; k++) {
        var tx = 0.5 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) / 16;
        x = Math.max(1, Math.min(w - 2, Math.round(w * tx)));
        var col = new Float32Array(h);
        for (y = 0; y < h; y++) {
          col[y] = (lumAt(d, (y * w + x - 1) * 4) + lumAt(d, (y * w + x) * 4) + lumAt(d, (y * w + x + 1) * 4)) / 3;
        }
        var c2 = accept(decodeRow(col));
        if (c2) { return c2; }
      }
    }
    return null;
  }

  // Legge il codice da una foto (file scelto o scattato): piu' nitida della webcam, prova anche in verticale
  function decodeImageFile(file) {
    return new Promise(function (resolve) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var sizes = [1600, 1000, 2400], found = null;
        for (var i = 0; i < sizes.length && !found; i++) {
          var sc = Math.min(1, sizes[i] / Math.max(im.width, im.height));
          var cw = Math.round(im.width * sc), ch = Math.round(im.height * sc);
          var cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
          var cx = cv.getContext('2d', { willReadFrequently: true });
          cx.drawImage(im, 0, 0, cw, ch);
          found = decodeImageData(cx.getImageData(0, 0, cw, ch), { rows: 41, vertical: true });
        }
        URL.revokeObjectURL(url);
        resolve(found);
      };
      im.onerror = function () { URL.revokeObjectURL(url); resolve(null); };
      im.src = url;
    });
  }

  var root = typeof window !== 'undefined' ? window : self;
  root.EAN13 = { decodeRow: decodeRow, decodeImageData: decodeImageData, decodeImageFile: decodeImageFile, checksumOk: checksumOk };

  // Eseguito come "worker" (processo separato): riceve i fotogrammi e risponde con il codice letto
  if (typeof window === 'undefined' && typeof self !== 'undefined' && typeof importScripts === 'function') {
    self.onmessage = function (e) {
      var m = e.data, img = { width: m.w, height: m.h, data: m.data };
      var code = null;
      try { code = decodeImageData(img, { rows: m.rows || 17, vertical: !!m.vertical }); } catch (err) { code = null; }
      self.postMessage({ id: m.id, code: code });
    };
    return;
  }

  /* ---------- Fotocamera ---------- */
  function Scanner(root, onCode) {
    this.root = root;
    this.video = root.querySelector('video');
    this.msg = root.querySelector('.scan-msg');
    this.onCode = onCode;
    this.stream = null;
    this.timer = null;
    this.tries = 0;
    this.busy = false;
    this.canvas = document.createElement('canvas');
    this.worker = null;
    this.workerUrl = SCRIPT_URL;
  }
  Scanner.prototype.openCamera = function (simple) {
    var c = simple ? { video: true, audio: false }
      : { audio: false, video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } } };
    return navigator.mediaDevices.getUserMedia(c);
  };
  Scanner.prototype.attach = function (stream) {
    var self = this;
    self.stream = stream;
    self.video.srcObject = stream;
    self.video.setAttribute('playsinline', '');
    self.video.muted = true;
    var p = self.video.play();
    return (p && p.then ? p : Promise.resolve()).catch(function () {});
  };
  Scanner.prototype.start = function () {
    var self = this;
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return Promise.reject(new Error('La fotocamera dal vivo funziona solo con il sito in HTTPS (o dal computer stesso): usa "Leggi il codice da una foto" oppure digita l\'ISBN.'));
    }
    self.stopped = false;
    self.root.classList.remove('found');
    if (self.msg) { self.msg.textContent = 'Inquadra il codice a barre sul retro del libro'; }
    return self.openCamera(false)
      .catch(function () { return self.openCamera(true); })
      .then(function (stream) { return self.attach(stream); })
      .then(function () {
        // se dopo 3 secondi non arriva nessuna immagine si riapre la fotocamera con le impostazioni piu' semplici
        setTimeout(function () {
          if (!self.stopped && self.stream && !self.video.videoWidth) {
            self.stream.getTracks().forEach(function (t) { t.stop(); });
            self.openCamera(true).then(function (s2) { return self.attach(s2); }).catch(function () {
              if (self.msg) { self.msg.textContent = 'La fotocamera non invia immagini: chiudi le altre app che la usano e riprova, oppure usa "Leggi il codice da una foto".'; }
            });
          }
        }, 3000);
        var useNative = false;
        if ('BarcodeDetector' in window) {
          try { self.detector = new window.BarcodeDetector({ formats: ['ean_13'] }); useNative = true; } catch (e) { useNative = false; }
        }
        if (!self.worker && typeof Worker !== 'undefined') {
          try {
            self.worker = new Worker(self.workerUrl);
            self.worker.onmessage = function (e) { self.onResult(e.data.code); };
            self.worker.onerror = function () { self.worker = null; };
          } catch (e) { self.worker = null; }
        }
        self.tries = 0;
        self.useNative = useNative;
        self.loop();
      });
  };
  Scanner.prototype.onResult = function (code) {
    this.busy = false;
    if (this.stopped) { return; }
    if (code && /^97[89]\d{10}$/.test(code) && checksumOk(code)) { this.found(code); return; }
    this.schedule(80);
  };
  Scanner.prototype.schedule = function (ms) {
    var self = this;
    clearTimeout(self.timer);
    self.timer = setTimeout(function () { self.loop(); }, ms);
  };
  Scanner.prototype.loop = function () {
    var self = this;
    if (self.stopped || !self.stream) { return; }
    var v = self.video;
    if (v.readyState < 2 || !v.videoWidth) { self.schedule(200); return; }
    if (self.busy) { self.schedule(100); return; }
    self.tries++;
    if (self.msg && self.tries === 50) {
      self.msg.textContent = 'Non riesco a leggerlo: più luce, codice dritto e nitido. Se la webcam non mette a fuoco, allontana un po\' il libro o usa "Leggi il codice da una foto".';
    }
    if (self.useNative) {
      self.busy = true;
      self.detector.detect(v).then(function (list) {
        var code = null;
        (list || []).forEach(function (b) { if (!code && /^97[89]\d{10}$/.test(b.rawValue)) { code = b.rawValue; } });
        if (code) { self.onResult(code); return; }
        self.busy = false;
        self.decodeFrame(v);
      }).catch(function () { self.useNative = false; self.busy = false; self.schedule(100); });
    } else {
      self.decodeFrame(v);
    }
  };
  // Fascia centrale del fotogramma (fino a 960 px di larghezza), analizzata nel worker per non bloccare la pagina
  Scanner.prototype.decodeFrame = function (v) {
    var vw = v.videoWidth, vh = v.videoHeight;
    var sc = Math.min(1, 960 / vw), cw = Math.round(vw * sc);
    var bandH = Math.round(vh * 0.6), ch = Math.round(bandH * sc);
    this.canvas.width = cw; this.canvas.height = ch;
    var ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(v, 0, Math.round((vh - bandH) / 2), vw, bandH, 0, 0, cw, ch);
    var img = ctx.getImageData(0, 0, cw, ch);
    var vertical = this.tries % 4 === 0;
    this.busy = true;
    if (this.worker) {
      this.worker.postMessage({ id: this.tries, w: cw, h: ch, data: img.data, rows: 17, vertical: vertical }, [img.data.buffer]);
    } else {
      var self = this;
      setTimeout(function () { self.onResult(decodeImageData(img, { rows: 11, vertical: vertical })); }, 0);
    }
  };
  Scanner.prototype.found = function (code) {
    this.root.classList.add('found');
    if (this.msg) { this.msg.textContent = 'Letto: ' + code; }
    if (window.App) { window.App.vibrate(60); }
    this.stop();
    this.onCode(code);
  };
  Scanner.prototype.stop = function () {
    this.stopped = true;
    this.busy = false;
    clearTimeout(this.timer);
    if (this.stream) { this.stream.getTracks().forEach(function (t) { t.stop(); }); }
    this.stream = null;
    if (this.video) { this.video.srcObject = null; }
  };
  window.IsbnScanner = Scanner;
})();
