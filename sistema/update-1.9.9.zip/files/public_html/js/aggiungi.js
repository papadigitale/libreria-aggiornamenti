/* Pagina "Aggiungi libro": ricerca per ISBN o titolo, scansione, scelta copertina */
(function () {
  'use strict';
  var App = window.App, esc = App.esc;
  var form = document.querySelector('[data-save-form]');
  if (!form) { return; }
  var statusEl = document.querySelector('[data-status]');
  var card = form.querySelector('[data-result-card]');
  var picks = form.querySelector('[data-cover-picks]');
  var dupBox = form.querySelector('[data-dup]');
  var editBox = form.querySelector('[data-edit-fields]');
  var urlsBox = form.querySelector('[data-cover-urls]');
  var scanner = null;

  function setStatus(kind, text) {
    statusEl.hidden = !text;
    statusEl.className = 'lookup-status' + (kind ? ' ' + kind : '');
    statusEl.innerHTML = (kind === 'busy' ? '<span class="spinner"></span>' : '') + esc(text || '');
  }

  // Riassunto dell'esito delle fonti consultate (utile quando un libro non si trova)
  function reportText(rep) {
    if (!rep || !rep.length) { return ''; }
    var seen = {}, parts = [];
    rep.forEach(function (x) {
      if (seen[x.source] && x.status !== 'ok') { return; }
      seen[x.source] = x.status === 'ok' ? 'trovato' : (x.status === 'vuoto' ? 'non presente' : 'errore' + (x.detail ? ': ' + x.detail : ''));
    });
    Object.keys(seen).forEach(function (k) { parts.push(k + ' (' + seen[k] + ')'); });
    return 'Fonti consultate: ' + parts.join(', ') + '.';
  }

  function field(name) { return form.querySelector('[name="' + name + '"]'); }
  function setField(name, v) { var f = field(name); if (f) { f.value = v == null ? '' : v; } }

  function previewUrl(u) { return 'api.php?action=cover_preview&u=' + encodeURIComponent(u); }

  function typoCover(b) {
    var first = (b.authors || '').split(',')[0];
    return '<div class="cover typo" style="background:linear-gradient(160deg,#5b1a1a,#2a0c0c);color:#e9d6a8"><span class="ca">' + esc(first)
      + '</span><span class="cl"></span><span class="ct">' + esc(b.title || '') + '</span></div>';
  }

  function showMainCover(b, url) {
    var box = card.querySelector('[data-rcover]');
    if (!url) { box.innerHTML = typoCover(b); return; }
    box.innerHTML = '<div class="cover has-img"><img alt="Copertina" src="' + esc(previewUrl(url)) + '"></div>';
    box.querySelector('img').onerror = function () { box.innerHTML = typoCover(b); };
  }

  function switchTab(name) {
    document.querySelectorAll('[data-tab]').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === name); });
    document.querySelectorAll('[data-pane]').forEach(function (p) { p.hidden = p.getAttribute('data-pane') !== name; });
    field('mode').value = name;
    if (name !== 'scan' && scanner) { scanner.stop(); toggleScanButtons(false); }
    if (name === 'mano') {
      form.hidden = false;
      card.hidden = true;
      picks.hidden = true;
      dupBox.hidden = true;
      editBox.open = true;
      form.querySelector('[data-edit-label]').textContent = 'Dati del libro';
      field('source').value = 'Manuale';
      setStatus('', '');
      var t = field('title'); if (t) { t.focus(); }
    }
  }

  function fill(b, dups) {
    form.hidden = false;
    card.hidden = false;
    editBox.open = false;
    form.querySelector('[data-edit-label]').textContent = 'Correggi o completa i dati';
    setField('title', b.title); setField('subtitle', b.subtitle); setField('authors', b.authors);
    setField('pages', b.pages); setField('pub_year', b.year); setField('publisher', b.publisher);
    setField('isbn', b.isbn13); setField('language', b.language); setField('description', b.description);
    setField('source', b.source || 'Online');
    var rows = [['Titolo', b.title], ['Autore', b.authors], ['Pagine', b.pages], ['Editore', b.publisher], ['Anno edizione', b.year]];
    card.querySelector('[data-rfields]').innerHTML = rows.map(function (r) {
      return '<div class="fr"><span class="fk">' + r[0] + '</span><span class="fv">' + (r[1] ? esc(r[1]) : '<span class="sub">— da completare</span>') + '</span></div>';
    }).join('');
    // copertine
    var covers = b.covers || [];
    urlsBox.innerHTML = covers.map(function (u) { return '<input type="hidden" name="cover_urls[]" value="' + esc(u) + '">'; }).join('')
      + '<input type="hidden" name="no_cover" value="0">';
    field('cover_choice').value = covers[0] || '';
    showMainCover(b, covers[0]);
    picks.innerHTML = '';
    picks.hidden = covers.length < 2;
    covers.forEach(function (u, i) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = i === 0 ? 'sel' : '';
      btn.innerHTML = '<img alt="" loading="lazy" src="' + esc(previewUrl(u)) + '">';
      btn.querySelector('img').onerror = function () { btn.remove(); if (picks.querySelectorAll('button').length < 3) { picks.hidden = picks.querySelectorAll('button').length < 2; } };
      btn.onclick = function () {
        picks.querySelectorAll('button').forEach(function (x) { x.classList.remove('sel'); });
        btn.classList.add('sel');
        field('cover_choice').value = u;
        field('no_cover').value = '0';
        showMainCover(b, u);
      };
      picks.appendChild(btn);
    });
    if (covers.length) {
      var none = document.createElement('button');
      none.type = 'button';
      none.className = 'none';
      none.textContent = 'Nessuna';
      none.onclick = function () {
        picks.querySelectorAll('button').forEach(function (x) { x.classList.remove('sel'); });
        none.classList.add('sel');
        field('no_cover').value = '1';
        showMainCover(b, '');
      };
      picks.appendChild(none);
    }
    // doppioni
    if (dups && dups.length) {
      dupBox.hidden = false;
      dupBox.innerHTML = 'Attenzione: in libreria c\'è già <a class="link" href="libro.php?id=' + dups[0].id + '">"' + esc(dups[0].title) + '"</a> con lo stesso ISBN. Puoi comunque salvarlo come seconda copia.';
    } else {
      dupBox.hidden = true;
    }
    setTimeout(function () { card.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 50);
  }

  function lookupIsbn(isbn) {
    isbn = (isbn || '').replace(/[^0-9Xx]/g, '');
    if (isbn.length !== 10 && isbn.length !== 13) { setStatus('err', 'L\'ISBN deve avere 10 o 13 cifre.'); return; }
    setStatus('busy', 'Cerco il libro sulle piattaforme online…');
    form.hidden = true;
    App.get({ action: 'lookup_isbn', isbn: isbn }).then(function (r) {
      if (r.ok) {
        setStatus('ok', '✓ Trovato su ' + (r.book.source || 'internet'));
        fill(r.book, r.duplicates);
      } else {
        setStatus('err', (r.error || 'Nessun risultato.') + ' ' + reportText(r.report));
        // si passa all'inserimento a mano con l'ISBN gia' scritto
        fill({ title: '', isbn13: r.isbn13 || isbn, covers: r.covers || [], source: 'Manuale' }, r.duplicates);
        editBox.open = true;
        card.hidden = true;
        var t = field('title'); if (t) { t.focus(); }
      }
    }).catch(function () { setStatus('err', 'Connessione non riuscita. Riprova.'); });
  }

  function lookupTitle(q) {
    var box = document.querySelector('[data-results]');
    box.innerHTML = '';
    form.hidden = true;
    if (q.trim().length < 2) { setStatus('err', 'Scrivi almeno 2 caratteri.'); return; }
    setStatus('busy', 'Cerco tra le edizioni disponibili…');
    App.get({ action: 'lookup_title', q: q }).then(function (r) {
      if (!r.ok) { setStatus('err', (r.error || 'Nessun risultato.') + ' ' + reportText(r.report)); return; }
      setStatus('ok', r.results.length + ' edizioni trovate: tocca quella che hai in mano.');
      r.results.forEach(function (b) {
        var el = document.createElement('button');
        el.type = 'button';
        el.className = 'res-item';
        el.innerHTML = '<span class="thumb">' + (b.cover ? '<img alt="" loading="lazy" src="' + esc(previewUrl(b.cover)) + '">' : '') + '</span>'
          + '<span><b>' + esc(b.title) + '</b><small>' + esc([b.authors, b.publisher, b.year].filter(Boolean).join(' · ')) + '</small>'
          + '<small>' + (b.pages ? esc(b.pages) + ' pagine · ' : '') + (b.isbn13 ? 'ISBN ' + esc(b.isbn13) : 'senza ISBN') + '</small></span>'
          + (b.duplicates && b.duplicates.length ? '<span class="dupmark">Già presente</span>' : '');
        var img = el.querySelector('img');
        if (img) { img.onerror = function () { img.remove(); }; }
        el.onclick = function () {
          box.querySelectorAll('.res-item').forEach(function (x) { x.style.opacity = x === el ? '1' : '.45'; });
          // con l'ISBN si recuperano dati e copertine piu' completi
          if (b.isbn13) {
            setStatus('busy', 'Completo i dati dell\'edizione scelta…');
            App.get({ action: 'lookup_isbn', isbn: b.isbn13 }).then(function (r2) {
              var full = r2.ok ? r2.book : b;
              if (r2.ok) {
                ['title', 'authors', 'publisher', 'year', 'pages'].forEach(function (k) { if (!full[k] && b[k]) { full[k] = b[k]; } });
                full.covers = (full.covers || []).concat((b.covers || []).filter(function (u) { return full.covers.indexOf(u) < 0; }));
              }
              setStatus('ok', '✓ Edizione selezionata');
              fill(full, r2.duplicates || b.duplicates);
            }).catch(function () { fill(b, b.duplicates); });
          } else {
            setStatus('ok', '✓ Edizione selezionata');
            fill(b, b.duplicates);
          }
        };
        box.appendChild(el);
      });
    }).catch(function () { setStatus('err', 'Connessione non riuscita. Riprova.'); });
  }

  document.querySelectorAll('[data-tab]').forEach(function (b) {
    b.addEventListener('click', function () { switchTab(b.getAttribute('data-tab')); });
  });
  document.querySelector('[data-lookup="isbn"]').addEventListener('submit', function (e) {
    e.preventDefault();
    lookupIsbn(this.isbn.value);
  });
  document.querySelector('[data-lookup="titolo"]').addEventListener('submit', function (e) {
    e.preventDefault();
    lookupTitle(this.q.value);
  });

  /* Scansione */
  var scanRoot = document.querySelector('[data-scanner]');
  var startBtn = document.querySelector('[data-scan-start]');
  var stopBtn = document.querySelector('[data-scan-stop]');
  function toggleScanButtons(on) { startBtn.hidden = on; stopBtn.hidden = !on; }
  function startScan() {
    if (!window.IsbnScanner) { return; }
    scanner = scanner || new window.IsbnScanner(scanRoot, function (code) {
      toggleScanButtons(false);
      switchTab('isbn');
      document.getElementById('isbn-in').value = code;
      field('mode').value = 'scan';
      lookupIsbn(code);
    });
    scanRoot.querySelector('.scan-msg').textContent = 'Inquadra il codice a barre sul retro del libro';
    toggleScanButtons(true);
    scanner.start().catch(function (err) {
      toggleScanButtons(false);
      var msg = err && err.name === 'NotAllowedError' ? 'Permesso fotocamera negato: abilitalo nelle impostazioni del browser.' : (err && err.message ? err.message : 'Fotocamera non disponibile.');
      document.querySelector('[data-scan-hint]').textContent = msg;
      setStatus('err', msg);
    });
  }
  startBtn.addEventListener('click', startScan);

  // Lettura da una foto (scattata col telefono o scelta dal PC): immagine nitida, funziona anche senza HTTPS
  var photo = document.querySelector('[data-scan-photo]');
  if (photo) {
    photo.addEventListener('change', function () {
      var f = photo.files && photo.files[0];
      if (!f || !window.EAN13) { return; }
      setStatus('busy', 'Cerco il codice a barre nella foto…');
      window.EAN13.decodeImageFile(f).then(function (code) {
        photo.value = '';
        if (!code) {
          setStatus('err', 'Nella foto non trovo un codice ISBN leggibile. Riprova più vicino e con più luce, oppure digita le cifre.');
          return;
        }
        switchTab('isbn');
        document.getElementById('isbn-in').value = code;
        field('mode').value = 'scan';
        lookupIsbn(code);
      });
    });
  }
  stopBtn.addEventListener('click', function () { if (scanner) { scanner.stop(); } toggleScanButtons(false); });

  // Avvio da collegamenti (es. ricerca vuota in libreria) o dopo un salvataggio in modalita' scansione
  var params = new URLSearchParams(location.search);
  if (params.get('isbn')) { lookupIsbn(params.get('isbn')); }
  else if (params.get('titolo')) { lookupTitle(params.get('titolo')); }
  if (params.get('modo') === 'scan' && params.get('ok')) { switchTab('scan'); startScan(); }
})();
