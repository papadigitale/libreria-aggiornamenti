/* Chiavi di accesso (passkey): creazione da "Il mio account" e accesso dalla pagina di login */
(function () {
  'use strict';
  var supported = !!(window.PublicKeyCredential && navigator.credentials && window.isSecureContext);

  function b64uToBuf(s) {
    s = String(s).replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) { s += '='; }
    var bin = atob(s), buf = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) { buf[i] = bin.charCodeAt(i); }
    return buf.buffer;
  }
  function bufToB64u(buf) {
    var b = new Uint8Array(buf), s = '';
    for (var i = 0; i < b.length; i++) { s += String.fromCharCode(b[i]); }
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function errText(e) {
    if (!e) { return 'Operazione non riuscita.'; }
    if (e.name === 'NotAllowedError') { return 'Operazione annullata o tempo scaduto.'; }
    if (e.name === 'InvalidStateError') { return 'Questa chiave è già registrata per il tuo account.'; }
    if (e.name === 'SecurityError') { return 'Il browser non permette le chiavi su questo indirizzo: apri il sito dal suo indirizzo https://.'; }
    return e.message || 'Operazione non riuscita.';
  }
  function show(el, text, ok) {
    if (!el) { return; }
    el.hidden = false;
    el.className = 'alert ' + (ok ? 'success' : 'error');
    el.textContent = text;
  }

  // creazione di una chiave: chiede le opzioni al sito, poi al telefono/computer/Bitwarden
  var createKey = function (name, pw) {
    return window.App.post('passkey_reg_options', pw ? { pw: pw } : {}).then(function (r) {
      if (!r.ok) { throw new Error(r.error); }
      var o = r.options;
      o.challenge = b64uToBuf(o.challenge);
      o.user.id = b64uToBuf(o.user.id);
      (o.excludeCredentials || []).forEach(function (c) { c.id = b64uToBuf(c.id); });
      return navigator.credentials.create({ publicKey: o });
    }).then(function (cred) {
      var resp = cred.response;
      var data = {
        id: cred.id,
        clientDataJSON: bufToB64u(resp.clientDataJSON),
        attestationObject: bufToB64u(resp.attestationObject),
        transports: resp.getTransports ? resp.getTransports() : []
      };
      return window.App.post('passkey_reg_finish', { credential: JSON.stringify(data), name: name });
    }).then(function (r) {
      if (!r.ok) { throw new Error(r.error); }
      return r;
    });
  };
  var store = function (k, v) { try { if (v === undefined) { return window.localStorage.getItem(k); } window.localStorage.setItem(k, v); } catch (e) { return null; } return null; };

  /* ---------- Proposta dopo l'accesso con la password ---------- */
  var prop = document.querySelector('[data-pk-propose]');
  if (prop) {
    if (supported && store('ldc_pk_no') !== '1') {
      prop.hidden = false;
      var pmsg = prop.querySelector('[data-pk-propose-msg]');
      var pbtn = prop.querySelector('[data-pk-propose-go]');
      pbtn.addEventListener('click', function () {
        pbtn.disabled = true;
        createKey('').then(function () {
          store('ldc_pk_no', '1');
          prop.innerHTML = '<div class="pkp-done">' + 'Fatto! La prossima volta tocca <b>«Accedi con una chiave di accesso»</b> nella pagina di accesso.' + '</div>';
          setTimeout(function () { prop.hidden = true; }, 6000);
        }).catch(function (e) { pbtn.disabled = false; show(pmsg, errText(e), false); });
      });
      prop.querySelector('[data-pk-propose-later]').addEventListener('click', function () { prop.hidden = true; });
      prop.querySelector('[data-pk-propose-never]').addEventListener('click', function () { store('ldc_pk_no', '1'); prop.hidden = true; });
    }
  }

  /* ---------- Creazione (Il mio account) ---------- */
  var reg = document.querySelector('[data-pk-register]');
  if (reg) {
    var msg = reg.querySelector('[data-pk-msg]');
    var btn = reg.querySelector('[data-pk-create]');
    if (!supported) {
      btn.disabled = true;
      show(msg, 'Questo browser o questo indirizzo non permettono le chiavi di accesso. Apri il sito dal suo indirizzo https:// con un browser aggiornato.', false);
    }
    reg.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!supported) { return; }
      btn.disabled = true;
      var name = reg.querySelector('[name=pk_name]').value;
      var pwf = reg.querySelector('[name=pk_pw]');
      createKey(name, pwf ? pwf.value : '').then(function () {
        store('ldc_pk_no', '1');
        window.location.href = 'account.php#chiavi';
        window.location.reload();
      }).catch(function (e) {
        btn.disabled = false;
        show(msg, errText(e), false);
      });
    });
  }

  /* ---------- Accesso (pagina di login) ---------- */
  var loginBtn = document.querySelector('[data-pk-login]');
  if (loginBtn) {
    var lmsg = document.querySelector('[data-pk-login-msg]');
    if (!supported) {
      loginBtn.hidden = true;
      if (loginBtn.parentNode) { loginBtn.parentNode.hidden = true; }
      return;
    }
    loginBtn.hidden = false;
    var pending = null;

    var finish = function (cred) {
      var resp = cred.response;
      var data = {
        id: cred.id,
        clientDataJSON: bufToB64u(resp.clientDataJSON),
        authenticatorData: bufToB64u(resp.authenticatorData),
        signature: bufToB64u(resp.signature),
        userHandle: resp.userHandle ? bufToB64u(resp.userHandle) : ''
      };
      var rem = document.querySelector('[data-remember]');
      return window.App.post('passkey_login_finish', { credential: JSON.stringify(data), remember: rem && rem.checked ? '1' : '' }).then(function (r) {
        if (!r.ok) { throw new Error(r.error); }
        window.location.href = r.redirect || 'libreria.php';
      });
    };
    var start = function (conditional) {
      if (pending) { pending.abort(); }
      pending = window.AbortController ? new AbortController() : null;
      var signal = pending ? pending.signal : undefined;
      return window.App.post('passkey_login_options').then(function (r) {
        if (!r.ok) { throw new Error(r.error); }
        var o = r.options;
        o.challenge = b64uToBuf(o.challenge);
        var req = { publicKey: o };
        if (signal) { req.signal = signal; }
        if (conditional) { req.mediation = 'conditional'; }
        return navigator.credentials.get(req);
      }).then(function (cred) {
        if (cred) { return finish(cred); }
      });
    };
    loginBtn.addEventListener('click', function () {
      loginBtn.disabled = true;
      if (lmsg) { lmsg.hidden = true; }
      start(false).catch(function (e) {
        if (e && e.name === 'AbortError') { return; }
        loginBtn.disabled = false;
        show(lmsg, errText(e), false);
      });
    });
    // Bitwarden e i browser propongono la chiave direttamente toccando il campo "Nome utente"
    if (PublicKeyCredential.isConditionalMediationAvailable) {
      PublicKeyCredential.isConditionalMediationAvailable().then(function (ok) {
        if (ok) {
          start(true).catch(function (e) {
            if (e && (e.name === 'AbortError' || e.name === 'NotAllowedError')) { return; }
            show(lmsg, errText(e), false);
          });
        }
      }).catch(function () {});
    }
  }
})();
