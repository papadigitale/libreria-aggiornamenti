/* Ruota di lettura personale */
(function () {
  'use strict';
  var App = window.App, esc = App.esc;
  var stateEl = document.getElementById('wheel-state');
  if (!stateEl) { return; }
  var S = JSON.parse(stateEl.textContent);
  var stage = document.querySelector('[data-stage]');
  var cv = stage.querySelector('canvas'), ctx = cv.getContext('2d');
  var pointer = stage.querySelector('.pointer');
  var emptyEl = stage.querySelector('[data-empty]');
  var spinBtns = document.querySelectorAll('[data-spin]');
  var rot = 0, spinning = false, current = null, spinId = 0;

  var css = getComputedStyle(document.documentElement);
  function cssVar(n, f) { var v = css.getPropertyValue(n).trim(); return v || f; }
  var C = S.colors; // principale, accento, testo scuro, tenue
  var SEG = [C[0], C[1], C[2], C[3], mix(C[0], C[1], 0.5), mix(C[2], C[0], 0.45)];

  function hexToRgb(h) { h = h.replace('#', ''); return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)]; }
  function mix(a, b, t) {
    var x = hexToRgb(a), y = hexToRgb(b);
    return '#' + [0, 1, 2].map(function (i) { return ('0' + Math.round(x[i] * (1 - t) + y[i] * t).toString(16)).slice(-2); }).join('');
  }
  function textOn(hex) {
    var c = hexToRgb(hex), l = (c[0] * 299 + c[1] * 587 + c[2] * 114) / 1000;
    return l > 150 ? '#2b1d14' : '#fbf6ec';
  }

  function size() {
    var r = cv.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    cv.width = Math.round(r.width * d); cv.height = Math.round(r.height * d);
    draw();
  }
  function fit(text, max) {
    if (ctx.measureText(text).width <= max) { return text; }
    while (text.length > 1 && ctx.measureText(text + '…').width > max) { text = text.slice(0, -1); }
    return text.replace(/\s+$/, '') + '…';
  }
  function segColor(i, n) {
    var k = i % SEG.length;
    if (i === n - 1 && k === 0 && n > 1) { k = 2; } // evita due spicchi uguali vicini
    return SEG[k];
  }
  function draw() {
    var W = cv.width, R = W / 2, items = S.items, n = items.length;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, W, W);
    if (!n) { return; }
    var step = Math.PI * 2 / n;
    ctx.translate(R, R);
    ctx.rotate(rot);
    var fontHead = cssVar('--head', 'Georgia, serif');
    for (var i = 0; i < n; i++) {
      var a0 = -Math.PI / 2 + i * step - step / 2, col = segColor(i, n);
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, R, a0, a0 + step); ctx.closePath();
      ctx.fillStyle = col; ctx.fill();
      ctx.strokeStyle = C[1]; ctx.lineWidth = Math.max(1, R * 0.008); ctx.stroke();
      ctx.save();
      ctx.rotate(a0 + step / 2);
      ctx.fillStyle = textOn(col);
      var fs = Math.max(R * 0.055, Math.min(R * 0.085, R * 1.6 / n));
      ctx.font = '600 ' + fs + 'px ' + fontHead;
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText(fit(items[i].t, R * 0.6), R * 0.9, 0);
      ctx.restore();
    }
    for (var j = 0; j < n; j++) {
      var a = -Math.PI / 2 + j * step - step / 2;
      ctx.beginPath(); ctx.arc(Math.cos(a) * R * 0.955, Math.sin(a) * R * 0.955, R * 0.022, 0, Math.PI * 2);
      ctx.fillStyle = mix(C[1], '#ffffff', 0.35); ctx.fill();
    }
    var g = ctx.createRadialGradient(0, 0, R * 0.2, 0, 0, R);
    g.addColorStop(0, 'rgba(0,0,0,.18)'); g.addColorStop(0.35, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.12)');
    ctx.beginPath(); ctx.arc(0, 0, R, 0, Math.PI * 2); ctx.fillStyle = g; ctx.fill();
  }
  function indexAt(r) {
    var n = S.items.length, step = Math.PI * 2 / n;
    var a = ((-r) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    return Math.round(a / step) % n;
  }
  function tick() {
    pointer.classList.remove('tick'); void pointer.getBoundingClientRect(); pointer.classList.add('tick');
    App.vibrate(4);
  }

  function refresh(data) {
    if (data.items) { S.items = data.items; }
    if (typeof data.total === 'number') { S.total = data.total; }
    if (data.settings) { S.settings = data.settings; }
    rot = 0;
    document.querySelector('[data-count]').textContent = S.total;
    document.querySelector('[data-count-label]').textContent = S.total === 1 ? 'libro' : 'libri';
    document.querySelector('[data-sample-note]').hidden = S.total <= S.max;
    var empty = S.total < 2;
    emptyEl.hidden = !empty;
    if (empty) {
      var src = S.settings.source;
      emptyEl.innerHTML = S.total === 0
        ? (src === 'manual' ? 'Non hai ancora scelto libri per la tua ruota. Tocca “Scegli i libri”.'
          : src === 'unread' ? 'Nessun libro ancora da leggere con questi filtri. Prova “Tutta la libreria”.' : 'Nessun libro corrisponde ai filtri.')
        : 'Serve almeno un secondo libro per far girare la ruota.';
    }
    spinBtns.forEach(function (b) { b.disabled = empty; });
    draw();
  }

  function spin() {
    if (spinning || S.total < 2) { return; }
    spinning = true;
    closeSheets();
    spinBtns.forEach(function (b) { b.disabled = true; });
    App.post('wheel_spin').then(function (r) {
      if (!r.ok) { spinning = false; spinBtns.forEach(function (b) { b.disabled = false; }); alertMsg(r.error); return; }
      S.items = r.items; S.total = r.total; spinId = r.spin_id;
      var n = S.items.length, step = Math.PI * 2 / n;
      rot = rot % (Math.PI * 2);
      draw();
      var jitter = (Math.random() - 0.5) * step * 0.7;
      var target = -r.index * step + jitter;
      var turns = 6 + Math.floor(Math.random() * 3);
      var start = rot, end = target - Math.PI * 2 * turns;
      while (end > start - Math.PI * 2 * 5) { end -= Math.PI * 2; }
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var dur = reduce ? 600 : 5200 + Math.random() * 1200, t0 = performance.now(), last = indexAt(start);
      (function frame(now) {
        var p = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - p, 4);
        rot = start + (end - start) * e;
        draw();
        var idx = indexAt(rot);
        if (idx !== last) { last = idx; tick(); }
        if (p < 1) { requestAnimationFrame(frame); }
        else {
          spinning = false;
          spinBtns.forEach(function (b) { b.disabled = false; });
          setTimeout(function () { show(S.items[r.index]); }, 350);
        }
      })(t0);
    }).catch(function () { spinning = false; spinBtns.forEach(function (b) { b.disabled = false; }); alertMsg('Connessione non riuscita.'); });
  }

  function show(b) {
    current = b;
    var q = function (k) { return document.querySelector('[data-r="' + k + '"]'); };
    q('t').textContent = b.t;
    q('a').textContent = b.a || '—';
    q('p').textContent = b.p || '—';
    q('e').textContent = b.e || '—';
    q('y').textContent = b.y || '—';
    if (b.cover) {
      q('cover').innerHTML = '<div class="cover has-img"><img alt="" src="' + esc(b.cover) + '"></div>';
    } else {
      q('cover').innerHTML = '<div class="cover typo" style="background:linear-gradient(160deg,' + esc(b.pal[0]) + ',' + esc(b.pal[1]) + ');color:' + esc(b.pal[2]) + '">'
        + '<span class="ca">' + esc((b.a || '').split(',')[0]) + '</span><span class="cl"></span><span class="ct">' + esc(b.t) + '</span></div>';
    }
    document.body.classList.add('show-result');
  }
  function closeSheets() { document.body.classList.remove('show-result', 'show-picker'); }
  function alertMsg(m) { window.alert(m); }

  document.querySelectorAll('[data-outcome]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var o = btn.getAttribute('data-outcome');
      App.post('wheel_outcome', { spin_id: spinId, outcome: o }).then(function (r) {
        if (!r.ok) { alertMsg(r.error); return; }
        if (o === 'rigirata') { closeSheets(); setTimeout(spin, 300); return; }
        // ricarica per aggiornare storico e conteggi
        location.reload();
      });
    });
  });
  document.querySelector('[data-veil]').addEventListener('click', closeSheets);
  spinBtns.forEach(function (b) { b.addEventListener('click', spin); });

  /* Impostazioni personali della ruota */
  var setBox = document.querySelector('[data-wheel-settings]');
  var pickBtn = document.querySelector('[data-open-picker]');
  setBox.addEventListener('change', function () {
    var src = setBox.querySelector('input[name=source]:checked').value;
    pickBtn.hidden = src !== 'manual';
    App.post('wheel_settings', {
      source: src,
      category_id: setBox.querySelector('[name=category_id]').value,
      max_pages: setBox.querySelector('[name=max_pages]').value
    }).then(function (r) {
      if (r.ok) { refresh(r); if (src === 'manual' && r.total === 0) { openPicker(); } }
    });
  });

  /* Scelta manuale dei libri */
  var picker = document.querySelector('[data-picker]');
  var listEl = picker.querySelector('[data-picker-list]');
  var qEl = picker.querySelector('[data-picker-q]');
  var saveBtn = picker.querySelector('[data-picker-save]');
  var books = null, selected = {}, filter = '';
  function countSel() { var n = Object.keys(selected).length; saveBtn.querySelector('[data-n]').textContent = n; return n; }
  function renderPicker() {
    var q = qEl.value.trim().toLowerCase();
    var shown = books.filter(function (b) {
      if (filter === 'sel' && !selected[b.id]) { return false; }
      if (filter === 'nonletti' && (b.s === 'letto' || b.s === 'in_lettura')) { return false; }
      if (filter === 'letto' && b.s !== 'letto') { return false; }
      return !q || (b.t + ' ' + b.a).toLowerCase().indexOf(q) >= 0;
    });
    listEl.innerHTML = shown.length ? shown.map(function (b) {
      return '<label class="pk"><input type="checkbox" value="' + b.id + '"' + (selected[b.id] ? ' checked' : '') + '>'
        + '<span><b>' + esc(b.t) + '</b><small>' + esc(b.a) + (b.s ? ' · ' + ({ letto: 'letto', in_lettura: 'in lettura', da_leggere: 'da leggere' })[b.s] : '') + '</small></span></label>';
    }).join('') : '<p class="sub">Nessun libro.</p>';
    return shown;
  }
  function openPicker() {
    document.body.classList.add('show-picker');
    if (books) { renderPicker(); return; }
    App.get({ action: 'wheel_books' }).then(function (r) {
      books = r.books || [];
      selected = {};
      (r.selected || []).forEach(function (id) { selected[id] = 1; });
      countSel();
      renderPicker();
    });
  }
  pickBtn.addEventListener('click', openPicker);
  listEl.addEventListener('change', function (e) {
    if (e.target.type === 'checkbox') {
      if (e.target.checked) { selected[e.target.value] = 1; } else { delete selected[e.target.value]; }
      countSel();
    }
  });
  qEl.addEventListener('input', renderPicker);
  picker.querySelector('[data-picker-filter]').addEventListener('click', function (e) {
    var c = e.target.closest('.chip'); if (!c) { return; }
    filter = c.getAttribute('data-f');
    this.querySelectorAll('.chip').forEach(function (x) { x.classList.toggle('on', x === c); });
    renderPicker();
  });
  picker.querySelector('[data-picker-all]').addEventListener('click', function () {
    renderPicker().forEach(function (b) { selected[b.id] = 1; });
    countSel(); renderPicker();
  });
  saveBtn.addEventListener('click', function () {
    saveBtn.disabled = true;
    App.post('wheel_items', { ids: Object.keys(selected).join(',') }).then(function (r) {
      saveBtn.disabled = false;
      if (!r.ok) { alertMsg(r.error); return; }
      document.querySelector('[data-manual-count]').textContent = r.count;
      setBox.querySelector('input[value=manual]').checked = true;
      closeSheets();
      refresh(r);
    });
  });

  window.addEventListener('resize', size);
  refresh(S);
  (document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(size);
  size();
})();
