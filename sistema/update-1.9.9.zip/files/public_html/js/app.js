/* Libreria di Casa — funzioni comuni a tutte le pagine */
(function () {
  'use strict';
  var cfgEl = document.getElementById('app-config');
  var cfg = {};
  try { cfg = JSON.parse(cfgEl ? cfgEl.textContent : '{}'); } catch (e) { cfg = {}; }

  function toForm(data) {
    var fd = new FormData();
    fd.append('csrf', cfg.csrf || '');
    Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k] == null ? '' : data[k]); });
    return fd;
  }
  function handle(r) {
    return r.json().catch(function () { return { ok: false, error: 'Risposta non valida dal server.' }; });
  }
  window.App = {
    csrf: cfg.csrf,
    get: function (params) {
      var qs = Object.keys(params).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]); }).join('&');
      return fetch('api.php?' + qs, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } }).then(handle);
    },
    post: function (action, data) {
      var d = data || {};
      d.action = action;
      return fetch('api.php', { method: 'POST', body: toForm(d), credentials: 'same-origin' }).then(handle);
    },
    esc: function (v) {
      return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c];
      });
    },
    vibrate: function (ms) { try { if (navigator.vibrate) { navigator.vibrate(ms); } } catch (e) {} }
  };

  // Conferma prima di inviare i moduli delicati (eliminazioni, ripristini...)
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.hasAttribute && f.hasAttribute('data-confirm') && !window.confirm(f.getAttribute('data-confirm'))) {
      e.preventDefault();
      return;
    }
    // evita doppi invii
    var b = f.querySelector('button[type=submit]');
    if (b && !f.hasAttribute('data-no-lock')) {
      setTimeout(function () { b.disabled = true; }, 0);
      setTimeout(function () { b.disabled = false; }, 8000);
    }
  });

  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-toggle]');
    if (t) {
      var el = document.querySelector(t.getAttribute('data-toggle'));
      if (el) { el.classList.toggle('open'); }
    }
    var p = e.target.closest('[data-toggle-pw]');
    if (p) {
      var inp = document.getElementById(p.getAttribute('data-toggle-pw'));
      if (inp) { inp.type = inp.type === 'password' ? 'text' : 'password'; }
    }
  });

  // Salvataggio immediato (es. stato di lettura)
  document.addEventListener('change', function (e) {
    if (e.target.hasAttribute && e.target.hasAttribute('data-autosubmit') && e.target.form) {
      e.target.form.submit();
    }
  });

  // Righe scorrevoli con frecce (es. "Aggiunti di recente")
  function initCarousels(root) {
  root.querySelectorAll('[data-carousel]').forEach(function (c) {
    var track = c.querySelector('.car-track');
    var prev = c.querySelector('.car-btn.prev'), next = c.querySelector('.car-btn.next');
    var update = function () {
      // frecce sempre visibili quando la riga e' piu' lunga dello schermo; nascoste solo se tutti i libri ci stanno
      c.classList.toggle('fits', track.scrollWidth <= track.clientWidth + 4);
      prev.disabled = track.scrollLeft <= 4;
      next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
    };
    // con il mouse si puo' trascinare la riga (sul telefono si scorre gia' con il dito)
    var down = false, moved = false, startX = 0, startLeft = 0;
    track.addEventListener('pointerdown', function (e) {
      if (e.pointerType !== 'mouse' || e.button !== 0) { return; }
      down = true; moved = false; startX = e.clientX; startLeft = track.scrollLeft;
    });
    window.addEventListener('pointermove', function (e) {
      if (!down) { return; }
      var dx = e.clientX - startX;
      if (!moved && Math.abs(dx) > 6) { moved = true; track.classList.add('dragging'); }
      if (moved) { track.scrollLeft = startLeft - dx; e.preventDefault(); }
    });
    window.addEventListener('pointerup', function () {
      if (!down) { return; }
      down = false;
      if (moved) {
        track.classList.remove('dragging');
        // allinea alla copertina piu' vicina
        var item = track.querySelector('.car-item');
        if (item) {
          var w = item.getBoundingClientRect().width + 12;
          track.scrollTo({ left: Math.round(track.scrollLeft / w) * w, behavior: 'smooth' });
        }
      }
    });
    track.addEventListener('click', function (e) { if (moved) { e.preventDefault(); e.stopPropagation(); moved = false; } }, true);
    track.addEventListener('dragstart', function (e) { e.preventDefault(); });
    [prev, next].forEach(function (b) {
      b.addEventListener('click', function () {
        var item = track.querySelector('.car-item');
        var step = item ? item.getBoundingClientRect().width + 12 : track.clientWidth;
        track.scrollBy({ left: step * (+b.getAttribute('data-dir')), behavior: 'smooth' });
      });
    });
    track.addEventListener('scroll', function () { window.requestAnimationFrame(update); }, { passive: true });
    window.addEventListener('resize', update);
    update();
  });
  }
  initCarousels(document);

  // Indice alfabetico: scorrimento morbido e lettera evidenziata
  function initAlpha(root) {
  root.querySelectorAll('.alpha a').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var t = document.querySelector(a.getAttribute('href'));
      if (!t) { return; }
      e.preventDefault();
      t.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.querySelectorAll('.alpha a.on').forEach(function (x) { x.classList.remove('on'); });
      a.classList.add('on');
      if (history.replaceState) { history.replaceState(null, '', a.getAttribute('href')); }
    });
  });
  }
  initAlpha(document);

  // Libreria: i risultati si aggiornano mentre si scrive nella barra di ricerca
  var lf = document.querySelector('[data-live-search]');
  var lbox = document.querySelector('[data-live-results]');
  if (lf && lbox && window.fetch && window.DOMParser) {
    var lin = lf.querySelector('input[name=q]'), ltimer = null, lctrl = null, llast = lin.value.trim();
    var lurl = function () {
      var p = [];
      ['q', 'cat', 'et', 'ordine', 'stato'].forEach(function (k) {
        var el = lf.querySelector('[name=' + k + ']');
        var v = el ? String(el.value).trim() : '';
        if (v !== '' && !(k === 'ordine' && v === 'recenti')) { p.push(encodeURIComponent(k) + '=' + encodeURIComponent(v)); }
      });
      return 'libreria.php' + (p.length ? '?' + p.join('&') : '');
    };
    var lrun = function () {
      var q = lin.value.trim();
      if (q === llast) { return; }
      llast = q;
      var url = lurl();
      if (lctrl && lctrl.abort) { lctrl.abort(); }
      lctrl = window.AbortController ? new AbortController() : null;
      lbox.classList.add('loading');
      fetch(url, { credentials: 'same-origin', signal: lctrl ? lctrl.signal : undefined }).then(function (r) { return r.text(); }).then(function (html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var nb = doc.querySelector('[data-live-results]');
        if (!nb) { return; }
        lbox.innerHTML = nb.innerHTML;
        lbox.classList.remove('loading');
        initCarousels(lbox);
        initAlpha(lbox);
        if (history.replaceState) { history.replaceState(null, '', url); }
      }).catch(function () { lbox.classList.remove('loading'); });
    };
    lin.addEventListener('input', function () { clearTimeout(ltimer); ltimer = setTimeout(lrun, 250); });
    lf.addEventListener('submit', function (e) { e.preventDefault(); clearTimeout(ltimer); lin.blur(); llast = null; lrun(); });
  }

  // Lente in basso ("Cerca"): barra di ricerca al centro dello schermo, con i risultati mentre si scrive
  var openSearch = function () {
    var ov = document.querySelector('.sov');
    if (!ov) {
      ov = document.createElement('div');
      ov.className = 'sov';
      ov.setAttribute('role', 'dialog');
      ov.setAttribute('aria-modal', 'true');
      ov.setAttribute('aria-label', 'Cerca nella libreria');
      ov.innerHTML = '<div class="sov-box"><form class="sov-form" action="libreria.php" method="get" role="search">'
        + '<svg class="i" width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>'
        + '<input type="search" name="q" placeholder="Titolo, autore, ISBN…" aria-label="Cerca" autocomplete="off" enterkeyhint="search">'
        + '<button type="button" class="sov-x" aria-label="Chiudi">✕</button></form>'
        + '<div class="sov-res" aria-live="polite"></div></div>';
      document.body.appendChild(ov);
      var inp = ov.querySelector('input'), res = ov.querySelector('.sov-res'), t = null, seq = 0;
      var close = function () { ov.classList.remove('open'); document.body.classList.remove('sov-on'); };
      ov.addEventListener('click', function (e) { if (e.target === ov) { close(); } });
      ov.querySelector('.sov-x').addEventListener('click', close);
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && ov.classList.contains('open')) { close(); } });
      inp.addEventListener('input', function () {
        clearTimeout(t);
        var q = inp.value.trim();
        if (!q) { res.innerHTML = ''; return; }
        t = setTimeout(function () {
          var my = ++seq;
          window.App.get({ action: 'search', q: q }).then(function (r) {
            if (my !== seq) { return; }
            if (!r.ok) { res.innerHTML = '<p class="sov-empty">' + window.App.esc(r.error || 'Errore.') + '</p>'; return; }
            if (!r.total) { res.innerHTML = '<p class="sov-empty">Nessun libro trovato.</p>'; return; }
            res.innerHTML = r.html + (r.total > 20 ? '<a class="sov-all" href="libreria.php?q=' + encodeURIComponent(q) + '">Vedi tutti i ' + r.total + ' risultati</a>'
              : '<a class="sov-all" href="libreria.php?q=' + encodeURIComponent(q) + '">Mostra nella libreria</a>');
          });
        }, 200);
      });
      ov._close = close;
    }
    ov.classList.add('open');
    document.body.classList.add('sov-on');
    var i = ov.querySelector('input');
    i.focus();
    i.select();
  };
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a[href="libreria.php?cerca=1"]') : null;
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey) { return; }
    e.preventDefault();
    openSearch();
  });

  // Menu in alto: si chiude toccando fuori
  document.addEventListener('click', function (e) {
    document.querySelectorAll('.sitemenu[open]').forEach(function (d) {
      if (!d.contains(e.target)) { d.removeAttribute('open'); }
    });
  });

  // Pulsante "Torna in alto": compare dopo aver scorso un po' la pagina
  (function () {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'totop';
    btn.setAttribute('aria-label', 'Torna in alto');
    btn.title = 'Torna in alto';
    btn.innerHTML = '<svg class="i" width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
    document.body.appendChild(btn);
    var ticking = false;
    var check = function () {
      ticking = false;
      btn.classList.toggle('show', window.pageYOffset > Math.max(320, window.innerHeight * 0.6));
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(check); }
    }, { passive: true });
    btn.addEventListener('click', function () {
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
      btn.blur();
    });
    check();
  })();

  // Voto a stelle (quarti di stella) e campo dell'avanzamento: pagina o percentuale
(function () {
  document.querySelectorAll('[data-rate]').forEach(function (box) {
    var r = box.querySelector('input[type=range]'), on = box.querySelector('.stars-on'), lab = box.querySelector('[data-rate-val]');
    var upd = function () {
      var v = parseFloat(r.value) || 0;
      on.style.width = (v / 5 * 100) + '%';
      lab.textContent = v ? String(v).replace('.', ',') + ' su 5' : 'nessun voto';
    };
    r.addEventListener('input', upd);
  });
  document.querySelectorAll('[data-prog-form]').forEach(function (f) {
    var mode = f.querySelector('[data-prog-mode]'), val = f.querySelector('input[name=value]');
    var total = parseInt(val.getAttribute('data-total'), 10) || 0;
    var upd = function () {
      if (mode.value === 'percent') { val.max = 100; val.placeholder = 'percentuale (0-100)'; }
      else { if (total) { val.max = total; } else { val.removeAttribute('max'); } val.placeholder = total ? 'pagina (di ' + total + ')' : 'pagina'; }
    };
    mode.addEventListener('change', upd);
  });
})();

// Gli avvisi di conferma spariscono da soli
  var ok = document.querySelector('.alert.success');
  if (ok) { setTimeout(function () { ok.style.transition = 'opacity .6s'; ok.style.opacity = '0'; setTimeout(function () { ok.remove(); }, 650); }, 5000); }
})();
