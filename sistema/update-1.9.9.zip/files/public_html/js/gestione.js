/* Pannello Gestione: anteprima dal vivo dell'aspetto, copertine mancanti */
(function () {
  'use strict';
  var root = document.documentElement;
  // Le variabili vanno applicate alla pagina e, se presente, all'anteprima del sito accanto ai controlli
  var frame = document.querySelector('[data-theme-preview]');
  var setVar = function (name, value) {
    root.style.setProperty(name, value);
    try {
      if (frame && frame.contentDocument) { frame.contentDocument.documentElement.style.setProperty(name, value); }
    } catch (e) { /* anteprima non ancora pronta */ }
  };

  // Colori: il selettore e il codice esadecimale restano allineati e l'anteprima e' immediata
  document.querySelectorAll('input[type=color][data-var]').forEach(function (c) {
    var hex = document.querySelector('[data-hex-for="' + c.id + '"]');
    var apply = function () {
      setVar('--' + c.getAttribute('data-var'), c.value);
      if (hex) { hex.value = c.value.toUpperCase(); }
    };
    c.addEventListener('input', apply);
    if (hex) {
      hex.addEventListener('input', function () {
        var v = hex.value.trim();
        if (/^#?[0-9a-fA-F]{6}$/.test(v)) { c.value = (v[0] === '#' ? v : '#' + v).toLowerCase(); apply(); }
      });
    }
  });

  var radius = document.querySelector('[data-range-var="radius"]');
  if (radius) {
    radius.addEventListener('input', function () {
      setVar('--radius', radius.value + 'px');
      setVar('--radius-s', Math.max(2, Math.round(radius.value * 0.6)) + 'px');
      setVar('--radius-pill', radius.value >= 12 ? '999px' : Math.max(3, radius.value) + 'px');
      var lab = document.querySelector('[data-radius-val]');
      if (lab) { lab.textContent = radius.value; }
    });
  }

  document.querySelectorAll('[data-font-select]').forEach(function (s) {
    s.addEventListener('change', function () {
      var opt = s.options[s.selectedIndex], stack = opt.getAttribute('data-stack');
      if (stack) { setVar(s.name === 'font_head' ? '--head' : '--body', stack); }
    });
  });

  // L'anteprima appena caricata riceve i valori non ancora salvati
  if (frame) {
    frame.addEventListener('load', function () {
      document.querySelectorAll('input[type=color][data-var]').forEach(function (c) { setVar('--' + c.getAttribute('data-var'), c.value); });
      document.querySelectorAll('[data-font-select]').forEach(function (s) {
        var st = s.options[s.selectedIndex].getAttribute('data-stack');
        if (st) { setVar(s.name === 'font_head' ? '--head' : '--body', st); }
      });
      if (radius) { radius.dispatchEvent(new Event('input')); }
    });
    document.querySelectorAll('[data-preview-go]').forEach(function (a) {
      a.addEventListener('click', function (e) { e.preventDefault(); frame.src = a.getAttribute('data-preview-go'); });
    });
  }

  // Copertine mancanti: si scaricano a piccoli gruppi per non bloccare il server
  var fill = document.querySelector('[data-fill-covers]');
  if (fill && fill.querySelector('[data-fill-start]')) {
    var btn = fill.querySelector('[data-fill-start]');
    var bar = fill.querySelector('.progress');
    var sub = fill.querySelector('.sub');
    var total = 0, found = 0;
    btn.addEventListener('click', function () {
      btn.disabled = true;
      bar.hidden = false;
      var step = function () {
        window.App.post('fill_covers').then(function (r) {
          if (!r.ok) { sub.textContent = r.error || 'Errore.'; btn.disabled = false; return; }
          if (!total) { total = r.left + r.checked; }
          found += r.done;
          var doneCount = total - r.left;
          bar.querySelector('i').style.width = Math.round(doneCount / Math.max(1, total) * 100) + '%';
          sub.textContent = 'Controllati ' + doneCount + ' di ' + total + ' · copertine trovate: ' + found;
          if (r.left > 0 && r.checked > 0) { step(); } else { btn.textContent = 'Fatto'; }
        }).catch(function () { sub.textContent = 'Connessione interrotta: riprova.'; btn.disabled = false; });
      };
      step();
    });
  }
})();
