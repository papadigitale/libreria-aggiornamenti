<?php
/* Pagine del sito create in Gestione → Sezioni → Pagine */
define('PAGE_EXTERNAL_IMAGES', true); // nelle pagine si possono mostrare immagini prese dal web
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/extras.php';
require_login();

$p = page_by_slug(get('p'));
$preview = can_edit() && get('anteprima') === '1';
if (!$p || ((int)$p['active'] !== 1 && !$preview) || (is_guest() && (int)$p['guests'] !== 1)) {
    flash('Pagina non trovata.', 'error');
    redirect('libreria.php');
}
$show_title = !isset($p['show_title']) || (int)$p['show_title'] === 1;
page_start($p['title'], 'pagina', array('back' => 'libreria.php'));
if (!empty($p['css'])) {
    echo '<style>' . page_css_clean($p['css']) . '</style>';
}
?>
<?php if ((int)$p['active'] !== 1): ?><div class="alert warn">Anteprima: questa pagina non è ancora pubblicata.</div><?php endif; ?>
<article class="page-body page-<?= h($p['slug']) ?> <?= isset($p['format']) && $p['format'] === 'html' ? 'is-html' : 'card' ?>">
  <?php if ($show_title): ?><h1 class="h1"><?= h($p['title']) ?></h1><?php endif; ?>
  <?= page_render($p) ?>
</article>
<?php if (can_edit() && get('embed') !== '1'): ?>
<p class="meta"><a class="link" href="gestione.php?sez=pagina&amp;id=<?= (int)$p['id'] ?>"><?= icon('edit', 14) ?> Modifica questa pagina</a></p>
<?php endif; ?>
<?php page_end(); ?>
