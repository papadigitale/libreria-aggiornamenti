<?php
// Controllo di salute per Docker (HEALTHCHECK): non usa il database
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');
echo "ok\n";
