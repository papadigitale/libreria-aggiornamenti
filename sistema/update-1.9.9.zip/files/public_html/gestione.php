<?php
/*
 * Pannello di gestione.
 *  Admin   : tutte le sezioni.
 *  Gestore : Panoramica, Generi, Dati e backup, Ricerca online.
 *            NON vede Aspetto, Testi, Utenti, Sicurezza (controllo accessi), Log, Sistema.
 * I permessi sono controllati sul server, non solo nascondendo i menu.
 */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/books.php';
require_once APP_ROOT . '/inc/data_tools.php';
require_once APP_ROOT . '/inc/auth.php';
require_once APP_ROOT . '/inc/g_common.php';
require_once APP_ROOT . '/inc/admin_layout.php';
require_editor();

$sez = get('sez');
if ($sez === '' && get('tab') !== '') {
    $sez = get('tab'); // indirizzi della versione precedente (gestione.php?sez=...)
}
$legacy = array('panoramica' => 'bacheca');
if (isset($legacy[$sez])) {
    $sez = $legacy[$sez];
}
$sections = admin_sections();
if (!isset($sections[$sez])) {
    $sez = 'bacheca';
}
if (!admin_section_allowed($sez)) {
    app_log('accesso_negato', 'Il gestore ha tentato di aprire la sezione "' . $sez . '"', 'warn');
    flash('Questa sezione è riservata all\'amministratore.', 'error');
    redirect('gestione.php');
}
$tab = $sez; // compatibilita' con i pannelli della versione precedente

/* ---------- Entrati con un dispositivo ricordato: le sezioni delicate chiedono di nuovo la password (1.9.3) ---------- */
if (is_file(APP_ROOT . '/inc/remember.php')) {
    require_once APP_ROOT . '/inc/remember.php';
    if (remember_needs_reauth()) {
        $re_sez = in_array($sez, remember_sensitive_sections(), true) || strpos($sez, 'plg-') === 0;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            check_csrf();
            $ra = post('action');
            if ($ra === 'riconferma') {
                require_once APP_ROOT . '/inc/auth.php';
                $me = current_user();
                $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
                $st->execute(array(current_uid()));
                $ip = client_ip();
                if (login_lock_remaining($ip, $me['username']) > 0) {
                    flash('Troppi tentativi errati: riprova più tardi.', 'error');
                } elseif (password_verify(isset($_POST['password']) ? (string)$_POST['password'] : '', (string)$st->fetchColumn())) {
                    $_SESSION['pw_ok_at'] = time();
                    app_log('password_riconfermata', 'Password confermata per le sezioni delicate (dispositivo ricordato)', 'info');
                } else {
                    record_attempt($ip, $me['username'], false);
                    if (function_exists('fw_after_failed_login')) {
                        fw_after_failed_login($ip, $me['username'], true);
                    }
                    app_log('password_errata', 'Conferma della password non riuscita (dispositivo ricordato)', 'warn');
                    flash('Password non corretta.', 'error');
                }
                redirect('gestione.php?sez=' . rawurlencode($sez));
            }
            $grp = post('group');
            if ($re_sez || preg_match('/^(upd_|plg_|repo_|key_|pub_|user_|fw_|rt_|backup_restore|backup_delete|autobackup_save|maint_|unlock|log_purge|trash_empty|trash_purge|reset_group)/', $ra)
                || ($ra === 'settings' && in_array($grp, array('sicurezza', 'aspetto', 'testi'), true))) {
                flash('Per questa operazione conferma prima la tua password.', 'error');
                redirect('gestione.php?sez=' . rawurlencode($sez));
            }
        } elseif ($re_sez) {
            admin_start($sections[$sez][1], $sez, array('sub' => 'Sezione protetta'));
            echo '<div class="card reauth"><div class="ct">' . icon('lock', 18) . ' Conferma la tua password</div>'
               . '<p class="sub">Sei entrato con un dispositivo ricordato. Per aprire le sezioni delicate (aggiornamenti, plugin, utenti, sicurezza, backup) '
               . 'serve la password, una volta ogni 30 minuti.</p>'
               . '<form method="post" class="stack">' . csrf_field() . '<input type="hidden" name="action" value="riconferma">'
               . '<input type="hidden" name="username" value="' . h(current_user()['username']) . '" autocomplete="username">'
               . '<input class="input" type="password" name="password" required autocomplete="current-password" placeholder="La tua password" autofocus>'
               . '<button class="btn primary" type="submit">Conferma</button></form></div>';
            admin_end();
            exit;
        }
    }
}

/* ---------- Scaricamenti (GET) ---------- */
if (get('scarica') !== '') {
    $what = get('scarica');
    if ($what === 'csv' && admin_section_allowed('dati')) {
        app_log('csv_esportato', 'Esportazione elenco libri in CSV');
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="libreria_' . date('Y-m-d') . '.csv"');
        echo csv_export();
        exit;
    }
    if ($what === 'modello' && admin_section_allowed('dati')) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="modello_importazione.csv"');
        echo "\xEF\xBB\xBF" . implode(';', array_values(csv_columns())) . "\r\n9788845292613;Il nome della rosa;;Umberto Eco;Bompiani;2012;624;Romanzo;Salotto;it;\r\n";
        exit;
    }
    if ($what === 'backup' && admin_section_allowed('dati') && backup_allowed(get('f')) && is_file(BACKUP_DIR . '/' . get('f'))) {
        app_log('backup_scaricato', get('f'));
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . get('f') . '"');
        header('Content-Length: ' . filesize(BACKUP_DIR . '/' . get('f')));
        readfile(BACKUP_DIR . '/' . get('f'));
        exit;
    }
    if ($what === 'log' && is_admin()) {
        $rows = db()->query('SELECT created_at, level, action, username, ip, detail FROM logs ORDER BY id DESC LIMIT 20000')->fetchAll();
        app_log('log_esportati', 'Esportazione log in CSV');
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="log_' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, array('Data', 'Livello', 'Azione', 'Utente', 'IP', 'Dettaglio'), ';', '"', '');
        foreach ($rows as $r) {
            fputcsv($out, array_values($r), ';', '"', '');
        }
        exit;
    }
    flash('File non disponibile.', 'error');
    redirect('gestione.php?sez=' . $tab);
}

/* ---------- Salvataggio impostazioni ---------- */
function save_settings_group($group)
{
    $defs = setting_defaults();
    $changed = array();
    foreach ($defs as $key => $d) {
        if ($d[0] !== $group || in_array($d[3], array('hidden'), true)) {
            continue;
        }
        $type = $d[3];
        if ($type === 'bool') {
            $val = isset($_POST[$key]) && $_POST[$key] === '1' ? '1' : '0';
        } else {
            if (!isset($_POST[$key]) || !is_string($_POST[$key])) {
                continue;
            }
            $val = $type === 'code' ? (string)$_POST[$key] : trim($_POST[$key]);
            if ($type === 'color') {
                if (!preg_match('/^#[0-9a-fA-F]{6}$/', $val)) {
                    continue;
                }
                $val = strtolower($val);
            } elseif ($type === 'number') {
                $val = (string)max(0, min(100000, (int)$val));
            } elseif ($type === 'select') {
                if (!isset($d[4][$val])) {
                    continue;
                }
            } elseif ($type === 'font') {
                if (!isset(font_options()[$val])) {
                    continue;
                }
            } elseif ($type === 'textarea') {
                $val = str_cut($val, 5000);
            } elseif ($type === 'code') {
                $val = str_cut($val, 30000);
            } else {
                $val = str_cut($val, 500);
            }
        }
        if ($val !== setting($key)) {
            setting_save($key, $val);
            $changed[] = $key;
        }
    }
    load_settings(true);
    return $changed;
}

function store_upload_image($file, $prefix, $maxw)
{
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK || $file['size'] > 15 * 1024 * 1024) {
        return array(false, 'Caricamento non riuscito (massimo 15 MB).');
    }
    $bin = file_get_contents($file['tmp_name']);
    $info = @getimagesizefromstring($bin);
    if (!$info || !in_array($info[2], array(IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, defined('IMAGETYPE_WEBP') ? IMAGETYPE_WEBP : -1), true)) {
        return array(false, 'Il file deve essere un\'immagine JPG, PNG o WEBP.');
    }
    if (!is_dir(UPLOADS_DIR)) {
        @mkdir(UPLOADS_DIR, 0775, true);
    }
    $png = $info[2] === IMAGETYPE_PNG || $info[2] === IMAGETYPE_GIF;
    $name = $prefix . '_' . substr(random_token(6), 0, 10) . ($png ? '.png' : '.jpg');
    if (function_exists('imagecreatefromstring')) {
        $src = @imagecreatefromstring($bin);
        if (!$src) {
            return array(false, 'Immagine non leggibile.');
        }
        $w = imagesx($src);
        $hh = imagesy($src);
        $nw = min($w, $maxw);
        $nh = (int)round($hh * $nw / $w);
        $dst = imagecreatetruecolor($nw, $nh);
        if ($png) {
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
        }
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $hh);
        $ok = $png ? imagepng($dst, UPLOADS_DIR . '/' . $name, 7) : imagejpeg($dst, UPLOADS_DIR . '/' . $name, 85);
        img_free($src);
        img_free($dst);
    } else {
        $ok = $info[2] !== IMAGETYPE_GIF && file_put_contents(UPLOADS_DIR . '/' . $name, $bin) !== false;
    }
    return $ok ? array(true, $name) : array(false, 'Impossibile salvare: la cartella data/uploads non è scrivibile.');
}

function remove_upload($name)
{
    if ($name !== '' && preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $name) && is_file(UPLOADS_DIR . '/' . $name)) {
        @unlink(UPLOADS_DIR . '/' . $name);
    }
}

$test_result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $a = post('action');
    $back = 'gestione.php?sez=' . $sez;

    /* --- Impostazioni (gruppo protetto per ruolo) --- */
    if ($a === 'settings') {
        $group = post('group');
        $need_admin = in_array($group, array('aspetto', 'testi', 'sicurezza'), true);
        if (!in_array($group, array('aspetto', 'testi', 'sicurezza', 'ricerca'), true) || ($need_admin && !is_admin())) {
            app_log('accesso_negato', 'Tentativo di modificare le impostazioni "' . $group . '"', 'alert');
            deny_page('Operazione non consentita.');
        }
        if ($group === 'sicurezza') {
            $rules = isset($_POST['sec_ip_allow']) ? (string)$_POST['sec_ip_allow'] : '';
            if (!ip_allowed(client_ip(), $rules)) {
                flash('Il tuo indirizzo attuale (' . client_ip() . ') non è nell\'elenco degli IP ammessi: aggiungilo, altrimenti verresti chiuso fuori.', 'error');
                redirect($back);
            }
        }
        $changed = save_settings_group($group);
        if ($group === 'aspetto') {
            if (isset(icon_styles()[post('icon_style')]) && post('icon_style') !== setting('icon_style', 'classiche')) {
                setting_save('icon_style', post('icon_style'));
                $changed[] = 'icon_style';
            }
            $acc = post('icon_accent') === '1' ? '1' : '0';
            if ($acc !== setting('icon_accent', '0')) {
                setting_save('icon_accent', $acc);
                $changed[] = 'icon_accent';
            }
            // "oppure scegli da Media": l'immagine scelta si usa come se fosse stata caricata qui (ne viene fatta una copia)
            if ((int)setting('db_version', '1') >= 10) {
                require_once APP_ROOT . '/inc/media.php';
                foreach (array('logo_media' => 'logo', 'bg_media' => 'bg_file', 'app_icon_media' => 'app_icon') as $mk => $fk) {
                    $mf = (int)post($mk) > 0 ? media_as_upload_file((int)post($mk)) : null;
                    if ($mf && (!isset($_FILES[$fk]) || $_FILES[$fk]['error'] === UPLOAD_ERR_NO_FILE)) {
                        $_FILES[$fk] = $mf;
                    }
                }
            }
            if (isset($_FILES['logo']) && $_FILES['logo']['error'] !== UPLOAD_ERR_NO_FILE) {
                $r = store_upload_image($_FILES['logo'], 'logo', 512);
                if ($r[0]) {
                    remove_upload(setting('logo_file'));
                    setting_save('logo_file', $r[1]);
                    $changed[] = 'logo_file';
                } else {
                    flash($r[1], 'error');
                    redirect($back);
                }
            }
            if (isset($_FILES['bg_file']) && $_FILES['bg_file']['error'] !== UPLOAD_ERR_NO_FILE) {
                $r = store_upload_image($_FILES['bg_file'], 'sfondo', 1920);
                if ($r[0]) {
                    remove_upload(setting('bg_image'));
                    setting_save('bg_image', $r[1]);
                    setting_save('bg_type', 'image');
                    $changed[] = 'bg_image';
                } else {
                    flash($r[1], 'error');
                    redirect($back);
                }
            }
            if (isset($_FILES['app_icon']) && $_FILES['app_icon']['error'] !== UPLOAD_ERR_NO_FILE) {
                $r = store_upload_image($_FILES['app_icon'], 'appicona', 1024);
                if ($r[0]) {
                    remove_upload(setting('app_icon_file'));
                    setting_save('app_icon_file', $r[1]);
                    $changed[] = 'app_icon_file';
                } else {
                    flash($r[1], 'error');
                    redirect($back);
                }
            }
            if (post('remove_app_icon') === '1') {
                remove_upload(setting('app_icon_file'));
                setting_save('app_icon_file', '');
                $changed[] = 'app_icon_file';
            }
            if (post('remove_logo') === '1') {
                remove_upload(setting('logo_file'));
                setting_save('logo_file', '');
                $changed[] = 'logo_file';
            }
            if (post('theme_preset_custom') === '1' && $changed) {
                setting_save('theme_preset', 'personalizzato');
            }
        }
        app_log('impostazioni', 'Sezione ' . $group . ': ' . ($changed ? implode(', ', $changed) : 'nessuna modifica'), $group === 'sicurezza' ? 'warn' : 'info');
        flash($changed ? 'Impostazioni salvate.' : 'Nessuna modifica da salvare.');
        redirect($back);
    }

    if ($a === 'preset' && is_admin()) {
        $presets = theme_presets();
        $p = post('preset');
        if (isset($presets[$p])) {
            foreach ($presets[$p][1] as $k => $v) {
                setting_save($k, $v);
            }
            setting_save('theme_preset', $p);
            app_log('impostazioni', 'Applicato lo stile "' . $presets[$p][0] . '"');
            flash('Stile "' . $presets[$p][0] . '" applicato. Puoi ritoccare ogni dettaglio qui sotto.');
        }
        redirect($back);
    }

    if ($a === 'reset_group' && is_admin() && in_array(post('group'), array('aspetto', 'testi'), true)) {
        $g = post('group');
        foreach (setting_defaults() as $k => $d) {
            if ($d[0] === $g && !in_array($k, array('logo_file', 'bg_image'), true)) {
                db()->prepare('DELETE FROM settings WHERE setting_key = ?')->execute(array($k));
            }
        }
        app_log('impostazioni', 'Ripristinati i valori predefiniti della sezione ' . $g, 'warn');
        flash('Valori predefiniti ripristinati.');
        redirect($back);
    }

    if ($a === 'remove_bg' && is_admin()) {
        remove_upload(setting('bg_image'));
        setting_save('bg_image', '');
        setting_save('bg_type', 'solid');
        flash('Immagine di sfondo rimossa.');
        redirect($back);
    }

    /* --- Generi --- */
    if ($a === 'cat_add' || $a === 'cat_save' || $a === 'cat_del') {
        $name = str_cut(post('name'), 100);
        try {
            if ($a === 'cat_add' && $name !== '') {
                db()->prepare('INSERT INTO categories (name, sort_order) VALUES (?, ?)')->execute(array($name, (int)post('sort_order', '500')));
                app_log('genere_aggiunto', $name);
                flash('Genere "' . $name . '" aggiunto.');
            } elseif ($a === 'cat_save' && $name !== '') {
                db()->prepare('UPDATE categories SET name = ?, sort_order = ? WHERE id = ?')->execute(array($name, (int)post('sort_order'), (int)post('id')));
                app_log('genere_modificato', $name);
                flash('Genere aggiornato.');
            } elseif ($a === 'cat_del') {
                db()->prepare('UPDATE books SET category_id = NULL WHERE category_id = ?')->execute(array((int)post('id')));
                db()->prepare('UPDATE wheel_settings SET category_id = NULL WHERE category_id = ?')->execute(array((int)post('id')));
                db()->prepare('DELETE FROM categories WHERE id = ?')->execute(array((int)post('id')));
                app_log('genere_eliminato', '#' . (int)post('id'), 'warn');
                flash('Genere eliminato (i libri restano, senza genere).');
            }
        } catch (PDOException $e) {
            flash('Esiste già un genere con questo nome.', 'error');
        }
        redirect('gestione.php?sez=generi');
    }

    /* --- Dati e backup --- */
    if ($a === 'backup_create') {
        $full = post('full') === '1' && is_admin();
        $f = backup_create('', $full);
        app_log('backup_creato', $f . ($full ? ' (completo: anche utenti e impostazioni)' : ''), $full ? 'warn' : 'info');
        flash(($full ? 'Backup completo creato: ' : 'Backup creato: ') . $f);
        redirect('gestione.php?sez=dati');
    }
    if ($a === 'backup_delete' && backup_allowed(post('f'))) {
        @unlink(BACKUP_DIR . '/' . post('f'));
        app_log('backup_eliminato', post('f'), 'warn');
        flash('Backup eliminato.');
        redirect('gestione.php?sez=dati');
    }
    if ($a === 'backup_restore') {
        $path = '';
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
            if (!backup_dir_ready()) {
                throw new Exception('La cartella data/backup non è scrivibile.');
            }
            $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION)) === 'json' ? 'json' : 'zip';
            $name = 'libreria_' . date('Ymd_His') . '_caricato_' . substr(random_token(2), 0, 4) . '.' . $ext;
            move_uploaded_file($_FILES['file']['tmp_name'], BACKUP_DIR . '/' . $name);
            if (backup_is_full(BACKUP_DIR . '/' . $name)) {
                // contiene gli account: il nome lo dice, cosi' resta visibile solo all'Admin
                $full_name = preg_replace('/\.(zip|json)$/', '_completo.$1', $name);
                rename(BACKUP_DIR . '/' . $name, BACKUP_DIR . '/' . $full_name);
                $name = $full_name;
            }
            $path = BACKUP_DIR . '/' . $name;
        } elseif (backup_allowed(post('f'))) {
            $path = BACKUP_DIR . '/' . post('f');
        }
        if ($path === '' || !is_file($path)) {
            flash('Scegli un file di backup.', 'error');
            redirect('gestione.php?sez=dati');
        }
        $safety = backup_create('prima'); // copia di sicurezza dello stato attuale prima di sovrascrivere
        try {
            $n = backup_restore($path, post('with_users') === '1' && is_admin());
        } catch (Exception $e) {
            flash('Ripristino non eseguito: ' . $e->getMessage(), 'error');
            redirect('gestione.php?sez=dati');
        }
        app_log('backup_ripristinato', basename($path) . ' (' . $n . ' libri). Copia di sicurezza: ' . $safety, 'alert');
        flash('Ripristino completato: ' . $n . ' libri. Prima del ripristino è stata salvata una copia: ' . $safety);
        redirect('gestione.php?sez=dati');
    }
    if ($a === 'csv_import') {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            flash('Scegli un file CSV.', 'error');
            redirect('gestione.php?sez=dati');
        }
        try {
            list($added, $skipped, $errors) = csv_import($_FILES['file']['tmp_name'], post('skip_dup') === '1');
        } catch (Exception $e) {
            flash($e->getMessage(), 'error');
            redirect('gestione.php?sez=dati');
        }
        app_log('csv_importato', $added . ' libri aggiunti, ' . $skipped . ' doppioni saltati, ' . count($errors) . ' errori');
        $msg = 'Importazione: ' . $added . ' libri aggiunti, ' . $skipped . ' già presenti saltati.';
        if ($errors) {
            $msg .= ' Righe con problemi: ' . implode(' | ', array_slice($errors, 0, 5)) . (count($errors) > 5 ? ' …' : '');
        }
        flash($msg . ($added ? ' Puoi completare le copertine da "Panoramica".' : ''), $errors ? 'warn' : 'success');
        redirect('gestione.php?sez=dati');
    }

    /* --- Ricerca online: prova --- */
    if ($a === 'test_lookup') {
        require_once APP_ROOT . '/inc/lookup.php';
        $isbn = post('isbn') !== '' ? post('isbn') : '9788845292613';
        $t0 = microtime(true);
        $test_result = lookup_isbn($isbn, true);
        $test_result['ms'] = (int)((microtime(true) - $t0) * 1000);
    }

    /* --- Utenti (solo Admin) --- */
    if (in_array($a, array('user_add', 'user_save', 'user_pw', 'user_2fa_off', 'user_pk_off', 'user_del'), true)) {
        if (!is_admin()) {
            app_log('accesso_negato', 'Tentativo di gestire utenti', 'alert');
            deny_page('Operazione non consentita.');
        }
        $id = (int)post('id');
        $admins = (int)db()->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1")->fetchColumn();
        $target = null;
        if ($id) {
            $st = db()->prepare('SELECT * FROM users WHERE id = ?');
            $st->execute(array($id));
            $target = $st->fetch();
            if (!$target) {
                redirect('gestione.php?sez=utenti');
            }
        }
        if ($a === 'user_add') {
            $username = strtolower(post('username'));
            $pw = isset($_POST['password']) ? (string)$_POST['password'] : '';
            $role = in_array(post('role'), user_roles(), true) ? post('role') : 'gestore';
            if (!preg_match('/^[a-z0-9._\-]{3,60}$/', $username)) {
                flash('Nome utente non valido: 3-60 caratteri tra lettere minuscole, numeri, punto, trattino.', 'error');
            } elseif (($p = password_problem($pw, $username)) !== '') {
                flash($p, 'error');
            } elseif (users_email_ready() && ($p = email_problem(post('email'))) !== '') {
                flash($p, 'error');
            } else {
                try {
                    db()->prepare('INSERT INTO users (username, display_name, password_hash, role, active, must_change_pw, created_at, updated_at) VALUES (?,?,?,?,1,?,?,?)')
                        ->execute(array($username, str_cut(post('display_name'), 100), pw_hash($pw), $role,
                            post('must_change') === '1' ? 1 : 0, now(), now()));
                    if (users_email_ready() && trim(post('email')) !== '') {
                        db()->prepare('UPDATE users SET email = ? WHERE username = ?')->execute(array(trim(post('email')), $username));
                    }
                    app_log('utente_creato', '"' . $username . '" con ruolo ' . $role, 'warn');
                    flash('Utente "' . $username . '" creato.');
                } catch (PDOException $e) {
                    flash('Esiste già un utente con questo nome.', 'error');
                }
            }
        } elseif ($a === 'user_save') {
            $role = in_array(post('role'), user_roles(), true) ? post('role') : 'gestore';
            $active = post('active') === '1' ? 1 : 0;
            if ($id === current_uid() && ($role !== 'admin' || !$active)) {
                flash('Non puoi togliere a te stesso il ruolo di Admin o disattivarti.', 'error');
            } elseif ($target['role'] === 'admin' && ($role !== 'admin' || !$active) && $admins <= 1) {
                flash('Deve restare almeno un Admin attivo.', 'error');
            } elseif (users_email_ready() && ($p = email_problem(post('email'))) !== '') {
                flash($p, 'error');
            } else {
                if (users_email_ready()) {
                    db()->prepare('UPDATE users SET email = ?, email_notify = ? WHERE id = ?')
                        ->execute(array(trim(post('email')) === '' ? null : trim(post('email')), post('email_notify') === '1' ? 1 : 0, $id));
                }
                db()->prepare('UPDATE users SET display_name = ?, role = ?, active = ?, updated_at = ? WHERE id = ?')
                    ->execute(array(str_cut(post('display_name'), 100), $role, $active, now(), $id));
                app_log('utente_modificato', '"' . $target['username'] . '": ruolo ' . $role . ', ' . ($active ? 'attivo' : 'disattivato'), 'warn');
                flash('Utente aggiornato.');
            }
        } elseif ($a === 'user_pw') {
            $pw = isset($_POST['password']) ? (string)$_POST['password'] : '';
            if (($p = password_problem($pw, $target['username'])) !== '') {
                flash($p, 'error');
            } else {
                db()->prepare('UPDATE users SET password_hash = ?, must_change_pw = 1, updated_at = ? WHERE id = ?')
                    ->execute(array(pw_hash($pw), now(), $id));
                db()->prepare('DELETE FROM login_attempts WHERE username = ? AND success = 0')->execute(array($target['username']));
                if ((int)setting('db_version', '1') >= 13) {
                    db()->prepare('DELETE FROM user_devices WHERE user_id = ?')->execute(array($id));
                }
                app_log('password_reimpostata', 'Password temporanea per "' . $target['username'] . '"', 'warn');
                flash('Password temporanea impostata: al prossimo accesso "' . $target['username'] . '" dovrà cambiarla.');
            }
        } elseif ($a === 'user_pk_off' && (int)setting('db_version', '1') >= 9) {
            db()->prepare('DELETE FROM user_passkeys WHERE user_id = ?')->execute(array($id));
            app_log('passkey_azzerate', 'Chiavi di accesso eliminate per "' . $target['username'] . '"', 'warn');
            flash('Chiavi di accesso eliminate per "' . $target['username'] . '".');
        } elseif ($a === 'user_2fa_off') {
            db()->prepare('UPDATE users SET totp_secret = NULL, totp_enabled = 0, updated_at = ? WHERE id = ?')->execute(array(now(), $id));
            app_log('2fa_azzerata', 'Verifica in due passaggi azzerata per "' . $target['username'] . '"', 'warn');
            flash('Verifica in due passaggi disattivata per "' . $target['username'] . '".');
        } elseif ($a === 'user_del') {
            if ($id === current_uid()) {
                flash('Non puoi eliminare il tuo stesso account.', 'error');
            } elseif ($target['role'] === 'admin' && $admins <= 1) {
                flash('Deve restare almeno un Admin.', 'error');
            } else {
                db()->prepare('UPDATE books SET created_by = NULL WHERE created_by = ?')->execute(array($id));
                db()->prepare('DELETE FROM users WHERE id = ?')->execute(array($id));
                app_log('utente_eliminato', '"' . $target['username'] . '"', 'alert');
                flash('Utente "' . $target['username'] . '" eliminato (la libreria non cambia, la sua ruota e i suoi stati sì).');
            }
        }
        redirect('gestione.php?sez=utenti');
    }

    /* --- Sicurezza: sblocco --- */
    if ($a === 'unlock' && is_admin()) {
        $k = post('key');
        $v = post('value');
        if ($k === 'ip') {
            db()->prepare('DELETE FROM login_attempts WHERE ip = ? AND success = 0')->execute(array($v));
        } elseif ($k === 'username') {
            db()->prepare('DELETE FROM login_attempts WHERE username = ? AND success = 0')->execute(array($v));
        }
        app_log('sblocco_accessi', $k . ' ' . $v, 'warn');
        flash('Sbloccato: ' . $v);
        redirect('gestione.php?sez=sicurezza');
    }

    /* --- Sezioni nuove (etichette, campi, home, pagine, libri, utenti, aggiornamento) --- */
    require_once APP_ROOT . '/inc/admin_actions.php';
    admin_handle_post($a, $sez);

    /* --- Log: pulizia --- */
    if ($a === 'log_purge' && is_admin()) {
        $days = max(1, (int)post('days'));
        $st = db()->prepare('DELETE FROM logs WHERE created_at < ?');
        $st->execute(array(date('Y-m-d H:i:s', time() - $days * 86400)));
        app_log('log_puliti', 'Eliminati i log più vecchi di ' . $days . ' giorni (' . $st->rowCount() . ' righe)', 'warn');
        flash('Eliminate ' . $st->rowCount() . ' righe di log.');
        redirect('gestione.php?sez=log');
    }
}

$sub = array(
    'bacheca' => 'Il riepilogo della libreria e di ciò che c\'è da sistemare',
    'libri' => 'Cerca, filtra e modifica più libri insieme',
    'copertine' => 'Copertine salvate, mancanti e file non più usati',
    'prestiti' => 'A chi hai prestato i libri e quando devono tornare',
    'cestino' => 'Libri eliminati, recuperabili per un certo numero di giorni',
    'doppioni' => 'Libri inseriti più volte: scegli quale tenere e unisci gli altri',
    'generi' => 'Il genere di ogni libro: aggiungi, rinomina, unisci e ordina',
    'etichette' => 'Crea nuove etichette oltre al Genere (es. Collana, Formato, Scaffale)',
    'campi' => 'Campi aggiuntivi nella scheda di ogni libro',
    'home' => 'Le righe della pagina iniziale e il loro ordine',
    'pagine' => 'Pagine di testo raggiungibili dal sito',
    'aspetto' => 'Colori, caratteri, sfondo e logo, con anteprima dal vivo',
    'testi' => 'Titoli e testi che compaiono nel sito',
    'utenti' => 'Account, ruoli, password e sessioni',
    'sicurezza' => 'Controllo accessi, blocchi e verifica in due passaggi',
    'dati' => 'Copie di sicurezza, ripristino, importazione ed esportazione',
    'ricerca' => 'Le piattaforme da cui arrivano dati e copertine',
    'destinazioni' => 'Copie dei backup su NAS, server SFTP/FTP, Nextcloud, Google Drive o Dropbox',
    'sistema' => 'Controlli tecnici del server',
    'log' => 'Accessi, modifiche e tentativi negati',
    'aggiornamento' => 'Installa una nuova versione caricando il file update.zip',
    'pulsanti' => 'I pulsanti sotto la barra di ricerca della Libreria: quali, in che ordine e con che nome',
    'controllo' => 'Lo stato della sicurezza del sito, con i consigli per migliorarla',
    'plugin' => 'Funzioni aggiuntive firmate dall\'autore del sito',
);
$title = $sections[$sez][1];
$opts = array('sub' => isset($sub[$sez]) ? $sub[$sez] : '', 'id' => (int)get('id'));
$panel = APP_ROOT . '/inc/' . $sections[$sez][3];
if ($sez === 'etichetta') {
    $TAX = taxonomy_get((int)get('id'));
    if (!$TAX) {
        flash('Etichetta non trovata.', 'error');
        redirect('gestione.php?sez=etichette');
    }
    $title = $TAX['name'];
    $opts['sub'] = 'Valori dell\'etichetta: aggiungi, rinomina, unisci e ordina';
} elseif ($sez === 'libro') {
    $BOOK = book_get((int)get('id'));
    if (!$BOOK) {
        flash('Libro non trovato.', 'error');
        redirect('gestione.php?sez=libri');
    }
    $title = $BOOK['title'];
    $opts['sub'] = 'Modifica dei dati del libro';
    $opts['actions'] = '<a class="adm-tbtn ghost" href="libro.php?id=' . (int)$BOOK['id'] . '" target="_blank" rel="noopener">' . admin_icon('ext', 15) . '<span>Apri la scheda</span></a>';
} elseif ($sez === 'pagina') {
    $PAGE = null;
    if ((int)get('id') > 0) {
        $st = db()->prepare('SELECT * FROM pages WHERE id = ?');
        $st->execute(array((int)get('id')));
        $PAGE = $st->fetch();
        if (!$PAGE) {
            flash('Pagina non trovata.', 'error');
            redirect('gestione.php?sez=pagine');
        }
    }
    $title = $PAGE ? $PAGE['title'] : 'Nuova pagina';
    $opts['sub'] = 'Testo con formattazione semplice: titoli, grassetto, elenchi e collegamenti';
} elseif ($sez === 'pagine') {
    $opts['actions'] = '<a class="adm-tbtn" href="gestione.php?sez=pagina">' . icon('plus', 16) . '<span>Nuova pagina</span></a>';
} elseif ($sez === 'libri') {
    $opts['wide'] = true;
    $opts['actions'] = '<details class="adm-export"><summary class="adm-tbtn ghost">' . icon('data', 16) . '<span>Esporta la libreria</span></summary>'
        . '<form method="post" action="gestione.php?sez=libri" class="adm-export-box">' . csrf_field() . '<input type="hidden" name="action" value="books_export">'
        . '<b>Tutti i libri, con la copertina</b>'
        . '<label class="lab">Formato</label><select class="input" name="ex_format"><option value="xlsx">Excel (.xlsx)</option><option value="pdf">PDF</option></select>'
        . '<label class="lab">Ordine</label><select class="input" name="ex_order"><option value="autore">per autore</option><option value="titolo">per titolo</option></select>'
        . '<button class="btn primary small" type="submit">Scarica</button>'
        . '<small class="muted">Per esportare solo alcuni libri: selezionali (anche con un filtro) e scegli "Esporta in Excel o PDF".</small></form></details>';
}
admin_start($title, $sez, $opts);
include $panel;
admin_end($sez === 'libro' ? array('js/gestione.js', 'js/libro.js') : array('js/gestione.js'));
