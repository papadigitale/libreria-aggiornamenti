<?php
require_once APP_ROOT . '/inc/security_check.php';
$checks = security_checks();
$cnt = array('ok' => 0, 'warn' => 0, 'bad' => 0);
foreach ($checks as $ch) {
    $cnt[$ch['lvl']]++;
}
$score = count($checks) ? round(($cnt['ok'] + $cnt['warn'] * 0.5) / count($checks) * 100) : 0;
$areas = array();
foreach ($checks as $ch) {
    $areas[$ch['area']][] = $ch;
}
?>
<div class="kpis">
  <div class="kpi"><b><?= (int)$score ?>%</b><span>punteggio</span></div>
  <div class="kpi"><b class="ok-text"><?= $cnt['ok'] ?></b><span>a posto</span></div>
  <div class="kpi"><b style="color:#c48a12"><?= $cnt['warn'] ?></b><span>da migliorare</span></div>
  <div class="kpi"><b class="err-text"><?= $cnt['bad'] ?></b><span>da sistemare</span></div>
</div>
<?php foreach ($areas as $area => $list): ?>
<div class="card">
  <div class="ct"><?= h($area) ?></div>
  <?php foreach ($list as $ch): ?>
  <div class="chk <?= h($ch['lvl']) ?>">
    <span class="chk-dot" aria-hidden="true"></span>
    <div><b><?= h($ch['title']) ?></b><small><?= h($ch['detail']) ?></small></div>
    <?php if ($ch['link'] !== '' && $ch['lvl'] !== 'ok'): ?><a class="link" href="gestione.php?sez=<?= h($ch['link']) ?>">Apri</a><?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>
<?php endforeach; ?>
<p class="hint">Il controllo si ripete ogni volta che apri questa pagina. Le date di fine supporto di PHP sono quelle ufficiali e si aggiornano con le nuove versioni della Libreria di Casa.</p>
