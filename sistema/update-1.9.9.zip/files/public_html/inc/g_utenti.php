<?php
$users = db()->query('SELECT * FROM users ORDER BY role, username')->fetchAll();
$suggest = substr(str_replace(array('+', '/', '='), '', base64_encode(random_bytes(12))), 0, 12);
?>
<div class="adm-grid2 wide-left"><div>
<div class="card">
  <div class="ct"><?= icon('user', 18) ?> Utenti</div>
  <p class="sub"><b>Admin</b>: controllo totale. <b>Gestore</b>: gestisce libri, generi, etichette, campi, sezioni, dati e backup, ma non aspetto,
    utenti, sicurezza, log e aggiornamenti. <b>Registrato</b>: usa solo il sito (consulta la libreria, segna letture e libri da leggere, ruota, sfide)
    e non entra nel pannello di gestione. La libreria è unica per tutti; stati di lettura e ruota sono personali.</p>
</div>
<?php foreach ($users as $usr): $me = (int)$usr['id'] === current_uid(); ?>
<details class="card user-card">
  <summary>
    <span class="avatar sm"><?= h(strtoupper(substr($usr['display_name'] !== '' ? $usr['display_name'] : $usr['username'], 0, 1))) ?></span>
    <span class="utext"><b><?= h($usr['display_name'] !== '' ? $usr['display_name'] : $usr['username']) ?><?= $me ? ' (tu)' : '' ?></b>
      <small><?= h($usr['username']) ?> · ultimo accesso <?= h(fmt_dt($usr['last_login_at'])) ?></small></span>
    <span class="tag <?= $usr['role'] === 'admin' ? 'reading' : '' ?>"><?= h(role_label($usr['role'])) ?></span>
    <?php if (!(int)$usr['active']): ?><span class="tag off">Disattivato</span><?php endif; ?>
    <?php if ((int)setting('db_version', '1') >= 9 && (int)db()->query('SELECT COUNT(*) FROM user_passkeys WHERE user_id = ' . (int)$usr['id'])->fetchColumn()): ?>
  <form method="post" data-confirm="Eliminare tutte le chiavi di accesso di questo utente (es. telefono o Bitwarden persi)? Potrà entrare con la password e crearne di nuove.">
    <?= csrf_field() ?><input type="hidden" name="action" value="user_pk_off"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
    <button class="btn ghost" type="submit">Elimina le chiavi di accesso (<?= (int)db()->query('SELECT COUNT(*) FROM user_passkeys WHERE user_id = ' . (int)$usr['id'])->fetchColumn() ?>)</button></form>
  <?php endif; ?>
  <?php if ((int)$usr['totp_enabled']): ?><span class="tag ok" title="Verifica in due passaggi attiva">2FA</span><?php endif; ?>
  </summary>
  <form method="post" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="user_save"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
    <label class="lab">Nome visualizzato</label>
    <input class="input" name="display_name" value="<?= h($usr['display_name']) ?>" maxlength="100">
    <?php if (users_email_ready()): ?>
    <label class="lab">Email</label>
    <input class="input" type="email" name="email" value="<?= h((string)$usr['email']) ?>" maxlength="190" placeholder="facoltativa: serve per le notifiche">
    <label class="check"><input type="checkbox" name="email_notify" value="1" <?= (int)$usr['email_notify'] ? 'checked' : '' ?>> Riceve le email del sito</label>
    <?php endif; ?>
    <label class="lab">Ruolo</label>
    <select class="input" name="role">
      <option value="registrato" <?= $usr['role'] === 'registrato' ? 'selected' : '' ?>>Registrato (solo il sito)</option>
      <option value="gestore" <?= $usr['role'] === 'gestore' ? 'selected' : '' ?>>Gestore</option>
      <option value="admin" <?= $usr['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
    </select>
    <label class="check"><input type="checkbox" name="active" value="1" <?= (int)$usr['active'] ? 'checked' : '' ?>> Account attivo (può accedere)</label>
    <button class="btn primary" type="submit">Salva</button>
  </form>
  <form method="post" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="user_pw"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
    <label class="lab">Nuova password temporanea (dovrà cambiarla al primo accesso)</label>
    <input class="input" name="password" value="<?= h($suggest) ?>" autocomplete="off">
    <button class="btn ghost" type="submit">Reimposta password</button>
  </form>
  <?php if ((int)$usr['totp_enabled']): ?>
  <form method="post" data-confirm="Disattivare la verifica in due passaggi per questo utente (es. telefono perso)?">
    <?= csrf_field() ?><input type="hidden" name="action" value="user_2fa_off"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
    <button class="btn ghost" type="submit">Azzera la verifica in due passaggi</button></form>
  <?php endif; ?>
  <form method="post" data-confirm="Chiudere tutte le sessioni aperte di &quot;<?= h($usr['username']) ?>&quot; (telefono, computer…)? Dovrà accedere di nuovo.">
    <?= csrf_field() ?><input type="hidden" name="action" value="user_logout_all"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
    <button class="btn ghost" type="submit"><?= icon('logout', 16) ?> Disconnetti da tutti i dispositivi<?php
      if ((int)setting('db_version', '1') >= 13) { $ndv = db()->prepare('SELECT COUNT(*) FROM user_devices WHERE user_id = ? AND expires_at > ?'); $ndv->execute(array((int)$usr['id'], now())); $ndv = (int)$ndv->fetchColumn(); echo $ndv ? ' (anche ' . $ndv . ' ricordat' . ($ndv === 1 ? 'o' : 'i') . ')' : ''; } ?></button></form>
  <?php if (!$me): ?>
  <form method="post" data-confirm="Eliminare definitivamente l'utente &quot;<?= h($usr['username']) ?>&quot;? Verranno cancellati i suoi stati di lettura e la sua ruota.">
    <?= csrf_field() ?><input type="hidden" name="action" value="user_del"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
    <button class="btn danger-ghost" type="submit"><?= icon('trash', 16) ?> Elimina utente</button></form>
  <?php endif; ?>
</details>
<?php endforeach; ?>
</div>
<form method="post" class="card stack">
  <?= csrf_field() ?><input type="hidden" name="action" value="user_add">
  <div class="ct">Nuovo utente</div>
  <label class="lab" for="nu-user">Nome utente (per l'accesso)</label>
  <input class="input" id="nu-user" name="username" required pattern="[a-zA-Z0-9._\-]{3,60}" autocapitalize="none" placeholder="es. giulia">
  <label class="lab" for="nu-name">Nome visualizzato</label>
  <input class="input" id="nu-name" name="display_name" maxlength="100" placeholder="es. Giulia">
  <?php if (users_email_ready()): ?>
  <label class="lab" for="nu-email">Email (facoltativa)</label>
  <input class="input" id="nu-email" type="email" name="email" maxlength="190" placeholder="es. giulia@esempio.it">
  <?php endif; ?>
  <label class="lab" for="nu-role">Ruolo</label>
  <select class="input" id="nu-role" name="role"><option value="registrato">Registrato (solo il sito)</option><option value="gestore" selected>Gestore</option><option value="admin">Admin</option></select>
  <label class="lab" for="nu-pw">Password iniziale</label>
  <input class="input" id="nu-pw" name="password" value="<?= h($suggest) ?>" autocomplete="off" required>
  <label class="check"><input type="checkbox" name="must_change" value="1" checked> Obbliga a cambiarla al primo accesso</label>
  <button class="btn primary" type="submit">Crea utente</button>
</form>
</div>
