<?php
/*
 * Completa un libro con i dati trovati online: copertina se manca, trama se manca (o se e' solo pubblicitaria),
 * campi vuoti (editore, anno, pagine...). Non sovrascrive mai cio' che c'e' gia'.
 * Senza ISBN prova a cercarlo per titolo e autore, ma usa il risultato solo se titolo e autore corrispondono.
 */
require_once dirname(__FILE__) . '/books.php';
require_once dirname(__FILE__) . '/lookup.php';
require_once dirname(__FILE__) . '/search.php';

// Il risultato della ricerca per titolo e' proprio questo libro?
function refill_same_book($b, $r)
{
    $t1 = search_norm($b['title']);
    $t2 = search_norm($r['title']);
    if ($t1 === '' || $t2 === '') {
        return false;
    }
    $title_ok = $t1 === $t2 || (strlen($t1) >= 6 && strpos($t2, $t1) === 0) || (strlen($t2) >= 6 && strpos($t1, $t2) === 0);
    if (!$title_ok) {
        return false;
    }
    $a1 = array_filter(explode(' ', search_norm($b['authors'])), function ($w) { return strlen($w) > 2; });
    $a2 = array_filter(explode(' ', search_norm($r['authors'])), function ($w) { return strlen($w) > 2; });
    return !$a1 || ($a2 && array_intersect($a1, $a2));
}

/*
 * Restituisce array('ok' => bool, 'changed' => array di cose aggiunte, 'msg' => testo)
 * $what: 'all' (tutto cio' che manca), oppure 'cover' / 'desc' per cercare solo quello
 */
function book_refill($id, $what = 'all')
{
    $b = book_get($id);
    if (!$b) {
        return array('ok' => false, 'changed' => array(), 'msg' => 'Libro non trovato.');
    }
    $need_cover = !$b['cover_file'] && $what !== 'desc';
    $need_desc = lookup_desc_should_replace((string)$b['description']) && $what !== 'cover';
    $nb = null;
    $covers = array();
    $via = '';
    if ($b['isbn13']) {
        $r = lookup_isbn($b['isbn13'], true);
        if (!empty($r['ok'])) {
            $nb = $r['book'];
            $covers = $nb['covers'];
        } elseif (!empty($r['covers'])) {
            $covers = $r['covers'];
        }
    } else {
        // niente ISBN: ricerca per titolo e autore, solo se il risultato corrisponde davvero
        $first = trim(explode(',', (string)$b['authors'])[0]);
        $l = lookup_title(trim($b['title'] . ' ' . $first));
        foreach (!empty($l['results']) ? array_slice($l['results'], 0, 12) : array() as $cand) {
            if (refill_same_book($b, $cand)) {
                $nb = $cand;
                $via = ' (trovato per titolo e autore)';
                if ($cand['isbn13'] !== '') {
                    $r = lookup_isbn($cand['isbn13'], true);
                    if (!empty($r['ok'])) {
                        $nb = array_merge($r['book'], array('title' => $cand['title']));
                    }
                }
                $covers = isset($nb['covers']) ? $nb['covers'] : array();
                break;
            }
        }
    }
    $changed = array();
    $set = array();
    $vals = array();
    if ($nb && $what === 'all') {
        $map = array('subtitle' => 'subtitle', 'authors' => 'authors', 'publisher' => 'publisher', 'pub_year' => 'year', 'pages' => 'pages', 'language' => 'language');
        if (!$b['isbn13'] && !empty($nb['isbn13'])) {
            $map['isbn13'] = 'isbn13';
            $map['isbn10'] = 'isbn10';
        }
        $names = array('subtitle' => 'sottotitolo', 'authors' => 'autore', 'publisher' => 'editore', 'pub_year' => 'anno', 'pages' => 'pagine',
            'language' => 'lingua', 'isbn13' => 'ISBN', 'isbn10' => '');
        foreach ($map as $col => $k) {
            if (((string)$b[$col] === '' || $b[$col] === null) && isset($nb[$k]) && (string)$nb[$k] !== '') {
                if ($col === 'isbn13' && books_with_isbn($nb[$k], $id)) {
                    continue; // quell'ISBN e' gia' di un altro libro
                }
                $set[] = $col . ' = ?';
                $vals[] = in_array($col, array('pub_year', 'pages'), true) ? (int)$nb[$k] : str_cut($nb[$k], 255);
                if ($names[$col] !== '') {
                    $changed[] = $names[$col];
                }
            }
        }
    }
    if ($nb && $need_desc && !empty($nb['description']) && $nb['description'] !== $b['description']) {
        $set[] = 'description = ?';
        $vals[] = $nb['description'];
        array_unshift($changed, 'trama');
    }
    if ($set) {
        $set[] = 'updated_at = ?';
        $vals[] = now();
        $vals[] = (int)$id;
        db()->prepare('UPDATE books SET ' . implode(', ', $set) . ' WHERE id = ?')->execute($vals);
    }
    if ($need_cover && $covers) {
        $c = cover_store_from_urls(array_slice(array_values(array_unique($covers)), 0, 6), $id, 'trusted');
        if ($c[0]) {
            array_unshift($changed, 'copertina');
        }
    }
    if ($changed) {
        app_log('libro_ricaricato', '#' . $id . ' "' . $b['title'] . '": ' . implode(', ', $changed) . $via);
        return array('ok' => true, 'changed' => $changed, 'msg' => 'Aggiunto: ' . implode(', ', $changed) . $via);
    }
    if (!$nb) {
        return array('ok' => true, 'changed' => array(), 'msg' => $b['isbn13'] ? 'Nessuna fonte online conosce questo ISBN.' : 'Senza ISBN e non trovato con certezza per titolo e autore.');
    }
    $miss = array();
    if ($need_cover) {
        $miss[] = 'copertina';
    }
    if ($need_desc) {
        $miss[] = 'trama';
    }
    return array('ok' => true, 'changed' => array(), 'msg' => $miss ? 'Trovato, ma senza ' . implode(' né ', $miss) . ' utilizzabile.' : 'Già completo: niente da aggiungere.');
}
