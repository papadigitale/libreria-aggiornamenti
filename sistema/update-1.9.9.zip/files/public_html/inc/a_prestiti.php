<?php
$pdo = db();
if (!v12_ready()) {
    echo '<div class="alert warn">Il database non è ancora aggiornato alla versione 1.2.</div>';
    return;
}
$today = date('Y-m-d');
$open = $pdo->query('SELECT l.*, b.title, b.authors, b.cover_file FROM loans l INNER JOIN books b ON b.id = l.book_id WHERE l.returned_at IS NULL '
    . 'ORDER BY CASE WHEN l.due_at IS NULL THEN 1 ELSE 0 END, l.due_at, l.lent_at')->fetchAll();
$history = $pdo->query('SELECT l.*, b.title, b.authors FROM loans l INNER JOIN books b ON b.id = l.book_id WHERE l.returned_at IS NOT NULL '
    . 'ORDER BY l.returned_at DESC, l.id DESC LIMIT 60')->fetchAll();
$late = 0;
foreach ($open as $l) {
    if ($l['due_at'] && $l['due_at'] < $today) {
        $late++;
    }
}
$returned = (int)$pdo->query('SELECT COUNT(*) FROM loans WHERE returned_at IS NOT NULL')->fetchColumn();
$people = $pdo->query('SELECT borrower, COUNT(*) AS tot, SUM(CASE WHEN returned_at IS NULL THEN 1 ELSE 0 END) AS aperti FROM loans GROUP BY borrower ORDER BY aperti DESC, tot DESC, borrower LIMIT 12')->fetchAll();
$lent_ids = array_flip(array_map(function ($l) { return (int)$l['book_id']; }, $open));
$books = $pdo->query('SELECT id, title, authors FROM books ORDER BY title')->fetchAll();
?>
<div class="kpis">
  <div class="kpi"><b><?= count($open) ?></b><span>libri in prestito</span></div>
  <div class="kpi <?= $late ? 'kpi-bad' : '' ?>"><b><?= $late ?></b><span>da restituire, scaduti</span></div>
  <div class="kpi"><b><?= $returned ?></b><span>prestiti conclusi</span></div>
  <div class="kpi"><b><?= count($people) ?></b><span>persone</span></div>
</div>

<div class="adm-grid2 wide-left">
  <div class="card">
    <div class="ct">Libri fuori casa</div>
    <?php if (!$open): ?><p class="sub">Tutti i libri sono a casa.</p><?php else: ?>
    <table class="tbl">
      <thead><tr><th class="cv"></th><th>Libro</th><th>A chi</th><th>Dal</th><th>Scadenza</th><th class="act"></th></tr></thead>
      <tbody>
      <?php foreach ($open as $l): $isLate = $l['due_at'] && $l['due_at'] < $today; ?>
        <tr class="<?= $isLate ? 'late' : '' ?>">
          <td class="cv"><?= book_cover_html($l, 'cover xs') ?></td>
          <td><a class="rt" href="gestione.php?sez=libro&amp;id=<?= (int)$l['book_id'] ?>"><?= h($l['title']) ?></a><small class="muted"><?= h($l['authors']) ?></small></td>
          <td><b><?= h($l['borrower']) ?></b><?php if ($l['contact']): ?><small class="muted"><?= h($l['contact']) ?></small><?php endif; ?></td>
          <td class="muted"><?= h(date('d/m/Y', strtotime($l['lent_at']))) ?></td>
          <td><?= $l['due_at'] ? '<span class="' . ($isLate ? 'err-text' : '') . '">' . h(date('d/m/Y', strtotime($l['due_at']))) . '</span>' : '<span class="muted">—</span>' ?>
            <small class="muted"><?= h(loan_status_text($l)) ?></small></td>
          <td class="act">
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="loan_return"><input type="hidden" name="id" value="<?= (int)$l['id'] ?>">
              <button class="btn primary small" type="submit">Restituito</button></form>
            <details class="extend"><summary class="iconbtn sm" title="Cambia la scadenza"><?= icon('edit', 15) ?></summary>
              <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="loan_extend"><input type="hidden" name="id" value="<?= (int)$l['id'] ?>">
                <input class="input sm" type="date" name="due_at" value="<?= h($l['due_at'] ? $l['due_at'] : date('Y-m-d', strtotime('+30 days'))) ?>" aria-label="Nuova scadenza">
                <button class="iconbtn sm" type="submit" title="Salva"><?= icon('check', 15) ?></button></form></details>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <div>
    <form method="post" class="card stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="loan_add">
      <div class="ct"><?= icon('plus', 18) ?> Nuovo prestito</div>
      <label class="lab" for="lo-book">Libro</label>
      <input class="input" id="lo-book" name="book" list="lo-books" required placeholder="Scrivi il titolo e sceglilo dall'elenco" autocomplete="off">
      <datalist id="lo-books">
        <?php foreach ($books as $b): if (isset($lent_ids[(int)$b['id']])) { continue; } ?>
        <option value="<?= h(str_cut($b['title'], 90) . ($b['authors'] ? ' — ' . str_cut($b['authors'], 40) : '') . ' [#' . (int)$b['id'] . ']') ?>">
        <?php endforeach; ?>
      </datalist>
      <label class="lab" for="lo-who">A chi</label>
      <input class="input" id="lo-who" name="borrower" maxlength="120" required list="lo-people">
      <datalist id="lo-people"><?php foreach ($people as $p): ?><option value="<?= h($p['borrower']) ?>"><?php endforeach; ?></datalist>
      <label class="lab" for="lo-contact">Telefono o email (facoltativo)</label>
      <input class="input" id="lo-contact" name="contact" maxlength="120">
      <div class="row2">
        <div><label class="lab" for="lo-from">Dal</label><input class="input" type="date" id="lo-from" name="lent_at" value="<?= h($today) ?>"></div>
        <div><label class="lab" for="lo-due">Restituire entro</label><input class="input" type="date" id="lo-due" name="due_at" value="<?= h(date('Y-m-d', strtotime('+30 days'))) ?>"></div>
      </div>
      <label class="lab" for="lo-notes">Note</label>
      <textarea class="input" id="lo-notes" name="notes" rows="2"></textarea>
      <button class="btn primary" type="submit">Registra il prestito</button>
    </form>
    <?php if ($people): ?>
    <div class="card">
      <div class="ct">Persone</div>
      <?php foreach ($people as $p): ?>
      <div class="fr row"><span><?= h($p['borrower']) ?></span><span class="sub"><?= (int)$p['aperti'] ? '<b>' . (int)$p['aperti'] . ' in corso</b> · ' : '' ?><?= (int)$p['tot'] ?> in tutto</span></div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($history): ?>
<div class="card">
  <div class="ct">Storico dei prestiti conclusi</div>
  <table class="tbl compact">
    <thead><tr><th>Libro</th><th>A chi</th><th>Dal</th><th>Restituito</th><th class="num">Giorni</th><th class="act"></th></tr></thead>
    <tbody>
    <?php foreach ($history as $l): ?>
      <tr><td><a class="rt" href="gestione.php?sez=libro&amp;id=<?= (int)$l['book_id'] ?>"><?= h($l['title']) ?></a></td><td><?= h($l['borrower']) ?></td>
        <td class="muted"><?= h(date('d/m/Y', strtotime($l['lent_at']))) ?></td><td class="muted"><?= h(date('d/m/Y', strtotime($l['returned_at']))) ?></td>
        <td class="num"><?= max(0, (int)round((strtotime($l['returned_at']) - strtotime($l['lent_at'])) / 86400)) ?></td>
        <td class="act"><form method="post" data-confirm="Togliere questo prestito dallo storico?"><?= csrf_field() ?><input type="hidden" name="action" value="loan_del">
          <input type="hidden" name="id" value="<?= (int)$l['id'] ?>"><button class="iconbtn sm danger" type="submit" title="Elimina"><?= icon('trash', 15) ?></button></form></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
