<?php
$pdo = db();
$counts = array();
if (extras_ready()) {
    foreach ($pdo->query('SELECT t.taxonomy_id, COUNT(DISTINCT t.id) AS terms, COUNT(DISTINCT bt.book_id) AS books FROM terms t '
        . 'LEFT JOIN book_terms bt ON bt.term_id = t.id GROUP BY t.taxonomy_id')->fetchAll() as $r) {
        $counts[(int)$r['taxonomy_id']] = $r;
    }
}
$ncat = count(categories_all());
$ncatb = (int)$pdo->query('SELECT COUNT(*) FROM books WHERE category_id IS NOT NULL')->fetchColumn();
?>
<div class="adm-grid2 wide-left">
  <div class="card">
    <div class="ct">Etichette della libreria</div>
    <p class="sub">Ogni etichetta compare nel modulo di ogni libro e, se vuoi, nei filtri della libreria e nella scheda del libro.</p>
    <table class="tbl">
      <thead><tr><th>Nome</th><th>Valori</th><th class="num">Valori</th><th class="num">Libri</th><th>Opzioni</th><th class="act"></th></tr></thead>
      <tbody>
        <tr><td><a class="rt" href="gestione.php?sez=generi">Genere</a> <span class="pill">predefinita</span></td><td class="muted">Uno per libro</td>
          <td class="num"><?= $ncat ?></td><td class="num"><?= $ncatb ?></td><td class="muted">filtri · scheda · ruota</td>
          <td class="act"><a class="iconbtn sm" href="gestione.php?sez=generi" title="Gestisci"><?= icon('edit', 15) ?></a></td></tr>
        <?php foreach (taxonomies_all() as $tid => $t): $c = isset($counts[$tid]) ? $counts[$tid] : array('terms' => 0, 'books' => 0); ?>
        <tr><td><a class="rt" href="gestione.php?sez=etichetta&amp;id=<?= (int)$tid ?>"><?= h($t['name']) ?></a></td>
          <td class="muted"><?= (int)$t['multiple'] ? 'Più di uno per libro' : 'Uno per libro' ?></td>
          <td class="num"><?= (int)$c['terms'] ?></td><td class="num"><?= (int)$c['books'] ?></td>
          <td class="muted"><?= h(implode(' · ', array_filter(array((int)$t['in_filters'] ? 'filtri' : '', (int)$t['on_card'] ? 'scheda' : '')))) ?: '—' ?></td>
          <td class="act"><a class="iconbtn sm" href="gestione.php?sez=etichetta&amp;id=<?= (int)$tid ?>" title="Gestisci"><?= icon('edit', 15) ?></a>
            <form method="post" data-confirm="Eliminare l'etichetta &quot;<?= h($t['name']) ?>&quot; e tutti i suoi valori? I libri restano.">
              <?= csrf_field() ?><input type="hidden" name="action" value="tax_del"><input type="hidden" name="id" value="<?= (int)$tid ?>">
              <button class="iconbtn sm danger" type="submit" title="Elimina"><?= icon('trash', 15) ?></button></form></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php if (!taxonomies_all()): ?><p class="hint">Non hai ancora creato etichette tue. Esempi utili: <b>Collana</b> (Oscar Mondadori, Einaudi Tascabili…),
      <b>Formato</b> (cartaceo, ebook, audiolibro), <b>Scaffale</b>, <b>Lingua originale</b>, <b>Regalato da</b>, <b>Temi</b> (più valori per libro).</p><?php endif; ?>
  </div>

  <form method="post" class="card stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="tax_add">
    <div class="ct"><?= icon('plus', 18) ?> Nuova etichetta</div>
    <label class="lab" for="tx-name">Nome</label>
    <input class="input" id="tx-name" name="name" maxlength="80" required placeholder="es. Collana">
    <label class="check switch"><input type="checkbox" name="multiple" value="1" checked><span>Un libro può avere più valori (es. Temi). Se spento: un solo valore (es. Formato)</span></label>
    <label class="check switch"><input type="checkbox" name="in_filters" value="1" checked><span>Usala nei filtri della libreria</span></label>
    <label class="check switch"><input type="checkbox" name="on_card" value="1" checked><span>Mostrala nella scheda del libro</span></label>
    <label class="lab" for="tx-values">Valori iniziali (facoltativo, uno per riga)</label>
    <textarea class="input" id="tx-values" name="values" rows="5" placeholder="Cartaceo&#10;Ebook&#10;Audiolibro"></textarea>
    <button class="btn primary" type="submit">Crea l'etichetta</button>
  </form>
</div>
