<?php
/*
 * Ricerca dei libri per parole chiave, fatta in PHP (uguale con qualsiasi database):
 *  - ignora maiuscole, accenti, apostrofi e punteggiatura ("perche" trova "Perché", "l'amica" trova "L'amica geniale");
 *  - ogni parola puo' essere un pezzo di parola ("piccol" trova "Dieci piccoli indiani");
 *  - tollera piccoli errori e singolare/plurale ("indiano" trova "indiani", "murakmi" trova "Murakami");
 *  - cerca in titolo, sottotitolo, autore, editore, ISBN, posizione, genere ed etichette;
 *  - ordina per pertinenza (il titolo pesa piu' dell'autore, che pesa piu' del resto).
 * Se nessun libro contiene tutte le parole, propone quelli che ne contengono la maggior parte.
 */
require_once dirname(__FILE__) . '/books.php';

function search_norm($s)
{
    $s = str_fold((string)$s);
    $s = preg_replace("/[’'`´]/u", ' ', $s);
    $s = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $s);
    return trim(preg_replace('/\s+/', ' ', $s));
}

// Parole della ricerca (le parole "vuote" come il, di, e restano solo se la ricerca e' fatta solo di quelle)
function search_words($q)
{
    $words = array_values(array_filter(explode(' ', search_norm($q)), 'strlen'));
    $stop = array('il', 'lo', 'la', 'i', 'gli', 'le', 'l', 'un', 'una', 'uno', 'di', 'del', 'della', 'dei', 'delle', 'dello', 'degli', 'e', 'ed',
        'a', 'al', 'alla', 'ai', 'in', 'nel', 'nella', 'con', 'per', 'tra', 'fra', 'da', 'dal', 'dalla', 'che', 'the', 'of', 'and', 'o');
    $keep = array_values(array_filter($words, function ($w) use ($stop) { return !in_array($w, $stop, true); }));
    return $keep ? array_slice($keep, 0, 12) : array_slice($words, 0, 12);
}

/*
 * Quanto una parola corrisponde a un testo gia' normalizzato:
 * 1 = c'e' (anche come pezzo di parola), 0.6 = simile (un errore di battitura), 0 = no
 */
function search_word_match($w, $text, $tokens)
{
    if ($text === '') {
        return 0;
    }
    if (strlen($w) <= 2) {
        // parole cortissime: solo come inizio di una parola, per non trovare tutto
        foreach ($tokens as $t) {
            if (strpos($t, $w) === 0) {
                return 1;
            }
        }
        return 0;
    }
    if (strpos($text, $w) !== false) {
        return 1;
    }
    if (strlen($w) < 4) {
        return 0;
    }
    $max = strlen($w) >= 8 ? 2 : 1;
    foreach ($tokens as $t) {
        if (abs(strlen($t) - strlen($w)) > $max + 1 || strlen($t) < 3) {
            continue;
        }
        if (levenshtein($w, $t) <= $max) {
            return 0.6;
        }
        // pezzo iniziale di una parola piu' lunga, con un errore ("dickes" -> "dickens")
        if (strlen($t) > strlen($w) && levenshtein($w, substr($t, 0, strlen($w))) <= 1) {
            return 0.6;
        }
    }
    return 0;
}

/*
 * Restituisce array('ids' => id in ordine di pertinenza, 'exact' => true se tutti i libri contengono tutte le parole)
 * $limit_ids: facoltativo, limita la ricerca a questi libri
 */
function book_search($q, $limit_ids = null)
{
    $words = search_words($q);
    $out = array('ids' => array(), 'exact' => true, 'words' => $words);
    if (!$words) {
        return $out;
    }
    $pdo = db();
    $rows = $pdo->query('SELECT b.id, b.title, b.subtitle, b.authors, b.publisher, b.isbn13, b.isbn10, b.shelf, c.name AS cat '
        . 'FROM books b LEFT JOIN categories c ON c.id = b.category_id')->fetchAll();
    // valori delle etichette (versione 1.1 e successive)
    $terms = array();
    if (function_exists('extras_ready') && extras_ready()) {
        foreach ($pdo->query('SELECT bt.book_id, t.name FROM book_terms bt INNER JOIN terms t ON t.id = bt.term_id')->fetchAll() as $r) {
            $terms[(int)$r['book_id']][] = $r['name'];
        }
    }
    $digits = preg_replace('/\D/', '', $q);
    $isbn = strlen($digits) >= 10 ? isbn_to13($digits) : '';
    $only_digits = strlen($digits) >= 4 && preg_match('/^[\d\s\-xX]+$/', trim($q));
    $scores = array();
    $partial = array();
    $limit = $limit_ids !== null ? array_flip(array_map('intval', $limit_ids)) : null;
    foreach ($rows as $b) {
        $id = (int)$b['id'];
        if ($limit !== null && !isset($limit[$id])) {
            continue;
        }
        if ($isbn !== '' && ($b['isbn13'] === $isbn || ($b['isbn10'] && $b['isbn10'] === isbn13_to_10($isbn)))) {
            $scores[$id] = 1000;
            continue;
        }
        if ($only_digits) {
            // pezzo di ISBN, anche scritto con trattini o spazi
            if (strpos((string)$b['isbn13'], $digits) !== false || strpos((string)$b['isbn10'], $digits) !== false) {
                $scores[$id] = 500;
                continue;
            }
            // altrimenti si cerca il numero anche nel titolo (es. "1984")
        }
        $fields = array(
            array(search_norm($b['title'] . ' ' . $b['subtitle']), 3),
            array(search_norm($b['authors']), 2),
            array(search_norm($b['publisher'] . ' ' . $b['shelf'] . ' ' . $b['cat'] . ' ' . (isset($terms[$id]) ? implode(' ', $terms[$id]) : '')
                . ' ' . $b['isbn13'] . ' ' . $b['isbn10']), 1),
        );
        foreach ($fields as $i => $f) {
            $fields[$i][2] = $f[0] === '' ? array() : explode(' ', $f[0]);
        }
        $score = 0;
        $matched = 0;
        foreach ($words as $w) {
            $best = 0;
            foreach ($fields as $f) {
                $m = search_word_match($w, $f[0], $f[2]);
                if ($m > 0) {
                    // a parita' di campo vale di piu' una parola intera o l'inizio di una parola
                    $bonus = in_array($w, $f[2], true) ? 1.3 : (preg_match('/(^| )' . preg_quote($w, '/') . '/', $f[0]) ? 1.15 : 1);
                    $best = max($best, $m * $f[1] * $bonus);
                }
            }
            if ($best > 0) {
                $matched++;
                $score += $best;
            }
        }
        if ($matched === count($words)) {
            // titolo che comincia come la ricerca: in cima
            $title = search_norm($b['title']);
            if ($title === implode(' ', $words) || strpos($title, implode(' ', $words)) === 0) {
                $score += 5;
            }
            $scores[$id] = $score;
        } elseif ($matched >= max(1, (int)ceil(count($words) / 2)) && count($words) > 1) {
            $partial[$id] = $score;
        }
    }
    if (!$scores && $partial) {
        $scores = $partial;
        $out['exact'] = false;
    }
    arsort($scores);
    $out['ids'] = array_keys($scores);
    return $out;
}

// Condizione SQL "il libro e' tra questi id" (vuoto = nessun libro) e la clausola per ordinarli per pertinenza
function search_sql_in($ids, $alias = 'b')
{
    if (!$ids) {
        return array('1 = 0', '');
    }
    $ids = array_map('intval', $ids);
    $in = $alias . '.id IN (' . implode(',', $ids) . ')';
    $order = 'CASE ' . $alias . '.id';
    foreach (array_slice($ids, 0, 500) as $i => $id) {
        $order .= ' WHEN ' . $id . ' THEN ' . $i;
    }
    $order .= ' ELSE 100000 END';
    return array($in, $order);
}
