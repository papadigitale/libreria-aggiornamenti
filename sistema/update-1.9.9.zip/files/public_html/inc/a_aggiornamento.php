<?php
require_once APP_ROOT . '/inc/updater.php';
require_once APP_ROOT . '/inc/firma.php';
$fpub = firma_chiave_pubblica();
$dir = updater_dir();
$pending = isset($_SESSION['upd_pending']) ? $_SESSION['upd_pending'] : null;
$insp = null;
if ($pending) {
    if (is_file($dir . '/' . $pending['file'])) {
        $insp = updater_inspect($dir . '/' . $pending['file'], !empty($pending['rollback']));
    } else {
        unset($_SESSION['upd_pending']);
        $pending = null;
    }
}
$bad = IS_DOCKER ? array() : updater_not_writable();
$codes = updater_code_backups();
$last = db()->query("SELECT created_at, detail FROM logs WHERE action IN ('aggiornamento', 'ritorno_versione') ORDER BY id DESC LIMIT 1")->fetch();
$max_up = min((int)ini_get('upload_max_filesize') ?: 2, (int)ini_get('post_max_size') ?: 8);
$where = IS_DOCKER ? 'Container Docker' : (DIRECTORY_SEPARATOR === '\\' ? 'Windows (es. UwAmp)' : (is_file('/etc/debian_version') ? 'Debian / Proxmox' : 'Linux'));
?>
<div class="adm-grid2">
  <div class="card">
    <div class="ct"><?= admin_icon('spin', 18) ?> Versione installata</div>
    <div class="fr row"><span>Programmi</span><b><?= h(APP_VERSION) ?></b></div>
    <div class="fr row"><span>Struttura del database</span><span><?= (int)setting('db_version', '1') ?> <?= (int)setting('db_version', '1') >= APP_DB_VERSION ? '<span class="ok-text">aggiornata</span>' : '<span class="err-text">da aggiornare</span>' ?></span></div>
    <div class="fr row"><span>PHP</span><span><?= h(PHP_VERSION) ?></span></div>
    <div class="fr row"><span>Installazione</span><span><?= h($where) ?></span></div>
    <div class="fr row"><span>Ultimo aggiornamento</span><span><?= $last ? h(fmt_dt($last['created_at'])) : '—' ?></span></div>
  </div>
  <div class="card">
    <div class="ct">Come funziona</div>
    <ol class="steps">
      <li>Carichi il file <b>update.zip</b>: il sito controlla che sia integro e più recente.</li>
      <li>Vedi cosa cambia e confermi con la tua password.</li>
      <li>Prima di toccare qualcosa vengono salvati un <b>backup completo</b> dei dati e una <b>copia dei programmi attuali</b>.</li>
      <li>Il sito va in manutenzione per pochi secondi, sostituisce i programmi e aggiorna il database se serve.</li>
      <li>Se qualcosa va storto rimette da solo la versione di prima. Puoi sempre tornare indietro da qui sotto.</li>
    </ol>
    <p class="hint">Libri, copertine, utenti, impostazioni e configurazione del database non vengono mai sostituiti.</p>
  </div>
</div>

<?php require APP_ROOT . '/inc/a_repo_card.php'; ?>

<?php if (IS_DOCKER): ?>
<div class="card">
  <div class="ct"><?= admin_icon('warn', 18) ?> Installazione con Docker</div>
  <p class="sub">Con Docker i programmi fanno parte dell'immagine: un aggiornamento fatto da qui sparirebbe alla prima ricreazione del container.
    Per aggiornare copia sul server la cartella del nuovo pacchetto Docker (lasciando <code>.env</code> e <code>dati/</code>) e lancia:</p>
  <pre class="cmd">docker compose up -d --build</pre>
  <p class="hint">I dati restano nel volume. Al primo avvio della nuova versione il database viene aggiornato da solo.</p>
</div>
<?php else: ?>

<?php if ($bad): ?>
<div class="alert error">
  <b>Il web server non può modificare i file dei programmi</b> (es. <?= h(implode(', ', array_slice($bad, 0, 3))) ?>), quindi l'aggiornamento da qui non è possibile.
  <?php if ($where === 'Debian / Proxmox'): ?>
  Nel container lancia di nuovo lo script di installazione rispondendo <b>s</b> a "Permettere gli aggiornamenti dal pannello", oppure:
  <pre class="cmd">chown -R www-data:www-data <?= h(updater_base()) ?></pre>
  <?php else: ?>
  Dai al web server il permesso di scrittura sulla cartella <code><?= h(updater_base()) ?></code>.
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if ($pending && $insp): $m = $insp['manifest']; ?>
<div class="card upd-pending">
  <div class="ct"><?= admin_icon('upload', 18) ?> <?= !empty($pending['rollback']) ? 'Ritorno alla versione ' : 'Pacchetto pronto: versione ' ?><?= h($m['version']) ?></div>
  <?php if (!empty($insp['firma']) && $insp['firma']['stato'] !== 'interno'): $fs = $insp['firma']['stato']; ?>
    <div class="sigline <?= $fs === 'firmato' ? 'ok' : ($fs === 'non_valido' ? 'bad' : 'warn') ?>"><?= admin_icon($fs === 'firmato' ? 'shield' : 'warn', 16) ?>
      <span><?= h($insp['firma']['testo']) ?></span></div>
  <?php endif; ?>
  <?php if ($insp['errors']): ?>
    <div class="alert error"><?= h(implode(' ', $insp['errors'])) ?></div>
  <?php else: ?>
  <div class="kpis small">
    <div class="kpi"><b><?= h(APP_VERSION) ?> → <?= h($m['version']) ?></b><span>versione</span></div>
    <div class="kpi"><b><?= (int)$insp['changed'] ?></b><span>file modificati</span></div>
    <div class="kpi"><b><?= (int)$insp['new'] ?></b><span>file nuovi</span></div>
    <div class="kpi"><b><?= (int)$insp['remove'] ?></b><span>file rimossi</span></div>
  </div>
  <?php if (!empty($m['notes'])): ?>
  <div class="ct sep">Novità</div>
  <ul class="notes"><?php foreach ((array)$m['notes'] as $nt): ?><li><?= h($nt) ?></li><?php endforeach; ?></ul>
  <?php endif; ?>
  <?php if (!empty($m['db_version']) && (int)$m['db_version'] > (int)setting('db_version', '1')): ?>
  <p class="hint">Il database passerà dalla struttura <?= (int)setting('db_version', '1') ?> alla <?= (int)$m['db_version'] ?> (solo tabelle e colonne nuove: i dati restano).</p>
  <?php endif; ?>
  <?php if (!empty($pending['rollback'])): ?>
  <p class="hint">Tornando indietro il database resta com'è: le funzioni della versione più recente semplicemente non saranno visibili.</p>
  <?php endif; ?>
  <details class="filelist"><summary>Elenco dei file che cambiano (<?= count($insp['list']) ?>)</summary>
    <div><?php foreach (array_slice($insp['list'], 0, 400) as $l): ?><code class="fl-<?= $l[0] === '+' ? 'new' : ($l[0] === '-' ? 'del' : 'mod') ?>"><?= h($l[0] . ' ' . $l[1]) ?></code><?php endforeach; ?></div></details>
  <form method="post" class="confirm-row" data-confirm="Installare adesso la versione <?= h($m['version']) ?>? Il sito sarà in manutenzione per qualche secondo.">
    <?= csrf_field() ?><input type="hidden" name="action" value="upd_apply">
    <input class="input" type="password" name="password" required autocomplete="current-password" placeholder="La tua password per confermare" aria-label="Password">
    <button class="btn primary small" type="submit" <?= $bad ? 'disabled' : '' ?>><?= !empty($pending['rollback']) ? 'Torna a questa versione' : 'Installa l\'aggiornamento' ?></button>
  </form>
  <?php endif; ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="upd_cancel"><button class="btn link small" type="submit">Annulla</button></form>
</div>
<?php else: ?>
<form method="post" enctype="multipart/form-data" class="card stack upd-drop">
  <?= csrf_field() ?><input type="hidden" name="action" value="upd_upload">
  <div class="ct"><?= admin_icon('upload', 18) ?> Carica un aggiornamento</div>
  <p class="sub">Scegli il file <b>update.zip</b> ricevuto con la nuova versione. Limite di caricamento di questo server: <?= (int)$max_up ?> MB.</p>
  <input class="input" type="file" name="package" accept=".zip,application/zip" required>
  <?php if ($fpub): ?>
    <p class="hint"><?= admin_icon('shield', 14) ?> Su questo sito si installano solo aggiornamenti firmati da <b><?= h($fpub['autore']) ?></b>
      (impronta <code><?= h(firma_impronta_leggibile($fpub['impronta'])) ?></code>).</p>
    <?php if (firma_privata_presente()): ?>
    <label class="lab" for="upd-pass">Pacchetto non ancora firmato? Scrivi la passphrase della tua chiave e lo firmi adesso</label>
    <input class="input" type="password" id="upd-pass" name="passphrase" autocomplete="off" placeholder="Lascia vuoto se il pacchetto è già firmato">
    <?php endif; ?>
  <?php else: ?>
    <p class="hint">Gli aggiornamenti vengono controllati file per file. Con la <a href="gestione.php?sez=plugin">chiave dell'autore</a> il sito accetterà solo pacchetti firmati.</p>
  <?php endif; ?>
  <button class="btn primary" type="submit" <?= $bad ? 'disabled' : '' ?>>Carica e controlla</button>
</form>
<?php endif; ?>

<?php if ($codes): ?>
<div class="card">
  <div class="ct">Tornare a una versione precedente</div>
  <p class="sub">Copie dei programmi salvate automaticamente prima di ogni aggiornamento (le ultime 5).</p>
  <table class="tbl compact">
    <thead><tr><th>Versione</th><th>Salvata il</th><th class="num">Dimensione</th><th class="act"></th></tr></thead>
    <tbody>
    <?php foreach ($codes as $c): ?>
      <tr><td><b><?= h($c['version']) ?></b></td><td><?= h(date('d/m/Y H:i', $c['time'])) ?></td><td class="num"><?= h(fmt_bytes($c['size'])) ?></td>
        <td class="act"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="upd_rollback"><input type="hidden" name="f" value="<?= h($c['file']) ?>">
          <button class="btn ghost small" type="submit">Prepara il ritorno</button></form></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php endif; ?>

<div class="card">
  <div class="ct">Modalità manutenzione</div>
  <p class="sub">Mentre lavori puoi mostrare a tutti tranne agli Admin la pagina "Torniamo subito". Si spegne da sola dopo 30 minuti.</p>
  <form method="post"><?= csrf_field() ?>
    <?php if (maintenance_on()): ?>
    <input type="hidden" name="action" value="maint_off"><button class="btn primary small" type="submit">Disattiva la manutenzione</button>
    <?php else: ?>
    <input type="hidden" name="action" value="maint_on"><button class="btn ghost small" type="submit">Attiva la manutenzione</button>
    <?php endif; ?>
  </form>
</div>
