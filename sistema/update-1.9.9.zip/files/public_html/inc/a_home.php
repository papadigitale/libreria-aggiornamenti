<?php
$kinds = home_section_kinds();
$secs = home_sections_all(false);
$taxes = taxonomies_all();
$terms = terms_by_taxonomy();
$has_authors = false;
foreach ($secs as $s) {
    if ($s['kind'] === 'authors') {
        $has_authors = true;
    }
}
$param_input = function ($need, $name, $value, $id = '') use ($taxes, $terms) {
    $idattr = $id !== '' ? ' id="' . h($id) . '"' : '';
    if ($need === 'category') {
        $h = '<select class="input" name="' . h($name) . '"' . $idattr . '>';
        foreach (categories_all() as $c) {
            $h .= '<option value="' . (int)$c['id'] . '"' . ((string)$c['id'] === (string)$value ? ' selected' : '') . '>' . h($c['name']) . '</option>';
        }
        return $h . '</select>';
    }
    if ($need === 'term') {
        $h = '<select class="input" name="' . h($name) . '"' . $idattr . '>';
        foreach ($taxes as $tid => $t) {
            if (empty($terms[$tid])) {
                continue;
            }
            $h .= '<optgroup label="' . h($t['name']) . '">';
            foreach ($terms[$tid] as $term) {
                $h .= '<option value="' . (int)$term['id'] . '"' . ((string)$term['id'] === (string)$value ? ' selected' : '') . '>' . h($term['name']) . '</option>';
            }
            $h .= '</optgroup>';
        }
        return $h . '</select>';
    }
    if ($need === 'status') {
        $h = '<select class="input" name="' . h($name) . '"' . $idattr . '>';
        foreach (reading_statuses() as $k => $v) {
            $h .= '<option value="' . h($k) . '"' . ($k === $value ? ' selected' : '') . '>' . h($v) . '</option>';
        }
        return $h . '</select>';
    }
    if ($need === 'number') {
        return '<input class="input" name="' . h($name) . '" inputmode="numeric" value="' . h((string)$value) . '"' . $idattr . '>';
    }
    return '';
};
?>
<div class="adm-grid2 wide-left">
  <div>
    <div class="card">
      <div class="ct">Stelle sotto le copertine</div>
      <form method="post" class="stack">
        <?= csrf_field() ?><input type="hidden" name="action" value="lib_stars_save">
        <p class="sub">Sotto titolo e autore di ogni libro, nella Libreria e nelle sue righe, si possono vedere le stelle del voto.</p>
        <?php $ls = setting_defaults()['lib_stars']; $cur = setting('lib_stars'); foreach ($ls[4] as $k => $txt): ?>
        <label class="check"><input type="radio" name="lib_stars" value="<?= h($k) ?>" <?= $cur === $k ? 'checked' : '' ?>> <?= h($txt) ?></label>
        <?php endforeach; ?>
        <p class="hint">Con «il voto di chi guarda» ognuno vede le sue stelle; gli ospiti non vedono niente. Con «la media» conta il voto più recente di ogni utente.</p>
        <div class="savebar"><button class="btn primary small" type="submit">Salva</button></div>
      </form>
    </div>
    <div class="card">
      <div class="ct">Righe della pagina iniziale</div>
      <p class="sub">Dall'alto in basso, come compaiono nella home della libreria. Le righe senza libri non vengono mostrate.
        Le righe "I miei libri…" sono personali: ogni utente vede i propri.</p>
      <?php if (!$secs): ?><p class="hint">Nessuna riga: la home mostra l'elenco semplice dei libri.</p><?php endif; ?>
    </div>
    <?php foreach ($secs as $i => $s): $need = isset($kinds[$s['kind']]) ? $kinds[$s['kind']][1] : ''; ?>
    <div class="card secrow <?= (int)$s['active'] ? '' : 'off' ?>">
      <div class="secmove">
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="sec_move"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <input type="hidden" name="dir" value="up"><button class="iconbtn sm" type="submit" <?= $i === 0 ? 'disabled' : '' ?> title="Sposta su"><?= admin_icon('up', 15) ?></button></form>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="sec_move"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <input type="hidden" name="dir" value="down"><button class="iconbtn sm" type="submit" <?= $i === count($secs) - 1 ? 'disabled' : '' ?> title="Sposta giù"><?= admin_icon('down', 15) ?></button></form>
      </div>
      <form method="post" class="secform">
        <?= csrf_field() ?><input type="hidden" name="action" value="sec_save"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
        <div class="sec-kind"><?= h(home_section_describe($s)) ?></div>
        <div class="row3">
          <div><label class="lab">Titolo</label><input class="input" name="title" value="<?= h($s['title']) ?>" maxlength="100"></div>
          <?php if ($need !== ''): ?><div><label class="lab"><?= $need === 'number' ? ($s['kind'] === 'year' ? 'Dall\'anno' : 'Pagine massime') : 'Scelta' ?></label>
            <?= $param_input($need, 'param', $s['param']) ?></div><?php endif; ?>
          <?php if ($s['kind'] !== 'authors'): ?><div><label class="lab">Libri nella riga</label>
            <input class="input" name="max_items" value="<?= (int)$s['max_items'] ?>" inputmode="numeric"></div><?php else: ?><input type="hidden" name="max_items" value="1"><?php endif; ?>
        </div>
        <div class="savebar">
          <label class="check switch"><input type="checkbox" name="active" value="1" <?= (int)$s['active'] ? 'checked' : '' ?>><span>Visibile</span></label>
          <button class="btn primary small" type="submit">Salva</button>
        </div>
      </form>
      <form method="post" data-confirm="Eliminare la riga &quot;<?= h($s['title']) ?>&quot;?"><?= csrf_field() ?><input type="hidden" name="action" value="sec_del">
        <input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="iconbtn sm danger" type="submit" title="Elimina"><?= icon('trash', 15) ?></button></form>
    </div>
    <?php endforeach; ?>
  </div>

  <div>
    <form method="post" class="card stack" data-sec-add>
      <?= csrf_field() ?><input type="hidden" name="action" value="sec_add">
      <div class="ct"><?= icon('plus', 18) ?> Nuova riga</div>
      <label class="lab" for="ns-kind">Cosa mostrare</label>
      <select class="input" id="ns-kind" name="kind" data-sec-kind>
        <?php foreach ($kinds as $k => $kd): if ($k === 'authors' && $has_authors) { continue; } if ($k === 'term' && !$taxes) { continue; } ?>
        <option value="<?= h($k) ?>" data-need="<?= h($kd[1]) ?>"><?= h($kd[0]) ?></option>
        <?php endforeach; ?>
      </select>
      <div data-need-box="category" hidden><label class="lab">Genere</label><?= $param_input('category', 'param_category', '') ?></div>
      <div data-need-box="term" hidden><label class="lab">Valore dell'etichetta</label><?= $param_input('term', 'param_term', '') ?></div>
      <div data-need-box="status" hidden><label class="lab">Stato di lettura</label><?= $param_input('status', 'param_status', 'in_lettura') ?></div>
      <div data-need-box="number" hidden><label class="lab" data-number-label>Numero</label><?= $param_input('number', 'param_number', '') ?></div>
      <label class="lab" for="ns-title">Titolo della riga (facoltativo)</label>
      <input class="input" id="ns-title" name="title" maxlength="100" placeholder="es. I classici di casa">
      <label class="lab" for="ns-max">Quanti libri al massimo</label>
      <input class="input" id="ns-max" name="max_items" value="12" inputmode="numeric">
      <button class="btn primary" type="submit">Aggiungi la riga</button>
    </form>
    <p class="hint"><a class="link" href="libreria.php" target="_blank" rel="noopener">Apri la pagina iniziale</a> per vedere il risultato.</p>
  </div>
</div>
