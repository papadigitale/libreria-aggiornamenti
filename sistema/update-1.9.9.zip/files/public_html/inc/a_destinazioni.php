<?php
/* Destinazioni esterne dei backup (solo Admin) */
require_once APP_ROOT . '/inc/remote_backup.php';
require_once APP_ROOT . '/inc/data_tools.php';
if (!rb_ready()) {
    echo '<div class="alert warn">Il database non è ancora aggiornato alla versione 1.4.</div>';
    return;
}
$types = rb_types();
$targets = rb_targets();
$edit = (int)get('id') ? rb_target((int)get('id')) : null;
$new_type = isset($types[get('tipo')]) ? get('tipo') : 'folder';
$t = $edit ? $edit : array('id' => 0, 'name' => '', 'type' => $new_type, 'cfg' => array(), 'active' => 1, 'send_full' => 0);
$val = function ($k) use ($t) {
    return in_array($k, rb_secret_fields(), true) ? '' : (isset($t['cfg'][$k]) ? (string)$t['cfg'][$k] : '');
};
$has = function ($k) use ($t) {
    return !empty($t['cfg'][$k]);
};
$latest = '';
foreach (backup_list() as $b) {
    if (strpos($b['name'], '_prova') === false) {
        $latest = $b['name'];
        break;
    }
}
$keep = (int)setting('auto_backup_keep', '5');
$secret_ph = 'salvata: lascia vuoto per non cambiarla';
$self = $edit ? 'gestione.php?sez=destinazioni&id=' . (int)$edit['id'] : 'gestione.php?sez=destinazioni';
?>
<div class="card">
  <p class="sub" style="margin:0">Ogni backup automatico (<?= h(strtolower(auto_backup_options()[setting('auto_backup', 'off')])) ?>,
    <a class="link" href="gestione.php?sez=dati">cambia</a>) viene copiato anche qui. Su ogni destinazione restano solo gli ultimi
    <b><?= $keep ?></b> backup, i più vecchi vengono cancellati (solo i file dei backup della libreria, nient'altro).</p>
</div>

<?php if ($targets): ?>
<div class="tbl-wrap">
  <table class="tbl">
    <thead><tr><th>Destinazione</th><th>Tipo</th><th>Backup completi</th><th>Ultimo invio</th><th class="act"></th></tr></thead>
    <tbody>
    <?php foreach ($targets as $d): ?>
      <tr class="<?= (int)$d['active'] ? '' : 'off' ?>">
        <td><a class="rt" href="gestione.php?sez=destinazioni&amp;id=<?= (int)$d['id'] ?>"><?= h($d['name']) ?></a>
          <?php if (!(int)$d['active']): ?> <span class="pill">disattivata</span><?php endif; ?>
          <?php if (!empty($d['cfg']['account'])): ?><small class="muted"><?= h($d['cfg']['account']) ?></small><?php endif; ?></td>
        <td class="muted"><?= h($types[$d['type']]) ?></td>
        <td class="muted"><?= (int)$d['send_full'] ? 'sì' : 'no' ?></td>
        <td><?php if ($d['last_at']): ?><span class="<?= $d['last_status'] === 'ok' ? 'ok-text' : 'err-text' ?>" style="display:inline"><?= $d['last_status'] === 'ok' ? 'Riuscito' : 'Errore' ?></span>
          <small class="muted"><?= h(fmt_dt($d['last_at'])) ?> · <?= h($d['last_message']) ?></small><?php else: ?><span class="muted">mai</span><?php endif; ?></td>
        <td class="act">
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="rt_test"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="btn ghost small" type="submit">Prova</button></form>
          <?php if ($latest !== ''): ?>
          <form method="post" class="inline" data-confirm="Inviare adesso <?= h($latest) ?> a &quot;<?= h($d['name']) ?>&quot;?"><?= csrf_field() ?>
            <input type="hidden" name="action" value="rt_send"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="btn ghost small" type="submit">Invia l'ultimo</button></form>
          <?php endif; ?>
          <a class="iconbtn sm" href="gestione.php?sez=destinazioni&amp;id=<?= (int)$d['id'] ?>" title="Modifica"><?= icon('edit', 15) ?></a>
          <form method="post" class="inline" data-confirm="Eliminare la destinazione &quot;<?= h($d['name']) ?>&quot;? I backup già copiati lì restano."><?= csrf_field() ?>
            <input type="hidden" name="action" value="rt_del"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="iconbtn sm danger" type="submit" title="Elimina"><?= icon('trash', 15) ?></button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<div class="adm-grid2 wide-left">
<form method="post" class="card stack" data-rt-form>
  <?= csrf_field() ?><input type="hidden" name="action" value="rt_save"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
  <div class="ct"><?= $edit ? icon('edit', 18) . ' Modifica "' . h($t['name']) . '"' : icon('plus', 18) . ' Nuova destinazione' ?></div>
  <div class="row2">
    <div><label class="lab" for="rt-type">Tipo</label>
      <select class="input" id="rt-type" name="type" data-rt-type <?= $edit ? 'disabled' : '' ?>>
        <?php foreach ($types as $k => $v): ?><option value="<?= h($k) ?>" <?= $t['type'] === $k ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?>
      </select><?php if ($edit): ?><input type="hidden" name="type" value="<?= h($t['type']) ?>"><?php endif; ?></div>
    <div><label class="lab" for="rt-name">Nome</label><input class="input" id="rt-name" name="name" value="<?= h($t['name']) ?>" maxlength="80" placeholder="es. NAS di casa"></div>
  </div>

  <div data-rt="folder">
    <label class="lab" for="rt-path">Cartella</label>
    <input class="input mono" id="rt-path" name="cfg[path]" value="<?= h($val('path')) ?>" placeholder="<?= DIRECTORY_SEPARATOR === '\\' ? '\\\\NAS\\Backup\\Libreria' : '/mnt/backup-nas/libreria' ?>">
    <p class="hint">Una cartella del server. Per una condivisione <b>SAMBA</b> (NAS, PC Windows): su Proxmox la si monta sul server e la si collega
      al container, poi qui si scrive il percorso interno (es. <code>/mnt/backup-nas</code>): i passaggi sono nella guida di installazione.
      Su Windows (UwAmp) puoi scrivere direttamente <code>\\NAS\cartella</code>.</p>
  </div>

  <div data-rt="sftp ftp ftpes">
    <div class="row3">
      <div><label class="lab" for="rt-host">Server</label><input class="input" id="rt-host" name="cfg[host]" value="<?= h($val('host')) ?>" placeholder="192.168.1.50"></div>
      <div><label class="lab" for="rt-port">Porta</label><input class="input" id="rt-port" name="cfg[port]" value="<?= h($val('port')) ?>" inputmode="numeric" placeholder="22 / 21"></div>
      <div><label class="lab" for="rt-dir">Cartella</label><input class="input" id="rt-dir" name="cfg[dir]" value="<?= h($val('dir')) ?>" placeholder="backup/libreria"></div>
    </div>
    <div class="row2">
      <div><label class="lab" for="rt-user">Utente</label><input class="input" id="rt-user" name="cfg[user]" value="<?= h($val('user')) ?>" autocomplete="off"></div>
      <div><label class="lab" for="rt-pass">Password</label><input class="input" id="rt-pass" type="password" name="cfg[pass]" autocomplete="new-password" placeholder="<?= $has('pass') ? $secret_ph : '' ?>"></div>
    </div>
    <div data-rt="sftp">
      <p class="hint">Con SFTP una cartella senza "/" iniziale parte dalla home dell'utente.</p>
      <details class="css-box" <?= $has('key') ? 'open' : '' ?>><summary>Accesso con chiave SSH (facoltativo)</summary>
        <textarea class="input mono" name="cfg[key]" rows="5" spellcheck="false" placeholder="<?= $has('key') ? 'chiave salvata: lascia vuoto per non cambiarla' : '-----BEGIN OPENSSH PRIVATE KEY-----' ?>"></textarea>
        <label class="lab">Frase della chiave (se c'è)</label><input class="input" type="password" name="cfg[passphrase]" autocomplete="new-password" placeholder="<?= $has('passphrase') ? $secret_ph : '' ?>">
        <label class="lab">Impronta del server (facoltativa, consigliata)</label><input class="input mono" name="cfg[fingerprint]" value="<?= h($val('fingerprint')) ?>" placeholder="SHA256:… oppure MD5 aa:bb:…">
      </details>
    </div>
  </div>

  <div data-rt="webdav">
    <label class="lab" for="rt-url">Indirizzo WebDAV della cartella</label>
    <input class="input mono" id="rt-url" name="cfg[url]" value="<?= h($val('url')) ?>" placeholder="https://cloud.esempio.it/remote.php/dav/files/UTENTE/Backup%20Libreria/">
    <div class="row2">
      <div><label class="lab">Utente</label><input class="input" name="cfg[user]" value="<?= h($val('user')) ?>" autocomplete="off" data-dup></div>
      <div><label class="lab">Password (meglio una "password per app")</label><input class="input" type="password" name="cfg[pass]" autocomplete="new-password" placeholder="<?= $has('pass') ? $secret_ph : '' ?>" data-dup></div>
    </div>
    <p class="hint">Nextcloud: Impostazioni personali → Sicurezza → "Crea nuova password per l'applicazione". L'indirizzo lo trovi in File →
      Impostazioni (in basso a sinistra) → WebDAV; aggiungi in fondo il nome di una cartella, che il sito crea da solo.</p>
  </div>

  <div data-rt="ftpes webdav">
    <label class="check switch"><input type="checkbox" name="cfg[insecure]" value="1" <?= $val('insecure') === '1' ? 'checked' : '' ?>>
      <span>Accetta un certificato non verificato (solo per server di casa con certificato autofirmato)</span></label>
  </div>

  <div data-rt="gdrive">
    <div class="row2">
      <div><label class="lab">ID client</label><input class="input mono" name="cfg[client_id]" value="<?= h($val('client_id')) ?>" placeholder="….apps.googleusercontent.com"></div>
      <div><label class="lab">Chiave segreta del client</label><input class="input mono" type="password" name="cfg[client_secret]" autocomplete="new-password" placeholder="<?= $has('client_secret') ? $secret_ph : '' ?>"></div>
    </div>
    <label class="lab">Nome della cartella su Drive</label><input class="input" name="cfg[folder]" value="<?= h($val('folder')) ?>" placeholder="Libreria di Casa - backup" data-dup>
    <details class="css-box"><summary>Come ottenere ID client e chiave (una volta sola)</summary>
      <ol class="steps">
        <li>Vai su <b>console.cloud.google.com</b> e usa il progetto della chiave di Google Books (o creane uno).</li>
        <li>"API e servizi" → "Libreria" → cerca <b>Google Drive API</b> → Abilita.</li>
        <li>"Schermata di consenso OAuth": tipo <b>Esterno</b>, nome dell'app, la tua email; in "Utenti di test" aggiungi il tuo indirizzo Gmail
          (oppure pubblica l'app, altrimenti il collegamento scade dopo 7 giorni).</li>
        <li>"Credenziali" → "Crea credenziali" → <b>ID client OAuth</b> → tipo <b>TV e dispositivi con input limitato</b>.</li>
        <li>Copia qui ID client e chiave segreta, salva, poi premi "Collega l'account Google".</li>
      </ol>
      <p class="hint">Il sito può vedere e cancellare solo i file che ha creato lui, non il resto del tuo Drive.</p>
    </details>
  </div>

  <div data-rt="dropbox">
    <div class="row2">
      <div><label class="lab">App key</label><input class="input mono" name="cfg[app_key]" value="<?= h($val('app_key')) ?>"></div>
      <div><label class="lab">App secret</label><input class="input mono" type="password" name="cfg[app_secret]" autocomplete="new-password" placeholder="<?= $has('app_secret') ? $secret_ph : '' ?>"></div>
    </div>
    <label class="lab">Sottocartella</label><input class="input" name="cfg[folder]" value="<?= h($val('folder')) ?>" placeholder="backup" data-dup>
    <details class="css-box"><summary>Come ottenere App key e App secret (una volta sola)</summary>
      <ol class="steps">
        <li>Vai su <b>dropbox.com/developers/apps</b> → "Create app".</li>
        <li>Scegli <b>Scoped access</b> e <b>App folder</b> (l'app vede solo la sua cartella in "Applicazioni"), dai un nome.</li>
        <li>Nella scheda "Permissions" spunta <b>files.metadata.read</b>, <b>files.content.write</b> e <b>files.content.read</b>, poi "Submit".</li>
        <li>Nella scheda "Settings" copia App key e App secret qui, salva, poi premi "Collega l'account Dropbox".</li>
      </ol>
    </details>
  </div>

  <label class="check switch"><input type="checkbox" name="send_full" value="1" <?= (int)$t['send_full'] ? 'checked' : '' ?>>
    <span>Ricevi anche i backup completi (contengono gli account con le password cifrate)</span></label>
  <label class="check switch"><input type="checkbox" name="active" value="1" <?= (int)$t['active'] ? 'checked' : '' ?>><span>Attiva</span></label>
  <div class="savebar"><button class="btn primary small" type="submit">Salva</button>
    <?php if ($edit): ?><a class="btn link small" href="gestione.php?sez=destinazioni">Nuova destinazione</a><?php endif; ?></div>
</form>

<div>
  <?php if ($edit && $edit['type'] === 'gdrive'): $p = isset($edit['cfg']['pending']) ? $edit['cfg']['pending'] : null; ?>
  <div class="card stack">
    <div class="ct">Account Google</div>
    <p class="sub"><?= $has('refresh_token') ? 'Collegato' . (!empty($edit['cfg']['account']) ? ': <b>' . h($edit['cfg']['account']) . '</b>' : '') . '.' : 'Non ancora collegato.' ?></p>
    <?php if ($p && $p['expires'] > time()): ?>
    <div class="devcode"><span>Apri</span><a class="link" href="<?= h($p['url']) ?>" target="_blank" rel="noopener"><?= h($p['url']) ?></a>
      <span>e inserisci il codice</span><b><?= h($p['user_code']) ?></b></div>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="rt_gdrive_finish"><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
      <button class="btn primary small" type="submit">Ho autorizzato, completa il collegamento</button></form>
    <?php else: ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="rt_gdrive_start"><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
      <button class="btn <?= $has('refresh_token') ? 'ghost' : 'primary' ?> small" type="submit"><?= $has('refresh_token') ? 'Ricollega' : 'Collega' ?> l'account Google</button></form>
    <?php endif; ?>
  </div>
  <?php elseif ($edit && $edit['type'] === 'dropbox'): ?>
  <div class="card stack">
    <div class="ct">Account Dropbox</div>
    <p class="sub"><?= $has('refresh_token') ? 'Collegato.' : 'Non ancora collegato.' ?></p>
    <?php if (rb_cfg($edit, 'app_key') !== ''): ?>
    <ol class="steps"><li><a class="link" href="<?= h(rb_dropbox_auth_url($edit)) ?>" target="_blank" rel="noopener">Apri Dropbox e premi "Consenti"</a></li>
      <li>Copia il codice che ti mostra e incollalo qui:</li></ol>
    <form method="post" class="confirm-row" style="margin-top:6px"><?= csrf_field() ?><input type="hidden" name="action" value="rt_dropbox_finish"><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
      <input class="input mono" name="code" required placeholder="codice di Dropbox" autocomplete="off">
      <button class="btn primary small" type="submit">Collega</button></form>
    <?php else: ?><p class="hint">Inserisci e salva prima App key e App secret.</p><?php endif; ?>
  </div>
  <?php endif; ?>
  <div class="card">
    <div class="ct">Quale scegliere?</div>
    <ul class="steps">
      <li><b>Nextcloud</b>: il più semplice se lo hai già in casa.</li>
      <li><b>NAS con SAMBA</b>: copia veloce in rete locale.</li>
      <li><b>Google Drive / Dropbox</b>: una copia fuori casa, utile in caso di furto o guasto.</li>
    </ul>
    <p class="hint">La regola d'oro: almeno una copia in un altro dispositivo e una fuori casa. "Prova" invia un file piccolo,
      controlla che compaia e lo cancella.</p>
  </div>
</div>
</div>
