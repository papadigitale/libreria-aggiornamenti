<?php /* Aspetto con anteprima dal vivo del sito accanto ai controlli */ ?>
<div class="apl">
  <div class="apl-main"><?php include APP_ROOT . '/inc/g_aspetto.php'; ?></div>
  <aside class="apl-side">
    <div class="ct">Anteprima dal vivo</div>
    <div class="phone-frame"><iframe src="libreria.php" title="Anteprima del sito" data-theme-preview loading="lazy"></iframe></div>
    <p class="hint">Colori, caratteri e arrotondamenti cambiano subito qui; diventano definitivi premendo "Salva".
      Logo e sfondo compaiono dopo il salvataggio.</p>
    <div class="row2"><a class="btn ghost small" href="#" data-preview-go="libreria.php">Libreria</a><a class="btn ghost small" href="#" data-preview-go="ruota.php">Ruota</a></div>
  </aside>
</div>
