<?php
$backups = array_values(array_filter(backup_list(), function ($b) { return backup_allowed($b['name']); }));
require_once APP_ROOT . '/inc/library_tools.php';
?>
<?php if (v12_ready()): $ab = setting('auto_backup', 'off'); $abl = (int)setting('auto_backup_last', '0'); $next = auto_backup_next(); ?>
<form method="post" class="card stack">
  <?= csrf_field() ?><input type="hidden" name="action" value="autobackup_save">
  <div class="ct"><?= admin_icon('spin', 18) ?> Backup automatici</div>
  <p class="sub">Il sito crea il backup all'ora scelta (o alla prima visita successiva), tiene solo gli ultimi e, se le hai impostate,
    ne manda una copia alle <a class="link" href="gestione.php?sez=destinazioni">destinazioni esterne</a>.
    <?= $abl ? 'Ultimo: <b>' . h(date('d/m/Y H:i', $abl)) . '</b>.' : '' ?>
    <?= $ab !== 'off' && $next ? ' Prossimo: <b>' . h(date('d/m/Y', $next)) . ' alle ' . h(date('H:i', $next)) . '</b>.' : '' ?></p>
  <div class="row3 sched" data-sched>
    <div><label class="lab" for="ab-mode">Frequenza</label><select class="input" id="ab-mode" name="auto_backup" data-sched-mode>
      <?php foreach (auto_backup_options() as $k => $v): ?><option value="<?= h($k) ?>" <?= $ab === $k ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?></select></div>
    <div data-sched-for="weekly"><label class="lab" for="ab-wd">Giorno</label><select class="input" id="ab-wd" name="auto_backup_weekday">
      <?php foreach (weekday_names() as $k => $v): ?><option value="<?= $k ?>" <?= (int)setting('auto_backup_weekday', '7') === $k ? 'selected' : '' ?>><?= h(ucfirst($v)) ?></option><?php endforeach; ?></select></div>
    <div data-sched-for="monthly"><label class="lab" for="ab-md">Giorno del mese</label><select class="input" id="ab-md" name="auto_backup_monthday">
      <?php for ($i = 1; $i <= 28; $i++): ?><option value="<?= $i ?>" <?= (int)setting('auto_backup_monthday', '1') === $i ? 'selected' : '' ?>><?= $i ?></option><?php endfor; ?></select></div>
    <div data-sched-for="daily weekly monthly"><label class="lab" for="ab-h">Ora</label><select class="input" id="ab-h" name="auto_backup_hour">
      <?php for ($i = 0; $i <= 23; $i++): ?><option value="<?= $i ?>" <?= (int)setting('auto_backup_hour', '3') === $i ? 'selected' : '' ?>><?= sprintf('%02d:00', $i) ?></option><?php endfor; ?></select></div>
    <div data-sched-for="daily weekly monthly"><label class="lab" for="ab-keep">Quanti tenerne</label><select class="input" id="ab-keep" name="auto_backup_keep">
      <?php foreach (array(1, 2, 3, 4, 5, 7, 10, 14, 30) as $i): ?><option value="<?= $i ?>" <?= (int)setting('auto_backup_keep', '5') === $i ? 'selected' : '' ?>>gli ultimi <?= $i ?></option><?php endforeach; ?></select></div>
  </div>
  <?php if (is_admin()): ?>
  <label class="check switch"><input type="checkbox" name="auto_backup_full" value="1" <?= setting('auto_backup_full', '0') === '1' ? 'checked' : '' ?>>
    <span>Backup completi (anche utenti e impostazioni): visibili e scaricabili solo dall'Admin</span></label>
  <?php endif; ?>
  <button class="btn primary" type="submit">Salva</button>
  <p class="hint">Per l'orario preciso anche di notte, quando nessuno usa il sito, aggiungi sul server un controllo ogni 15 minuti
    (nel container Proxmox: <code>echo "*/15 * * * * www-data php <?= h(dirname(APP_ROOT)) ?>/strumenti/backup_auto.php &gt;/dev/null" &gt; /etc/cron.d/libreria</code>).</p>
</form>
<?php endif; ?>
<div class="card stack">
  <div class="ct"><?= icon('data', 18) ?> Backup della libreria</div>
  <p class="sub">Contiene libri, copertine, generi, stati di lettura e ruote personali. Utenti, password, impostazioni e log non vengono toccati.
    <?= class_exists('ZipArchive') ? '' : '<br><b>Nota:</b> l\'estensione ZIP di PHP non è attiva, il backup non includerà le copertine.' ?></p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="backup_create">
    <button class="btn primary" type="submit">Crea un backup adesso</button></form>
  <?php if (is_admin()): ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="backup_create"><input type="hidden" name="full" value="1">
    <button class="btn ghost" type="submit">Backup completo (anche utenti e impostazioni)</button></form>
  <p class="hint">Il backup completo serve per trasferire il sito su un altro server (es. Docker): contiene anche gli account con le password cifrate,
    quindi conservalo in un posto sicuro.</p>
  <?php endif; ?>
  <?php if ($backups): ?>
  <div class="list">
    <?php foreach (array_slice($backups, 0, 15) as $b): ?>
    <div class="lrow">
      <span><b><?= h(date('d/m/Y H:i', $b['time'])) ?></b><small><?= h($b['name']) ?> · <?= h(fmt_bytes($b['size'])) ?></small></span>
      <a class="iconbtn" href="gestione.php?sez=dati&amp;scarica=backup&amp;f=<?= h(rawurlencode($b['name'])) ?>" aria-label="Scarica"><?= icon('cloud', 18) ?></a>
      <form method="post" data-confirm="Ripristinare questo backup? La libreria attuale verrà sostituita (prima ne viene salvata automaticamente una copia).">
        <?= csrf_field() ?><input type="hidden" name="action" value="backup_restore"><input type="hidden" name="f" value="<?= h($b['name']) ?>">
        <button class="iconbtn" type="submit" aria-label="Ripristina"><?= icon('spin', 18) ?></button></form>
      <form method="post" data-confirm="Eliminare questo file di backup?">
        <?= csrf_field() ?><input type="hidden" name="action" value="backup_delete"><input type="hidden" name="f" value="<?= h($b['name']) ?>">
        <button class="iconbtn danger" type="submit" aria-label="Elimina"><?= icon('trash', 18) ?></button></form>
    </div>
    <?php endforeach; ?>
  </div>
  <p class="hint">I backup sono salvati nella cartella <code>data/backup</code> del server. Scaricane una copia ogni tanto su un altro dispositivo.</p>
  <?php endif; ?>
</div>

<form method="post" enctype="multipart/form-data" class="card stack" data-confirm="Ripristinare il backup caricato? La libreria attuale verrà sostituita (prima ne viene salvata una copia).">
  <?= csrf_field() ?><input type="hidden" name="action" value="backup_restore">
  <div class="ct">Ripristina da un file</div>
  <input class="input" type="file" name="file" accept=".zip,.json" required>
  <?php if (is_admin()): ?>
  <label class="check"><input type="checkbox" name="with_users" value="1"> Se è un backup completo, aggiungi anche gli utenti mancanti e le impostazioni del sito</label>
  <?php endif; ?>
  <button class="btn ghost" type="submit">Carica e ripristina</button>
</form>

<div class="card stack">
  <div class="ct">Elenco libri in CSV (Excel)</div>
  <a class="btn ghost" href="gestione.php?sez=dati&amp;scarica=csv">Scarica l'elenco completo</a>
  <form method="post" enctype="multipart/form-data" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="csv_import">
    <label class="lab">Importa libri da un file CSV</label>
    <input class="input" type="file" name="file" accept=".csv,text/csv" required>
    <label class="check"><input type="checkbox" name="skip_dup" value="1" checked> Salta i libri con un ISBN già presente</label>
    <button class="btn primary" type="submit">Importa</button>
  </form>
  <p class="hint">Colonne riconosciute: <?= h(implode(', ', array_values(csv_columns()))) ?>. Separatore punto e virgola o virgola.
    <a class="link" href="gestione.php?sez=dati&amp;scarica=modello">Scarica un modello</a>.</p>
</div>
