<?php
$lv = get('livello');
$act = get('azione');
$usr = get('utente');
$txt = str_cut(get('testo'), 100);
$from = preg_match('/^\d{4}-\d{2}-\d{2}$/', get('dal')) ? get('dal') : '';
$to = preg_match('/^\d{4}-\d{2}-\d{2}$/', get('al')) ? get('al') : '';
$pg = max(1, (int)get('pag', '1'));
$per = 50;
$w = array('1=1');
$p = array();
if (in_array($lv, array('info', 'warn', 'alert'), true)) {
    $w[] = 'level = ?';
    $p[] = $lv;
}
if ($act !== '') {
    $w[] = 'action = ?';
    $p[] = $act;
}
if ($usr !== '') {
    $w[] = 'username = ?';
    $p[] = $usr;
}
if ($txt !== '') {
    $w[] = "(detail LIKE ? ESCAPE '!' OR ip LIKE ? ESCAPE '!')";
    $like = '%' . str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $txt) . '%';
    $p[] = $like;
    $p[] = $like;
}
if ($from !== '') {
    $w[] = 'created_at >= ?';
    $p[] = $from . ' 00:00:00';
}
if ($to !== '') {
    $w[] = 'created_at <= ?';
    $p[] = $to . ' 23:59:59';
}
$sqlw = implode(' AND ', $w);
$st = db()->prepare('SELECT COUNT(*) FROM logs WHERE ' . $sqlw);
$st->execute($p);
$count = (int)$st->fetchColumn();
$st = db()->prepare('SELECT * FROM logs WHERE ' . $sqlw . ' ORDER BY id DESC LIMIT ' . $per . ' OFFSET ' . (($pg - 1) * $per));
$st->execute($p);
$rows = $st->fetchAll();
$actions = db()->query('SELECT DISTINCT action FROM logs ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);
$names = db()->query("SELECT DISTINCT username FROM logs WHERE username IS NOT NULL AND username <> '' ORDER BY username")->fetchAll(PDO::FETCH_COLUMN);
$alerts = (int)db()->query("SELECT COUNT(*) FROM logs WHERE level = 'alert' AND created_at >= '" . date('Y-m-d H:i:s', time() - 7 * 86400) . "'")->fetchColumn();
$levels = array('info' => 'Informazione', 'warn' => 'Attenzione', 'alert' => 'Allarme');
$qs = function ($over) use ($lv, $act, $usr, $txt, $from, $to) {
    return 'gestione.php?' . http_build_query(array_merge(array('tab' => 'log', 'livello' => $lv, 'azione' => $act, 'utente' => $usr,
        'testo' => $txt, 'dal' => $from, 'al' => $to), $over));
};
?>
<?php if ($alerts > 0): ?><div class="alert warn"><?= $alerts ?> eventi di livello "Allarme" negli ultimi 7 giorni.</div><?php endif; ?>
<form method="get" class="card stack log-filter">
  <input type="hidden" name="tab" value="log">
  <div class="ct"><?= icon('log', 18) ?> Log di sistema</div>
  <div class="row2">
    <select class="input" name="livello"><option value="">Tutti i livelli</option>
      <?php foreach ($levels as $k => $v): ?><option value="<?= $k ?>" <?= $lv === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?></select>
    <select class="input" name="azione"><option value="">Tutte le azioni</option>
      <?php foreach ($actions as $a): ?><option value="<?= h($a) ?>" <?= $act === $a ? 'selected' : '' ?>><?= h(str_replace('_', ' ', $a)) ?></option><?php endforeach; ?></select>
  </div>
  <div class="row2">
    <select class="input" name="utente"><option value="">Tutti gli utenti</option>
      <?php foreach ($names as $n): ?><option value="<?= h($n) ?>" <?= $usr === $n ? 'selected' : '' ?>><?= h($n) ?></option><?php endforeach; ?></select>
    <input class="input" name="testo" value="<?= h($txt) ?>" placeholder="Testo o IP">
  </div>
  <div class="row2"><input class="input" type="date" name="dal" value="<?= h($from) ?>" aria-label="Dal"><input class="input" type="date" name="al" value="<?= h($to) ?>" aria-label="Al"></div>
  <div class="row2"><a class="btn ghost" href="gestione.php?sez=log">Azzera</a><button class="btn primary" type="submit">Filtra</button></div>
</form>

<div class="sechead"><span><?= $count ?> eventi</span><a class="link" href="gestione.php?sez=log&amp;scarica=log">Esporta CSV</a></div>
<div class="logs">
  <?php foreach ($rows as $r): ?>
  <div class="logrow lv-<?= h($r['level']) ?>">
    <div class="lr-top"><span class="lr-act"><?= h(str_replace('_', ' ', $r['action'])) ?></span><span class="lr-time"><?= h(fmt_dt($r['created_at'])) ?></span></div>
    <?php if ($r['detail'] !== null && $r['detail'] !== ''): ?><div class="lr-det"><?= h($r['detail']) ?></div><?php endif; ?>
    <div class="lr-meta"><?= h($r['username'] !== null && $r['username'] !== '' ? $r['username'] : '—') ?> · <?= h($r['ip']) ?></div>
  </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><p class="sub">Nessun evento.</p><?php endif; ?>
</div>
<div class="row2 pager">
  <?php if ($pg > 1): ?><a class="btn ghost" href="<?= h($qs(array('pag' => $pg - 1))) ?>">← Più recenti</a><?php else: ?><span></span><?php endif; ?>
  <?php if ($pg * $per < $count): ?><a class="btn ghost" href="<?= h($qs(array('pag' => $pg + 1))) ?>">Più vecchi →</a><?php endif; ?>
</div>

<form method="post" class="card stack" data-confirm="Eliminare definitivamente i log più vecchi?">
  <?= csrf_field() ?><input type="hidden" name="action" value="log_purge">
  <div class="ct">Pulizia</div>
  <label class="lab">Elimina i log più vecchi di (giorni)</label>
  <input class="input" type="number" name="days" value="90" min="1">
  <button class="btn ghost" type="submit">Elimina</button>
  <p class="hint">I log più vecchi di <?= setting_int('log_retention') ?> giorni vengono comunque eliminati in automatico (impostazione in Sicurezza).</p>
</form>
