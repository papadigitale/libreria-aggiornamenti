<?php
/* Sistema → Officina: pubblica aggiornamenti e plugin nel repository GitHub (1.9.8) */
require_once APP_ROOT . '/inc/pubblica.php';
$fpub = firma_chiave_pubblica();
$priv = firma_privata_presente();
$cfg = pub_config();
$url_siti = pub_url_siti();
$catalogo = null;
$cat_err = '';
if (pub_pronto() && get('catalogo') === '1') {
    try {
        list($catalogo) = pub_catalogo();
    } catch (Exception $e) {
        $cat_err = $e->getMessage();
    }
}
?>
<div class="adm-grid2">
  <div class="card">
    <div class="ct"><?= admin_icon('tool', 18) ?> Cos'è l'officina</div>
    <p class="sub">Da qui firmi e pubblichi su GitHub gli aggiornamenti e i plugin: i siti collegati al repository vedono l'avviso e li installano con un clic.</p>
    <ol class="pub-steps">
      <li><b>Chiave dell'autore</b> con la chiave privata su questo sito: <?= $fpub && $priv ? '<span class="ok-text">' . admin_icon('check', 14) . ' pronta (' . h(firma_impronta_leggibile($fpub['impronta'])) . ')</span>' : '<span class="err-text">manca</span> → <a class="link" href="gestione.php?sez=plugin#chiave">Plugin → Chiave dell\'autore → Importa</a>' ?></li>
      <li><b>Collegamento a GitHub</b> (qui sotto): <?= $cfg['owner'] !== '' && $cfg['token'] !== '' ? '<span class="ok-text">' . admin_icon('check', 14) . ' ' . h($cfg['owner'] . '/' . $cfg['repo']) . '</span>' : '<span class="err-text">da fare</span>' ?></li>
      <li><b>Pubblica</b> il pacchetto: il sito lo firma, lo carica e aggiorna il catalogo firmato.</li>
    </ol>
    <p class="hint">Usa l'officina su un'installazione raggiungibile solo dalla rete di casa: così la chiave privata non sta sul sito pubblico.</p>
  </div>

  <form method="post" class="card stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="pub_config">
    <div class="ct"><?= admin_icon('cloud', 18) ?> Collegamento a GitHub</div>
    <div class="row2"><div><label class="lab" for="pub-own">Nome utente GitHub</label><input class="input" id="pub-own" name="owner" value="<?= h($cfg['owner']) ?>" required autocomplete="off"></div>
      <div><label class="lab" for="pub-rep">Nome del repository</label><input class="input" id="pub-rep" name="repo" value="<?= h($cfg['repo']) ?>" required autocomplete="off" placeholder="es. libreria-repository"></div></div>
    <label class="lab" for="pub-br">Ramo</label><input class="input" id="pub-br" name="branch" value="<?= h($cfg['branch'] !== '' ? $cfg['branch'] : 'main') ?>">
    <label class="lab" for="pub-tok">Token di accesso (fine-grained)</label>
    <input class="input" id="pub-tok" name="token" type="password" autocomplete="off" placeholder="<?= $cfg['token'] !== '' ? 'Salvato (cifrato). Scrivine uno nuovo solo per sostituirlo' : 'github_pat_…' ?>">
    <p class="hint">Il token deve avere accesso <b>solo a questo repository</b>, con il permesso <b>Contents: Read and write</b>. È salvato cifrato e non esce mai da questo server.</p>
    <div class="row-btn"><button class="btn primary small" type="submit">Salva e prova</button>
      <?php if ($cfg['token'] !== ''): ?><button class="btn link small" type="submit" form="pub-test">Prova il collegamento</button><?php endif; ?></div>
  </form>
  <form method="post" id="pub-test"><?= csrf_field() ?><input type="hidden" name="action" value="pub_test"></form>
</div>

<?php if ($url_siti !== ''): ?>
<div class="card">
  <div class="ct"><?= admin_icon('link', 18) ?> Indirizzo da scrivere sui siti</div>
  <p class="sub">Sui siti che devono ricevere gli aggiornamenti: <b>Gestione → Sistema → Aggiornamento → Repository</b>, incolla questo indirizzo e salva.</p>
  <div class="pub-url"><input class="input" readonly value="<?= h($url_siti) ?>"></div>
</div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card stack" data-confirm="Firmare e pubblicare questo pacchetto nel repository?">
  <?= csrf_field() ?><input type="hidden" name="action" value="pub_publish">
  <div class="ct"><?= admin_icon('upload', 18) ?> Pubblica un aggiornamento o un plugin</div>
  <p class="sub">Scegli lo ZIP: un aggiornamento (<code>update-X.Y.Z.zip</code>) o un plugin. Va bene anche già firmato: viene firmato di nuovo con la tua chiave.
    La versione deve essere più alta di quella già pubblicata.</p>
  <input class="input" type="file" name="pacchetto" accept=".zip,application/zip" required <?= pub_pronto() ? '' : 'disabled' ?>>
  <label class="lab">Novità (solo per i plugin, una per riga; gli aggiornamenti hanno già le loro note)</label>
  <textarea class="input" name="note" rows="2" maxlength="1000" <?= pub_pronto() ? '' : 'disabled' ?>></textarea>
  <input class="input" type="password" name="passphrase" required autocomplete="off" placeholder="Passphrase della chiave" <?= pub_pronto() ? '' : 'disabled' ?>>
  <button class="btn primary" type="submit" <?= pub_pronto() ? '' : 'disabled' ?>><?= admin_icon('upload', 16) ?> Firma e pubblica</button>
  <?php if (!pub_pronto()): ?><p class="hint">Completa prima i passi 1 e 2.</p><?php endif; ?>
</form>

<?php if (pub_pronto()): ?>
<div class="card">
  <div class="ct"><?= admin_icon('list', 18) ?> Cosa c'è nel repository</div>
  <?php if (!$catalogo && $cat_err === ''): ?>
    <a class="btn ghost small" href="gestione.php?sez=pubblica&amp;catalogo=1">Leggi il catalogo da GitHub</a>
  <?php elseif ($cat_err !== ''): ?>
    <div class="alert error"><?= h($cat_err) ?></div>
  <?php else: ?>
    <div class="fr row"><span>Ultima pubblicazione</span><span><?= $catalogo['emesso'] ? h(date('d/m/Y H:i', strtotime($catalogo['emesso']))) : '—' ?></span></div>
    <div class="fr row"><span>Sistema</span><span><?= !empty($catalogo['sistema']['versione']) ? '<b>' . h($catalogo['sistema']['versione']) . '</b>' : '—' ?></span></div>
    <?php if (!empty($catalogo['plugin'])): ?>
    <table class="tbl compact">
      <thead><tr><th>Plugin</th><th>Versione</th><th>Richiede</th><th class="act"></th></tr></thead>
      <tbody><?php foreach ($catalogo['plugin'] as $pid => $p): ?>
        <tr><td><b><?= h($p['nome']) ?></b><br><small class="muted"><?= h($pid) ?></small></td><td><?= h($p['versione']) ?></td><td><?= h($p['richiede']) ?></td>
          <td class="act"><details><summary class="btn link small">Ritira</summary>
            <form method="post" class="row-btn" data-confirm="Togliere «<?= h($p['nome']) ?>» dal catalogo? I siti non lo vedranno più tra i disponibili (chi l'ha installato lo tiene)."><?= csrf_field() ?>
              <input type="hidden" name="action" value="pub_withdraw"><input type="hidden" name="id" value="<?= h($pid) ?>">
              <input class="input" type="password" name="passphrase" required autocomplete="off" placeholder="Passphrase">
              <button class="btn danger-ghost small" type="submit">Ritira</button></form></details></td></tr>
      <?php endforeach; ?></tbody>
    </table>
    <?php else: ?><p class="sub">Nessun plugin pubblicato.</p><?php endif; ?>
  <?php endif; ?>
</div>
<?php endif; ?>
