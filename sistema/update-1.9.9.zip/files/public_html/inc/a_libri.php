<?php
/* Elenco completo dei libri con filtri, ordinamento e modifica di più libri insieme */
$pdo = db();
require_once APP_ROOT . '/inc/reading.php';
$rd_ready = reading_ready();
$rd_users = $rd_ready ? $pdo->query("SELECT id, username, display_name FROM users WHERE active = 1 AND role IN ('admin','gestore','registrato') ORDER BY display_name, username")->fetchAll() : array();
$q = str_cut(get('q'), 100);
$fcat = get('cat');
$fet = (int)get('et');
$filtro = get('filtro');
$per = in_array((int)get('per'), array(25, 50, 100, 200), true) ? (int)get('per') : 50;
$pg = max(1, (int)get('p', '1'));
$cols = array('titolo' => 'b.title', 'autore' => 'b.authors', 'editore' => 'b.publisher', 'anno' => 'b.pub_year', 'pagine' => 'b.pages',
    'genere' => 'c.name', 'aggiunto' => 'b.created_at');
$ord = isset($cols[get('ordina')]) ? get('ordina') : 'aggiunto';
$dir = get('dir') === 'asc' || (get('dir') === '' && in_array($ord, array('titolo', 'autore', 'editore', 'genere'), true)) ? 'asc' : 'desc';
$filtri = array('' => 'Tutti', 'senzacopertina' => 'Senza copertina', 'senzagenere' => 'Senza genere', 'senzaisbn' => 'Senza ISBN',
    'senzatrama' => 'Senza trama', 'doppioni' => 'Stesso ISBN più volte', 'prestati' => 'In prestito');
if (!isset($filtri[$filtro])) {
    $filtro = '';
}

$where = array('1=1');
$params = array();
$relevance = '';
if ($q !== '') {
    require_once APP_ROOT . '/inc/search.php';
    list($cond, $relevance) = search_sql_in(book_search($q)['ids']);
    $where[] = $cond;
}
if ($fcat === 'nessuno') {
    $where[] = 'b.category_id IS NULL';
} elseif ((int)$fcat > 0) {
    $where[] = 'b.category_id = ?';
    $params[] = (int)$fcat;
}
if ($fet > 0) {
    $where[] = 'b.id IN (SELECT book_id FROM book_terms WHERE term_id = ?)';
    $params[] = $fet;
}
$fx = array(
    'senzacopertina' => "(b.cover_file IS NULL OR b.cover_file = '')",
    'senzagenere' => 'b.category_id IS NULL',
    'senzaisbn' => "(b.isbn13 IS NULL OR b.isbn13 = '')",
    'senzatrama' => "(b.description IS NULL OR b.description = '')",
    'prestati' => v12_ready() ? 'b.id IN (SELECT book_id FROM loans WHERE returned_at IS NULL)' : '1=0',
    'doppioni' => "b.isbn13 IN (SELECT isbn13 FROM (SELECT isbn13 FROM books WHERE isbn13 IS NOT NULL AND isbn13 <> '' GROUP BY isbn13 HAVING COUNT(*) > 1) d)",
);
if ($filtro !== '') {
    $where[] = $fx[$filtro];
}
$from = 'FROM books b LEFT JOIN categories c ON c.id = b.category_id WHERE ' . implode(' AND ', $where);
$st = $pdo->prepare('SELECT COUNT(*) ' . $from);
$st->execute($params);
$found = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($found / $per));
$pg = min($pg, $pages);
$order = $cols[$ord] . ' ' . $dir . ($ord === 'doppioni' ? '' : ', b.title ASC');
if ($relevance !== '' && get('ordina') === '') {
    $order = $relevance . ', ' . $order; // con una ricerca: prima i piu' pertinenti
}
if ($filtro === 'doppioni') {
    $order = 'b.isbn13, b.id';
}
$st = $pdo->prepare('SELECT b.id, b.title, b.subtitle, b.authors, b.publisher, b.pub_year, b.pages, b.isbn13, b.cover_file, b.shelf, b.created_at, c.name AS cat '
    . $from . ' ORDER BY ' . $order . ' LIMIT ' . (int)$per . ' OFFSET ' . (int)(($pg - 1) * $per));
$st->execute($params);
$rows = $st->fetchAll();
$all_ids = array();
if ($found > count($rows) && $found <= 5000) {
    $st = $pdo->prepare('SELECT b.id ' . $from . ' ORDER BY ' . $order);
    $st->execute($params);
    $all_ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}
$tmap = books_terms_map(array_map(function ($r) { return $r['id']; }, $rows));
$taxes = taxonomies_all();
$terms = terms_by_taxonomy();
$fields = custom_fields_all();

$state = array('q' => $q, 'cat' => $fcat, 'et' => $fet ? $fet : '', 'filtro' => $filtro, 'ordina' => $ord, 'dir' => $dir, 'per' => $per === 50 ? '' : $per);
$url = function ($over) use ($state) {
    $p = array_filter(array_merge($state, $over), function ($v) { return $v !== '' && $v !== null && $v !== 0; });
    return 'gestione.php?' . http_build_query(array_merge(array('sez' => 'libri'), $p));
};
$self = $url(array('p' => $pg > 1 ? $pg : ''));
$th = function ($key, $label, $class = '') use ($ord, $dir, $url) {
    $on = $ord === $key;
    $nd = $on && $dir === 'asc' ? 'desc' : 'asc';
    return '<th class="' . $class . ($on ? ' sorted' : '') . '"><a href="' . h($url(array('ordina' => $key, 'dir' => $nd, 'p' => ''))) . '">' . h($label)
         . ($on ? ' <span class="arr">' . ($dir === 'asc' ? '▲' : '▼') . '</span>' : '') . '</a></th>';
};
?>
<div class="viewtabs">
  <?php foreach ($filtri as $k => $v): ?>
  <a class="<?= $filtro === $k ? 'on' : '' ?>" href="<?= h($url(array('filtro' => $k, 'p' => ''))) ?>"><?= h($v) ?></a>
  <?php endforeach; ?>
</div>

<form class="toolbar" method="get" action="gestione.php">
  <input type="hidden" name="sez" value="libri">
  <?php if ($filtro !== ''): ?><input type="hidden" name="filtro" value="<?= h($filtro) ?>"><?php endif; ?>
  <input class="input" type="search" name="q" value="<?= h($q) ?>" placeholder="Titolo, autore, editore, ISBN, posizione…" aria-label="Cerca">
  <select class="input" name="cat" aria-label="Genere">
    <option value="">Tutti i generi</option>
    <option value="nessuno" <?= $fcat === 'nessuno' ? 'selected' : '' ?>>— Senza genere</option>
    <?php foreach (categories_all() as $c): ?>
    <option value="<?= (int)$c['id'] ?>" <?= (int)$fcat === (int)$c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <?php if ($taxes): ?>
  <select class="input" name="et" aria-label="Etichetta">
    <option value="">Tutte le etichette</option>
    <?php foreach ($taxes as $tid => $t): if (empty($terms[$tid])) { continue; } ?>
    <optgroup label="<?= h($t['name']) ?>">
      <?php foreach ($terms[$tid] as $term): ?><option value="<?= (int)$term['id'] ?>" <?= $fet === (int)$term['id'] ? 'selected' : '' ?>><?= h($term['name']) ?></option><?php endforeach; ?>
    </optgroup>
    <?php endforeach; ?>
  </select>
  <?php endif; ?>
  <select class="input narrow" name="per" aria-label="Libri per pagina">
    <?php foreach (array(25, 50, 100, 200) as $o): ?><option value="<?= $o ?>" <?= $per === $o ? 'selected' : '' ?>><?= $o ?> per pagina</option><?php endforeach; ?>
  </select>
  <button class="btn primary small" type="submit">Filtra</button>
  <?php if ($q !== '' || $fcat !== '' || $fet): ?><a class="btn ghost small" href="gestione.php?sez=libri">Azzera</a><?php endif; ?>
</form>

<form method="post" action="gestione.php?sez=libri" id="bulk" data-bulk>
  <?= csrf_field() ?><input type="hidden" name="action" value="books_bulk"><input type="hidden" name="back" value="<?= h($self) ?>">
  <div class="bulkbar">
    <span class="bulk-count" data-bulk-count>Nessun libro selezionato</span>
    <select class="input" name="op" data-bulk-op aria-label="Azione">
      <option value="">Azione sui selezionati…</option>
      <option value="genre">Assegna il genere</option>
      <?php if ($taxes): ?><option value="term_add">Aggiungi un'etichetta</option><option value="term_remove">Togli un'etichetta</option><?php endif; ?>
      <option value="export">Esporta in Excel o PDF</option>
      <option value="refill">Cerca online copertina, trama e dati mancanti</option>
      <option value="shelf">Imposta la posizione in casa</option>
      <?php if ($fields): ?><option value="field">Imposta un campo personalizzato</option><?php endif; ?>
      <?php if ($rd_ready): ?><option value="reading">Segna come letto, da leggere…</option><?php endif; ?>
      <option value="delete">Sposta nel cestino</option>
    </select>
    <?php if ($rd_ready): ?>
    <select class="input" name="rd_status" data-bulk-for="reading" hidden aria-label="Stato di lettura" data-rd-status>
      <?php foreach (reading_statuses() as $k => $v): ?><option value="<?= h($k) ?>" <?= $k === 'letto' ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?>
      <option value="">Togli lo stato</option>
    </select>
    <select class="input" name="rd_user" data-bulk-for="reading" hidden aria-label="Per chi">
      <?php foreach ($rd_users as $ru): ?><option value="<?= (int)$ru['id'] ?>" <?= (int)$ru['id'] === current_uid() ? 'selected' : '' ?>>per <?= h($ru['display_name'] !== '' ? $ru['display_name'] : $ru['username']) ?></option><?php endforeach; ?>
    </select>
    <select class="input" name="rd_when" data-bulk-for="reading" hidden aria-label="Quando" data-rd-when>
      <option value="today">oggi</option>
      <option value="date">il giorno…</option>
      <option value="unknown">data sconosciuta</option>
    </select>
    <input class="input" type="date" name="rd_date" max="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>" data-bulk-for="reading" hidden aria-label="Data" data-rd-date>
    <?php endif; ?>
    <select class="input" name="category_id" data-bulk-for="genre" hidden aria-label="Genere">
      <option value="">— nessun genere</option>
      <?php foreach (categories_all() as $c): ?><option value="<?= (int)$c['id'] ?>"><?= h($c['name']) ?></option><?php endforeach; ?>
    </select>
    <?php if ($taxes): ?>
    <select class="input" name="term_id" data-bulk-for="term_add term_remove" hidden aria-label="Valore">
      <?php foreach ($taxes as $tid => $t): if (empty($terms[$tid])) { continue; } ?>
      <optgroup label="<?= h($t['name']) ?>"><?php foreach ($terms[$tid] as $term): ?><option value="<?= (int)$term['id'] ?>"><?= h($term['name']) ?></option><?php endforeach; ?></optgroup>
      <?php endforeach; ?>
    </select>
    <?php endif; ?>
    <input class="input" name="shelf" maxlength="100" placeholder="es. Studio, scaffale 3" data-bulk-for="shelf" hidden aria-label="Posizione">
    <?php if ($fields): ?>
    <select class="input" name="field_id" data-bulk-for="field" hidden aria-label="Campo">
      <?php foreach ($fields as $fid => $f): ?><option value="<?= (int)$fid ?>"><?= h($f['name']) ?> (<?= h(custom_field_types()[$f['type']]) ?>)</option><?php endforeach; ?>
    </select>
    <input class="input" name="field_value" placeholder="valore (vuoto = cancella)" data-bulk-for="field" hidden aria-label="Valore del campo">
    <?php endif; ?>
    <select class="input" name="ex_format" data-bulk-for="export" hidden aria-label="Formato">
      <option value="xlsx">Excel (.xlsx)</option><option value="pdf">PDF</option>
    </select>
    <select class="input" name="ex_order" data-bulk-for="export" hidden aria-label="Ordine">
      <option value="autore">per autore</option><option value="titolo">per titolo</option>
    </select>
    <select class="input" name="refill_what" data-bulk-for="refill" hidden aria-label="Cosa cercare">
      <option value="all">tutto ciò che manca</option>
      <option value="cover">solo le copertine</option>
      <option value="desc">solo le trame</option>
    </select>
    <button class="btn primary small" type="submit" data-bulk-go disabled>Applica</button>
    <span class="bulk-total"><?= number_format($found, 0, ',', '.') ?> libri<?= $found > $per ? ' · pagina ' . $pg . ' di ' . $pages : '' ?></span>
  </div>

  <?php if ($all_ids): ?>
  <div class="selall" data-selall hidden>Sono selezionati i <?= count($rows) ?> libri di questa pagina.
    <button type="button" class="linkbtn" data-selall-go data-ids="<?= h(json_encode($all_ids)) ?>">Seleziona tutti i <?= number_format($found, 0, ',', '.') ?> libri trovati</button></div>
  <?php endif; ?>
  <div class="refill-box" data-refill hidden>
    <div class="refill-head"><b data-refill-title>Ricerca online in corso…</b>
      <span class="muted" data-refill-count></span>
      <button type="button" class="btn ghost small" data-refill-stop>Ferma</button>
      <a class="btn primary small" href="<?= h($self) ?>" data-refill-done hidden>Aggiorna l'elenco</a></div>
    <div class="progress"><i></i></div>
    <div class="refill-sum muted" data-refill-sum></div>
    <ul class="refill-log" data-refill-log></ul>
  </div>

  <div class="tbl-wrap">
  <table class="tbl books">
    <thead><tr>
      <th class="chk"><input type="checkbox" data-check-all aria-label="Seleziona tutti"></th>
      <th class="cv"></th>
      <?= $th('titolo', 'Titolo') ?><?= $th('autore', 'Autore') ?><?= $th('genere', 'Genere') ?>
      <?php if ($taxes): ?><th>Etichette</th><?php endif; ?>
      <?= $th('editore', 'Editore') ?><?= $th('anno', 'Anno', 'num') ?><?= $th('pagine', 'Pag.', 'num') ?><?= $th('aggiunto', 'Aggiunto', 'num') ?>
      <th class="act"></th>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td class="chk"><input type="checkbox" name="ids[]" value="<?= (int)$r['id'] ?>" data-row-check aria-label="Seleziona"></td>
        <td class="cv"><?= book_cover_html($r, 'cover xs') ?></td>
        <td><a class="rt" href="gestione.php?sez=libro&amp;id=<?= (int)$r['id'] ?>"><?= h($r['title']) ?></a>
          <?php if ($r['subtitle']): ?><small class="muted"><?= h(str_cut($r['subtitle'], 80)) ?></small><?php endif; ?>
          <?php if ($r['isbn13'] || $r['shelf']): ?><small class="muted"><?= h(trim($r['isbn13'] . ($r['shelf'] ? ' · ' . $r['shelf'] : ''), ' ·')) ?></small><?php endif; ?></td>
        <td><?= h($r['authors']) ?></td>
        <td><?= $r['cat'] !== null ? h($r['cat']) : '<span class="muted">—</span>' ?></td>
        <?php if ($taxes): ?><td class="tags">
          <?php foreach ($taxes as $tid => $t): if (empty($tmap[(int)$r['id']][$tid])) { continue; } ?>
            <?php foreach ($tmap[(int)$r['id']][$tid] as $nm): ?><span class="tagp" title="<?= h($t['name']) ?>"><?= h($nm) ?></span><?php endforeach; ?>
          <?php endforeach; ?></td><?php endif; ?>
        <td><?= h($r['publisher']) ?></td>
        <td class="num"><?= $r['pub_year'] ? (int)$r['pub_year'] : '' ?></td>
        <td class="num"><?= $r['pages'] ? (int)$r['pages'] : '' ?></td>
        <td class="num muted"><?= h(date('d/m/y', strtotime($r['created_at']))) ?></td>
        <td class="act"><a class="iconbtn sm" href="gestione.php?sez=libro&amp;id=<?= (int)$r['id'] ?>" title="Modifica"><?= icon('edit', 15) ?></a>
          <a class="iconbtn sm" href="libro.php?id=<?= (int)$r['id'] ?>" target="_blank" rel="noopener" title="Apri la scheda nel sito"><?= admin_icon('ext', 15) ?></a></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="11" class="empty-row">Nessun libro corrisponde ai filtri.</td></tr><?php endif; ?>
    </tbody>
  </table>
  </div>
</form>

<?php if ($pages > 1): ?>
<nav class="pager" aria-label="Pagine">
  <?php if ($pg > 1): ?><a href="<?= h($url(array('p' => $pg - 1))) ?>">‹ Precedente</a><?php endif; ?>
  <?php for ($i = max(1, $pg - 3); $i <= min($pages, $pg + 3); $i++): ?>
    <a class="<?= $i === $pg ? 'on' : '' ?>" href="<?= h($url(array('p' => $i))) ?>"><?= $i ?></a>
  <?php endfor; ?>
  <?php if ($pg < $pages): ?><a href="<?= h($url(array('p' => $pg + 1))) ?>">Successiva ›</a><?php endif; ?>
</nav>
<?php endif; ?>
