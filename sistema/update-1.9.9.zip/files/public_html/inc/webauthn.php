<?php
/*
 * Chiavi di accesso (passkey, standard WebAuthn) scritte senza librerie esterne.
 * Il sito conserva solo la chiave PUBBLICA: la chiave privata resta nel gestore (Bitwarden, Google, Apple, Windows Hello).
 * Si chiede sempre la verifica dell'utente (impronta, volto o PIN): la chiave vale quindi come doppio fattore.
 * Algoritmi: ES256 (il piu' diffuso), RS256 e, con l'estensione sodium, Ed25519.
 */

function pk_ready()
{
    return (int)setting('db_version', '1') >= 9;
}

function pk_enabled()
{
    return pk_ready() && setting('sec_passkeys', '1') === '1';
}

function b64u_enc($bin)
{
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

function b64u_dec($s)
{
    $s = strtr((string)$s, '-_', '+/');
    $pad = strlen($s) % 4;
    if ($pad) {
        $s .= str_repeat('=', 4 - $pad);
    }
    $r = base64_decode($s, true);
    return $r === false ? '' : $r;
}

/* ---------- CBOR (solo quello che serve a WebAuthn) ---------- */

function cbor_decode($data, &$pos = 0, $depth = 0)
{
    if ($depth > 16 || $pos >= strlen($data)) {
        throw new Exception('CBOR non valido');
    }
    $ib = ord($data[$pos++]);
    $major = $ib >> 5;
    $info = $ib & 0x1f;
    $len = cbor_len($data, $pos, $info);
    switch ($major) {
        case 0:
            return $len;
        case 1:
            return -1 - $len;
        case 2:
        case 3:
            if ($pos + $len > strlen($data)) {
                throw new Exception('CBOR troncato');
            }
            $v = substr($data, $pos, $len);
            $pos += $len;
            return $v;
        case 4:
            $a = array();
            for ($i = 0; $i < $len; $i++) {
                $a[] = cbor_decode($data, $pos, $depth + 1);
            }
            return $a;
        case 5:
            $m = array();
            for ($i = 0; $i < $len; $i++) {
                $k = cbor_decode($data, $pos, $depth + 1);
                $m[is_int($k) ? $k : (string)$k] = cbor_decode($data, $pos, $depth + 1);
            }
            return $m;
        case 6:
            return cbor_decode($data, $pos, $depth + 1); // tag: si ignora
        case 7:
            if ($info === 20) {
                return false;
            }
            if ($info === 21) {
                return true;
            }
            return null;
    }
    throw new Exception('CBOR non supportato');
}

function cbor_len($data, &$pos, $info)
{
    if ($info < 24) {
        return $info;
    }
    $n = array(24 => 1, 25 => 2, 26 => 4, 27 => 8);
    if (!isset($n[$info]) || $pos + $n[$info] > strlen($data)) {
        throw new Exception('CBOR non valido');
    }
    $v = 0;
    for ($i = 0; $i < $n[$info]; $i++) {
        $v = $v * 256 + ord($data[$pos++]);
    }
    return (int)$v;
}

/* ---------- Chiave pubblica COSE → PEM ---------- */

function der_len($n)
{
    if ($n < 128) {
        return chr($n);
    }
    $b = '';
    while ($n > 0) {
        $b = chr($n & 0xff) . $b;
        $n >>= 8;
    }
    return chr(0x80 | strlen($b)) . $b;
}

function der_int($bin)
{
    $bin = ltrim($bin, "\0");
    if ($bin === '' || ord($bin[0]) > 0x7f) {
        $bin = "\0" . $bin;
    }
    return "\x02" . der_len(strlen($bin)) . $bin;
}

function der_seq($s)
{
    return "\x30" . der_len(strlen($s)) . $s;
}

// Restituisce array(alg, pem o chiave grezza) oppure lancia un'eccezione
function pk_cose_to_key($cose)
{
    if (!is_array($cose) || !isset($cose[1], $cose[3])) {
        throw new Exception('Chiave non valida');
    }
    $kty = $cose[1];
    $alg = $cose[3];
    if ($kty === 2 && $alg === -7) { // EC2, P-256, ES256
        if (!isset($cose[-2], $cose[-3]) || strlen($cose[-2]) !== 32 || strlen($cose[-3]) !== 32 || (isset($cose[-1]) && $cose[-1] !== 1)) {
            throw new Exception('Chiave EC non valida');
        }
        $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . "\x04" . $cose[-2] . $cose[-3];
        return array(-7, "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n");
    }
    if ($kty === 3 && $alg === -257) { // RSA, RS256
        if (!isset($cose[-1], $cose[-2])) {
            throw new Exception('Chiave RSA non valida');
        }
        $rsa = der_seq(der_int($cose[-1]) . der_int($cose[-2]));
        $bits = "\x03" . der_len(strlen($rsa) + 1) . "\0" . $rsa;
        $der = der_seq(der_seq("\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00") . $bits);
        return array(-257, "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n");
    }
    if ($kty === 1 && $alg === -8 && function_exists('sodium_crypto_sign_verify_detached')) { // OKP, Ed25519
        if (!isset($cose[-2]) || strlen($cose[-2]) !== 32) {
            throw new Exception('Chiave Ed25519 non valida');
        }
        return array(-8, base64_encode($cose[-2]));
    }
    throw new Exception('Tipo di chiave non supportato (algoritmo ' . (int)$alg . ')');
}

function pk_algs()
{
    $a = array(array('type' => 'public-key', 'alg' => -7), array('type' => 'public-key', 'alg' => -257));
    if (function_exists('sodium_crypto_sign_verify_detached')) {
        array_unshift($a, array('type' => 'public-key', 'alg' => -8));
    }
    return $a;
}

/* ---------- Sito (Relying Party) ---------- */

// Nome di dominio del sito (senza porta); le chiavi valgono solo per questo dominio
function pk_rp_id()
{
    $host = isset($_SERVER['HTTP_HOST']) ? strtolower((string)$_SERVER['HTTP_HOST']) : '';
    $host = preg_replace('/:\d+$/', '', $host);
    return preg_match('/^[a-z0-9.\-]+$/', $host) ? $host : '';
}

// Indirizzi da cui la chiave puo' essere usata: sempre https:// con il nome del sito (dietro Nginx Proxy Manager e
// Cloudflare il server puo' non sapere di essere in HTTPS, ma il browser usa le chiavi solo in HTTPS) e http:// solo per "localhost"
function pk_origins()
{
    $host = isset($_SERVER['HTTP_HOST']) ? strtolower((string)$_SERVER['HTTP_HOST']) : '';
    $o = array('https://' . $host);
    if (pk_rp_id() === 'localhost') {
        $o[] = 'http://' . $host;
    }
    return $o;
}

// Le chiavi funzionano solo con un nome di dominio (non con l'indirizzo IP)
function pk_available_here()
{
    $rp = pk_rp_id();
    return $rp !== '' && !filter_var($rp, FILTER_VALIDATE_IP) && strpos($rp, '.') !== false || $rp === 'localhost';
}

function pk_user_handle($uid)
{
    return 'libreria-u' . (int)$uid;
}

function pk_challenge($purpose)
{
    $c = random_bytes(32);
    $_SESSION['pk_' . $purpose] = array('c' => b64u_enc($c), 't' => time());
    return b64u_enc($c);
}

function pk_take_challenge($purpose)
{
    $k = 'pk_' . $purpose;
    $v = isset($_SESSION[$k]) ? $_SESSION[$k] : null;
    unset($_SESSION[$k]);
    if (!$v || time() - (int)$v['t'] > 300) {
        throw new Exception('Tempo scaduto: riprova.');
    }
    return $v['c'];
}

function pk_list($uid)
{
    $st = db()->prepare('SELECT * FROM user_passkeys WHERE user_id = ? ORDER BY created_at');
    $st->execute(array((int)$uid));
    return $st->fetchAll();
}

/* ---------- Dati del client e dell'autenticatore ---------- */

function pk_check_client($json, $type, $challenge)
{
    $c = json_decode($json, true);
    if (!is_array($c) || !isset($c['type'], $c['challenge'], $c['origin'])) {
        throw new Exception('Risposta del browser non valida.');
    }
    if ($c['type'] !== $type) {
        throw new Exception('Operazione non valida.');
    }
    if (!hash_equals($challenge, (string)$c['challenge'])) {
        throw new Exception('Richiesta scaduta o non valida: riprova.');
    }
    if (!in_array($c['origin'], pk_origins(), true)) {
        throw new Exception('Indirizzo del sito non corrispondente (' . $c['origin'] . ').');
    }
    if (!empty($c['crossOrigin'])) {
        throw new Exception('Richiesta da un altro sito.');
    }
}

function pk_parse_auth_data($ad, $need_cred)
{
    if (strlen($ad) < 37) {
        throw new Exception('Dati dell\'autenticatore troppo corti.');
    }
    $r = array('rp_hash' => substr($ad, 0, 32), 'flags' => ord($ad[32]), 'count' => unpack('N', substr($ad, 33, 4)));
    $r['count'] = (int)$r['count'][1];
    if (!hash_equals(hash('sha256', pk_rp_id(), true), $r['rp_hash'])) {
        throw new Exception('La chiave appartiene a un altro sito.');
    }
    if (!($r['flags'] & 0x01)) {
        throw new Exception('Presenza dell\'utente non confermata.');
    }
    if (!($r['flags'] & 0x04)) {
        throw new Exception('Serve lo sblocco con impronta, volto o PIN.');
    }
    if ($need_cred) {
        if (!($r['flags'] & 0x40) || strlen($ad) < 55) {
            throw new Exception('La chiave non è stata creata.');
        }
        $r['aaguid'] = bin2hex(substr($ad, 37, 16));
        $l = unpack('n', substr($ad, 53, 2));
        $l = (int)$l[1];
        $r['cred_id'] = substr($ad, 55, $l);
        $pos = 55 + $l;
        $r['cose'] = cbor_decode($ad, $pos);
    }
    return $r;
}

/* ---------- Registrazione ---------- */

function pk_register_options($u)
{
    $exclude = array();
    foreach (pk_list($u['id']) as $p) {
        $exclude[] = array('type' => 'public-key', 'id' => $p['credential_id']);
    }
    return array(
        'challenge' => pk_challenge('reg'),
        'rp' => array('id' => pk_rp_id(), 'name' => str_cut(setting('brand_title', 'Libreria di Casa'), 60)),
        'user' => array('id' => b64u_enc(pk_user_handle($u['id'])), 'name' => $u['username'],
            'displayName' => $u['display_name'] !== '' ? $u['display_name'] : $u['username']),
        'pubKeyCredParams' => pk_algs(),
        'authenticatorSelection' => array('residentKey' => 'required', 'requireResidentKey' => true, 'userVerification' => 'required'),
        'attestation' => 'none',
        'excludeCredentials' => $exclude,
        'timeout' => 120000,
    );
}

// $resp: dati inviati dalla pagina. Restituisce l'id della nuova chiave
function pk_register_finish($u, $resp, $name)
{
    $challenge = pk_take_challenge('reg');
    $client = b64u_dec(isset($resp['clientDataJSON']) ? $resp['clientDataJSON'] : '');
    pk_check_client($client, 'webauthn.create', $challenge);
    $pos = 0;
    $att = cbor_decode(b64u_dec(isset($resp['attestationObject']) ? $resp['attestationObject'] : ''), $pos);
    if (!is_array($att) || !isset($att['authData'])) {
        throw new Exception('Risposta dell\'autenticatore non valida.');
    }
    $ad = pk_parse_auth_data($att['authData'], true);
    list($alg, $key) = pk_cose_to_key($ad['cose']);
    $cid = b64u_enc($ad['cred_id']);
    if ($cid === '' || strlen($cid) > 255) {
        throw new Exception('Identificativo della chiave non valido.');
    }
    $st = db()->prepare('SELECT COUNT(*) FROM user_passkeys WHERE credential_id = ?');
    $st->execute(array($cid));
    if ((int)$st->fetchColumn()) {
        throw new Exception('Questa chiave è già registrata.');
    }
    $name = trim(str_cut((string)$name, 80));
    if ($name === '') {
        $name = pk_guess_name($ad['aaguid']);
    }
    $tr = isset($resp['transports']) && is_array($resp['transports']) ? implode(',', array_slice(array_filter($resp['transports'], 'is_string'), 0, 6)) : '';
    db()->prepare('INSERT INTO user_passkeys (user_id, credential_id, public_key, alg, sign_count, name, aaguid, transports, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
        ->execute(array((int)$u['id'], $cid, $key, $alg, $ad['count'], $name, $ad['aaguid'], str_cut($tr, 100), now()));
    return (int)db()->lastInsertId();
}

// Nome proposto in base al gestore che ha creato la chiave (identificativo AAGUID)
function pk_guess_name($aaguid)
{
    $known = array(
        'd548826e79b4db40a3d811116f7e8349' => 'Bitwarden',
        'ea9b8d664d011d213ce4b6b48cb575d4' => 'Google Password Manager',
        'fbfc3007154e4ecc8c0b6e020557d7bd' => 'iCloud Portachiavi',
        '08987058cadc4b81b6e130de50dcbe96' => 'Windows Hello',
        '9ddd1817af5a4672a2b93e3dd95000a9' => 'Windows Hello',
        '6028b017b1d44c02b4b3afcdafc96bb2' => 'Windows Hello',
        'bada5566a7aa401fbd9645619a55120d' => '1Password',
    );
    return isset($known[$aaguid]) ? $known[$aaguid] : 'Chiave di accesso';
}

/* ---------- Accesso ---------- */

function pk_login_options()
{
    return array(
        'challenge' => pk_challenge('login'),
        'rpId' => pk_rp_id(),
        'allowCredentials' => array(),
        'userVerification' => 'required',
        'timeout' => 120000,
    );
}

// Restituisce l'utente (riga di users) se la chiave e' valida, altrimenti lancia un'eccezione
function pk_login_finish($resp)
{
    $challenge = pk_take_challenge('login');
    $cid = isset($resp['id']) ? (string)$resp['id'] : '';
    $st = db()->prepare('SELECT p.*, u.username FROM user_passkeys p INNER JOIN users u ON u.id = p.user_id WHERE p.credential_id = ?');
    $st->execute(array($cid));
    $pk = $st->fetch();
    if (!$pk) {
        throw new Exception('Questa chiave di accesso non è (più) registrata sul sito: entra con la password e creane una nuova da "Il mio account".');
    }
    $client = b64u_dec(isset($resp['clientDataJSON']) ? $resp['clientDataJSON'] : '');
    pk_check_client($client, 'webauthn.get', $challenge);
    $adbin = b64u_dec(isset($resp['authenticatorData']) ? $resp['authenticatorData'] : '');
    $ad = pk_parse_auth_data($adbin, false);
    if (!empty($resp['userHandle']) && b64u_dec($resp['userHandle']) !== pk_user_handle($pk['user_id'])) {
        throw new Exception('La chiave non corrisponde all\'utente.');
    }
    $sig = b64u_dec(isset($resp['signature']) ? $resp['signature'] : '');
    $msg = $adbin . hash('sha256', $client, true);
    $alg = (int)$pk['alg'];
    if ($alg === -8) {
        $ok = function_exists('sodium_crypto_sign_verify_detached') && strlen($sig) === 64
            && sodium_crypto_sign_verify_detached($sig, $msg, base64_decode($pk['public_key']));
    } else {
        $ok = openssl_verify($msg, $sig, $pk['public_key'], OPENSSL_ALGO_SHA256) === 1;
    }
    if (!$ok) {
        throw new Exception('Firma della chiave non valida.');
    }
    // contatore: se la chiave ne usa uno, deve sempre crescere (altrimenti potrebbe essere una copia)
    if ($ad['count'] > 0 || (int)$pk['sign_count'] > 0) {
        if ($ad['count'] <= (int)$pk['sign_count']) {
            app_log('passkey_sospetta', 'Contatore della chiave "' . $pk['name'] . '" non valido: possibile copia', 'alert', $pk['username']);
            throw new Exception('Chiave di accesso non valida.');
        }
    }
    db()->prepare('UPDATE user_passkeys SET sign_count = ?, last_used_at = ? WHERE id = ?')->execute(array($ad['count'], now(), (int)$pk['id']));
    $st = db()->prepare('SELECT * FROM users WHERE id = ?');
    $st->execute(array((int)$pk['user_id']));
    $u = $st->fetch();
    if (!$u || (int)$u['active'] !== 1 || !in_array($u['role'], user_roles(), true)) {
        throw new Exception('Questo account è disattivato.');
    }
    $u['_passkey_name'] = $pk['name'];
    return $u;
}
