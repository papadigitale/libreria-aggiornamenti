<?php
/* Plugin → "Disponibili nel repository" */
require_once APP_ROOT . '/inc/repo.php';
$rp_dati = repo_dati();
$rp_inst = array();
foreach ($rows as $r) {
    $rp_inst[$r['id']] = $r;
}
?>
<div class="card" id="disponibili">
  <div class="ct"><?= admin_icon('cloud', 18) ?> Disponibili nel repository</div>
  <?php if (repo_url() === ''): ?>
    <p class="sub">Collega un repository in <a class="link" href="gestione.php?sez=aggiornamento#repository">Sistema → Aggiornamento</a> per vedere qui i plugin disponibili e installarli con un clic.</p>
  <?php elseif (!$rp_dati || empty($rp_dati['plugin'])): ?>
    <p class="sub">Nel catalogo non ci sono plugin<?= setting('repo_error', '') !== '' ? ' (' . h(setting('repo_error')) . ')' : '' ?>.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="repo_check"><button class="btn ghost small" type="submit">Controlla adesso</button></form>
  <?php else: ?>
    <p class="sub">I plugin arrivano già firmati: il sito controlla che il file sia identico a quello del catalogo firmato e la firma del pacchetto. Un plugin nuovo si installa spento.</p>
    <div class="plg-av">
    <?php foreach ($rp_dati['plugin'] as $pid => $p): if (!plugin_id_ok_repo($pid)) { continue; }
        $ico = repo_icona_data_uri($pid);
        $gia = isset($rp_inst[$pid]) ? $rp_inst[$pid] : null;
        $comp = repo_compatibile($p);
        $nuovo = $gia && version_compare((string)$p['versione'], (string)$gia['version'], '>'); ?>
      <div class="plg-av-i">
        <?= $ico !== '' ? '<img src="' . h($ico) . '" alt="">' : '<span class="plg-noicon">' . admin_icon('plug', 24) . '</span>' ?>
        <div class="txt"><b><?= h($p['nome']) ?> <span class="muted"><?= h($p['versione']) ?></span></b>
          <small><?= h($p['descrizione']) ?></small>
          <?php if (!empty($p['note'])): ?><small>Novità: <?= h(implode(' · ', (array)$p['note'])) ?></small><?php endif; ?>
          <?php if (!$comp): ?>
            <small class="err-text">Richiede la versione <?= h($p['richiede']) ?> della Libreria<?= !empty($p['php_min']) ? ' e PHP ' . h($p['php_min']) : '' ?>.</small>
          <?php elseif ($gia && !$nuovo): ?>
            <small class="ok-text">Installato (<?= h($gia['version']) ?>)</small>
          <?php else: ?>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="plg_repo_install"><input type="hidden" name="id" value="<?= h($pid) ?>">
              <button class="btn primary small" type="submit"><?= $nuovo ? 'Aggiorna da ' . h($gia['version']) . ' a ' . h($p['versione']) : 'Installa' ?></button></form>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
    <p class="hint">Catalogo controllato il <?= h(date('d/m/Y H:i', (int)setting('repo_checked_at', '0'))) ?>.</p>
  <?php endif; ?>
</div>
