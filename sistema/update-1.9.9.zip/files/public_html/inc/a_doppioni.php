<?php
$groups = dup_groups();
$ign = count(dup_ignored());
?>
<div class="card">
  <p class="sub" style="margin:0">Libri con lo stesso ISBN, oppure con lo stesso titolo e autore. Scegli quale <b>tenere</b> e premi "Unisci":
    gli verranno aggiunti i dati che gli mancano (trama, copertina, pagine…), gli stati di lettura, le etichette e i prestiti degli altri,
    che finiranno nel cestino. Se sono davvero libri diversi (es. due edizioni che vuoi conservare) premi "Non sono doppioni".</p>
</div>
<?php if (!$groups): ?>
<div class="card center"><p class="sub">Nessun doppione trovato. <?= $ign ? $ign . ' gruppi segnati come "non doppioni".' : '' ?></p></div>
<?php endif; ?>
<?php foreach ($groups as $g): ?>
<div class="card dupgroup">
  <div class="ct"><?= h($g['reason']) ?> <span class="pill"><?= count($g['books']) ?> libri</span></div>
  <form method="post" data-confirm="Unire questi libri tenendo quello selezionato? Gli altri andranno nel cestino.">
    <?= csrf_field() ?><input type="hidden" name="action" value="dup_merge">
    <div class="dupcols">
      <?php foreach ($g['books'] as $i => $b): ?>
      <label class="dupbook">
        <input type="hidden" name="ids[]" value="<?= (int)$b['id'] ?>">
        <span class="duppick"><input type="radio" name="keep" value="<?= (int)$b['id'] ?>" <?= $i === 0 ? 'checked' : '' ?>> Tieni questo</span>
        <?= book_cover_html($b, 'cover') ?>
        <b><?= h($b['title']) ?></b>
        <small><?= h($b['authors']) ?></small>
        <dl>
          <dt>Editore</dt><dd><?= h($b['publisher'] ?: '—') ?></dd>
          <dt>Anno</dt><dd><?= $b['pub_year'] ? (int)$b['pub_year'] : '—' ?></dd>
          <dt>Pagine</dt><dd><?= $b['pages'] ? (int)$b['pages'] : '—' ?></dd>
          <dt>ISBN</dt><dd><?= h($b['isbn13'] ?: '—') ?></dd>
          <dt>Genere</dt><dd><?= h($b['cat'] ?: '—') ?></dd>
          <dt>Trama</dt><dd><?= $b['description'] ? 'sì' : 'no' ?></dd>
          <dt>Aggiunto</dt><dd><?= h(date('d/m/Y', strtotime($b['created_at']))) ?></dd>
        </dl>
        <a class="link" href="gestione.php?sez=libro&amp;id=<?= (int)$b['id'] ?>" target="_blank" rel="noopener">Apri #<?= (int)$b['id'] ?></a>
      </label>
      <?php endforeach; ?>
    </div>
    <div class="savebar"><button class="btn primary small" type="submit"><?= admin_icon('merge', 15) ?> Unisci</button></div>
  </form>
  <form method="post" class="dup-ignore"><?= csrf_field() ?><input type="hidden" name="action" value="dup_ignore"><input type="hidden" name="key" value="<?= h($g['key']) ?>">
    <button class="btn link small" type="submit">Non sono doppioni</button></form>
</div>
<?php endforeach; ?>
