<?php
/* Scheda del libro: "La mia lettura" (stato, avanzamento, voto, diario delle letture). Variabili: $mine, $b, $id, $uid */
$ready = reading_ready();
$sessions = $ready ? reading_sessions($uid, $id) : array();
$open = null;
foreach ($sessions as $s) {
    if ($s['status'] === 'in_lettura') {
        $open = $s;
        break;
    }
}
$total = (int)$b['pages'];
$last = $open ? reading_last_point($open['id']) : null;
$pct = 0;
if ($last) {
    $pct = $last['percent'] !== null ? (float)$last['percent'] : ($total > 0 && $last['page'] !== null ? $last['page'] / $total * 100 : 0);
}
$done = $open && $last && (($total > 0 && (int)$last['page'] >= $total) || $pct >= 100);
$latest = $sessions ? $sessions[0] : null;
$now_local = date('Y-m-d\TH:i');
$fmt_d = function ($d) { return $d ? date('d/m/Y', strtotime($d)) : ''; };
$others = array();
if ($ready) {
    $st = db()->prepare("SELECT s.rating, s.review, s.finished_at, u.display_name, u.username FROM reading_sessions s INNER JOIN users u ON u.id = s.user_id "
        . "WHERE s.book_id = ? AND s.user_id <> ? AND u.active = 1 AND (s.rating IS NOT NULL OR (s.review IS NOT NULL AND s.review <> '')) ORDER BY s.finished_at DESC");
    $st->execute(array($id, $uid));
    $others = $st->fetchAll();
}
?>
<div class="card reading" id="lettura">
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="action" value="stato">
    <div class="ct">La mia lettura</div>
    <div class="seg seg5">
      <label><input type="radio" name="status" value="" <?= (string)$mine['status'] === '' ? 'checked' : '' ?> data-autosubmit><span>Nessuna</span></label>
      <?php foreach (reading_statuses() as $k => $v): ?>
      <label><input type="radio" name="status" value="<?= h($k) ?>" <?= $mine['status'] === $k ? 'checked' : '' ?> data-autosubmit><span><?= h($v) ?></span></label>
      <?php endforeach; ?>
    </div>
    <label class="check"><input type="checkbox" name="excluded" value="1" <?= (int)$mine['wheel_excluded'] === 1 ? 'checked' : '' ?> data-autosubmit>
      Escludi dalla mia ruota di lettura</label>
    <noscript><button class="btn primary" type="submit">Salva</button></noscript>
  </form>

<?php if (!$ready): ?>
  <?php if ($mine['started_at'] || $mine['finished_at']): ?>
  <p class="hint"><?= $mine['started_at'] ? 'Iniziato il ' . h($fmt_d($mine['started_at'])) : '' ?><?= $mine['finished_at'] ? ' · Finito il ' . h($fmt_d($mine['finished_at'])) : '' ?></p>
  <?php endif; ?>
</div>
<?php return; endif; ?>

  <?php if ($open || in_array((string)$mine['status'], array('', 'da_leggere'), true)): ?>
  <div class="prog">
    <?php if ($open && $last): ?>
    <div class="prog-head"><b><?= $last['page'] !== null ? 'Pagina ' . (int)$last['page'] . ($total ? ' di ' . $total : '') : rating_text($pct) . '%' ?></b>
      <span class="muted"><?= round($pct) ?>% · <?= h(date('d/m H:i', strtotime($last['read_at']))) ?></span></div>
    <div class="pbar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= round($pct) ?>"><i style="width:<?= min(100, round($pct, 1)) ?>%"></i></div>
    <?php elseif ($open): ?>
    <p class="hint">Iniziato il <?= h($fmt_d($open['started_at'])) ?>. Segna a che pagina sei arrivato man mano che leggi.</p>
    <?php else: ?>
    <p class="hint">Hai cominciato? Segna a che pagina sei: il libro passa da solo a "In lettura".</p>
    <?php endif; ?>

    <?php if ($done): ?>
    <form method="post" class="finish-box"><?= csrf_field() ?><input type="hidden" name="action" value="finito">
      <span><b>Sei arrivato alla fine!</b> Lo segni come letto?</span>
      <button class="btn primary small" type="submit"><?= icon('check', 16) ?> Letto</button></form>
    <?php endif; ?>

    <?php if ($total === 0 && can_edit()): ?>
    <form method="post" class="inline-row"><?= csrf_field() ?><input type="hidden" name="action" value="pagine_libro">
      <label class="lab" for="rd-pages">Quante pagine ha il libro? Serve per percentuali e statistiche</label>
      <div class="row-btn"><input class="input" type="number" id="rd-pages" name="pages" min="1" max="99999" inputmode="numeric" placeholder="es. 320">
        <button class="btn ghost small" type="submit">Salva</button></div></form>
    <?php endif; ?>

    <form method="post" class="stack prog-form" data-prog-form>
      <?= csrf_field() ?><input type="hidden" name="action" value="progresso">
      <div class="row2">
        <div><label class="lab" for="rd-val">A che punto sei</label>
          <div class="row-btn"><input class="input" type="number" id="rd-val" name="value" min="0" step="any" inputmode="decimal" required
              max="<?= $total ? $total : '' ?>" placeholder="<?= $total ? 'pagina (di ' . $total . ')' : 'pagina' ?>" data-total="<?= $total ?>">
            <select class="input unit" name="mode" aria-label="Unità" data-prog-mode><option value="page">pag.</option><option value="percent">%</option></select></div></div>
        <div><label class="lab" for="rd-when">Quando</label><input class="input" type="datetime-local" id="rd-when" name="read_at" value="<?= h($now_local) ?>" max="<?= h($now_local) ?>"></div>
      </div>
      <details class="note-box"><summary>Aggiungi una nota o una citazione</summary>
        <textarea class="input" name="note" rows="2" maxlength="500" placeholder="facoltativa"></textarea></details>
      <button class="btn primary" type="submit"><?= icon('check', 18) ?> Salva l'avanzamento</button>
    </form>

    <?php if ($open): $plist = reading_progress_list($open['id']); if ($plist): ?>
    <div class="plog">
      <?php $rows = array_reverse($plist); $prev = 0; $deltas = array();
      foreach ($rows as $p) { $pg = $p['page'] !== null ? (int)$p['page'] : null; $deltas[$p['id']] = $pg !== null ? $pg - $prev : null; if ($pg !== null) { $prev = $pg; } }
      foreach (array_slice($plist, 0, 12) as $p): $dl = $deltas[$p['id']]; ?>
      <div class="plog-row">
        <span class="plog-when"><?= h(date('d/m/Y H:i', strtotime($p['read_at']))) ?></span>
        <span class="plog-what"><b><?= $p['page'] !== null ? 'pag. ' . (int)$p['page'] : rating_text($p['percent']) . '%' ?></b>
          <?php if ($dl !== null && $dl > 0): ?><em class="ok-text">+<?= $dl ?></em><?php endif; ?>
          <?php if ($p['note']): ?><small><?= h($p['note']) ?></small><?php endif; ?></span>
        <form method="post" class="inline" data-confirm="Cancellare questo avanzamento?"><?= csrf_field() ?><input type="hidden" name="action" value="progresso_del">
          <input type="hidden" name="pid" value="<?= (int)$p['id'] ?>"><button class="iconbtn sm" type="submit" aria-label="Cancella"><?= icon('x', 14) ?></button></form>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; endif; ?>
  </div>
  <?php endif; ?>

  <?php if ($latest && in_array($latest['status'], array('letto', 'abbandonato'), true)): ?>
  <form method="post" class="stack rate-form">
    <?= csrf_field() ?><input type="hidden" name="action" value="voto"><input type="hidden" name="sid" value="<?= (int)$latest['id'] ?>">
    <div class="ct sep">Il mio voto</div>
    <div class="rate" data-rate>
      <?= stars_html($latest['rating'] !== null ? $latest['rating'] : 0, 'big') ?>
      <span class="rate-val" data-rate-val><?= $latest['rating'] !== null ? rating_text($latest['rating']) : 'nessun voto' ?></span>
      <input type="range" name="rating" min="0" max="5" step="0.25" value="<?= $latest['rating'] !== null ? h($latest['rating']) : '0' ?>" aria-label="Voto da 0 a 5 stelle, a quarti di stella">
    </div>
    <label class="lab" for="rd-rev">Recensione breve (facoltativa)</label>
    <textarea class="input" id="rd-rev" name="review" rows="3" maxlength="4000" placeholder="Cosa ti è piaciuto, cosa no…"><?= h((string)$latest['review']) ?></textarea>
    <div class="row-btn"><button class="btn primary" type="submit">Salva il voto</button></div>
  </form>
  <?php if ($latest['status'] === 'letto' && !$open): ?>
  <form method="post" class="reread"><?= csrf_field() ?><input type="hidden" name="action" value="rilettura">
    <button class="btn ghost small" type="submit"><?= icon('spin', 16) ?> Inizia una rilettura</button></form>
  <?php endif; ?>
  <?php endif; ?>

  <?php if ($sessions): ?>
  <details class="diary" <?= count($sessions) > 1 ? '' : '' ?>>
    <summary>Le mie letture di questo libro (<?= count($sessions) ?>)</summary>
    <?php foreach ($sessions as $s): ?>
    <div class="diary-row">
      <div><span class="status-pill <?= h($s['status']) ?>"><?= h(status_label($s['status'])) ?></span>
        <span class="muted"><?php
          if ($s['status'] === 'in_lettura') {
              echo 'dal ' . h($fmt_d($s['started_at']));
          } elseif ((int)$s['date_unknown']) {
              echo $s['started_at'] ? 'iniziato il ' . h($fmt_d($s['started_at'])) . ', fine in data sconosciuta' : 'data sconosciuta';
          } else {
              echo ($s['started_at'] ? 'dal ' . h($fmt_d($s['started_at'])) . ' al ' : 'il ') . h($fmt_d($s['finished_at']));
          } ?></span>
        <?php if ($s['rating'] !== null): ?><?= stars_html($s['rating']) ?><?php endif; ?>
        <?php if ($s['source'] === 'goodreads'): ?><small class="muted">da Goodreads</small><?php endif; ?>
        <?php if ($s['review']): ?><p class="review"><?= nl2br(h($s['review'])) ?></p><?php endif; ?></div>
      <details class="diary-edit"><summary>Modifica</summary>
        <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="date_lettura"><input type="hidden" name="sid" value="<?= (int)$s['id'] ?>">
          <div class="row2">
            <div><label class="lab">Iniziato il</label><input class="input" type="date" name="started_at" value="<?= h($s['started_at'] ? substr($s['started_at'], 0, 10) : '') ?>" max="<?= date('Y-m-d') ?>"></div>
            <?php if ($s['status'] !== 'in_lettura'): ?>
            <div><label class="lab">Finito il</label><input class="input" type="date" name="finished_at" value="<?= h($s['finished_at'] ? substr($s['finished_at'], 0, 10) : '') ?>" max="<?= date('Y-m-d') ?>"></div>
            <?php endif; ?>
          </div>
          <?php if ($s['status'] !== 'in_lettura'): ?>
          <label class="check"><input type="checkbox" name="unknown" value="1" <?= (int)$s['date_unknown'] ? 'checked' : '' ?>><span>Non ricordo quando l'ho finito (conta nel totale, non nelle statistiche dell'anno)</span></label>
          <?php endif; ?>
          <button class="btn ghost small" type="submit">Salva le date</button>
        </form>
        <form method="post" data-confirm="Cancellare questa lettura dal diario, con il suo avanzamento e il voto?"><?= csrf_field() ?>
          <input type="hidden" name="action" value="lettura_del"><input type="hidden" name="sid" value="<?= (int)$s['id'] ?>">
          <button class="btn danger-ghost small" type="submit"><?= icon('trash', 15) ?> Cancella questa lettura</button></form>
      </details>
    </div>
    <?php endforeach; ?>
    <p class="hint"><a class="link" href="statistiche.php">Le mie statistiche e i trofei →</a></p>
  </details>
  <?php endif; ?>
</div>

<?php if ($others): ?>
<div class="card">
  <div class="ct">Voti in famiglia</div>
  <?php foreach ($others as $o): ?>
  <div class="diary-row"><div><b><?= h($o['display_name'] !== '' ? $o['display_name'] : $o['username']) ?></b>
    <?php if ($o['rating'] !== null): ?><?= stars_html($o['rating']) ?><?php endif; ?>
    <?php if ($o['review']): ?><p class="review"><?= nl2br(h($o['review'])) ?></p><?php endif; ?></div></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
