<?php
/*
 * Campi del modulo libro (usati in "Aggiungi" e "Modifica").
 * Si aspetta $val = array con i valori attuali (chiavi come la tabella books).
 */
$v = function ($k) use ($val) {
    return isset($val[$k]) && $val[$k] !== null ? (string)$val[$k] : '';
};
?>
<label class="lab" for="bf-title">Titolo *</label>
<input class="input" id="bf-title" name="title" required maxlength="255" value="<?= h($v('title')) ?>">
<label class="lab" for="bf-subtitle">Sottotitolo</label>
<input class="input" id="bf-subtitle" name="subtitle" maxlength="255" value="<?= h($v('subtitle')) ?>">
<label class="lab" for="bf-authors">Autore</label>
<input class="input" id="bf-authors" name="authors" maxlength="255" value="<?= h($v('authors')) ?>">
<div class="row2">
  <div><label class="lab" for="bf-pages">Pagine</label>
    <input class="input" id="bf-pages" name="pages" inputmode="numeric" maxlength="6" value="<?= h($v('pages')) ?>"></div>
  <div><label class="lab" for="bf-year">Anno edizione</label>
    <input class="input" id="bf-year" name="pub_year" inputmode="numeric" maxlength="4" value="<?= h($v('pub_year')) ?>"></div>
</div>
<label class="lab" for="bf-publisher">Editore</label>
<input class="input" id="bf-publisher" name="publisher" maxlength="150" value="<?= h($v('publisher')) ?>">
<label class="lab" for="bf-isbn">ISBN</label>
<input class="input" id="bf-isbn" name="isbn" inputmode="numeric" maxlength="20" value="<?= h($v('isbn13') !== '' ? $v('isbn13') : $v('isbn')) ?>">
<div class="row2">
  <div><label class="lab" for="bf-cat">Genere</label>
    <select class="input" id="bf-cat" name="category_id">
      <option value="">—</option>
      <?php foreach (categories_all() as $c): ?>
      <option value="<?= (int)$c['id'] ?>" <?= (int)$v('category_id') === (int)$c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
      <?php endforeach; ?>
    </select></div>
  <div><label class="lab" for="bf-lang">Lingua</label>
    <input class="input" id="bf-lang" name="language" maxlength="10" placeholder="it" value="<?= h($v('language')) ?>"></div>
</div>
<label class="lab" for="bf-shelf">Posizione in casa</label>
<input class="input" id="bf-shelf" name="shelf" maxlength="100" placeholder="es. Salotto, scaffale 2" value="<?= h($v('shelf')) ?>">
<?php require_once APP_ROOT . '/inc/extras.php'; echo book_extras_form_html(isset($val['id']) ? (int)$val['id'] : 0, $val); ?>
<label class="lab" for="bf-desc">Trama / descrizione</label>
<textarea class="input" id="bf-desc" name="description" rows="4"><?= h($v('description')) ?></textarea>
<label class="lab" for="bf-notes">Note personali</label>
<textarea class="input" id="bf-notes" name="notes" rows="2"><?= h($v('notes')) ?></textarea>
