<?php
// Pagina del pannello creata da un plugin ($plugin->admin_page)
$pg = isset($GLOBALS['PLG_PAGES'][$sez]) ? $GLOBALS['PLG_PAGES'][$sez] : null;
if (!$pg): ?>
<div class="alert error">Pagina non disponibile: il plugin è spento o è stato rimosso.</div>
<?php return; endif;
$pid = $pg['plugin']->id;
// i moduli della pagina si aprono con $plugin->form_start(): mandano action=plg_salva con il token CSRF
$GLOBALS['PLG_CURRENT'] = $pid;
ob_start();
try {
    call_user_func($pg['render'], $pg['plugin']);
    $html = ob_get_clean();
} catch (Throwable $e) {
    ob_end_clean();
    plugin_fail($pid, $e);
    $html = '<div class="alert error">Il plugin è andato in errore ed è stato spento. Dettagli nel log.</div>';
}
$GLOBALS['PLG_CURRENT'] = null;
echo $html;
