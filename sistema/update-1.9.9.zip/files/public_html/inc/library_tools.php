<?php
/*
 * Versione 1.2: prestiti, cestino, doppioni, backup automatici.
 * Senza il database aggiornato (struttura 3) le funzioni tornano al comportamento precedente.
 */
require_once dirname(__FILE__) . '/books.php';

function v12_ready()
{
    return (int)setting('db_version', '1') >= 3;
}

/* ================= Prestiti ================= */
function loan_open_for_book($book_id)
{
    if (!v12_ready()) {
        return null;
    }
    $st = db()->prepare('SELECT * FROM loans WHERE book_id = ? AND returned_at IS NULL ORDER BY lent_at DESC, id DESC LIMIT 1');
    $st->execute(array((int)$book_id));
    $r = $st->fetch();
    return $r ? $r : null;
}

function loans_for_book($book_id)
{
    if (!v12_ready()) {
        return array();
    }
    $st = db()->prepare('SELECT * FROM loans WHERE book_id = ? ORDER BY lent_at DESC, id DESC');
    $st->execute(array((int)$book_id));
    return $st->fetchAll();
}

// array(id_libro => prestito aperto)
function loans_open_map()
{
    static $cache = null;
    if ($cache === null) {
        $cache = array();
        if (v12_ready()) {
            foreach (db()->query('SELECT * FROM loans WHERE returned_at IS NULL')->fetchAll() as $l) {
                $cache[(int)$l['book_id']] = $l;
            }
        }
    }
    return $cache;
}

function loans_overdue_count()
{
    if (!v12_ready()) {
        return 0;
    }
    $st = db()->prepare('SELECT COUNT(*) FROM loans WHERE returned_at IS NULL AND due_at IS NOT NULL AND due_at < ?');
    $st->execute(array(date('Y-m-d')));
    return (int)$st->fetchColumn();
}

function loan_date($s)
{
    $s = trim((string)$s);
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
        return $s;
    }
    if (preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $s, $m) && checkdate((int)$m[2], (int)$m[1], (int)$m[3])) {
        return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
    }
    return '';
}

// Ritorna '' se tutto bene, altrimenti il messaggio di errore
function loan_create($book_id, $borrower, $contact, $lent_at, $due_at, $notes)
{
    $borrower = str_cut(trim($borrower), 120);
    if (!book_get($book_id)) {
        return 'Libro non trovato.';
    }
    if ($borrower === '') {
        return 'Scrivi a chi presti il libro.';
    }
    if (loan_open_for_book($book_id)) {
        return 'Questo libro risulta già in prestito: segna prima la restituzione.';
    }
    $lent = loan_date($lent_at) !== '' ? loan_date($lent_at) : date('Y-m-d');
    $due = loan_date($due_at);
    if ($due !== '' && $due < $lent) {
        return 'La data di restituzione non può essere prima della data del prestito.';
    }
    db()->prepare('INSERT INTO loans (book_id, borrower, contact, lent_at, due_at, notes, created_by, created_at) VALUES (?,?,?,?,?,?,?,?)')
        ->execute(array((int)$book_id, $borrower, str_cut(trim($contact), 120), $lent, $due !== '' ? $due : null, str_cut(trim($notes), 2000),
            current_uid() ? current_uid() : null, now()));
    return '';
}

function loan_get($id)
{
    $st = db()->prepare('SELECT l.*, b.title FROM loans l INNER JOIN books b ON b.id = l.book_id WHERE l.id = ?');
    $st->execute(array((int)$id));
    $r = $st->fetch();
    return $r ? $r : null;
}

function loan_borrowers()
{
    if (!v12_ready()) {
        return array();
    }
    return db()->query('SELECT borrower, MAX(contact) AS contact, COUNT(*) AS n FROM loans GROUP BY borrower ORDER BY borrower')->fetchAll();
}

function loan_status_text($l)
{
    if ($l['returned_at']) {
        return 'restituito il ' . date('d/m/Y', strtotime($l['returned_at']));
    }
    if ($l['due_at'] && $l['due_at'] < date('Y-m-d')) {
        $d = (int)floor((strtotime(date('Y-m-d')) - strtotime($l['due_at'])) / 86400);
        return 'in ritardo di ' . $d . ($d === 1 ? ' giorno' : ' giorni');
    }
    return $l['due_at'] ? 'da restituire entro il ' . date('d/m/Y', strtotime($l['due_at'])) : 'senza scadenza';
}

/* ================= Cestino ================= */
// Tabelle collegate a un libro che vengono salvate nel cestino insieme al libro
function trash_child_tables()
{
    $t = array('user_books' => 'book_id', 'wheel_items' => 'book_id', 'wheel_spins' => 'book_id');
    if (function_exists('extras_ready') && extras_ready()) {
        $t['book_terms'] = 'book_id';
        $t['book_field_values'] = 'book_id';
    }
    if (v12_ready()) {
        $t['loans'] = 'book_id';
    }
    if ((int)setting('db_version', '1') >= 8) {
        $t['reading_sessions'] = 'book_id';
        $t['reading_progress'] = 'book_id';
    }
    return $t;
}

// Sposta un libro nel cestino (senza database aggiornato: eliminazione definitiva come prima)
function book_trash($id)
{
    $b = book_get($id);
    if (!$b) {
        return false;
    }
    if (function_exists('lib_do')) {
        register_shutdown_function('lib_do', 'libro_eliminato', (int)$id);
    }
    if (!v12_ready()) {
        book_delete($id);
        return true;
    }
    $pdo = db();
    $snap = array('book' => $b, 'children' => array(), 'version' => APP_VERSION);
    foreach (trash_child_tables() as $t => $col) {
        $st = $pdo->prepare('SELECT * FROM ' . $t . ' WHERE ' . $col . ' = ?');
        $st->execute(array((int)$id));
        $snap['children'][$t] = $st->fetchAll();
    }
    $u = current_user();
    $pdo->prepare('INSERT INTO books_trash (book_id, title, authors, cover_file, data, deleted_by, deleted_at) VALUES (?,?,?,?,?,?,?)')
        ->execute(array((int)$id, $b['title'], $b['authors'], $b['cover_file'], json_encode($snap), $u ? $u['username'] : null, now()));
    // la copertina resta su disco finche' il libro e' nel cestino
    $pdo->prepare('DELETE FROM books WHERE id = ?')->execute(array((int)$id));
    return true;
}

function trash_list()
{
    if (!v12_ready()) {
        return array();
    }
    return db()->query('SELECT id, book_id, title, authors, cover_file, deleted_by, deleted_at FROM books_trash ORDER BY deleted_at DESC, id DESC')->fetchAll();
}

function trash_count()
{
    return v12_ready() ? (int)db()->query('SELECT COUNT(*) FROM books_trash')->fetchColumn() : 0;
}

// Rimette in libreria un libro del cestino. Ritorna l'id del libro oppure un messaggio di errore (stringa)
function trash_restore($trash_id)
{
    $pdo = db();
    $st = $pdo->prepare('SELECT * FROM books_trash WHERE id = ?');
    $st->execute(array((int)$trash_id));
    $t = $st->fetch();
    if (!$t) {
        return 'Elemento non trovato nel cestino.';
    }
    $snap = json_decode($t['data'], true);
    if (!is_array($snap) || empty($snap['book'])) {
        return 'Dati del libro non leggibili.';
    }
    $b = $snap['book'];
    $cols = array('id', 'isbn13', 'isbn10', 'title', 'subtitle', 'authors', 'publisher', 'pub_year', 'pages', 'language', 'category_id', 'shelf',
        'cover_file', 'description', 'notes', 'source', 'created_by', 'created_at', 'updated_at');
    $vals = array();
    foreach ($cols as $c) {
        $vals[$c] = isset($b[$c]) && $b[$c] !== '' ? $b[$c] : null;
    }
    $vals['title'] = $vals['title'] !== null ? $vals['title'] : 'Senza titolo';
    if ($vals['category_id'] !== null && category_name((int)$vals['category_id']) === '') {
        $vals['category_id'] = null; // genere eliminato nel frattempo
    }
    if ($vals['created_by'] !== null && !(int)$pdo->query('SELECT COUNT(*) FROM users WHERE id = ' . (int)$vals['created_by'])->fetchColumn()) {
        $vals['created_by'] = null;
    }
    if ($vals['cover_file'] !== null && !is_file(COVERS_DIR . '/' . $vals['cover_file'])) {
        $vals['cover_file'] = null;
    }
    if (book_get((int)$vals['id'])) {
        unset($vals['id']); // l'id e' stato riusato: il libro torna con un id nuovo
    }
    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO books (' . implode(',', array_keys($vals)) . ') VALUES (' . implode(',', array_fill(0, count($vals), '?')) . ')')
            ->execute(array_values($vals));
        $newid = isset($vals['id']) ? (int)$vals['id'] : (int)$pdo->lastInsertId();
        $tables = trash_child_tables();
        foreach ((array)$snap['children'] as $table => $rows) {
            if (!isset($tables[$table])) {
                continue;
            }
            foreach ((array)$rows as $r) {
                $r['book_id'] = $newid;
                if ($table === 'wheel_spins' || $table === 'loans') {
                    unset($r['id']);
                }
                $keys = array_filter(array_keys($r), function ($k) { return preg_match('/^[a-z_]+$/', $k); });
                try {
                    $pdo->prepare('INSERT INTO ' . $table . ' (' . implode(',', $keys) . ') VALUES (' . implode(',', array_fill(0, count($keys), '?')) . ')')
                        ->execute(array_map(function ($k) use ($r) { return $r[$k]; }, $keys));
                } catch (Exception $e) {
                    // riga non piu' valida (es. utente o etichetta eliminati): si salta
                }
            }
        }
        $pdo->prepare('DELETE FROM books_trash WHERE id = ?')->execute(array((int)$trash_id));
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        return 'Ripristino non riuscito: ' . $e->getMessage();
    }
    return $newid;
}

// Elimina per sempre un elemento del cestino (e la sua copertina, se nessun altro libro la usa)
function trash_purge($trash_id)
{
    $pdo = db();
    $st = $pdo->prepare('SELECT cover_file FROM books_trash WHERE id = ?');
    $st->execute(array((int)$trash_id));
    $cover = $st->fetchColumn();
    if ($cover === false) {
        return false;
    }
    $pdo->prepare('DELETE FROM books_trash WHERE id = ?')->execute(array((int)$trash_id));
    if ($cover) {
        $u = $pdo->prepare('SELECT (SELECT COUNT(*) FROM books WHERE cover_file = ?) + (SELECT COUNT(*) FROM books_trash WHERE cover_file = ?)');
        $u->execute(array($cover, $cover));
        if (!(int)$u->fetchColumn()) {
            cover_delete_file($cover);
        }
    }
    return true;
}

function trash_days()
{
    return max(1, min(365, (int)setting('trash_days', '30')));
}

function trash_auto_purge()
{
    if (!v12_ready()) {
        return 0;
    }
    $st = db()->prepare('SELECT id FROM books_trash WHERE deleted_at < ?');
    $st->execute(array(date('Y-m-d H:i:s', time() - trash_days() * 86400)));
    $n = 0;
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        if (trash_purge($id)) {
            $n++;
        }
    }
    return $n;
}

/* ================= Doppioni ================= */
function dup_key_title($b)
{
    $first = trim(explode(',', (string)$b['authors'])[0]);
    $t = preg_replace('/[^a-z0-9]+/', ' ', str_fold(preg_replace('/\s*[:(\-–].*$/u', '', (string)$b['title'])));
    return trim($t) . '|' . preg_replace('/[^a-z0-9]+/', '', str_fold($first));
}

function dup_ignored()
{
    $l = json_decode(setting('dup_ignore', '[]'), true);
    return is_array($l) ? $l : array();
}

// Gruppi di possibili doppioni: array(array('key' =>, 'reason' =>, 'books' => array(...)))
function dup_groups()
{
    $rows = db()->query('SELECT b.id, b.title, b.subtitle, b.authors, b.publisher, b.pub_year, b.pages, b.isbn13, b.cover_file, b.created_at, b.description, '
        . 'c.name AS cat FROM books b LEFT JOIN categories c ON c.id = b.category_id ORDER BY b.id')->fetchAll();
    $ignored = array_flip(dup_ignored());
    $by_isbn = array();
    $by_title = array();
    foreach ($rows as $r) {
        if ($r['isbn13']) {
            $by_isbn[$r['isbn13']][] = $r;
        }
        $k = dup_key_title($r);
        if (strlen($k) > 3) {
            $by_title[$k][] = $r;
        }
    }
    $groups = array();
    $seen = array();
    foreach ($by_isbn as $isbn => $list) {
        if (count($list) < 2) {
            continue;
        }
        $ids = array_map(function ($b) { return (int)$b['id']; }, $list);
        $key = 'i:' . implode(',', $ids);
        foreach ($ids as $i) {
            $seen[$i] = 1;
        }
        if (!isset($ignored[$key])) {
            $groups[] = array('key' => $key, 'reason' => 'Stesso ISBN ' . $isbn, 'books' => $list);
        }
    }
    foreach ($by_title as $k => $list) {
        if (count($list) < 2) {
            continue;
        }
        $ids = array_map(function ($b) { return (int)$b['id']; }, $list);
        $new = array_filter($ids, function ($i) use ($seen) { return !isset($seen[$i]); });
        if (!$new) {
            continue; // gia' raggruppati per ISBN
        }
        $key = 't:' . implode(',', $ids);
        if (!isset($ignored[$key])) {
            $groups[] = array('key' => $key, 'reason' => 'Stesso titolo e autore', 'books' => $list);
        }
    }
    return $groups;
}

/*
 * Unisce i doppioni nel libro da tenere: completa i dati mancanti, porta stati di lettura, ruote,
 * etichette, campi e prestiti, poi sposta gli altri nel cestino.
 */
function dup_merge($keep_id, $other_ids)
{
    $pdo = db();
    $keep = book_get($keep_id);
    if (!$keep) {
        return 0;
    }
    $n = 0;
    $fill = array('isbn13', 'isbn10', 'subtitle', 'authors', 'publisher', 'pub_year', 'pages', 'language', 'category_id', 'shelf', 'cover_file', 'description', 'notes');
    foreach ($other_ids as $oid) {
        $oid = (int)$oid;
        if ($oid === (int)$keep_id) {
            continue;
        }
        $o = book_get($oid);
        if (!$o) {
            continue;
        }
        $set = array();
        $vals = array();
        foreach ($fill as $c) {
            if (($keep[$c] === null || $keep[$c] === '') && $o[$c] !== null && $o[$c] !== '') {
                $set[] = $c . ' = ?';
                $vals[] = $o[$c];
                $keep[$c] = $o[$c];
            }
        }
        if ($set) {
            $vals[] = (int)$keep_id;
            $pdo->prepare('UPDATE books SET ' . implode(', ', $set) . ' WHERE id = ?')->execute($vals);
        }
        // righe collegate: si copiano solo se il libro da tenere non le ha gia'
        $copy = array(
            'user_books' => array('user_id', 'SELECT COUNT(*) FROM user_books WHERE book_id = ? AND user_id = ?'),
            'wheel_items' => array('user_id', 'SELECT COUNT(*) FROM wheel_items WHERE book_id = ? AND user_id = ?'),
        );
        if (function_exists('extras_ready') && extras_ready()) {
            $copy['book_terms'] = array('term_id', 'SELECT COUNT(*) FROM book_terms WHERE book_id = ? AND term_id = ?');
            $copy['book_field_values'] = array('field_id', 'SELECT COUNT(*) FROM book_field_values WHERE book_id = ? AND field_id = ?');
        }
        foreach ($copy as $table => $c) {
            $st = $pdo->prepare('SELECT * FROM ' . $table . ' WHERE book_id = ?');
            $st->execute(array($oid));
            foreach ($st->fetchAll() as $r) {
                $chk = $pdo->prepare($c[1]);
                $chk->execute(array((int)$keep_id, $r[$c[0]]));
                if ((int)$chk->fetchColumn()) {
                    continue;
                }
                $r['book_id'] = (int)$keep_id;
                $keys = array_keys($r);
                $pdo->prepare('INSERT INTO ' . $table . ' (' . implode(',', $keys) . ') VALUES (' . implode(',', array_fill(0, count($keys), '?')) . ')')
                    ->execute(array_values($r));
            }
        }
        $pdo->prepare('UPDATE wheel_spins SET book_id = ? WHERE book_id = ?')->execute(array((int)$keep_id, $oid));
        if (v12_ready()) {
            $pdo->prepare('UPDATE loans SET book_id = ? WHERE book_id = ?')->execute(array((int)$keep_id, $oid));
        }
        if ((int)setting('db_version', '1') >= 8) {
            // il diario di lettura passa al libro tenuto
            $pdo->prepare('UPDATE reading_sessions SET book_id = ? WHERE book_id = ?')->execute(array((int)$keep_id, $oid));
            $pdo->prepare('UPDATE reading_progress SET book_id = ? WHERE book_id = ?')->execute(array((int)$keep_id, $oid));
        }
        if ($o['cover_file'] && $o['cover_file'] === $keep['cover_file']) {
            // la copertina ora appartiene al libro tenuto: nel cestino non deve essere cancellata insieme all'altro
            $pdo->prepare('UPDATE books SET cover_file = NULL WHERE id = ?')->execute(array($oid));
        }
        book_trash($oid);
        $n++;
    }
    $pdo->prepare('UPDATE books SET updated_at = ? WHERE id = ?')->execute(array(now(), (int)$keep_id));
    return $n;
}

/* ================= Backup automatici e pulizie periodiche ================= */
function auto_backup_options()
{
    return array('off' => 'Disattivati', 'daily' => 'Ogni giorno', 'weekly' => 'Ogni settimana', 'monthly' => 'Ogni mese');
}

function weekday_names()
{
    return array(1 => 'lunedì', 2 => 'martedì', 3 => 'mercoledì', 4 => 'giovedì', 5 => 'venerdì', 6 => 'sabato', 7 => 'domenica');
}

// Momento dell'ultima scadenza programmata (non successiva ad adesso), come timestamp
function auto_backup_slot($now = null)
{
    $now = $now === null ? time() : $now;
    $mode = setting('auto_backup', 'off');
    $hour = max(0, min(23, (int)setting('auto_backup_hour', '3')));
    $today = mktime($hour, 0, 0, (int)date('n', $now), (int)date('j', $now), (int)date('Y', $now));
    if ($mode === 'daily') {
        return $today <= $now ? $today : strtotime('-1 day', $today);
    }
    if ($mode === 'weekly') {
        $wd = max(1, min(7, (int)setting('auto_backup_weekday', '7')));
        $diff = ((int)date('N', $now) - $wd + 7) % 7;
        $slot = strtotime('-' . $diff . ' days', $today);
        return $slot <= $now ? $slot : strtotime('-7 days', $slot);
    }
    if ($mode === 'monthly') {
        $md = max(1, min(28, (int)setting('auto_backup_monthday', '1')));
        $slot = mktime($hour, 0, 0, (int)date('n', $now), $md, (int)date('Y', $now));
        return $slot <= $now ? $slot : mktime($hour, 0, 0, (int)date('n', $now) - 1, $md, (int)date('Y', $now));
    }
    return 0;
}

function auto_backup_next()
{
    $slot = auto_backup_slot();
    if (!$slot) {
        return 0;
    }
    $mode = setting('auto_backup', 'off');
    return $mode === 'daily' ? strtotime('+1 day', $slot) : ($mode === 'weekly' ? strtotime('+7 days', $slot) : strtotime('+1 month', $slot));
}

function auto_backup_due()
{
    $mode = setting('auto_backup', 'off');
    if (!v12_ready() || !isset(auto_backup_options()[$mode]) || $mode === 'off') {
        return false;
    }
    return (int)setting('auto_backup_last', '0') < auto_backup_slot();
}

// Ritorna il nome del backup creato, oppure '' se non era il momento
function auto_backup_run($force = false)
{
    if (!$force && !auto_backup_due()) {
        return '';
    }
    require_once dirname(__FILE__) . '/data_tools.php';
    if (!backup_dir_ready()) {
        return '';
    }
    setting_save('auto_backup_last', (string)time());
    $file = backup_create('auto', setting('auto_backup_full', '0') === '1');
    // si tengono solo gli ultimi N backup automatici
    $keep = max(1, min(30, (int)setting('auto_backup_keep', '5')));
    $autos = array_values(array_filter(backup_list(), function ($b) { return strpos($b['name'], '_auto') !== false; }));
    foreach (array_slice($autos, $keep) as $old) {
        @unlink(BACKUP_DIR . '/' . $old['name']);
    }
    app_log('backup_automatico', $file, 'info', '');
    // copia sulle destinazioni esterne (NAS, SFTP, Nextcloud, Google Drive, Dropbox...)
    if (is_file(dirname(__FILE__) . '/remote_backup.php')) {
        require_once dirname(__FILE__) . '/remote_backup.php';
        if (rb_ready()) {
            rb_send_all($file);
        }
    }
    return $file;
}

/*
 * Lavori periodici eseguiti al termine di una visita qualsiasi (non serve il cron):
 * backup automatico se e' il momento, pulizia del cestino una volta al giorno.
 */
function periodic_tasks()
{
    if (!v12_ready() || !is_dir(DATA_DIR) || !is_writable(DATA_DIR)) {
        return;
    }
    $due_purge = (int)setting('trash_purge_last', '0') < time() - 86400;
    $due_geo = function_exists('fw_geo_due') && fw_geo_due();
    $due_plg = function_exists('plugins_daily_due') && plugins_daily_due();
    if (is_file(APP_ROOT . '/inc/repo.php')) {
        require_once APP_ROOT . '/inc/repo.php';
    }
    $due_repo = function_exists('repo_due') && repo_due();
    if (!$due_purge && !auto_backup_due() && !$due_geo && !$due_plg && !$due_repo) {
        return;
    }
    $lock = @fopen(DATA_DIR . '/periodic.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
        return; // un'altra richiesta ci sta gia' pensando
    }
    load_settings(true);
    try {
        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request(); // la pagina arriva subito al visitatore
        }
        @ignore_user_abort(true);
        if ((int)setting('trash_purge_last', '0') < time() - 86400) {
            setting_save('trash_purge_last', (string)time());
            $n = trash_auto_purge();
            if ($n) {
                app_log('cestino_svuotato', $n . ' libri eliminati definitivamente dopo ' . trash_days() . ' giorni nel cestino', 'info', '');
            }
        }
        auto_backup_run();
        if (function_exists('plugins_daily_run')) {
            plugins_daily_run();
        }
        if (function_exists('repo_due') && repo_due()) {
            repo_controlla(); // solo il controllo: avvisa l'Admin, non installa niente
        }
        if (function_exists('fw_geo_due') && fw_geo_due()) {
            $g = fw_geo_update();
            if (!$g[0]) {
                app_log('firewall_nazioni', 'Aggiornamento del database delle nazioni non riuscito: ' . $g[1], 'warn', '');
            }
        }
    } catch (Exception $e) {
        app_log('lavori_periodici', 'Errore: ' . $e->getMessage(), 'warn', '');
    }
    flock($lock, LOCK_UN);
    fclose($lock);
}
