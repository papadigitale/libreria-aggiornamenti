<?php
/* Media: immagini, PDF, video e audio per le pagine, organizzati in cartelle */
require_once APP_ROOT . '/inc/media.php';
if (!media_ready()) {
    echo '<div class="alert warn">Il database non è ancora aggiornato alla versione 1.8.</div>';
    return;
}
$folders = media_folders();
$fid = get('cartella', 'all');
if ($fid !== 'all' && $fid !== 'none' && !media_folder_get((int)$fid)) {
    $fid = 'all';
}
$q = str_cut(trim(get('q')), 80);
$kind = isset(media_kind_labels()[get('tipo')]) ? get('tipo') : '';
$files = media_list($fid, $q, $kind);
$tot = (int)db()->query('SELECT COUNT(*) FROM media_files')->fetchColumn();
$none = (int)db()->query('SELECT COUNT(*) FROM media_files WHERE folder_id IS NULL')->fetchColumn();
$used = (int)db()->query('SELECT COALESCE(SUM(size),0) FROM media_files')->fetchColumn();
$sel = (int)get('file') ? media_get((int)get('file')) : null;
$self = 'gestione.php?sez=media' . ($fid !== 'all' ? '&cartella=' . rawurlencode($fid) : '');
$furl = function ($f) use ($q, $kind) {
    return 'gestione.php?sez=media' . ($f !== 'all' ? '&cartella=' . rawurlencode($f) : '') . ($q !== '' ? '&q=' . rawurlencode($q) : '') . ($kind !== '' ? '&tipo=' . $kind : '');
};
$kind_icon = array('image' => 'image', 'pdf' => 'pdf', 'video' => 'film', 'audio' => 'music');
$max_ini = function () {
    $v = ini_get('upload_max_filesize');
    $n = (int)$v;
    $u = strtoupper(substr(trim($v), -1));
    return $u === 'G' ? $n * 1024 : ($u === 'M' ? $n : max(1, (int)round($n / 1048576)));
};
?>
<div class="media-layout">
  <aside class="media-side">
    <div class="card">
      <div class="ct"><?= icon('folder', 18) ?> Cartelle</div>
      <a class="mfold <?= $fid === 'all' ? 'on' : '' ?>" href="<?= h($furl('all')) ?>"><span>Tutti i file</span><b><?= $tot ?></b></a>
      <a class="mfold <?= $fid === 'none' ? 'on' : '' ?>" href="<?= h($furl('none')) ?>"><span>Senza cartella</span><b><?= $none ?></b></a>
      <?php foreach ($folders as $f): ?>
      <div class="mfold-row">
        <a class="mfold <?= (string)$fid === (string)$f['id'] ? 'on' : '' ?>" href="<?= h($furl((string)$f['id'])) ?>"><span><?= icon('folder', 15) ?> <?= h($f['name']) ?></span><b><?= (int)$f['n'] ?></b></a>
        <details class="mfold-edit"><summary title="Rinomina o elimina"><?= icon('edit', 14) ?></summary>
          <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="mfolder_rename"><input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
            <input class="input" name="name" value="<?= h($f['name']) ?>" maxlength="80" required aria-label="Nome della cartella">
            <button class="btn ghost small" type="submit">Rinomina</button></form>
          <form method="post" class="stack" data-confirm="Eliminare la cartella &quot;<?= h($f['name']) ?>&quot;? I file non vengono cancellati: vanno nella cartella scelta.">
            <?= csrf_field() ?><input type="hidden" name="action" value="mfolder_del"><input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
            <?php if ((int)$f['n']): ?>
            <label class="lab">Sposta i suoi <?= (int)$f['n'] ?> file in</label>
            <select class="input" name="move_to"><option value="0">Senza cartella</option>
              <?php foreach ($folders as $o): if ((int)$o['id'] === (int)$f['id']) { continue; } ?><option value="<?= (int)$o['id'] ?>"><?= h($o['name']) ?></option><?php endforeach; ?></select>
            <?php endif; ?>
            <button class="btn danger-ghost small" type="submit">Elimina la cartella</button></form>
        </details>
      </div>
      <?php endforeach; ?>
      <form method="post" class="mfold-new"><?= csrf_field() ?><input type="hidden" name="action" value="mfolder_add">
        <input class="input" name="name" maxlength="80" placeholder="Nuova cartella…" required aria-label="Nome della nuova cartella">
        <button class="btn ghost small" type="submit"><?= icon('plus', 15) ?></button></form>
      <p class="hint"><?= media_human_size($used) ?> usati in tutto.</p>
    </div>
  </aside>

  <section class="media-main">
    <form method="post" enctype="multipart/form-data" class="card media-drop" data-media-drop>
      <?= csrf_field() ?><input type="hidden" name="action" value="media_upload"><input type="hidden" name="back" value="<?= h($self) ?>">
      <div class="drop-area" data-drop-area>
        <?= icon('upload', 28) ?>
        <b>Trascina qui i file oppure <label class="linkbtn">sceglili<input type="file" name="files[]" multiple accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.mp4,.mp3" data-drop-input hidden></label></b>
        <small>JPG, PNG, WEBP, GIF, PDF, MP4, MP3 · fino a 50 MB ciascuno<?= $max_ini() < 50 ? ' (il server ora ne accetta al massimo ' . $max_ini() . ' MB)' : '' ?></small>
        <span class="drop-list" data-drop-list></span>
      </div>
      <div class="inline-form" style="margin-top:10px">
        <label for="up-folder">Nella cartella</label>
        <select class="input" id="up-folder" name="folder_id" style="max-width:240px"><option value="0">Senza cartella</option>
          <?php foreach ($folders as $f): ?><option value="<?= (int)$f['id'] ?>" <?= (string)$fid === (string)$f['id'] ? 'selected' : '' ?>><?= h($f['name']) ?></option><?php endforeach; ?></select>
        <button class="btn primary small" type="submit" data-drop-go disabled><?= icon('upload', 15) ?> Carica</button>
      </div>
    </form>

    <?php if ($sel): $usage = media_usage($sel['filename']); ?>
    <div class="card media-detail" id="dettaglio">
      <div class="md-prev">
        <?php if ($sel['kind'] === 'image'): ?><img src="<?= h(media_url($sel['filename'])) ?>" alt="">
        <?php elseif ($sel['kind'] === 'video'): ?><video src="<?= h(media_url($sel['filename'])) ?>" controls preload="metadata"></video>
        <?php elseif ($sel['kind'] === 'audio'): ?><div class="md-ico"><?= icon('music', 48) ?></div><audio src="<?= h(media_url($sel['filename'])) ?>" controls preload="metadata"></audio>
        <?php else: ?><div class="md-ico"><?= icon('pdf', 56) ?></div><a class="btn ghost small" href="<?= h(media_url($sel['filename'])) ?>" target="_blank" rel="noopener">Apri il PDF</a><?php endif; ?>
      </div>
      <div class="md-info">
        <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="media_save"><input type="hidden" name="id" value="<?= (int)$sel['id'] ?>">
          <input type="hidden" name="back" value="<?= h($self . '&file=' . (int)$sel['id']) ?>">
          <label class="lab">Nome</label><input class="input" name="title" value="<?= h($sel['title']) ?>" maxlength="150" required>
          <?php if ($sel['kind'] === 'image'): ?>
          <label class="lab">Testo alternativo (descrive l'immagine a chi non la vede)</label><input class="input" name="alt" value="<?= h($sel['alt']) ?>" maxlength="250">
          <?php endif; ?>
          <label class="lab">Cartella</label>
          <select class="input" name="folder_id"><option value="0">Senza cartella</option>
            <?php foreach ($folders as $f): ?><option value="<?= (int)$f['id'] ?>" <?= (int)$sel['folder_id'] === (int)$f['id'] ? 'selected' : '' ?>><?= h($f['name']) ?></option><?php endforeach; ?></select>
          <div class="savebar"><button class="btn primary small" type="submit">Salva</button>
            <a class="btn link small" href="<?= h($self) ?>">Chiudi</a></div>
        </form>
        <div class="fr row"><span>File</span><span><?= h($sel['original_name']) ?></span></div>
        <div class="fr row"><span>Tipo e peso</span><span><?= h(strtoupper(pathinfo($sel['filename'], PATHINFO_EXTENSION))) ?> · <?= media_human_size((int)$sel['size']) ?><?= $sel['width'] ? ' · ' . (int)$sel['width'] . '×' . (int)$sel['height'] . ' px' : '' ?></span></div>
        <div class="fr row"><span>Caricato</span><span><?= h(fmt_dt($sel['created_at'])) ?><?= $sel['uploaded_by'] ? ' da ' . h($sel['uploaded_by']) : '' ?></span></div>
        <label class="lab">Indirizzo</label>
        <div class="row-btn"><input class="input mono" value="<?= h(media_url($sel['filename'])) ?>" readonly data-copy-src>
          <button class="btn ghost small" type="button" data-copy>Copia</button></div>
        <label class="lab">Codice per una pagina in HTML</label>
        <div class="row-btn"><input class="input mono" value="<?= h(media_embed_code($sel, 'html')) ?>" readonly data-copy-src>
          <button class="btn ghost small" type="button" data-copy>Copia</button></div>
        <p class="hint"><?= $usage ? 'Usato in: ' . implode(', ', array_map(function ($u) { return '<a class="link" href="' . h($u[2]) . '">' . h($u[0] . ' "' . $u[1] . '"') . '</a>'; }, $usage)) : 'Non è usato in nessuna pagina.' ?></p>
        <form method="post" data-confirm="<?= h($usage ? 'Questo file è usato in ' . count($usage) . ' pagin' . (count($usage) === 1 ? 'a' : 'e') . ': lì non si vedrà più. Eliminarlo comunque?' : 'Eliminare definitivamente questo file?') ?>">
          <?= csrf_field() ?><input type="hidden" name="action" value="media_del"><input type="hidden" name="id" value="<?= (int)$sel['id'] ?>"><input type="hidden" name="back" value="<?= h($self) ?>">
          <button class="btn danger-ghost small" type="submit"><?= icon('trash', 15) ?> Elimina il file</button></form>
      </div>
    </div>
    <?php endif; ?>

    <form method="get" class="toolbar"><input type="hidden" name="sez" value="media"><?php if ($fid !== 'all'): ?><input type="hidden" name="cartella" value="<?= h($fid) ?>"><?php endif; ?>
      <input class="input" type="search" name="q" value="<?= h($q) ?>" placeholder="Cerca per nome…" style="max-width:280px">
      <select class="input" name="tipo" style="max-width:160px"><option value="">Tutti i tipi</option>
        <?php foreach (media_kind_labels() as $k => $v): ?><option value="<?= $k ?>" <?= $kind === $k ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?></select>
      <button class="btn ghost small" type="submit">Filtra</button>
      <span class="muted" style="margin-left:auto"><?= count($files) ?> file</span>
    </form>

    <form method="post" data-mbulk>
      <?= csrf_field() ?><input type="hidden" name="action" value="media_bulk"><input type="hidden" name="back" value="<?= h($self) ?>">
      <?php if ($files): ?>
      <div class="bulkbar">
        <label class="check"><input type="checkbox" data-mcheck-all> <span data-mcount>Seleziona</span></label>
        <select class="input" name="op" style="max-width:200px"><option value="move">Sposta nella cartella</option><option value="delete">Elimina</option></select>
        <select class="input" name="folder_id" style="max-width:220px"><option value="0">Senza cartella</option>
          <?php foreach ($folders as $f): ?><option value="<?= (int)$f['id'] ?>"><?= h($f['name']) ?></option><?php endforeach; ?></select>
        <button class="btn primary small" type="submit" data-mgo disabled>Applica</button>
      </div>
      <?php endif; ?>
      <div class="media-grid">
        <?php if (!$files): ?><p class="sub" style="grid-column:1/-1">Nessun file<?= $q !== '' || $kind !== '' ? ' con questi filtri' : ' in questa cartella' ?>. Caricane uno qui sopra.</p><?php endif; ?>
        <?php foreach ($files as $m): ?>
        <div class="mtile <?= $sel && (int)$sel['id'] === (int)$m['id'] ? 'on' : '' ?>">
          <input type="checkbox" name="ids[]" value="<?= (int)$m['id'] ?>" data-mcheck aria-label="Seleziona <?= h($m['title']) ?>">
          <a href="<?= h($self . '&file=' . (int)$m['id']) ?>#dettaglio">
            <span class="mthumb k-<?= h($m['kind']) ?>"><?php if ((int)$m['has_thumb']): ?><img src="<?= h(media_url($m['filename'], true)) ?>" alt="" loading="lazy"><?php else: ?><?= icon($kind_icon[$m['kind']], 34) ?><?php endif; ?></span>
            <span class="mname"><?= h($m['title']) ?></span>
            <small><?= h(strtoupper(pathinfo($m['filename'], PATHINFO_EXTENSION))) ?> · <?= media_human_size((int)$m['size']) ?></small>
          </a>
        </div>
        <?php endforeach; ?>
      </div>
    </form>
  </section>
</div>
