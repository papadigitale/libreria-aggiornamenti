<?php
/*
 * Etichette personalizzate (oltre al Genere), campi personalizzati della scheda libro,
 * righe della pagina iniziale e pagine del sito.
 * Tutte le funzioni restituiscono elenchi vuoti se il database non e' ancora aggiornato.
 */
require_once dirname(__FILE__) . '/books.php';

/* ================= Etichette ================= */
function taxonomies_all($reset = false)
{
    static $cache = null;
    if (!extras_ready()) {
        return array();
    }
    if ($cache === null || $reset) {
        $cache = array();
        foreach (db()->query('SELECT * FROM taxonomies ORDER BY sort_order, name')->fetchAll() as $t) {
            $cache[(int)$t['id']] = $t;
        }
    }
    return $cache;
}

function taxonomy_get($id)
{
    $all = taxonomies_all();
    return isset($all[(int)$id]) ? $all[(int)$id] : null;
}

// Valori di tutte le etichette: array(id_etichetta => array(valori))
function terms_by_taxonomy($reset = false)
{
    static $cache = null;
    if (!extras_ready()) {
        return array();
    }
    if ($cache === null || $reset) {
        $cache = array();
        foreach (db()->query('SELECT id, taxonomy_id, name, sort_order FROM terms ORDER BY sort_order, name')->fetchAll() as $t) {
            $cache[(int)$t['taxonomy_id']][] = $t;
        }
    }
    return $cache;
}

function term_get($id)
{
    if (!extras_ready() || (int)$id <= 0) {
        return null;
    }
    $st = db()->prepare('SELECT t.*, x.name AS taxonomy_name FROM terms t INNER JOIN taxonomies x ON x.id = t.taxonomy_id WHERE t.id = ?');
    $st->execute(array((int)$id));
    $r = $st->fetch();
    return $r ? $r : null;
}

// Crea (se manca) un valore di un'etichetta e ne restituisce l'id
function term_ensure($taxonomy_id, $name)
{
    $name = str_cut(trim(preg_replace('/\s+/', ' ', $name)), 100);
    if ($name === '' || !taxonomy_get($taxonomy_id)) {
        return 0;
    }
    $st = db()->prepare('SELECT id, name FROM terms WHERE taxonomy_id = ?');
    $st->execute(array((int)$taxonomy_id));
    foreach ($st->fetchAll() as $t) {
        if (str_fold($t['name']) === str_fold($name)) {
            return (int)$t['id'];
        }
    }
    db()->prepare('INSERT INTO terms (taxonomy_id, name, sort_order) VALUES (?, ?, 500)')->execute(array((int)$taxonomy_id, $name));
    terms_by_taxonomy(true);
    return (int)db()->lastInsertId();
}

function book_term_ids($book_id)
{
    if (!extras_ready()) {
        return array();
    }
    $st = db()->prepare('SELECT term_id FROM book_terms WHERE book_id = ?');
    $st->execute(array((int)$book_id));
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

// Per un elenco di libri: array(id_libro => array(id_etichetta => array(nomi)))
function books_terms_map($book_ids)
{
    $out = array();
    $book_ids = array_values(array_filter(array_map('intval', (array)$book_ids)));
    if (!$book_ids || !extras_ready()) {
        return $out;
    }
    foreach (array_chunk($book_ids, 500) as $chunk) {
        $st = db()->prepare('SELECT bt.book_id, t.taxonomy_id, t.name FROM book_terms bt INNER JOIN terms t ON t.id = bt.term_id '
            . 'WHERE bt.book_id IN (' . implode(',', array_fill(0, count($chunk), '?')) . ') ORDER BY t.sort_order, t.name');
        $st->execute($chunk);
        foreach ($st->fetchAll() as $r) {
            $out[(int)$r['book_id']][(int)$r['taxonomy_id']][] = $r['name'];
        }
    }
    return $out;
}

/* ================= Campi personalizzati ================= */
function custom_field_types()
{
    return array(
        'text' => 'Testo breve', 'longtext' => 'Testo lungo', 'number' => 'Numero', 'date' => 'Data',
        'bool' => 'Sì / No', 'select' => 'Elenco a scelta', 'url' => 'Indirizzo web',
    );
}

function custom_fields_all($reset = false)
{
    static $cache = null;
    if (!extras_ready()) {
        return array();
    }
    if ($cache === null || $reset) {
        $cache = array();
        foreach (db()->query('SELECT * FROM custom_fields ORDER BY sort_order, name')->fetchAll() as $f) {
            $cache[(int)$f['id']] = $f;
        }
    }
    return $cache;
}

function custom_field_options($f)
{
    $out = array();
    foreach (preg_split('/\r?\n/', (string)$f['options']) as $o) {
        $o = trim($o);
        if ($o !== '' && !in_array($o, $out, true)) {
            $out[] = $o;
        }
    }
    return $out;
}

// Normalizza il valore inserito; '' = vuoto (il valore viene cancellato)
function custom_field_clean($f, $raw)
{
    $raw = is_string($raw) ? trim($raw) : '';
    switch ($f['type']) {
        case 'bool':
            return $raw === '1' ? '1' : '';
        case 'number':
            $n = str_replace(array(' ', '.'), '', $raw);
            $n = str_replace(',', '.', $n);
            if (!preg_match('/^-?\d+(\.\d+)?$/', $n)) {
                // accetta anche "12.50" scritto con il punto decimale
                $n = str_replace(',', '.', str_replace(' ', '', $raw));
                if (!preg_match('/^-?\d+(\.\d+)?$/', $n)) {
                    return '';
                }
            }
            return $n;
        case 'date':
            if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $raw, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
                return $raw;
            }
            if (preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $raw, $m) && checkdate((int)$m[2], (int)$m[1], (int)$m[3])) {
                return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
            }
            return '';
        case 'select':
            return in_array($raw, custom_field_options($f), true) ? $raw : '';
        case 'url':
            return preg_match('#^https?://[^\s<>"]+$#i', $raw) ? str_cut($raw, 500) : '';
        case 'longtext':
            return str_cut($raw, 5000);
        default:
            return str_cut($raw, 255);
    }
}

function custom_field_display($f, $v)
{
    if ($v === '' || $v === null) {
        return '';
    }
    if ($f['type'] === 'bool') {
        return $v === '1' ? 'Sì' : '';
    }
    if ($f['type'] === 'date') {
        return date('d/m/Y', strtotime($v));
    }
    if ($f['type'] === 'number') {
        $dec = strpos($v, '.') !== false ? min(2, strlen(substr($v, strpos($v, '.') + 1))) : 0;
        return number_format((float)$v, $dec, ',', '.');
    }
    return $v;
}

function book_field_values($book_id)
{
    if (!extras_ready()) {
        return array();
    }
    $st = db()->prepare('SELECT field_id, value FROM book_field_values WHERE book_id = ?');
    $st->execute(array((int)$book_id));
    $out = array();
    foreach ($st->fetchAll() as $r) {
        $out[(int)$r['field_id']] = (string)$r['value'];
    }
    return $out;
}

function book_field_set($book_id, $field_id, $value)
{
    db()->prepare('DELETE FROM book_field_values WHERE book_id = ? AND field_id = ?')->execute(array((int)$book_id, (int)$field_id));
    if ($value !== '') {
        db()->prepare('INSERT INTO book_field_values (book_id, field_id, value) VALUES (?,?,?)')->execute(array((int)$book_id, (int)$field_id, $value));
    }
}

/* ================= Salvataggio dal modulo del libro ================= */
// Salva etichette e campi personalizzati inviati dal modulo (solo se il modulo li conteneva)
function book_extras_save($book_id, $in)
{
    if (!extras_ready() || empty($in['extras_present'])) {
        return;
    }
    $pdo = db();
    $tx = isset($in['tx']) && is_array($in['tx']) ? $in['tx'] : array();
    $txnew = isset($in['tx_new']) && is_array($in['tx_new']) ? $in['tx_new'] : array();
    $terms = terms_by_taxonomy();
    foreach (taxonomies_all() as $tid => $t) {
        $valid = array();
        foreach (isset($terms[$tid]) ? $terms[$tid] : array() as $term) {
            $valid[(int)$term['id']] = 1;
        }
        $chosen = array();
        foreach ((array)(isset($tx[$tid]) ? $tx[$tid] : array()) as $v) {
            if (is_scalar($v) && isset($valid[(int)$v])) {
                $chosen[(int)$v] = 1;
            }
        }
        if (isset($txnew[$tid]) && is_string($txnew[$tid]) && trim($txnew[$tid]) !== '') {
            $parts = (int)$t['multiple'] ? explode(',', $txnew[$tid]) : array($txnew[$tid]);
            foreach ($parts as $p) {
                $nid = term_ensure($tid, $p);
                if ($nid) {
                    if (!(int)$t['multiple']) {
                        $chosen = array();
                    }
                    $chosen[$nid] = 1;
                }
            }
        }
        if (!(int)$t['multiple'] && count($chosen) > 1) {
            $chosen = array_slice($chosen, -1, 1, true);
        }
        $pdo->prepare('DELETE FROM book_terms WHERE book_id = ? AND term_id IN (SELECT id FROM terms WHERE taxonomy_id = ?)')
            ->execute(array((int)$book_id, (int)$tid));
        $ins = $pdo->prepare('INSERT INTO book_terms (book_id, term_id) VALUES (?, ?)');
        foreach (array_keys($chosen) as $term_id) {
            $ins->execute(array((int)$book_id, (int)$term_id));
        }
    }
    $cf = isset($in['cf']) && is_array($in['cf']) ? $in['cf'] : array();
    foreach (custom_fields_all() as $fid => $f) {
        book_field_set($book_id, $fid, custom_field_clean($f, isset($cf[$fid]) ? $cf[$fid] : ''));
    }
}

// Campi aggiuntivi nel modulo del libro. $posted = valori reinviati dopo un errore
function book_extras_form_html($book_id, $posted = null)
{
    $taxes = taxonomies_all();
    $fields = custom_fields_all();
    if (!$taxes && !$fields) {
        return '';
    }
    $terms = terms_by_taxonomy();
    $sel = array();
    $vals = array();
    if (is_array($posted) && !empty($posted['extras_present'])) {
        foreach ((array)(isset($posted['tx']) ? $posted['tx'] : array()) as $tid => $list) {
            foreach ((array)$list as $v) {
                $sel[(int)$v] = 1;
            }
        }
        $vals = isset($posted['cf']) && is_array($posted['cf']) ? $posted['cf'] : array();
    } elseif ($book_id) {
        foreach (book_term_ids($book_id) as $id) {
            $sel[$id] = 1;
        }
        $vals = book_field_values($book_id);
    }
    $h = '<input type="hidden" name="extras_present" value="1"><div class="extras">';
    foreach ($taxes as $tid => $t) {
        $list = isset($terms[$tid]) ? $terms[$tid] : array();
        $h .= '<div class="xfield"><span class="lab">' . h($t['name']) . '</span>';
        if ((int)$t['multiple']) {
            $h .= '<div class="tchips">';
            foreach ($list as $term) {
                $on = isset($sel[(int)$term['id']]);
                $h .= '<label class="tchip"><input type="checkbox" name="tx[' . (int)$tid . '][]" value="' . (int)$term['id'] . '"' . ($on ? ' checked' : '') . '>'
                    . '<span>' . h($term['name']) . '</span></label>';
            }
            $h .= '</div><input class="input small" name="tx_new[' . (int)$tid . ']" maxlength="200" placeholder="Nuovo valore (più valori separati da virgola)" aria-label="Nuovo valore per ' . h($t['name']) . '">';
        } else {
            $h .= '<div class="row2"><select class="input" name="tx[' . (int)$tid . '][]" aria-label="' . h($t['name']) . '"><option value="">—</option>';
            foreach ($list as $term) {
                $h .= '<option value="' . (int)$term['id'] . '"' . (isset($sel[(int)$term['id']]) ? ' selected' : '') . '>' . h($term['name']) . '</option>';
            }
            $h .= '</select><input class="input" name="tx_new[' . (int)$tid . ']" maxlength="100" placeholder="oppure un valore nuovo" aria-label="Nuovo valore per ' . h($t['name']) . '"></div>';
        }
        $h .= '</div>';
    }
    foreach ($fields as $fid => $f) {
        $v = isset($vals[$fid]) ? (string)$vals[$fid] : '';
        $id = 'cf-' . (int)$fid;
        $name = 'cf[' . (int)$fid . ']';
        if ($f['type'] === 'bool') {
            $h .= '<label class="check switch"><input type="checkbox" name="' . $name . '" value="1"' . ($v === '1' ? ' checked' : '') . '><span>' . h($f['name']) . '</span></label>';
            continue;
        }
        $h .= '<div class="xfield"><label class="lab" for="' . $id . '">' . h($f['name']) . '</label>';
        if ($f['type'] === 'longtext') {
            $h .= '<textarea class="input" id="' . $id . '" name="' . $name . '" rows="3">' . h($v) . '</textarea>';
        } elseif ($f['type'] === 'select') {
            $h .= '<select class="input" id="' . $id . '" name="' . $name . '"><option value="">—</option>';
            foreach (custom_field_options($f) as $o) {
                $h .= '<option' . ($o === $v ? ' selected' : '') . '>' . h($o) . '</option>';
            }
            $h .= '</select>';
        } else {
            $type = array('number' => 'text', 'date' => 'date', 'url' => 'url');
            $extra = $f['type'] === 'number' ? ' inputmode="decimal"' : '';
            $h .= '<input class="input" id="' . $id . '" type="' . (isset($type[$f['type']]) ? $type[$f['type']] : 'text') . '" name="' . $name . '" value="'
                . h($f['type'] === 'number' ? str_replace('.', ',', $v) : $v) . '" maxlength="500"' . $extra . '>';
        }
        $h .= '</div>';
    }
    return $h . '</div>';
}

// Righe da mostrare nella scheda del libro: array(array(etichetta, valore_html))
function book_extras_display($book_id)
{
    $rows = array();
    $map = books_terms_map(array($book_id));
    $mine = isset($map[(int)$book_id]) ? $map[(int)$book_id] : array();
    foreach (taxonomies_all() as $tid => $t) {
        if ((int)$t['on_card'] && !empty($mine[$tid])) {
            $links = array();
            $terms = terms_by_taxonomy();
            foreach ($mine[$tid] as $name) {
                $tid_term = 0;
                foreach (isset($terms[$tid]) ? $terms[$tid] : array() as $term) {
                    if ($term['name'] === $name) {
                        $tid_term = (int)$term['id'];
                    }
                }
                $links[] = (int)$t['in_filters'] && $tid_term ? '<a class="link" href="libreria.php?et=' . $tid_term . '">' . h($name) . '</a>' : h($name);
            }
            $rows[] = array($t['name'], implode(', ', $links));
        }
    }
    $vals = book_field_values($book_id);
    foreach (custom_fields_all() as $fid => $f) {
        if ((int)$f['on_card'] && isset($vals[$fid]) && $vals[$fid] !== '') {
            $d = custom_field_display($f, $vals[$fid]);
            if ($d === '') {
                continue;
            }
            if ($f['type'] === 'url') {
                $d = '<a class="link" href="' . h($vals[$fid]) . '" target="_blank" rel="noopener noreferrer">' . h(preg_replace('#^https?://(www\.)?#', '', $d)) . '</a>';
            } else {
                $d = nl2br(h($d));
            }
            $rows[] = array($f['name'], $d);
        }
    }
    return $rows;
}

/* ================= Righe della pagina iniziale ================= */
function home_section_kinds()
{
    // tipo => array(nome, parametro richiesto, titolo proposto)
    return array(
        'recent'   => array('Aggiunti di recente', '', 'Aggiunti di recente'),
        'authors'  => array('Tutti i libri per autore, con indice alfabetico', '', 'Tutti i libri per autore'),
        'category' => array('Libri di un genere', 'category', ''),
        'term'     => array('Libri con un valore di un\'etichetta', 'term', ''),
        'status'   => array('I miei libri per stato di lettura', 'status', ''),
        'short'    => array('Libri brevi (fino a N pagine)', 'number', 'Letture brevi'),
        'random'   => array('Libri scelti a caso a ogni visita', '', 'Da riscoprire'),
        'year'     => array('Pubblicati da un certo anno in poi', 'number', 'Edizioni recenti'),
    );
}

function home_sections_all($only_active = true)
{
    if (!extras_ready()) {
        return array();
    }
    return db()->query('SELECT * FROM home_sections' . ($only_active ? ' WHERE active = 1' : '') . ' ORDER BY sort_order, id')->fetchAll();
}

function home_section_describe($s)
{
    $k = home_section_kinds();
    $label = isset($k[$s['kind']]) ? $k[$s['kind']][0] : $s['kind'];
    if ($s['kind'] === 'category') {
        $label .= ': ' . category_name((int)$s['param']);
    } elseif ($s['kind'] === 'term') {
        $t = term_get((int)$s['param']);
        $label .= ': ' . ($t ? $t['taxonomy_name'] . ' → ' . $t['name'] : '(valore eliminato)');
    } elseif ($s['kind'] === 'status') {
        $label .= ': ' . status_label($s['param']);
    } elseif ($s['kind'] === 'short') {
        $label = 'Libri fino a ' . (int)$s['param'] . ' pagine';
    } elseif ($s['kind'] === 'year') {
        $label = 'Pubblicati dal ' . (int)$s['param'] . ' in poi';
    }
    return $label;
}

// Libri di una riga della home
function home_section_books($s, $uid)
{
    $lim = max(1, min(30, (int)$s['max_items']));
    $sel = 'SELECT b.id, b.title, b.authors, b.cover_file, ub.status AS my_status FROM books b '
         . 'LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = ? ';
    $p = array((int)$uid);
    switch ($s['kind']) {
        case 'recent':
            $sql = $sel . 'ORDER BY b.created_at DESC, b.id DESC';
            break;
        case 'category':
            $sql = $sel . 'WHERE b.category_id = ? ORDER BY b.created_at DESC, b.id DESC';
            $p[] = (int)$s['param'];
            break;
        case 'term':
            $sql = $sel . 'INNER JOIN book_terms bt ON bt.book_id = b.id AND bt.term_id = ? ORDER BY b.created_at DESC, b.id DESC';
            $p[] = (int)$s['param'];
            break;
        case 'status':
            if (!is_user()) {
                return array();
            }
            $sql = $sel . 'WHERE ub.status = ? ORDER BY ub.updated_at DESC, b.id DESC';
            $p[] = (string)$s['param'];
            break;
        case 'short':
            $sql = $sel . 'WHERE b.pages > 0 AND b.pages <= ? ORDER BY b.pages ASC, b.title';
            $p[] = max(1, (int)$s['param']);
            break;
        case 'year':
            $sql = $sel . 'WHERE b.pub_year >= ? ORDER BY b.pub_year DESC, b.title';
            $p[] = (int)$s['param'];
            break;
        case 'random':
            $sql = $sel . 'ORDER BY ' . (DB_DRIVER === 'sqlite' ? 'RANDOM()' : 'RAND()');
            break;
        default:
            return array();
    }
    $st = db()->prepare($sql . ' LIMIT ' . $lim);
    $st->execute($p);
    return $st->fetchAll();
}

function home_section_link($s)
{
    switch ($s['kind']) {
        case 'recent':
            return 'libreria.php?ordine=recenti&p=1';
        case 'category':
            return 'libreria.php?cat=' . (int)$s['param'];
        case 'term':
            return 'libreria.php?et=' . (int)$s['param'];
        case 'status':
            return 'libreria.php?stato=' . rawurlencode($s['param']);
        case 'short':
            return 'libreria.php?ordine=pagine&maxpag=' . (int)$s['param'];
        case 'year':
            return 'libreria.php?ordine=anno&dal=' . (int)$s['param'];
    }
    return '';
}

/* ================= Pagine del sito ================= */
function slugify($s)
{
    $s = str_fold($s);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim($s, '-');
    return $s !== '' ? substr($s, 0, 70) : 'pagina';
}

function pages_menu()
{
    if (!extras_ready()) {
        return array();
    }
    $rows = db()->query('SELECT id, slug, title, guests FROM pages WHERE active = 1 AND in_menu = 1 ORDER BY sort_order, title')->fetchAll();
    return array_values(array_filter($rows, function ($p) {
        return is_user() || (int)$p['guests'] === 1;
    }));
}

function page_by_slug($slug)
{
    if (!extras_ready()) {
        return null;
    }
    $st = db()->prepare('SELECT * FROM pages WHERE slug = ?');
    $st->execute(array((string)$slug));
    $p = $st->fetch();
    return $p ? $p : null;
}

// Collegamenti ammessi nel testo delle pagine
function md_safe_url($u)
{
    $u = trim($u);
    if (preg_match('#^(https?://|mailto:)[^\s"<>]+$#i', $u) || preg_match('#^[a-z0-9_\-]+\.php(\?[A-Za-z0-9_=&%+.\-]*)?(\#[A-Za-z0-9_\-]*)?$#', $u)) {
        return $u;
    }
    return '';
}

function md_inline($t)
{
    // il testo arriva gia' convertito con h()
    $t = preg_replace('/`([^`]+)`/', '<code>$1</code>', $t);
    $t = preg_replace('/\*\*(.+?)\*\*/s', '<b>$1</b>', $t);
    $t = preg_replace('/(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?![*\w])/s', '<i>$1</i>', $t);
    // immagini: ![descrizione](indirizzo)
    $t = preg_replace_callback('/!\[([^\]]*)\]\(([^)\s]+)\)/', function ($m) {
        $url = md_safe_url(html_entity_decode($m[2], ENT_QUOTES, 'UTF-8'));
        if ($url !== '' && preg_match('/\.mp4($|[&#])/i', $url)) {
            return '<video src="' . h($url) . '" controls preload="metadata" style="max-width:100%"></video>';
        }
        if ($url !== '' && preg_match('/\.mp3($|[&#])/i', $url)) {
            return '<audio src="' . h($url) . '" controls preload="metadata"></audio>';
        }
        return $url === '' ? $m[1] : '<img src="' . h($url) . '" alt="' . $m[1] . '" loading="lazy">';
    }, $t);
    $t = preg_replace_callback('/(?<!!)\[([^\]]+)\]\(([^)\s]+)\)/', function ($m) {
        $url = md_safe_url(html_entity_decode($m[2], ENT_QUOTES, 'UTF-8'));
        if ($url === '') {
            return $m[1];
        }
        $ext = preg_match('#^https?://#i', $url);
        return '<a class="link" href="' . h($url) . '"' . ($ext ? ' target="_blank" rel="noopener noreferrer"' : '') . '>' . $m[1] . '</a>';
    }, $t);
    return $t;
}

// Markdown essenziale e sicuro: # titoli, **grassetto**, *corsivo*, [link](url), elenchi, > citazioni, --- linea
function md_render($text)
{
    $lines = preg_split('/\r?\n/', (string)$text);
    $html = '';
    $para = array();
    $list = '';
    $flush = function () use (&$para, &$html) {
        if ($para) {
            $html .= '<p>' . implode('<br>', array_map('md_inline', $para)) . '</p>';
            $para = array();
        }
    };
    $close_list = function () use (&$list, &$html) {
        if ($list !== '') {
            $html .= '</' . $list . '>';
            $list = '';
        }
    };
    foreach ($lines as $raw) {
        $l = h(rtrim($raw));
        if (trim($l) === '') {
            $flush();
            $close_list();
            continue;
        }
        if (preg_match('/^(#{1,3})\s+(.*)$/', $l, $m)) {
            $flush();
            $close_list();
            $lv = strlen($m[1]) + 1;
            $html .= '<h' . $lv . '>' . md_inline($m[2]) . '</h' . $lv . '>';
        } elseif (preg_match('/^(-{3,}|\*{3,})$/', trim($l))) {
            $flush();
            $close_list();
            $html .= '<hr>';
        } elseif (preg_match('/^\s*[-*]\s+(.*)$/', $l, $m) || preg_match('/^\s*\d+[.)]\s+(.*)$/', $l, $m2)) {
            $flush();
            $type = isset($m[1]) ? 'ul' : 'ol';
            $content = isset($m[1]) ? $m[1] : $m2[1];
            if ($list !== $type) {
                $close_list();
                $html .= '<' . $type . '>';
                $list = $type;
            }
            $html .= '<li>' . md_inline($content) . '</li>';
        } elseif (preg_match('/^&gt;\s?(.*)$/', $l, $m)) {
            $flush();
            $close_list();
            $html .= '<blockquote>' . md_inline($m[1]) . '</blockquote>';
        } else {
            $close_list();
            $para[] = $l;
        }
    }
    $flush();
    $close_list();
    return str_replace('</blockquote><blockquote>', '<br>', $html);
}

/* ================= Pagine in HTML ================= */
function pages_v4()
{
    return (int)setting('db_version', '1') >= 4;
}

// URL ammessi negli attributi href/src del codice HTML delle pagine
function html_safe_url($u, $is_src)
{
    $u = trim(html_entity_decode((string)$u, ENT_QUOTES, 'UTF-8'));
    $l = strtolower(preg_replace('/[\s\x00-\x1f]+/', '', $u));
    if ($l === '' || $l[0] === '#') {
        return $u;
    }
    if (preg_match('#^(https?:)?//#', $l) || preg_match('#^(mailto|tel):#', $l) && !$is_src) {
        return $u;
    }
    if ($is_src && preg_match('#^data:image/(png|jpe?g|gif|webp);base64,#', $l)) {
        return $u;
    }
    if (preg_match('#^[a-z][a-z0-9+.\-]*:#', $l)) {
        return ''; // javascript:, data:, vbscript: e simili
    }
    return $u; // indirizzo relativo (es. libro.php?id=3, media.php?a=...)
}

/*
 * Ripulisce il codice HTML scritto nelle pagine: restano titoli, testo, elenchi, tabelle, immagini,
 * collegamenti, blocchi con classi e stili; spariscono script, moduli, oggetti incorporati e attributi "on...".
 * (Anche se qualcosa sfuggisse, la Content-Security-Policy del sito impedisce l'esecuzione di script in linea.)
 */
function html_sanitize($html)
{
    $html = (string)$html;
    $allowed = array('a', 'abbr', 'article', 'aside', 'b', 'blockquote', 'br', 'caption', 'cite', 'code', 'col', 'colgroup', 'dd', 'del', 'details',
        'div', 'dl', 'dt', 'em', 'figcaption', 'figure', 'footer', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hr', 'i', 'img', 'ins', 'kbd',
        'li', 'main', 'mark', 'nav', 'ol', 'p', 'picture', 'pre', 'q', 's', 'section', 'small', 'source', 'span', 'strong', 'sub', 'summary', 'sup',
        'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'time', 'tr', 'u', 'ul', 'audio', 'video');
    $drop_with_content = array('script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'form', 'input', 'textarea', 'select',
        'button', 'link', 'meta', 'base', 'svg', 'math', 'template', 'noscript', 'title', 'head');
    $attrs = array('class', 'id', 'style', 'title', 'alt', 'src', 'srcset', 'href', 'width', 'height', 'colspan', 'rowspan', 'target', 'rel',
        'loading', 'lang', 'dir', 'open', 'datetime', 'cite', 'controls', 'poster', 'type', 'start', 'reversed', 'scope', 'align', 'role',
        'aria-label', 'aria-hidden');
    if (!class_exists('DOMDocument')) {
        // senza l'estensione DOM: solo i tag ammessi e niente attributi pericolosi
        foreach ($drop_with_content as $t) {
            $html = preg_replace('#<' . $t . '\b.*?</' . $t . '\s*>#is', '', $html);
        }
        $html = strip_tags($html, '<' . implode('><', $allowed) . '>');
        $html = preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);
        return preg_replace('/(href|src)\s*=\s*(["\']?)\s*(javascript|vbscript|data):[^"\'>\s]*\2/i', '$1="#"', $html);
    }
    $doc = new DOMDocument();
    $prev = libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8"><div id="__radice">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    libxml_use_internal_errors($prev);
    $root = $doc->getElementById('__radice');
    if (!$root) {
        return h($html);
    }
    $clean = function ($node) use (&$clean, $allowed, $drop_with_content, $attrs) {
        for ($i = $node->childNodes->length - 1; $i >= 0; $i--) {
            $c = $node->childNodes->item($i);
            if ($c->nodeType === XML_COMMENT_NODE || $c->nodeType === XML_PI_NODE) {
                $node->removeChild($c);
                continue;
            }
            if ($c->nodeType !== XML_ELEMENT_NODE) {
                continue;
            }
            $tag = strtolower($c->nodeName);
            if (in_array($tag, $drop_with_content, true)) {
                $node->removeChild($c);
                continue;
            }
            $clean($c);
            if (!in_array($tag, $allowed, true)) {
                // tag non ammesso: si tiene il contenuto
                while ($c->firstChild) {
                    $node->insertBefore($c->firstChild, $c);
                }
                $node->removeChild($c);
                continue;
            }
            for ($j = $c->attributes->length - 1; $j >= 0; $j--) {
                $a = $c->attributes->item($j);
                $name = strtolower($a->nodeName);
                $ok = in_array($name, $attrs, true) || preg_match('/^data-[a-z0-9\-]+$/', $name);
                if ($ok && ($name === 'href' || $name === 'src' || $name === 'poster' || $name === 'cite')) {
                    $u = html_safe_url($a->nodeValue, $name !== 'href');
                    $ok = $u !== '';
                }
                if ($ok && $name === 'srcset' && preg_match('/(javascript|vbscript|data):/i', $a->nodeValue)) {
                    $ok = false;
                }
                if ($ok && $name === 'style' && preg_match('/expression\s*\(|javascript:|behavior\s*:|-moz-binding/i', $a->nodeValue)) {
                    $ok = false;
                }
                if (!$ok) {
                    $c->removeAttribute($a->nodeName);
                }
            }
            if ($tag === 'a' && strtolower($c->getAttribute('target')) === '_blank') {
                $c->setAttribute('rel', 'noopener noreferrer');
            }
        }
    };
    $clean($root);
    $out = '';
    foreach ($root->childNodes as $c) {
        $out .= $doc->saveHTML($c);
    }
    return $out;
}

// CSS aggiuntivo di una pagina: non deve poter chiudere il tag <style>
function page_css_clean($css)
{
    $css = str_cut((string)$css, 30000);
    return str_ireplace(array('</style', '<style', '<!--', '-->'), '', $css);
}

function page_render($p)
{
    if (isset($p['format']) && $p['format'] === 'html') {
        return html_sanitize($p['body']);
    }
    return md_render($p['body']);
}
