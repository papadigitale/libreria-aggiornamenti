<?php
/* Valori di un'etichetta personalizzata ($TAX preparato da gestione.php) */
$t = $TAX;
$st = db()->prepare('SELECT t.id, t.name, t.sort_order, COUNT(bt.book_id) AS n FROM terms t LEFT JOIN book_terms bt ON bt.term_id = t.id '
    . 'WHERE t.taxonomy_id = ? GROUP BY t.id, t.name, t.sort_order ORDER BY t.sort_order, t.name');
$st->execute(array((int)$t['id']));
$list = $st->fetchAll();
?>
<div class="adm-grid2 wide-left">
  <div class="card">
    <div class="ct">Valori di "<?= h($t['name']) ?>"</div>
    <p class="sub">Il numero a sinistra decide l'ordine. "Unisci" sposta i libri su un altro valore ed elimina questo.</p>
    <?php if (!$list): ?><p class="hint">Nessun valore ancora: aggiungili qui a destra oppure direttamente dal modulo di un libro.</p><?php endif; ?>
    <table class="tbl terms">
      <thead><tr><th class="num">Ordine</th><th>Nome</th><th class="num">Libri</th><th>Unisci in</th><th class="act"></th></tr></thead>
      <tbody>
      <?php foreach ($list as $term): $fid = 'tf' . (int)$term['id']; ?>
        <tr>
          <td class="num"><input class="input num sm" form="<?= $fid ?>" name="sort_order" value="<?= (int)$term['sort_order'] ?>" inputmode="numeric" aria-label="Ordine"></td>
          <td><input class="input sm" form="<?= $fid ?>" name="name" value="<?= h($term['name']) ?>" maxlength="100" aria-label="Nome"></td>
          <td class="num"><a class="link" href="gestione.php?sez=libri&amp;et=<?= (int)$term['id'] ?>"><?= (int)$term['n'] ?></a></td>
          <td>
            <?php if (count($list) > 1): ?>
            <form method="post" class="inline" data-confirm="Unire &quot;<?= h($term['name']) ?>&quot; al valore scelto? I libri verranno spostati.">
              <?= csrf_field() ?><input type="hidden" name="action" value="term_merge"><input type="hidden" name="taxonomy_id" value="<?= (int)$t['id'] ?>">
              <input type="hidden" name="id" value="<?= (int)$term['id'] ?>">
              <select class="input sm" name="target" aria-label="Unisci in"><option value="">—</option>
                <?php foreach ($list as $o): if ($o['id'] === $term['id']) { continue; } ?><option value="<?= (int)$o['id'] ?>"><?= h($o['name']) ?></option><?php endforeach; ?>
              </select>
              <button class="iconbtn sm" type="submit" title="Unisci"><?= admin_icon('merge', 15) ?></button>
            </form>
            <?php endif; ?>
          </td>
          <td class="act">
            <form method="post" id="<?= $fid ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="term_save">
              <input type="hidden" name="taxonomy_id" value="<?= (int)$t['id'] ?>"><input type="hidden" name="id" value="<?= (int)$term['id'] ?>">
              <button class="iconbtn sm" type="submit" title="Salva"><?= icon('check', 15) ?></button></form>
            <form method="post" class="inline" data-confirm="Eliminare &quot;<?= h($term['name']) ?>&quot;? I <?= (int)$term['n'] ?> libri restano, senza questo valore.">
              <?= csrf_field() ?><input type="hidden" name="action" value="term_del"><input type="hidden" name="taxonomy_id" value="<?= (int)$t['id'] ?>">
              <input type="hidden" name="id" value="<?= (int)$term['id'] ?>">
              <button class="iconbtn sm danger" type="submit" title="Elimina"><?= icon('trash', 15) ?></button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div>
    <form method="post" class="card stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="term_add"><input type="hidden" name="taxonomy_id" value="<?= (int)$t['id'] ?>">
      <div class="ct"><?= icon('plus', 18) ?> Aggiungi valori</div>
      <textarea class="input" name="names" rows="5" required placeholder="Uno per riga" aria-label="Nuovi valori"></textarea>
      <button class="btn primary" type="submit">Aggiungi</button>
    </form>
    <form method="post" class="card stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="tax_save"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
      <input type="hidden" name="back" value="gestione.php?sez=etichetta&amp;id=<?= (int)$t['id'] ?>">
      <div class="ct">Impostazioni dell'etichetta</div>
      <div class="cat-form"><input class="input num" name="sort_order" value="<?= (int)$t['sort_order'] ?>" inputmode="numeric" aria-label="Ordine nel menu">
        <input class="input" name="name" value="<?= h($t['name']) ?>" maxlength="80" required aria-label="Nome"></div>
      <label class="check switch"><input type="checkbox" name="multiple" value="1" <?= (int)$t['multiple'] ? 'checked' : '' ?>><span>Più valori per libro</span></label>
      <label class="check switch"><input type="checkbox" name="in_filters" value="1" <?= (int)$t['in_filters'] ? 'checked' : '' ?>><span>Nei filtri della libreria</span></label>
      <label class="check switch"><input type="checkbox" name="on_card" value="1" <?= (int)$t['on_card'] ? 'checked' : '' ?>><span>Nella scheda del libro</span></label>
      <button class="btn ghost" type="submit">Salva le impostazioni</button>
    </form>
  </div>
</div>
