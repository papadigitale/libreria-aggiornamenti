<?php
/*
 * Azioni del pannello per repository, chiave dell'autore e officina (solo Admin). Ogni ramo termina con un redirect.
 */
require_once dirname(__FILE__) . '/repo.php';
require_once dirname(__FILE__) . '/plugins.php';

function repo_password_ok()
{
    require_once dirname(__FILE__) . '/updater.php';
    if (updater_check_password()) {
        return true;
    }
    app_log('password_errata', 'Password errata per un\'operazione sulla chiave o sul repository', 'alert');
    flash('Password non corretta.', 'error');
    return false;
}

function repo_handle_post($a)
{
    $agg = 'gestione.php?sez=aggiornamento#repository';
    $plg = 'gestione.php?sez=plugin';
    $off = 'gestione.php?sez=pubblica';

    /* ---------- Repository (tutti i siti) ---------- */
    if ($a === 'repo_save') {
        $u = trim(post('repo_url'));
        if ($u !== '' && !repo_url_valida($u)) {
            flash('Indirizzo non valido: deve iniziare con https:// (es. https://raw.githubusercontent.com/utente/repository/main/).', 'error');
            redirect($agg);
        }
        $prima = (string)setting('repo_url', '');
        setting_save('repo_url', $u !== '' ? rtrim($u, '/') . '/' : '');
        setting_save('repo_check', post('repo_check') === '1' ? '1' : '0');
        if ($prima !== $u) {
            // nuovo repository: si riparte da zero con il controllo dei cataloghi
            foreach (array('repo_seq', 'repo_cache', 'repo_error', 'repo_checked_at', 'repo_chiave_proposta') as $k) {
                setting_save($k, '');
            }
            app_log('repository', 'Indirizzo del repository: ' . ($u !== '' ? $u : '(nessuno)'), 'warn');
        }
        load_settings(true);
        if ($u !== '') {
            list($ok, $msg) = repo_controlla();
            flash('Impostazioni salvate. ' . $msg, $ok ? 'success' : 'error');
        } else {
            flash('Repository scollegato.');
        }
        redirect($agg);
    }
    if ($a === 'repo_check') {
        list($ok, $msg) = repo_controlla();
        flash($msg, $ok ? 'success' : 'error');
        redirect($agg);
    }
    if ($a === 'repo_trust') {
        if (!repo_password_ok()) {
            redirect($agg);
        }
        try {
            repo_fidati_chiave(post('impronta'));
            firma_chiave_pubblica(true);
            load_settings(true);
            list($ok, $msg) = repo_controlla();
            flash('Chiave dell\'autore impostata: da ora il sito accetta solo aggiornamenti e plugin firmati con questa chiave. ' . $msg);
        } catch (Exception $e) {
            flash($e->getMessage(), 'error');
        }
        redirect($agg);
    }
    if ($a === 'repo_get_update') {
        require_once dirname(__FILE__) . '/updater.php';
        $nv = repo_aggiornamento();
        if (!$nv) {
            flash('Nessun aggiornamento disponibile.', 'error');
            redirect($agg);
        }
        if (!$nv['compatibile']) {
            flash('La versione ' . $nv['versione'] . ' richiede la ' . $nv['richiede'] . ' o PHP ' . $nv['php_min'] . ': aggiorna prima quelli.', 'error');
            redirect($agg);
        }
        if (IS_DOCKER) {
            flash('Con Docker i programmi si aggiornano ricostruendo l\'immagine (vedi le istruzioni in questa pagina).', 'error');
            redirect($agg);
        }
        $dir = updater_dir();
        if (!is_dir($dir) || !is_writable($dir)) {
            flash('La cartella data/updates non è scrivibile.', 'error');
            redirect($agg);
        }
        try {
            $bin = repo_scarica($nv['file'], $nv['sha256'], $nv['dim']);
        } catch (Exception $e) {
            app_log('aggiornamento_rifiutato', 'Dal repository: ' . $e->getMessage(), 'warn');
            flash($e->getMessage(), 'error');
            redirect($agg);
        }
        $name = 'in_arrivo_' . substr(random_token(4), 0, 8) . '.zip';
        file_put_contents($dir . '/' . $name, $bin);
        if (!empty($_SESSION['upd_pending']) && is_file($dir . '/' . $_SESSION['upd_pending']['file'])) {
            @unlink($dir . '/' . $_SESSION['upd_pending']['file']);
        }
        $r = updater_inspect($dir . '/' . $name);
        if ($r['errors']) {
            @unlink($dir . '/' . $name);
            unset($_SESSION['upd_pending']);
            app_log('aggiornamento_rifiutato', 'Dal repository: ' . implode(' | ', array_slice($r['errors'], 0, 3)), 'warn');
            flash('Pacchetto non installabile: ' . implode(' ', array_slice($r['errors'], 0, 3)), 'error');
            redirect($agg);
        }
        $_SESSION['upd_pending'] = array('file' => $name, 'version' => $r['manifest']['version'], 'rollback' => false);
        app_log('aggiornamento_caricato', 'Versione ' . $r['manifest']['version'] . ' scaricata dal repository e verificata');
        flash('Versione ' . $r['manifest']['version'] . ' scaricata e verificata: controlla il riepilogo e conferma con la password.');
        redirect('gestione.php?sez=aggiornamento');
    }
    if ($a === 'plg_repo_install') {
        $id = post('id');
        $d = repo_dati();
        $p = $d && plugin_id_ok_repo($id) && isset($d['plugin'][$id]) ? $d['plugin'][$id] : null;
        if (!$p) {
            flash('Plugin non trovato nel catalogo: premi «Controlla adesso».', 'error');
            redirect($plg . '#disponibili');
        }
        if (!repo_compatibile($p)) {
            flash('«' . $p['nome'] . '» richiede la versione ' . $p['richiede'] . ' della Libreria: aggiorna prima il sito.', 'error');
            redirect($plg . '#disponibili');
        }
        @mkdir(plugins_dir(), 0775, true);
        $tmp = plugins_dir() . '/.arrivo_' . substr(random_token(4), 0, 8) . '.zip';
        try {
            file_put_contents($tmp, repo_scarica($p['file'], $p['sha256'], $p['dim']));
            $r = plugin_install($tmp);
            @unlink($tmp);
            $row = plugin_get($r[0]);
            if ($row['id'] !== $id) {
                throw new Exception('Il pacchetto non corrisponde al catalogo.');
            }
            app_log('plugin_installato', 'Plugin "' . $row['name'] . '" ' . $row['version'] . ($r[1] ? ' installato' : ' aggiornato (da ' . $r[2] . ')') . ' dal repository', 'warn');
            flash($r[1] ? 'Plugin «' . $row['name'] . '» installato: attivalo qui sotto quando vuoi.' : 'Plugin «' . $row['name'] . '» aggiornato alla versione ' . $row['version'] . '.');
        } catch (Exception $e) {
            @unlink($tmp);
            app_log('plugin_rifiutato', 'Dal repository: ' . $e->getMessage(), 'warn');
            flash('Plugin non installato: ' . $e->getMessage(), 'error');
        }
        redirect($plg);
    }

    /* ---------- Chiave privata: importa (officina), scarica (copia di sicurezza), togli dal server ---------- */
    if ($a === 'key_import') {
        if (!repo_password_ok()) {
            redirect($plg . '#chiave');
        }
        if (firma_pass_bloccata()) {
            flash('Troppe passphrase sbagliate: riprova tra 15 minuti.', 'error');
            redirect($plg . '#chiave');
        }
        if (!isset($_FILES['key_file']) || $_FILES['key_file']['error'] !== UPLOAD_ERR_OK || $_FILES['key_file']['size'] > 20000) {
            flash('Scegli il file chiave_privata.json.', 'error');
            redirect($plg . '#chiave');
        }
        try {
            $imp = firma_importa_privata((string)file_get_contents($_FILES['key_file']['tmp_name']), post('passphrase'));
            flash('Chiave importata (impronta ' . firma_impronta_leggibile($imp) . '). Ora da questo sito puoi firmare e pubblicare.');
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Passphrase') !== false) {
                firma_pass_errata();
            }
            flash('Chiave non importata: ' . $e->getMessage(), 'error');
        }
        redirect($plg . '#chiave');
    }
    if ($a === 'key_export') {
        if (!repo_password_ok() || !firma_privata_presente()) {
            redirect($plg . '#chiave');
        }
        app_log('chiave_privata_scaricata', 'Copia della chiave privata (cifrata) scaricata dal pannello', 'alert');
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="chiave_privata.json"');
        header('Cache-Control: no-store');
        readfile(firma_priv_file());
        exit;
    }
    if ($a === 'key_remove') {
        if (!repo_password_ok()) {
            redirect($plg . '#chiave');
        }
        if (post('conferma') !== 'TOGLI') {
            flash('Scrivi TOGLI nel campo di conferma.', 'error');
            redirect($plg . '#chiave');
        }
        @unlink(firma_priv_file());
        app_log('chiave_privata_tolta', 'Chiave privata dell\'autore tolta da questo server', 'alert');
        flash(firma_privata_presente() ? 'Impossibile cancellare il file: controlla i permessi.' : 'Chiave privata tolta da questo server. Il sito continua a controllare le firme con la chiave pubblica.', firma_privata_presente() ? 'error' : 'success');
        redirect($plg . '#chiave');
    }

    /* ---------- Officina ---------- */
    require_once dirname(__FILE__) . '/pubblica.php';
    if ($a === 'pub_config') {
        $own = trim(post('owner'));
        $rep = trim(post('repo'));
        $br = trim(post('branch')) !== '' ? trim(post('branch')) : 'main';
        if (!preg_match('/^[A-Za-z0-9\-]{1,39}$/', $own) || !preg_match('/^[A-Za-z0-9._\-]{1,100}$/', $rep) || !preg_match('#^[A-Za-z0-9._\-/]{1,100}$#', $br)) {
            flash('Controlla nome utente, nome del repository e ramo (solo lettere, numeri, punto, trattino).', 'error');
            redirect($off);
        }
        setting_save('pub_owner', $own);
        setting_save('pub_repo', $rep);
        setting_save('pub_branch', $br);
        $tok = trim(post('token'));
        if ($tok !== '') {
            if (!preg_match('/^(github_pat_|ghp_)[A-Za-z0-9_]{20,255}$/', $tok)) {
                flash('Il token non sembra un token di GitHub (inizia con github_pat_).', 'error');
                redirect($off);
            }
            setting_save('pub_token', sec_encrypt($tok, 'github'));
        }
        load_settings(true);
        app_log('officina', 'Collegamento a GitHub: ' . $own . '/' . $rep . ' (' . $br . ')', 'warn');
        try {
            flash('Salvato. ' . pub_prova());
        } catch (Exception $e) {
            flash('Salvato, ma la prova non è riuscita: ' . $e->getMessage(), 'error');
        }
        redirect($off);
    }
    if ($a === 'pub_test') {
        try {
            flash(pub_prova());
        } catch (Exception $e) {
            flash($e->getMessage(), 'error');
        }
        redirect($off);
    }
    if ($a === 'pub_publish') {
        if (!isset($_FILES['pacchetto']) || $_FILES['pacchetto']['error'] !== UPLOAD_ERR_OK || $_FILES['pacchetto']['size'] > REPO_MAX_FILE) {
            flash('Scegli il file .zip da pubblicare (al massimo 100 MB).', 'error');
            redirect($off);
        }
        $tmp = pub_dir() . '/in_uscita_' . substr(random_token(4), 0, 8) . '.zip';
        if (!move_uploaded_file($_FILES['pacchetto']['tmp_name'], $tmp)) {
            flash('Caricamento non riuscito.', 'error');
            redirect($off);
        }
        @set_time_limit(300);
        try {
            flash(pub_pubblica($tmp, post('passphrase'), post('note')));
        } catch (Exception $e) {
            app_log('officina', 'Pubblicazione non riuscita: ' . $e->getMessage(), 'warn');
            flash('Pubblicazione non riuscita: ' . $e->getMessage(), 'error');
        }
        @unlink($tmp);
        redirect($off);
    }
    if ($a === 'pub_withdraw') {
        try {
            flash(pub_ritira_plugin(post('id'), post('passphrase')));
        } catch (Exception $e) {
            flash($e->getMessage(), 'error');
        }
        redirect($off);
    }
    redirect('gestione.php');
}
