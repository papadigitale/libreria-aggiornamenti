<?php
/*
 * Richieste HTTP verso internet (ricerca libri e download copertine).
 * Usa cURL se disponibile, altrimenti file_get_contents. Protezioni:
 *  - solo http/https
 *  - niente indirizzi della rete locale (evita che il server venga usato per "sondare" la LAN)
 *  - limite di dimensione e di tempo
 */

// Chi aggiorna il sito senza sostituire CONF/config.php riceve comunque l'elenco dei certificati
if (!defined('CA_BUNDLE')) {
    define('CA_BUNDLE', dirname(APP_ROOT) . '/CONF/cacert.pem');
}

function host_is_public($host)
{
    return host_public_ips($host) !== array();
}

// Indirizzi IPv4 pubblici del sito (vuoto = sito della rete locale, riservato o inesistente)
function host_public_ips($host)
{
    $host = strtolower(trim((string)$host, '[]'));
    if ($host === '' || $host === 'localhost' || substr($host, -6) === '.local' || substr($host, -9) === '.internal') {
        return array();
    }
    if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        return array(); // indirizzi IPv6 scritti a mano: non servono e sono difficili da controllare
    }
    $ips = filter_var($host, FILTER_VALIDATE_IP) ? array($host) : @gethostbynamel($host);
    if (!$ips) {
        return array();
    }
    foreach ($ips as $ip) {
        if (!ip_is_public_v4($ip)) {
            return array(); // basta un indirizzo interno per rifiutare
        }
    }
    return $ips;
}

function ip_is_public_v4($ip)
{
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        return false;
    }
    $n = ip2long($ip);
    // reti speciali che PHP non considera sempre "riservate"
    foreach (array(array('0.0.0.0', 8), array('100.64.0.0', 10), array('127.0.0.0', 8), array('169.254.0.0', 16), array('192.0.0.0', 24),
        array('192.0.2.0', 24), array('198.18.0.0', 15), array('198.51.100.0', 24), array('203.0.113.0', 24), array('224.0.0.0', 3)) as $net) {
        $mask = -1 << (32 - $net[1]);
        if (($n & $mask) === (ip2long($net[0]) & $mask)) {
            return false;
        }
    }
    return true;
}

// Domini da cui si accettano anteprime/copertine senza ulteriori controlli
function host_is_trusted_cover($host)
{
    $host = strtolower($host);
    foreach (array('googleapis.com', 'books.google.com', 'books.google.it', 'googleusercontent.com', 'openlibrary.org', 'archive.org',
        'ibs.it', 'lafeltrinelli.it', 'gr-assets.com', 'goodreads.com', 'media-amazon.com', 'ssl-images-amazon.com', 'images-amazon.com', 'hoepli.it') as $suffix) {
        if ($host === $suffix || substr($host, -strlen('.' . $suffix)) === '.' . $suffix) {
            return true;
        }
    }
    return false;
}

/*
 * Esito: array('code'=>int, 'body'=>string, 'type'=>string, 'error'=>string)
 * $policy: 'api' (host fissi), 'trusted' (solo domini copertine noti), 'public' (qualsiasi host pubblico)
 */
function http_get($url, $timeout = 8, $max_bytes = 6291456, $policy = 'api', $redirects = 3)
{
    $mock = getenv('LIBRERIA_HTTP_MOCK');
    if ($mock && is_dir($mock)) {
        return http_mock($mock, $url);
    }
    $p = parse_url($url);
    if (!$p || !isset($p['scheme'], $p['host']) || !in_array(strtolower($p['scheme']), array('http', 'https'), true)) {
        return array('code' => 0, 'body' => '', 'type' => '', 'error' => 'Indirizzo non valido');
    }
    $host = $p['host'];
    if ($policy === 'trusted' && !host_is_trusted_cover($host)) {
        return array('code' => 0, 'body' => '', 'type' => '', 'error' => 'Sito non ammesso');
    }
    $pinned = array();
    if ($policy !== 'api') {
        $pinned = host_public_ips($host);
        if (!$pinned) {
            return array('code' => 0, 'body' => '', 'type' => '', 'error' => 'Indirizzo non raggiungibile o non ammesso');
        }
    }

    $res = array('code' => 0, 'body' => '', 'type' => '', 'error' => '', 'location' => '');
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $body = '';
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_USERAGENT      => http_user_agent(),
            CURLOPT_HTTPHEADER     => array('Accept-Language: it-IT,it;q=0.9,en;q=0.5'),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_PROTOCOLS      => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_WRITEFUNCTION  => function ($ch, $chunk) use (&$body, $max_bytes) {
                $body .= $chunk;
                return strlen($body) > $max_bytes ? 0 : strlen($chunk);
            },
        ));
        if (HTTP_PROXY_URL !== '') {
            curl_setopt($ch, CURLOPT_PROXY, HTTP_PROXY_URL);
        } elseif ($pinned) {
            // ci si collega proprio all'indirizzo controllato: un DNS "furbo" non puo' dirottare la richiesta verso la rete locale
            $port = isset($p['port']) ? (int)$p['port'] : (strtolower($p['scheme']) === 'https' ? 443 : 80);
            curl_setopt($ch, CURLOPT_RESOLVE, array($host . ':' . $port . ':' . $pinned[0]));
            curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        }
        if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
            curl_setopt($ch, CURLOPT_CAINFO, CA_BUNDLE);
        }
        curl_setopt($ch, CURLOPT_ENCODING, '');
        $ok = curl_exec($ch);
        $res['code'] = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $res['type'] = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $res['location'] = (string)curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        if (!$ok && $res['code'] === 0) {
            $res['error'] = http_error_text(curl_errno($ch), curl_error($ch));
        }
        curl_done($ch);
        $res['body'] = $body;
    } else {
        $opts = array('http' => array('method' => 'GET', 'timeout' => $timeout, 'follow_location' => 0, 'ignore_errors' => true,
            'header' => "User-Agent: " . http_user_agent() . "\r\nAccept-Language: it-IT,it;q=0.9\r\n"));
        if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
            $opts['ssl'] = array('cafile' => CA_BUNDLE, 'verify_peer' => true);
        }
        if (HTTP_PROXY_URL !== '') {
            $opts['http']['proxy'] = HTTP_PROXY_URL;
            $opts['http']['request_fulluri'] = true;
        }
        // con fopen le intestazioni arrivano da stream_get_meta_data (la variabile $http_response_header e' deprecata da PHP 8.5)
        $fp = @fopen($url, 'rb', false, stream_context_create($opts));
        $body = false;
        $headers = array();
        if ($fp) {
            $meta = stream_get_meta_data($fp);
            $headers = isset($meta['wrapper_data']) && is_array($meta['wrapper_data']) ? $meta['wrapper_data'] : array();
            $body = (string)stream_get_contents($fp, $max_bytes);
            fclose($fp);
        }
        foreach ($headers as $hline) {
            if (preg_match('#^HTTP/\S+\s+(\d+)#', $hline, $m)) {
                $res['code'] = (int)$m[1];
            } elseif (stripos($hline, 'Content-Type:') === 0) {
                $res['type'] = trim(substr($hline, 13));
            } elseif (stripos($hline, 'Location:') === 0) {
                $res['location'] = trim(substr($hline, 9));
            }
        }
        $res['body'] = $body === false ? '' : $body;
        if ($body === false && $res['code'] === 0) {
            $res['error'] = 'Connessione non riuscita';
        }
    }
    if ($res['code'] >= 300 && $res['code'] < 400 && $res['location'] !== '' && $redirects > 0) {
        $next = $res['location'];
        if (strpos($next, '//') === 0) {
            $next = $p['scheme'] . ':' . $next;
        } elseif (!preg_match('#^https?://#i', $next)) {
            $next = $p['scheme'] . '://' . $host . (substr($next, 0, 1) === '/' ? '' : '/') . $next;
        }
        return http_get($next, $timeout, $max_bytes, $policy === 'api' ? 'public' : $policy, $redirects - 1);
    }
    return $res;
}

// Modalita' di prova: risponde con file preparati (nome = md5 dell'URL)
function http_mock($dir, $url)
{
    foreach (array_unique(array($url, preg_replace('/\?.*$/', '', $url))) as $u) {
        $base = rtrim($dir, '/') . '/' . md5($u);
        foreach (array('json' => 'application/json', 'jpg' => 'image/jpeg', 'png' => 'image/png', 'zip' => 'application/zip') as $ext => $type) {
            if (is_file($base . '.' . $ext)) {
                return array('code' => 200, 'body' => file_get_contents($base . '.' . $ext), 'type' => $type, 'error' => '');
            }
        }
    }
    @file_put_contents(rtrim($dir, '/') . '/_missing.log', $url . "\n", FILE_APPEND);
    return array('code' => 404, 'body' => '', 'type' => '', 'error' => 'Non trovato');
}

function http_user_agent()
{
    // alcune librerie online rispondono solo a un browser "normale"
    return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 LibreriaDiCasa/1.1';
}

function http_error_text($errno, $err)
{
    if (in_array($errno, array(60, 77, 51, 58), true) || stripos($err, 'certificate') !== false || stripos($err, 'SSL') !== false) {
        return 'certificati HTTPS non verificabili (' . $err . ')';
    }
    if ($errno === 6) {
        return 'nome del sito non risolto: il server non ha accesso a internet o al DNS';
    }
    if ($errno === 7) {
        return 'connessione rifiutata (firewall o proxy?)';
    }
    if ($errno === 28) {
        return 'tempo scaduto';
    }
    return $err !== '' ? $err : 'connessione non riuscita';
}

function http_get_json($url, $timeout = 8)
{
    $r = http_get($url, $timeout, 4194304, 'api');
    if ($r['code'] !== 200) {
        return null;
    }
    $j = json_decode($r['body'], true);
    return is_array($j) ? $j : null;
}
