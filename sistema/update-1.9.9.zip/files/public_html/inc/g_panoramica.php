<?php
$pdo = db();
$tot = $pdo->query("SELECT COUNT(*) AS n, SUM(CASE WHEN cover_file IS NOT NULL AND cover_file <> '' THEN 1 ELSE 0 END) AS cov, "
    . "SUM(COALESCE(pages,0)) AS pg, COUNT(DISTINCT authors) AS au FROM books")->fetch();
$missing = (int)$pdo->query("SELECT COUNT(*) FROM books WHERE (cover_file IS NULL OR cover_file = '') AND isbn13 IS NOT NULL AND isbn13 <> '' "
    . "AND (source IS NULL OR source <> 'senza-copertina')")->fetchColumn();
$byCat = $pdo->query('SELECT COALESCE(c.name, \'Senza genere\') AS name, COUNT(b.id) AS n FROM books b LEFT JOIN categories c ON c.id = b.category_id '
    . 'GROUP BY c.name ORDER BY n DESC')->fetchAll();
$topAuthors = $pdo->query("SELECT authors, COUNT(*) AS n FROM books WHERE authors IS NOT NULL AND authors <> '' GROUP BY authors ORDER BY n DESC, authors LIMIT 5")->fetchAll();
$readers = $pdo->query("SELECT u.display_name, u.username, SUM(CASE WHEN ub.status = 'letto' THEN 1 ELSE 0 END) AS letti, "
    . "SUM(CASE WHEN ub.status = 'in_lettura' THEN 1 ELSE 0 END) AS inlett FROM users u LEFT JOIN user_books ub ON ub.user_id = u.id "
    . "WHERE u.active = 1 GROUP BY u.id, u.display_name, u.username ORDER BY letti DESC")->fetchAll();
$recent = $pdo->query('SELECT b.id, b.title, b.created_at, u.display_name, u.username FROM books b LEFT JOIN users u ON u.id = b.created_by '
    . 'ORDER BY b.created_at DESC, b.id DESC LIMIT 5')->fetchAll();
$maxCat = 1;
foreach ($byCat as $c) {
    $maxCat = max($maxCat, (int)$c['n']);
}
?>
<div class="stats">
  <div class="stat"><b><?= (int)$tot['n'] ?></b><span>libri</span></div>
  <div class="stat"><b><?= (int)$tot['au'] ?></b><span>autori</span></div>
  <div class="stat"><b><?= number_format((int)$tot['pg'], 0, ',', '.') ?></b><span>pagine in tutto</span></div>
  <div class="stat"><b><?= (int)$tot['cov'] ?></b><span>con copertina</span></div>
</div>

<?php if ($missing > 0): ?>
<div class="card" data-fill-covers>
  <div class="ct"><?= icon('image', 18) ?> Copertine mancanti</div>
  <p class="sub"><?= $missing ?> libri con ISBN non hanno ancora la copertina. Il sito può cercarle online una alla volta.</p>
  <div class="progress" hidden><i></i></div>
  <button class="btn primary" type="button" data-fill-start>Cerca le copertine mancanti</button>
</div>
<?php endif; ?>

<div class="card">
  <div class="ct">Libri per genere</div>
  <?php if (!$byCat): ?><p class="sub">Nessun libro ancora.</p><?php endif; ?>
  <?php foreach ($byCat as $c): ?>
  <div class="bar"><span><?= h($c['name']) ?></span><i style="width:<?= max(4, round((int)$c['n'] / $maxCat * 100)) ?>%"></i><b><?= (int)$c['n'] ?></b></div>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="ct">Lettori</div>
  <?php foreach ($readers as $r): ?>
  <div class="fr row"><span><?= h($r['display_name'] !== '' ? $r['display_name'] : $r['username']) ?></span>
    <span class="sub"><?= (int)$r['letti'] ?> letti · <?= (int)$r['inlett'] ?> in lettura</span></div>
  <?php endforeach; ?>
</div>

<?php if ($topAuthors): ?>
<div class="card">
  <div class="ct">Autori più presenti</div>
  <?php foreach ($topAuthors as $a): ?>
  <div class="fr row"><a class="link" href="libreria.php?q=<?= h(rawurlencode($a['authors'])) ?>"><?= h($a['authors']) ?></a><span class="sub"><?= (int)$a['n'] ?></span></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($recent): ?>
<div class="card">
  <div class="ct">Ultimi inserimenti</div>
  <?php foreach ($recent as $r): ?>
  <div class="fr row"><a class="link" href="libro.php?id=<?= (int)$r['id'] ?>"><?= h($r['title']) ?></a>
    <span class="sub"><?= h(date('d/m', strtotime($r['created_at']))) ?><?= $r['username'] ? ' · ' . h($r['display_name'] !== '' ? $r['display_name'] : $r['username']) : '' ?></span></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
