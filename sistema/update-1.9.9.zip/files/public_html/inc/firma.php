<?php
/*
 * Firma dell'autore (Ed25519, estensione sodium di PHP).
 *
 * - CONF/firma_autore.json       chiave PUBBLICA dell'autore: il sito accetta solo plugin (e, se c'e', aggiornamenti) firmati con questa chiave.
 *                                Non viene mai scritta ne' cancellata dagli aggiornamenti o dal pannello: si crea dal server (strumenti/firma.php).
 * - data/firma/chiave_privata.json  chiave PRIVATA, cifrata con la passphrase (Argon2id + XSalsa20-Poly1305). Serve solo a chi firma:
 *                                conviene tenerne una copia sul proprio computer; si puo' anche togliere dal server.
 *
 * La firma di un pacchetto ZIP e' il file firma.json dentro lo ZIP: contiene l'impronta SHA-256 di ogni altro file del pacchetto,
 * cosi' qualsiasi modifica (anche di un solo carattere, o un file aggiunto) rende la firma non valida.
 */

function firma_pub_file()
{
    // con Docker i programmi (e quindi CONF) si ricreano a ogni aggiornamento dell'immagine: la chiave sta nel volume dei dati
    if (defined('IS_DOCKER') && IS_DOCKER && !is_file(dirname(APP_ROOT) . '/CONF/firma_autore.json')) {
        return DATA_DIR . '/firma/firma_autore.json';
    }
    return dirname(APP_ROOT) . '/CONF/firma_autore.json';
}

function firma_priv_file()
{
    return DATA_DIR . '/firma/chiave_privata.json';
}

function firma_disponibile()
{
    return function_exists('sodium_crypto_sign_verify_detached') && function_exists('sodium_crypto_pwhash') && class_exists('ZipArchive');
}

function firma_impronta($pk_bin)
{
    return strtoupper(substr(hash('sha256', 'libreria-di-casa/chiave/' . $pk_bin), 0, 20));
}

function firma_impronta_leggibile($imp)
{
    return trim(chunk_split((string)$imp, 4, ' '));
}

// Chiave pubblica dell'autore (null se non c'e' o non e' valida)
function firma_chiave_pubblica($reset = false)
{
    static $cache = false;
    if ($cache !== false && !$reset) {
        return $cache;
    }
    $f = firma_pub_file();
    $cache = null;
    if (is_file($f)) {
        $d = json_decode((string)@file_get_contents($f), true);
        $pk = is_array($d) && isset($d['chiave']) ? base64_decode((string)$d['chiave'], true) : false;
        if ($pk !== false && strlen($pk) === 32) {
            $cache = array('autore' => isset($d['autore']) ? (string)$d['autore'] : '', 'pk' => $pk, 'impronta' => firma_impronta($pk),
                'creata' => isset($d['creata']) ? (string)$d['creata'] : '');
        }
    }
    return $cache;
}

function firma_privata_presente($file = null)
{
    return is_file($file === null ? firma_priv_file() : $file);
}

/*
 * Crea la coppia di chiavi. Si rifiuta se la chiave pubblica esiste gia' (per cambiarla va tolta a mano dal server).
 * Restituisce l'impronta.
 */
function firma_crea_chiavi($autore, $passphrase, $priv_file = null)
{
    if (!firma_disponibile()) {
        throw new Exception('Serve l\'estensione sodium di PHP (inclusa in PHP 7.2 e successivi).');
    }
    if (is_file(firma_pub_file())) {
        throw new Exception('Esiste già una chiave dell\'autore (' . firma_pub_file() . '). Per sostituirla cancella prima quel file.');
    }
    $autore = trim(preg_replace('/\s+/u', ' ', (string)$autore));
    if ($autore === '' || strlen($autore) > 100) {
        throw new Exception('Scrivi il nome dell\'autore (massimo 100 caratteri).');
    }
    if (strlen((string)$passphrase) < 12) {
        throw new Exception('La passphrase deve avere almeno 12 caratteri (meglio una frase di 4-5 parole).');
    }
    $priv_file = $priv_file === null ? firma_priv_file() : $priv_file;
    $kp = sodium_crypto_sign_keypair();
    $sk = sodium_crypto_sign_secretkey($kp);
    $pk = sodium_crypto_sign_publickey($kp);
    $imp = firma_impronta($pk);
    $salt = random_bytes(SODIUM_CRYPTO_PWHASH_SALTBYTES);
    $ops = SODIUM_CRYPTO_PWHASH_OPSLIMIT_MODERATE;
    $mem = SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE * 2; // 128 MB: lento da indovinare, leggero per il server
    $key = sodium_crypto_pwhash(SODIUM_CRYPTO_SECRETBOX_KEYBYTES, (string)$passphrase, $salt, $ops, $mem, SODIUM_CRYPTO_PWHASH_ALG_ARGON2ID13);
    $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    $priv = array(
        'formato' => 1, 'tipo' => 'chiave-privata-libreria-di-casa', 'autore' => $autore, 'impronta' => $imp,
        'chiave_pubblica' => base64_encode($pk), 'sale' => base64_encode($salt), 'ops' => $ops, 'mem' => $mem,
        'nonce' => base64_encode($nonce), 'cifrata' => base64_encode(sodium_crypto_secretbox($sk, $nonce, $key)),
        'creata' => date('c'),
    );
    $pub = array('formato' => 1, 'autore' => $autore, 'chiave' => base64_encode($pk), 'impronta' => $imp, 'creata' => date('c'));
    if (!is_dir(dirname($priv_file))) {
        @mkdir(dirname($priv_file), 0700, true);
    }
    if (strpos($priv_file, DATA_DIR . '/') === 0 && !is_file(dirname($priv_file) . '/.htaccess')) {
        @file_put_contents(dirname($priv_file) . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    $old = umask(0077);
    $ok = @file_put_contents($priv_file, json_encode($priv, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX);
    umask($old);
    if (!$ok) {
        throw new Exception('Impossibile scrivere la chiave privata in ' . $priv_file);
    }
    @chmod($priv_file, 0600);
    if (!is_dir(dirname(firma_pub_file()))) {
        @mkdir(dirname(firma_pub_file()), 0700, true);
    }
    if (!@file_put_contents(firma_pub_file(), json_encode($pub, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX)) {
        @unlink($priv_file);
        throw new Exception('Impossibile scrivere la chiave pubblica in ' . firma_pub_file());
    }
    @chmod(firma_pub_file(), 0644);
    if (function_exists('sodium_memzero')) {
        sodium_memzero($sk);
        sodium_memzero($key);
    }
    return $imp;
}

// Scrive la chiave PUBBLICA solo se il sito non ne ha ancora una (1.9.8: "fidati della chiave del repository", importazione nell'officina).
// Una chiave gia' presente non si cambia mai dal pannello.
function firma_scrivi_pubblica($autore, $pk)
{
    if (is_file(firma_pub_file())) {
        throw new Exception('Su questo sito c\'è già una chiave dell\'autore: dal pannello non si può cambiare.');
    }
    if (strlen($pk) !== 32) {
        throw new Exception('Chiave non valida.');
    }
    $pub = array('formato' => 1, 'autore' => str_cut(trim((string)$autore), 100), 'chiave' => base64_encode($pk), 'impronta' => firma_impronta($pk), 'creata' => date('c'));
    if (!is_dir(dirname(firma_pub_file()))) {
        @mkdir(dirname(firma_pub_file()), 0755, true);
    }
    if (!@file_put_contents(firma_pub_file(), json_encode($pub, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX)) {
        throw new Exception('Impossibile scrivere ' . firma_pub_file() . ': controlla i permessi della cartella.');
    }
    @chmod(firma_pub_file(), 0644);
    app_log('chiave_autore', 'Chiave dell\'autore impostata: ' . $pub['autore'] . ' (' . firma_impronta_leggibile($pub['impronta']) . ')', 'alert');
    return $pub['impronta'];
}

/*
 * Importa la chiave privata (file chiave_privata.json cifrato) dopo averla aperta con la passphrase.
 * Deve corrispondere alla chiave pubblica del sito; se il sito non ne ha una, la pubblica viene presa da qui.
 */
function firma_importa_privata($raw, $passphrase)
{
    $d = json_decode((string)$raw, true);
    if (!is_array($d) || !isset($d['tipo']) || $d['tipo'] !== 'chiave-privata-libreria-di-casa') {
        throw new Exception('Il file non è una chiave privata della Libreria di Casa (chiave_privata.json).');
    }
    $tmp = DATA_DIR . '/firma_import_' . random_token(6) . '.json';
    @file_put_contents($tmp, $raw);
    try {
        $k = firma_apri_privata($passphrase, $tmp);
    } catch (Exception $e) {
        @unlink($tmp);
        throw $e;
    }
    @unlink($tmp);
    $pub = firma_chiave_pubblica();
    if ($pub && !hash_equals($pub['impronta'], $k[1])) {
        throw new Exception('Questa chiave (impronta ' . firma_impronta_leggibile($k[1]) . ') non è quella del sito (' . firma_impronta_leggibile($pub['impronta']) . ').');
    }
    if (!$pub) {
        firma_scrivi_pubblica($k[2], substr($k[0], 32));
        firma_chiave_pubblica(true);
    }
    $f = firma_priv_file();
    if (!is_dir(dirname($f))) {
        @mkdir(dirname($f), 0700, true);
        @file_put_contents(dirname($f) . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    $old = umask(0077);
    $ok = @file_put_contents($f, $raw, LOCK_EX);
    umask($old);
    if (!$ok) {
        throw new Exception('Impossibile salvare la chiave privata in ' . $f);
    }
    @chmod($f, 0600);
    app_log('chiave_privata_importata', 'Chiave privata dell\'autore importata (' . firma_impronta_leggibile($k[1]) . ')', 'alert');
    if (function_exists('sodium_memzero')) {
        sodium_memzero($k[0]);
    }
    return $k[1];
}

// Apre la chiave privata con la passphrase: restituisce array(sk, impronta, autore)
function firma_apri_privata($passphrase, $file = null)
{
    if (!firma_disponibile()) {
        throw new Exception('Serve l\'estensione sodium di PHP.');
    }
    $file = $file === null ? firma_priv_file() : $file;
    $d = is_file($file) ? json_decode((string)@file_get_contents($file), true) : null;
    if (!is_array($d) || !isset($d['tipo']) || $d['tipo'] !== 'chiave-privata-libreria-di-casa') {
        throw new Exception('Chiave privata non trovata o non valida.');
    }
    $ops = (int)$d['ops'];
    $mem = (int)$d['mem'];
    if ($ops < 1 || $ops > 20 || $mem < 8 * 1048576 || $mem > 1073741824) {
        throw new Exception('Chiave privata non valida.');
    }
    $key = sodium_crypto_pwhash(SODIUM_CRYPTO_SECRETBOX_KEYBYTES, (string)$passphrase, base64_decode($d['sale']), $ops, $mem, SODIUM_CRYPTO_PWHASH_ALG_ARGON2ID13);
    $sk = sodium_crypto_secretbox_open(base64_decode($d['cifrata']), base64_decode($d['nonce']), $key);
    if ($sk === false || strlen($sk) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) {
        throw new Exception('Passphrase non corretta.');
    }
    $pk = substr($sk, 32);
    return array($sk, firma_impronta($pk), (string)$d['autore']);
}

/*
 * Elenco dei file di uno ZIP con l'impronta SHA-256 di ciascuno (tranne firma.json).
 * Rifiuta nomi pericolosi, doppioni e archivi enormi.
 */
function firma_zip_manifesto($zip_path, $max_files = 6000, $max_bytes = 314572800)
{
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        throw new Exception('Il file non è un archivio ZIP valido.');
    }
    $out = array();
    $tot = 0;
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $st = $zip->statIndex($i);
        $name = $st['name'];
        if (substr($name, -1) === '/') {
            continue; // cartella
        }
        if ($name === 'firma.json') {
            continue;
        }
        if (!preg_match('#^[A-Za-z0-9._\-/ ]{1,250}$#', $name) || strpos($name, '..') !== false || $name[0] === '/' || strpos($name, '\\') !== false) {
            $zip->close();
            throw new Exception('Nome di file non ammesso nel pacchetto: ' . $name);
        }
        if (isset($out[$name])) {
            $zip->close();
            throw new Exception('Il pacchetto contiene due volte lo stesso file: ' . $name);
        }
        $tot += (int)$st['size'];
        if (count($out) >= $max_files || $tot > $max_bytes) {
            $zip->close();
            throw new Exception('Il pacchetto è troppo grande.');
        }
        $h = hash_init('sha256');
        $stream = $zip->getStream($name);
        if (!$stream) {
            $zip->close();
            throw new Exception('File non leggibile nel pacchetto: ' . $name);
        }
        while (!feof($stream)) {
            hash_update($h, (string)fread($stream, 262144));
        }
        fclose($stream);
        $out[$name] = hash_final($h);
    }
    $zip->close();
    ksort($out, SORT_STRING);
    return $out;
}

function firma_messaggio($tipo, $impronta, $quando, $files)
{
    $lines = '';
    foreach ($files as $p => $h) {
        $lines .= $h . '  ' . $p . "\n";
    }
    return "libreria-di-casa/firma/v1\n" . $tipo . "\n" . $impronta . "\n" . $quando . "\n" . hash('sha256', $lines);
}

// Riconosce il tipo di pacchetto dal contenuto
function firma_tipo_zip($zip_path)
{
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        return '';
    }
    $t = $zip->locateName('libreria-update.json') !== false ? 'aggiornamento' : ($zip->locateName('plugin.json') !== false ? 'plugin' : '');
    $zip->close();
    return $t;
}

// Firma uno ZIP (aggiunge o sostituisce firma.json). $priv = risultato di firma_apri_privata()
function firma_firma_zip($zip_path, $priv, $tipo = '')
{
    $tipo = $tipo !== '' ? $tipo : firma_tipo_zip($zip_path);
    if (!in_array($tipo, array('aggiornamento', 'plugin'), true)) {
        throw new Exception('Il file non è né un aggiornamento né un plugin della Libreria di Casa.');
    }
    $files = firma_zip_manifesto($zip_path);
    if (!$files) {
        throw new Exception('Il pacchetto è vuoto.');
    }
    $quando = date('c');
    $sig = sodium_crypto_sign_detached(firma_messaggio($tipo, $priv[1], $quando, $files), $priv[0]);
    $doc = array('formato' => 1, 'tipo' => $tipo, 'autore' => $priv[2], 'impronta' => $priv[1], 'firmato_il' => $quando,
        'file' => count($files), 'firma' => base64_encode($sig));
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        throw new Exception('Impossibile aprire il pacchetto per firmarlo.');
    }
    if ($zip->locateName('firma.json') !== false) {
        $zip->deleteName('firma.json');
    }
    $zip->addFromString('firma.json', json_encode($doc, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
    if (!$zip->close()) {
        throw new Exception('Impossibile salvare la firma nel pacchetto.');
    }
    return $doc;
}

/*
 * Verifica la firma di uno ZIP con la chiave dell'autore.
 * Esito: array('stato' => firmato|non_firmato|non_valido|nessuna_chiave|non_disponibile, 'testo' => ..., 'info' => firma.json, 'files' => manifesto)
 */
function firma_verifica_zip($zip_path, $tipo)
{
    $pub = firma_chiave_pubblica();
    $res = array('stato' => '', 'testo' => '', 'info' => null, 'files' => array());
    if (!firma_disponibile()) {
        return array('stato' => 'non_disponibile', 'testo' => 'Il server non ha l\'estensione sodium di PHP: le firme non si possono controllare.') + $res;
    }
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        return array('stato' => 'non_valido', 'testo' => 'Il file non è un archivio ZIP valido.') + $res;
    }
    $raw = $zip->getFromName('firma.json');
    $zip->close();
    if ($raw === false) {
        return array('stato' => $pub ? 'non_firmato' : 'nessuna_chiave', 'testo' => 'Il pacchetto non è firmato.') + $res;
    }
    $d = json_decode($raw, true);
    if (!is_array($d) || !isset($d['tipo'], $d['impronta'], $d['firmato_il'], $d['firma']) || (int)(isset($d['formato']) ? $d['formato'] : 0) !== 1) {
        return array('stato' => 'non_valido', 'testo' => 'Il file della firma è danneggiato.') + $res;
    }
    $res['info'] = $d;
    if ($d['tipo'] !== $tipo) {
        return array('stato' => 'non_valido', 'testo' => 'La firma è di un altro tipo di pacchetto.') + $res;
    }
    if (!$pub) {
        return array('stato' => 'nessuna_chiave', 'testo' => 'Pacchetto firmato da "' . (isset($d['autore']) ? $d['autore'] : '?') . '", ma su questo sito non c\'è la chiave dell\'autore per controllarlo.') + $res;
    }
    if (!hash_equals($pub['impronta'], (string)$d['impronta'])) {
        return array('stato' => 'non_valido', 'testo' => 'Il pacchetto è firmato con un\'altra chiave (impronta ' . firma_impronta_leggibile($d['impronta']) . '), non con quella dell\'autore di questo sito.') + $res;
    }
    try {
        $files = firma_zip_manifesto($zip_path);
    } catch (Exception $e) {
        return array('stato' => 'non_valido', 'testo' => $e->getMessage()) + $res;
    }
    $sig = base64_decode((string)$d['firma'], true);
    if ($sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES
        || !sodium_crypto_sign_verify_detached($sig, firma_messaggio($tipo, $pub['impronta'], (string)$d['firmato_il'], $files), $pub['pk'])) {
        return array('stato' => 'non_valido', 'testo' => 'Firma NON valida: il pacchetto è stato modificato dopo la firma oppure non è dell\'autore.') + $res;
    }
    $res['files'] = $files;
    return array('stato' => 'firmato', 'testo' => 'Firma valida di ' . $pub['autore'] . ' (' . date('d/m/Y H:i', strtotime($d['firmato_il'])) . ').') + $res;
}

// Tentativi di passphrase dal pannello: al massimo 5 errori ogni 15 minuti (per tutto il sito, non per sessione)
function firma_pass_bloccata()
{
    $st = db()->prepare("SELECT COUNT(*) FROM logs WHERE action = 'firma_passphrase_errata' AND created_at >= ?");
    $st->execute(array(date('Y-m-d H:i:s', time() - 900)));
    return (int)$st->fetchColumn() >= 5;
}

function firma_pass_errata()
{
    app_log('firma_passphrase_errata', 'Passphrase della chiave dell\'autore errata', 'alert');
}
