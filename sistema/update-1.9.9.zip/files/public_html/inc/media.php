<?php
/*
 * Media: immagini, PDF, video e audio caricati per le pagine del sito (come la libreria media di WordPress),
 * organizzati in cartelle. I file stanno in data/media (fuori dalla cartella web) e si leggono da media.php?m=...
 * Formati: JPG, PNG, WEBP, GIF, PDF, MP4, MP3 (massimo 50 MB ciascuno). Niente SVG: possono contenere codice.
 */

if (!defined('MEDIA_DIR')) {
    define('MEDIA_DIR', DATA_DIR . '/media');
}
define('MEDIA_MAX_BYTES', 50 * 1048576);

function media_ready()
{
    return (int)setting('db_version', '1') >= 10;
}

function media_types()
{
    return array(
        'jpg' => array('image/jpeg', 'image'), 'jpeg' => array('image/jpeg', 'image'), 'png' => array('image/png', 'image'),
        'webp' => array('image/webp', 'image'), 'gif' => array('image/gif', 'image'), 'pdf' => array('application/pdf', 'pdf'),
        'mp4' => array('video/mp4', 'video'), 'mp3' => array('audio/mpeg', 'audio'),
    );
}

function media_kind_labels()
{
    return array('image' => 'Immagini', 'pdf' => 'PDF', 'video' => 'Video', 'audio' => 'Audio');
}

function media_dir_ready()
{
    foreach (array(MEDIA_DIR, MEDIA_DIR . '/thumbs') as $d) {
        if (!is_dir($d) && !@mkdir($d, 0775, true)) {
            return false;
        }
    }
    if (!is_file(MEDIA_DIR . '/.htaccess')) {
        @file_put_contents(MEDIA_DIR . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return is_writable(MEDIA_DIR);
}

function media_url($file, $thumb = false)
{
    return 'media.php?m=' . rawurlencode($file) . ($thumb ? '&t=1' : '');
}

function media_valid_name($f)
{
    return (bool)preg_match('/^[a-z0-9][a-z0-9\-]{0,80}\.(jpg|jpeg|png|webp|gif|pdf|mp4|mp3)$/', (string)$f);
}

function media_human_size($n)
{
    if ($n >= 1048576) {
        return number_format($n / 1048576, 1, ',', '.') . ' MB';
    }
    return number_format(max(1, $n / 1024), 0, ',', '.') . ' KB';
}

/* ---------- Cartelle ---------- */

function media_folders()
{
    return db()->query('SELECT f.*, (SELECT COUNT(*) FROM media_files m WHERE m.folder_id = f.id) AS n FROM media_folders f ORDER BY f.sort_order, f.name')->fetchAll();
}

function media_folder_get($id)
{
    $st = db()->prepare('SELECT * FROM media_folders WHERE id = ?');
    $st->execute(array((int)$id));
    $r = $st->fetch();
    return $r ? $r : null;
}

function media_folder_name_ok($name)
{
    $name = trim(preg_replace('/\s+/u', ' ', (string)$name));
    return str_cut($name, 80);
}

/* ---------- File ---------- */

function media_get($id)
{
    $st = db()->prepare('SELECT * FROM media_files WHERE id = ?');
    $st->execute(array((int)$id));
    $r = $st->fetch();
    return $r ? $r : null;
}

// Controlla che il contenuto sia davvero del tipo dichiarato dall'estensione
function media_sniff($path, $ext)
{
    $h = (string)@file_get_contents($path, false, null, 0, 16);
    switch ($ext) {
        case 'pdf':
            return substr($h, 0, 5) === '%PDF-';
        case 'mp4':
            return substr($h, 4, 4) === 'ftyp';
        case 'mp3':
            return substr($h, 0, 3) === 'ID3' || (strlen($h) > 1 && ord($h[0]) === 0xFF && (ord($h[1]) & 0xE0) === 0xE0);
        default:
            $info = @getimagesize($path);
            $want = array('jpg' => IMAGETYPE_JPEG, 'jpeg' => IMAGETYPE_JPEG, 'png' => IMAGETYPE_PNG, 'gif' => IMAGETYPE_GIF,
                'webp' => defined('IMAGETYPE_WEBP') ? IMAGETYPE_WEBP : 18);
            return $info && isset($want[$ext]) && $info[2] === $want[$ext];
    }
}

function media_slug($name)
{
    $s = strtolower(str_fold((string)$name));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim(substr($s, 0, 50), '-');
    return $s !== '' ? $s : 'file';
}

/*
 * Salva un file caricato ($f = una voce di $_FILES). Restituisce array(true, id) oppure array(false, messaggio)
 */
function media_store($f, $folder_id = null)
{
    $orig = isset($f['name']) ? (string)$f['name'] : 'file';
    if (!isset($f['error']) || $f['error'] !== UPLOAD_ERR_OK) {
        $e = isset($f['error']) ? (int)$f['error'] : -1;
        return array(false, $orig . ': ' . ($e === UPLOAD_ERR_INI_SIZE || $e === UPLOAD_ERR_FORM_SIZE ? 'file troppo grande per il server.' : 'caricamento non riuscito.'));
    }
    if ($f['size'] > MEDIA_MAX_BYTES) {
        return array(false, $orig . ': supera i 50 MB.');
    }
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $types = media_types();
    if (!isset($types[$ext])) {
        return array(false, $orig . ': formato non ammesso (solo JPG, PNG, WEBP, GIF, PDF, MP4, MP3).');
    }
    if (!media_sniff($f['tmp_name'], $ext)) {
        return array(false, $orig . ': il contenuto non corrisponde a un file ' . strtoupper($ext) . ' valido.');
    }
    if (!media_dir_ready()) {
        return array(false, 'La cartella data/media non esiste o non è scrivibile.');
    }
    if ($ext === 'jpeg') {
        $ext = 'jpg';
    }
    list($mime, $kind) = $types[$ext];
    $base = media_slug(pathinfo($orig, PATHINFO_FILENAME));
    $name = $base . '-' . substr(bin2hex(random_bytes(4)), 0, 6) . '.' . $ext;
    $dest = MEDIA_DIR . '/' . $name;
    $w = null;
    $hgt = null;
    $done = false;
    if ($kind === 'image' && $ext !== 'gif' && function_exists('imagecreatefromstring')) {
        // le foto molto grandi si rimpiccioliscono (il sito non ne ha bisogno e le pagine restano leggere)
        $info = @getimagesize($f['tmp_name']);
        if ($info && $info[0] > 2400) {
            $src = @imagecreatefromstring(file_get_contents($f['tmp_name']));
            if ($src) {
                $nw = 2400;
                $nh = (int)round($info[1] * $nw / $info[0]);
                $dst = imagecreatetruecolor($nw, $nh);
                if ($ext !== 'jpg') {
                    imagealphablending($dst, false);
                    imagesavealpha($dst, true);
                }
                imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $info[0], $info[1]);
                $ok = $ext === 'png' ? imagepng($dst, $dest, 7) : ($ext === 'webp' && function_exists('imagewebp') ? imagewebp($dst, $dest, 85) : imagejpeg($dst, $dest, 86));
                img_free($src);
                img_free($dst);
                $done = (bool)$ok;
            }
        }
    }
    if (!$done && !@move_uploaded_file($f['tmp_name'], $dest) && !@copy($f['tmp_name'], $dest)) {
        return array(false, $orig . ': impossibile salvare il file.');
    }
    @chmod($dest, 0664);
    if ($kind === 'image') {
        $info = @getimagesize($dest);
        if ($info) {
            $w = $info[0];
            $hgt = $info[1];
        }
    }
    $thumb = $kind === 'image' ? media_make_thumb($dest, $name) : 0;
    $title = trim(str_cut(preg_replace('/[_\-]+/', ' ', pathinfo($orig, PATHINFO_FILENAME)), 120));
    $folder_id = $folder_id && media_folder_get($folder_id) ? (int)$folder_id : null;
    db()->prepare('INSERT INTO media_files (folder_id, filename, original_name, title, alt, mime, kind, size, width, height, has_thumb, uploaded_by, created_at) '
        . 'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute(array($folder_id, $name, str_cut($orig, 200), $title !== '' ? $title : $name, '', $mime, $kind, (int)filesize($dest), $w, $hgt, $thumb,
            isset($_SESSION['username']) ? $_SESSION['username'] : null, now()));
    return array(true, (int)db()->lastInsertId());
}

// Miniatura larga 360 px (JPEG, o PNG se l'immagine ha trasparenze)
function media_make_thumb($path, $name)
{
    if (!function_exists('imagecreatefromstring')) {
        return 0;
    }
    $src = @imagecreatefromstring(file_get_contents($path));
    if (!$src) {
        return 0;
    }
    $sw = imagesx($src);
    $sh = imagesy($src);
    $tw = min(360, $sw);
    $th = max(1, (int)round($sh * $tw / $sw));
    $dst = imagecreatetruecolor($tw, $th);
    $png = preg_match('/\.(png|gif|webp)$/', $name);
    if ($png) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $tw, $th, $sw, $sh);
    $ok = $png ? imagepng($dst, MEDIA_DIR . '/thumbs/' . $name . '.png', 8) : imagejpeg($dst, MEDIA_DIR . '/thumbs/' . $name . '.jpg', 80);
    img_free($src);
    img_free($dst);
    return $ok ? 1 : 0;
}

function media_thumb_path($name)
{
    foreach (array('.jpg', '.png') as $e) {
        if (is_file(MEDIA_DIR . '/thumbs/' . $name . $e)) {
            return MEDIA_DIR . '/thumbs/' . $name . $e;
        }
    }
    return '';
}

function media_delete($id)
{
    $m = media_get($id);
    if (!$m) {
        return false;
    }
    if (media_valid_name($m['filename'])) {
        @unlink(MEDIA_DIR . '/' . $m['filename']);
        $t = media_thumb_path($m['filename']);
        if ($t !== '') {
            @unlink($t);
        }
    }
    db()->prepare('DELETE FROM media_files WHERE id = ?')->execute(array((int)$id));
    return true;
}

// Pagine (e impostazioni) che usano il file
function media_usage($filename)
{
    $out = array();
    if (function_exists('extras_ready') && extras_ready()) {
        $st = db()->prepare('SELECT id, title FROM pages WHERE body LIKE ? OR ' . ((int)setting('db_version', '1') >= 4 ? 'css' : 'body') . ' LIKE ?');
        $like = '%' . str_replace(array('%', '_'), array('\\%', '\\_'), $filename) . '%';
        $st->execute(array($like, $like));
        foreach ($st->fetchAll() as $p) {
            $out[] = array('Pagina', $p['title'], 'gestione.php?sez=pagina&id=' . (int)$p['id']);
        }
    }
    if (strpos((string)setting('custom_css'), $filename) !== false) {
        $out[] = array('CSS personalizzato', 'Aspetto', 'gestione.php?sez=aspetto');
    }
    return $out;
}

// Elenco per il pannello e per la finestra "Inserisci da Media"
function media_list($folder = 'all', $q = '', $kind = '', $limit = 500)
{
    $where = array('1=1');
    $args = array();
    if ($folder === 'none') {
        $where[] = 'folder_id IS NULL';
    } elseif ($folder !== 'all' && (int)$folder > 0) {
        $where[] = 'folder_id = ?';
        $args[] = (int)$folder;
    }
    if ($kind !== '' && isset(media_kind_labels()[$kind])) {
        $where[] = 'kind = ?';
        $args[] = $kind;
    }
    if ($q !== '') {
        $where[] = '(title LIKE ? OR original_name LIKE ? OR alt LIKE ?)';
        $like = '%' . $q . '%';
        array_push($args, $like, $like, $like);
    }
    $st = db()->prepare('SELECT * FROM media_files WHERE ' . implode(' AND ', $where) . ' ORDER BY created_at DESC, id DESC LIMIT ' . (int)$limit);
    $st->execute($args);
    return $st->fetchAll();
}

function media_public($m)
{
    return array(
        'id' => (int)$m['id'], 'title' => $m['title'], 'alt' => (string)$m['alt'], 'kind' => $m['kind'], 'name' => $m['filename'],
        'url' => media_url($m['filename']), 'thumb' => (int)$m['has_thumb'] ? media_url($m['filename'], true) : '',
        'w' => $m['width'] ? (int)$m['width'] : null, 'h' => $m['height'] ? (int)$m['height'] : null, 'size' => media_human_size((int)$m['size']),
        'folder' => $m['folder_id'] ? (int)$m['folder_id'] : 0,
    );
}

// Codice da inserire in una pagina (testo semplice o HTML)
function media_embed_code($m, $fmt)
{
    $u = media_url($m['filename']);
    $alt = (string)$m['alt'] !== '' ? $m['alt'] : $m['title'];
    if ($fmt === 'md') {
        return $m['kind'] === 'pdf' ? '[' . $m['title'] . ' (PDF)](' . $u . ')' : '![' . $alt . '](' . $u . ')';
    }
    $a = htmlspecialchars($alt, ENT_QUOTES, 'UTF-8');
    switch ($m['kind']) {
        case 'pdf':
            return '<a href="' . $u . '" target="_blank" rel="noopener">' . htmlspecialchars($m['title'], ENT_QUOTES, 'UTF-8') . ' (PDF)</a>';
        case 'video':
            return '<video src="' . $u . '" controls preload="metadata" style="max-width:100%"></video>';
        case 'audio':
            return '<audio src="' . $u . '" controls preload="metadata"></audio>';
        default:
            return '<img src="' . $u . '" alt="' . $a . '"' . ($m['width'] ? ' width="' . (int)$m['width'] . '" height="' . (int)$m['height'] . '"' : '') . ' loading="lazy">';
    }
}

// Copia un'immagine di Media nella cartella dei file del sito (per logo, sfondo, icona dell'app)
function media_as_upload_file($id)
{
    $m = media_get($id);
    if (!$m || $m['kind'] !== 'image' || !media_valid_name($m['filename']) || !is_file(MEDIA_DIR . '/' . $m['filename'])) {
        return null;
    }
    return array('name' => $m['original_name'], 'tmp_name' => MEDIA_DIR . '/' . $m['filename'], 'error' => UPLOAD_ERR_OK, 'size' => (int)$m['size']);
}
