<?php
$checks = array();
$checks[] = array('Versione PHP', PHP_VERSION . (version_compare(PHP_VERSION, '7.0.0', '<') ? ' (funziona, ma conviene passare a PHP 7.4 o 8)' : ''), version_compare(PHP_VERSION, '7.0.0', '>='), true);
foreach (array('pdo_mysql' => 'Database MySQL (pdo_mysql)', 'curl' => 'Connessioni internet (curl)', 'gd' => 'Elaborazione immagini (gd)',
    'zip' => 'Backup ZIP (zip)', 'mbstring' => 'Testi accentati (mbstring)', 'openssl' => 'HTTPS in uscita (openssl)') as $ext => $label) {
    $ok = extension_loaded($ext);
    $checks[] = array($label, $ok ? 'attiva' : 'non attiva', $ok, in_array($ext, array('curl', 'zip', 'mbstring', 'gd'), true));
}
try {
    $ver = DB_DRIVER === 'sqlite' ? 'SQLite ' . db()->query('select sqlite_version()')->fetchColumn() : db()->query('SELECT VERSION()')->fetchColumn();
    $checks[] = array('Database', $ver . ' su ' . (DB_DRIVER === 'sqlite' ? 'file locale' : DB_HOST), true);
} catch (Exception $e) {
    $checks[] = array('Database', 'errore', false);
}
foreach (array('data/covers' => COVERS_DIR, 'data/uploads' => UPLOADS_DIR, 'data/backup' => BACKUP_DIR) as $label => $dir) {
    $ok = is_dir($dir) && is_writable($dir);
    $checks[] = array('Cartella ' . $label, $ok ? 'scrivibile' : 'NON scrivibile', $ok);
}
$checks[] = array('Cartelle private fuori dal web', is_file(APP_ROOT . '/../CONF/config.php') && !is_file(APP_ROOT . '/config.php') ? 'sì' : 'verificare', true);
$checks[] = array('Collegamento cifrato', is_https() ? 'HTTPS' : 'HTTP (non cifrato)', is_https(), true);
$checks[] = array('Modalità debug', APP_DEBUG ? 'attiva (disattivala in CONF/config.php)' : 'disattivata', !APP_DEBUG, true);
$checks[] = array('Password admin iniziale', (int)db()->query("SELECT COUNT(*) FROM users WHERE username = 'admin' AND must_change_pw = 1")->fetchColumn() ? 'ancora da cambiare' : 'cambiata', true);
$covers = array();
$size = 0;
foreach ((is_dir(COVERS_DIR) ? scandir(COVERS_DIR) : array()) as $f) {
    if (preg_match('/\.(jpg|png|webp)$/', $f)) {
        $covers[] = $f;
        $size += filesize(COVERS_DIR . '/' . $f);
    }
}
$checks[] = array('Copertine salvate', count((array)$covers) . ' file, ' . fmt_bytes($size), true);
?>
<div class="card">
  <div class="ct"><?= icon('gear', 18) ?> Stato del sistema</div>
  <?php foreach ($checks as $c): ?>
  <div class="fr row"><span><?= h($c[0]) ?></span>
    <span class="<?= $c[2] ? 'ok-text' : (!empty($c[3]) ? 'warn-text' : 'err-text') ?>"><?= h($c[1]) ?></span></div>
  <?php endforeach; ?>
</div>
<div class="card">
  <div class="ct">Informazioni</div>
  <div class="fr row"><span>Server web</span><span class="sub"><?= h(isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : '—') ?></span></div>
  <div class="fr row"><span>Indirizzo del server</span><span class="sub"><?= h(isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : '—') ?></span></div>
  <div class="fr row"><span>Il tuo indirizzo</span><span class="sub"><?= h(client_ip()) ?></span></div>
  <div class="fr row"><span>Ora del server</span><span class="sub"><?= h(date('d/m/Y H:i:s')) ?></span></div>
  <div class="fr row"><span>Caricamento massimo file</span><span class="sub"><?= h(ini_get('upload_max_filesize')) ?></span></div>
</div>
