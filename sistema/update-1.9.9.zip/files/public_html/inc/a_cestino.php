<?php
if (!v12_ready()) {
    echo '<div class="alert warn">Il database non è ancora aggiornato alla versione 1.2.</div>';
    return;
}
$items = trash_list();
$days = trash_days();
?>
<div class="card">
  <div class="savebar" style="margin-top:0">
    <p class="sub" style="margin:0 auto 0 0">I libri eliminati restano qui <b><?= $days ?> giorni</b>, con copertina, etichette, stati di lettura e prestiti:
      ripristinandoli tornano esattamente com'erano. Poi vengono eliminati per sempre.</p>
    <?php if ($items): ?>
    <form method="post" data-confirm="Eliminare per sempre tutti i <?= count($items) ?> libri del cestino?"><?= csrf_field() ?><input type="hidden" name="action" value="trash_empty">
      <button class="btn danger-ghost small" type="submit"><?= icon('trash', 15) ?> Svuota il cestino</button></form>
    <?php endif; ?>
  </div>
</div>
<div class="tbl-wrap">
  <table class="tbl">
    <thead><tr><th class="cv"></th><th>Titolo</th><th>Autore</th><th>Eliminato il</th><th>Da</th><th>Eliminato per sempre il</th><th class="act"></th></tr></thead>
    <tbody>
    <?php foreach ($items as $t): $end = strtotime($t['deleted_at']) + $days * 86400; ?>
      <tr>
        <td class="cv"><?= book_cover_html(array('title' => $t['title'], 'authors' => $t['authors'], 'cover_file' => $t['cover_file'] && is_file(COVERS_DIR . '/' . $t['cover_file']) ? $t['cover_file'] : ''), 'cover xs') ?></td>
        <td><b><?= h($t['title']) ?></b></td><td><?= h($t['authors']) ?></td>
        <td class="muted"><?= h(fmt_dt($t['deleted_at'])) ?></td><td class="muted"><?= h((string)$t['deleted_by']) ?></td>
        <td class="muted"><?= h(date('d/m/Y', $end)) ?></td>
        <td class="act">
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="trash_restore"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
            <button class="btn ghost small" type="submit"><?= icon('back', 14) ?> Ripristina</button></form>
          <form method="post" class="inline" data-confirm="Eliminare per sempre &quot;<?= h($t['title']) ?>&quot;?"><?= csrf_field() ?><input type="hidden" name="action" value="trash_purge">
            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>"><button class="iconbtn sm danger" type="submit" title="Elimina per sempre"><?= icon('trash', 15) ?></button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$items): ?><tr><td colspan="7" class="empty-row">Il cestino è vuoto.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<form method="post" class="card inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="trash_days">
  <label for="tr-days">Svuota automaticamente dopo</label>
  <input class="input num sm" id="tr-days" name="days" value="<?= (int)$days ?>" inputmode="numeric"> <span>giorni</span>
  <button class="btn ghost small" type="submit">Salva</button>
</form>
