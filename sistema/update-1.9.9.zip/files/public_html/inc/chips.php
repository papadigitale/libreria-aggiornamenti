<?php
/*
 * Pulsanti sotto la barra di ricerca della Libreria (1.9.4): li sceglie l'Admin in Gestione → Sezioni → Pulsanti della libreria.
 * Ogni pulsante e' un filtro: quelli "personali" (stati di lettura, voti, ruota) li vede solo chi e' registrato.
 * Impostazione lib_chips: elenco JSON di array('t' => tipo, 'n' => nome mostrato, 'on' => 1|0, 'v' => id del genere o del valore dell'etichetta)
 */

// tipo => array(nome predefinito, personale?, descrizione)
function chip_types()
{
    return array(
        'tutti'       => array('Tutti', false, 'Tutta la libreria (sempre presente)'),
        'da_leggere'  => array('Da leggere', true, 'Libri segnati «Da leggere»'),
        'in_lettura'  => array('In lettura', true, 'Libri che stai leggendo'),
        'letto'       => array('Letti', true, 'Libri segnati come letti'),
        'non_letti'   => array('Non letti', true, 'Tutti i libri non segnati come letti'),
        'abbandonato' => array('Abbandonati', true, 'Libri lasciati a metà'),
        'nessuna'     => array('Senza stato', true, 'Libri a cui non hai dato uno stato'),
        'esclusi'     => array('Esclusi dalla ruota', true, 'Libri che la ruota non estrae'),
        'preferiti'   => array('Preferiti', true, 'Letti con voto da 4 stelle in su'),
        'da_valutare' => array('Da valutare', true, 'Letti ma senza voto'),
        'prestati'    => array('Prestati', false, 'Libri fuori casa in questo momento'),
        'recenti'     => array('Arrivati da poco', false, 'Aggiunti negli ultimi 30 giorni'),
        'genere'      => array('', false, 'Un genere a scelta'),
        'etichetta'   => array('', false, 'Un valore di un\'etichetta a scelta'),
    );
}

// Pulsanti come erano fino alla 1.9.3, piu' i nuovi spenti
function chips_default()
{
    $out = array();
    foreach (array('tutti' => 1, 'da_leggere' => 1, 'in_lettura' => 1, 'letto' => 1, 'nessuna' => 1, 'esclusi' => 1, 'non_letti' => 0, 'abbandonato' => 0,
        'preferiti' => 0, 'da_valutare' => 0, 'prestati' => 0, 'recenti' => 0) as $t => $on) {
        $out[] = array('t' => $t, 'n' => chip_types()[$t][0], 'on' => $on, 'v' => 0);
    }
    return $out;
}

// Configurazione salvata (i tipi nuovi delle versioni future si aggiungono spenti in fondo)
function chips_config()
{
    $types = chip_types();
    $c = json_decode((string)setting('lib_chips', ''), true);
    if (!is_array($c) || !$c) {
        return chips_default();
    }
    $out = array();
    $seen = array();
    foreach ($c as $it) {
        if (!is_array($it) || !isset($it['t'], $types[$it['t']])) {
            continue;
        }
        $t = $it['t'];
        $v = isset($it['v']) ? (int)$it['v'] : 0;
        $key = $t . ':' . $v;
        if (isset($seen[$key]) || (($t === 'genere' || $t === 'etichetta') && $v <= 0)) {
            continue;
        }
        $seen[$key] = 1;
        $out[] = array('t' => $t, 'n' => str_cut(trim((string)(isset($it['n']) ? $it['n'] : '')), 40), 'on' => $t === 'tutti' ? 1 : (!empty($it['on']) ? 1 : 0), 'v' => $v);
    }
    foreach (chips_default() as $d) {
        if (!isset($seen[$d['t'] . ':0'])) {
            $d['on'] = $d['t'] === 'tutti' ? 1 : 0;
            $d['t'] === 'tutti' ? array_unshift($out, $d) : ($out[] = $d);
        }
    }
    return $out;
}

// Nome mostrato: quello scelto dall'Admin, altrimenti quello predefinito (per generi ed etichette il loro nome)
function chip_label($c)
{
    if ($c['n'] !== '') {
        return $c['n'];
    }
    if ($c['t'] === 'genere') {
        return function_exists('category_name') ? (string)category_name($c['v']) : 'Genere';
    }
    if ($c['t'] === 'etichetta') {
        $t = function_exists('term_get') ? term_get($c['v']) : null;
        return $t ? $t['name'] : 'Etichetta';
    }
    return chip_types()[$c['t']][0];
}

// Disponibile su questo sito (per esempio i prestiti e i voti arrivano con versioni del database precise)
function chip_available($t)
{
    $db = (int)setting('db_version', '1');
    if ($t === 'prestati') {
        return $db >= 3;
    }
    if ($t === 'preferiti' || $t === 'da_valutare' || $t === 'abbandonato') {
        return $db >= 8;
    }
    return true;
}

/*
 * Pulsanti visibili per chi guarda: array di array(chiave per l'indirizzo, nome, tipo, valore)
 * La chiave e' quella del parametro "stato"; generi ed etichette usano i parametri cat / et gia' esistenti.
 */
function chips_visible()
{
    $types = chip_types();
    $out = array();
    foreach (chips_config() as $c) {
        if (!$c['on'] || !chip_available($c['t']) || ($types[$c['t']][1] && !is_user())) {
            continue;
        }
        if ($c['t'] === 'genere' && !(function_exists('category_name') && category_name($c['v']) !== '')) {
            continue; // genere cancellato
        }
        if ($c['t'] === 'etichetta' && !(function_exists('term_get') && term_get($c['v']))) {
            continue;
        }
        $out[] = array('k' => $c['t'] === 'tutti' ? '' : $c['t'], 'n' => chip_label($c), 't' => $c['t'], 'v' => $c['v']);
    }
    return $out;
}

/*
 * Condizione SQL per un pulsante di stato (tabelle: b = books, ub = user_books dell'utente). Aggiunge i parametri a $params.
 */
function chip_where($k, $uid, &$params)
{
    switch ($k) {
        case 'nessuna':
            return "(ub.status IS NULL OR ub.status = '')";
        case 'da_leggere':
        case 'in_lettura':
        case 'letto':
        case 'abbandonato':
            $params[] = $k;
            return 'ub.status = ?';
        case 'non_letti':
            return "(ub.status IS NULL OR ub.status <> 'letto')";
        case 'esclusi':
            return 'ub.wheel_excluded = 1';
        case 'preferiti':
            $params[] = (int)$uid;
            return "b.id IN (SELECT book_id FROM reading_sessions WHERE user_id = ? AND status = 'letto' AND rating >= 4)";
        case 'da_valutare':
            $params[] = (int)$uid;
            return "ub.status = 'letto' AND b.id NOT IN (SELECT book_id FROM reading_sessions WHERE user_id = ? AND rating IS NOT NULL)";
        case 'prestati':
            return 'b.id IN (SELECT book_id FROM loans WHERE returned_at IS NULL)';
        case 'recenti':
            $params[] = date('Y-m-d H:i:s', time() - 30 * 86400);
            return 'b.created_at >= ?';
    }
    return '';
}
