<?php
/*
 * Libri: ISBN, salvataggio, copertine, stati di lettura personali.
 */
require_once dirname(__FILE__) . '/http.php';

/* ---------- ISBN ---------- */
function isbn_clean($s)
{
    return strtoupper(preg_replace('/[^0-9Xx]/', '', (string)$s));
}

function isbn13_valid($s)
{
    if (!preg_match('/^\d{13}$/', $s)) {
        return false;
    }
    $sum = 0;
    for ($i = 0; $i < 12; $i++) {
        $sum += (int)$s[$i] * ($i % 2 ? 3 : 1);
    }
    return (10 - $sum % 10) % 10 === (int)$s[12];
}

function isbn10_valid($s)
{
    if (!preg_match('/^\d{9}[\dX]$/', $s)) {
        return false;
    }
    $sum = 0;
    for ($i = 0; $i < 10; $i++) {
        $v = $s[$i] === 'X' ? 10 : (int)$s[$i];
        $sum += $v * (10 - $i);
    }
    return $sum % 11 === 0;
}

function isbn10_to_13($s)
{
    $s = isbn_clean($s);
    if (!isbn10_valid($s)) {
        return '';
    }
    $core = '978' . substr($s, 0, 9);
    $sum = 0;
    for ($i = 0; $i < 12; $i++) {
        $sum += (int)$core[$i] * ($i % 2 ? 3 : 1);
    }
    return $core . ((10 - $sum % 10) % 10);
}

function isbn13_to_10($s)
{
    if (!isbn13_valid($s) || strpos($s, '978') !== 0) {
        return '';
    }
    $core = substr($s, 3, 9);
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += (int)$core[$i] * (10 - $i);
    }
    $c = (11 - $sum % 11) % 11;
    return $core . ($c === 10 ? 'X' : (string)$c);
}

// Qualsiasi ISBN valido (10 o 13) -> ISBN-13; stringa vuota se non valido
function isbn_to13($raw)
{
    $s = isbn_clean($raw);
    if (strlen($s) === 13 && isbn13_valid($s)) {
        return $s;
    }
    if (strlen($s) === 10) {
        return isbn10_to_13($s);
    }
    return '';
}

function isbn_format($s)
{
    if (strlen($s) === 13) {
        return substr($s, 0, 3) . '-' . substr($s, 3, 2) . '-' . substr($s, 5, 3) . '-' . substr($s, 8, 4) . '-' . substr($s, 12);
    }
    return $s;
}

/* ---------- Categorie ---------- */
function categories_all($reset = false)
{
    static $cache = null;
    if ($cache === null || $reset) {
        $cache = db()->query('SELECT id, name, sort_order FROM categories ORDER BY sort_order, name')->fetchAll();
    }
    return $cache;
}

function category_name($id)
{
    foreach (categories_all() as $c) {
        if ((int)$c['id'] === (int)$id) {
            return $c['name'];
        }
    }
    return '';
}

/* ---------- Libri ---------- */
function book_get($id)
{
    $st = db()->prepare('SELECT * FROM books WHERE id = ?');
    $st->execute(array((int)$id));
    $b = $st->fetch();
    return $b ? $b : null;
}

function book_fields_from_input($in)
{
    $f = array();
    $f['title'] = str_cut(trim(isset($in['title']) ? $in['title'] : ''), 255);
    $f['subtitle'] = str_cut(trim(isset($in['subtitle']) ? $in['subtitle'] : ''), 255);
    $f['authors'] = str_cut(trim(isset($in['authors']) ? $in['authors'] : ''), 255);
    $f['publisher'] = str_cut(trim(isset($in['publisher']) ? $in['publisher'] : ''), 150);
    $y = preg_replace('/\D/', '', isset($in['pub_year']) ? $in['pub_year'] : '');
    $f['pub_year'] = ($y !== '' && (int)$y > 0 && (int)$y <= (int)date('Y') + 2) ? (int)$y : null;
    $p = preg_replace('/\D/', '', isset($in['pages']) ? $in['pages'] : '');
    $f['pages'] = ($p !== '' && (int)$p > 0 && (int)$p < 100000) ? (int)$p : null;
    $raw = isbn_clean(isset($in['isbn']) ? $in['isbn'] : '');
    $f['isbn13'] = isbn_to13($raw);
    $f['isbn10'] = $f['isbn13'] !== '' ? isbn13_to_10($f['isbn13']) : '';
    if ($f['isbn13'] === '') {
        $f['isbn13'] = null;
    }
    if ($f['isbn10'] === '') {
        $f['isbn10'] = null;
    }
    $f['_isbn_raw'] = $raw;
    $f['language'] = str_cut(preg_replace('/[^a-zA-Z\-]/', '', isset($in['language']) ? $in['language'] : ''), 10);
    $c = (int)(isset($in['category_id']) ? $in['category_id'] : 0);
    $f['category_id'] = ($c > 0 && category_name($c) !== '') ? $c : null;
    $f['shelf'] = str_cut(trim(isset($in['shelf']) ? $in['shelf'] : ''), 100);
    $f['description'] = str_cut(trim(isset($in['description']) ? $in['description'] : ''), 5000);
    $f['notes'] = str_cut(trim(isset($in['notes']) ? $in['notes'] : ''), 5000);
    return $f;
}

function book_validate($f)
{
    if ($f['title'] === '') {
        return 'Il titolo è obbligatorio.';
    }
    if ($f['_isbn_raw'] !== '' && $f['isbn13'] === null) {
        return 'Il codice ISBN inserito non è valido (controlla le cifre).';
    }
    return '';
}

function book_insert($f, $source)
{
    $pdo = db();
    $pdo->prepare('INSERT INTO books (isbn13, isbn10, title, subtitle, authors, publisher, pub_year, pages, language, category_id, shelf, '
        . 'description, notes, source, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute(array($f['isbn13'], $f['isbn10'], $f['title'], $f['subtitle'], $f['authors'], $f['publisher'], $f['pub_year'], $f['pages'],
            $f['language'], $f['category_id'], $f['shelf'], $f['description'], $f['notes'], str_cut($source, 30), current_uid() ? current_uid() : null, now(), now()));
    $id = (int)$pdo->lastInsertId();
    if (function_exists('lib_do')) {
        // dopo la fine della pagina: il libro ha gia' copertina, etichette e campi
        register_shutdown_function('lib_do', 'libro_salvato', $id, true);
    }
    return $id;
}

function book_update($id, $f)
{
    db()->prepare('UPDATE books SET isbn13=?, isbn10=?, title=?, subtitle=?, authors=?, publisher=?, pub_year=?, pages=?, language=?, category_id=?, '
        . 'shelf=?, description=?, notes=?, updated_at=? WHERE id=?')
        ->execute(array($f['isbn13'], $f['isbn10'], $f['title'], $f['subtitle'], $f['authors'], $f['publisher'], $f['pub_year'], $f['pages'],
            $f['language'], $f['category_id'], $f['shelf'], $f['description'], $f['notes'], now(), (int)$id));
    if (function_exists('lib_do')) {
        register_shutdown_function('lib_do', 'libro_salvato', (int)$id, false);
    }
}

function book_delete($id)
{
    $b = book_get($id);
    if (!$b) {
        return;
    }
    db()->prepare('DELETE FROM books WHERE id = ?')->execute(array((int)$id));
    cover_delete_file($b['cover_file']);
    if (function_exists('lib_do')) {
        register_shutdown_function('lib_do', 'libro_eliminato', (int)$id);
    }
}

function books_with_isbn($isbn13, $except_id = 0)
{
    if (!$isbn13) {
        return array();
    }
    $st = db()->prepare('SELECT id, title FROM books WHERE isbn13 = ? AND id <> ?');
    $st->execute(array($isbn13, (int)$except_id));
    return $st->fetchAll();
}

/* ---------- Copertine ---------- */
function cover_delete_file($file)
{
    if ($file && preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $file) && is_file(COVERS_DIR . '/' . $file)) {
        @unlink(COVERS_DIR . '/' . $file);
    }
}

/*
 * Salva un'immagine (contenuto binario) come copertina del libro.
 * L'immagine viene verificata e, se c'e' la libreria GD, ridimensionata e ricodificata in JPEG
 * (questo elimina eventuali contenuti estranei nascosti nel file).
 */
function cover_store_binary($bin, $book_id)
{
    if (strlen($bin) < 200) {
        return array(false, 'Immagine vuota o non valida.');
    }
    $info = @getimagesizefromstring($bin);
    if (!$info || !in_array($info[2], array(IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, defined('IMAGETYPE_WEBP') ? IMAGETYPE_WEBP : -1), true)) {
        return array(false, 'Il file non è un\'immagine JPG, PNG o WEBP.');
    }
    if ($info[0] < 40 || $info[1] < 40) {
        return array(false, 'Immagine troppo piccola (probabilmente non è una copertina).');
    }
    if (!is_dir(COVERS_DIR)) {
        @mkdir(COVERS_DIR, 0775, true);
    }
    $name = 'b' . (int)$book_id . '_' . substr(random_token(6), 0, 10);
    if (function_exists('imagecreatefromstring')) {
        $src = @imagecreatefromstring($bin);
        if (!$src) {
            return array(false, 'Immagine non leggibile.');
        }
        $w = imagesx($src);
        $hgt = imagesy($src);
        $maxw = 700;
        $nw = $w > $maxw ? $maxw : $w;
        $nh = (int)round($hgt * $nw / $w);
        $dst = imagecreatetruecolor($nw, $nh);
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $hgt);
        $file = $name . '.jpg';
        $ok = imagejpeg($dst, COVERS_DIR . '/' . $file, 85);
        img_free($src);
        img_free($dst);
        if (!$ok) {
            return array(false, 'Impossibile salvare la copertina: controlla che la cartella data/covers sia scrivibile.');
        }
    } else {
        $ext = $info[2] === IMAGETYPE_PNG ? 'png' : ($info[2] === IMAGETYPE_JPEG ? 'jpg' : 'webp');
        $file = $name . '.' . $ext;
        if (@file_put_contents(COVERS_DIR . '/' . $file, $bin) === false) {
            return array(false, 'Impossibile salvare la copertina: controlla che la cartella data/covers sia scrivibile.');
        }
    }
    $old = db()->prepare('SELECT cover_file FROM books WHERE id = ?');
    $old->execute(array((int)$book_id));
    $old_file = $old->fetchColumn();
    db()->prepare('UPDATE books SET cover_file = ?, updated_at = ? WHERE id = ?')->execute(array($file, now(), (int)$book_id));
    if ($old_file && $old_file !== $file) {
        cover_delete_file($old_file);
    }
    return array(true, $file);
}

// Prova gli URL in ordine finche' uno funziona. $policy: 'trusted' (dalla ricerca) o 'public' (URL scritto a mano)
function cover_store_from_urls($urls, $book_id, $policy = 'trusted')
{
    $last = 'Nessuna copertina disponibile.';
    foreach ((array)$urls as $u) {
        $u = trim((string)$u);
        if ($u === '') {
            continue;
        }
        $r = http_get($u, setting_int('lookup_timeout', 3, 30), 6291456, $policy);
        if ($r['code'] === 200 && $r['body'] !== '') {
            $res = cover_store_binary($r['body'], $book_id);
            if ($res[0]) {
                return $res;
            }
            $last = $res[1];
        } else {
            $last = 'Copertina non scaricabile' . ($r['error'] !== '' ? ': ' . $r['error'] : '') . '.';
        }
    }
    return array(false, $last);
}

function cover_store_upload($file, $book_id)
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return array(false, '');
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return array(false, $file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE
            ? 'Immagine troppo grande.' : 'Caricamento non riuscito.');
    }
    if ($file['size'] > 12 * 1024 * 1024) {
        return array(false, 'Immagine troppo grande (massimo 12 MB).');
    }
    return cover_store_binary(file_get_contents($file['tmp_name']), $book_id);
}

/*
 * Copertina "tipografica" usata quando manca l'immagine: colori calcolati dal titolo,
 * cosi' ogni libro ha sempre lo stesso aspetto.
 */
function cover_palette($title)
{
    $p = array(
        array('#5b1a1a', '#2a0c0c', '#e9d6a8'), array('#1f4d3a', '#0f2a20', '#f0d78c'), array('#2d4f8a', '#18294d', '#f3efe2'),
        array('#7c6a9e', '#4b3d66', '#ffffff'), array('#262b33', '#11141a', '#e6c27a'), array('#c06a3b', '#8a4322', '#fff1df'),
        array('#c9a76b', '#9b7a42', '#2b1d14'), array('#3d5a6c', '#22343f', '#f0e6d0'), array('#8a2f3c', '#541a23', '#f5e6c8'),
        array('#5d6b47', '#3a4429', '#f3ebdd'), array('#d8d2c4', '#b9b1a0', '#2a2a2a'), array('#3e7d6b', '#245246', '#fff6e0'),
    );
    return $p[abs(crc32((string)$title)) % count($p)];
}

function book_cover_html($b, $class = 'cover')
{
    if (!empty($b['cover_file'])) {
        return '<div class="' . h($class) . ' has-img"><img src="' . h(cover_url($b['cover_file'])) . '" alt="Copertina di ' . h($b['title'])
             . '" loading="lazy" decoding="async"></div>';
    }
    $c = cover_palette($b['title']);
    $author = isset($b['authors']) ? $b['authors'] : '';
    $first = trim(explode(',', $author)[0]);
    return '<div class="' . h($class) . ' typo" style="background:linear-gradient(160deg,' . $c[0] . ',' . $c[1] . ');color:' . $c[2] . '">'
         . '<span class="ca">' . h(str_cut($first, 40)) . '</span><span class="cl"></span><span class="ct">' . h(str_cut($b['title'], 80)) . '</span></div>';
}

/* ---------- Ordinamento per autore ---------- */
function str_fold($s)
{
    // minuscolo e senza accenti, per confronti e ordinamenti
    $s = function_exists('mb_strtolower') ? mb_strtolower((string)$s, 'UTF-8') : strtolower((string)$s);
    return strtr($s, array('à' => 'a', 'á' => 'a', 'â' => 'a', 'ä' => 'a', 'ã' => 'a', 'å' => 'a', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e',
        'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'ö' => 'o', 'õ' => 'o', 'ø' => 'o',
        'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'ç' => 'c', 'ñ' => 'n', 'ß' => 'ss', 'œ' => 'oe', 'æ' => 'ae', 'š' => 's', 'ž' => 'z', 'č' => 'c'));
}

/*
 * Cognome del primo autore: "Charles Dickens" -> "Dickens", "Dickens, Charles" -> "Dickens".
 * Restituisce array(chiave di ordinamento, lettera dell'indice)
 */
function author_sort_info($authors)
{
    $first = trim(preg_split('/\s*(?:;|\s&\s|\se\s(?=[A-ZÀ-Ý]))\s*/u', (string)$authors)[0]);
    if ($first === '') {
        return array('~', '#');
    }
    // forma "Cognome, Nome" (cognome di una parola, o con particella: "Tomasi di Lampedusa, Giuseppe")
    // e' diversa da un elenco "Italo Calvino, Esther Calvino"
    $inverted = false;
    if (preg_match('/^([^,]+),\s*([^,]+)/u', $first, $m)) {
        $sw = preg_split('/\s+/u', trim($m[1]));
        $inverted = count($sw) === 1 || (count($sw) <= 3 && preg_match('/\s(di|de|da|del|della|van|von|der|le|la|du)\s/u', ' ' . trim($m[1]) . ' '));
    }
    if ($inverted) {
        $surname = trim($m[1]);
        $given = trim($m[2]);
    } else {
        $first = trim(explode(',', $first)[0]);
        $words = preg_split('/\s+/u', $first);
        $surname = array_pop($words);
        $given = implode(' ', $words);
    }
    $key = str_fold($surname . ' ' . $given);
    $letter = strtoupper(substr(str_fold($surname), 0, 1));
    if (!preg_match('/^[A-Z]$/', $letter)) {
        $letter = '#';
    }
    return array($key, $letter);
}

/* ---------- Stato di lettura personale ---------- */
function user_book_row($uid, $book_id)
{
    $st = db()->prepare('SELECT * FROM user_books WHERE user_id = ? AND book_id = ?');
    $st->execute(array((int)$uid, (int)$book_id));
    $r = $st->fetch();
    return $r ? $r : array('status' => '', 'wheel_excluded' => 0, 'started_at' => null, 'finished_at' => null);
}

function user_book_save($uid, $book_id, $status = null, $excluded = null)
{
    // con il diario di lettura (versione 1.6) lo stato passa dalle letture, che ne tengono la storia
    if (function_exists('reading_ready') || is_file(dirname(__FILE__) . '/reading.php')) {
        require_once dirname(__FILE__) . '/reading.php';
        if (reading_ready()) {
            $cur = user_book_row($uid, $book_id);
            if ($status !== null && $status !== (string)$cur['status']) {
                reading_set_status($uid, $book_id, $status);
            }
            if ($excluded !== null) {
                if (!isset(user_book_row($uid, $book_id)['user_id'])) {
                    reading_sync_user_book($uid, $book_id, '');
                }
                db()->prepare('UPDATE user_books SET wheel_excluded = ?, updated_at = ? WHERE user_id = ? AND book_id = ?')
                    ->execute(array($excluded ? 1 : 0, now(), (int)$uid, (int)$book_id));
            }
            return;
        }
    }
    $cur = user_book_row($uid, $book_id);
    $exists = isset($cur['user_id']);
    $statuses = reading_statuses();
    $new_status = $status === null ? (string)$cur['status'] : (isset($statuses[$status]) ? $status : ''); // '' = nessuna etichetta
    $new_excl = $excluded !== null ? ($excluded ? 1 : 0) : (int)$cur['wheel_excluded'];
    $started = $cur['started_at'];
    $finished = $cur['finished_at'];
    if ($new_status !== $cur['status']) {
        if ($new_status === 'in_lettura') {
            $started = date('Y-m-d');
            $finished = null;
        } elseif ($new_status === 'letto') {
            $finished = date('Y-m-d');
            if (!$started) {
                $started = null;
            }
        } else {
            $started = null;
            $finished = null;
        }
    }
    if ($exists) {
        db()->prepare('UPDATE user_books SET status=?, wheel_excluded=?, started_at=?, finished_at=?, updated_at=? WHERE user_id=? AND book_id=?')
            ->execute(array($new_status, $new_excl, $started, $finished, now(), (int)$uid, (int)$book_id));
    } else {
        db()->prepare('INSERT INTO user_books (user_id, book_id, status, wheel_excluded, started_at, finished_at, updated_at) VALUES (?,?,?,?,?,?,?)')
            ->execute(array((int)$uid, (int)$book_id, $new_status, $new_excl, $started, $finished, now()));
    }
}

function status_label($s)
{
    $all = reading_statuses();
    return isset($all[$s]) ? $all[$s] : 'Nessuna etichetta';
}
