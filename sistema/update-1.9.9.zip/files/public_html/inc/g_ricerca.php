<?= settings_form_open('ricerca') ?>
  <div class="ct"><?= icon('cloud', 18) ?> Piattaforme per cercare i libri</div>
  <p class="sub">Quando inserisci un ISBN il sito interroga queste fonti nell'ordine e unisce i dati trovati; con il titolo le consulta tutte
    e ti propone le edizioni.</p>
  <?= render_setting('lookup_google') ?>
  <?= render_setting('lookup_shops') ?>
  <?= render_setting('lookup_sbn') ?>
  <?= render_setting('lookup_goodreads') ?>
  <p class="hint">Goodreads ha chiuso le sue API nel 2020: il sito legge la pagina pubblica del libro. Le condizioni d'uso di Goodreads non
    prevedono la lettura automatica e il sito può bloccarla o cambiare formato, quindi questa fonte è disattivata finché non la accendi tu.</p>
  <?= render_setting('lookup_openlib') ?>
  <?= render_setting('lookup_amazon') ?>
  <?= render_setting('lookup_lang') ?>
  <?= render_setting('google_api_key') ?>
  <p class="hint">Senza chiave Google limita le ricerche e risponde "errore 429". La chiave è gratuita: console.cloud.google.com → nuovo progetto →
    "API e servizi" → "Libreria" → <b>Books API</b> → Abilita → "Credenziali" → "Crea credenziali" → <b>Chiave API</b>. Incollala qui e premi Salva.</p>
  <?= render_setting('lookup_timeout') ?>
  <button class="btn primary" type="submit">Salva</button>
</form>

<form method="post" class="card stack">
  <?= csrf_field() ?><input type="hidden" name="action" value="test_lookup">
  <div class="ct">Prova la ricerca</div>
  <p class="sub">Verifica che il server riesca a raggiungere internet e le piattaforme.</p>
  <input class="input" name="isbn" inputmode="numeric" placeholder="ISBN di prova (vuoto = Il nome della rosa)" value="<?= h(post('isbn')) ?>">
  <button class="btn ghost" type="submit">Prova adesso</button>
  <?php if ($test_result !== null && !empty($test_result['report'])): ?>
    <div class="card src-report">
      <div class="fk">Esito per fonte</div>
      <?php foreach ($test_result['report'] as $rep): ?>
      <div class="fr row"><span><?= h($rep['source']) ?></span>
        <span class="<?= $rep['status'] === 'ok' ? 'ok-text' : ($rep['status'] === 'errore' ? 'err-text' : 'warn-text') ?>">
          <?= h($rep['status'] === 'ok' ? 'trovato' : ($rep['status'] === 'vuoto' ? 'non presente' : 'errore')) ?><?= $rep['detail'] !== '' ? ' – ' . h($rep['detail']) : '' ?></span></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <?php if ($test_result !== null): ?>
    <?php if (!empty($test_result['ok'])): $tb = $test_result['book']; ?>
      <div class="alert success">Funziona (<?= (int)$test_result['ms'] ?> ms). Trovato: <b><?= h($tb['title']) ?></b> — <?= h($tb['authors']) ?>,
        <?= h($tb['publisher']) ?> <?= h($tb['year']) ?>, <?= h($tb['pages']) ?> pagine. Fonte: <?= h($tb['source']) ?>. Copertine trovate: <?= count($tb['covers']) ?>.</div>
    <?php else: ?>
      <div class="alert error"><?= h(isset($test_result['error']) ? $test_result['error'] : 'Nessuna risposta') ?>
        (<?= (int)$test_result['ms'] ?> ms). Se il problema è la connessione, verifica che il web server possa uscire su internet
        o imposta il proxy in <code>CONF/config.php</code>.</div>
    <?php endif; ?>
  <?php endif; ?>
</form>
