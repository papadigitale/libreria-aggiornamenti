<?php
$pdo = db();
$used = array();
foreach ($pdo->query("SELECT cover_file FROM books WHERE cover_file IS NOT NULL AND cover_file <> ''")->fetchAll(PDO::FETCH_COLUMN) as $f) {
    $used[$f] = 1;
}
$files = 0;
$size = 0;
$orph = 0;
$orph_size = 0;
foreach ((is_dir(COVERS_DIR) ? scandir(COVERS_DIR) : array()) as $f) {
    if (!preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $f)) {
        continue;
    }
    $s = filesize(COVERS_DIR . '/' . $f);
    $files++;
    $size += $s;
    if (!isset($used[$f])) {
        $orph++;
        $orph_size += $s;
    }
}
$uploads = array();
foreach ((is_dir(UPLOADS_DIR) ? scandir(UPLOADS_DIR) : array()) as $f) {
    if (preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $f)) {
        $uploads[] = array($f, filesize(UPLOADS_DIR . '/' . $f), in_array($f, array(setting('logo_file'), setting('bg_image'), setting('app_icon_file')), true));
    }
}
$missing = (int)$pdo->query("SELECT COUNT(*) FROM books WHERE (cover_file IS NULL OR cover_file = '') AND isbn13 IS NOT NULL AND isbn13 <> '' "
    . "AND (source IS NULL OR source <> 'senza-copertina')")->fetchColumn();
$nocover = $pdo->query("SELECT id, title, authors, isbn13, cover_file FROM books WHERE cover_file IS NULL OR cover_file = '' ORDER BY title LIMIT 60")->fetchAll();
$total_nocover = (int)$pdo->query("SELECT COUNT(*) FROM books WHERE cover_file IS NULL OR cover_file = ''")->fetchColumn();
?>
<div class="kpis">
  <div class="kpi"><b><?= count($used) ?></b><span>libri con copertina</span></div>
  <div class="kpi"><b><?= $total_nocover ?></b><span>senza copertina</span></div>
  <div class="kpi"><b><?= h(fmt_bytes($size)) ?></b><span>spazio occupato</span></div>
  <div class="kpi"><b><?= $orph ?></b><span>immagini non più usate</span></div>
</div>

<div class="adm-grid2">
  <div class="card" data-fill-covers>
    <div class="ct"><?= icon('cloud', 18) ?> Cerca le copertine mancanti</div>
    <p class="sub"><?= $missing ? $missing . ' libri con ISBN non hanno la copertina: il sito le cerca online una alla volta.' : 'Tutti i libri con ISBN hanno già una copertina (o sono stati segnati come "senza copertina").' ?></p>
    <div class="progress" hidden><i></i></div>
    <?php if ($missing): ?><button class="btn primary small" type="button" data-fill-start>Cerca adesso</button><?php endif; ?>
  </div>
  <div class="card">
    <div class="ct"><?= icon('trash', 18) ?> Immagini non più usate</div>
    <p class="sub"><?= $orph ? $orph . ' file (' . h(fmt_bytes($orph_size)) . ') restano da copertine sostituite o libri eliminati.' : 'Nessun file inutilizzato.' ?></p>
    <?php if ($orph): ?>
    <form method="post" data-confirm="Eliminare le <?= $orph ?> immagini non collegate a nessun libro?"><?= csrf_field() ?><input type="hidden" name="action" value="covers_cleanup">
      <button class="btn ghost small" type="submit">Elimina i file inutilizzati</button></form>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="ct">Libri senza copertina<?= $total_nocover > 60 ? ' (i primi 60 di ' . $total_nocover . ')' : '' ?></div>
  <?php if (!$nocover): ?><p class="sub">Ogni libro ha la sua copertina.</p><?php endif; ?>
  <div class="cover-grid">
    <?php foreach ($nocover as $b): ?>
    <a href="libro.php?id=<?= (int)$b['id'] ?>#copertina" target="_blank" rel="noopener" title="Aggiungi la copertina">
      <?= book_cover_html($b, 'cover') ?><span><?= h(str_cut($b['title'], 40)) ?></span><small><?= $b['isbn13'] ? 'ISBN ' . h($b['isbn13']) : 'senza ISBN' ?></small></a>
    <?php endforeach; ?>
  </div>
</div>

<?php if ($uploads): ?>
<div class="card">
  <div class="ct">Logo e sfondi caricati</div>
  <?php foreach ($uploads as $u): ?>
  <div class="fr row"><span><code><?= h($u[0]) ?></code></span><span class="sub"><?= h(fmt_bytes($u[1])) ?> · <?= $u[2] ? 'in uso' : 'non in uso' ?></span></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
