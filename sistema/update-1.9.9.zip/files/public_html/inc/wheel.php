<?php
/*
 * Ruota di lettura PERSONALE: ogni utente ha le proprie impostazioni, la propria selezione
 * di libri e il proprio storico. La libreria invece e' unica e condivisa.
 *
 * Fonti possibili:
 *   unread  = i libri che QUESTO utente non ha ancora letto (da leggere o senza etichetta)
 *   library = tutti i libri della libreria
 *   manual  = solo i libri scelti a mano dall'utente
 * In tutti i casi si possono aggiungere filtri per genere e numero massimo di pagine.
 */
require_once dirname(__FILE__) . '/books.php';

define('WHEEL_MAX_SEGMENTS', 24);

function wheel_sources()
{
    return array('unread' => 'Non ancora letti', 'library' => 'Tutta la libreria', 'manual' => 'Scelti da me');
}

function wheel_settings_get($uid)
{
    $st = db()->prepare('SELECT * FROM wheel_settings WHERE user_id = ?');
    $st->execute(array((int)$uid));
    $r = $st->fetch();
    if (!$r) {
        $r = array('user_id' => $uid, 'source' => 'unread', 'category_id' => null, 'max_pages' => null);
    }
    $src = wheel_sources();
    if (!isset($src[$r['source']])) {
        $r['source'] = 'unread';
    }
    return $r;
}

function wheel_settings_save($uid, $source, $category_id, $max_pages)
{
    $src = wheel_sources();
    $source = isset($src[$source]) ? $source : 'unread';
    $category_id = ((int)$category_id > 0 && category_name((int)$category_id) !== '') ? (int)$category_id : null;
    $max_pages = ((int)$max_pages > 0) ? (int)$max_pages : null;
    $st = db()->prepare('SELECT COUNT(*) FROM wheel_settings WHERE user_id = ?');
    $st->execute(array((int)$uid));
    if ((int)$st->fetchColumn() > 0) {
        db()->prepare('UPDATE wheel_settings SET source=?, category_id=?, max_pages=?, updated_at=? WHERE user_id=?')
            ->execute(array($source, $category_id, $max_pages, now(), (int)$uid));
    } else {
        db()->prepare('INSERT INTO wheel_settings (user_id, source, category_id, max_pages, updated_at) VALUES (?,?,?,?,?)')
            ->execute(array((int)$uid, $source, $category_id, $max_pages, now()));
    }
    return wheel_settings_get($uid);
}

// Tutti i libri che possono uscire dalla ruota di questo utente (con le impostazioni attuali)
function wheel_pool($uid, $ws)
{
    $sql = 'SELECT b.id, b.title, b.authors, b.publisher, b.pub_year, b.pages, b.cover_file, b.category_id, '
         . 'ub.status AS my_status FROM books b '
         . 'LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = ? ';
    $params = array((int)$uid);
    if ($ws['source'] === 'manual') {
        $sql .= 'INNER JOIN wheel_items wi ON wi.book_id = b.id AND wi.user_id = ? WHERE 1=1 ';
        $params[] = (int)$uid;
    } else {
        $sql .= 'WHERE (ub.wheel_excluded IS NULL OR ub.wheel_excluded = 0) ';
        if ($ws['source'] === 'unread') {
            $sql .= "AND (ub.status IS NULL OR ub.status = '' OR ub.status = 'da_leggere') ";
        }
    }
    // i libri gia' estratti (nella lista "Ultime estrazioni") non escono di nuovo finche' non si tolgono dalla lista
    $sql .= 'AND b.id NOT IN (SELECT book_id FROM wheel_spins WHERE user_id = ?) ';
    $params[] = (int)$uid;
    if ((int)setting('db_version', '1') >= 3) {
        // i libri prestati non si possono leggere: restano fuori dalla ruota finche' non tornano
        $sql .= 'AND b.id NOT IN (SELECT book_id FROM loans WHERE returned_at IS NULL) ';
    }
    if (!empty($ws['category_id'])) {
        $sql .= 'AND b.category_id = ? ';
        $params[] = (int)$ws['category_id'];
    }
    if (!empty($ws['max_pages'])) {
        $sql .= 'AND b.pages IS NOT NULL AND b.pages <= ? ';
        $params[] = (int)$ws['max_pages'];
    }
    $sql .= 'ORDER BY b.title';
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function wheel_public_book($b)
{
    return array(
        'id' => (int)$b['id'],
        't' => $b['title'],
        'a' => (string)$b['authors'],
        'p' => $b['pages'] ? (int)$b['pages'] : null,
        'e' => (string)$b['publisher'],
        'y' => $b['pub_year'] ? (int)$b['pub_year'] : null,
        'cover' => $b['cover_file'] ? cover_url($b['cover_file']) : '',
        'pal' => cover_palette($b['title']),
        'status' => (string)$b['my_status'],
    );
}

// Libri da disegnare sulla ruota (al massimo WHEEL_MAX_SEGMENTS, scelti a caso se sono di piu')
function wheel_display($pool, $must_include_id = 0)
{
    if (count($pool) <= WHEEL_MAX_SEGMENTS) {
        $show = $pool;
    } else {
        $keys = array_keys($pool);
        shuffle($keys);
        $show = array();
        foreach ($pool as $b) {
            if ((int)$b['id'] === (int)$must_include_id) {
                $show[] = $b;
            }
        }
        foreach ($keys as $k) {
            if (count($show) >= WHEEL_MAX_SEGMENTS) {
                break;
            }
            if ((int)$pool[$k]['id'] !== (int)$must_include_id) {
                $show[] = $pool[$k];
            }
        }
    }
    shuffle($show);
    return array_map('wheel_public_book', $show);
}

/*
 * Estrazione: il vincitore viene scelto dal SERVER (random_int, equo su TUTTI i libri della fonte,
 * anche se la ruota ne mostra solo 24). Il browser si limita ad animare la ruota fino a quello spicchio.
 */
function wheel_spin($uid)
{
    $ws = wheel_settings_get($uid);
    $pool = wheel_pool($uid, $ws);
    if (count($pool) < 2) {
        return array('ok' => false, 'error' => count($pool) === 0
            ? 'Non ci sono libri sulla ruota con queste impostazioni.'
            : 'Serve almeno un secondo libro per far girare la ruota.');
    }
    $winner = $pool[random_int(0, count($pool) - 1)];
    $items = wheel_display($pool, $winner['id']);
    $index = 0;
    foreach ($items as $i => $it) {
        if ($it['id'] === (int)$winner['id']) {
            $index = $i;
        }
    }
    db()->prepare('INSERT INTO wheel_spins (user_id, book_id, source, outcome, created_at) VALUES (?,?,?,?,?)')
        ->execute(array((int)$uid, (int)$winner['id'], $ws['source'], null, now()));
    $spin_id = (int)db()->lastInsertId();
    return array('ok' => true, 'spin_id' => $spin_id, 'index' => $index, 'items' => $items, 'total' => count($pool));
}

function wheel_outcome($uid, $spin_id, $outcome)
{
    $st = db()->prepare('SELECT * FROM wheel_spins WHERE id = ? AND user_id = ?');
    $st->execute(array((int)$spin_id, (int)$uid));
    $sp = $st->fetch();
    if (!$sp) {
        return array('ok' => false, 'error' => 'Estrazione non trovata.');
    }
    if (!in_array($outcome, array('in_lettura', 'escluso', 'rigirata'), true)) {
        return array('ok' => false, 'error' => 'Scelta non valida.');
    }
    db()->prepare('UPDATE wheel_spins SET outcome = ? WHERE id = ?')->execute(array($outcome, (int)$spin_id));
    if ($outcome === 'in_lettura') {
        user_book_save($uid, $sp['book_id'], 'in_lettura');
    } elseif ($outcome === 'escluso') {
        if ($sp['source'] === 'manual') {
            db()->prepare('DELETE FROM wheel_items WHERE user_id = ? AND book_id = ?')->execute(array((int)$uid, (int)$sp['book_id']));
        }
        user_book_save($uid, $sp['book_id'], null, true);
    }
    return array('ok' => true);
}

function wheel_history($uid, $limit = 10)
{
    $st = db()->prepare('SELECT s.id, s.outcome, s.created_at, b.id AS book_id, b.title, b.authors, b.cover_file, ub.status AS my_status '
        . 'FROM wheel_spins s INNER JOIN books b ON b.id = s.book_id '
        . 'LEFT JOIN user_books ub ON ub.book_id = b.id AND ub.user_id = s.user_id '
        . 'WHERE s.user_id = ? AND s.id IN (SELECT MAX(id) FROM wheel_spins WHERE user_id = ? GROUP BY book_id) '
        . 'ORDER BY s.created_at DESC, s.id DESC LIMIT ' . (int)$limit);
    $st->execute(array((int)$uid, (int)$uid));
    return $st->fetchAll();
}

// Toglie un libro dalla lista delle estrazioni: torna a poter uscire dalla ruota (anche se era stato escluso da li')
function wheel_spin_remove($uid, $spin_id)
{
    $st = db()->prepare('SELECT * FROM wheel_spins WHERE id = ? AND user_id = ?');
    $st->execute(array((int)$spin_id, (int)$uid));
    $sp = $st->fetch();
    if (!$sp) {
        return false;
    }
    db()->prepare('DELETE FROM wheel_spins WHERE user_id = ? AND book_id = ?')->execute(array((int)$uid, (int)$sp['book_id']));
    if ($sp['outcome'] === 'escluso') {
        db()->prepare('UPDATE user_books SET wheel_excluded = 0 WHERE user_id = ? AND book_id = ?')->execute(array((int)$uid, (int)$sp['book_id']));
        if ($sp['source'] === 'manual') {
            $c = db()->prepare('SELECT COUNT(*) FROM wheel_items WHERE user_id = ? AND book_id = ?');
            $c->execute(array((int)$uid, (int)$sp['book_id']));
            if (!(int)$c->fetchColumn()) {
                db()->prepare('INSERT INTO wheel_items (user_id, book_id) VALUES (?,?)')->execute(array((int)$uid, (int)$sp['book_id']));
            }
        }
    }
    return true;
}

function wheel_spins_clear($uid)
{
    foreach (db()->query('SELECT id FROM wheel_spins WHERE user_id = ' . (int)$uid . " AND outcome = 'escluso'")->fetchAll(PDO::FETCH_COLUMN) as $sid) {
        wheel_spin_remove($uid, $sid);
    }
    db()->prepare('DELETE FROM wheel_spins WHERE user_id = ?')->execute(array((int)$uid));
}

// Selezione manuale: sostituisce l'elenco dei libri scelti
function wheel_items_save($uid, $ids)
{
    $clean = array();
    foreach ((array)$ids as $id) {
        if ((int)$id > 0) {
            $clean[(int)$id] = 1;
        }
    }
    $pdo = db();
    $pdo->beginTransaction();
    $pdo->prepare('DELETE FROM wheel_items WHERE user_id = ?')->execute(array((int)$uid));
    if ($clean) {
        $exist = $pdo->query('SELECT id FROM books WHERE id IN (' . implode(',', array_keys($clean)) . ')')->fetchAll(PDO::FETCH_COLUMN);
        $ins = $pdo->prepare('INSERT INTO wheel_items (user_id, book_id) VALUES (?, ?)');
        foreach ($exist as $bid) {
            $ins->execute(array((int)$uid, (int)$bid));
            // un libro scelto a mano non deve risultare escluso
            $pdo->prepare('UPDATE user_books SET wheel_excluded = 0 WHERE user_id = ? AND book_id = ?')->execute(array((int)$uid, (int)$bid));
        }
    }
    $pdo->commit();
    return count($clean);
}

function wheel_item_ids($uid)
{
    $st = db()->prepare('SELECT book_id FROM wheel_items WHERE user_id = ?');
    $st->execute(array((int)$uid));
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}
