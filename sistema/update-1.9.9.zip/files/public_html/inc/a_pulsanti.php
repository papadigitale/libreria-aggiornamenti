<?php
require_once APP_ROOT . '/inc/chips.php';
$cfg = chips_config();
$types = chip_types();
$n = count($cfg);
$tax = function_exists('taxonomies_all') ? taxonomies_all() : array();
$terms = function_exists('terms_by_taxonomy') ? terms_by_taxonomy() : array();
?>
<div class="card">
  <div class="ct"><?= admin_icon('layout', 18) ?> Pulsanti sotto la barra di ricerca</div>
  <p class="sub">Scegli quali pulsanti compaiono nella pagina Libreria, il loro ordine (1 = il primo a sinistra) e il nome. Valgono per tutti gli utenti.
    I pulsanti segnati con <span class="tag">personale</span> mostrano i libri di chi guarda (i suoi letti, i suoi voti) e gli ospiti non li vedono.</p>
  <form method="post" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="chips_save">
    <table class="tbl compact chips-tbl">
      <thead><tr><th>Mostra</th><th>Nome sul pulsante</th><th>Cosa mostra</th><th class="num">Posizione</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($cfg as $i => $c): $t = $types[$c['t']]; $avail = chip_available($c['t']); ?>
      <tr class="<?= $c['on'] ? '' : 'off' ?>">
        <td><?php if ($c['t'] === 'tutti'): ?><input type="checkbox" checked disabled title="Sempre presente"><input type="hidden" name="on[<?= $i ?>]" value="1">
            <?php else: ?><input type="checkbox" name="on[<?= $i ?>]" value="1" <?= $c['on'] ? 'checked' : '' ?> <?= $avail ? '' : 'disabled' ?> aria-label="Mostra"><?php endif; ?>
          <input type="hidden" name="t[<?= $i ?>]" value="<?= h($c['t']) ?>"><input type="hidden" name="v[<?= $i ?>]" value="<?= (int)$c['v'] ?>"></td>
        <td><input class="input" name="n[<?= $i ?>]" value="<?= h($c['n']) ?>" maxlength="40" placeholder="<?= h(chip_label(array('t' => $c['t'], 'n' => '', 'v' => $c['v']))) ?>"></td>
        <td><?php
            if ($c['t'] === 'genere') {
                echo 'Genere: <b>' . h((string)category_name($c['v'])) . '</b>';
            } elseif ($c['t'] === 'etichetta') {
                $tr = term_get($c['v']);
                echo $tr ? h($tr['taxonomy_name']) . ': <b>' . h($tr['name']) . '</b>' : '<span class="muted">valore eliminato</span>';
            } else {
                echo h($t[2]);
            }
            echo $t[1] ? ' <span class="tag">personale</span>' : '';
            echo $avail ? '' : ' <span class="muted">(serve un database più recente)</span>';
        ?></td>
        <td class="num"><select class="input" name="pos[<?= $i ?>]" aria-label="Posizione"><?php for ($p = 1; $p <= $n; $p++): ?><option value="<?= $p ?>" <?= $p === $i + 1 ? 'selected' : '' ?>><?= $p ?></option><?php endfor; ?></select></td>
        <td><?php if ($c['t'] === 'genere' || $c['t'] === 'etichetta'): ?><button class="btn link small" type="submit" name="del" value="<?= $i ?>" title="Togli questo pulsante">Togli</button><?php endif; ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <p class="hint">Lascia vuoto il nome per usare quello predefinito.</p>
    <div class="savebar"><button class="btn primary" type="submit">Salva i pulsanti</button></div>
  </form>
  <form method="post" data-confirm="Tornare ai pulsanti predefiniti? Quelli per generi ed etichette verranno tolti.">
    <?= csrf_field() ?><input type="hidden" name="action" value="chips_reset"><button class="btn link small" type="submit">Ripristina i pulsanti predefiniti</button></form>
</div>

<div class="adm-grid2">
<div class="card">
  <div class="ct"><?= admin_icon('plus', 18) ?> Aggiungi un pulsante per un genere o un'etichetta</div>
  <p class="sub">Per esempio un pulsante «Gialli» oppure «Adelphi»: un tocco e la libreria mostra solo quei libri (un secondo tocco toglie il filtro).</p>
  <form method="post" class="stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="chips_add">
    <label class="lab" for="ch-what">Genere o valore</label>
    <select class="input" id="ch-what" name="what" required>
      <option value="">Scegli…</option>
      <optgroup label="Generi">
        <?php foreach (categories_all() as $c): ?><option value="g<?= (int)$c['id'] ?>"><?= h($c['name']) ?></option><?php endforeach; ?>
      </optgroup>
      <?php foreach ($tax as $tid => $tx): if (empty($terms[$tid])) { continue; } ?>
      <optgroup label="<?= h($tx['name']) ?>">
        <?php foreach ($terms[$tid] as $tr): ?><option value="e<?= (int)$tr['id'] ?>"><?= h($tr['name']) ?></option><?php endforeach; ?>
      </optgroup>
      <?php endforeach; ?>
    </select>
    <label class="lab" for="ch-name">Nome sul pulsante (facoltativo)</label>
    <input class="input" id="ch-name" name="name" maxlength="40" placeholder="lo stesso del genere o del valore">
    <button class="btn primary small" type="submit">Aggiungi</button>
  </form>
</div>
<div class="card">
  <div class="ct">Anteprima</div>
  <div class="chips chips-prev">
    <?php foreach ($cfg as $c): if (!$c['on'] || !chip_available($c['t'])) { continue; } ?>
    <span class="chip <?= $c['t'] === 'tutti' ? 'on' : '' ?>"><?= h(chip_label($c)) ?></span>
    <?php endforeach; ?>
  </div>
  <p class="hint">Così li vede un utente registrato. Gli ospiti vedono solo quelli non personali.</p>
</div>
</div>
