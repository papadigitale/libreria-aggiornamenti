<?php
/*
 * Firewall della Libreria (sul modello di Wordfence):
 *  - IP reale del visitatore anche dietro Nginx Proxy Manager e Cloudflare, senza poterlo falsificare;
 *  - blocco di tutto il sito, sempre piu' lungo, per chi sbaglia troppe volte l'accesso, prova nomi utente
 *    inesistenti o vietati, o cerca pagine di attacco (wp-login.php, .env, phpmyadmin...);
 *  - protezione da attacchi distribuiti (molti IP insieme);
 *  - blocco per nazione (blocca le nazioni scelte, oppure consenti solo quelle), con la nazione data da
 *    Cloudflare o da un database locale gratuito (DB-IP Lite) aggiornato ogni mese;
 *  - IP sempre consentiti, blocchi a mano (anche intervalli), registro degli eventi.
 * Tutto funziona con MySQL e con PHP 7.4 → 8.5. Il file viene caricato da CONF/bootstrap.php.
 */

/* ---------- Indirizzi ---------- */

// Intervalli di Cloudflare (https://www.cloudflare.com/ips/)
function fw_cloudflare_ranges()
{
    return array(
        '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22', '141.101.64.0/18', '108.162.192.0/18',
        '190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
        '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
        '2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32', '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
    );
}

// Indirizzi della rete locale (casa, container, Docker, VPN tipo Tailscale)
function fw_local_ranges()
{
    return array('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '127.0.0.0/8', '169.254.0.0/16', '100.64.0.0/10',
        '::1/128', 'fc00::/7', 'fe80::/10');
}

// Forma unica di un indirizzo ("::ffff:1.2.3.4" diventa "1.2.3.4"); '' se non e' un IP
function fw_norm_ip($ip)
{
    $ip = trim((string)$ip);
    if ($ip === '') {
        return '';
    }
    if (preg_match('/^\[([0-9a-fA-F:.]+)\](:\d+)?$/', $ip, $m)) {   // [ipv6]:porta
        $ip = $m[1];
    } elseif (preg_match('/^(\d+\.\d+\.\d+\.\d+):\d+$/', $ip, $m)) { // ipv4:porta
        $ip = $m[1];
    }
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return '';
    }
    $bin = @inet_pton($ip);
    if ($bin === false) {
        return '';
    }
    if (strlen($bin) === 16 && substr($bin, 0, 12) === str_repeat("\0", 10) . "\xff\xff") {
        return inet_ntop(substr($bin, 12));
    }
    return inet_ntop($bin);
}

function ip_cidr_match($ip, $cidr)
{
    $a = @inet_pton($ip);
    if ($a === false) {
        return false;
    }
    if (strpos($cidr, '/') === false) {
        $b = @inet_pton($cidr);
        return $b !== false && $a === $b;
    }
    list($net, $bits) = explode('/', $cidr, 2);
    $b = @inet_pton(trim($net));
    if ($b === false || strlen($a) !== strlen($b) || !preg_match('/^\d{1,3}$/', trim($bits))) {
        return false;
    }
    $bits = (int)$bits;
    if ($bits > strlen($a) * 8) {
        return false;
    }
    $full = (int)floor($bits / 8);
    if ($full > 0 && substr($a, 0, $full) !== substr($b, 0, $full)) {
        return false;
    }
    $rem = $bits % 8;
    if ($rem === 0) {
        return true;
    }
    $mask = (0xFF << (8 - $rem)) & 0xFF;
    return (ord($a[$full]) & $mask) === (ord($b[$full]) & $mask);
}

function ip_in_list($ip, $list)
{
    foreach ($list as $r) {
        if (ip_cidr_match($ip, $r)) {
            return true;
        }
    }
    return false;
}

function ip_is_local($ip)
{
    return $ip !== '' && ip_in_list($ip, fw_local_ranges());
}

function ip_is_cloudflare($ip)
{
    return $ip !== '' && ip_in_list($ip, fw_cloudflare_ranges());
}

/*
 * Il sito e' dietro un reverse proxy della rete di casa (Nginx Proxy Manager, Traefik, Caddy...)?
 * Lo dice la configurazione del server (LIBRERIA_TRUST_PROXY=1) oppure il pannello (Firewall).
 * Senza proxy dichiarato si usa solo l'indirizzo che si collega al server: in casi particolari (Docker con
 * "userland proxy") tutti i visitatori sembrerebbero locali e potrebbero falsificare X-Forwarded-For.
 * Cloudflare invece e' sempre riconosciuto dai suoi indirizzi.
 */
function fw_trust_local_proxy()
{
    if (TRUST_PROXY) {
        return true;
    }
    if (defined('IS_INSTALLER') || !function_exists('setting')) {
        return false;
    }
    try {
        return setting('fw_proxy', '0') === '1';
    } catch (Exception $e) {
        return false;
    }
}

/*
 * Chi sta davvero visitando il sito.
 * La catena e' X-Forwarded-For + l'indirizzo che si collega al server. Si parte da destra (l'ultimo passaggio,
 * l'unico sicuro) e si va a sinistra solo finche' il passaggio e' un proxy fidato (rete locale = Nginx Proxy
 * Manager, oppure Cloudflare). Il primo indirizzo non fidato e' il visitatore: quello che un malintenzionato
 * scrive a mano in X-Forwarded-For resta piu' a sinistra e viene ignorato.
 */
function fw_client($reset = false)
{
    static $c = null;
    if ($c !== null && !$reset) {
        return $c;
    }
    $remote = fw_norm_ip(isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '');
    $chain = array();
    $local_ok = fw_trust_local_proxy();
    $trusted = function ($ip) use ($local_ok) {
        return ip_is_cloudflare($ip) || ($local_ok && ip_is_local($ip));
    };
    if ($remote !== '' && !empty($_SERVER['HTTP_X_FORWARDED_FOR']) && $trusted($remote)) {
        foreach (explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR']) as $x) {
            $x = fw_norm_ip($x);
            if ($x !== '') {
                $chain[] = $x;
            }
        }
        $chain = array_slice($chain, -20);
    }
    $chain[] = $remote;
    $i = count($chain) - 1;
    while ($i > 0 && $trusted($chain[$i])) {
        $i--;
    }
    $ip = $chain[$i];
    $c = array(
        'ip' => $ip,
        'remote' => $remote,
        'via_cf' => isset($chain[$i + 1]) && ip_is_cloudflare($chain[$i + 1]) && !ip_is_cloudflare($ip),
        'chain' => $chain,
        'proxy' => $local_ok,
        'proxy_hint' => !$local_ok && $remote !== '' && ip_is_local($remote) && !empty($_SERVER['HTTP_X_FORWARDED_FOR']),
    );
    return $c;
}

// Nazione del visitatore attuale: 'IT', 'LAN' (rete di casa), 'T1' (Tor, da Cloudflare), '' (sconosciuta)
function fw_client_country($with_source = false, $reset = false)
{
    static $r = null;
    if ($r === null || $reset) {
        $c = fw_client();
        $cc = '';
        $src = '';
        $hdr = isset($_SERVER['HTTP_CF_IPCOUNTRY']) ? strtoupper(trim($_SERVER['HTTP_CF_IPCOUNTRY'])) : '';
        if (ip_is_local($c['ip'])) {
            $cc = 'LAN';
            $src = 'rete di casa';
        } elseif ($c['via_cf'] && preg_match('/^[A-Z][A-Z0-9]$/', $hdr) && $hdr !== 'XX') {
            // la nazione di Cloudflare vale solo se la richiesta arriva davvero da Cloudflare
            $cc = $hdr;
            $src = 'Cloudflare';
        } else {
            $cc = fw_geo_lookup($c['ip']);
            $src = $cc !== '' ? 'database delle nazioni' : '';
        }
        $r = array($cc, $src);
    }
    return $with_source ? $r : $r[0];
}

function fw_country_name($cc)
{
    if ($cc === 'LAN') {
        return 'Rete di casa';
    }
    if ($cc === 'T1') {
        return 'Rete Tor';
    }
    if ($cc === '' || $cc === null) {
        return 'Sconosciuta';
    }
    require_once dirname(__FILE__) . '/countries.php';
    $l = fw_countries();
    return isset($l[$cc]) ? $l[$cc] : $cc;
}

/* ---------- Impostazioni ---------- */

function fw_ready()
{
    return function_exists('setting') && (int)setting('db_version', '1') >= 7;
}

function fw_enabled()
{
    return fw_ready() && setting('fw_enabled', '1') === '1';
}

function fw_lines($text)
{
    $out = array();
    foreach (preg_split('/[\r\n,;]+/', (string)$text) as $l) {
        $l = trim(preg_replace('/#.*$/', '', $l));
        if ($l !== '') {
            $out[] = $l;
        }
    }
    return $out;
}

// Una regola: IP singolo, intervallo CIDR (IPv4 o IPv6) o con asterisco (192.168.1.*)
function fw_rule_valid($r)
{
    if (strpos($r, '*') !== false) {
        return (bool)preg_match('/^(\d{1,3}\.){1,3}\*$/', $r);
    }
    if (strpos($r, '/') !== false) {
        list($n, $b) = explode('/', $r, 2);
        $bin = @inet_pton($n);
        return $bin !== false && preg_match('/^\d{1,3}$/', $b) && (int)$b <= strlen($bin) * 8 && (int)$b >= (strlen($bin) === 4 ? 8 : 16);
    }
    return fw_norm_ip($r) !== '';
}

function fw_rule_match($ip, $r)
{
    if (strpos($r, '*') !== false) {
        return strpos($ip, rtrim($r, '*')) === 0 && strpos($ip, ':') === false;
    }
    return ip_cidr_match($ip, $r);
}

// IP che il firewall non blocca mai
function fw_whitelisted($ip, $lan = null, $list = null)
{
    if ($ip === '' || $ip === '127.0.0.1' || $ip === '::1') {
        return true;
    }
    $lan = $lan === null ? setting('fw_lan_allow', '1') === '1' : $lan;
    if ($lan && ip_is_local($ip)) {
        return true;
    }
    foreach (fw_lines($list === null ? setting('fw_whitelist') : $list) as $r) {
        if (fw_rule_match($ip, $r)) {
            return true;
        }
    }
    return false;
}

function fw_reasons()
{
    return array(
        'brute'   => 'Troppi accessi errati',
        'user'    => 'Nomi utente inesistenti o vietati',
        'scanner' => 'Ha cercato pagine di attacco',
        'manual'  => 'Bloccato a mano',
        'country' => 'Nazione non consentita',
        'direct'  => 'Non è passato da Cloudflare',
        'siege'   => 'Attacco distribuito',
        'blocked' => 'Richiesta da IP bloccato',
        'token'   => 'Link di condivisione sbagliati',
    );
}

/* ---------- Blocchi ---------- */

function fw_block_find($ip)
{
    $st = db()->prepare('SELECT * FROM fw_blocks WHERE active = 1 AND (expires_at IS NULL OR expires_at > ?) AND (ip = ? OR is_range = 1) ORDER BY is_range, id DESC');
    $st->execute(array(now(), $ip));
    foreach ($st->fetchAll() as $b) {
        if (!(int)$b['is_range'] || fw_rule_match($ip, $b['ip'])) {
            return $b;
        }
    }
    return null;
}

// Durata in minuti del blocco numero $level per lo stesso IP (0 = per sempre)
function fw_block_minutes($level)
{
    $base = max(1, setting_int('sec_lock_minutes', 1, 1440));
    if (setting('fw_escalate', '1') !== '1') {
        return $base;
    }
    $steps = array(1 => $base, 2 => max($base, 60), 3 => max($base, 1440), 4 => max($base, 10080));
    if ($level >= 5) {
        return setting('fw_permanent', '0') === '1' ? 0 : $steps[4];
    }
    return $steps[$level];
}

function fw_block_add($ip, $reason, $detail, $minutes, $source = 'auto', $level = 1, $country = '')
{
    $is_range = (strpos($ip, '/') !== false || strpos($ip, '*') !== false) ? 1 : 0;
    $exp = $minutes > 0 ? date('Y-m-d H:i:s', time() + $minutes * 60) : null;
    db()->prepare('INSERT INTO fw_blocks (ip, is_range, country, reason, detail, source, level, active, hits, created_at, expires_at, created_by) VALUES (?,?,?,?,?,?,?,1,0,?,?,?)')
        ->execute(array($ip, $is_range, str_cut($country, 4), $reason, str_cut($detail, 255), $source, (int)$level, now(), $exp,
            isset($_SESSION['username']) && $source === 'manual' ? $_SESSION['username'] : null));
    return (int)db()->lastInsertId();
}

/*
 * Blocco automatico di tutto il sito per l'IP indicato (di solito il visitatore attuale).
 * Restituisce i minuti di blocco (0 = per sempre) oppure false se l'IP non va bloccato.
 */
function fw_block_auto($ip, $reason, $detail)
{
    if (!fw_enabled() || fw_whitelisted($ip) || fw_block_find($ip)) {
        return false;
    }
    $st = db()->prepare("SELECT COUNT(*) FROM fw_blocks WHERE ip = ? AND source = 'auto' AND created_at >= ?");
    $st->execute(array($ip, date('Y-m-d H:i:s', time() - 30 * 86400)));
    $level = (int)$st->fetchColumn() + 1;
    $min = fw_block_minutes($level);
    $cc = $ip === fw_client()['ip'] ? fw_client_country() : fw_geo_lookup($ip);
    fw_block_add($ip, $reason, $detail, $min, 'auto', $level, $cc);
    $reasons = fw_reasons();
    $durata = $min === 0 ? 'per sempre' : 'per ' . fw_duration_text($min);
    fw_event($reason, $detail . ' → IP bloccato ' . $durata . ($level > 1 ? ' (' . $level . '° blocco)' : ''), $ip, $cc, false);
    app_log('firewall_blocco', 'IP ' . $ip . ' (' . fw_country_name($cc) . ') bloccato ' . $durata . ': ' . $reasons[$reason] . ' – ' . $detail, 'alert', '');
    return $min;
}

function fw_duration_text($min)
{
    if ($min <= 0) {
        return 'sempre';
    }
    if ($min % 10080 === 0) {
        return ($min / 10080) . ($min === 10080 ? ' settimana' : ' settimane');
    }
    if ($min % 1440 === 0) {
        return ($min / 1440) . ($min === 1440 ? ' giorno' : ' giorni');
    }
    if ($min % 60 === 0) {
        return ($min / 60) . ($min === 60 ? ' ora' : ' ore');
    }
    return $min . ($min === 1 ? ' minuto' : ' minuti');
}

// Sblocca un IP: toglie i blocchi automatici (e la loro storia) e gli accessi errati registrati
function fw_unblock_ip($ip)
{
    db()->prepare("DELETE FROM fw_blocks WHERE ip = ? AND source = 'auto'")->execute(array($ip));
    db()->prepare("UPDATE fw_blocks SET active = 0 WHERE ip = ?")->execute(array($ip));
    db()->prepare('DELETE FROM login_attempts WHERE ip = ? AND success = 0')->execute(array($ip));
}

/* ---------- Registro ---------- */

// Gli eventi uguali (stesso IP, stesso tipo) entro 10 minuti diventano una riga sola con il contatore
function fw_event($kind, $detail, $ip = null, $country = null, $merge = true)
{
    try {
        $c = fw_client();
        $ip = $ip === null ? $c['ip'] : $ip;
        $country = $country === null ? ($ip === $c['ip'] ? fw_client_country() : '') : $country;
        $path = isset($_SERVER['REQUEST_URI']) ? str_cut(preg_replace('/[\x00-\x1F\x7F]/', '', $_SERVER['REQUEST_URI']), 250) : '';
        $now = now();
        if ($merge) {
            $st = db()->prepare('UPDATE fw_events SET hits = hits + 1, last_at = ?, path = ? WHERE ip = ? AND kind = ? AND last_at >= ?');
            $st->execute(array($now, $path, $ip, $kind, date('Y-m-d H:i:s', time() - 600)));
            if ($st->rowCount() > 0) {
                return;
            }
        }
        db()->prepare('INSERT INTO fw_events (ip, country, kind, detail, path, hits, created_at, last_at) VALUES (?,?,?,?,?,1,?,?)')
            ->execute(array($ip, str_cut((string)$country, 4), $kind, str_cut($detail, 255), $path, $now, $now));
        if (mt_rand(1, 100) === 1) {
            $days = max(7, setting_int('fw_events_days', 7, 3650));
            db()->prepare('DELETE FROM fw_events WHERE last_at < ?')->execute(array(date('Y-m-d H:i:s', time() - $days * 86400)));
            db()->prepare("DELETE FROM fw_blocks WHERE expires_at IS NOT NULL AND expires_at < ? AND source = 'auto'")
                ->execute(array(date('Y-m-d H:i:s', time() - 30 * 86400)));
        }
    } catch (Exception $e) {
        // il registro non deve mai bloccare il sito
    }
}

/* ---------- Nazioni ---------- */

function fw_geo_list($text = null)
{
    $out = array();
    foreach (explode(',', strtoupper($text === null ? setting('fw_geo_list') : $text)) as $c) {
        $c = trim($c);
        if (preg_match('/^[A-Z]{2}$/', $c)) {
            $out[] = $c;
        }
    }
    return array_values(array_unique($out));
}

function fw_geo_config()
{
    return array('mode' => setting('fw_geo_mode', 'off'), 'scope' => setting('fw_geo_scope', 'site'), 'list' => fw_geo_list(),
        'unknown' => setting('fw_geo_unknown', 'allow'), 'tor' => setting('fw_geo_tor', '0') === '1');
}

// true se con queste regole la nazione $cc va bloccata
function fw_geo_denies($cc, $cfg)
{
    if ($cfg['mode'] === 'off' || $cc === 'LAN') {
        return false;
    }
    if ($cc === 'T1') {
        return $cfg['tor'] || $cfg['mode'] === 'allow';
    }
    if ($cc === '') {
        return $cfg['unknown'] === 'block';
    }
    $in = in_array($cc, $cfg['list'], true);
    return $cfg['mode'] === 'block' ? $in : !$in;
}

/* ---------- Controllo di ogni richiesta (da CONF/bootstrap.php) ---------- */

function fw_check_request($script)
{
    if (PHP_SAPI === 'cli' || !fw_enabled()) {
        return;
    }
    try {
        $c = fw_client();
        if ($c['via_cf'] && (int)setting('fw_cf_seen', '0') < time() - 3600) {
            setting_save('fw_cf_seen', (string)time());
        }
        if (fw_whitelisted($c['ip'])) {
            return;
        }
        $b = fw_block_find($c['ip']);
        if ($b) {
            db()->prepare('UPDATE fw_blocks SET hits = hits + 1, last_hit = ? WHERE id = ?')->execute(array(now(), $b['id']));
            fw_deny('blocked', $b);
        }
        if (setting('fw_cf_only', '0') === '1' && !$c['via_cf'] && !ip_is_local($c['ip'])) {
            fw_event('direct', 'Collegamento diretto al server, senza passare da Cloudflare');
            fw_deny('direct');
        }
        $cfg = fw_geo_config();
        if ($cfg['mode'] !== 'off' && ($cfg['scope'] === 'site' || in_array($script, array('index.php', 'api.php'), true))) {
            $cc = fw_client_country();
            if (fw_geo_denies($cc, $cfg)) {
                fw_event('country', 'Nazione non consentita: ' . fw_country_name($cc));
                fw_deny('country');
            }
        }
    } catch (Exception $e) {
        // un errore del firewall (es. database non raggiungibile) non deve chiudere il sito
    }
}

function fw_deny($kind, $block = null)
{
    if (ob_get_level()) {
        @ob_end_clean();
    }
    header('HTTP/1.1 403 Forbidden');
    header('Cache-Control: no-store');
    if ($kind === 'blocked') {
        $msg = 'L\'accesso da questo indirizzo è stato bloccato per motivi di sicurezza.';
        if ($block && $block['expires_at']) {
            $msg .= ' Il blocco termina il ' . date('d/m/Y \a\l\l\e H:i', strtotime($block['expires_at'])) . '.';
        }
    } elseif ($kind === 'country') {
        $msg = 'Questo sito non è disponibile dalla tua zona.';
    } else {
        $msg = 'Accesso non consentito.';
    }
    if (defined('IS_API')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('ok' => false, 'error' => $msg));
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">'
       . '<title>Accesso non consentito</title><body style="font-family:Georgia,serif;background:#f3ebdd;color:#2b1d14;padding:30px;text-align:center">'
       . '<h2>Accesso non consentito</h2><p>' . h($msg) . '</p><p style="color:#7a6552;font-size:13px">IP ' . h(fw_client()['ip'])
       . ($block ? ' · codice B' . (int)$block['id'] : '') . '</p></body></html>';
    exit;
}

/* ---------- Accessi (da inc/auth.php) ---------- */

function fw_siege_active()
{
    return fw_enabled() && (int)setting('fw_siege_until', '0') > time();
}

// Durante un attacco distribuito entrano solo gli IP sempre consentiti e quelli da cui si e' gia' entrati negli ultimi 30 giorni
function fw_known_device($ip)
{
    if (fw_whitelisted($ip)) {
        return true;
    }
    $st = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND success = 1 AND created_at >= ?');
    $st->execute(array($ip, date('Y-m-d H:i:s', time() - 30 * 86400)));
    return (int)$st->fetchColumn() > 0;
}

function fw_login_refused($ip)
{
    return fw_siege_active() && !fw_known_device($ip);
}

function fw_after_failed_login($ip, $username, $exists)
{
    if (!fw_enabled()) {
        return;
    }
    try {
        // attacco distribuito: troppi errori in 10 minuti, da tutti gli IP insieme
        $siege = setting_int('fw_siege', 0, 100000);
        if ($siege > 0 && !fw_siege_active()) {
            $st = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND created_at >= ?');
            $st->execute(array(date('Y-m-d H:i:s', time() - 600)));
            if ((int)$st->fetchColumn() >= $siege) {
                setting_save('fw_siege_until', (string)(time() + 1800));
                load_settings(true);
                fw_event('siege', 'Più di ' . $siege . ' accessi errati in 10 minuti: per 30 minuti entra solo chi è già entrato da quel dispositivo', $ip, null, false);
                app_log('firewall_attacco', 'Attacco distribuito: accesso sospeso per 30 minuti ai dispositivi sconosciuti', 'alert', '');
            }
        }
        if (fw_whitelisted($ip)) {
            return;
        }
        $lname = strtolower($username);
        if (!$exists && $lname !== '') {
            if (in_array($lname, array_map('strtolower', fw_lines(setting('fw_banned_names'))), true)) {
                fw_block_auto($ip, 'user', 'Ha provato il nome utente vietato "' . str_cut($username, 40) . '"');
                return;
            }
            $max = setting_int('fw_unknown_max', 0, 50);
            if ($max > 0) {
                $st = db()->prepare('SELECT COUNT(*) FROM login_attempts la WHERE la.ip = ? AND la.success = 0 AND la.created_at >= ? '
                    . 'AND NOT EXISTS (SELECT 1 FROM users u WHERE u.username = la.username)');
                $st->execute(array($ip, date('Y-m-d H:i:s', time() - 86400)));
                if ((int)$st->fetchColumn() >= $max) {
                    fw_block_auto($ip, 'user', $max . ' tentativi con nomi utente inesistenti (ultimo "' . str_cut($username, 40) . '")');
                    return;
                }
            }
        }
        $max = setting_int('sec_max_attempts', 3, 50);
        $st = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND success = 0 AND created_at >= ?');
        $st->execute(array($ip, date('Y-m-d H:i:s', time() - setting_int('sec_lock_minutes', 1, 1440) * 60)));
        $n = (int)$st->fetchColumn();
        if ($n >= $max) {
            fw_block_auto($ip, 'brute', $n . ' accessi errati (ultimo con utente "' . str_cut($username, 40) . '")');
        }
    } catch (Exception $e) {
    }
}

/* ---------- Trappola per i programmi che cercano falle (trappola.php, dal file .htaccess) ---------- */

function fw_honeypot_paths()
{
    return array('wp-login.php', 'xmlrpc.php', 'wp-admin', 'wp-content', 'wp-includes', 'wp-config.php', 'wp-json',
        '.env', '.git', '.aws', '.ssh', 'phpmyadmin', 'pma', 'myadmin', 'adminer.php', 'phpinfo.php', 'vendor/phpunit',
        'cgi-bin', 'boaform', 'HNAP1', 'actuator', 'server-status', '.DS_Store', 'config.json', 'backup.zip', 'db.sql');
}

/* ---------- Database locale delle nazioni (DB-IP Lite, licenza CC BY 4.0) ---------- */

function fw_geo_dir()
{
    return DATA_DIR . '/geo';
}

function fw_geo_ok()
{
    return is_file(fw_geo_dir() . '/v4.bin') && filesize(fw_geo_dir() . '/v4.bin') > 1000;
}

// Ricerca binaria nel file (record: inizio, fine, nazione). Restituisce 'IT' o ''
function fw_geo_lookup($ip)
{
    $bin = @inet_pton((string)$ip);
    if ($bin === false || !function_exists('fw_geo_dir') || !defined('DATA_DIR')) {
        return '';
    }
    $len = strlen($bin);
    $file = fw_geo_dir() . ($len === 4 ? '/v4.bin' : '/v6.bin');
    if (!is_file($file)) {
        return '';
    }
    $rec = $len * 2 + 2;
    $n = (int)floor(filesize($file) / $rec);
    $f = @fopen($file, 'rb');
    if (!$f || $n === 0) {
        return '';
    }
    $lo = 0;
    $hi = $n - 1;
    $found = '';
    while ($lo <= $hi) {
        $mid = ($lo + $hi) >> 1;
        fseek($f, $mid * $rec);
        $r = fread($f, $rec);
        if (strlen($r) !== $rec) {
            break;
        }
        $start = substr($r, 0, $len);
        $end = substr($r, $len, $len);
        if (strcmp($bin, $start) < 0) {
            $hi = $mid - 1;
        } elseif (strcmp($bin, $end) > 0) {
            $lo = $mid + 1;
        } else {
            $found = substr($r, $len * 2, 2);
            break;
        }
    }
    fclose($f);
    return preg_match('/^[A-Z]{2}$/', $found) && $found !== 'ZZ' ? $found : '';
}

function fw_geo_url($months_ago = 0)
{
    $t = getenv('LIBRERIA_TEST_GEO_URL');
    if ($t) {
        return $t;
    }
    return 'https://download.db-ip.com/free/dbip-country-lite-' . date('Y-m', strtotime(date('Y-m-01') . ' -' . (int)$months_ago . ' month')) . '.csv.gz';
}

// Scarica e prepara il database delle nazioni. Restituisce array(ok, messaggio)
function fw_geo_update()
{
    if (!function_exists('curl_init')) {
        return array(false, 'L\'estensione curl di PHP non è attiva.');
    }
    if (!function_exists('gzopen')) {
        return array(false, 'L\'estensione zlib di PHP non è attiva.');
    }
    $dir = fw_geo_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
        return array(false, 'Non riesco a creare la cartella ' . $dir . '.');
    }
    @file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
    setting_save('fw_geo_try', (string)time());
    @set_time_limit(600);
    $gz = $dir . '/download.csv.gz';
    $err = '';
    foreach (array(0, 1) as $ago) {
        $url = fw_geo_url($ago);
        $fh = fopen($gz, 'wb');
        $ch = curl_init($url);
        $o = array(CURLOPT_FILE => $fh, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_TIMEOUT => 300, CURLOPT_FAILONERROR => true, CURLOPT_USERAGENT => 'LibreriaDiCasa/' . APP_VERSION);
        if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
            $o[CURLOPT_CAINFO] = CA_BUNDLE;
        }
        if (defined('HTTP_PROXY_URL') && HTTP_PROXY_URL !== '') {
            $o[CURLOPT_PROXY] = HTTP_PROXY_URL;
        }
        curl_setopt_array($ch, $o);
        $ok = curl_exec($ch);
        $err = curl_error($ch);
        curl_done($ch);
        fclose($fh);
        if ($ok && filesize($gz) > 100) {
            break;
        }
        $ok = false;
    }
    if (!$ok) {
        @unlink($gz);
        return array(false, 'Download non riuscito' . ($err ? ' (' . $err . ')' : '') . '.');
    }
    $r = fw_geo_build($gz);
    @unlink($gz);
    if ($r[0]) {
        setting_save('fw_geo_db_date', date('Y-m-d'));
        app_log('firewall_nazioni', 'Database delle nazioni aggiornato: ' . $r[1], 'info', '');
    }
    return $r;
}

// Converte il CSV (inizio,fine,nazione) nei due file binari ordinati
function fw_geo_build($gz)
{
    $in = @gzopen($gz, 'rb');
    if (!$in) {
        return array(false, 'Il file scaricato non si apre.');
    }
    $dir = fw_geo_dir();
    $out = array(4 => fopen($dir . '/v4.tmp', 'wb'), 16 => fopen($dir . '/v6.tmp', 'wb'));
    $last = array(4 => '', 16 => '');
    $count = array(4 => 0, 16 => 0);
    $bad = 0;
    while (($line = gzgets($in, 512)) !== false) {
        $p = str_getcsv(trim($line), ',', '"', '');
        if (count($p) < 3) {
            continue;
        }
        $a = @inet_pton(trim($p[0]));
        $b = @inet_pton(trim($p[1]));
        $cc = strtoupper(trim($p[2]));
        if ($a === false || $b === false || strlen($a) !== strlen($b) || !preg_match('/^[A-Z]{2}$/', $cc) || strcmp($a, $b) > 0) {
            $bad++;
            continue;
        }
        $l = strlen($a);
        if ($last[$l] !== '' && strcmp($a, $last[$l]) <= 0) {
            gzclose($in);
            fclose($out[4]);
            fclose($out[16]);
            @unlink($dir . '/v4.tmp');
            @unlink($dir . '/v6.tmp');
            return array(false, 'Il file scaricato non è ordinato: non è stato usato.');
        }
        $last[$l] = $b;
        fwrite($out[$l], $a . $b . $cc);
        $count[$l]++;
    }
    gzclose($in);
    fclose($out[4]);
    fclose($out[16]);
    $min = getenv('LIBRERIA_TEST_GEO_URL') ? 10 : 50000;
    if ($count[4] < $min) {
        @unlink($dir . '/v4.tmp');
        @unlink($dir . '/v6.tmp');
        return array(false, 'Il file scaricato non contiene il database delle nazioni (' . $count[4] . ' righe valide).');
    }
    rename($dir . '/v4.tmp', $dir . '/v4.bin');
    rename($dir . '/v6.tmp', $dir . '/v6.bin');
    return array(true, number_format($count[4] + $count[16], 0, ',', '.') . ' intervalli di indirizzi');
}

function fw_geo_due()
{
    if (!fw_ready() || setting('fw_geo_auto', '1') !== '1') {
        return false;
    }
    // serve solo se qualcuno lo usa: blocco per nazione attivo
    if (setting('fw_geo_mode', 'off') === 'off' && !fw_geo_ok()) {
        return false;
    }
    $d = setting('fw_geo_db_date');
    $old = $d === '' || strtotime($d) < time() - 32 * 86400;
    return $old && (int)setting('fw_geo_try', '0') < time() - 86400;
}

/* ---------- Statistiche per il pannello ---------- */

function fw_stats($days = 7)
{
    $since = date('Y-m-d H:i:s', time() - $days * 86400);
    $st = db()->prepare('SELECT kind, SUM(hits) AS n FROM fw_events WHERE last_at >= ? GROUP BY kind');
    $st->execute(array($since));
    $by = array();
    foreach ($st->fetchAll() as $r) {
        $by[$r['kind']] = (int)$r['n'];
    }
    $st = db()->prepare('SELECT SUM(hits) FROM fw_blocks WHERE last_hit >= ?');
    $st->execute(array($since));
    $by['blocked'] = (int)$st->fetchColumn();
    $st = db()->prepare("SELECT country, SUM(hits) AS n FROM fw_events WHERE last_at >= ? AND country <> '' AND country <> 'LAN' GROUP BY country ORDER BY n DESC LIMIT 5");
    $st->execute(array($since));
    $countries = $st->fetchAll();
    $st = db()->prepare('SELECT COUNT(*) FROM fw_blocks WHERE active = 1 AND (expires_at IS NULL OR expires_at > ?)');
    $st->execute(array(now()));
    return array('by' => $by, 'countries' => $countries, 'active' => (int)$st->fetchColumn(), 'total' => array_sum($by));
}
