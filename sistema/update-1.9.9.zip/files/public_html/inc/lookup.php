<?php
/*
 * Ricerca dei dati di un libro su piu' fonti online, unendo i risultati:
 *
 *   1) Google Books            - API pubblica, buona copertura anche italiana
 *   2) La Feltrinelli / IBS    - schede delle librerie online italiane (dati e copertine delle edizioni italiane)
 *   3) OPAC SBN                - catalogo del Servizio Bibliotecario Nazionale (tutte le edizioni pubblicate in Italia)
 *   4) Goodreads               - scheda pubblica del libro (facoltativa, non e' un servizio ufficiale)
 *   5) Open Library            - catalogo internazionale con copertine
 *   +  copertine di riserva per ISBN (IBS, La Feltrinelli, Amazon, Open Library)
 *
 * Goodreads ha chiuso le API pubbliche nel 2020: viene letta la scheda pubblica del libro.
 * Ogni fonte si attiva/disattiva da Gestione > Ricerca online. L'esito di ogni fonte viene registrato
 * (lookup_report) per capire subito se un libro "non si trova" o se manca la connessione.
 *
 * Risultato normalizzato: title, subtitle, authors, publisher, year, pages, isbn13, isbn10, language,
 * description, cover (URL migliore), covers (URL alternativi), source
 */
require_once dirname(__FILE__) . '/http.php';
require_once dirname(__FILE__) . '/books.php';

$GLOBALS['LOOKUP_REPORT'] = array();

function lookup_note($source, $status, $detail = '')
{
    $GLOBALS['LOOKUP_REPORT'][] = array('source' => $source, 'status' => $status, 'detail' => $detail);
}

function lookup_report()
{
    return $GLOBALS['LOOKUP_REPORT'];
}

// Scarica una pagina/JSON registrando l'esito. Restituisce il corpo o null.
function lookup_fetch($source, $url, $json = true)
{
    $r = http_get($url, setting_int('lookup_timeout', 3, 30), 4194304, 'api');
    if ($r['code'] === 0) {
        lookup_note($source, 'errore', $r['error']);
        return null;
    }
    if ($r['code'] === 404) {
        return null;
    }
    if ($r['code'] !== 200) {
        lookup_note($source, 'errore', 'risposta HTTP ' . $r['code'] . ($r['code'] === 429 ? ' (troppe richieste: aggiungi una chiave API o riprova più tardi)' : ''));
        return null;
    }
    if (!$json) {
        return $r['body'];
    }
    $j = json_decode($r['body'], true);
    if (!is_array($j)) {
        lookup_note($source, 'errore', 'risposta non leggibile');
        return null;
    }
    return $j;
}

function lookup_empty()
{
    return array('title' => '', 'subtitle' => '', 'authors' => '', 'publisher' => '', 'year' => '', 'pages' => '',
        'isbn13' => '', 'isbn10' => '', 'language' => '', 'description' => '', 'cover' => '', 'covers' => array(), 'source' => '');
}

/*
 * Trama / quarta di copertina: si scartano i testi pubblicitari delle librerie
 * ("acquista su ... a 18€", "spedizione gratuita"...) e i testi troppo corti.
 */
function lookup_desc_ok($d)
{
    $d = trim((string)$d);
    if (str_len($d) < 80) {
        return false;
    }
    if (preg_match('/acquista|acquistalo|spedizion|consegna|€|\bprezzo\b|carrello|disponibilit|ordina (ora|subito)|compra (ora|online)|\bsconto\b|recensioni dei clienti|^.{0,140}è un libro di .{0,80}pubblicato da/iu', $d)) {
        return false;
    }
    return true;
}

// Riconosce la lingua di un testo contando le parole piu' comuni: 'it', 'en', 'fr', 'es', 'de' oppure ''
function lookup_text_lang($d)
{
    $words = preg_split('/[^\p{L}\']+/u', function_exists('mb_strtolower') ? mb_strtolower((string)$d, 'UTF-8') : strtolower((string)$d));
    $dict = array(
        'it' => array('il', 'lo', 'la', 'gli', 'le', 'di', 'che', 'e', 'è', 'un', 'una', 'del', 'della', 'dei', 'per', 'con', 'non', 'nel', 'nella', 'sono', 'più', 'come', 'anche', 'suo', 'sua', 'questo', 'alla', 'al', 'ai', 'delle', 'tra', 'ma'),
        'en' => array('the', 'and', 'of', 'to', 'a', 'in', 'is', 'that', 'his', 'her', 'with', 'for', 'as', 'was', 'he', 'she', 'it', 'by', 'on', 'this', 'from', 'who', 'an', 'are', 'be', 'their'),
        'fr' => array('le', 'les', 'des', 'et', 'est', 'une', 'du', 'dans', 'qui', 'pour', 'pas', 'sur', 'au', 'avec', 'son', 'ses', 'elle'),
        'es' => array('el', 'los', 'las', 'y', 'es', 'una', 'del', 'que', 'en', 'por', 'con', 'para', 'su', 'sus', 'como', 'pero', 'muy'),
        'de' => array('der', 'die', 'das', 'und', 'ist', 'ein', 'eine', 'nicht', 'mit', 'von', 'zu', 'den', 'sich', 'auf', 'für', 'ich'),
    );
    $score = array();
    foreach ($dict as $lang => $list) {
        $score[$lang] = 0;
        $set = array_flip($list);
        foreach ($words as $w) {
            if (isset($set[$w])) {
                $score[$lang]++;
            }
        }
    }
    arsort($score);
    $top = key($score);
    $vals = array_values($score);
    if ($vals[0] < 3 || $vals[0] < $vals[1] * 1.3) {
        return '';
    }
    return $top;
}

/*
 * Sceglie la descrizione migliore tra quelle trovate: prima quelle nella lingua preferita
 * (Gestione > Ricerca online > Lingua preferita), poi la piu' completa.
 * Con lingua "Italiano" le descrizioni in altre lingue vengono scartate.
 */
function lookup_best_desc($list)
{
    $pref = setting('lookup_lang');
    $best = '';
    $best_score = -1;
    foreach ($list as $d) {
        $d = trim((string)$d);
        if (!lookup_desc_ok($d)) {
            continue;
        }
        $lang = lookup_text_lang($d);
        if ($pref !== '' && $lang !== '' && $lang !== $pref) {
            continue; // altra lingua
        }
        $score = ($pref !== '' && $lang === $pref ? 100000 : 0) + str_len($d);
        if ($score > $best_score) {
            $best = $d;
            $best_score = $score;
        }
    }
    return str_cut($best, 3000);
}

// La descrizione salvata va sostituita? (assente, pubblicitaria o in un'altra lingua)
function lookup_desc_should_replace($old)
{
    $old = trim((string)$old);
    if ($old === '' || !lookup_desc_ok($old)) {
        return true;
    }
    $pref = setting('lookup_lang');
    $lang = lookup_text_lang($old);
    return $pref !== '' && $lang !== '' && $lang !== $pref;
}

// Testo HTML -> testo semplice mantenendo gli a capo dei paragrafi
function lookup_clean_par($s)
{
    $s = preg_replace('#<(br|/p|/div)[^>]*>#i', "\n", (string)$s);
    $s = html_entity_decode(strip_tags($s), ENT_QUOTES, 'UTF-8');
    $out = array();
    foreach (preg_split('/\R/u', $s) as $l) {
        $l = trim(preg_replace('/[ \t]+/u', ' ', $l));
        if ($l !== '') {
            $out[] = $l;
        }
    }
    return implode("\n", $out);
}

function lookup_year($date)
{
    return preg_match('/(1[4-9]\d\d|20\d\d)/', (string)$date, $m) ? $m[1] : '';
}

function lookup_clean($s)
{
    $s = html_entity_decode(strip_tags((string)$s), ENT_QUOTES, 'UTF-8');
    $s = preg_replace('/\s+/u', ' ', $s);
    return trim($s, " \t\n\r\0\x0B.,;:-");
}

// "Dickens, Charles <1812-1870>"  ->  "Charles Dickens"
function lookup_flip_name($s)
{
    $s = trim(preg_replace('/<[^>]*>|\[[^\]]*\]/', '', $s));
    if (preg_match('/^([^,]+),\s*(.+)$/u', $s, $m)) {
        return trim($m[2]) . ' ' . trim($m[1]);
    }
    return $s;
}

/* =====================================================================
 * 1) GOOGLE BOOKS
 * ===================================================================== */
function google_cover_fix($url)
{
    if ($url === '') {
        return '';
    }
    $url = preg_replace('#^http://#', 'https://', $url);
    return str_replace('&edge=curl', '', $url);
}

function google_parse_volume($item)
{
    $v = isset($item['volumeInfo']) ? $item['volumeInfo'] : array();
    $r = lookup_empty();
    $r['title'] = isset($v['title']) ? $v['title'] : '';
    $r['subtitle'] = isset($v['subtitle']) ? $v['subtitle'] : '';
    $r['authors'] = isset($v['authors']) && is_array($v['authors']) ? implode(', ', $v['authors']) : '';
    $r['publisher'] = isset($v['publisher']) ? trim($v['publisher'], " \"") : '';
    $r['year'] = isset($v['publishedDate']) ? lookup_year($v['publishedDate']) : '';
    $r['pages'] = isset($v['pageCount']) && (int)$v['pageCount'] > 0 ? (string)(int)$v['pageCount'] : '';
    $r['language'] = isset($v['language']) ? $v['language'] : '';
    $r['description'] = isset($v['description']) ? str_cut(lookup_clean_par($v['description']), 3000) : '';
    if (isset($v['industryIdentifiers']) && is_array($v['industryIdentifiers'])) {
        foreach ($v['industryIdentifiers'] as $idf) {
            if (!isset($idf['type'], $idf['identifier'])) {
                continue;
            }
            if ($idf['type'] === 'ISBN_13') {
                $r['isbn13'] = isbn_clean($idf['identifier']);
            } elseif ($idf['type'] === 'ISBN_10') {
                $r['isbn10'] = isbn_clean($idf['identifier']);
            }
        }
    }
    if ($r['isbn13'] === '' && $r['isbn10'] !== '') {
        $r['isbn13'] = isbn10_to_13($r['isbn10']);
    }
    if (isset($v['imageLinks']) && is_array($v['imageLinks'])) {
        foreach (array('extraLarge', 'large', 'medium', 'small', 'thumbnail', 'smallThumbnail') as $k) {
            if (!empty($v['imageLinks'][$k])) {
                $r['covers'][] = google_cover_fix($v['imageLinks'][$k]);
            }
        }
    }
    $r['source'] = 'Google Books';
    $r['_gid'] = isset($item['id']) ? $item['id'] : '';
    return $r;
}

function google_url($params)
{
    $key = trim(setting('google_api_key'));
    if ($key !== '') {
        $params['key'] = $key;
    }
    return 'https://www.googleapis.com/books/v1/volumes?' . http_build_query($params);
}

function google_by_isbn($isbn13)
{
    $j = lookup_fetch('Google Books', google_url(array('q' => 'isbn:' . $isbn13, 'maxResults' => 5)));
    if ($j && empty($j['items'])) {
        // a volte l'ISBN e' indicizzato solo come testo libero
        $j = lookup_fetch('Google Books', google_url(array('q' => $isbn13, 'maxResults' => 5)));
    }
    if (!$j || empty($j['items'])) {
        if ($j !== null) {
            lookup_note('Google Books', 'vuoto');
        }
        return null;
    }
    // si preferisce il risultato che contiene esattamente questo ISBN
    $pick = $j['items'][0];
    foreach ($j['items'] as $it) {
        $p = google_parse_volume($it);
        if ($p['isbn13'] === $isbn13) {
            $pick = $it;
            break;
        }
    }
    $r = google_parse_volume($pick);
    if ($r['isbn13'] !== '' && $r['isbn13'] !== $isbn13) {
        lookup_note('Google Books', 'vuoto', 'trovata solo un\'altra edizione');
        return null;
    }
    if ($r['_gid'] !== '') {
        $key = trim(setting('google_api_key'));
        $full = lookup_fetch('Google Books', 'https://www.googleapis.com/books/v1/volumes/' . rawurlencode($r['_gid']) . ($key !== '' ? '?key=' . rawurlencode($key) : ''));
        if ($full) {
            $r2 = google_parse_volume($full);
            foreach (array('pages', 'publisher', 'year', 'description', 'subtitle') as $k) {
                if ($r[$k] === '' && $r2[$k] !== '') {
                    $r[$k] = $r2[$k];
                }
            }
            $r['covers'] = array_values(array_unique(array_merge($r2['covers'], $r['covers'])));
        }
    }
    lookup_note('Google Books', 'ok');
    return $r;
}

function google_search($q)
{
    $params = array('q' => $q, 'maxResults' => 15, 'printType' => 'books');
    if (setting('lookup_lang') !== '') {
        $params['langRestrict'] = setting('lookup_lang');
    }
    $j = lookup_fetch('Google Books', google_url($params));
    $out = array();
    if ($j && !empty($j['items'])) {
        foreach ($j['items'] as $it) {
            $out[] = google_parse_volume($it);
        }
    }
    lookup_note('Google Books', $out ? 'ok' : ($j !== null ? 'vuoto' : 'errore'), $out ? count($out) . ' risultati' : '');
    return $out;
}

/* =====================================================================
 * 2) LA FELTRINELLI / IBS  (stessa piattaforma: scheda prodotto per EAN)
 * ===================================================================== */
function html_to_lines($html)
{
    $html = preg_replace('#<(script|style|noscript|svg)[^>]*>.*?</\1>#si', ' ', $html);
    $html = preg_replace('#<(br|/p|/div|/li|/dt|/dd|/h\d|/tr|/td|/th|/span|/a|/label)[^>]*>#i', "$0\n", $html);
    $text = html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8');
    $lines = array();
    foreach (preg_split('/\R/u', $text) as $l) {
        $l = trim(preg_replace('/\s+/u', ' ', $l));
        if ($l !== '') {
            $lines[] = $l;
        }
    }
    return $lines;
}

// Cerca "Etichetta: valore" oppure l'etichetta su una riga e il valore sulla successiva
function html_label_value($lines, $labels, $pattern = null)
{
    $n = count($lines);
    for ($i = 0; $i < $n; $i++) {
        foreach ((array)$labels as $lab) {
            $l = $lines[$i];
            $val = null;
            if (strcasecmp(rtrim($l, ': '), $lab) === 0 && $i + 1 < $n) {
                $val = $lines[$i + 1];
            } elseif (stripos($l, $lab . ':') === 0) {
                $val = trim(substr($l, strlen($lab) + 1));
            }
            if ($val !== null && $val !== '' && ($pattern === null || preg_match($pattern, $val))) {
                return $val;
            }
        }
    }
    return '';
}

function html_meta($html, $prop)
{
    $p = preg_quote($prop, '#');
    if (preg_match('#<meta[^>]+(?:property|name)=["\']' . $p . '["\'][^>]*content=(["\'])(.*?)\1#is', $html, $m)
        || preg_match('#<meta[^>]+content=(["\'])(.*?)\1[^>]*(?:property|name)=["\']' . $p . '["\']#is', $html, $m)) {
        return html_entity_decode($m[2], ENT_QUOTES, 'UTF-8');
    }
    return '';
}

// Dati strutturati schema.org (JSON-LD), se presenti
function html_jsonld_book($html)
{
    if (!preg_match_all('#<script[^>]+application/ld\+json[^>]*>(.*?)</script>#si', $html, $mm)) {
        return null;
    }
    foreach ($mm[1] as $raw) {
        $j = json_decode(trim($raw), true);
        if (!is_array($j)) {
            continue;
        }
        $stack = array($j);
        while ($stack) {
            $node = array_pop($stack);
            if (!is_array($node)) {
                continue;
            }
            $type = isset($node['@type']) ? (is_array($node['@type']) ? implode(',', $node['@type']) : $node['@type']) : '';
            if (stripos($type, 'Book') !== false || stripos($type, 'Product') !== false) {
                return $node;
            }
            foreach ($node as $v) {
                if (is_array($v)) {
                    $stack[] = $v;
                }
            }
        }
    }
    return null;
}

function shop_by_isbn($isbn13)
{
    $shops = array(
        array('La Feltrinelli', 'https://www.lafeltrinelli.it/libro/e/' . $isbn13, 'https://www.lafeltrinelli.it/images/' . $isbn13 . '_0_0_536_0_75.jpg'),
        array('IBS', 'https://www.ibs.it/libro/e/' . $isbn13, 'https://www.ibs.it/images/' . $isbn13 . '_0_0_536_0_75.jpg'),
    );
    foreach ($shops as $s) {
        $html = lookup_fetch($s[0], $s[1], false);
        if ($html === null || strpos($html, $isbn13) === false) {
            if ($html !== null) {
                lookup_note($s[0], 'vuoto');
            }
            continue;
        }
        $r = lookup_empty();
        $lines = html_to_lines($html);
        $ld = html_jsonld_book($html);
        if ($ld) {
            $r['title'] = isset($ld['name']) ? lookup_clean($ld['name']) : '';
            if (isset($ld['author'])) {
                $a = $ld['author'];
                $names = array();
                foreach ((isset($a['name']) ? array($a) : (array)$a) as $one) {
                    $names[] = is_array($one) ? (isset($one['name']) ? $one['name'] : '') : $one;
                }
                $r['authors'] = lookup_clean(implode(', ', array_filter($names)));
            }
            if (isset($ld['numberOfPages'])) {
                $r['pages'] = (string)(int)$ld['numberOfPages'];
            }
            if (isset($ld['publisher'])) {
                $r['publisher'] = lookup_clean(is_array($ld['publisher']) ? (isset($ld['publisher']['name']) ? $ld['publisher']['name'] : '') : $ld['publisher']);
            }
            if (isset($ld['datePublished'])) {
                $r['year'] = lookup_year($ld['datePublished']);
            }
        }
        // "Titolo - Autore - Libro - Editore - Collana | Feltrinelli"
        $og = html_meta($html, 'og:title');
        $parts = array_map('trim', explode(' - ', preg_replace('/\s*\|.*$/', '', $og)));
        if ($r['title'] === '' && $parts && $parts[0] !== '') {
            $r['title'] = $parts[0];
        }
        if ($r['authors'] === '' && count($parts) > 2 && preg_match('/^(Libro|Ebook|E-book|Audiolibro)/i', $parts[2])) {
            $r['authors'] = $parts[1];
        }
        if ($r['title'] === '' && preg_match('#<h1[^>]*>(.*?)</h1>#si', $html, $m)) {
            $r['title'] = lookup_clean($m[1]);
        }
        if ($r['authors'] === '') {
            $r['authors'] = html_label_value($lines, array('Autore', 'Autori'));
        }
        if ($r['publisher'] === '') {
            $r['publisher'] = html_label_value($lines, array('Editore'), '/[A-Za-z]/');
        }
        if ($r['year'] === '') {
            $r['year'] = lookup_year(html_label_value($lines, array('Anno edizione', 'In commercio dal', 'Anno'), '/\d{4}/'));
        }
        if ($r['pages'] === '') {
            $pg = html_label_value($lines, array('Pagine', 'Numero pagine'), '/\d/');
            if (preg_match_all('/\d+/', $pg, $nums)) {
                $r['pages'] = (string)max(array_map('intval', $nums[0]));
            }
        }
        $sub = html_label_value($lines, array('Sottotitolo'));
        if ($sub !== '') {
            $r['subtitle'] = $sub;
        }
        $cands = array();
        if ($ld && !empty($ld['description'])) {
            $cands[] = lookup_clean_par($ld['description']);
        }
        // sezione "Descrizione" / "Trama" della scheda: righe successive fino alla prossima sezione
        $stops = '/^(Dettagli|Dettagli prodotto|Autore|Autori|Editore|Collana|Anno edizione|Pagine|EAN|Recensioni|Altri libri|Potrebbe interessarti|Informazioni|Formato|Lingua|Traduttore)\b/i';
        $n = count($lines);
        for ($i = 0; $i < $n; $i++) {
            if (preg_match('/^(Descrizione|Trama|Sinossi|Quarta di copertina)\s*:?$/i', $lines[$i])) {
                $buf = array();
                for ($k = $i + 1; $k < $n && count($buf) < 30; $k++) {
                    if (preg_match($stops, $lines[$k])) {
                        break;
                    }
                    $buf[] = $lines[$k];
                }
                $cands[] = implode("\n", $buf);
            }
        }
        $cands[] = html_meta($html, 'og:description');
        $r['description'] = lookup_best_desc($cands);
        $img = html_meta($html, 'og:image');
        $r['covers'][] = $s[2];
        if ($img !== '' && strpos($img, $isbn13) !== false) {
            $r['covers'][] = preg_replace('#^http://#', 'https://', $img);
        }
        $r['isbn13'] = $isbn13;
        $r['language'] = 'it';
        $r['source'] = $s[0];
        if ($r['title'] === '') {
            lookup_note($s[0], 'vuoto', 'pagina senza dati riconoscibili');
            continue;
        }
        lookup_note($s[0], 'ok');
        return $r;
    }
    return null;
}

/* =====================================================================
 * 3) OPAC SBN - Servizio Bibliotecario Nazionale
 *    (servizio JSON usato dall'app ufficiale "OPAC SBN"; non documentato ufficialmente)
 * ===================================================================== */
function sbn_find_records($j)
{
    // individua l'elenco di schede ovunque si trovi nella risposta
    $stack = array($j);
    while ($stack) {
        $node = array_shift($stack);
        if (!is_array($node)) {
            continue;
        }
        if (isset($node[0]) && is_array($node[0]) && isset($node[0]['titolo'])) {
            return $node;
        }
        if (isset($node['titolo']) && !isset($node[0])) {
            return array($node);
        }
        foreach ($node as $v) {
            if (is_array($v)) {
                $stack[] = $v;
            }
        }
    }
    return array();
}

function sbn_text($v)
{
    if (is_array($v)) {
        $flat = array();
        array_walk_recursive($v, function ($x) use (&$flat) {
            if (is_string($x) || is_numeric($x)) {
                $flat[] = (string)$x;
            }
        });
        return implode(' ; ', $flat);
    }
    return (string)$v;
}

function sbn_parse($rec)
{
    $r = lookup_empty();
    $tit = sbn_text(isset($rec['titolo']) ? $rec['titolo'] : '');
    $tit = str_replace('*', '', $tit);
    $main = trim(preg_split('# / #', $tit)[0]);
    $bits = preg_split('# : #', $main, 2);
    $r['title'] = lookup_clean($bits[0]);
    $r['subtitle'] = isset($bits[1]) ? lookup_clean($bits[1]) : '';
    $aut = sbn_text(isset($rec['autorePrincipale']) ? $rec['autorePrincipale'] : '');
    if ($aut === '' && preg_match('# / ([^;]+)#', $tit, $m)) {
        $aut = $m[1];
    } else {
        $aut = lookup_flip_name($aut);
    }
    $r['authors'] = lookup_clean($aut);
    $pub = sbn_text(isset($rec['pubblicazione']) ? $rec['pubblicazione'] : '');
    if (preg_match('/:\s*([^,;\[\]]+)/u', $pub, $m)) {
        $r['publisher'] = lookup_clean($m[1]);
    }
    $r['year'] = lookup_year($pub);
    $fis = sbn_text(isset($rec['descrizioneFisica']) ? $rec['descrizioneFisica'] : '');
    if (preg_match_all('/(\d+)\s*p\b/u', $fis, $mm)) {
        $r['pages'] = (string)max(array_map('intval', $mm[1]));
    }
    $num = sbn_text(isset($rec['numeri']) ? $rec['numeri'] : '');
    if (preg_match_all('/(97[89][\d\-]{10,16}|\b\d[\d\-]{8,11}[\dXx]\b)/', $num, $mm)) {
        foreach ($mm[1] as $cand) {
            $i13 = isbn_to13($cand);
            if ($i13 !== '') {
                $r['isbn13'] = $i13;
                break;
            }
        }
    }
    $r['language'] = 'it';
    $r['source'] = 'OPAC SBN';
    $r['_bid'] = isset($rec['codiceIdentificativo']) ? (string)$rec['codiceIdentificativo'] : '';
    return $r;
}

function sbn_base()
{
    return 'https://opac.sbn.it/opacmobilegw/';
}

function sbn_by_isbn($isbn13)
{
    $j = lookup_fetch('OPAC SBN', sbn_base() . 'search.json?' . http_build_query(array('isbn' => $isbn13)));
    if ($j === null) {
        return null;
    }
    $recs = sbn_find_records($j);
    if (!$recs) {
        $i10 = isbn13_to_10($isbn13);
        if ($i10 !== '') {
            $j = lookup_fetch('OPAC SBN', sbn_base() . 'search.json?' . http_build_query(array('isbn' => $i10)));
            $recs = $j ? sbn_find_records($j) : array();
        }
    }
    if (!$recs) {
        lookup_note('OPAC SBN', 'vuoto');
        return null;
    }
    $r = sbn_parse($recs[0]);
    // la scheda completa contiene anche il numero di pagine
    if ($r['_bid'] !== '' && $r['pages'] === '') {
        $full = lookup_fetch('OPAC SBN', sbn_base() . 'full.json?' . http_build_query(array('bid' => $r['_bid'])));
        if ($full) {
            $fr = sbn_find_records($full);
            if ($fr) {
                $r2 = sbn_parse($fr[0]);
                foreach (array('pages', 'publisher', 'year', 'authors', 'subtitle') as $k) {
                    if ($r[$k] === '' && $r2[$k] !== '') {
                        $r[$k] = $r2[$k];
                    }
                }
            }
        }
    }
    $r['isbn13'] = $isbn13;
    if ($r['title'] === '') {
        lookup_note('OPAC SBN', 'vuoto');
        return null;
    }
    lookup_note('OPAC SBN', 'ok');
    return $r;
}

function sbn_search($q)
{
    $j = lookup_fetch('OPAC SBN', sbn_base() . 'search.json?' . http_build_query(array('any' => $q, 'type' => 0, 'start' => 0, 'rows' => 15)));
    $out = array();
    if ($j) {
        foreach (sbn_find_records($j) as $rec) {
            $r = sbn_parse($rec);
            if ($r['title'] !== '') {
                $out[] = $r;
            }
        }
    }
    lookup_note('OPAC SBN', $out ? 'ok' : ($j !== null ? 'vuoto' : 'errore'), $out ? count($out) . ' risultati' : '');
    return $out;
}

/* =====================================================================
 * 4) OPEN LIBRARY
 * ===================================================================== */
function openlib_by_isbn($isbn13)
{
    $j = lookup_fetch('Open Library', 'https://openlibrary.org/api/books?' . http_build_query(array('bibkeys' => 'ISBN:' . $isbn13, 'format' => 'json', 'jscmd' => 'data')));
    if (!$j || empty($j['ISBN:' . $isbn13])) {
        if ($j !== null) {
            lookup_note('Open Library', 'vuoto');
        }
        return null;
    }
    $d = $j['ISBN:' . $isbn13];
    $r = lookup_empty();
    $r['title'] = isset($d['title']) ? $d['title'] : '';
    $r['subtitle'] = isset($d['subtitle']) ? $d['subtitle'] : '';
    $names = array();
    if (!empty($d['authors'])) {
        foreach ($d['authors'] as $a) {
            if (!empty($a['name'])) {
                $names[] = $a['name'];
            }
        }
    }
    $r['authors'] = implode(', ', $names);
    $r['publisher'] = !empty($d['publishers'][0]['name']) ? $d['publishers'][0]['name'] : '';
    $r['year'] = isset($d['publish_date']) ? lookup_year($d['publish_date']) : '';
    $r['pages'] = !empty($d['number_of_pages']) ? (string)(int)$d['number_of_pages'] : '';
    $r['isbn13'] = $isbn13;
    foreach (array('large', 'medium') as $k) {
        if (!empty($d['cover'][$k])) {
            $r['covers'][] = preg_replace('#^http://#', 'https://', $d['cover'][$k]);
        }
    }
    $r['source'] = 'Open Library';
    lookup_note('Open Library', 'ok');
    return $r;
}

function openlib_search($q)
{
    $params = array('q' => $q, 'limit' => 10,
        'fields' => 'title,subtitle,author_name,publisher,first_publish_year,publish_year,isbn,number_of_pages_median,cover_i,language');
    if (setting('lookup_lang') === 'it') {
        $params['language'] = 'ita';
    }
    $j = lookup_fetch('Open Library', 'https://openlibrary.org/search.json?' . http_build_query($params));
    $out = array();
    if ($j && !empty($j['docs'])) {
        foreach ($j['docs'] as $d) {
            $r = lookup_empty();
            $r['title'] = isset($d['title']) ? $d['title'] : '';
            $r['subtitle'] = isset($d['subtitle']) ? $d['subtitle'] : '';
            $r['authors'] = !empty($d['author_name']) ? implode(', ', array_slice($d['author_name'], 0, 3)) : '';
            $r['publisher'] = !empty($d['publisher'][0]) ? $d['publisher'][0] : '';
            $r['year'] = !empty($d['first_publish_year']) ? (string)$d['first_publish_year'] : '';
            $r['pages'] = !empty($d['number_of_pages_median']) ? (string)(int)$d['number_of_pages_median'] : '';
            if (!empty($d['isbn'])) {
                foreach ($d['isbn'] as $i) {
                    $i = isbn_clean($i);
                    if (strlen($i) === 13 && (strpos($i, '97888') === 0 || $r['isbn13'] === '')) {
                        $r['isbn13'] = $i;
                    }
                }
            }
            if (!empty($d['cover_i'])) {
                $r['covers'][] = 'https://covers.openlibrary.org/b/id/' . (int)$d['cover_i'] . '-L.jpg';
            }
            $r['source'] = 'Open Library';
            if ($r['title'] !== '') {
                $out[] = $r;
            }
        }
    }
    lookup_note('Open Library', $out ? 'ok' : ($j !== null ? 'vuoto' : 'errore'), $out ? count($out) . ' risultati' : '');
    return $out;
}

/* =====================================================================
 * 5) GOODREADS
 *    Goodreads non ha piu' API pubbliche (chiuse nel 2020): si legge la scheda pubblica del libro.
 *    Non e' un servizio ufficiale: Goodreads puo' rallentare o bloccare le richieste automatiche
 *    e le sue condizioni d'uso non le prevedono. Per questo la fonte e' attivabile a parte.
 * ===================================================================== */
function goodreads_parse_page($html, $isbn13 = '')
{
    $r = lookup_empty();
    $ld = html_jsonld_book($html);
    if ($ld) {
        $r['title'] = isset($ld['name']) ? lookup_clean($ld['name']) : '';
        if (isset($ld['author'])) {
            $a = $ld['author'];
            $names = array();
            foreach ((isset($a['name']) ? array($a) : (array)$a) as $one) {
                $names[] = is_array($one) ? (isset($one['name']) ? $one['name'] : '') : $one;
            }
            // Goodreads elenca anche traduttori e curatori come autori: si tiene il primo
            $names = array_values(array_filter($names));
            $r['authors'] = $names ? lookup_clean($names[0]) : '';
        }
        if (!empty($ld['numberOfPages'])) {
            $r['pages'] = (string)(int)$ld['numberOfPages'];
        }
        if (!empty($ld['isbn'])) {
            $r['isbn13'] = isbn_to13($ld['isbn']);
        }
        if (!empty($ld['inLanguage'])) {
            $lang = strtolower((string)$ld['inLanguage']);
            $r['language'] = $lang === 'italian' ? 'it' : ($lang === 'english' ? 'en' : str_cut($lang, 10));
        }
        if (!empty($ld['image']) && is_string($ld['image'])) {
            $r['covers'][] = preg_replace('#^http://#', 'https://', $ld['image']);
        }
    }
    if ($r['title'] === '') {
        $og = html_meta($html, 'og:title');
        $r['title'] = lookup_clean(preg_replace('/\s+by\s+.*$/i', '', $og));
    }
    // dati dell'edizione (editore, data) dal JSON interno della pagina
    if (preg_match('/"publisher"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/', $html, $m)) {
        $r['publisher'] = lookup_clean(json_decode('"' . $m[1] . '"'));
    }
    if (preg_match('/"publicationTime"\s*:\s*(-?\d{9,14})/', $html, $m)) {
        $r['year'] = date('Y', (int)floor((float)$m[1] / 1000));
    }
    if (($r['publisher'] === '' || $r['year'] === '') && preg_match('/Published\s+[^<]*?(\d{4})\s+by\s+([^<\n]+)/i', strip_tags($html), $m)) {
        if ($r['year'] === '') {
            $r['year'] = $m[1];
        }
        if ($r['publisher'] === '') {
            $r['publisher'] = lookup_clean($m[2]);
        }
    }
    if ($r['pages'] === '' && preg_match('/"numPages"\s*:\s*(\d+)/', $html, $m)) {
        $r['pages'] = $m[1];
    }
    $cands = array(html_meta($html, 'og:description'));
    if ($ld && !empty($ld['description'])) {
        $cands[] = lookup_clean_par($ld['description']);
    }
    if (preg_match_all('/"description(?:\(\{[^}]*\}\))?"\s*:\s*"((?:[^"\\\\]|\\\\.){80,})"/', $html, $mm)) {
        foreach ($mm[1] as $raw) {
            $txt = json_decode('"' . $raw . '"');
            if (is_string($txt)) {
                $cands[] = lookup_clean_par($txt);
            }
        }
    }
    $r['description'] = lookup_best_desc($cands);
    if ($isbn13 !== '' && $r['isbn13'] === '') {
        $r['isbn13'] = $isbn13;
    }
    $r['source'] = 'Goodreads';
    return $r;
}

function goodreads_by_isbn($isbn13)
{
    $urls = array('https://www.goodreads.com/book/isbn/' . $isbn13, 'https://www.goodreads.com/search?q=' . $isbn13);
    foreach ($urls as $u) {
        $html = lookup_fetch('Goodreads', $u, false);
        if ($html === null) {
            continue;
        }
        $i10 = isbn13_to_10($isbn13);
        if (strpos($html, $isbn13) === false && ($i10 === '' || strpos($html, $i10) === false)) {
            continue; // pagina di ricerca vuota o altro libro
        }
        $r = goodreads_parse_page($html, $isbn13);
        if ($r['title'] !== '' && ($r['isbn13'] === $isbn13 || $r['isbn13'] === '')) {
            $r['isbn13'] = $isbn13;
            lookup_note('Goodreads', 'ok');
            return $r;
        }
    }
    lookup_note('Goodreads', 'vuoto');
    return null;
}

function goodreads_search($q)
{
    $html = lookup_fetch('Goodreads', 'https://www.goodreads.com/search?' . http_build_query(array('q' => $q, 'search_type' => 'books')), false);
    $out = array();
    if ($html !== null && preg_match_all('#<tr[^>]*itemtype=["\']http://schema.org/Book["\'][^>]*>(.*?)</tr>#si', $html, $rows)) {
        foreach (array_slice($rows[1], 0, 10) as $row) {
            $r = lookup_empty();
            if (preg_match('#class=["\']bookTitle["\'][^>]*>.*?<span[^>]*>(.*?)</span>#si', $row, $m)) {
                $r['title'] = lookup_clean($m[1]);
            }
            if (preg_match_all('#class=["\']authorName["\'][^>]*>.*?<span[^>]*>(.*?)</span>#si', $row, $m)) {
                $r['authors'] = lookup_clean(implode(', ', array_slice($m[1], 0, 3)));
            }
            if (preg_match('#<img[^>]+class=["\']bookCover["\'][^>]+src=["\']([^"\']+)["\']#i', $row, $m)) {
                // le miniature dei risultati hanno il suffisso ._SY75_ : senza si ottiene l'immagine grande
                $r['covers'][] = preg_replace('/\._S[XY]\d+_(?=\.)/', '', $m[1]);
            }
            if (preg_match('#published\s*(\d{4})#i', strip_tags($row), $m)) {
                $r['year'] = $m[1];
            }
            $r['source'] = 'Goodreads';
            if ($r['title'] !== '') {
                $out[] = $r;
            }
        }
    }
    lookup_note('Goodreads', $out ? 'ok' : ($html !== null ? 'vuoto' : 'errore'), $out ? count($out) . ' risultati' : '');
    return $out;
}

/* =====================================================================
 * Copertine di riserva (indirizzi diretti per ISBN, verificati al momento dell'anteprima/salvataggio)
 * ===================================================================== */
function extra_covers($isbn13)
{
    $c = array();
    if (setting('lookup_shops') === '1') {
        $c[] = 'https://www.lafeltrinelli.it/images/' . $isbn13 . '_0_0_536_0_75.jpg';
        $c[] = 'https://www.ibs.it/images/' . $isbn13 . '_0_0_536_0_75.jpg';
    }
    if (setting('lookup_openlib') === '1') {
        $c[] = 'https://covers.openlibrary.org/b/isbn/' . $isbn13 . '-L.jpg?default=false';
    }
    if (setting('lookup_amazon') === '1') {
        $i10 = isbn13_to_10($isbn13);
        if ($i10 !== '') {
            $c[] = 'https://images-na.ssl-images-amazon.com/images/P/' . $i10 . '.01.LZZZZZZZ.jpg';
        }
    }
    return $c;
}

function lookup_finish($r)
{
    unset($r['_gid'], $r['_bid']);
    $r['covers'] = array_values(array_unique(array_filter($r['covers'])));
    $r['cover'] = $r['covers'] ? $r['covers'][0] : '';
    return $r;
}

function lookup_network_down()
{
    $rep = lookup_report();
    if (!$rep) {
        return false;
    }
    foreach ($rep as $x) {
        if ($x['status'] !== 'errore') {
            return false;
        }
    }
    return true;
}

function lookup_error_message($fallback)
{
    if (lookup_network_down()) {
        $first = lookup_report();
        return 'Il server non riesce a collegarsi alle piattaforme online (' . $first[0]['detail'] . '). '
             . 'Controlla in Gestione → Ricerca online → Prova adesso. Intanto puoi inserire i dati a mano.';
    }
    return $fallback;
}

/*
 * Ricerca per ISBN: interroga le fonti in ordine e unisce i dati.
 * Ci si ferma appena titolo, autore, editore, anno e pagine sono completi.
 */
function lookup_isbn($raw, $all_sources = false)
{
    $GLOBALS['LOOKUP_REPORT'] = array();
    $isbn13 = isbn_to13($raw);
    if ($isbn13 === '') {
        return array('ok' => false, 'error' => 'Codice ISBN non valido: controlla le cifre (10 o 13).', 'report' => array());
    }
    $sources = array();
    if (setting('lookup_google') === '1') {
        $sources[] = 'google_by_isbn';
    }
    if (setting('lookup_shops') === '1') {
        $sources[] = 'shop_by_isbn';
    }
    if (setting('lookup_sbn') === '1') {
        $sources[] = 'sbn_by_isbn';
    }
    if (setting('lookup_goodreads') === '1') {
        $sources[] = 'goodreads_by_isbn';
    }
    if (setting('lookup_openlib') === '1') {
        $sources[] = 'openlib_by_isbn';
    }
    $res = lookup_empty();
    $used = array();
    $covers = array();
    $descs = array();
    foreach ($sources as $fn) {
        $f = $fn($isbn13);
        if (!$f) {
            continue;
        }
        $used[] = $f['source'];
        foreach ($res as $k => $v) {
            if ($k !== 'covers' && $k !== 'source' && $k !== 'description' && $v === '' && isset($f[$k]) && $f[$k] !== '') {
                $res[$k] = $f[$k];
            }
        }
        $descs[] = $f['description'];
        $covers = array_merge($covers, $f['covers']);
        $complete = $res['title'] !== '' && $res['authors'] !== '' && $res['publisher'] !== '' && $res['year'] !== '' && $res['pages'] !== '';
        if (!$all_sources && $complete && lookup_best_desc($descs) !== '') {
            break;
        }
    }
    $res['description'] = lookup_best_desc($descs);
    $res['covers'] = array_merge($covers, extra_covers($isbn13));
    $res['isbn13'] = $isbn13;
    if ($res['isbn10'] === '') {
        $res['isbn10'] = isbn13_to_10($isbn13);
    }
    $res['source'] = implode(' + ', array_unique($used));
    if ($res['title'] === '') {
        return array('ok' => false, 'isbn13' => $isbn13, 'covers' => array_values(array_unique($res['covers'])), 'report' => lookup_report(),
            'error' => lookup_error_message('Nessuna delle fonti online conosce questo ISBN. Puoi inserire i dati a mano: le copertine trovate per questo codice sono comunque proposte qui sotto.'));
    }
    return array('ok' => true, 'book' => lookup_finish($res), 'report' => lookup_report());
}

// Ricerca per titolo (ed eventualmente autore): elenco di edizioni tra cui scegliere
function lookup_title($q)
{
    $GLOBALS['LOOKUP_REPORT'] = array();
    $q = trim($q);
    if (str_len($q) < 2) {
        return array('ok' => false, 'error' => 'Scrivi almeno 2 caratteri.', 'report' => array());
    }
    $lists = array();
    if (setting('lookup_google') === '1') {
        $lists[] = google_search($q);
    }
    if (setting('lookup_sbn') === '1') {
        $lists[] = sbn_search($q);
    }
    if (setting('lookup_goodreads') === '1') {
        $lists[] = goodreads_search($q);
    }
    if (setting('lookup_openlib') === '1') {
        $lists[] = openlib_search($q);
    }
    // si alternano i risultati delle diverse fonti, cosi' in cima ci sono le migliori di ciascuna
    $merged = array();
    $max = 0;
    foreach ($lists as $l) {
        $max = max($max, count($l));
    }
    for ($i = 0; $i < $max; $i++) {
        foreach ($lists as $l) {
            if (isset($l[$i])) {
                $merged[] = $l[$i];
            }
        }
    }
    $seen = array();
    $out = array();
    foreach ($merged as $r) {
        $key = $r['isbn13'] !== '' ? $r['isbn13'] : strtolower($r['title'] . '|' . $r['authors'] . '|' . $r['publisher'] . '|' . $r['year']);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = 1;
        if ($r['isbn13'] !== '') {
            $r['covers'] = array_merge($r['covers'], extra_covers($r['isbn13']));
        }
        $out[] = lookup_finish($r);
        if (count($out) >= 30) {
            break;
        }
    }
    if (!$out) {
        return array('ok' => false, 'report' => lookup_report(),
            'error' => lookup_error_message('Nessun risultato. Prova con meno parole, aggiungi il cognome dell\'autore o cerca per ISBN.'));
    }
    return array('ok' => true, 'results' => $out, 'report' => lookup_report());
}
