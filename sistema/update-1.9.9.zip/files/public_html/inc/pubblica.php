<?php
/*
 * OFFICINA (1.9.8): pubblicazione di aggiornamenti e plugin nel repository GitHub.
 *
 * Si usa su un'installazione separata, raggiungibile solo dalla rete di casa, che custodisce la chiave privata dell'autore.
 * Pubblica = firma il pacchetto, lo carica su GitHub, aggiorna il catalogo indice.json e lo firma.
 * Il token GitHub (fine-grained, solo quel repository, permesso "Contents: read and write") e' salvato cifrato.
 */
require_once dirname(__FILE__) . '/firma.php';
require_once dirname(__FILE__) . '/repo.php';
require_once dirname(__FILE__) . '/crypto.php';

function pub_config()
{
    return array(
        'owner' => (string)setting('pub_owner', ''), 'repo' => (string)setting('pub_repo', ''), 'branch' => (string)setting('pub_branch', 'main'),
        'token' => (string)setting('pub_token', ''),
    );
}

function pub_pronto()
{
    $c = pub_config();
    return $c['owner'] !== '' && $c['repo'] !== '' && $c['token'] !== '' && firma_chiave_pubblica() && firma_privata_presente();
}

function pub_token()
{
    $t = (string)setting('pub_token', '');
    return $t !== '' ? (string)sec_decrypt($t, 'github') : '';
}

// Indirizzo da scrivere sui siti (Sistema → Aggiornamento → Repository)
function pub_url_siti()
{
    $c = pub_config();
    return $c['owner'] !== '' && $c['repo'] !== '' ? 'https://raw.githubusercontent.com/' . $c['owner'] . '/' . $c['repo'] . '/' . ($c['branch'] !== '' ? $c['branch'] : 'main') . '/' : '';
}

/* ---------------- API di GitHub ---------------- */

function gh_chiama($method, $path, $body = null)
{
    $c = pub_config();
    $tok = pub_token();
    if ($tok === '') {
        throw new Exception('Token GitHub non impostato.');
    }
    if (!function_exists('curl_init')) {
        throw new Exception('Serve l\'estensione curl di PHP.');
    }
    // LIBRERIA_GITHUB_API: solo per le prove (un finto GitHub locale), impostabile soltanto sul server
    $api = getenv('LIBRERIA_GITHUB_API') ? rtrim((string)getenv('LIBRERIA_GITHUB_API'), '/') : 'https://api.github.com';
    $url = $api . '/repos/' . rawurlencode($c['owner']) . '/' . rawurlencode($c['repo']) . $path;
    $ch = curl_init($url);
    $h = array('Accept: application/vnd.github+json', 'X-GitHub-Api-Version: 2022-11-28', 'Authorization: Bearer ' . $tok, 'User-Agent: LibreriaDiCasa-officina');
    $opts = array(CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => $method, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 180,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_PROTOCOLS => getenv('LIBRERIA_GITHUB_API') ? (CURLPROTO_HTTP | CURLPROTO_HTTPS) : CURLPROTO_HTTPS, CURLOPT_FOLLOWLOCATION => false);
    if ($body !== null) {
        $h[] = 'Content-Type: application/json';
        $opts[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
    $opts[CURLOPT_HTTPHEADER] = $h;
    curl_setopt_array($ch, $opts);
    if (defined('HTTP_PROXY_URL') && HTTP_PROXY_URL !== '') {
        curl_setopt($ch, CURLOPT_PROXY, HTTP_PROXY_URL);
    }
    if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
        curl_setopt($ch, CURLOPT_CAINFO, CA_BUNDLE);
    }
    $out = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_done($ch);
    if ($out === false) {
        throw new Exception('GitHub non raggiungibile: ' . $err);
    }
    $j = json_decode((string)$out, true);
    return array($code, is_array($j) ? $j : array());
}

function gh_errore($code, $j)
{
    $m = isset($j['message']) ? (string)$j['message'] : '';
    if ($code === 401) {
        return 'GitHub rifiuta il token (scaduto o sbagliato): creane uno nuovo e incollalo qui.';
    }
    if ($code === 403) {
        return 'Il token non ha il permesso di scrivere in questo repository (serve "Contents: Read and write").';
    }
    if ($code === 404) {
        return 'Repository non trovato: controlla nome utente e nome del repository, e che il token abbia accesso proprio a quel repository.';
    }
    return 'Errore di GitHub (' . $code . ')' . ($m !== '' ? ': ' . $m : '') . '.';
}

// Prova la connessione: restituisce una descrizione del repository
function pub_prova()
{
    list($code, $j) = gh_chiama('GET', '');
    if ($code !== 200) {
        throw new Exception(gh_errore($code, $j));
    }
    if (!empty($j['private'])) {
        throw new Exception('Il repository è privato: i siti non potrebbero leggerlo. In GitHub → Settings → Danger Zone rendilo pubblico (i pacchetti sono firmati).');
    }
    if (isset($j['permissions']['push']) && !$j['permissions']['push']) {
        throw new Exception('Il token può leggere ma non scrivere: dagli il permesso "Contents: Read and write".');
    }
    return 'Collegato a ' . $j['full_name'] . ' (ramo predefinito: ' . (isset($j['default_branch']) ? $j['default_branch'] : '?') . ').';
}

// Legge un file del repository: array(contenuto, sha) oppure array(null, null) se non c'e'
function gh_leggi($path)
{
    $c = pub_config();
    list($code, $j) = gh_chiama('GET', '/contents/' . str_replace('%2F', '/', rawurlencode($path)) . '?ref=' . rawurlencode($c['branch']));
    if ($code === 404) {
        return array(null, null);
    }
    if ($code !== 200 || !isset($j['sha'])) {
        throw new Exception(gh_errore($code, $j));
    }
    if (isset($j['content']) && $j['content'] !== '') {
        return array(base64_decode(str_replace("\n", '', $j['content'])), $j['sha']);
    }
    // file grandi: si scarica dal blob
    list($c2, $b) = gh_chiama('GET', '/git/blobs/' . $j['sha']);
    if ($c2 !== 200 || !isset($b['content'])) {
        throw new Exception(gh_errore($c2, $b));
    }
    return array(base64_decode(str_replace("\n", '', $b['content'])), $j['sha']);
}

function gh_scrivi($path, $bin, $messaggio, $sha = null)
{
    $c = pub_config();
    $body = array('message' => $messaggio, 'content' => base64_encode($bin), 'branch' => $c['branch']);
    if ($sha) {
        $body['sha'] = $sha;
    }
    list($code, $j) = gh_chiama('PUT', '/contents/' . str_replace('%2F', '/', rawurlencode($path)), $body);
    if ($code !== 200 && $code !== 201) {
        throw new Exception(gh_errore($code, $j));
    }
}

// sha del file su GitHub (per sovrascriverlo), null se non c'e'
function gh_sha($path)
{
    $c = pub_config();
    list($code, $j) = gh_chiama('GET', '/contents/' . str_replace('%2F', '/', rawurlencode($path)) . '?ref=' . rawurlencode($c['branch']));
    return $code === 200 && isset($j['sha']) ? (string)$j['sha'] : null;
}

/* ---------------- Catalogo ---------------- */

// Catalogo attuale su GitHub (verificato con la chiave del sito): array(dati, sha)
function pub_catalogo()
{
    list($raw, $sha) = gh_leggi('indice.json');
    if ($raw === null) {
        return array(array('app' => 'libreria-di-casa', 'seq' => 0, 'emesso' => '', 'sistema' => null, 'plugin' => array()), null);
    }
    $pub = firma_chiave_pubblica();
    list($dati) = repo_verifica_indice($raw, $pub['pk']);
    if (!isset($dati['plugin']) || !is_array($dati['plugin'])) {
        $dati['plugin'] = array();
    }
    return array($dati, $sha);
}

function pub_salva_catalogo($dati, $sha, $priv, $messaggio)
{
    // numero sempre crescente anche se il repository venisse ricreato da zero (i siti rifiutano cataloghi con un numero piu' basso)
    $dati['seq'] = max((int)$dati['seq'] + 1, time());
    $dati['emesso'] = date('c');
    gh_scrivi('indice.json', repo_firma_indice($dati, $priv), $messaggio, $sha);
    // copia locale, utile per controllare cosa e' stato pubblicato anche senza GitHub
    @file_put_contents(pub_dir() . '/indice-pubblicato.json', json_encode($dati, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return $dati;
}

function pub_dir()
{
    $d = DATA_DIR . '/pubblica';
    if (!is_dir($d)) {
        @mkdir($d, 0700, true);
        @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return $d;
}

/* ---------------- Pubblicazione ---------------- */

function pub_leggi_zip($zip_path, $nome)
{
    $z = new ZipArchive();
    if ($z->open($zip_path) !== true) {
        return false;
    }
    $r = $z->getFromName($nome);
    $z->close();
    return $r;
}

/*
 * Pubblica uno ZIP (aggiornamento o plugin). $note: testo facoltativo (una nota per riga) per i plugin.
 * Restituisce un messaggio di riepilogo.
 */
function pub_pubblica($zip_path, $passphrase, $note_extra = '')
{
    if (!pub_pronto()) {
        throw new Exception('L\'officina non è ancora pronta: servono la chiave dell\'autore (con la chiave privata) e il collegamento a GitHub.');
    }
    $tipo = firma_tipo_zip($zip_path);
    if (!in_array($tipo, array('aggiornamento', 'plugin'), true)) {
        throw new Exception('Il file non è né un aggiornamento (update-….zip) né un plugin della Libreria di Casa.');
    }
    if (firma_pass_bloccata()) {
        throw new Exception('Troppe passphrase sbagliate: riprova tra 15 minuti.');
    }
    try {
        $priv = firma_apri_privata($passphrase);
    } catch (Exception $e) {
        firma_pass_errata();
        throw $e;
    }
    // metadati dal pacchetto
    if ($tipo === 'aggiornamento') {
        $m = json_decode((string)pub_leggi_zip($zip_path, 'libreria-update.json'), true);
        if (!is_array($m) || empty($m['version']) || !preg_match('/^\d+\.\d+\.\d+$/', (string)$m['version'])) {
            throw new Exception('Il pacchetto di aggiornamento non ha un numero di versione valido.');
        }
        $versione = (string)$m['version'];
        $file = 'sistema/update-' . $versione . '.zip';
    } else {
        $m = json_decode((string)pub_leggi_zip($zip_path, 'plugin.json'), true);
        if (!is_array($m) || empty($m['id']) || !plugin_id_ok_repo($m['id']) || empty($m['versione']) || !preg_match('/^\d+\.\d+(\.\d+)?$/', (string)$m['versione'])) {
            throw new Exception('plugin.json non valido (servono id e versione).');
        }
        $versione = (string)$m['versione'];
        $file = 'plugin/' . $m['id'] . '-' . $versione . '.zip';
    }
    list($cat, $sha_cat) = pub_catalogo();
    $prima = $tipo === 'aggiornamento' ? (isset($cat['sistema']['versione']) ? (string)$cat['sistema']['versione'] : '')
        : (isset($cat['plugin'][$m['id']]['versione']) ? (string)$cat['plugin'][$m['id']]['versione'] : '');
    if ($prima !== '' && !version_compare($versione, $prima, '>')) {
        throw new Exception('Nel repository c\'è già la versione ' . $prima . ': pubblica una versione più alta (cambia il numero di versione del pacchetto).');
    }
    // firma (sostituisce un'eventuale firma precedente) e controllo
    firma_firma_zip($zip_path, $priv, $tipo);
    $v = firma_verifica_zip($zip_path, $tipo);
    if ($v['stato'] !== 'firmato') {
        throw new Exception('Controllo della firma non riuscito: ' . $v['testo']);
    }
    $bin = (string)file_get_contents($zip_path);
    if (strlen($bin) > REPO_MAX_FILE) {
        throw new Exception('Il pacchetto è troppo grande per il repository (massimo 100 MB).');
    }
    $voce = array('versione' => $versione, 'file' => $file, 'sha256' => hash('sha256', $bin), 'dim' => strlen($bin), 'data' => date('c'));
    gh_scrivi($file, $bin, 'Pubblica ' . $file, gh_sha($file));
    if ($tipo === 'aggiornamento') {
        $note = array_values(array_filter(array_map('strval', isset($m['notes']) ? (array)$m['notes'] : array())));
        $voce += array('richiede' => (string)(isset($m['requires']) ? $m['requires'] : ''), 'php_min' => (string)(isset($m['php_min']) ? $m['php_min'] : ''),
            'db_version' => (int)(isset($m['db_version']) ? $m['db_version'] : 0), 'note' => $note);
        $storico = isset($cat['sistema']['storico']) ? (array)$cat['sistema']['storico'] : array();
        array_unshift($storico, array('versione' => $versione, 'data' => $voce['data'], 'note' => $note));
        $voce['storico'] = array_slice($storico, 0, 40);
        $cat['sistema'] = $voce;
        $chi = 'versione ' . $versione . ' del sistema';
    } else {
        $note = array_values(array_filter(array_map('trim', preg_split('/\R/', (string)$note_extra))));
        $voce += array('nome' => str_cut((string)(isset($m['nome']) ? $m['nome'] : $m['id']), 100), 'autore' => str_cut((string)(isset($m['autore']) ? $m['autore'] : ''), 100),
            'descrizione' => str_cut((string)(isset($m['descrizione']) ? $m['descrizione'] : ''), 600), 'richiede' => (string)(isset($m['richiede']) ? $m['richiede'] : ''),
            'php_min' => (string)(isset($m['php_min']) ? $m['php_min'] : ''), 'note' => $note);
        // icona: dal pacchetto, se dichiarata in plugin.json
        if (!empty($m['icona']) && preg_match('#^[A-Za-z0-9._\-/]{1,120}\.(png|jpg|webp)$#', (string)$m['icona'])) {
            $ico = pub_leggi_zip($zip_path, (string)$m['icona']);
            if ($ico !== false && strlen($ico) < 512000 && @getimagesizefromstring($ico)) {
                $ext = strtolower(pathinfo($m['icona'], PATHINFO_EXTENSION));
                $fi = 'plugin/' . $m['id'] . '.' . $ext;
                $vecchia = isset($cat['plugin'][$m['id']]['icona']['sha256']) ? $cat['plugin'][$m['id']]['icona']['sha256'] : '';
                if ($vecchia !== hash('sha256', $ico)) {
                    gh_scrivi($fi, $ico, 'Icona di ' . $m['id'], gh_sha($fi));
                }
                $voce['icona'] = array('file' => $fi, 'sha256' => hash('sha256', $ico), 'dim' => strlen($ico));
            }
        }
        $cat['plugin'][$m['id']] = $voce;
        ksort($cat['plugin']);
        $chi = 'plugin «' . $voce['nome'] . '» ' . $versione;
    }
    $cat = pub_salva_catalogo($cat, $sha_cat, $priv, 'Catalogo: ' . $chi);
    if (function_exists('sodium_memzero')) {
        sodium_memzero($priv[0]);
    }
    app_log('pubblicato', 'Pubblicato nel repository: ' . $chi . ' (catalogo n. ' . $cat['seq'] . ')', 'warn');
    return 'Pubblicato: ' . $chi . '. I siti collegati lo vedranno al prossimo controllo (entro un giorno, oppure subito con «Controlla adesso»; GitHub può impiegare fino a 5 minuti).';
}

// Toglie un plugin dal catalogo (il file resta su GitHub, ma i siti non lo vedono piu' tra i disponibili)
function pub_ritira_plugin($id, $passphrase)
{
    if (!plugin_id_ok_repo($id)) {
        throw new Exception('Plugin non valido.');
    }
    if (firma_pass_bloccata()) {
        throw new Exception('Troppe passphrase sbagliate: riprova tra 15 minuti.');
    }
    try {
        $priv = firma_apri_privata($passphrase);
    } catch (Exception $e) {
        firma_pass_errata();
        throw $e;
    }
    list($cat, $sha) = pub_catalogo();
    if (!isset($cat['plugin'][$id])) {
        throw new Exception('Il plugin non è nel catalogo.');
    }
    $nome = $cat['plugin'][$id]['nome'];
    unset($cat['plugin'][$id]);
    pub_salva_catalogo($cat, $sha, $priv, 'Catalogo: ritirato ' . $id);
    app_log('pubblicato', 'Plugin «' . $nome . '» ritirato dal repository', 'warn');
    return 'Plugin «' . $nome . '» tolto dal catalogo.';
}
