<?php
$pages = extras_ready() ? db()->query('SELECT * FROM pages ORDER BY sort_order, title')->fetchAll() : array();
?>
<div class="card">
  <p class="sub">Le pagine pubblicate e "nel menu" compaiono nel menu in alto del sito (pulsante ☰) e in fondo a ogni pagina. Puoi anche collegarle da altre pagine con il loro indirizzo.</p>
  <table class="tbl">
    <thead><tr><th>Titolo</th><th>Indirizzo</th><th>Stato</th><th>Visibile a</th><th class="num">Ordine</th><th>Modificata</th><th class="act"></th></tr></thead>
    <tbody>
    <?php foreach ($pages as $p): ?>
      <tr><td><a class="rt" href="gestione.php?sez=pagina&amp;id=<?= (int)$p['id'] ?>"><?= h($p['title']) ?></a></td>
        <td><code>page.php?p=<?= h($p['slug']) ?></code></td>
        <td><?= (int)$p['active'] ? '<span class="pill ok">Pubblicata</span>' : '<span class="pill">Bozza</span>' ?><?= (int)$p['in_menu'] ? ' <span class="pill">nel menu</span>' : '' ?></td>
        <td class="muted"><?= (int)$p['guests'] ? 'tutti, anche ospiti' : 'solo utenti registrati' ?></td>
        <td class="num"><?= (int)$p['sort_order'] ?></td>
        <td class="muted"><?= h(fmt_dt($p['updated_at'])) ?></td>
        <td class="act"><a class="iconbtn sm" href="gestione.php?sez=pagina&amp;id=<?= (int)$p['id'] ?>" title="Modifica"><?= icon('edit', 15) ?></a>
          <a class="iconbtn sm" href="page.php?p=<?= h(rawurlencode($p['slug'])) ?>&amp;anteprima=1" target="_blank" rel="noopener" title="Apri"><?= admin_icon('ext', 15) ?></a>
          <form method="post" data-confirm="Eliminare la pagina &quot;<?= h($p['title']) ?>&quot;? Non si può annullare."><?= csrf_field() ?>
            <input type="hidden" name="action" value="page_del"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <button class="iconbtn sm danger" type="submit" title="Elimina"><?= icon('trash', 15) ?></button></form></td></tr>
    <?php endforeach; ?>
    <?php if (!$pages): ?><tr><td colspan="7" class="empty-row">Nessuna pagina. Idee: "Come è organizzata la libreria", "Regole per i prestiti", "Libri da comprare".
      <a class="link" href="gestione.php?sez=pagina">Crea la prima</a></td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
