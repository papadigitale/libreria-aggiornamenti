<?php
/* Modifica di una pagina ($PAGE preparato da gestione.php; null = nuova) */
$p = $PAGE ? $PAGE : array('id' => 0, 'title' => '', 'slug' => '', 'body' => '', 'in_menu' => 1, 'guests' => 1, 'active' => 1, 'sort_order' => 10,
    'format' => 'md', 'css' => '', 'show_title' => 1);
$v4 = pages_v4();
$fmt = isset($p['format']) && $p['format'] === 'html' ? 'html' : 'md';
// immagini caricate per le pagine (cartella data/uploads, nome che inizia con "pagina_")
$imgs = array();
foreach ((is_dir(UPLOADS_DIR) ? scandir(UPLOADS_DIR) : array()) as $f) {
    if (preg_match('/^pagina_[a-z0-9_\-]+\.(jpg|png|webp)$/', $f)) {
        $imgs[$f] = filemtime(UPLOADS_DIR . '/' . $f);
    }
}
arsort($imgs);
?>
<div class="adm-edit">
  <form method="post" class="card stack" id="pgform" action="gestione.php?sez=pagina<?= $p['id'] ? '&amp;id=' . (int)$p['id'] : '' ?>">
    <?= csrf_field() ?><input type="hidden" name="action" value="page_save"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
    <label class="lab" for="pg-title">Titolo</label>
    <input class="input big" id="pg-title" name="title" value="<?= h($p['title']) ?>" maxlength="150" required>
    <?php if ($v4): ?>
    <div class="fmt-switch" role="radiogroup" aria-label="Formato del testo">
      <label><input type="radio" name="format" value="md" <?= $fmt === 'md' ? 'checked' : '' ?> data-fmt> Testo semplice</label>
      <label><input type="radio" name="format" value="html" <?= $fmt === 'html' ? 'checked' : '' ?> data-fmt> Codice HTML</label>
    </div>
    <?php endif; ?>
    <label class="lab" for="pg-body">Contenuto</label>
    <div class="mdbar" data-md-bar data-for-fmt="md">
      <button type="button" data-md="**" title="Grassetto"><b>G</b></button>
      <button type="button" data-md="*" title="Corsivo"><i>C</i></button>
      <button type="button" data-md-line="## " title="Titolo">Titolo</button>
      <button type="button" data-md-line="- " title="Elenco">• Elenco</button>
      <button type="button" data-md-line="> " title="Citazione">“ Citazione</button>
      <button type="button" data-md-link title="Collegamento">Link</button>
      <?php if ((int)setting('db_version', '1') >= 10): ?><button type="button" data-media-pick title="Immagini, PDF, video e audio">＋ Da Media</button><?php endif; ?>
    </div>
    <div class="mdbar" data-html-bar data-for-fmt="html" hidden>
      <button type="button" data-tag="h2">Titolo</button>
      <button type="button" data-tag="p">Paragrafo</button>
      <button type="button" data-tag="strong"><b>G</b></button>
      <button type="button" data-tag="em"><i>C</i></button>
      <button type="button" data-snippet='<ul>&#10;  <li>…</li>&#10;</ul>'>Elenco</button>
      <button type="button" data-snippet='<a href="https://">testo</a>'>Link</button>
      <button type="button" data-snippet='<div class="box">&#10;  …&#10;</div>'>Riquadro</button>
      <button type="button" data-snippet='<div class="colonne">&#10;  <div>…</div>&#10;  <div>…</div>&#10;</div>'>Due colonne</button>
      <?php if ((int)setting('db_version', '1') >= 10): ?><button type="button" data-media-pick title="Immagini, PDF, video e audio">＋ Da Media</button><?php endif; ?>
    </div>
    <textarea class="input mdtext" id="pg-body" name="body" rows="22" data-md-text spellcheck="<?= $fmt === 'html' ? 'false' : 'true' ?>"><?= h((string)$p['body']) ?></textarea>
    <p class="hint" data-for-fmt="md">Formattazione: <code>## Titolo</code> · <code>**grassetto**</code> · <code>*corsivo*</code> · <code>- elenco</code> ·
      <code>[testo](https://indirizzo)</code> · <code>---</code> linea. Per collegare un libro: <code>[Il nome della rosa](libro.php?id=12)</code>.</p>
    <p class="hint" data-for-fmt="html" hidden>Puoi usare titoli, paragrafi, elenchi, tabelle, immagini, collegamenti, <code>&lt;div&gt;</code> e <code>&lt;section&gt;</code>
      con classi e stili, <code>&lt;details&gt;</code>, video e audio. Per sicurezza vengono tolti script, moduli e contenuti incorporati da altri siti
      (<code>&lt;script&gt;</code>, <code>&lt;iframe&gt;</code>, <code>onclick</code>…). Classi pronte: <code>box</code>, <code>colonne</code>, <code>centro</code>, <code>evidenza</code>.</p>
    <?php if ($v4): ?>
    <?php if (is_admin()): ?>
    <details class="css-box" <?= !empty($p['css']) ? 'open' : '' ?>>
      <summary>CSS aggiuntivo per questa pagina</summary>
      <textarea class="input mdtext" name="css" rows="10" spellcheck="false" placeholder=".page-body h2 { color: #7a1f2b; }&#10;.box { background: #fff8e8; }"><?= h((string)$p['css']) ?></textarea>
      <p class="hint">Vale solo per questa pagina. Il contenuto si trova dentro <code>.page-<?= h($p['slug'] !== '' ? $p['slug'] : 'indirizzo') ?></code>.
        Per lo stile di tutto il sito usa Aspetto → CSS personalizzato.</p>
    </details>
    <?php elseif (!empty($p['css'])): ?>
    <p class="hint">Questa pagina ha uno stile personalizzato, modificabile solo dall'Admin.</p>
    <?php endif; ?>
    <?php endif; ?>
    <div class="savebar"><button class="btn primary small" type="submit">Salva</button>
      <a class="btn link small" href="gestione.php?sez=pagine">Torna alle pagine</a></div>
  </form>

  <aside class="adm-aside">
    <div class="card stack">
      <div class="ct">Pubblicazione</div>
      <label class="check switch"><input type="checkbox" name="active" value="1" form="pgform" <?= (int)$p['active'] ? 'checked' : '' ?>><span>Pubblicata</span></label>
      <label class="check switch"><input type="checkbox" name="in_menu" value="1" form="pgform" <?= (int)$p['in_menu'] ? 'checked' : '' ?>><span>Nel menu del sito</span></label>
      <label class="check switch"><input type="checkbox" name="guests" value="1" form="pgform" <?= (int)$p['guests'] ? 'checked' : '' ?>><span>Visibile anche agli ospiti</span></label>
      <?php if ($v4): ?>
      <label class="check switch"><input type="checkbox" name="show_title" value="1" form="pgform" <?= !isset($p['show_title']) || (int)$p['show_title'] ? 'checked' : '' ?>><span>Mostra il titolo in cima</span></label>
      <?php endif; ?>
      <label class="lab" for="pg-slug">Indirizzo</label>
      <input class="input" id="pg-slug" name="slug" form="pgform" value="<?= h($p['slug']) ?>" maxlength="80" placeholder="creato dal titolo">
      <label class="lab" for="pg-ord">Ordine nel menu</label>
      <input class="input" id="pg-ord" name="sort_order" form="pgform" value="<?= (int)$p['sort_order'] ?>" inputmode="numeric">
      <?php if ($p['id']): ?><a class="btn ghost small" href="page.php?p=<?= h(rawurlencode($p['slug'])) ?>&amp;anteprima=1" target="_blank" rel="noopener"><?= admin_icon('ext', 15) ?> Apri la pagina</a><?php endif; ?>
    </div>
    <?php if ($p['id']): ?>
    <div class="card"><div class="ct">Anteprima sul telefono</div>
      <p class="hint" style="margin-top:0">Ultimo salvataggio.</p>
      <div class="mini-phone"><iframe src="page.php?p=<?= h(rawurlencode($p['slug'])) ?>&amp;anteprima=1&amp;embed=1" title="Anteprima della pagina" loading="lazy"></iframe></div></div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" class="card stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="page_image"><input type="hidden" name="back" value="gestione.php?sez=pagina<?= $p['id'] ? '&id=' . (int)$p['id'] : '' ?>">
      <div class="ct">Immagini per le pagine</div>
      <input class="input" type="file" name="image" accept="image/*" required aria-label="Immagine">
      <button class="btn ghost small" type="submit"><?= admin_icon('upload', 15) ?> Carica</button>
      <?php foreach (array_slice(array_keys($imgs), 0, 12) as $f): ?>
      <div class="imgrow"><img src="<?= h(asset_url($f)) ?>" alt=""><button type="button" class="link" data-insert-img="<?= h(asset_url($f)) ?>">Inserisci</button></div>
      <?php endforeach; ?>
      <p class="hint">"Inserisci" mette l'immagine nel testo, dove si trova il cursore.</p>
    </form>
    <?php if ($p['id']): ?>
    <form method="post" data-confirm="Eliminare la pagina &quot;<?= h($p['title']) ?>&quot;?"><?= csrf_field() ?><input type="hidden" name="action" value="page_del">
      <input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn danger-ghost small" type="submit"><?= icon('trash', 15) ?> Elimina la pagina</button></form>
    <?php endif; ?>
  </aside>
</div>
