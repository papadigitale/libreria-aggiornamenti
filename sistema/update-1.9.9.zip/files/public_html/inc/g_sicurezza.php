<?php
$window = date('Y-m-d H:i:s', time() - setting_int('sec_lock_minutes', 1, 1440) * 60);
$max = setting_int('sec_max_attempts', 3, 50);
$st = db()->prepare('SELECT ip, COUNT(*) AS n, MAX(created_at) AS last FROM login_attempts WHERE success = 0 AND created_at >= ? GROUP BY ip HAVING COUNT(*) >= ' . (int)$max);
$st->execute(array($window));
$lockedIps = $st->fetchAll();
$st = db()->prepare("SELECT username, COUNT(*) AS n, MAX(created_at) AS last FROM login_attempts WHERE success = 0 AND created_at >= ? AND username <> '' GROUP BY username HAVING COUNT(*) >= " . (int)$max);
$st->execute(array($window));
$lockedUsers = $st->fetchAll();
$attempts = db()->query('SELECT * FROM login_attempts ORDER BY id DESC LIMIT 25')->fetchAll();
?>
<?= settings_form_open('sicurezza') ?>
  <div class="ct"><?= icon('shield', 18) ?> Accessi e password</div>
  <div class="row2"><div><?= render_setting('sec_max_attempts', 'Tentativi errati prima del blocco') ?></div><div><?= render_setting('sec_lock_minutes', 'Minuti di blocco') ?></div></div>
  <?= render_setting('sec_idle_minutes') ?>
  <?= render_setting('sec_session_max_hours') ?>
  <?= render_setting('sec_remember_on') ?>
  <?= render_setting('sec_remember_days') ?>
  <p class="hint">«Ricorda questo dispositivo» funziona solo aprendo il sito in https://. Chi entra così deve rimettere la password per le sezioni delicate
    del pannello (aggiornamenti, plugin, utenti, sicurezza, backup). Spegnendo l'opzione, i dispositivi già ricordati smettono di entrare da soli.</p>
  <?= render_setting('sec_min_password') ?>
  <?= render_setting('sec_2fa_admin') ?>
  <?= render_setting('sec_passkeys') ?>
  <p class="hint">Con le chiavi di accesso ognuno può entrare con Bitwarden (o Google, Apple, Windows Hello) senza password né codice:
    si creano da <a class="link" href="account.php#chiavi">Il mio account</a>. Funzionano solo dall'indirizzo del sito in HTTPS, non dall'indirizzo IP.</p>
  <?= render_setting('guest_enabled') ?>

  <p class="hint">Con il <a class="link" href="gestione.php?sez=firewall">Firewall</a> attivo, chi supera questi tentativi viene bloccato su tutto il sito, con blocchi sempre più lunghi se ci riprova.</p>

  <div class="ct sep">Controllo accessi per indirizzo IP</div>
  <?= render_setting('sec_ip_allow') ?>
  <p class="hint">Il tuo dispositivo ora è <code><?= h(client_ip()) ?></code>. Esempi: <code>192.168.1.*</code> (tutta la rete di casa),
    <code>192.168.1.0/24</code>, <code>192.168.1.35</code>. Dal server stesso (localhost) si entra sempre.</p>

  <div class="ct sep">Connessione</div>
  <?= render_setting('sec_force_https') ?>
  <p class="hint">Stato attuale: <?= is_https() ? '<b class="ok-text">HTTPS attivo</b>' : 'collegamento non cifrato (HTTP)' ?>.
    Attivalo solo dopo aver installato un certificato sul server, altrimenti il sito non si aprirà.</p>
  <?= render_setting('log_retention') ?>
  <button class="btn primary" type="submit">Salva le impostazioni di sicurezza</button>
</form>

<div class="card">
  <div class="ct"><?= icon('lock', 18) ?> Accessi bloccati ora</div>
  <?php if (!$lockedIps && !$lockedUsers): ?><p class="sub">Nessun blocco attivo.</p><?php endif; ?>
  <?php foreach (array(array('ip', $lockedIps, 'IP'), array('username', $lockedUsers, 'Utente')) as $grp): foreach ($grp[1] as $l): ?>
  <form method="post" class="lrow">
    <?= csrf_field() ?><input type="hidden" name="action" value="unlock"><input type="hidden" name="key" value="<?= h($grp[0]) ?>">
    <input type="hidden" name="value" value="<?= h($l[$grp[0]]) ?>">
    <span><b><?= h($grp[2]) ?> <?= h($l[$grp[0]]) ?></b><small><?= (int)$l['n'] ?> errori · ultimo <?= h(fmt_dt($l['last'])) ?></small></span>
    <button class="btn ghost small" type="submit">Sblocca</button>
  </form>
  <?php endforeach; endforeach; ?>
</div>

<div class="card">
  <div class="ct">Ultimi tentativi di accesso</div>
  <div class="table-wrap"><table class="tbl">
    <tr><th>Quando</th><th>Utente</th><th>IP</th><th>Esito</th></tr>
    <?php foreach ($attempts as $a): ?>
    <tr><td><?= h(fmt_dt($a['created_at'])) ?></td><td><?= h($a['username']) ?></td><td><?= h($a['ip']) ?></td>
      <td><?= (int)$a['success'] ? '<span class="tag ok">Riuscito</span>' : '<span class="tag off">Errato</span>' ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
