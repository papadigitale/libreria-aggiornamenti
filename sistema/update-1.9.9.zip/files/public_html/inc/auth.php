<?php
/*
 * Accesso, blocco dopo troppi tentativi errati, verifica in due passaggi.
 */
require_once dirname(__FILE__) . '/totp.php';

// Restituisce i secondi di blocco rimanenti (0 = non bloccato) per IP o per nome utente
function login_lock_remaining($ip, $username)
{
    $max = setting_int('sec_max_attempts', 3, 50);
    $window = setting_int('sec_lock_minutes', 1, 1440) * 60;
    $since = date('Y-m-d H:i:s', time() - $window);
    $worst = 0;
    $checks = array(array('ip = ?', $ip));
    // il blocco del nome utente (contro gli attacchi da tanti IP) non ferma i dispositivi gia' conosciuti:
    // cosi' chi attacca il tuo nome utente non puo' chiuderti fuori da casa o dal tuo telefono
    $known = function_exists('fw_enabled') && fw_enabled() && fw_known_device($ip);
    if ($username !== '' && !$known) {
        $checks[] = array('username = ?', $username);
    }
    foreach ($checks as $c) {
        $st = db()->prepare('SELECT created_at FROM login_attempts WHERE ' . $c[0] . ' AND success = 0 AND created_at >= ? ORDER BY created_at DESC LIMIT ' . (int)$max);
        $st->execute(array($c[1], $since));
        $rows = $st->fetchAll(PDO::FETCH_COLUMN);
        if (count($rows) >= $max) {
            $oldest = strtotime($rows[count($rows) - 1]);
            $left = $oldest + $window - time();
            if ($left > $worst) {
                $worst = $left;
            }
        }
    }
    return $worst;
}

function record_attempt($ip, $username, $success)
{
    db()->prepare('INSERT INTO login_attempts (ip, username, success, created_at) VALUES (?,?,?,?)')
        ->execute(array($ip, str_cut($username, 60), $success ? 1 : 0, now()));
    if ($success) {
        // un accesso riuscito azzera gli errori precedenti di quell'utente da quell'IP
        db()->prepare('DELETE FROM login_attempts WHERE success = 0 AND ip = ? AND username = ?')->execute(array($ip, $username));
    }
}

function minutes_text($seconds)
{
    $m = (int)ceil($seconds / 60);
    return $m <= 1 ? '1 minuto' : $m . ' minuti';
}

/*
 * Esito: array('ok'=>bool, 'error'=>string, 'need_2fa'=>bool)
 */
function do_login($username, $password)
{
    $ip = client_ip();
    $username = str_cut(trim($username), 60);
    if (function_exists('fw_login_refused') && fw_login_refused($ip)) {
        app_log('login_sospeso', 'Accesso rifiutato durante un attacco distribuito per "' . $username . '"', 'warn', $username);
        // conta comunque come errore: chi insiste viene bloccato come sempre
        record_attempt($ip, $username, false);
        $st = db()->prepare('SELECT COUNT(*) FROM users WHERE username = ?');
        $st->execute(array($username));
        fw_after_failed_login($ip, $username, (int)$st->fetchColumn() > 0);
        return array('ok' => false, 'error' => 'Per un attacco in corso gli accessi da dispositivi nuovi sono sospesi per qualche minuto. Riprova più tardi.', 'need_2fa' => false);
    }
    $left = login_lock_remaining($ip, $username);
    if ($left > 0) {
        app_log('login_bloccato', 'Tentativo durante il blocco per "' . $username . '"', 'warn', $username);
        return array('ok' => false, 'error' => 'Troppi tentativi errati. Riprova tra ' . minutes_text($left) . '.', 'need_2fa' => false);
    }
    $st = db()->prepare('SELECT * FROM users WHERE username = ?');
    $st->execute(array($username));
    $u = $st->fetch();
    // confronto eseguito comunque, per non rivelare se l'utente esiste
    $hash = $u ? $u['password_hash'] : (defined('PASSWORD_ARGON2ID') ? '$argon2id$v=19$m=65536,t=3,p=1$eVNrQTF3Tm5Td2ZBL1NrNg$D/55yt/cp6RhrN3khilIgo7/aD8gBLMA9aUtO5ce7Qw'
        : '$2y$12$KpgwPAVwL8ExIh4zgH9Y0ui1a24t7k1.rXzcYVOLkKufXt4DNj64e');
    $good = password_verify($password, $hash) && $u;
    if (!$good) {
        record_attempt($ip, $username, false);
        app_log('login_fallito', 'Credenziali errate per "' . $username . '"', 'warn', $username);
        if (function_exists('fw_after_failed_login')) {
            fw_after_failed_login($ip, $username, (bool)$u);
        }
        usleep(random_int(300000, 700000)); // rallenta chi prova molte password
        if (login_lock_remaining($ip, $username) > 0) {
            app_log('blocco_attivato', 'Accessi bloccati per ' . setting_int('sec_lock_minutes') . ' minuti (utente "' . $username . '", IP ' . $ip . ')', 'alert', $username);
        }
        return array('ok' => false, 'error' => 'Nome utente o password non corretti.', 'need_2fa' => false);
    }
    if ((int)$u['active'] !== 1) {
        record_attempt($ip, $username, false);
        app_log('login_disattivato', 'Accesso negato: account disattivato', 'warn', $username);
        return array('ok' => false, 'error' => 'Questo account è disattivato. Contatta l\'amministratore.', 'need_2fa' => false);
    }
    if (pw_needs_rehash($u['password_hash'])) {
        // la password viene ricifrata con l'algoritmo piu' robusto disponibile (Argon2id)
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute(array(pw_hash($password), $u['id']));
    }
    if ((int)$u['totp_enabled'] === 1 && $u['totp_secret']) {
        session_regenerate_id(true);
        $_SESSION['pending_uid'] = (int)$u['id'];
        $_SESSION['pending_time'] = time();
        return array('ok' => false, 'error' => '', 'need_2fa' => true);
    }
    finish_login($u);
    $_SESSION['pw_ok_at'] = time();
    $_SESSION['pk_proponi'] = 1;
    return array('ok' => true, 'error' => '', 'need_2fa' => false);
}

function verify_pending_2fa($code)
{
    $ip = client_ip();
    if (empty($_SESSION['pending_uid']) || time() - (int)$_SESSION['pending_time'] > 300) {
        unset($_SESSION['pending_uid'], $_SESSION['pending_time']);
        return array('ok' => false, 'error' => 'Tempo scaduto: inserisci di nuovo nome utente e password.', 'restart' => true);
    }
    $st = db()->prepare('SELECT * FROM users WHERE id = ?');
    $st->execute(array((int)$_SESSION['pending_uid']));
    $u = $st->fetch();
    if (!$u || (int)$u['active'] !== 1) {
        unset($_SESSION['pending_uid']);
        return array('ok' => false, 'error' => 'Accesso non consentito.', 'restart' => true);
    }
    $left = login_lock_remaining($ip, $u['username']);
    if ($left > 0) {
        unset($_SESSION['pending_uid']);
        return array('ok' => false, 'error' => 'Troppi tentativi errati. Riprova tra ' . minutes_text($left) . '.', 'restart' => true);
    }
    $secret = totp_secret_read($u['totp_secret']);
    $step = $secret !== '' ? totp_match_step($secret, $code, isset($u['totp_last_step']) ? (int)$u['totp_last_step'] : 0) : false;
    if ($step === false) {
        record_attempt($ip, $u['username'], false);
        app_log('2fa_fallita', 'Codice di verifica errato', 'warn', $u['username']);
        if (function_exists('fw_after_failed_login')) {
            fw_after_failed_login($ip, $u['username'], true);
        }
        return array('ok' => false, 'error' => 'Codice non valido. Controlla l\'app di autenticazione.', 'restart' => false);
    }
    unset($_SESSION['pending_uid'], $_SESSION['pending_time']);
    if (array_key_exists('totp_last_step', $u)) {
        // il codice appena usato non vale piu'; un segreto ancora in chiaro viene cifrato
        db()->prepare('UPDATE users SET totp_last_step = ?' . (strpos((string)$u['totp_secret'], ':') === false ? ', totp_secret = ?' : '') . ' WHERE id = ?')
            ->execute(strpos((string)$u['totp_secret'], ':') === false ? array($step, totp_secret_store($secret), (int)$u['id']) : array($step, (int)$u['id']));
    }
    finish_login($u, true);
    $_SESSION['pw_ok_at'] = time();
    $_SESSION['pk_proponi'] = 1;
    return array('ok' => true, 'error' => '', 'restart' => false);
}

function finish_login($u, $with2fa = false, $how = '')
{
    session_regenerate_id(true);
    $keep_flash = isset($_SESSION['flash']) ? $_SESSION['flash'] : null;
    $_SESSION = array();
    if ($keep_flash) {
        $_SESSION['flash'] = $keep_flash;
    }
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['role'] = $u['role'];
    $_SESSION['username'] = $u['username'];
    $_SESSION['last_seen'] = time();
    $_SESSION['login_at'] = time();
    $_SESSION['sid_at'] = time();
    $_SESSION['sv'] = isset($u['session_version']) ? (int)$u['session_version'] : 0;
    db()->prepare('UPDATE users SET last_login_at = ?, last_login_ip = ? WHERE id = ?')->execute(array(now(), client_ip(), $u['id']));
    record_attempt(client_ip(), $u['username'], true);
    app_log('login', 'Accesso eseguito' . ($with2fa ? ' con verifica in due passaggi' : '') . ($how !== '' ? ' ' . $how : ''), 'info', $u['username']);
    if (function_exists('lib_do')) {
        $pub = $u;
        unset($pub['password_hash'], $pub['totp_secret']);
        lib_do('accesso', $pub);
    }
}

function password_problem($pw, $username = '')
{
    $min = setting_int('sec_min_password', 6, 64);
    if (str_len($pw) < $min) {
        return 'La password deve avere almeno ' . $min . ' caratteri.';
    }
    if ($username !== '' && strcasecmp($pw, $username) === 0) {
        return 'La password non può essere uguale al nome utente.';
    }
    if (strlen($pw) > 256) {
        return 'La password è troppo lunga (al massimo 256 caratteri).';
    }
    $low = strtolower($pw);
    $common = array('password', 'password1', 'password123', 'passw0rd', '12345678', '123456789', '1234567890', '0123456789', '987654321',
        '11111111', '00000000', '12341234', '87654321', 'admin123', 'admin1234', 'administrator', 'amministratore', 'qwertyuiop', 'qwerty123',
        'qwertyui', 'asdfghjkl', 'zxcvbnm123', '1q2w3e4r', '1q2w3e4r5t', 'q1w2e3r4', 'iloveyou', 'ti amo', 'tiamo123', 'libreria', 'libreria123',
        'biblioteca', 'libri123', 'welcome1', 'benvenuto', 'letmein', 'sunshine', 'football', 'juventus', 'juventus1897', 'inter1908',
        'milan1899', 'napoli1926', 'roma1927', 'forzaitalia', 'forzajuve', 'calcio123', 'ciaociao', 'ciao1234', 'cambiami', 'segreto',
        'segreta', 'principessa', 'dragon123', 'master123', 'changeme', 'trustno1', 'abc12345', 'abcd1234', 'aaaaaaaa', 'italia123');
    if (in_array($low, $common, true) || ($username !== '' && stripos($pw, $username) !== false && str_len($pw) - str_len($username) < 4)) {
        return 'Questa password è troppo comune o troppo simile al nome utente: scegline un\'altra.';
    }
    if (preg_match('/^(.)\1+$/u', $pw) || strpos('01234567890123456789', $pw) !== false || strpos('abcdefghijklmnopqrstuvwxyz', $low) !== false) {
        return 'La password è una sequenza troppo semplice: scegline un\'altra.';
    }
    return '';
}
