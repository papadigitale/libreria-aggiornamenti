<?php
/*
 * Verifica in due passaggi (TOTP, RFC 6238) compatibile con Google Authenticator,
 * Microsoft Authenticator, Aegis, 2FAS, ecc. Nessuna libreria esterna.
 */

function totp_base32_encode($bin)
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    for ($i = 0, $n = strlen($bin); $i < $n; $i++) {
        $bits .= str_pad(decbin(ord($bin[$i])), 8, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 5) as $chunk) {
        $out .= $alphabet[bindec(str_pad($chunk, 5, '0', STR_PAD_RIGHT))];
    }
    return $out;
}

function totp_base32_decode($b32)
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $b32));
    $bits = '';
    for ($i = 0, $n = strlen($b32); $i < $n; $i++) {
        $bits .= str_pad(decbin(strpos($alphabet, $b32[$i])), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) {
            $out .= chr(bindec($byte));
        }
    }
    return $out;
}

function totp_new_secret()
{
    return totp_base32_encode(random_bytes(20));
}

function totp_code($secret, $counter)
{
    $key = totp_base32_decode($secret);
    $bin = pack('N*', 0) . pack('N*', $counter);
    $hash = hash_hmac('sha1', $bin, $key, true);
    $offset = ord($hash[19]) & 0x0F;
    $value = ((ord($hash[$offset]) & 0x7F) << 24) | ((ord($hash[$offset + 1]) & 0xFF) << 16)
           | ((ord($hash[$offset + 2]) & 0xFF) << 8) | (ord($hash[$offset + 3]) & 0xFF);
    return str_pad((string)($value % 1000000), 6, '0', STR_PAD_LEFT);
}

// Accetta il codice del periodo attuale e di quello prima/dopo (tolleranza orologio di ±30 s)
function totp_verify($secret, $code)
{
    return totp_match_step($secret, $code, 0) !== false;
}

/*
 * Come totp_verify, ma restituisce il "periodo" del codice accettato (o false).
 * Un codice gia' usato (periodo <= $last_step) non vale piu': chi lo intercetta non puo' riusarlo.
 */
function totp_match_step($secret, $code, $last_step)
{
    $code = preg_replace('/\D/', '', (string)$code);
    if (strlen($code) !== 6 || $secret === '') {
        return false;
    }
    $t = (int)floor(time() / 30);
    $found = false;
    for ($i = -1; $i <= 1; $i++) {
        if (hash_equals(totp_code($secret, $t + $i), $code) && $t + $i > (int)$last_step) {
            $found = $t + $i;
        }
    }
    return $found;
}

// Il segreto nel database e' cifrato con la chiave del server (data/secret.key); quelli vecchi in chiaro si leggono ancora
function totp_secret_read($stored)
{
    $stored = (string)$stored;
    if ($stored === '') {
        return '';
    }
    if (preg_match('/^(v1|v2|p):/', $stored)) {
        require_once dirname(__FILE__) . '/crypto.php';
        return sec_decrypt($stored, 'totp');
    }
    return $stored;
}

function totp_secret_store($plain)
{
    require_once dirname(__FILE__) . '/crypto.php';
    try {
        return sec_encrypt($plain, 'totp');
    } catch (Exception $e) {
        return $plain; // senza OpenSSL resta in chiaro, come prima
    }
}

function totp_uri($secret, $username, $issuer)
{
    return 'otpauth://totp/' . rawurlencode($issuer . ':' . $username) . '?secret=' . $secret
         . '&issuer=' . rawurlencode($issuer) . '&digits=6&period=30';
}
