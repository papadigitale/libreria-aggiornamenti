<?php
/*
 * Pannello di gestione a schermo pieno (pensato per il computer):
 * barra laterale con gruppi apribili, barra in alto, contenuto a destra.
 * Le voci riservate all'Admin non compaiono al Gestore e sono comunque bloccate dal server.
 */
require_once dirname(__FILE__) . '/layout.php';
require_once dirname(__FILE__) . '/extras.php';
require_once dirname(__FILE__) . '/library_tools.php';

// Gruppi del menu: chiave => array(nome, icona)
function admin_groups()
{
    return array(
        'bacheca'   => array('Bacheca', 'chart'),
        'libri'     => array('Libri', 'books'),
        'prestiti'  => array('Prestiti', 'share'),
        'etichette' => array('Etichette', 'tag'),
        'campi'     => array('Campi personalizzati', 'list'),
        'sezioni'   => array('Sezioni', 'layout'),
        'media'     => array('Media', 'media'),
        'aspetto'   => array('Aspetto', 'brush'),
        'utenti'    => array('Utenti', 'user'),
        'sicurezza' => array('Sicurezza', 'lock'),
        'strumenti' => array('Strumenti', 'tool'),
        'plugin'    => array('Plugin', 'plug'),
        'sistema'   => array('Sistema', 'gear'),
    );
}

/*
 * Sezioni: chiave => array(gruppo, nome, solo_admin, file, nel_menu)
 * I file g_*.php sono i pannelli della versione precedente, a_*.php quelli nuovi.
 */
function admin_sections()
{
    return array(
        'bacheca'       => array('bacheca', 'Bacheca', false, 'a_bacheca.php', true),
        'libri'         => array('libri', 'Tutti i libri', false, 'a_libri.php', true),
        'libro'         => array('libri', 'Modifica libro', false, 'a_libro.php', false),
        'copertine'     => array('libri', 'Copertine e immagini', false, 'a_copertine.php', true),
        'doppioni'      => array('libri', 'Doppioni', false, 'a_doppioni.php', true),
        'cestino'       => array('libri', 'Cestino', false, 'a_cestino.php', true),
        'prestiti'      => array('prestiti', 'Prestiti', false, 'a_prestiti.php', true),
        'generi'        => array('etichette', 'Generi', false, 'g_generi.php', true),
        'etichetta'     => array('etichette', 'Etichetta', false, 'a_etichetta.php', false),
        'etichette'     => array('etichette', 'Gestisci le etichette', false, 'a_etichette.php', true),
        'campi'         => array('campi', 'Campi personalizzati', false, 'a_campi.php', true),
        'home'          => array('sezioni', 'Pagina iniziale', false, 'a_home.php', true),
        'pagine'        => array('sezioni', 'Pagine del sito', false, 'a_pagine.php', true),
        'pulsanti'      => array('sezioni', 'Pulsanti della libreria', true, 'a_pulsanti.php', true),
        'pagina'        => array('sezioni', 'Modifica pagina', false, 'a_pagina.php', false),
        'media'         => array('media', 'Libreria media', false, 'a_media.php', true),
        'aspetto'       => array('aspetto', 'Stile e colori', true, 'a_aspetto.php', true),
        'testi'         => array('aspetto', 'Testi', true, 'g_testi.php', true),
        'utenti'        => array('utenti', 'Utenti', true, 'g_utenti.php', true),
        'sicurezza'     => array('sicurezza', 'Sicurezza e accessi', true, 'g_sicurezza.php', true),
        'firewall'      => array('sicurezza', 'Firewall', true, 'a_firewall.php', true),
        'blocchi'       => array('sicurezza', 'IP bloccati e registro', true, 'a_blocchi.php', true),
        'dati'          => array('strumenti', 'Backup, ripristino e CSV', false, 'g_dati.php', true),
        'destinazioni'  => array('strumenti', 'Destinazioni dei backup', true, 'a_destinazioni.php', true),
        'ricerca'       => array('strumenti', 'Ricerca online', false, 'g_ricerca.php', true),
        'sistema'       => array('sistema', 'Stato del sistema', true, 'g_sistema.php', true),
        'log'           => array('sistema', 'Log', true, 'g_log.php', true),
        'aggiornamento' => array('sistema', 'Aggiornamento', true, 'a_aggiornamento.php', true),
        'controllo'     => array('sicurezza', 'Controllo di sicurezza', true, 'a_controllo.php', true),
        'plugin'        => array('plugin', 'Gestisci i plugin', true, 'a_plugin.php', true),
        // officina: compare nel menu solo dove c'e' la chiave privata dell'autore (o la pubblicazione e' gia' configurata)
        'pubblica'      => array('sistema', 'Officina: pubblica', true, 'a_pubblica.php', is_file(DATA_DIR . '/firma/chiave_privata.json') || setting('pub_owner', '') !== ''),
    ) + (function_exists('plugins_admin_sections') ? plugins_admin_sections() : array());
}

function admin_section_allowed($sez)
{
    $s = admin_sections();
    return isset($s[$sez]) && (!$s[$sez][2] || is_admin());
}

function admin_url($sez, $params = array())
{
    return 'gestione.php?' . http_build_query(array_merge(array('sez' => $sez), $params));
}

function admin_icon($name, $size = 18)
{
    return icon($name, $size);
}

// Voci del menu, con le etichette personalizzate aggiunte dinamicamente nel gruppo "Etichette"
function admin_menu()
{
    $menu = array();
    foreach (admin_groups() as $g => $gd) {
        $menu[$g] = array('label' => $gd[0], 'icon' => $gd[1], 'items' => array());
    }
    foreach (admin_sections() as $k => $s) {
        if (!$s[4] || !admin_section_allowed($k)) {
            continue;
        }
        if ($k === 'etichette') {
            foreach (taxonomies_all() as $tid => $t) {
                $menu['etichette']['items'][] = array('sez' => 'etichetta', 'id' => $tid, 'label' => $t['name'], 'url' => admin_url('etichetta', array('id' => $tid)));
            }
        }
        $badge = 0;
        if ($k === 'prestiti') {
            $badge = loans_overdue_count();
        } elseif ($k === 'cestino') {
            $badge = trash_count();
        }
        $menu[$s[0]]['items'][] = array('sez' => $k, 'id' => 0, 'label' => $s[1], 'url' => admin_url($k), 'badge' => $badge);
        if ($k === 'libri') {
            $menu['libri']['items'][] = array('sez' => '_nuovo', 'id' => 0, 'label' => 'Aggiungi libro', 'url' => 'aggiungi.php');
        }
    }
    return array_filter($menu, function ($g) {
        return count($g['items']) > 0;
    });
}

function admin_start($title, $sez, $opts = array())
{
    global $MIGRATION_ERROR;
    $sections = admin_sections();
    $group = isset($sections[$sez]) ? $sections[$sez][0] : 'bacheca';
    $cur_id = isset($opts['id']) ? (int)$opts['id'] : 0;
    $v = (int)@filemtime(APP_ROOT . '/css/style.css') + (int)@filemtime(APP_ROOT . '/css/admin.css');
    echo '<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<meta name="robots" content="noindex"><link rel="icon" href="icon.php?s=192">'
       . '<title>' . h($title) . ' · Gestione · ' . h(setting('brand_title')) . '</title>'
       . '<link rel="stylesheet" href="css/style.css?v=' . $v . '"><link rel="stylesheet" href="css/admin.css?v=' . $v . '">' . theme_head()
       . (function_exists('lib_filter') ? (string)lib_filter('admin_testa', '') : '')
       . '</head><body class="adm">';
    echo '<div class="adm-shell" data-adm-shell>';
    // ---- barra laterale
    echo '<aside class="adm-side" aria-label="Menu della gestione">';
    echo '<a class="adm-brand" href="gestione.php">' . brand_logo_html() . '<span><b>' . h(setting('brand_title')) . '</b><small>Gestione</small></span></a>';
    echo '<nav class="adm-nav">';
    foreach (admin_menu() as $g => $m) {
        $is_cur = $g === $group;
        if (count($m['items']) === 1) {
            $it = $m['items'][0];
            echo '<div class="ag single' . ($is_cur ? ' cur' : '') . '"><a class="ag-h" href="' . h($it['url']) . '" title="' . h($m['label']) . '">'
               . admin_icon($m['icon'], 18) . '<span>' . h($m['label']) . '</span>'
               . (!empty($it['badge']) ? '<em class="nbadge" title="Prestiti scaduti">' . (int)$it['badge'] . '</em>' : '') . '</a></div>';
            continue;
        }
        echo '<div class="ag' . ($is_cur ? ' cur open' : '') . '" data-group="' . h($g) . '">'
           . '<button class="ag-h" type="button" aria-expanded="' . ($is_cur ? 'true' : 'false') . '" title="' . h($m['label']) . '">'
           . admin_icon($m['icon'], 18) . '<span>' . h($m['label']) . '</span>' . admin_icon('chev', 14) . '</button><div class="ag-items"><div class="ag-fly">' . h($m['label']) . '</div>';
        foreach ($m['items'] as $it) {
            $on = $it['sez'] === $sez && ($it['id'] === 0 || $it['id'] === $cur_id);
            if ($sez === 'libro' && $it['sez'] === 'libri') {
                $on = true;
            }
            if ($sez === 'pagina' && $it['sez'] === 'pagine') {
                $on = true;
            }
            echo '<a class="' . ($on ? 'on' : '') . ($it['sez'] === 'etichetta' ? ' sub' : '') . '" href="' . h($it['url']) . '">' . h($it['label'])
               . (!empty($it['badge']) ? ' <em class="nbadge soft">' . (int)$it['badge'] . '</em>' : '') . '</a>';
        }
        echo '</div></div>';
    }
    echo '</nav>';
    echo '<button class="adm-mini" type="button" data-adm-mini>' . admin_icon('back', 16) . '<span>Riduci il menu</span></button>';
    echo '</aside>';
    // ---- area principale
    echo '<div class="adm-main"><header class="adm-top">';
    echo '<button class="adm-burger" type="button" data-adm-burger aria-label="Menu">' . admin_icon('menu', 20) . '</button>';
    $g = admin_groups();
    $gname = isset($g[$group]) ? $g[$group][0] : '';
    echo '<div class="adm-crumb">' . ($gname !== $title ? '<span>' . h($gname) . '</span>' . admin_icon('chev', 12) : '') . '<b>' . h($title) . '</b></div>';
    echo '<form class="adm-search" method="get" action="gestione.php" role="search"><input type="hidden" name="sez" value="libri">'
       . icon('search', 16) . '<input type="search" name="q" placeholder="Cerca un libro…" aria-label="Cerca un libro" value="' . h($sez === 'libri' ? get('q') : '') . '"></form>';
    echo '<a class="adm-tbtn" href="aggiungi.php">' . icon('plus', 16) . '<span>Aggiungi libro</span></a>';
    echo '<a class="adm-tbtn ghost" href="libreria.php">' . icon('books', 15) . '<span>Vai al sito</span></a>';
    $u = current_user();
    echo '<details class="adm-user"><summary><span class="avatar sm">' . h(user_initials()) . '</span><span class="adm-uname">'
       . h($u ? ($u['display_name'] !== '' ? $u['display_name'] : $u['username']) : '') . '<small>' . (is_admin() ? 'Admin' : 'Gestore') . '</small></span></summary>'
       . '<div class="adm-umenu"><a href="account.php">' . icon('user', 16) . ' Il mio account</a>'
       . '<a href="logout.php?t=' . h(csrf_token()) . '">' . icon('logout', 16) . ' Esci</a></div></details>';
    echo '</header><main class="adm-content' . (!empty($opts['wide']) ? ' wide' : '') . '">';
    echo '<div class="adm-head"><div><h1 class="adm-h1">' . h($title) . '</h1>'
       . (!empty($opts['sub']) ? '<p class="adm-sub">' . h($opts['sub']) . '</p>' : '') . '</div>'
       . (!empty($opts['actions']) ? '<div class="adm-actions">' . $opts['actions'] . '</div>' : '') . '</div>';
    if ($MIGRATION_ERROR !== '' && is_admin()) {
        echo '<div class="alert error">' . h($MIGRATION_ERROR) . '</div>';
    }
    if (maintenance_on()) {
        echo '<div class="alert warn">Il sito è in <b>modalità manutenzione</b>: i visitatori vedono la pagina "Torniamo subito".</div>';
    }
    // nuova versione nel repository (solo Admin, solo avviso)
    if (is_admin() && $sez !== 'aggiornamento' && setting('repo_cache', '') !== '' && is_file(APP_ROOT . '/inc/repo.php')) {
        require_once APP_ROOT . '/inc/repo.php';
        $nv = repo_aggiornamento();
        if ($nv) {
            echo '<div class="alert warn repo-avviso">' . admin_icon('spin', 16) . ' <span>È disponibile la <b>versione ' . h($nv['versione']) . '</b> (installata: ' . h(APP_VERSION) . ').</span> '
               . '<a class="btn primary small" href="gestione.php?sez=aggiornamento#repository">Vedi le novità e aggiorna</a></div>';
        }
    }
    echo flash_show();
}

function admin_end($scripts = array())
{
    echo '<p class="adm-foot">Libreria di Casa · versione ' . h(APP_VERSION) . '</p></main></div></div>';
    echo '<script type="application/json" id="app-config">' . json_encode(array('csrf' => csrf_token()), JSON_HEX_TAG | JSON_HEX_AMP) . '</script>';
    foreach (array_merge(array('js/app.js', 'js/admin.js'), $scripts) as $s) {
        echo '<script src="' . h($s) . '?v=' . (int)@filemtime(APP_ROOT . '/' . $s) . '"></script>';
    }
    if (function_exists('lib_filter')) {
        echo (string)lib_filter('admin_fondo', '');
    }
    echo '</body></html>';
}
