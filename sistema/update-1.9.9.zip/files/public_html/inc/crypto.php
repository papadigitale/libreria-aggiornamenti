<?php
/*
 * Cifratura dei segreti salvati nel database (password delle destinazioni dei backup, token, codici della verifica in due passaggi).
 * Chiave: data/secret.key (32 byte casuali, creata al primo uso, non finisce nei backup).
 *   v2: AES-256-GCM (cifratura autenticata), chiave derivata con HKDF-SHA256     <- quella usata d'ora in poi
 *   v1: AES-256-CBC + HMAC-SHA256 (versioni fino alla 1.8): si legge ancora e si riscrive in v2 alla prima modifica
 * Ogni testo cifrato e' legato al suo uso ($context): un valore copiato da un campo all'altro non si decifra.
 */

function sec_key()
{
    static $k = null;
    if ($k !== null) {
        return $k;
    }
    $f = DATA_DIR . '/secret.key';
    if (!is_file($f)) {
        $old = umask(0077);
        $h = @fopen($f, 'x'); // "x": non sovrascrive mai una chiave gia' esistente
        if ($h) {
            fwrite($h, bin2hex(random_bytes(32)));
            fclose($h);
        }
        umask($old);
        @chmod($f, 0600);
    }
    $raw = @file_get_contents($f);
    if (!$raw || strlen(trim($raw)) < 64) {
        throw new Exception('Impossibile leggere o creare la chiave data/secret.key: la cartella data non è scrivibile.');
    }
    return $k = hex2bin(substr(trim($raw), 0, 64));
}

function sec_gcm_ok()
{
    return function_exists('openssl_encrypt') && in_array('aes-256-gcm', array_map('strtolower', openssl_get_cipher_methods()), true);
}

function sec_encrypt($plain, $context = 'generico')
{
    $plain = (string)$plain;
    if ($plain === '') {
        return '';
    }
    if (!function_exists('openssl_encrypt')) {
        throw new Exception('Per salvare i dati riservati serve l\'estensione OpenSSL di PHP.');
    }
    $k = sec_key();
    if (sec_gcm_ok()) {
        $key = hash_hkdf('sha256', $k, 32, 'libreria-di-casa/v2/' . $context);
        $iv = random_bytes(12);
        $tag = '';
        $ct = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'v2|' . $context, 16);
        if ($ct !== false) {
            return 'v2:' . base64_encode($iv . $tag . $ct);
        }
    }
    // OpenSSL senza GCM (molto raro): cifratura v1, comunque autenticata
    $iv = random_bytes(16);
    $ct = openssl_encrypt($plain, 'aes-256-cbc', hash('sha256', 'enc' . $k, true), OPENSSL_RAW_DATA, $iv);
    $mac = hash_hmac('sha256', $iv . $ct, hash('sha256', 'mac' . $k, true), true);
    return 'v1:' . base64_encode($iv . $mac . $ct);
}

function sec_decrypt($stored, $context = 'generico')
{
    $stored = (string)$stored;
    if ($stored === '') {
        return '';
    }
    if (substr($stored, 0, 2) === 'p:') {
        return (string)base64_decode(substr($stored, 2)); // vecchio formato senza OpenSSL
    }
    if (!function_exists('openssl_decrypt')) {
        return '';
    }
    $k = sec_key();
    $bin = (string)base64_decode(substr($stored, 3), true);
    if (substr($stored, 0, 3) === 'v2:') {
        if (strlen($bin) < 29) {
            return '';
        }
        $key = hash_hkdf('sha256', $k, 32, 'libreria-di-casa/v2/' . $context);
        $out = openssl_decrypt(substr($bin, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($bin, 0, 12), substr($bin, 12, 16), 'v2|' . $context);
        return $out === false ? '' : $out;
    }
    if (substr($stored, 0, 3) === 'v1:') {
        $iv = substr($bin, 0, 16);
        $mac = substr($bin, 16, 32);
        $ct = substr($bin, 48);
        if (!hash_equals(hash_hmac('sha256', $iv . $ct, hash('sha256', 'mac' . $k, true), true), $mac)) {
            return '';
        }
        $out = openssl_decrypt($ct, 'aes-256-cbc', hash('sha256', 'enc' . $k, true), OPENSSL_RAW_DATA, $iv);
        return $out === false ? '' : $out;
    }
    return '';
}

function sec_is_encrypted($v)
{
    return is_string($v) && preg_match('/^(v1|v2|p):/', $v) === 1;
}
