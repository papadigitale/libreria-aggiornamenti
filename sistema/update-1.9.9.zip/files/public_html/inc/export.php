<?php
/*
 * Esportazione dell'elenco dei libri in Excel (.xlsx) o PDF, con la copertina piccola a sinistra,
 * titolo, autore, editore e anno. Scritta senza librerie esterne (file .xlsx costruito a mano con ZipArchive,
 * PDF costruito a mano con i font standard Helvetica). Le miniature si preparano con GD, se c'e'.
 */
require_once dirname(__FILE__) . '/books.php';

// $ids: null = tutta la libreria. $order: 'autore' | 'titolo'
function export_rows($ids, $order)
{
    $sql = 'SELECT id, title, subtitle, authors, publisher, pub_year, cover_file FROM books';
    if ($ids !== null) {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if (!$ids) {
            return array();
        }
        $sql .= ' WHERE id IN (' . implode(',', $ids) . ')';
    }
    $rows = db()->query($sql)->fetchAll();
    foreach ($rows as $i => $r) {
        $a = author_sort_info($r['authors']);
        $rows[$i]['_ka'] = $a[0];
        $rows[$i]['_kt'] = str_fold(preg_replace('/^(il|lo|la|i|gli|le|l\'|un|uno|una|un\')\s*/iu', '', (string)$r['title']));
    }
    usort($rows, function ($x, $y) use ($order) {
        if ($order === 'titolo') {
            $c = strcmp($x['_kt'], $y['_kt']);
            return $c !== 0 ? $c : strcmp($x['_ka'], $y['_ka']);
        }
        $c = strcmp($x['_ka'], $y['_ka']);
        return $c !== 0 ? $c : strcmp($x['_kt'], $y['_kt']);
    });
    return $rows;
}

/*
 * Miniatura JPEG della copertina: array(dati, larghezza, altezza, canali) oppure null.
 * Con GD si ritaglia a 2:3 e si rimpicciolisce; senza GD si usa il file originale solo se e' gia' un JPEG.
 */
function export_thumb($file, $w = 90, $h = 135)
{
    if (!$file || !preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $file) || !is_file(COVERS_DIR . '/' . $file)) {
        return null;
    }
    $bin = file_get_contents(COVERS_DIR . '/' . $file);
    if (function_exists('imagecreatefromstring')) {
        $src = @imagecreatefromstring($bin);
        if ($src) {
            $sw = imagesx($src);
            $sh = imagesy($src);
            // ritaglio centrale alle proporzioni della miniatura
            $ratio = $w / $h;
            if ($sw / $sh > $ratio) {
                $cw = (int)round($sh * $ratio);
                $ch = $sh;
                $cx = (int)(($sw - $cw) / 2);
                $cy = 0;
            } else {
                $cw = $sw;
                $ch = (int)round($sw / $ratio);
                $cx = 0;
                $cy = (int)(($sh - $ch) / 2);
            }
            $dst = imagecreatetruecolor($w, $h);
            imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
            imagecopyresampled($dst, $src, 0, 0, $cx, $cy, $w, $h, $cw, $ch);
            ob_start();
            imagejpeg($dst, null, 82);
            $out = ob_get_clean();
            img_free($src);
            img_free($dst);
            return array($out, $w, $h, 3);
        }
    }
    $info = @getimagesizefromstring($bin);
    if ($info && $info[2] === IMAGETYPE_JPEG) {
        return array($bin, $info[0], $info[1], isset($info['channels']) ? (int)$info['channels'] : 3);
    }
    return null;
}

function export_filename($ext)
{
    $base = preg_replace('/[^A-Za-z0-9]+/', '-', str_fold(setting('brand_title', 'libreria')));
    $base = trim($base, '-');
    return ($base !== '' ? $base : 'libreria') . '_elenco_' . date('Y-m-d') . '.' . $ext;
}

function export_send($ids, $format, $order)
{
    @set_time_limit(300);
    $rows = export_rows($ids, $order === 'titolo' ? 'titolo' : 'autore');
    if ($format === 'pdf') {
        $data = export_pdf($rows, $ids === null);
        $type = 'application/pdf';
        $name = export_filename('pdf');
    } else {
        $data = export_xlsx($rows);
        $type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        $name = export_filename('xlsx');
    }
    app_log('esportazione', 'Elenco di ' . count($rows) . ' libri esportato in ' . strtoupper($format === 'pdf' ? 'pdf' : 'xlsx'));
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: ' . $type);
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Content-Length: ' . strlen($data));
    header('Cache-Control: no-store');
    echo $data;
    exit;
}

/* ================= Excel (.xlsx) ================= */

function x_esc($s)
{
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string)$s);
    return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function export_xlsx($rows)
{
    if (!class_exists('ZipArchive')) {
        throw new Exception('Per l\'esportazione in Excel serve l\'estensione zip di PHP.');
    }
    $tmp = tempnam(sys_get_temp_dir(), 'xlsx');
    $z = new ZipArchive();
    if ($z->open($tmp, ZipArchive::OVERWRITE) !== true) {
        throw new Exception('Impossibile creare il file Excel.');
    }
    $n = count($rows);
    $head = array('Copertina', 'Titolo', 'Autore', 'Editore', 'Anno');
    $cols = array('A', 'B', 'C', 'D', 'E');
    $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        . '<sheetFormatPr defaultRowHeight="15"/>'
        . '<cols><col min="1" max="1" width="8.5" customWidth="1"/><col min="2" max="2" width="48" customWidth="1"/>'
        . '<col min="3" max="3" width="30" customWidth="1"/><col min="4" max="4" width="24" customWidth="1"/><col min="5" max="5" width="8" customWidth="1"/></cols>'
        . '<sheetData><row r="1" ht="22" customHeight="1">';
    foreach ($head as $i => $t) {
        $sheet .= '<c r="' . $cols[$i] . '1" t="inlineStr" s="1"><is><t>' . x_esc($t) . '</t></is></c>';
    }
    $sheet .= '</row>';
    $drawing = '';
    $drels = '';
    $img = 0;
    $types_img = false;
    foreach ($rows as $k => $b) {
        $r = $k + 2;
        $title = $b['title'] . ($b['subtitle'] ? "\n" . $b['subtitle'] : '');
        $sheet .= '<row r="' . $r . '" ht="50" customHeight="1">'
            . '<c r="A' . $r . '" s="2"/>'
            . '<c r="B' . $r . '" t="inlineStr" s="3"><is><t xml:space="preserve">' . x_esc($title) . '</t></is></c>'
            . '<c r="C' . $r . '" t="inlineStr" s="2"><is><t xml:space="preserve">' . x_esc($b['authors']) . '</t></is></c>'
            . '<c r="D' . $r . '" t="inlineStr" s="2"><is><t xml:space="preserve">' . x_esc($b['publisher']) . '</t></is></c>'
            . ($b['pub_year'] ? '<c r="E' . $r . '" s="4"><v>' . (int)$b['pub_year'] . '</v></c>' : '<c r="E' . $r . '" s="4"/>')
            . '</row>';
        $t = export_thumb($b['cover_file'], 60, 90);
        if ($t) {
            $img++;
            $types_img = true;
            $z->addFromString('xl/media/image' . $img . '.jpeg', $t[0]);
            $cx = 40 * 9525;
            $cy = 60 * 9525;
            $drawing .= '<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>76200</xdr:colOff><xdr:row>' . ($r - 1) . '</xdr:row><xdr:rowOff>28575</xdr:rowOff></xdr:from>'
                . '<xdr:ext cx="' . $cx . '" cy="' . $cy . '"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="' . ($img + 1) . '" name="Copertina ' . $img . '"/>'
                . '<xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr>'
                . '<xdr:blipFill><a:blip r:embed="rId' . $img . '"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>'
                . '<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' . $cx . '" cy="' . $cy . '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr>'
                . '</xdr:pic><xdr:clientData/></xdr:oneCellAnchor>';
            $drels .= '<Relationship Id="rId' . $img . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image' . $img . '.jpeg"/>';
        }
    }
    $sheet .= '</sheetData>';
    if ($n > 0) {
        $sheet .= '<autoFilter ref="B1:E' . ($n + 1) . '"/>';
    }
    $sheet .= '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>'
        . '<pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>'
        . '<headerFooter><oddFooter>&amp;C' . x_esc(setting('brand_title', 'Libreria di Casa')) . ' · pagina &amp;P di &amp;N</oddFooter></headerFooter>'
        . ($img ? '<drawing r:id="rId1"/>' : '') . '</worksheet>';

    $z->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . ($types_img ? '<Default Extension="jpeg" ContentType="image/jpeg"/>' : '')
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        . ($img ? '<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>' : '')
        . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
        . '</Types>');
    $z->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        . '</Relationships>');
    $z->addFromString('docProps/core.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" '
        . 'xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        . '<dc:title>' . x_esc(setting('brand_title', 'Libreria di Casa') . ' – elenco dei libri') . '</dc:title><dc:creator>Libreria di Casa</dc:creator>'
        . '<dcterms:created xsi:type="dcterms:W3CDTF">' . gmdate('Y-m-d\TH:i:s\Z') . '</dcterms:created></cp:coreProperties>');
    $z->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets><sheet name="Libreria" sheetId="1" r:id="rId1"/></sheets>'
        . ($n > 0 ? '<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">Libreria!$B$1:$E$' . ($n + 1) . '</definedName>'
            . '<definedName name="_xlnm.Print_Titles" localSheetId="0">Libreria!$1:$1</definedName></definedNames>' : '')
        . '</workbook>');
    $z->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        . '</Relationships>');
    $primary = strtoupper(ltrim(safe_hex(setting('color_primary', '#7a1f2b')), '#'));
    $z->addFromString('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
        . '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
        . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FF' . $primary . '"/><bgColor indexed="64"/></patternFill></fill></fills>'
        . '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
        . '<border><left/><right/><top/><bottom style="thin"><color rgb="FFDDDDDD"/></bottom><diagonal/></border></borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf>'
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
        . '<xf numFmtId="0" fontId="2" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
        . '<xf numFmtId="1" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
        . '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
    $z->addFromString('xl/worksheets/sheet1.xml', $sheet);
    if ($img) {
        $z->addFromString('xl/worksheets/_rels/sheet1.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>');
        $z->addFromString('xl/drawings/drawing1.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' . $drawing . '</xdr:wsDr>');
        $z->addFromString('xl/drawings/_rels/drawing1.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $drels . '</Relationships>');
    }
    $z->close();
    $data = file_get_contents($tmp);
    @unlink($tmp);
    return $data;
}

function safe_hex($c)
{
    return preg_match('/^#[0-9a-fA-F]{6}$/', (string)$c) ? $c : '#7a1f2b';
}

/* ================= PDF ================= */

function pdf_txt($s)
{
    $s = (string)$s;
    $t = function_exists('iconv') ? @iconv('UTF-8', 'Windows-1252//TRANSLIT', $s) : false;
    if ($t === false) {
        $t = function_exists('mb_convert_encoding') ? mb_convert_encoding($s, 'Windows-1252', 'UTF-8') : (string)@iconv('UTF-8', 'Windows-1252//TRANSLIT', $s);
    }
    return $t;
}

function pdf_width($s1252, $font, $size)
{
    static $w = null;
    if ($w === null) {
        require_once dirname(__FILE__) . '/pdf_fonts.php';
        $w = pdf_font_widths();
    }
    $t = 0;
    $fw = $w[$font];
    for ($i = 0, $n = strlen($s1252); $i < $n; $i++) {
        $t += $fw[ord($s1252[$i])];
    }
    return $t * $size / 1000;
}

// Taglia il testo (gia' in Windows-1252) alla larghezza indicata, con i puntini
function pdf_fit($s, $font, $size, $max)
{
    if (pdf_width($s, $font, $size) <= $max) {
        return $s;
    }
    $ell = "\x85";
    while ($s !== '' && pdf_width($s . $ell, $font, $size) > $max) {
        $s = substr($s, 0, -1);
    }
    return rtrim($s) . $ell;
}

function pdf_str($s)
{
    return '(' . str_replace(array('\\', '(', ')', "\r", "\n"), array('\\\\', '\\(', '\\)', ' ', ' '), $s) . ')';
}

function pdf_rgb($hex)
{
    $hex = ltrim(safe_hex($hex), '#');
    return sprintf('%.3F %.3F %.3F', hexdec(substr($hex, 0, 2)) / 255, hexdec(substr($hex, 2, 2)) / 255, hexdec(substr($hex, 4, 2)) / 255);
}

function export_pdf($rows, $all)
{
    $W = 595.28;
    $H = 841.89;
    $M = 36;
    $rowH = 52;
    $thumbW = 30;
    $thumbH = 45;
    $xText = $M + $thumbW + 12;
    $xPub = 372;
    $xYearR = $W - $M;
    $wText = $xPub - $xText - 12;
    $wPub = $xYearR - 40 - $xPub;
    $primary = pdf_rgb(setting('color_primary', '#7a1f2b'));
    $brand = pdf_txt(setting('brand_title', 'Libreria di Casa'));
    $n = count($rows);
    $sub = pdf_txt(($all ? 'Elenco completo' : 'Elenco') . ' · ' . $n . ($n === 1 ? ' libro' : ' libri') . ' · aggiornato al ' . date('d/m/Y'));

    // impaginazione: prima pagina con l'intestazione grande
    $firstTop = $H - $M - 58;
    $otherTop = $H - $M - 18;
    $bottom = $M + 24;
    $pages = array();
    $i = 0;
    $p = 0;
    do {
        $top = $p === 0 ? $firstTop : $otherTop;
        $cap = max(1, (int)floor(($top - 18 - $bottom) / $rowH));
        $pages[] = array_slice($rows, $i, $cap);
        $i += $cap;
        $p++;
    } while ($i < $n);

    $objs = array();       // numero => contenuto (senza "obj")
    $objs[1] = null;       // catalogo
    $objs[2] = null;       // pagine
    $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
    $next = 5;
    $kids = array();
    $total = count($pages);
    foreach ($pages as $pi => $list) {
        $c = '';
        $xobj = array();
        $top = $pi === 0 ? $firstTop : $otherTop;
        if ($pi === 0) {
            $c .= 'BT /F2 18 Tf ' . $primary . ' rg ' . sprintf('%.2F %.2F', $M, $H - $M - 18) . ' Td ' . pdf_str(pdf_fit($brand, 'Helvetica-Bold', 18, $W - 2 * $M)) . " Tj ET\n";
            $c .= 'BT /F1 9.5 Tf 0.45 0.4 0.36 rg ' . sprintf('%.2F %.2F', $M, $H - $M - 36) . ' Td ' . pdf_str($sub) . " Tj ET\n";
        }
        // intestazione delle colonne
        $hy = $top;
        $c .= 'BT /F2 7.5 Tf 0.45 0.4 0.36 rg ' . sprintf('%.2F %.2F', $xText, $hy) . ' Td ' . pdf_str('TITOLO E AUTORE') . " Tj ET\n";
        $c .= 'BT /F2 7.5 Tf ' . sprintf('%.2F %.2F', $xPub, $hy) . ' Td ' . pdf_str('EDITORE') . " Tj ET\n";
        $c .= 'BT /F2 7.5 Tf ' . sprintf('%.2F %.2F', $xYearR - pdf_width('ANNO', 'Helvetica-Bold', 7.5), $hy) . ' Td ' . pdf_str('ANNO') . " Tj ET\n";
        $c .= $primary . ' RG 0.8 w ' . sprintf('%.2F %.2F m %.2F %.2F l S', $M, $hy - 6, $W - $M, $hy - 6) . "\n";
        $y = $hy - 6;
        foreach ($list as $b) {
            $rowTop = $y;
            $ty = $rowTop - ($rowH - $thumbH) / 2 - $thumbH; // base della miniatura
            $t = export_thumb($b['cover_file'], 90, 135);
            if ($t) {
                $id = $next++;
                $cs = $t[3] === 1 ? '/DeviceGray' : ($t[3] === 4 ? '/DeviceCMYK /Decode [1 0 1 0 1 0 1 0]' : '/DeviceRGB');
                $objs[$id] = array('<< /Type /XObject /Subtype /Image /Width ' . $t[1] . ' /Height ' . $t[2] . ' /ColorSpace ' . $cs
                    . ' /BitsPerComponent 8 /Filter /DCTDecode /Length ' . strlen($t[0]) . ' >>', $t[0]);
                $name = 'Im' . $id;
                $xobj[] = '/' . $name . ' ' . $id . ' 0 R';
                $c .= sprintf("q %.2F 0 0 %.2F %.2F %.2F cm /%s Do Q\n", $thumbW, $thumbH, $M, $ty, $name);
            } else {
                $pal = cover_palette($b['title']);
                $c .= pdf_rgb($pal[0]) . ' rg ' . sprintf('%.2F %.2F %.2F %.2F re f', $M, $ty, $thumbW, $thumbH) . "\n";
            }
            $c .= '0.85 0.82 0.78 RG 0.4 w ' . sprintf('%.2F %.2F %.2F %.2F re S', $M, $ty, $thumbW, $thumbH) . "\n";
            $title = pdf_fit(pdf_txt($b['title']), 'Helvetica-Bold', 10.5, $wText);
            $auth = pdf_fit(pdf_txt($b['authors']), 'Helvetica', 9, $wText);
            $mid = $rowTop - $rowH / 2;
            $c .= 'BT /F2 10.5 Tf 0.13 0.1 0.08 rg ' . sprintf('%.2F %.2F', $xText, $mid + 3) . ' Td ' . pdf_str($title) . " Tj ET\n";
            $c .= 'BT /F1 9 Tf 0.42 0.37 0.33 rg ' . sprintf('%.2F %.2F', $xText, $mid - 9) . ' Td ' . pdf_str($auth) . " Tj ET\n";
            if ($b['subtitle'] !== null && $b['subtitle'] !== '') {
                $st = pdf_fit(pdf_txt($b['subtitle']), 'Helvetica', 7.5, $wText);
                $c .= 'BT /F1 7.5 Tf 0.55 0.5 0.46 rg ' . sprintf('%.2F %.2F', $xText, $mid - 19) . ' Td ' . pdf_str($st) . " Tj ET\n";
            }
            $pub = pdf_fit(pdf_txt($b['publisher']), 'Helvetica', 9, $wPub);
            $c .= 'BT /F1 9 Tf 0.25 0.2 0.17 rg ' . sprintf('%.2F %.2F', $xPub, $mid - 3) . ' Td ' . pdf_str($pub) . " Tj ET\n";
            if ($b['pub_year']) {
                $yr = (string)(int)$b['pub_year'];
                $c .= 'BT /F1 9 Tf ' . sprintf('%.2F %.2F', $xYearR - pdf_width($yr, 'Helvetica', 9), $mid - 3) . ' Td ' . pdf_str($yr) . " Tj ET\n";
            }
            $y -= $rowH;
            $c .= '0.88 0.85 0.8 RG 0.4 w ' . sprintf('%.2F %.2F m %.2F %.2F l S', $M, $y, $W - $M, $y) . "\n";
        }
        if (!$list) {
            $c .= 'BT /F1 10 Tf 0.4 0.4 0.4 rg ' . sprintf('%.2F %.2F', $M, $y - 24) . ' Td ' . pdf_str('Nessun libro da esportare.') . " Tj ET\n";
        }
        $foot = pdf_txt(setting('brand_title', 'Libreria di Casa') . ' · pagina ' . ($pi + 1) . ' di ' . $total);
        $c .= 'BT /F1 8 Tf 0.55 0.5 0.46 rg ' . sprintf('%.2F %.2F', ($W - pdf_width($foot, 'Helvetica', 8)) / 2, $M - 6) . ' Td ' . pdf_str($foot) . " Tj ET\n";
        $stream = function_exists('gzcompress') ? gzcompress($c, 6) : $c;
        $cid = $next++;
        $objs[$cid] = array('<< /Length ' . strlen($stream) . (function_exists('gzcompress') ? ' /Filter /FlateDecode' : '') . ' >>', $stream);
        $pid = $next++;
        $objs[$pid] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . sprintf('%.2F %.2F', $W, $H) . '] /Contents ' . $cid . ' 0 R '
            . '/Resources << /Font << /F1 3 0 R /F2 4 0 R >>' . ($xobj ? ' /XObject << ' . implode(' ', $xobj) . ' >>' : '') . ' >> >>';
        $kids[] = $pid . ' 0 R';
    }
    $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
    $objs[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';
    $info = $next++;
    $objs[$info] = '<< /Title ' . pdf_str(pdf_txt(setting('brand_title', 'Libreria di Casa') . ' - elenco dei libri')) . ' /Producer (Libreria di Casa) /CreationDate (D:' . date('YmdHis') . ') >>';

    $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
    $offs = array();
    ksort($objs);
    foreach ($objs as $num => $o) {
        $offs[$num] = strlen($out);
        if (is_array($o)) {
            $out .= $num . " 0 obj\n" . $o[0] . "\nstream\n" . $o[1] . "\nendstream\nendobj\n";
        } else {
            $out .= $num . " 0 obj\n" . $o . "\nendobj\n";
        }
    }
    $xref = strlen($out);
    $max = max(array_keys($objs));
    $out .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
    for ($k = 1; $k <= $max; $k++) {
        $out .= isset($offs[$k]) ? sprintf("%010d 00000 n \n", $offs[$k]) : "0000000000 65535 f \n";
    }
    $out .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R /Info " . $info . " 0 R >>\nstartxref\n" . $xref . "\n%%EOF\n";
    return $out;
}
