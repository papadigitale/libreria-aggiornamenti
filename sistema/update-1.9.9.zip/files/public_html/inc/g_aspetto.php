<?php
// "oppure scegli da Media": elenco delle immagini caricate in Gestione → Media
if (!function_exists('aspetto_media_select')) {
    function aspetto_media_select($name)
    {
        static $imgs = null;
        if ($imgs === null) {
            $imgs = array();
            if ((int)setting('db_version', '1') >= 10) {
                require_once APP_ROOT . '/inc/media.php';
                $imgs = media_list('all', '', 'image', 300);
            }
        }
        if (!$imgs) {
            return '';
        }
        $o = '<select class="input" name="' . h($name) . '" aria-label="Oppure scegli da Media"><option value="">… oppure scegli un\'immagine da Media</option>';
        foreach ($imgs as $m) {
            $o .= '<option value="' . (int)$m['id'] . '">' . h(($m['title'] !== '' ? $m['title'] : $m['original_name']) . ($m['width'] ? ' (' . $m['width'] . '×' . $m['height'] . ')' : '')) . '</option>';
        }
        return $o . '</select>';
    }
}
?>
<?php
$presets = theme_presets();
$current = setting('theme_preset');
?>
<div class="card">
  <div class="ct"><?= icon('brush', 18) ?> Stili pronti</div>
  <p class="sub">Parti da uno stile e poi personalizza ogni dettaglio qui sotto.</p>
  <div class="presets">
    <?php foreach ($presets as $k => $p): $c = $p[1]; ?>
    <form method="post" class="preset <?= $current === $k ? 'sel' : '' ?>">
      <?= csrf_field() ?><input type="hidden" name="action" value="preset"><input type="hidden" name="preset" value="<?= h($k) ?>">
      <button type="submit" style="background:<?= h($c['color_bg']) ?>;color:<?= h($c['color_ink']) ?>;border-radius:<?= (int)$c['radius'] ?>px">
        <span class="pv-dots"><i style="background:<?= h($c['color_primary']) ?>"></i><i style="background:<?= h($c['color_accent']) ?>"></i><i style="background:<?= h($c['color_panel']) ?>"></i></span>
        <span class="pv-name" style="font-family:<?= h(font_options()[$c['font_head']][1]) ?>"><?= h($p[0]) ?></span>
        <?= $current === $k ? '<span class="pv-on">In uso</span>' : '' ?>
      </button>
    </form>
    <?php endforeach; ?>
  </div>
</div>

<?= settings_form_open('aspetto', true) ?>
  <input type="hidden" name="theme_preset_custom" value="1">
  <div class="ct">Colori</div>
  <p class="sub">Le modifiche si vedono subito in anteprima su questa pagina; diventano definitive premendo "Salva".</p>
  <div class="color-grid">
    <?php foreach (array('color_primary', 'color_on_primary', 'color_accent', 'color_bg', 'color_panel', 'color_soft', 'color_ink', 'color_muted', 'color_line', 'color_ok', 'color_danger') as $k): ?>
      <div><?= render_setting($k) ?></div>
    <?php endforeach; ?>
  </div>

  <div class="ct sep">Sfondo del sito</div>
  <?= render_setting('bg_type') ?>
  <label class="lab" for="bg-file">Carica un'immagine di sfondo</label>
  <input class="input" type="file" id="bg-file" name="bg_file" accept="image/*">
  <?= aspetto_media_select('bg_media') ?>
  <?php if (setting('bg_image') !== ''): ?>
    <div class="thumbrow"><img src="<?= h(asset_url(setting('bg_image'))) ?>" alt="Sfondo attuale">
      <button class="btn link" type="submit" form="remove-bg">Rimuovi immagine</button></div>
  <?php endif; ?>
  <?= render_setting('bg_overlay') ?>

  <div class="ct sep">Caratteri</div>
  <?= render_setting('font_head') ?>
  <?= render_setting('font_head_google') ?>
  <?= render_setting('font_body') ?>
  <?= render_setting('font_body_google') ?>
  <div class="font-preview" data-font-preview><span class="fp-h">Il nome della rosa</span><span class="fp-b">Umberto Eco · Bompiani, 2012 · 624 pagine</span></div>
  <?= render_setting('font_size') ?>

  <div class="ct sep">Forme e impaginazione</div>
  <label class="lab" for="st-radius">Arrotondamento angoli: <b data-radius-val><?= setting_int('radius') ?></b> px</label>
  <input type="range" id="st-radius" name="radius" min="0" max="28" value="<?= setting_int('radius', 0, 28) ?>" data-range-var="radius">
  <?= render_setting('grid_cols') ?>
  <?= render_setting('cover_shadow') ?>

  <div class="ct sep">Stile delle icone</div>
  <?php
    $ico_cur = icon_style();
    $ico_css = '';
    foreach (icon_styles() as $ik => $iv) {
        $ico_css .= icon_style_css($ik, '.icoprev-' . $ik);
    }
    echo '<style>' . $ico_css . '</style>';
  ?>
  <div class="ico-styles">
    <?php foreach (icon_styles() as $ik => $iv): ?>
    <label class="ico-card icoprev-<?= h($ik) ?>">
      <input type="radio" name="icon_style" value="<?= h($ik) ?>" <?= $ik === $ico_cur ? 'checked' : '' ?>>
      <span class="ico-row"><?php foreach (array('books', 'search', 'wheel', 'gear', 'user', 'lock', 'image', 'trash', 'tag', 'cloud', 'camera', 'folder') as $in) { echo icon($in, 24, $ik); } ?></span>
      <b><?= h($iv[0]) ?></b><small><?= h($iv[1]) ?></small>
    </label>
    <?php endforeach; ?>
  </div>
  <label class="check switch" style="margin-top:10px"><input type="checkbox" name="icon_accent" value="1" <?= setting('icon_accent', '0') === '1' ? 'checked' : '' ?>><span>Icone nel colore di accento del tema (es. dorate)</span></label>
  <p class="hint">Lo stile vale per tutto il sito: barra in basso, menu, pulsanti e pannello di gestione.</p>

  <div class="ct sep">Logo</div>
  <div class="thumbrow"><?= brand_logo_html() ?><span class="sub"><?= setting('logo_file') !== '' ? 'Logo personalizzato' : 'Icona predefinita' ?></span></div>
  <input class="input" type="file" name="logo" accept="image/*">
  <?= aspetto_media_select('logo_media') ?>
  <?php if (setting('logo_file') !== ''): ?>
    <label class="check"><input type="checkbox" name="remove_logo" value="1"> Togli il logo e usa l'icona predefinita</label>
  <?php endif; ?>

  <div class="ct sep">Icona dell'app (schermata Home del telefono)</div>
  <div class="thumbrow"><img src="icon.php?s=192&amp;v=<?= h(substr(md5(setting('app_icon_file') . setting('logo_file')), 0, 8)) ?>" alt="" width="56" height="56" style="border-radius:12px">
    <span class="sub"><?= setting('app_icon_file') !== '' ? 'Icona personalizzata' : (setting('logo_file') !== '' ? 'Fatta con il logo' : 'Icona predefinita') ?></span></div>
  <input class="input" type="file" name="app_icon" accept="image/png,image/jpeg,image/webp">
  <?= aspetto_media_select('app_icon_media') ?>
  <p class="hint">Un'immagine quadrata, almeno 512 × 512 pixel, con lo sfondo pieno fino ai bordi (niente trasparenze) e il disegno principale al centro:
    il telefono la ritaglia in tondo o con gli angoli arrotondati. Dopo averla cambiata, togli l'icona dalla schermata Home e aggiungila di nuovo.</p>
  <?php if (setting('app_icon_file') !== ''): ?>
    <label class="check"><input type="checkbox" name="remove_app_icon" value="1"> Togli l'icona personalizzata</label>
  <?php endif; ?>

  <div class="ct sep">CSS personalizzato</div>
  <?= render_setting('custom_css', 'Regole CSS aggiuntive (per chi vuole il controllo totale)') ?>
  <p class="hint">Variabili disponibili: --primary, --accent, --bg, --panel, --soft, --ink, --muted, --line, --radius, --head, --body.</p>

  <button class="btn primary sticky-save" type="submit">Salva l'aspetto</button>
</form>
<form method="post" id="remove-bg"><?= csrf_field() ?><input type="hidden" name="action" value="remove_bg"></form>
<form method="post" data-confirm="Riportare colori, caratteri e forme ai valori predefiniti (Biblioteca Classica)?">
  <?= csrf_field() ?><input type="hidden" name="action" value="reset_group"><input type="hidden" name="group" value="aspetto">
  <button class="btn link" type="submit">Ripristina l'aspetto predefinito</button>
</form>
