<?php
$types = custom_field_types();
$counts = array();
if (extras_ready()) {
    foreach (db()->query("SELECT field_id, COUNT(*) AS n FROM book_field_values WHERE value <> '' GROUP BY field_id")->fetchAll() as $r) {
        $counts[(int)$r['field_id']] = (int)$r['n'];
    }
}
$fields = custom_fields_all();
?>
<div class="adm-grid2 wide-left">
  <div>
    <div class="card">
      <div class="ct">Campi della scheda libro</div>
      <p class="sub">I campi compaiono nel modulo di ogni libro (Aggiungi e Modifica), sotto quelli normali. Il numero decide l'ordine.</p>
      <?php if (!$fields): ?><p class="hint">Nessun campo ancora. Esempi: <b>Prezzo pagato</b> (numero), <b>Data di acquisto</b> (data), <b>Autografato</b> (sì/no),
        <b>Condizioni</b> (elenco: Nuovo, Buono, Rovinato), <b>Link alla recensione</b> (indirizzo web).</p><?php endif; ?>
    </div>
    <?php foreach ($fields as $fid => $f): ?>
    <details class="card">
      <summary><?= h($f['name']) ?> <span class="pill"><?= h($types[$f['type']]) ?></span>
        <span class="muted sm-text"><?= isset($counts[$fid]) ? $counts[$fid] . ' libri compilati' : 'nessun libro compilato' ?></span></summary>
      <form method="post" class="stack">
        <?= csrf_field() ?><input type="hidden" name="action" value="field_save"><input type="hidden" name="id" value="<?= (int)$fid ?>">
        <div class="row3">
          <div><label class="lab">Nome</label><input class="input" name="name" value="<?= h($f['name']) ?>" maxlength="80" required></div>
          <div><label class="lab">Tipo</label><select class="input" name="type" data-field-type>
            <?php foreach ($types as $k => $v): ?><option value="<?= h($k) ?>" <?= $f['type'] === $k ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?></select></div>
          <div><label class="lab">Ordine</label><input class="input" name="sort_order" value="<?= (int)$f['sort_order'] ?>" inputmode="numeric"></div>
        </div>
        <div data-options-box <?= $f['type'] === 'select' ? '' : 'hidden' ?>><label class="lab">Voci dell'elenco (una per riga)</label>
          <textarea class="input" name="options" rows="4"><?= h((string)$f['options']) ?></textarea></div>
        <label class="check switch"><input type="checkbox" name="on_card" value="1" <?= (int)$f['on_card'] ? 'checked' : '' ?>><span>Mostralo nella scheda del libro</span></label>
        <label class="check switch"><input type="checkbox" name="in_csv" value="1" <?= (int)$f['in_csv'] ? 'checked' : '' ?>><span>Includilo nell'esportazione CSV</span></label>
        <p class="hint">Cambiare tipo a un campo già compilato può rendere illeggibili alcuni valori (es. da testo a numero).</p>
        <div class="savebar"><button class="btn primary small" type="submit">Salva</button></div>
      </form>
      <form method="post" data-confirm="Eliminare il campo &quot;<?= h($f['name']) ?>&quot; e i valori di tutti i libri?">
        <?= csrf_field() ?><input type="hidden" name="action" value="field_del"><input type="hidden" name="id" value="<?= (int)$fid ?>">
        <button class="btn danger-ghost small" type="submit"><?= icon('trash', 15) ?> Elimina il campo</button></form>
    </details>
    <?php endforeach; ?>
  </div>

  <form method="post" class="card stack">
    <?= csrf_field() ?><input type="hidden" name="action" value="field_add">
    <div class="ct"><?= icon('plus', 18) ?> Nuovo campo</div>
    <label class="lab" for="nf-name">Nome</label>
    <input class="input" id="nf-name" name="name" maxlength="80" required placeholder="es. Prezzo pagato">
    <label class="lab" for="nf-type">Tipo</label>
    <select class="input" id="nf-type" name="type" data-field-type>
      <?php foreach ($types as $k => $v): ?><option value="<?= h($k) ?>"><?= h($v) ?></option><?php endforeach; ?>
    </select>
    <div data-options-box hidden><label class="lab" for="nf-opt">Voci dell'elenco (una per riga)</label>
      <textarea class="input" id="nf-opt" name="options" rows="4" placeholder="Nuovo&#10;Buono&#10;Rovinato"></textarea></div>
    <label class="check switch"><input type="checkbox" name="on_card" value="1" checked><span>Mostralo nella scheda del libro</span></label>
    <label class="check switch"><input type="checkbox" name="in_csv" value="1" checked><span>Includilo nell'esportazione CSV</span></label>
    <button class="btn primary" type="submit">Crea il campo</button>
  </form>
</div>
