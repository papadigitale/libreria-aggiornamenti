<?php
/*
 * Aggiornamento dei programmi da un pacchetto update.zip caricato dal pannello.
 *
 * Formato del pacchetto:
 *   libreria-update.json   { "app": "libreria-di-casa", "version": "1.2.0", "requires": "1.1.0",
 *                            "php_min": "7.4.0", "db_version": 3, "date": "...", "notes": ["..."],
 *                            "files": { "public_html/index.php": "<sha256>", ... }, "remove": ["percorso", ...] }
 *   files/<percorso>       i file nuovi, con la stessa struttura delle cartelle del sito
 *
 * Si possono sostituire solo public_html, CONF (tranne config.php), sql, strumenti e LEGGIMI.md:
 * la cartella data (copertine, backup, configurazione) e il database non vengono mai toccati dai file.
 * Prima di installare: backup completo dei dati e copia dei programmi attuali (per tornare indietro).
 */

define('UPDATE_MANIFEST', 'libreria-update.json');

function updater_base()
{
    return dirname(APP_ROOT);
}

function updater_dir()
{
    $d = DATA_DIR . '/updates';
    if (!is_dir($d)) {
        @mkdir($d, 0775, true);
    }
    if (is_dir($d) && !is_file($d . '/.htaccess')) {
        @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return $d;
}

function updater_path_ok($p)
{
    if (!is_string($p) || $p === '' || strlen($p) > 200) {
        return false;
    }
    if ($p === 'LEGGIMI.md') {
        return true;
    }
    // la configurazione e la chiave dell'autore non viaggiano mai negli aggiornamenti
    if (!preg_match('#^(public_html|CONF|sql|strumenti)/[A-Za-z0-9._\-/]+$#', $p) || $p === 'CONF/config.php' || $p === 'CONF/firma_autore.json') {
        return false;
    }
    foreach (explode('/', $p) as $seg) {
        if ($seg === '' || $seg === '.' || $seg === '..') {
            return false;
        }
    }
    return true;
}

// Tutti i file dei programmi attualmente installati (percorsi relativi)
function updater_current_files($base = null)
{
    $base = $base === null ? updater_base() : $base;
    $out = array();
    foreach (array('public_html', 'CONF', 'sql', 'strumenti') as $root) {
        if (!is_dir($base . '/' . $root)) {
            continue;
        }
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base . '/' . $root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $f) {
            if (!$f->isFile()) {
                continue;
            }
            $rel = $root . '/' . str_replace('\\', '/', substr($f->getPathname(), strlen($base . '/' . $root) + 1));
            if (updater_path_ok($rel)) {
                $out[] = $rel;
            }
        }
    }
    if (is_file($base . '/LEGGIMI.md')) {
        $out[] = 'LEGGIMI.md';
    }
    sort($out);
    return $out;
}

/*
 * Crea un pacchetto con i programmi di $base (usato per la copia di sicurezza prima di aggiornare
 * e dallo strumento strumenti/crea_aggiornamento.php).
 */
function updater_build_package($base, $zip_path, $version, $notes = array(), $remove = array(), $requires = '', $db_version = 0)
{
    if (!class_exists('ZipArchive')) {
        throw new Exception('L\'estensione ZIP di PHP non è attiva.');
    }
    $files = array();
    $zip = new ZipArchive();
    if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new Exception('Impossibile creare ' . $zip_path);
    }
    foreach (updater_current_files($base) as $rel) {
        $files[$rel] = hash_file('sha256', $base . '/' . $rel);
        $zip->addFile($base . '/' . $rel, 'files/' . $rel);
    }
    $manifest = array('app' => 'libreria-di-casa', 'version' => $version, 'requires' => $requires, 'php_min' => '7.4.0',
        'db_version' => (int)$db_version, 'date' => date('c'), 'notes' => array_values((array)$notes), 'files' => $files,
        'remove' => array_values(array_filter((array)$remove, 'updater_path_ok')));
    $zip->addFromString(UPDATE_MANIFEST, json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $zip->close();
    return $manifest;
}

/*
 * Legge e verifica un pacchetto. Ritorna array con: manifest, new, changed, same, remove, errors.
 * $rollback = true: ammette anche una versione uguale o precedente (ritorno a una copia salvata).
 */
function updater_inspect($zip_path, $rollback = false)
{
    $r = array('manifest' => null, 'new' => 0, 'changed' => 0, 'same' => 0, 'remove' => 0, 'errors' => array(), 'list' => array());
    if (!class_exists('ZipArchive')) {
        $r['errors'][] = 'L\'estensione ZIP di PHP non è attiva sul server.';
        return $r;
    }
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        $r['errors'][] = 'Il file non è un archivio ZIP valido.';
        return $r;
    }
    $json = $zip->getFromName(UPDATE_MANIFEST);
    $m = $json !== false ? json_decode($json, true) : null;
    if (!is_array($m) || !isset($m['app']) || $m['app'] !== 'libreria-di-casa') {
        $zip->close();
        $r['errors'][] = 'Questo file non è un pacchetto di aggiornamento della Libreria di Casa (manca ' . UPDATE_MANIFEST . ').';
        return $r;
    }
    $r['manifest'] = $m;
    $ver = isset($m['version']) ? (string)$m['version'] : '';
    if (!preg_match('/^\d+\.\d+\.\d+$/', $ver)) {
        $r['errors'][] = 'Numero di versione del pacchetto non valido.';
    } elseif (!$rollback && version_compare($ver, APP_VERSION, '<=')) {
        $r['errors'][] = 'Il pacchetto contiene la versione ' . $ver . ', che non è più recente di quella installata (' . APP_VERSION . ').';
    }
    if (!empty($m['requires']) && version_compare(APP_VERSION, (string)$m['requires'], '<')) {
        $r['errors'][] = 'Questo aggiornamento richiede almeno la versione ' . $m['requires'] . ': installa prima gli aggiornamenti intermedi.';
    }
    if (!empty($m['php_min']) && version_compare(PHP_VERSION, (string)$m['php_min'], '<')) {
        $r['errors'][] = 'Questo aggiornamento richiede PHP ' . $m['php_min'] . ' o successivo (sul server c\'è ' . PHP_VERSION . ').';
    }
    $files = isset($m['files']) && is_array($m['files']) ? $m['files'] : array();
    if (!$files || count($files) > 5000) {
        $r['errors'][] = 'L\'elenco dei file del pacchetto è vuoto o non valido.';
    }
    $base = updater_base();
    foreach ($files as $path => $hash) {
        if (!updater_path_ok($path) || !preg_match('/^[a-f0-9]{64}$/', (string)$hash)) {
            $r['errors'][] = 'Percorso non ammesso nel pacchetto: ' . $path;
            continue;
        }
        $stat = $zip->statName('files/' . $path);
        if ($stat === false || $stat['size'] > 30 * 1024 * 1024) {
            $r['errors'][] = 'File mancante o troppo grande nel pacchetto: ' . $path;
            continue;
        }
        $data = $zip->getFromName('files/' . $path);
        if ($data === false || hash('sha256', $data) !== $hash) {
            $r['errors'][] = 'File danneggiato (controllo di integrità non superato): ' . $path;
            continue;
        }
        if (!is_file($base . '/' . $path)) {
            $r['new']++;
            $r['list'][] = array('+', $path);
        } elseif (hash_file('sha256', $base . '/' . $path) !== $hash) {
            $r['changed']++;
            $r['list'][] = array('~', $path);
        } else {
            $r['same']++;
        }
    }
    foreach ((array)(isset($m['remove']) ? $m['remove'] : array()) as $p) {
        if (!updater_path_ok($p)) {
            $r['errors'][] = 'Percorso da rimuovere non ammesso: ' . $p;
        } elseif (is_file($base . '/' . $p)) {
            $r['remove']++;
            $r['list'][] = array('-', $p);
        }
    }
    $zip->close();
    // firma dell'autore: obbligatoria se sul sito c'e' la sua chiave (le copie automatiche per tornare indietro sono interne)
    require_once dirname(__FILE__) . '/firma.php';
    $r['firma'] = $rollback ? array('stato' => 'interno', 'testo' => 'Copia automatica dei programmi di questo sito.')
        : firma_verifica_zip($zip_path, 'aggiornamento');
    if (!$rollback) {
        $fs = $r['firma']['stato'];
        if ($fs === 'non_valido') {
            array_unshift($r['errors'], $r['firma']['testo']);
        } elseif (firma_chiave_pubblica() && $fs !== 'firmato') {
            array_unshift($r['errors'], $fs === 'non_disponibile' ? $r['firma']['testo']
                : 'Il pacchetto non è firmato dall\'autore: su questo sito si installano solo aggiornamenti firmati.');
            $r['unsigned'] = $fs === 'non_firmato';
        }
    }
    if (count($r['errors']) > 12) {
        $r['errors'] = array_merge(array_slice($r['errors'], 0, 12), array('… e altri ' . (count($r['errors']) - 12) . ' problemi.'));
    }
    return $r;
}

// File e cartelle dei programmi che il web server non puo' modificare (vuoto = tutto a posto)
function updater_not_writable()
{
    $base = updater_base();
    $bad = array();
    foreach (array('public_html', 'CONF', 'sql', 'strumenti') as $root) {
        if (is_dir($base . '/' . $root) && !is_writable($base . '/' . $root)) {
            $bad[] = $root . '/';
        }
    }
    foreach (updater_current_files() as $rel) {
        if (count($bad) >= 8) {
            break;
        }
        if (!is_writable($base . '/' . $rel) || !is_writable(dirname($base . '/' . $rel))) {
            $bad[] = $rel;
        }
    }
    return array_values(array_unique($bad));
}

// Scrive un file sostituendo quello esistente nel modo piu' sicuro possibile
function updater_write($target, $data)
{
    $dir = dirname($target);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
        throw new Exception('Impossibile creare la cartella ' . $dir);
    }
    $tmp = $target . '.upd-' . substr(md5(uniqid('', true)), 0, 6);
    if (@file_put_contents($tmp, $data) === false) {
        throw new Exception('Impossibile scrivere ' . $target);
    }
    if (is_file($target)) {
        @chmod($tmp, fileperms($target) & 0777);
    }
    if (!@rename($tmp, $target)) {
        @unlink($tmp);
        if (@file_put_contents($target, $data) === false) {
            throw new Exception('Impossibile sostituire ' . $target);
        }
    }
}

// Copia i file del pacchetto sul sito (senza controlli: il pacchetto e' gia' stato verificato)
function updater_copy_files($zip_path)
{
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        throw new Exception('Pacchetto non leggibile.');
    }
    $m = json_decode($zip->getFromName(UPDATE_MANIFEST), true);
    $base = updater_base();
    $n = 0;
    foreach ($m['files'] as $path => $hash) {
        if (!updater_path_ok($path)) {
            continue;
        }
        $data = $zip->getFromName('files/' . $path);
        if ($data === false || hash('sha256', $data) !== $hash) {
            $zip->close();
            throw new Exception('File danneggiato: ' . $path);
        }
        if (is_file($base . '/' . $path) && hash_file('sha256', $base . '/' . $path) === $hash) {
            continue;
        }
        updater_write($base . '/' . $path, $data);
        $n++;
    }
    foreach ((array)(isset($m['remove']) ? $m['remove'] : array()) as $p) {
        if (updater_path_ok($p) && is_file($base . '/' . $p)) {
            @unlink($base . '/' . $p);
        }
    }
    $zip->close();
    return $n;
}

function updater_code_backups()
{
    $out = array();
    foreach (glob(updater_dir() . '/codice_*.zip') ?: array() as $f) {
        if (preg_match('/^codice_(\d+\.\d+\.\d+)_(\d{8}_\d{6})\.zip$/', basename($f), $m)) {
            $out[] = array('file' => basename($f), 'version' => $m[1], 'time' => filemtime($f), 'size' => filesize($f));
        }
    }
    usort($out, function ($a, $b) {
        return $b['time'] - $a['time'];
    });
    return $out;
}

/*
 * Installa un pacchetto gia' verificato. In caso di errore rimette i programmi di prima.
 * Ritorna array(file_scritti, copia_programmi, backup_dati)
 */
function updater_apply($zip_path, $target_version, $rollback = false)
{
    if (function_exists('set_time_limit')) {
        @set_time_limit(300);
    }
    require_once dirname(__FILE__) . '/data_tools.php';
    $dir = updater_dir();
    // 1) backup completo dei dati (libri, copertine, utenti, impostazioni)
    $data_backup = backup_create($rollback ? 'prima-ritorno' : 'prima-aggiornamento', true);
    // 2) copia dei programmi attuali, nello stesso formato di un pacchetto (serve per tornare indietro)
    $code_backup = 'codice_' . APP_VERSION . '_' . date('Ymd_His') . '.zip';
    updater_build_package(updater_base(), $dir . '/' . $code_backup, APP_VERSION, array('Copia automatica prima di installare la versione ' . $target_version),
        array(), '', APP_DB_VERSION);
    // 3) manutenzione + copia dei file
    @file_put_contents(MAINTENANCE_FILE, date('c') . ' aggiornamento a ' . $target_version . "\n");
    try {
        $n = updater_copy_files($zip_path);
    } catch (Exception $e) {
        try {
            updater_copy_files($dir . '/' . $code_backup); // si rimette tutto com'era
        } catch (Exception $e2) {
            @unlink(MAINTENANCE_FILE);
            throw new Exception($e->getMessage() . ' — ATTENZIONE: anche il ripristino automatico non è riuscito (' . $e2->getMessage()
                . '). I programmi di prima sono in data/updates/' . $code_backup);
        }
        @unlink(MAINTENANCE_FILE);
        throw new Exception($e->getMessage() . ' Nessuna modifica: i programmi di prima sono stati rimessi al loro posto.');
    }
    @unlink(MAINTENANCE_FILE);
    if (function_exists('opcache_reset')) {
        @opcache_reset();
    }
    // tiene solo le 5 copie dei programmi piu' recenti
    foreach (array_slice(updater_code_backups(), 5) as $old) {
        @unlink($dir . '/' . $old['file']);
    }
    return array($n, $code_backup, $data_backup);
}

function updater_check_password()
{
    $u = current_user();
    if (!$u) {
        return false;
    }
    $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
    $st->execute(array((int)$u['id']));
    return password_verify(isset($_POST['password']) ? (string)$_POST['password'] : '', (string)$st->fetchColumn());
}

function updater_handle_post($a)
{
    $back = 'gestione.php?sez=aggiornamento';
    if ($a === 'maint_on' || $a === 'maint_off') {
        if ($a === 'maint_on') {
            @file_put_contents(MAINTENANCE_FILE, date('c') . " manutenzione manuale\n");
            @touch(MAINTENANCE_FILE);
        } else {
            @unlink(MAINTENANCE_FILE);
        }
        app_log('manutenzione', $a === 'maint_on' ? 'Modalità manutenzione attivata' : 'Modalità manutenzione disattivata', 'warn');
        flash($a === 'maint_on' ? 'Manutenzione attiva per 30 minuti: gli altri utenti vedono "Torniamo subito".' : 'Manutenzione disattivata.');
        redirect($back);
    }
    if (IS_DOCKER) {
        flash('Con Docker i programmi si aggiornano ricostruendo l\'immagine (vedi le istruzioni in questa pagina).', 'error');
        redirect($back);
    }
    $dir = updater_dir();
    if ($a === 'upd_cancel') {
        if (!empty($_SESSION['upd_pending']) && is_file($dir . '/' . $_SESSION['upd_pending']['file'])) {
            @unlink($dir . '/' . $_SESSION['upd_pending']['file']);
        }
        unset($_SESSION['upd_pending']);
        redirect($back);
    }
    if ($a === 'upd_upload') {
        if (!isset($_FILES['package']) || $_FILES['package']['error'] !== UPLOAD_ERR_OK) {
            $err = isset($_FILES['package']['error']) ? (int)$_FILES['package']['error'] : 0;
            flash($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE ? 'Il file è più grande del limite di caricamento del server.' : 'Scegli il file update.zip.', 'error');
            redirect($back);
        }
        if (!is_dir($dir) || !is_writable($dir)) {
            flash('La cartella data/updates non è scrivibile.', 'error');
            redirect($back);
        }
        $name = 'in_arrivo_' . substr(random_token(4), 0, 8) . '.zip';
        if (!move_uploaded_file($_FILES['package']['tmp_name'], $dir . '/' . $name)) {
            flash('Caricamento non riuscito.', 'error');
            redirect($back);
        }
        if (!empty($_SESSION['upd_pending']) && is_file($dir . '/' . $_SESSION['upd_pending']['file'])) {
            @unlink($dir . '/' . $_SESSION['upd_pending']['file']);
        }
        // pacchetto non firmato e chiave privata sul server: lo si firma qui con la passphrase dell'autore
        require_once dirname(__FILE__) . '/firma.php';
        if (post('passphrase') !== '' && firma_chiave_pubblica() && firma_privata_presente()) {
            $pre = firma_verifica_zip($dir . '/' . $name, 'aggiornamento');
            if ($pre['stato'] === 'non_firmato') {
                if (firma_pass_bloccata()) {
                    @unlink($dir . '/' . $name);
                    flash('Troppe passphrase sbagliate: riprova tra 15 minuti.', 'error');
                    redirect($back);
                }
                try {
                    $k = firma_apri_privata(post('passphrase'));
                    firma_firma_zip($dir . '/' . $name, $k, 'aggiornamento');
                    app_log('aggiornamento_firmato', 'Pacchetto firmato dal pannello con la chiave dell\'autore', 'warn');
                } catch (Exception $e) {
                    firma_pass_errata();
                    @unlink($dir . '/' . $name);
                    flash('Firma non riuscita: ' . $e->getMessage(), 'error');
                    redirect($back);
                }
            }
        }
        $r = updater_inspect($dir . '/' . $name);
        if ($r['errors']) {
            @unlink($dir . '/' . $name);
            unset($_SESSION['upd_pending']);
            app_log('aggiornamento_rifiutato', implode(' | ', array_slice($r['errors'], 0, 3)), 'warn');
            flash('Pacchetto non installabile: ' . implode(' ', array_slice($r['errors'], 0, 3)), 'error');
            redirect($back);
        }
        $_SESSION['upd_pending'] = array('file' => $name, 'version' => $r['manifest']['version'], 'rollback' => false);
        app_log('aggiornamento_caricato', 'Pacchetto versione ' . $r['manifest']['version'] . ' verificato');
        redirect($back);
    }
    if ($a === 'upd_rollback') {
        $f = post('f');
        $ok = false;
        foreach (updater_code_backups() as $cb) {
            if ($cb['file'] === $f) {
                $ok = true;
            }
        }
        if (!$ok) {
            redirect($back);
        }
        $_SESSION['upd_pending'] = array('file' => $f, 'version' => preg_replace('/^codice_([\d.]+)_.*$/', '$1', $f), 'rollback' => true);
        redirect($back);
    }
    if ($a === 'upd_apply') {
        $p = isset($_SESSION['upd_pending']) ? $_SESSION['upd_pending'] : null;
        if (!$p || !is_file($dir . '/' . $p['file'])) {
            flash('Carica di nuovo il pacchetto.', 'error');
            redirect($back);
        }
        if (!updater_check_password()) {
            app_log('aggiornamento_password_errata', 'Password errata alla conferma dell\'aggiornamento', 'alert');
            flash('Password non corretta: aggiornamento non eseguito.', 'error');
            redirect($back);
        }
        $bad = updater_not_writable();
        if ($bad) {
            flash('Il web server non può modificare i file dei programmi (' . implode(', ', array_slice($bad, 0, 3)) . '): vedi le istruzioni in questa pagina.', 'error');
            redirect($back);
        }
        $r = updater_inspect($dir . '/' . $p['file'], !empty($p['rollback']));
        if ($r['errors']) {
            flash('Pacchetto non installabile: ' . implode(' ', array_slice($r['errors'], 0, 3)), 'error');
            redirect($back);
        }
        $from = APP_VERSION;
        try {
            list($n, $code_backup, $data_backup) = updater_apply($dir . '/' . $p['file'], $p['version'], !empty($p['rollback']));
        } catch (Exception $e) {
            app_log('aggiornamento_fallito', $e->getMessage(), 'alert');
            flash('Aggiornamento non riuscito: ' . $e->getMessage(), 'error');
            redirect($back);
        }
        if (empty($p['rollback'])) {
            @unlink($dir . '/' . $p['file']);
        }
        unset($_SESSION['upd_pending']);
        app_log(!empty($p['rollback']) ? 'ritorno_versione' : 'aggiornamento', 'Da ' . $from . ' a ' . $p['version'] . ': ' . $n . ' file. Copia dei programmi: '
            . $code_backup . ', backup dei dati: ' . $data_backup, 'alert');
        flash((!empty($p['rollback']) ? 'Ritorno alla versione ' : 'Aggiornamento alla versione ') . $p['version'] . ' completato (' . $n . ' file). '
            . 'Prima è stato salvato un backup completo: ' . $data_backup . '.');
        redirect($back . '&fatto=1');
    }
}
