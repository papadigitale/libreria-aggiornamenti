<?php
/* Modifica di un libro dal pannello ($BOOK preparato da gestione.php) */
$b = $BOOK;
$val = $b;
$readers = db()->prepare("SELECT u.display_name, u.username, ub.status, ub.updated_at FROM user_books ub INNER JOIN users u ON u.id = ub.user_id "
    . "WHERE ub.book_id = ? AND ub.status <> '' ORDER BY u.display_name");
$readers->execute(array((int)$b['id']));
$readers = $readers->fetchAll();
$back = admin_back_from_referer();
// libro precedente e successivo nell'elenco per titolo, per passare velocemente al prossimo
$prev = db()->prepare('SELECT id, title FROM books WHERE title < ? OR (title = ? AND id < ?) ORDER BY title DESC, id DESC LIMIT 1');
$prev->execute(array($b['title'], $b['title'], (int)$b['id']));
$prev = $prev->fetch();
$next = db()->prepare('SELECT id, title FROM books WHERE title > ? OR (title = ? AND id > ?) ORDER BY title ASC, id ASC LIMIT 1');
$next->execute(array($b['title'], $b['title'], (int)$b['id']));
$next = $next->fetch();

function admin_back_from_referer()
{
    $r = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
    if (preg_match('#/(gestione\.php\?sez=libri[A-Za-z0-9_=&%+.\-]*)$#', $r, $m)) {
        return $m[1];
    }
    return 'gestione.php?sez=libri';
}
?>
<div class="adm-edit">
  <form method="post" class="card stack" action="gestione.php?sez=libro&amp;id=<?= (int)$b['id'] ?>">
    <?= csrf_field() ?><input type="hidden" name="action" value="book_save"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
    <input type="hidden" name="back" value="<?= h($back) ?>">
    <div class="form-cols">
      <?php include APP_ROOT . '/inc/book_form_fields.php'; ?>
    </div>
    <div class="savebar">
      <button class="btn primary small" type="submit">Salva modifiche</button>
      <button class="btn ghost small" type="submit" name="next" value="lista">Salva e torna all'elenco</button>
      <a class="btn link small" href="<?= h($back) ?>">Annulla</a>
    </div>
  </form>

  <aside class="adm-aside">
    <div class="card center">
      <?= book_cover_html($b, 'cover big') ?>
      <div class="side-links">
        <form method="post" action="gestione.php?sez=libro&amp;id=<?= (int)$b['id'] ?>"><?= csrf_field() ?><input type="hidden" name="action" value="book_refill_one">
          <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
          <button class="btn ghost small" type="submit"><?= icon('cloud', 15) ?> Cerca online copertina, trama e dati mancanti</button></form>
        <a class="link small-link" href="libro.php?id=<?= (int)$b['id'] ?>">Apri la scheda sul sito</a>
      </div>
    </div>
    <details class="card" id="copertina" <?= get('cop') === '1' ? 'open' : '' ?>>
      <summary class="ct" style="cursor:pointer;margin:0"><?= icon('image', 16) ?> Cambia copertina</summary>
      <form method="post" enctype="multipart/form-data" class="stack" action="gestione.php?sez=libro&amp;id=<?= (int)$b['id'] ?>">
        <?= csrf_field() ?><input type="hidden" name="action" value="book_cover"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
        <?php if ($b['isbn13']): ?>
        <div class="cover-options" data-cover-options data-isbn="<?= h($b['isbn13']) ?>">
          <button class="btn ghost small" type="button" data-find-covers><?= icon('cloud', 15) ?> Cerca copertine online</button>
          <div class="cover-picks"></div>
        </div>
        <?php endif; ?>
        <label class="lab" for="cv-file">Immagine dal computer</label>
        <input class="input" type="file" id="cv-file" name="cover" accept="image/*">
        <label class="lab" for="cv-url">Oppure indirizzo di un'immagine sul web</label>
        <input class="input" type="url" id="cv-url" name="cover_url" placeholder="https://…">
        <button class="btn primary small" type="submit">Usa questa copertina</button>
      </form>
      <?php if ($b['cover_file']): ?>
      <form method="post" action="gestione.php?sez=libro&amp;id=<?= (int)$b['id'] ?>" data-confirm="Togliere la copertina di questo libro?"><?= csrf_field() ?>
        <input type="hidden" name="action" value="book_cover_del"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
        <button class="btn danger-ghost small" type="submit" style="margin-top:8px"><?= icon('trash', 15) ?> Togli la copertina</button></form>
      <?php endif; ?>
    </details>
    <div class="card">
      <div class="ct">Informazioni</div>
      <div class="fr row"><span>Aggiunto</span><span><?= h(fmt_dt($b['created_at'])) ?></span></div>
      <div class="fr row"><span>Ultima modifica</span><span><?= h(fmt_dt($b['updated_at'])) ?></span></div>
      <div class="fr row"><span>Fonte dei dati</span><span><?= h($b['source'] ? $b['source'] : '—') ?></span></div>
      <?php foreach ($readers as $r): ?>
      <div class="fr row"><span><?= h($r['display_name'] !== '' ? $r['display_name'] : $r['username']) ?></span><span class="pill st-<?= h($r['status']) ?>"><?= h(status_label($r['status'])) ?></span></div>
      <?php endforeach; ?>
    </div>
    <?php $loan = loan_open_for_book((int)$b['id']); if ($loan): ?>
    <div class="card loan-side <?= $loan['due_at'] && $loan['due_at'] < date('Y-m-d') ? 'late' : '' ?>"><div class="ct">In prestito</div>
      <p class="sub"><b><?= h($loan['borrower']) ?></b> dal <?= h(date('d/m/Y', strtotime($loan['lent_at']))) ?> · <?= h(loan_status_text($loan)) ?></p>
      <a class="link" href="gestione.php?sez=prestiti">Gestisci i prestiti</a></div>
    <?php endif; ?>
    <div class="card prevnext">
      <?php if ($prev): ?><a href="gestione.php?sez=libro&amp;id=<?= (int)$prev['id'] ?>">‹ <?= h(str_cut($prev['title'], 34)) ?></a><?php else: ?><span></span><?php endif; ?>
      <?php if ($next): ?><a href="gestione.php?sez=libro&amp;id=<?= (int)$next['id'] ?>"><?= h(str_cut($next['title'], 34)) ?> ›</a><?php endif; ?>
    </div>
    <form method="post" action="gestione.php?sez=libri" data-confirm="Spostare &quot;<?= h($b['title']) ?>&quot; nel cestino? Potrai recuperarlo da Libri → Cestino.">
      <?= csrf_field() ?><input type="hidden" name="action" value="books_bulk"><input type="hidden" name="op" value="delete">
      <input type="hidden" name="ids[]" value="<?= (int)$b['id'] ?>"><input type="hidden" name="back" value="<?= h($back) ?>">
      <button class="btn danger-ghost small" type="submit"><?= icon('trash', 15) ?> Sposta nel cestino</button>
    </form>
  </aside>
</div>
