<?php
/*
 * Icone del sito: 5 set disegnati apposta (24x24, SVG), selezionabili in Aspetto → Stile delle icone.
 *   classiche   linee pulite (lo stile originale)
 *   eleganti    tratto finissimo e dettagli raffinati
 *   morbide     forme tonde e piene di carattere
 *   piene       sagome piene, come le icone di iPhone e Android
 *   geometriche angoli vivi e forme squadrate
 * Opzione in piu': icone nel colore di accento del tema.
 */
require_once dirname(__FILE__) . '/icon_sets.php';

function icon_styles()
{
    return array(
        'classiche'   => array('Classiche', 'Linee pulite di spessore medio: lo stile originale'),
        'eleganti'    => array('Eleganti', 'Tratto finissimo e dettagli raffinati'),
        'morbide'     => array('Morbide', 'Forme tonde e amichevoli, tratto pieno'),
        'piene'       => array('Piene', 'Sagome piene, come le icone di iPhone e Android'),
        'geometriche' => array('Geometriche', 'Angoli vivi e forme squadrate, stile architettonico'),
    );
}

function icon_style()
{
    static $s = null;
    if ($s === null) {
        $s = function_exists('setting') ? setting('icon_style', 'classiche') : 'classiche';
        if (!isset(icon_styles()[$s])) {
            $s = 'classiche';
        }
    }
    return $s;
}

function icon($name, $size = 20, $set = null)
{
    static $data = null;
    if ($data === null) {
        $data = icon_sets_data();
    }
    $set = $set === null ? icon_style() : $set;
    $inner = isset($data[$set][$name]) ? $data[$set][$name] : (isset($data['classiche'][$name]) ? $data['classiche'][$name] : '');
    return '<svg class="i i-' . h($name) . '" width="' . (int)$size . '" height="' . (int)$size . '" viewBox="0 0 24 24" aria-hidden="true">' . $inner . '</svg>';
}

// Regole CSS di un set (con $scope si limitano a un contenitore, per le anteprime)
function icon_style_css($style = null, $scope = '')
{
    $style = $style === null ? icon_style() : $style;
    $p = $scope !== '' ? $scope . ' ' : '';
    $base = $p . 'svg.i{fill:none;stroke:currentColor;stroke-linecap:round;stroke-linejoin:round;';
    $rules = array(
        'classiche'   => $base . 'stroke-width:1.8}',
        'eleganti'    => $base . 'stroke-width:1.15}',
        'morbide'     => $base . 'stroke-width:2.1}',
        'piene'       => $p . 'svg.i{fill:currentColor;stroke:none}' . $p . 'svg.i .s{fill:none;stroke:currentColor;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}',
        'geometriche' => $base . 'stroke-width:1.7;stroke-linecap:square;stroke-linejoin:miter}',
    );
    $css = $rules[$style];
    if ($scope === '' && function_exists('setting') && setting('icon_accent', '0') === '1') {
        // icone nel colore di accento (tranne sui pulsanti colorati, dove resta il colore del testo)
        $css .= 'svg.i{color:var(--accent)}.btn.primary svg.i,.fab svg.i,.adm-tbtn:not(.ghost) svg.i,.seg svg.i,.alert svg.i{color:inherit}';
    }
    return $css;
}

// Compatibilita' con la 1.7: non servono piu' maschere
function icon_sprite($style = null)
{
    return '';
}
