<?php
/*
 * Backup e ripristino della libreria, esportazione/importazione CSV.
 * Il backup contiene: generi, libri, copertine, stati di lettura e ruote personali.
 * NON contiene utenti, password, impostazioni di sicurezza e log (restano quelli attuali).
 */
require_once dirname(__FILE__) . '/books.php';

function backup_dir_ready()
{
    if (!is_dir(BACKUP_DIR)) {
        @mkdir(BACKUP_DIR, 0775, true);
    }
    return is_dir(BACKUP_DIR) && is_writable(BACKUP_DIR);
}

function backup_export_data($full = false)
{
    $pdo = db();
    $users = array();
    foreach ($pdo->query('SELECT id, username FROM users')->fetchAll() as $u) {
        $users[(int)$u['id']] = $u['username'];
    }
    $map_user = function ($rows) use ($users) {
        $out = array();
        foreach ($rows as $r) {
            if (!isset($users[(int)$r['user_id']])) {
                continue;
            }
            $r['username'] = $users[(int)$r['user_id']];
            unset($r['user_id']);
            $out[] = $r;
        }
        return $out;
    };
    // diario di lettura (versione 1.6): letture, avanzamento, obiettivi, trofei di ogni utente
    $reading = array();
    if ((int)setting('db_version', '1') >= 8) {
        foreach (backup_reading_tables() as $t => $cols) {
            $reading[$t] = $map_user($pdo->query('SELECT user_id, ' . implode(', ', $cols) . ' FROM ' . $t . ' ORDER BY 1')->fetchAll());
        }
    }
    $extra = array();
    if (function_exists('extras_ready') && extras_ready()) {
        foreach (backup_extra_tables() as $t => $cols) {
            $extra[$t] = $pdo->query('SELECT ' . implode(', ', $cols) . ' FROM ' . $t)->fetchAll();
        }
    }
    // libreria media (versione 1.8): cartelle e schede dei file; i file veri vanno nello ZIP, in media/
    if ((int)setting('db_version', '1') >= 10) {
        require_once dirname(__FILE__) . '/media.php';
        $extra['media_folders'] = $pdo->query('SELECT id, name, sort_order, created_at FROM media_folders ORDER BY id')->fetchAll();
        $extra['media_files'] = $pdo->query('SELECT id, folder_id, filename, original_name, title, alt, mime, kind, size, width, height, has_thumb, created_at FROM media_files ORDER BY id')->fetchAll();
    }
    return array(
        'app' => 'libreria-di-casa',
        'version' => 2,
        'app_version' => APP_VERSION,
        'created_at' => now(),
        'categories' => $pdo->query('SELECT * FROM categories ORDER BY id')->fetchAll(),
        'books' => $pdo->query('SELECT * FROM books ORDER BY id')->fetchAll(),
        'user_books' => $map_user($pdo->query('SELECT * FROM user_books')->fetchAll()),
        'wheel_settings' => $map_user($pdo->query('SELECT * FROM wheel_settings')->fetchAll()),
        'wheel_items' => $map_user($pdo->query('SELECT * FROM wheel_items')->fetchAll()),
        'wheel_spins' => $map_user($pdo->query('SELECT * FROM wheel_spins')->fetchAll()),
    ) + $reading + $extra + ($full ? array(
        // backup COMPLETO (solo Admin): anche utenti (con password cifrate) e impostazioni del sito
        'full' => true,
        // il segreto della verifica in due passaggi va in chiaro nel backup completo: la chiave del server non viaggia con il backup
        'users' => array_map(function ($u) {
            require_once dirname(__FILE__) . '/totp.php';
            $u['totp_secret'] = $u['totp_secret'] ? totp_secret_read($u['totp_secret']) : $u['totp_secret'];
            return $u;
        }, $pdo->query('SELECT username, display_name, password_hash, role, active, must_change_pw, totp_secret, totp_enabled, created_at'
            . ((int)setting('db_version', '1') >= 12 ? ', email, email_notify' : '') . ' FROM users')->fetchAll()),
        'settings' => $pdo->query('SELECT setting_key, setting_value FROM settings')->fetchAll(),
    ) : array());
}

function backup_reading_tables()
{
    return array(
        'reading_sessions' => array('id', 'book_id', 'status', 'started_at', 'finished_at', 'date_unknown', 'rating', 'review', 'source', 'created_at', 'updated_at'),
        'reading_progress' => array('id', 'session_id', 'book_id', 'page', 'percent', 'note', 'read_at', 'created_at'),
        'reading_goals' => array('year', 'books'),
        'user_trophies' => array('code', 'level', 'unlocked_at', 'seen'),
    );
}

// Tabelle aggiunte con la versione 1.1 (etichette, campi, sezioni, pagine), nell'ordine di inserimento
function backup_extra_tables()
{
    return array(
        'taxonomies' => array('id', 'name', 'multiple', 'in_filters', 'on_card', 'sort_order', 'created_at'),
        'terms' => array('id', 'taxonomy_id', 'name', 'sort_order'),
        'custom_fields' => array('id', 'name', 'type', 'options', 'on_card', 'in_csv', 'sort_order', 'created_at'),
        'book_terms' => array('book_id', 'term_id'),
        'book_field_values' => array('book_id', 'field_id', 'value'),
        'home_sections' => array('id', 'title', 'kind', 'param', 'max_items', 'active', 'sort_order'),
        'pages' => array_merge(array('id', 'slug', 'title', 'body', 'in_menu', 'guests', 'active', 'sort_order', 'updated_at'),
            (int)setting('db_version', '1') >= 4 ? array('format', 'css', 'show_title') : array()),
    );
}

function backup_is_full($path)
{
    try {
        $d = backup_read($path);
        return !empty($d['full']);
    } catch (Exception $e) {
        return false;
    }
}

function backup_create($tag = '', $full = false)
{
    if (!backup_dir_ready()) {
        throw new Exception('La cartella data/backup non esiste o non è scrivibile.');
    }
    $data = backup_export_data($full);
    if ($full) {
        // i backup con gli account si riconoscono dal nome: li vede solo l'Admin
        $tag = $tag === '' ? 'completo' : (strpos($tag, 'completo') === false ? $tag . '_completo' : $tag);
    }
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $base = 'libreria_' . date('Ymd_His') . ($tag !== '' ? '_' . $tag : '');
    $ext = class_exists('ZipArchive') ? '.zip' : '.json';
    if (is_file(BACKUP_DIR . '/' . $base . $ext)) {
        $base .= '_' . substr(random_token(2), 0, 4);
    }
    if (class_exists('ZipArchive')) {
        $file = $base . '.zip';
        $zip = new ZipArchive();
        if ($zip->open(BACKUP_DIR . '/' . $file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new Exception('Impossibile creare il file di backup.');
        }
        $zip->addFromString('data.json', $json);
        foreach ($data['books'] as $b) {
            if ($b['cover_file'] && is_file(COVERS_DIR . '/' . $b['cover_file'])) {
                $zip->addFile(COVERS_DIR . '/' . $b['cover_file'], 'covers/' . $b['cover_file']);
            }
        }
        // i file della libreria media (non nelle copie di sicurezza automatiche "prima-...": i file restano comunque al loro posto)
        if (!empty($data['media_files']) && strpos($tag, 'prima') !== 0 && defined('MEDIA_DIR')) {
            foreach ($data['media_files'] as $m) {
                if (preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp|gif|pdf|mp4|mp3)$/', $m['filename']) && is_file(MEDIA_DIR . '/' . $m['filename'])) {
                    $zip->addFile(MEDIA_DIR . '/' . $m['filename'], 'media/' . $m['filename']);
                    if (method_exists($zip, 'setCompressionName') && preg_match('/\.(jpg|png|webp|gif|mp4|mp3)$/', $m['filename'])) {
                        $zip->setCompressionName('media/' . $m['filename'], ZipArchive::CM_STORE); // gia' compressi
                    }
                }
            }
        }
        $zip->close();
    } else {
        $file = $base . '.json';
        file_put_contents(BACKUP_DIR . '/' . $file, $json);
    }
    return $file;
}

function backup_list()
{
    $out = array();
    if (!is_dir(BACKUP_DIR)) {
        return $out;
    }
    foreach (scandir(BACKUP_DIR) as $f) {
        if (backup_name_ok($f)) {
            $out[] = array('name' => $f, 'size' => filesize(BACKUP_DIR . '/' . $f), 'time' => filemtime(BACKUP_DIR . '/' . $f));
        }
    }
    usort($out, function ($a, $b) {
        return $b['time'] - $a['time'];
    });
    return $out;
}

// I backup completi contengono gli account: li vede e li usa solo l'Admin
function backup_allowed($f)
{
    return backup_name_ok($f) && (strpos($f, '_completo') === false || is_admin());
}

function backup_name_ok($f)
{
    return (bool)preg_match('/^libreria_\d{8}_\d{6}(_[a-z0-9]+)*\.(zip|json)$/', $f);
}

function backup_read($path)
{
    $covers = array();
    if (substr($path, -4) === '.zip' || (is_file($path) && file_get_contents($path, false, null, 0, 2) === 'PK')) {
        if (!class_exists('ZipArchive')) {
            throw new Exception('Il server non supporta i file ZIP (estensione zip di PHP non attiva).');
        }
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new Exception('File di backup non leggibile.');
        }
        $json = $zip->getFromName('data.json');
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $n = $zip->getNameIndex($i);
            if (preg_match('#^covers/([a-z0-9_\-]+\.(jpg|png|webp))$#', $n, $m)) {
                $covers[$m[1]] = $zip->getFromIndex($i);
            }
        }
        $zip->close();
    } else {
        $json = file_get_contents($path);
    }
    $data = json_decode((string)$json, true);
    if (!is_array($data) || !isset($data['app']) || $data['app'] !== 'libreria-di-casa' || !isset($data['books'], $data['categories'])) {
        throw new Exception('Il file non è un backup valido di questa libreria.');
    }
    $data['_covers'] = $covers;
    return $data;
}

/*
 * Ripristina la libreria. Con $with_users (solo backup completi, solo Admin) aggiunge anche gli utenti
 * che non esistono gia' (con le loro password) e le impostazioni del sito; gli utenti attuali restano invariati.
 */
function backup_restore($path, $with_users = false)
{
    $data = backup_read($path);
    $pdo = db();
    if ($with_users && !empty($data['full'])) {
        backup_restore_users_settings($data);
    }
    $uid_by_name = array();
    foreach ($pdo->query('SELECT id, username FROM users')->fetchAll() as $u) {
        $uid_by_name[$u['username']] = (int)$u['id'];
    }
    $pdo->beginTransaction();
    try {
        $extras = function_exists('extras_ready') && extras_ready();
        if ($extras) {
            // etichette e campi: si sostituiscono solo se il backup li contiene (backup della versione 1.1 o successiva)
            foreach (array('book_terms', 'book_field_values') as $t) {
                $pdo->exec('DELETE FROM ' . $t);
            }
            foreach (array('terms', 'taxonomies', 'custom_fields', 'home_sections', 'pages') as $t) {
                $parent = $t === 'terms' ? 'taxonomies' : $t;
                if (isset($data[$parent]) && is_array($data[$parent])) {
                    $pdo->exec('DELETE FROM ' . $t);
                }
            }
        }
        $reading_on = (int)setting('db_version', '1') >= 8;
        if ($reading_on) {
            foreach (array('reading_progress', 'reading_sessions', 'reading_goals', 'user_trophies') as $t) {
                $pdo->exec('DELETE FROM ' . $t);
            }
        }
        foreach (array('wheel_spins', 'wheel_items', 'wheel_settings', 'user_books', 'books', 'categories') as $t) {
            $pdo->exec('DELETE FROM ' . $t);
        }
        $ins = $pdo->prepare('INSERT INTO categories (id, name, sort_order) VALUES (?,?,?)');
        foreach ($data['categories'] as $c) {
            $ins->execute(array((int)$c['id'], str_cut($c['name'], 100), (int)$c['sort_order']));
        }
        $cols = array('id', 'isbn13', 'isbn10', 'title', 'subtitle', 'authors', 'publisher', 'pub_year', 'pages', 'language', 'category_id', 'shelf',
            'cover_file', 'description', 'notes', 'source', 'created_by', 'created_at', 'updated_at');
        $ins = $pdo->prepare('INSERT INTO books (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')');
        foreach ($data['books'] as $b) {
            $row = array();
            foreach ($cols as $c) {
                $row[] = isset($b[$c]) && $b[$c] !== '' ? $b[$c] : null;
            }
            $row[0] = (int)$b['id'];
            $row[3] = isset($b['title']) && $b['title'] !== '' ? $b['title'] : 'Senza titolo';
            if ($row[12] !== null && !preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', $row[12])) {
                $row[12] = null;
            }
            if ($row[16] !== null && !in_array((int)$row[16], $uid_by_name, true)) {
                $row[16] = null;
            }
            $ins->execute($row);
        }
        $tables = array(
            'user_books' => array('book_id', 'status', 'wheel_excluded', 'started_at', 'finished_at', 'updated_at'),
            'wheel_settings' => array('source', 'category_id', 'max_pages', 'updated_at'),
            'wheel_items' => array('book_id'),
            'wheel_spins' => array('book_id', 'source', 'outcome', 'created_at'),
        );
        if ($reading_on) {
            $tables += backup_reading_tables();
        }
        foreach ($tables as $t => $tcols) {
            if (empty($data[$t])) {
                continue;
            }
            $ins = $pdo->prepare('INSERT INTO ' . $t . ' (user_id,' . implode(',', $tcols) . ') VALUES (?' . str_repeat(',?', count($tcols)) . ')');
            foreach ($data[$t] as $r) {
                if (!isset($r['username'], $uid_by_name[$r['username']])) {
                    continue; // utente non presente in questa installazione
                }
                $row = array($uid_by_name[$r['username']]);
                foreach ($tcols as $c) {
                    $row[] = isset($r[$c]) ? $r[$c] : null;
                }
                try {
                    $ins->execute($row);
                } catch (Exception $e) {
                    // riga incoerente (es. libro mancante): si salta
                }
            }
        }
        if ($reading_on && !isset($data['reading_sessions'])) {
            // backup di una versione precedente alla 1.6: il diario riparte dagli stati di lettura
            require_once dirname(__FILE__) . '/migrate.php';
            reading_sessions_from_user_books($pdo);
        }
        if ($extras) {
            foreach (backup_extra_tables() as $t => $tcols) {
                if (empty($data[$t]) || !is_array($data[$t])) {
                    continue;
                }
                foreach ($data[$t] as $r) {
                    $use = array_values(array_filter($tcols, function ($c) use ($r) { return array_key_exists($c, $r); }));
                    $row = array();
                    foreach ($use as $c) {
                        $row[] = $r[$c];
                    }
                    try {
                        $pdo->prepare('INSERT INTO ' . $t . ' (' . implode(',', $use) . ') VALUES (' . implode(',', array_fill(0, count($use), '?')) . ')')->execute($row);
                    } catch (Exception $e) {
                        // riga incoerente: si salta
                    }
                }
            }
        }
        $media_on = (int)setting('db_version', '1') >= 10 && isset($data['media_files']) && is_array($data['media_files']);
        if ($media_on) {
            $pdo->exec('DELETE FROM media_files');
            $pdo->exec('DELETE FROM media_folders');
            $mt = array(
                'media_folders' => array('id', 'name', 'sort_order', 'created_at'),
                'media_files' => array('id', 'folder_id', 'filename', 'original_name', 'title', 'alt', 'mime', 'kind', 'size', 'width', 'height', 'has_thumb', 'created_at'),
            );
            foreach ($mt as $t => $tcols) {
                $ins = $pdo->prepare('INSERT INTO ' . $t . ' (' . implode(',', $tcols) . ') VALUES (' . implode(',', array_fill(0, count($tcols), '?')) . ')');
                foreach (isset($data[$t]) && is_array($data[$t]) ? $data[$t] : array() as $r) {
                    if ($t === 'media_files' && (!isset($r['filename']) || !preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp|gif|pdf|mp4|mp3)$/', $r['filename']))) {
                        continue;
                    }
                    $row = array();
                    foreach ($tcols as $c) {
                        $row[] = isset($r[$c]) ? $r[$c] : null;
                    }
                    try {
                        $ins->execute($row);
                    } catch (Exception $e) {
                        // riga incoerente: si salta
                    }
                }
            }
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    if (!empty($media_on)) {
        backup_restore_media_files($path);
    }
    if (!is_dir(COVERS_DIR)) {
        @mkdir(COVERS_DIR, 0775, true);
    }
    foreach ($data['_covers'] as $name => $bin) {
        if (@getimagesizefromstring($bin)) {
            file_put_contents(COVERS_DIR . '/' . $name, $bin);
        }
    }
    return count($data['books']);
}

// Estrae i file media/ dallo ZIP un pezzo alla volta (anche video grandi senza riempire la memoria)
function backup_restore_media_files($path)
{
    if (!class_exists('ZipArchive') || !is_file($path) || file_get_contents($path, false, null, 0, 2) !== 'PK') {
        return 0;
    }
    require_once dirname(__FILE__) . '/media.php';
    if (!media_dir_ready()) {
        return 0;
    }
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        return 0;
    }
    $n = 0;
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if (!preg_match('#^media/([a-z0-9_\-]+\.(jpg|png|webp|gif|pdf|mp4|mp3))$#', $name, $m)) {
            continue;
        }
        $st = $zip->getStream($name);
        if (!$st) {
            continue;
        }
        $tmp = MEDIA_DIR . '/.ripristino_' . $m[1];
        $out = fopen($tmp, 'wb');
        $bytes = 0;
        while ($out && !feof($st)) {
            $chunk = fread($st, 262144);
            $bytes += strlen($chunk);
            if ($bytes > MEDIA_MAX_BYTES + 1048576) {
                break;
            }
            fwrite($out, $chunk);
        }
        fclose($st);
        if ($out) {
            fclose($out);
        }
        if ($bytes <= MEDIA_MAX_BYTES + 1048576 && @rename($tmp, MEDIA_DIR . '/' . $m[1])) {
            $n++;
            $mm = db()->prepare('SELECT * FROM media_files WHERE filename = ?');
            $mm->execute(array($m[1]));
            $row = $mm->fetch();
            if ($row && $row['kind'] === 'image') {
                media_make_thumb(MEDIA_DIR . '/' . $m[1], $m[1]);
            }
        } else {
            @unlink($tmp);
        }
    }
    $zip->close();
    return $n;
}

function totp_secret_store_lazy($plain)
{
    require_once dirname(__FILE__) . '/totp.php';
    return strpos((string)$plain, ':') === false ? totp_secret_store($plain) : $plain;
}

function backup_restore_users_settings($data)
{
    $pdo = db();
    $exist = array();
    foreach ($pdo->query('SELECT username FROM users')->fetchAll(PDO::FETCH_COLUMN) as $u) {
        $exist[$u] = 1;
    }
    $ins = $pdo->prepare('INSERT INTO users (username, display_name, password_hash, role, active, must_change_pw, totp_secret, totp_enabled, created_at, updated_at) '
        . 'VALUES (?,?,?,?,?,?,?,?,?,?)');
    foreach ((array)(isset($data['users']) ? $data['users'] : array()) as $u) {
        if (empty($u['username']) || isset($exist[$u['username']]) || empty($u['password_hash'])) {
            continue;
        }
        $ins->execute(array(str_cut($u['username'], 60), str_cut((string)$u['display_name'], 100), $u['password_hash'],
            in_array($u['role'], user_roles(), true) ? $u['role'] : 'gestore', (int)$u['active'] ? 1 : 0, (int)$u['must_change_pw'] ? 1 : 0,
            $u['totp_secret'] ? ((int)setting('db_version', '1') >= 11 ? totp_secret_store_lazy($u['totp_secret']) : $u['totp_secret']) : null, (int)$u['totp_enabled'] ? 1 : 0, $u['created_at'] ? $u['created_at'] : now(), now()));
        if ((int)setting('db_version', '1') >= 12 && !empty($u['email']) && email_problem($u['email']) === '') {
            $pdo->prepare('UPDATE users SET email = ?, email_notify = ? WHERE username = ?')
                ->execute(array($u['email'], isset($u['email_notify']) && !(int)$u['email_notify'] ? 0 : 1, str_cut($u['username'], 60)));
        }
    }
    // impostazioni: tutte tranne quelle che potrebbero chiudere fuori dal nuovo server
    $skip = array('sec_ip_allow' => 1, 'sec_force_https' => 1, 'db_version' => 1, 'fw_cf_only' => 1, 'fw_geo_mode' => 1, 'fw_siege_until' => 1,
        'fw_cf_seen' => 1, 'fw_geo_db_date' => 1, 'fw_geo_try' => 1);
    foreach ((array)(isset($data['settings']) ? $data['settings'] : array()) as $st) {
        if (!isset($st['setting_key']) || isset($skip[$st['setting_key']])) {
            continue;
        }
        setting_save($st['setting_key'], (string)$st['setting_value']);
    }
    if (function_exists('load_settings')) {
        load_settings(true);
    }
}

/* ---------- CSV ---------- */
function csv_columns()
{
    return array('isbn' => 'ISBN', 'titolo' => 'Titolo', 'sottotitolo' => 'Sottotitolo', 'autore' => 'Autore', 'editore' => 'Editore',
        'anno' => 'Anno edizione', 'pagine' => 'Pagine', 'genere' => 'Genere', 'posizione' => 'Posizione', 'lingua' => 'Lingua', 'note' => 'Note');
}

function csv_export()
{
    require_once dirname(__FILE__) . '/extras.php';
    $rows = db()->query('SELECT b.*, c.name AS cat FROM books b LEFT JOIN categories c ON c.id = b.category_id ORDER BY b.title')->fetchAll();
    $taxes = taxonomies_all();
    $fields = array_filter(custom_fields_all(), function ($f) { return (int)$f['in_csv'] === 1; });
    $terms = books_terms_map(array_map(function ($b) { return $b['id']; }, $rows));
    $values = array();
    if ($fields) {
        foreach (db()->query('SELECT book_id, field_id, value FROM book_field_values')->fetchAll() as $v) {
            $values[(int)$v['book_id']][(int)$v['field_id']] = $v['value'];
        }
    }
    $out = fopen('php://temp', 'w+');
    fwrite($out, "\xEF\xBB\xBF"); // BOM: Excel riconosce gli accenti
    $head = array_values(csv_columns());
    foreach ($taxes as $t) {
        $head[] = $t['name'];
    }
    foreach ($fields as $f) {
        $head[] = $f['name'];
    }
    fputcsv($out, $head, ';', '"', '');
    foreach ($rows as $b) {
        $line = array($b['isbn13'], $b['title'], $b['subtitle'], $b['authors'], $b['publisher'], $b['pub_year'], $b['pages'],
            $b['cat'], $b['shelf'], $b['language'], $b['notes']);
        foreach ($taxes as $tid => $t) {
            $line[] = isset($terms[(int)$b['id']][$tid]) ? implode(', ', $terms[(int)$b['id']][$tid]) : '';
        }
        foreach ($fields as $fid => $f) {
            $v = isset($values[(int)$b['id']][$fid]) ? $values[(int)$b['id']][$fid] : '';
            $line[] = $f['type'] === 'bool' ? ($v === '1' ? 'Sì' : '') : ($f['type'] === 'number' ? str_replace('.', ',', $v) : custom_field_display($f, $v));
        }
        fputcsv($out, $line, ';', '"', '');
    }
    rewind($out);
    return stream_get_contents($out);
}

function csv_norm_header($s)
{
    $s = strtolower(trim(preg_replace('/^\xEF\xBB\xBF/', '', $s)));
    $s = str_replace(array('à', 'è', 'é', 'ì', 'ò', 'ù'), array('a', 'e', 'e', 'i', 'o', 'u'), $s);
    $alias = array(
        'isbn' => 'isbn', 'isbn13' => 'isbn', 'isbn 13' => 'isbn', 'codice isbn' => 'isbn', 'ean' => 'isbn',
        'titolo' => 'titolo', 'title' => 'titolo', 'sottotitolo' => 'sottotitolo', 'subtitle' => 'sottotitolo',
        'autore' => 'autore', 'autori' => 'autore', 'author' => 'autore', 'authors' => 'autore',
        'editore' => 'editore', 'casa editrice' => 'editore', 'publisher' => 'editore',
        'anno' => 'anno', 'anno edizione' => 'anno', 'year' => 'anno', 'pagine' => 'pagine', 'numero pagine' => 'pagine', 'pages' => 'pagine',
        'genere' => 'genere', 'categoria' => 'genere', 'category' => 'genere', 'posizione' => 'posizione', 'scaffale' => 'posizione',
        'lingua' => 'lingua', 'language' => 'lingua', 'note' => 'note', 'notes' => 'note',
    );
    return isset($alias[$s]) ? $alias[$s] : '';
}

// Importa libri da CSV (separatore ; o , riconosciuto da solo). Esito: array(inseriti, saltati, errori[])
function csv_import($path, $skip_duplicates = true)
{
    $fh = fopen($path, 'r');
    if (!$fh) {
        throw new Exception('File non leggibile.');
    }
    $first = fgets($fh);
    $delim = substr_count($first, ';') >= substr_count($first, ',') ? ';' : ',';
    rewind($fh);
    $header = fgetcsv($fh, 0, $delim, '"', '');
    require_once dirname(__FILE__) . '/extras.php';
    $map = array();
    $xtax = array();   // colonna => id etichetta
    $xfield = array(); // colonna => campo personalizzato
    $taxnames = array();
    foreach (taxonomies_all() as $tid => $t) {
        $taxnames[str_fold($t['name'])] = $tid;
    }
    $fieldnames = array();
    foreach (custom_fields_all() as $fid => $f) {
        $fieldnames[str_fold($f['name'])] = $f;
    }
    foreach ((array)$header as $i => $hcell) {
        $k = csv_norm_header((string)$hcell);
        $fold = str_fold(preg_replace('/^\xEF\xBB\xBF/', '', (string)$hcell));
        if ($k !== '') {
            $map[$k] = $i;
        } elseif (isset($taxnames[$fold])) {
            $xtax[$i] = $taxnames[$fold];
        } elseif (isset($fieldnames[$fold])) {
            $xfield[$i] = $fieldnames[$fold];
        }
    }
    if (!isset($map['titolo']) && !isset($map['isbn'])) {
        fclose($fh);
        throw new Exception('Il file deve avere almeno la colonna "Titolo" o "ISBN" nella prima riga.');
    }
    $cats = array();
    foreach (categories_all() as $c) {
        $cats[strtolower($c['name'])] = (int)$c['id'];
    }
    $added = 0;
    $skipped = 0;
    $errors = array();
    $line = 1;
    $pdo = db();
    while (($row = fgetcsv($fh, 0, $delim, '"', '')) !== false) {
        $line++;
        if (count(array_filter($row, 'strlen')) === 0) {
            continue;
        }
        $get = function ($k) use ($map, $row) {
            return isset($map[$k], $row[$map[$k]]) ? trim($row[$map[$k]]) : '';
        };
        $catname = $get('genere');
        $catid = '';
        if ($catname !== '') {
            if (!isset($cats[strtolower($catname)])) {
                $pdo->prepare('INSERT INTO categories (name, sort_order) VALUES (?, ?)')->execute(array(str_cut($catname, 100), 500));
                $cats[strtolower($catname)] = (int)$pdo->lastInsertId();
                categories_all(true);
            }
            $catid = $cats[strtolower($catname)];
        }
        $f = book_fields_from_input(array('isbn' => $get('isbn'), 'title' => $get('titolo'), 'subtitle' => $get('sottotitolo'), 'authors' => $get('autore'),
            'publisher' => $get('editore'), 'pub_year' => $get('anno'), 'pages' => $get('pagine'), 'category_id' => $catid,
            'shelf' => $get('posizione'), 'language' => $get('lingua'), 'notes' => $get('note')));
        if ($f['title'] === '' && $f['isbn13']) {
            $f['title'] = 'ISBN ' . $f['isbn13'] . ' (da completare)';
        }
        $err = book_validate($f);
        if ($err !== '') {
            $errors[] = 'Riga ' . $line . ': ' . $err;
            continue;
        }
        if ($skip_duplicates && $f['isbn13'] && books_with_isbn($f['isbn13'])) {
            $skipped++;
            continue;
        }
        $newid = book_insert($f, 'CSV');
        if ($xtax || $xfield) {
            $ins = array('extras_present' => 1, 'tx' => array(), 'tx_new' => array(), 'cf' => array());
            foreach ($xtax as $col => $tid) {
                $ins['tx_new'][$tid] = isset($row[$col]) ? (string)$row[$col] : '';
            }
            foreach ($xfield as $col => $fd) {
                $v = isset($row[$col]) ? trim((string)$row[$col]) : '';
                if ($fd['type'] === 'bool') {
                    $v = in_array(str_fold($v), array('si', 'sì', 'yes', '1', 'x', 'vero', 'true'), true) ? '1' : '';
                }
                $ins['cf'][(int)$fd['id']] = $v;
            }
            book_extras_save($newid, $ins);
        }
        $added++;
    }
    fclose($fh);
    return array($added, $skipped, $errors);
}
