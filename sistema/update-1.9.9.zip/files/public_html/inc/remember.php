<?php
/*
 * "Ricorda questo dispositivo" (1.9.3): dopo un accesso completo (password, verifica in due passaggi o chiave di accesso)
 * il browser riceve un gettone che lo fa rientrare da solo per N giorni (Sicurezza → durata, da 7 a 90).
 *
 * - Il gettone non e' l'identificativo della sessione: e' un segreto a parte, casuale (selettore + 32 byte).
 * - Nel database c'e' solo la sua impronta SHA-256: chi leggesse il database non potrebbe usarla.
 * - Cookie __Host- : solo HTTPS, nessun dominio, invisibile al JavaScript, non inviato da altri siti.
 * - Cambia a ogni uso. Se arriva un gettone vecchio (copiato da qualcuno) il sito dimentica tutti i dispositivi
 *   dell'utente e registra un avviso di sicurezza. Per le richieste in parallelo il gettone precedente vale ancora 2 minuti.
 * - Scade dopo N giorni dalla creazione (non si allunga da solo). Si annulla con il cambio della password,
 *   con "Disconnetti da tutti i dispositivi", con "Esci" su quel dispositivo e dall'elenco in «Il mio account».
 * - Le sezioni delicate del pannello chiedono di nuovo la password a chi e' entrato con un dispositivo ricordato.
 */

function remember_cookie()
{
    return '__Host-ldc_ricorda';
}

function remember_ready()
{
    return (int)setting('db_version', '1') >= 13 && setting('sec_remember_on', '1') === '1' && is_https();
}

function remember_days()
{
    return setting_int('sec_remember_days', 7, 90);
}

function remember_b64u($bin)
{
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

function remember_set_cookie($value, $expires)
{
    if (headers_sent()) {
        return;
    }
    setcookie(remember_cookie(), $value, array('expires' => $expires, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax'));
}

function remember_clear_cookie()
{
    if (isset($_COOKIE[remember_cookie()])) {
        remember_set_cookie('', time() - 3600);
        unset($_COOKIE[remember_cookie()]);
    }
}

// Nome leggibile del dispositivo, ricavato dal browser (solo per l'elenco, non per riconoscerlo)
function remember_device_name($ua)
{
    $ua = (string)$ua;
    $os = preg_match('/iPhone/i', $ua) ? 'iPhone' : (preg_match('/iPad/i', $ua) ? 'iPad' : (preg_match('/Android/i', $ua) ? 'Android'
        : (preg_match('/Macintosh|Mac OS X/i', $ua) ? 'Mac' : (preg_match('/Windows/i', $ua) ? 'Windows' : (preg_match('/CrOS/i', $ua) ? 'Chromebook'
        : (preg_match('/Linux/i', $ua) ? 'Linux' : 'Dispositivo'))))));
    $br = preg_match('/Edg\//i', $ua) ? 'Edge' : (preg_match('/OPR\/|Opera/i', $ua) ? 'Opera' : (preg_match('/Firefox|FxiOS/i', $ua) ? 'Firefox'
        : (preg_match('/SamsungBrowser/i', $ua) ? 'Samsung Internet' : (preg_match('/Chrome|CriOS/i', $ua) ? 'Chrome' : (preg_match('/Safari/i', $ua) ? 'Safari' : 'browser')))));
    return $os . ' · ' . $br;
}

// Crea il gettone per l'utente appena entrato
function remember_create($uid)
{
    if (!remember_ready()) {
        return false;
    }
    $sel = bin2hex(random_bytes(12));
    $val = remember_b64u(random_bytes(32));
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? str_cut($_SERVER['HTTP_USER_AGENT'], 250) : '';
    $exp = time() + remember_days() * 86400;
    db()->prepare('INSERT INTO user_devices (user_id, selector, token_hash, name, user_agent, last_ip, created_at, last_used_at, expires_at) VALUES (?,?,?,?,?,?,?,?,?)')
        ->execute(array((int)$uid, $sel, hash('sha256', $val), remember_device_name($ua), $ua, client_ip(), now(), now(), date('Y-m-d H:i:s', $exp)));
    $_SESSION['device_id'] = (int)db()->lastInsertId();
    remember_set_cookie($sel . ':' . $val, $exp);
    // non si tengono piu' di 20 dispositivi per utente: si dimenticano i meno usati
    $old = db()->prepare('SELECT id FROM user_devices WHERE user_id = ? ORDER BY last_used_at DESC LIMIT 100 OFFSET 20');
    $old->execute(array((int)$uid));
    foreach ($old->fetchAll(PDO::FETCH_COLUMN) as $id) {
        db()->prepare('DELETE FROM user_devices WHERE id = ?')->execute(array((int)$id));
    }
    app_log('dispositivo_ricordato', 'Dispositivo ricordato per ' . remember_days() . ' giorni: ' . remember_device_name($ua), 'info');
    return true;
}

// Rientro automatico con il gettone (chiamata da CONF/bootstrap.php quando non c'e' una sessione)
function remember_try_login()
{
    $raw = isset($_COOKIE[remember_cookie()]) ? (string)$_COOKIE[remember_cookie()] : '';
    if ($raw === '' || is_logged() || (int)setting('db_version', '1') < 13) {
        return false;
    }
    if (!remember_ready() || !preg_match('/^([a-f0-9]{24}):([A-Za-z0-9_\-]{43})$/', $raw, $m)) {
        remember_clear_cookie();
        return false;
    }
    $st = db()->prepare('SELECT * FROM user_devices WHERE selector = ?');
    $st->execute(array($m[1]));
    $d = $st->fetch();
    if (!$d || strtotime($d['expires_at']) < time()) {
        if ($d) {
            db()->prepare('DELETE FROM user_devices WHERE id = ?')->execute(array((int)$d['id']));
        }
        remember_clear_cookie();
        return false;
    }
    $h = hash('sha256', $m[2]);
    $current = hash_equals((string)$d['token_hash'], $h);
    $grace = !$current && $d['prev_hash'] && $d['rotated_at'] && strtotime($d['rotated_at']) > time() - 120 && hash_equals((string)$d['prev_hash'], $h);
    if (!$current && !$grace) {
        // gettone gia' usato: qualcuno ne ha una copia. Si dimenticano tutti i dispositivi dell'utente.
        db()->prepare('DELETE FROM user_devices WHERE user_id = ?')->execute(array((int)$d['user_id']));
        remember_clear_cookie();
        $u = db()->prepare('SELECT username FROM users WHERE id = ?');
        $u->execute(array((int)$d['user_id']));
        app_log('dispositivo_sospetto', 'Gettone di un dispositivo ricordato riusato (' . $d['name'] . '): per sicurezza tutti i dispositivi ricordati sono stati dimenticati', 'alert', (string)$u->fetchColumn());
        return false;
    }
    $st = db()->prepare('SELECT * FROM users WHERE id = ?');
    $st->execute(array((int)$d['user_id']));
    $u = $st->fetch();
    if (!$u || (int)$u['active'] !== 1 || !in_array($u['role'], user_roles(), true)) {
        db()->prepare('DELETE FROM user_devices WHERE id = ?')->execute(array((int)$d['id']));
        remember_clear_cookie();
        return false;
    }
    require_once APP_ROOT . '/inc/auth.php';
    finish_login($u, false, 'con un dispositivo ricordato (' . $d['name'] . ')');
    $_SESSION['via_ricordo'] = 1;
    $_SESSION['device_id'] = (int)$d['id'];
    if ($current) {
        $val = remember_b64u(random_bytes(32));
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? str_cut($_SERVER['HTTP_USER_AGENT'], 250) : '';
        db()->prepare('UPDATE user_devices SET token_hash = ?, prev_hash = ?, rotated_at = ?, last_used_at = ?, last_ip = ?, user_agent = ? WHERE id = ?')
            ->execute(array(hash('sha256', $val), $d['token_hash'], now(), now(), client_ip(), $ua, (int)$d['id']));
        remember_set_cookie($d['selector'] . ':' . $val, strtotime($d['expires_at']));
    }
    return true;
}

// "Esci": il dispositivo viene dimenticato (altrimenti rientrerebbe da solo alla visita successiva)
function remember_forget_current()
{
    if ((int)setting('db_version', '1') < 13) {
        return;
    }
    $raw = isset($_COOKIE[remember_cookie()]) ? (string)$_COOKIE[remember_cookie()] : '';
    if (preg_match('/^([a-f0-9]{24}):/', $raw, $m)) {
        db()->prepare('DELETE FROM user_devices WHERE selector = ?')->execute(array($m[1]));
    } elseif (!empty($_SESSION['device_id'])) {
        db()->prepare('DELETE FROM user_devices WHERE id = ?')->execute(array((int)$_SESSION['device_id']));
    }
    remember_clear_cookie();
}

function remember_forget_user($uid)
{
    if ((int)setting('db_version', '1') >= 13) {
        db()->prepare('DELETE FROM user_devices WHERE user_id = ?')->execute(array((int)$uid));
    }
}

function remember_list($uid)
{
    if ((int)setting('db_version', '1') < 13) {
        return array();
    }
    $st = db()->prepare('SELECT * FROM user_devices WHERE user_id = ? AND expires_at > ? ORDER BY last_used_at DESC');
    $st->execute(array((int)$uid, now()));
    return $st->fetchAll();
}

/*
 * Sezioni delicate: a chi e' entrato con un dispositivo ricordato si chiede la password (vale 30 minuti).
 */
function remember_needs_reauth()
{
    return !empty($_SESSION['via_ricordo']) && time() - (int)(isset($_SESSION['pw_ok_at']) ? $_SESSION['pw_ok_at'] : 0) > 1800;
}

function remember_sensitive_sections()
{
    return array('aggiornamento', 'plugin', 'pubblica', 'utenti', 'sicurezza', 'firewall', 'blocchi', 'controllo', 'destinazioni', 'dati');
}
