<?= settings_form_open('testi') ?>
  <div class="ct"><?= icon('edit', 18) ?> Testi del sito</div>
  <?php foreach (setting_defaults() as $k => $d): if ($d[0] !== 'testi') { continue; } ?>
    <?= render_setting($k) ?>
  <?php endforeach; ?>
  <button class="btn primary" type="submit">Salva i testi</button>
</form>
<form method="post" data-confirm="Riportare tutti i testi ai valori predefiniti?">
  <?= csrf_field() ?><input type="hidden" name="action" value="reset_group"><input type="hidden" name="group" value="testi">
  <button class="btn link" type="submit">Ripristina i testi predefiniti</button>
</form>
