<?php
/*
 * Controllo di sicurezza: lo stato del sito con i consigli per migliorarlo.
 * Le date di fine supporto di PHP sono quelle ufficiali di php.net (aggiornate con ogni versione della Libreria).
 */

// versione => fine degli aggiornamenti di sicurezza
function php_support_table()
{
    return array(
        '7.4' => '2022-11-28', '8.0' => '2023-11-26', '8.1' => '2025-12-31', '8.2' => '2026-12-31',
        '8.3' => '2027-12-31', '8.4' => '2028-12-31', '8.5' => '2029-12-31',
    );
}

// array(livello ok|warn|bad, testo, data di fine supporto o '')
function php_support_status($version = PHP_VERSION)
{
    $mm = implode('.', array_slice(explode('.', $version), 0, 2));
    $t = php_support_table();
    if (!isset($t[$mm])) {
        return version_compare($mm, '8.5', '>') ? array('ok', 'PHP ' . $version . ' è più recente di quelle conosciute da questa versione del sito.', '')
            : array('bad', 'PHP ' . $version . ' non riceve più aggiornamenti di sicurezza.', '');
    }
    $end = strtotime($t[$mm] . ' 23:59:59');
    $d = date('d/m/Y', $end);
    if ($end < time()) {
        return array('bad', 'PHP ' . $mm . ' non riceve più aggiornamenti di sicurezza dal ' . $d . ': aggiorna PHP (consigliati 8.3 o 8.4).', $t[$mm]);
    }
    if ($end < time() + 183 * 86400) {
        return array('warn', 'PHP ' . $mm . ' riceve aggiornamenti di sicurezza solo fino al ' . $d . ': prepara il passaggio a una versione più recente.', $t[$mm]);
    }
    return array('ok', 'PHP ' . $mm . ' riceve aggiornamenti di sicurezza fino al ' . $d . '.', $t[$mm]);
}

function security_checks()
{
    $pdo = db();
    $c = array();
    $add = function ($lvl, $area, $title, $detail, $link = '') use (&$c) {
        $c[] = array('lvl' => $lvl, 'area' => $area, 'title' => $title, 'detail' => $detail, 'link' => $link);
    };
    // --- Server
    $php = php_support_status();
    $add($php[0], 'Server', 'Versione di PHP (' . PHP_VERSION . ')', $php[1], 'sistema');
    $add(is_https() ? 'ok' : 'bad', 'Server', 'Connessione cifrata (HTTPS)', is_https() ? 'Il sito è aperto in HTTPS: password e cookie viaggiano cifrati.'
        : 'Il sito è aperto senza HTTPS: chi è sulla stessa rete può leggere le password. Usa l\'indirizzo https://.', 'sicurezza');
    if (is_https()) {
        $add(setting('sec_force_https') === '1' ? 'ok' : 'warn', 'Server', 'HTTPS obbligatorio', setting('sec_force_https') === '1'
            ? 'Chi apre il sito in http viene portato su https.' : 'Attiva "HTTPS obbligatorio" in Sicurezza e accessi.', 'sicurezza');
    }
    $add(!APP_DEBUG && !ini_get('display_errors') ? 'ok' : 'warn', 'Server', 'Messaggi di errore tecnici nascosti',
        !APP_DEBUG && !ini_get('display_errors') ? 'I dettagli degli errori non vengono mostrati ai visitatori.' : 'La modalità debug o display_errors è attiva: va usata solo per le prove.', 'sistema');
    $inside = strpos(realpath(DATA_DIR) . '/', realpath(APP_ROOT) . '/') === 0;
    $add($inside ? 'bad' : 'ok', 'Server', 'Cartella dei dati fuori dalla parte pubblica', $inside ? 'La cartella data è dentro public_html: spostala accanto (vedi la guida).'
        : 'Database, chiavi e backup stanno fuori dalla cartella pubblicata dal web server.');
    $key = DATA_DIR . '/secret.key';
    if (is_file($key) && DIRECTORY_SEPARATOR === '/') {
        $perm = fileperms($key) & 0777;
        $add($perm & 0077 ? 'warn' : 'ok', 'Server', 'Permessi della chiave segreta', $perm & 0077 ? 'data/secret.key è leggibile da altri utenti del server (permessi ' . decoct($perm) . '): imposta 600.'
            : 'data/secret.key è leggibile solo dal web server.');
    }
    $add(ini_get('allow_url_include') ? 'bad' : 'ok', 'Server', 'allow_url_include spento', ini_get('allow_url_include') ? 'Spegni allow_url_include nella configurazione di PHP.' : 'PHP non può eseguire codice preso da internet.');
    $add(defined('PASSWORD_ARGON2ID') ? 'ok' : 'warn', 'Server', 'Cifratura delle password', defined('PASSWORD_ARGON2ID')
        ? 'Le password sono protette con Argon2id (lo standard attuale).' : 'Il server non ha Argon2id: le password usano bcrypt (sicuro, ma meno moderno).');
    $add(function_exists('sodium_crypto_sign_verify_detached') ? 'ok' : 'warn', 'Server', 'Estensione sodium', function_exists('sodium_crypto_sign_verify_detached')
        ? 'Disponibile: firme dei plugin e degli aggiornamenti, chiavi di accesso Ed25519.' : 'Manca: senza, i plugin non si possono installare.');
    // --- Accessi
    $u0 = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE username = 'admin' AND must_change_pw = 1")->fetchColumn();
    if ($u0) {
        $add('bad', 'Accessi', 'Password iniziale di "admin"', 'La password iniziale non è ancora stata cambiata.', 'utenti');
    }
    $nofa = $pdo->query("SELECT username FROM users WHERE role = 'admin' AND active = 1 AND totp_enabled = 0")->fetchAll(PDO::FETCH_COLUMN);
    $add($nofa ? 'warn' : 'ok', 'Accessi', 'Verifica in due passaggi degli Admin', $nofa ? 'Senza verifica in due passaggi: ' . implode(', ', $nofa) . '.' : 'Tutti gli Admin usano la verifica in due passaggi.', 'utenti');
    $min = setting_int('sec_min_password', 6, 64);
    $add($min >= 10 ? 'ok' : 'warn', 'Accessi', 'Lunghezza minima delle password', $min >= 10 ? 'Almeno ' . $min . ' caratteri.' : 'Ora è ' . $min . ': consigliati almeno 10 caratteri.', 'sicurezza');
    $idle = setting_int('sec_idle_minutes', 5, 10080);
    $add($idle <= 240 ? 'ok' : 'warn', 'Accessi', 'Disconnessione per inattività', 'Dopo ' . $idle . ' minuti' . ($idle <= 240 ? '.' : ': per un sito raggiungibile da internet sono consigliati al massimo 240.'), 'sicurezza');
    if ((int)setting('db_version', '1') >= 13) {
        $rd = setting_int('sec_remember_days', 7, 90);
        $ron = setting('sec_remember_on', '1') === '1';
        $add(!$ron || $rd <= 60 ? 'ok' : 'warn', 'Accessi', 'Dispositivi ricordati', !$ron ? 'Spento: si entra sempre con password o chiave di accesso.'
            : 'Un dispositivo resta ricordato ' . $rd . ' giorni' . ($rd <= 60 ? '; le sezioni delicate chiedono comunque la password.' : ': per un sito raggiungibile da internet sono consigliati al massimo 60.'), 'sicurezza');
    }
    $fw = function_exists('fw_enabled') && fw_enabled();
    $add($fw ? 'ok' : 'warn', 'Accessi', 'Firewall', $fw ? 'Attivo: blocca chi prova troppe password e gli indirizzi sospetti.' : 'Il firewall è spento.', 'firewall');
    // --- Programmi
    require_once dirname(__FILE__) . '/firma.php';
    $pub = firma_chiave_pubblica();
    $add($pub ? 'ok' : 'warn', 'Programmi', 'Firma dell\'autore', $pub ? 'Il sito installa solo aggiornamenti e plugin firmati da ' . $pub['autore'] . ' (impronta ' . firma_impronta_leggibile($pub['impronta']) . ').'
        : 'Nessuna chiave dell\'autore: gli aggiornamenti non vengono controllati con la firma e i plugin non si possono installare.', 'plugin');
    if (plugins_ready()) {
        require_once dirname(__FILE__) . '/plugins.php';
        $bad = array();
        foreach (plugins_rows() as $r) {
            if ($r['status'] !== 'ok') {
                $bad[] = $r['name'];
            }
        }
        $add($bad ? 'bad' : 'ok', 'Programmi', 'Integrità dei plugin', $bad ? 'Plugin bloccati o in errore: ' . implode(', ', $bad) . '.' : 'Nessun plugin con problemi.', 'plugin');
    }
    // --- Dati
    require_once dirname(__FILE__) . '/data_tools.php';
    $bk = array_values(array_filter(backup_list(), function ($b) { return strpos($b['name'], 'prima') === false; }));
    $age = $bk ? (time() - $bk[0]['time']) / 86400 : 9999;
    $add($age <= 7 ? 'ok' : ($age <= 30 ? 'warn' : 'bad'), 'Dati', 'Backup recente', $bk ? 'Ultimo backup: ' . date('d/m/Y H:i', $bk[0]['time']) . '.' : 'Nessun backup.', 'dati');
    $remote = (int)setting('db_version', '1') >= 5 ? (int)$pdo->query('SELECT COUNT(*) FROM backup_targets WHERE active = 1')->fetchColumn() : 0;
    $add($remote ? 'ok' : 'warn', 'Dati', 'Copia dei backup fuori dal server', $remote ? $remote . ' destinazioni attive.' : 'I backup restano solo su questo server: aggiungi una destinazione (NAS, Nextcloud, Drive…).', 'destinazioni');
    return $c;
}
