<?php
$cats = db()->query('SELECT c.id, c.name, c.sort_order, COUNT(b.id) AS n FROM categories c LEFT JOIN books b ON b.category_id = c.id '
    . 'GROUP BY c.id, c.name, c.sort_order ORDER BY c.sort_order, c.name')->fetchAll();
$none = (int)db()->query('SELECT COUNT(*) FROM books WHERE category_id IS NULL')->fetchColumn();
?>
<div class="adm-grid2 wide-left">
  <div class="card">
    <div class="ct">Generi della libreria</div>
    <p class="sub">Il numero a sinistra decide l'ordine negli elenchi. "Unisci" sposta tutti i libri su un altro genere ed elimina questo.
      <?php if ($none): ?><a class="link" href="gestione.php?sez=libri&amp;cat=nessuno"><?= $none ?> libri senza genere</a><?php endif; ?></p>
    <table class="tbl terms">
      <thead><tr><th class="num">Ordine</th><th>Nome</th><th class="num">Libri</th><th>Unisci in</th><th class="act"></th></tr></thead>
      <tbody>
      <?php foreach ($cats as $c): $fid = 'cf' . (int)$c['id']; ?>
        <tr>
          <td class="num"><input class="input num sm" form="<?= $fid ?>" name="sort_order" value="<?= (int)$c['sort_order'] ?>" inputmode="numeric" aria-label="Ordine"></td>
          <td><input class="input sm" form="<?= $fid ?>" name="name" value="<?= h($c['name']) ?>" maxlength="100" aria-label="Nome"></td>
          <td class="num"><a class="link" href="gestione.php?sez=libri&amp;cat=<?= (int)$c['id'] ?>"><?= (int)$c['n'] ?></a></td>
          <td>
            <form method="post" class="inline" data-confirm="Unire &quot;<?= h($c['name']) ?>&quot; al genere scelto? I <?= (int)$c['n'] ?> libri verranno spostati.">
              <?= csrf_field() ?><input type="hidden" name="action" value="cat_merge"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <select class="input sm" name="target" aria-label="Unisci in"><option value="">—</option>
                <?php foreach ($cats as $o): if ($o['id'] === $c['id']) { continue; } ?><option value="<?= (int)$o['id'] ?>"><?= h($o['name']) ?></option><?php endforeach; ?>
              </select>
              <button class="iconbtn sm" type="submit" title="Unisci"><?= admin_icon('merge', 15) ?></button>
            </form>
          </td>
          <td class="act">
            <form method="post" id="<?= $fid ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="cat_save"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="iconbtn sm" type="submit" title="Salva"><?= icon('check', 15) ?></button></form>
            <form method="post" class="inline" data-confirm="Eliminare il genere &quot;<?= h($c['name']) ?>&quot;? I <?= (int)$c['n'] ?> libri resteranno senza genere.">
              <?= csrf_field() ?><input type="hidden" name="action" value="cat_del"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="iconbtn sm danger" type="submit" title="Elimina"><?= icon('trash', 15) ?></button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div>
    <form method="post" class="card stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="cat_add">
      <div class="ct"><?= icon('plus', 18) ?> Nuovo genere</div>
      <div class="cat-form">
        <input class="input num" name="sort_order" value="500" inputmode="numeric" aria-label="Ordine">
        <input class="input" name="name" maxlength="100" placeholder="es. Cucina" required aria-label="Nome">
      </div>
      <button class="btn primary" type="submit">Aggiungi genere</button>
    </form>
    <form method="post" class="card stack">
      <?= csrf_field() ?><input type="hidden" name="action" value="cat_bulk">
      <div class="ct">Aggiungi più generi insieme</div>
      <textarea class="input" name="names" rows="5" required placeholder="Uno per riga&#10;es. Viaggi&#10;Arte&#10;Cucina" aria-label="Generi"></textarea>
      <button class="btn ghost" type="submit">Aggiungi tutti</button>
    </form>
    <p class="hint">Ti servono altri modi per classificare i libri (collana, formato, scaffale…)? Crea un'etichetta in
      <a class="link" href="gestione.php?sez=etichette">Gestisci le etichette</a>.</p>
  </div>
</div>
