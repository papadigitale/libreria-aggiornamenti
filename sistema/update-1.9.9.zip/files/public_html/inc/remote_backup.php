<?php
/*
 * Copia dei backup su altre destinazioni: cartella (anche condivisione SAMBA montata), SFTP, FTP/FTPES,
 * WebDAV (Nextcloud), Google Drive, Dropbox. Le password e i token sono salvati cifrati
 * (chiave in data/secret.key, che non finisce nei backup).
 * Ogni destinazione tiene solo gli ultimi N backup (stesso numero dei backup automatici).
 */

// Indirizzi dei servizi (modificabili solo per le prove)
function rb_url($what)
{
    $map = array(
        'g_oauth' => array('LIBRERIA_TEST_GOOGLE_OAUTH', 'https://oauth2.googleapis.com'),
        'g_api' => array('LIBRERIA_TEST_GOOGLE_API', 'https://www.googleapis.com'),
        'd_auth' => array('LIBRERIA_TEST_DROPBOX_WWW', 'https://www.dropbox.com'),
        'd_api' => array('LIBRERIA_TEST_DROPBOX_API', 'https://api.dropboxapi.com'),
        'd_content' => array('LIBRERIA_TEST_DROPBOX_CONTENT', 'https://content.dropboxapi.com'),
    );
    $v = getenv($map[$what][0]);
    return $v ? rtrim($v, '/') : $map[$what][1];
}

function rb_types()
{
    return array(
        'folder' => 'Cartella del server / condivisione SAMBA montata',
        'sftp' => 'SFTP (SSH)',
        'ftp' => 'FTP',
        'ftpes' => 'FTP con TLS (FTPES)',
        'webdav' => 'Nextcloud / WebDAV',
        'gdrive' => 'Google Drive',
        'dropbox' => 'Dropbox',
    );
}

// Campi segreti (salvati cifrati) per tipo
function rb_secret_fields()
{
    return array('pass', 'key', 'passphrase', 'client_secret', 'app_secret', 'refresh_token');
}

/* ---------------- Cifratura dei segreti (vedi inc/crypto.php) ---------------- */
require_once dirname(__FILE__) . '/crypto.php';

function rb_key()
{
    return sec_key();
}

// il contesto resta "generico" per leggere anche i segreti salvati dalle versioni precedenti
function rb_encrypt($plain)
{
    return sec_encrypt($plain, 'generico');
}

function rb_decrypt($stored)
{
    return sec_decrypt($stored, 'generico');
}

/* ---------------- Destinazioni ---------------- */
function rb_ready()
{
    return (int)setting('db_version', '1') >= 5;
}

function rb_targets($only_active = false)
{
    if (!rb_ready()) {
        return array();
    }
    $out = array();
    foreach (db()->query('SELECT * FROM backup_targets' . ($only_active ? ' WHERE active = 1' : '') . ' ORDER BY id')->fetchAll() as $t) {
        $t['cfg'] = json_decode((string)$t['config'], true);
        if (!is_array($t['cfg'])) {
            $t['cfg'] = array();
        }
        $out[(int)$t['id']] = $t;
    }
    return $out;
}

function rb_target($id)
{
    $all = rb_targets();
    return isset($all[(int)$id]) ? $all[(int)$id] : null;
}

function rb_cfg($t, $k)
{
    if (!isset($t['cfg'][$k])) {
        return '';
    }
    return in_array($k, rb_secret_fields(), true) ? rb_decrypt($t['cfg'][$k]) : (string)$t['cfg'][$k];
}

function rb_save_cfg($id, $cfg)
{
    db()->prepare('UPDATE backup_targets SET config = ? WHERE id = ?')->execute(array(json_encode($cfg), (int)$id));
}

function rb_set_status($id, $ok, $msg)
{
    db()->prepare('UPDATE backup_targets SET last_status = ?, last_message = ?, last_at = ? WHERE id = ?')
        ->execute(array($ok ? 'ok' : 'errore', str_cut($msg, 500), now(), (int)$id));
}

function rb_is_backup_name($n)
{
    return (bool)preg_match('/^libreria_\d{8}_\d{6}(_[a-z0-9\-]+)*\.(zip|json)$/', $n);
}

/* ---------------- curl ---------------- */
function rb_curl($url, $opts = array(), $external = false)
{
    if (!function_exists('curl_init')) {
        throw new Exception('L\'estensione curl di PHP non è attiva.');
    }
    $ch = curl_init($url);
    $base = array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 20,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_USERAGENT => 'LibreriaDiCasa/' . APP_VERSION,
    );
    if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
        $base[CURLOPT_CAINFO] = CA_BUNDLE;
    }
    if ($external && defined('HTTP_PROXY_URL') && HTTP_PROXY_URL !== '') {
        $base[CURLOPT_PROXY] = HTTP_PROXY_URL;
    }
    curl_setopt_array($ch, $base);
    curl_setopt_array($ch, $opts);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = curl_error($ch);
    $errno = curl_errno($ch);
    curl_done($ch);
    return array('code' => $code, 'body' => $body === false ? '' : $body, 'error' => $errno ? $err : '', 'errno' => $errno);
}

function rb_curl_has($proto)
{
    $v = function_exists('curl_version') ? curl_version() : array('protocols' => array());
    return in_array($proto, $v['protocols'], true);
}

function rb_fail($r, $what)
{
    if ($r['error'] !== '') {
        throw new Exception($what . ': ' . $r['error']);
    }
    $msg = trim(strip_tags(is_string($r['body']) ? $r['body'] : ''));
    $j = json_decode((string)$r['body'], true);
    if (is_array($j)) {
        if (isset($j['error_description'])) {
            $msg = $j['error_description'];
        } elseif (isset($j['error']['message'])) {
            $msg = $j['error']['message'];
        } elseif (isset($j['error_summary'])) {
            $msg = $j['error_summary'];
        } elseif (isset($j['error']) && is_string($j['error'])) {
            $msg = $j['error'];
        }
    }
    throw new Exception($what . ' (risposta ' . $r['code'] . ($msg !== '' ? ': ' . str_cut($msg, 200) : '') . ')');
}

/* ================= Driver ================= */
/*
 * Ogni tipo offre: put($t, $local_path, $name), names($t) -> elenco dei nomi dei backup, del($t, $name)
 */

// ---- Cartella (anche condivisione SAMBA montata sul server, o \\server\cartella su Windows)
function rb_folder_dir($t)
{
    $d = rtrim(rb_cfg($t, 'path'), "/\\");
    if ($d === '') {
        throw new Exception('Indica la cartella.');
    }
    if (!is_dir($d)) {
        throw new Exception('La cartella ' . $d . ' non esiste o non è raggiungibile (la condivisione è montata?).');
    }
    if (!is_writable($d)) {
        throw new Exception('Il sito non può scrivere nella cartella ' . $d . ' (controlla i permessi).');
    }
    return $d;
}

function rb_folder_put($t, $path, $name)
{
    $d = rb_folder_dir($t);
    if (!@copy($path, $d . DIRECTORY_SEPARATOR . $name . '.parziale') || !@rename($d . DIRECTORY_SEPARATOR . $name . '.parziale', $d . DIRECTORY_SEPARATOR . $name)) {
        @unlink($d . DIRECTORY_SEPARATOR . $name . '.parziale');
        throw new Exception('Copia nella cartella ' . $d . ' non riuscita (spazio o permessi).');
    }
}

function rb_folder_names($t)
{
    return array_values(array_filter(scandir(rb_folder_dir($t)), 'rb_is_backup_name'));
}

function rb_folder_del($t, $name)
{
    @unlink(rb_folder_dir($t) . DIRECTORY_SEPARATOR . $name);
}

// ---- SFTP / FTP / FTPES
function rb_ftp_base($t)
{
    $type = $t['type'];
    $host = trim(rb_cfg($t, 'host'));
    if ($host === '' || !preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $host)) {
        throw new Exception('Indica l\'indirizzo del server.');
    }
    $port = (int)rb_cfg($t, 'port');
    if ($port <= 0) {
        $port = $type === 'sftp' ? 22 : 21;
    }
    $dir = trim(str_replace('\\', '/', rb_cfg($t, 'dir')), '/');
    $proto = $type === 'sftp' ? 'sftp' : 'ftp';
    if (!rb_curl_has($proto)) {
        throw new Exception('Il curl di questo server non supporta ' . strtoupper($proto) . '.');
    }
    $abs = substr(rb_cfg($t, 'dir'), 0, 1) === '/';
    // SFTP: i percorsi senza "/" iniziale partono dalla cartella home dell'utente
    $path = $proto === 'sftp' ? ($abs ? '/' . $dir : '/~/' . $dir) : '/' . $dir;
    $path = rtrim($path, '/') . '/';
    return array('url' => $proto . '://' . $host . ':' . $port . str_replace('%2F', '/', rawurlencode($path)), 'path' => $path, 'proto' => $proto);
}

function rb_ftp_opts($t)
{
    $o = array(CURLOPT_USERPWD => rb_cfg($t, 'user') . ':' . rb_cfg($t, 'pass'));
    if ($t['type'] === 'ftpes') {
        $o[CURLOPT_USE_SSL] = CURLUSESSL_ALL;
        if (rb_cfg($t, 'insecure') === '1') {
            $o[CURLOPT_SSL_VERIFYPEER] = false;
            $o[CURLOPT_SSL_VERIFYHOST] = 0;
        }
    }
    if ($t['type'] === 'sftp') {
        $key = rb_cfg($t, 'key');
        if (defined('CURLOPT_SSH_AUTH_TYPES')) {
            $o[CURLOPT_SSH_AUTH_TYPES] = $key !== '' ? CURLSSH_AUTH_PUBLICKEY : (CURLSSH_AUTH_PASSWORD | CURLSSH_AUTH_KEYBOARD);
        }
        if ($key !== '') {
            $kf = DATA_DIR . '/tmp-sftp-' . substr(md5(uniqid('', true)), 0, 8);
            file_put_contents($kf, $key);
            @chmod($kf, 0600);
            $GLOBALS['RB_TMP_FILES'][] = $kf;
            $o[CURLOPT_SSH_PRIVATE_KEYFILE] = $kf;
            if (rb_cfg($t, 'passphrase') !== '') {
                $o[CURLOPT_KEYPASSWD] = rb_cfg($t, 'passphrase');
            }
            unset($o[CURLOPT_USERPWD]);
            $o[CURLOPT_USERNAME] = rb_cfg($t, 'user');
        }
        $fp = trim(rb_cfg($t, 'fingerprint'));
        if ($fp !== '') {
            if (preg_match('/^SHA256:(.+)$/', $fp, $m) && defined('CURLOPT_SSH_HOST_PUBLIC_KEY_SHA256')) {
                $o[CURLOPT_SSH_HOST_PUBLIC_KEY_SHA256] = rtrim($m[1], '=');
            } elseif (preg_match('/^(MD5:)?([0-9a-f:]{47})$/i', $fp, $m)) {
                $o[CURLOPT_SSH_HOST_PUBLIC_KEY_MD5] = strtolower(str_replace(':', '', $m[2]));
            }
        }
    }
    return $o;
}

function rb_cleanup_tmp()
{
    foreach (isset($GLOBALS['RB_TMP_FILES']) ? $GLOBALS['RB_TMP_FILES'] : array() as $f) {
        @unlink($f);
    }
    $GLOBALS['RB_TMP_FILES'] = array();
}

function rb_ftp_put($t, $path, $name)
{
    $b = rb_ftp_base($t);
    $fh = fopen($path, 'rb');
    $r = rb_curl($b['url'] . rawurlencode($name), rb_ftp_opts($t) + array(
        CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => filesize($path), CURLOPT_FTP_CREATE_MISSING_DIRS => true));
    fclose($fh);
    rb_cleanup_tmp();
    if ($r['errno']) {
        rb_fail($r, 'Invio non riuscito');
    }
}

function rb_ftp_names($t)
{
    $b = rb_ftp_base($t);
    $r = rb_curl($b['url'], rb_ftp_opts($t) + array(CURLOPT_DIRLISTONLY => true));
    rb_cleanup_tmp();
    if ($r['errno']) {
        rb_fail($r, 'Elenco dei file non riuscito');
    }
    $out = array();
    foreach (preg_split('/\r?\n/', (string)$r['body']) as $l) {
        $l = basename(trim($l));
        if (rb_is_backup_name($l)) {
            $out[] = $l;
        }
    }
    return $out;
}

function rb_ftp_del($t, $name)
{
    if (!rb_is_backup_name($name)) {
        return;
    }
    $b = rb_ftp_base($t);
    if ($b['proto'] === 'sftp') {
        // percorso assoluto, oppure relativo alla home ("/~/cartella/" -> "cartella/")
        $rel = substr($b['path'], 0, 3) === '/~/' ? substr($b['path'], 3) : $b['path'];
        $cmd = 'rm "' . $rel . $name . '"';
    } else {
        $cmd = 'DELE ' . $b['path'] . $name; // percorso completo: curl invia il comando prima di entrare nella cartella
    }
    $r = rb_curl($b['url'], rb_ftp_opts($t) + array(CURLOPT_NOBODY => true, CURLOPT_QUOTE => array($cmd)));
    rb_cleanup_tmp();
    if ($r['errno']) {
        rb_fail($r, 'Eliminazione del vecchio backup ' . $name . ' non riuscita');
    }
}

// ---- WebDAV / Nextcloud
function rb_dav_base($t)
{
    $u = trim(rb_cfg($t, 'url'));
    if (!preg_match('#^https?://#i', $u)) {
        throw new Exception('Indica l\'indirizzo WebDAV completo (inizia con https://).');
    }
    return rtrim($u, '/') . '/';
}

function rb_dav_opts($t)
{
    $o = array(CURLOPT_USERPWD => rb_cfg($t, 'user') . ':' . rb_cfg($t, 'pass'), CURLOPT_HTTPAUTH => CURLAUTH_BASIC);
    if (rb_cfg($t, 'insecure') === '1') {
        $o[CURLOPT_SSL_VERIFYPEER] = false;
        $o[CURLOPT_SSL_VERIFYHOST] = 0;
    }
    return $o;
}

function rb_dav_put($t, $path, $name)
{
    $base = rb_dav_base($t);
    $r = rb_curl($base, rb_dav_opts($t) + array(CURLOPT_CUSTOMREQUEST => 'MKCOL'));
    if ($r['errno'] || $r['code'] === 401) {
        rb_fail($r, $r['code'] === 401 ? 'Utente o password non accettati' : 'Collegamento non riuscito');
    }
    $fh = fopen($path, 'rb');
    $r = rb_curl($base . rawurlencode($name), rb_dav_opts($t) + array(CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => filesize($path)));
    fclose($fh);
    if ($r['errno'] || $r['code'] < 200 || $r['code'] >= 300) {
        rb_fail($r, 'Invio non riuscito');
    }
}

function rb_dav_names($t)
{
    $r = rb_curl(rb_dav_base($t), rb_dav_opts($t) + array(CURLOPT_CUSTOMREQUEST => 'PROPFIND',
        CURLOPT_HTTPHEADER => array('Depth: 1', 'Content-Type: application/xml'),
        CURLOPT_POSTFIELDS => '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:getlastmodified/></d:prop></d:propfind>'));
    if ($r['errno'] || $r['code'] !== 207) {
        rb_fail($r, 'Elenco dei file non riuscito');
    }
    $out = array();
    if (preg_match_all('#<(?:[a-z0-9]+:)?href>([^<]+)</(?:[a-z0-9]+:)?href>#i', $r['body'], $m)) {
        foreach ($m[1] as $href) {
            $n = rawurldecode(basename(rtrim(html_entity_decode($href), '/')));
            if (rb_is_backup_name($n)) {
                $out[] = $n;
            }
        }
    }
    return $out;
}

function rb_dav_del($t, $name)
{
    if (!rb_is_backup_name($name)) {
        return;
    }
    $r = rb_curl(rb_dav_base($t) . rawurlencode($name), rb_dav_opts($t) + array(CURLOPT_CUSTOMREQUEST => 'DELETE'));
    if ($r['errno'] || ($r['code'] >= 300 && $r['code'] !== 404)) {
        rb_fail($r, 'Eliminazione del vecchio backup ' . $name . ' non riuscita');
    }
}

// ---- Google Drive (collegamento con codice, "dispositivi con input limitato"; permesso solo sui file creati dal sito)
function rb_gdrive_token($t)
{
    $rt = rb_cfg($t, 'refresh_token');
    if ($rt === '') {
        throw new Exception('Account Google non ancora collegato.');
    }
    $r = rb_curl(rb_url('g_oauth') . '/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => rb_cfg($t, 'client_id'), 'client_secret' => rb_cfg($t, 'client_secret'), 'refresh_token' => $rt, 'grant_type' => 'refresh_token'))), true);
    $j = json_decode((string)$r['body'], true);
    if (!isset($j['access_token'])) {
        rb_fail($r, 'Accesso a Google non riuscito (prova a ricollegare l\'account)');
    }
    return $j['access_token'];
}

function rb_gdrive_api($tok, $method, $url, $body = null, $headers = array())
{
    $o = array(CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => array_merge(array('Authorization: Bearer ' . $tok), $headers));
    if ($body !== null) {
        $o[CURLOPT_POSTFIELDS] = $body;
    }
    return rb_curl($url, $o, true);
}

function rb_gdrive_folder($t, $tok)
{
    $fid = rb_cfg($t, 'folder_id');
    if ($fid !== '') {
        $r = rb_gdrive_api($tok, 'GET', rb_url('g_api') . '/drive/v3/files/' . rawurlencode($fid) . '?fields=id,trashed');
        $j = json_decode((string)$r['body'], true);
        if ($r['code'] === 200 && empty($j['trashed'])) {
            return $fid;
        }
    }
    $name = rb_cfg($t, 'folder') !== '' ? rb_cfg($t, 'folder') : 'Libreria di Casa - backup';
    $r = rb_gdrive_api($tok, 'POST', rb_url('g_api') . '/drive/v3/files', json_encode(array('name' => $name, 'mimeType' => 'application/vnd.google-apps.folder')),
        array('Content-Type: application/json'));
    $j = json_decode((string)$r['body'], true);
    if (!isset($j['id'])) {
        rb_fail($r, 'Creazione della cartella su Google Drive non riuscita');
    }
    $cfg = $t['cfg'];
    $cfg['folder_id'] = $j['id'];
    rb_save_cfg($t['id'], $cfg);
    return $j['id'];
}

function rb_gdrive_put($t, $path, $name)
{
    $tok = rb_gdrive_token($t);
    $folder = rb_gdrive_folder($t, $tok);
    $size = filesize($path);
    $r = rb_curl(rb_url('g_api') . '/upload/drive/v3/files?uploadType=resumable', array(CURLOPT_POST => true, CURLOPT_HEADER => true,
        CURLOPT_POSTFIELDS => json_encode(array('name' => $name, 'parents' => array($folder))),
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: application/json; charset=UTF-8',
            'X-Upload-Content-Type: application/zip', 'X-Upload-Content-Length: ' . $size)), true);
    if ($r['code'] !== 200 || !preg_match('/^location:\s*(\S+)/mi', $r['body'], $m)) {
        rb_fail($r, 'Avvio del caricamento su Google Drive non riuscito');
    }
    $fh = fopen($path, 'rb');
    $r = rb_curl(trim($m[1]), array(CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => $size,
        CURLOPT_HTTPHEADER => array('Content-Type: application/zip')), true);
    fclose($fh);
    if ($r['code'] !== 200 && $r['code'] !== 201) {
        rb_fail($r, 'Caricamento su Google Drive non riuscito');
    }
}

function rb_gdrive_list($t)
{
    $tok = rb_gdrive_token($t);
    $folder = rb_gdrive_folder($t, $tok);
    $q = "'" . str_replace("'", "\\'", $folder) . "' in parents and trashed = false";
    $r = rb_gdrive_api($tok, 'GET', rb_url('g_api') . '/drive/v3/files?pageSize=200&fields=files(id,name)&q=' . rawurlencode($q));
    $j = json_decode((string)$r['body'], true);
    if ($r['code'] !== 200 || !isset($j['files'])) {
        rb_fail($r, 'Elenco dei file su Google Drive non riuscito');
    }
    $out = array();
    foreach ($j['files'] as $f) {
        if (rb_is_backup_name($f['name'])) {
            $out[$f['name']] = $f['id'];
        }
    }
    return array($tok, $out);
}

function rb_gdrive_names($t)
{
    $l = rb_gdrive_list($t);
    return array_keys($l[1]);
}

function rb_gdrive_del($t, $name)
{
    $l = rb_gdrive_list($t);
    if (isset($l[1][$name])) {
        $r = rb_gdrive_api($l[0], 'DELETE', rb_url('g_api') . '/drive/v3/files/' . rawurlencode($l[1][$name]));
        if ($r['code'] !== 204 && $r['code'] !== 200 && $r['code'] !== 404) {
            rb_fail($r, 'Eliminazione del vecchio backup su Google Drive non riuscita');
        }
    }
}

// Avvio del collegamento: Google restituisce un codice da inserire su google.com/device
function rb_gdrive_start($t)
{
    if (rb_cfg($t, 'client_id') === '' || rb_cfg($t, 'client_secret') === '') {
        throw new Exception('Inserisci prima ID client e chiave segreta e salva.');
    }
    $r = rb_curl(rb_url('g_oauth') . '/device/code', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => rb_cfg($t, 'client_id'), 'scope' => 'https://www.googleapis.com/auth/drive.file'))), true);
    $j = json_decode((string)$r['body'], true);
    if (!isset($j['device_code'])) {
        rb_fail($r, 'Google non ha accettato la richiesta (il client deve essere di tipo "TV e dispositivi con input limitato")');
    }
    $cfg = $t['cfg'];
    $cfg['pending'] = array('device_code' => $j['device_code'], 'user_code' => $j['user_code'],
        'url' => isset($j['verification_url']) ? $j['verification_url'] : 'https://www.google.com/device', 'expires' => time() + (int)$j['expires_in']);
    rb_save_cfg($t['id'], $cfg);
}

function rb_gdrive_finish($t)
{
    $p = isset($t['cfg']['pending']) ? $t['cfg']['pending'] : null;
    if (!$p || $p['expires'] < time()) {
        throw new Exception('Il codice è scaduto: premi di nuovo "Collega l\'account Google".');
    }
    $r = rb_curl(rb_url('g_oauth') . '/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => rb_cfg($t, 'client_id'), 'client_secret' => rb_cfg($t, 'client_secret'), 'device_code' => $p['device_code'],
        'grant_type' => 'urn:ietf:params:oauth:grant-type:device_code'))), true);
    $j = json_decode((string)$r['body'], true);
    if (isset($j['error']) && in_array($j['error'], array('authorization_pending', 'slow_down'), true)) {
        throw new Exception('Google non ha ancora ricevuto l\'autorizzazione: completa la pagina di Google e riprova.');
    }
    if (!isset($j['refresh_token'])) {
        rb_fail($r, 'Collegamento non riuscito');
    }
    $cfg = $t['cfg'];
    unset($cfg['pending'], $cfg['folder_id']);
    $cfg['refresh_token'] = rb_encrypt($j['refresh_token']);
    $cfg['account'] = '';
    $about = rb_gdrive_api($j['access_token'], 'GET', rb_url('g_api') . '/drive/v3/about?fields=user(emailAddress)');
    $a = json_decode((string)$about['body'], true);
    if (isset($a['user']['emailAddress'])) {
        $cfg['account'] = $a['user']['emailAddress'];
    }
    rb_save_cfg($t['id'], $cfg);
}

// ---- Dropbox (collegamento con codice da copiare; l'app lavora nella sua cartella "Applicazioni")
function rb_dropbox_auth_url($t)
{
    return rb_url('d_auth') . '/oauth2/authorize?' . http_build_query(array('client_id' => rb_cfg($t, 'app_key'), 'response_type' => 'code',
        'token_access_type' => 'offline'));
}

function rb_dropbox_finish($t, $code)
{
    $r = rb_curl(rb_url('d_api') . '/oauth2/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'code' => trim($code), 'grant_type' => 'authorization_code', 'client_id' => rb_cfg($t, 'app_key'), 'client_secret' => rb_cfg($t, 'app_secret')))), true);
    $j = json_decode((string)$r['body'], true);
    if (!isset($j['refresh_token'])) {
        rb_fail($r, 'Collegamento a Dropbox non riuscito (codice errato o scaduto?)');
    }
    $cfg = $t['cfg'];
    $cfg['refresh_token'] = rb_encrypt($j['refresh_token']);
    $cfg['account'] = isset($j['account_id']) ? 'account collegato' : '';
    rb_save_cfg($t['id'], $cfg);
}

function rb_dropbox_token($t)
{
    $rt = rb_cfg($t, 'refresh_token');
    if ($rt === '') {
        throw new Exception('Account Dropbox non ancora collegato.');
    }
    $r = rb_curl(rb_url('d_api') . '/oauth2/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'refresh_token' => $rt, 'grant_type' => 'refresh_token', 'client_id' => rb_cfg($t, 'app_key'), 'client_secret' => rb_cfg($t, 'app_secret')))), true);
    $j = json_decode((string)$r['body'], true);
    if (!isset($j['access_token'])) {
        rb_fail($r, 'Accesso a Dropbox non riuscito (prova a ricollegare l\'account)');
    }
    return $j['access_token'];
}

function rb_dropbox_dir($t)
{
    $d = trim(str_replace('\\', '/', rb_cfg($t, 'folder')), '/');
    return $d === '' ? '' : '/' . $d;
}

function rb_dropbox_rpc($tok, $endpoint, $args)
{
    return rb_curl(rb_url('d_api') . '/2/' . $endpoint, array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($args),
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: application/json')), true);
}

function rb_dropbox_put($t, $path, $name)
{
    $tok = rb_dropbox_token($t);
    $dest = rb_dropbox_dir($t) . '/' . $name;
    $size = filesize($path);
    $chunk = 8 * 1024 * 1024;
    $hdr = function ($arg) use ($tok) {
        return array('Authorization: Bearer ' . $tok, 'Content-Type: application/octet-stream',
            'Dropbox-API-Arg: ' . json_encode($arg, JSON_UNESCAPED_SLASHES));
    };
    if ($size <= 140 * 1024 * 1024) {
        $r = rb_curl(rb_url('d_content') . '/2/files/upload', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => file_get_contents($path),
            CURLOPT_HTTPHEADER => $hdr(array('path' => $dest, 'mode' => 'overwrite', 'mute' => true))), true);
        if ($r['code'] !== 200) {
            rb_fail($r, 'Caricamento su Dropbox non riuscito');
        }
        return;
    }
    // file grandi: caricamento a pezzi
    $fh = fopen($path, 'rb');
    $r = rb_curl(rb_url('d_content') . '/2/files/upload_session/start', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => fread($fh, $chunk),
        CURLOPT_HTTPHEADER => $hdr(array('close' => false))), true);
    $j = json_decode((string)$r['body'], true);
    if (!isset($j['session_id'])) {
        fclose($fh);
        rb_fail($r, 'Caricamento su Dropbox non riuscito');
    }
    $sid = $j['session_id'];
    $off = ftell($fh);
    while ($size - $off > $chunk) {
        $r = rb_curl(rb_url('d_content') . '/2/files/upload_session/append_v2', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => fread($fh, $chunk),
            CURLOPT_HTTPHEADER => $hdr(array('cursor' => array('session_id' => $sid, 'offset' => $off), 'close' => false))), true);
        if ($r['code'] !== 200) {
            fclose($fh);
            rb_fail($r, 'Caricamento su Dropbox interrotto');
        }
        $off = ftell($fh);
    }
    $rest = (string)stream_get_contents($fh);
    fclose($fh);
    $r = rb_curl(rb_url('d_content') . '/2/files/upload_session/finish', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => $rest,
        CURLOPT_HTTPHEADER => $hdr(array('cursor' => array('session_id' => $sid, 'offset' => $off),
            'commit' => array('path' => $dest, 'mode' => 'overwrite', 'mute' => true)))), true);
    if ($r['code'] !== 200) {
        rb_fail($r, 'Caricamento su Dropbox non completato');
    }
}

function rb_dropbox_names($t)
{
    $tok = rb_dropbox_token($t);
    $r = rb_dropbox_rpc($tok, 'files/list_folder', array('path' => rb_dropbox_dir($t)));
    if ($r['code'] === 409 && strpos($r['body'], 'not_found') !== false) {
        return array();
    }
    $j = json_decode((string)$r['body'], true);
    if ($r['code'] !== 200 || !isset($j['entries'])) {
        rb_fail($r, 'Elenco dei file su Dropbox non riuscito');
    }
    $out = array();
    foreach ($j['entries'] as $e) {
        if (isset($e['name']) && rb_is_backup_name($e['name'])) {
            $out[] = $e['name'];
        }
    }
    return $out;
}

function rb_dropbox_del($t, $name)
{
    if (!rb_is_backup_name($name)) {
        return;
    }
    $r = rb_dropbox_rpc(rb_dropbox_token($t), 'files/delete_v2', array('path' => rb_dropbox_dir($t) . '/' . $name));
    if ($r['code'] !== 200 && !($r['code'] === 409 && strpos($r['body'], 'not_found') !== false)) {
        rb_fail($r, 'Eliminazione del vecchio backup su Dropbox non riuscita');
    }
}

/* ================= Operazioni ================= */
function rb_driver($type)
{
    $d = array('folder' => 'folder', 'sftp' => 'ftp', 'ftp' => 'ftp', 'ftpes' => 'ftp', 'webdav' => 'dav', 'gdrive' => 'gdrive', 'dropbox' => 'dropbox');
    if (!isset($d[$type])) {
        throw new Exception('Tipo di destinazione sconosciuto.');
    }
    return $d[$type];
}

function rb_call($t, $op)
{
    $args = array_slice(func_get_args(), 2);
    array_unshift($args, $t);
    return call_user_func_array('rb_' . rb_driver($t['type']) . '_' . $op, $args);
}

// Copia un backup locale sulla destinazione e tiene solo gli ultimi $keep
function rb_send($t, $file, $keep)
{
    if (function_exists('set_time_limit')) {
        @set_time_limit(0);
    }
    $path = BACKUP_DIR . '/' . $file;
    if (!rb_is_backup_name($file) || !is_file($path)) {
        throw new Exception('Backup non trovato: ' . $file);
    }
    rb_call($t, 'put', $path, $file);
    $removed = 0;
    if ($keep > 0) {
        $names = rb_call($t, 'names');
        rsort($names); // il nome contiene data e ora: ordine alfabetico = ordine di tempo
        foreach (array_slice($names, $keep) as $old) {
            rb_call($t, 'del', $old);
            $removed++;
        }
    }
    return $removed;
}

// Prova completa: carica un piccolo file, lo ritrova nell'elenco e lo cancella
function rb_test($t)
{
    $name = 'libreria_' . date('Ymd_His') . '_prova.zip';
    $tmp = BACKUP_DIR . '/' . $name;
    if (!@file_put_contents($tmp, 'Prova di collegamento della Libreria di Casa: questo file si puo\' eliminare.')) {
        throw new Exception('Impossibile creare il file di prova in data/backup.');
    }
    try {
        rb_call($t, 'put', $tmp, $name);
        $names = rb_call($t, 'names');
        if (!in_array($name, $names, true)) {
            throw new Exception('Il file di prova è stato inviato ma non compare nell\'elenco della destinazione.');
        }
        rb_call($t, 'del', $name);
    } catch (Exception $e) {
        @unlink($tmp);
        throw $e;
    }
    @unlink($tmp);
    return count($names) - 1;
}

// Dopo un backup automatico: invio a tutte le destinazioni attive (gli errori finiscono nel log e nello stato)
function rb_send_all($file)
{
    $keep = max(1, min(30, (int)setting('auto_backup_keep', '5')));
    foreach (rb_targets(true) as $t) {
        // i backup completi contengono gli account: vanno solo alle destinazioni che li ammettono
        if (strpos($file, 'completo') !== false && (int)$t['send_full'] !== 1) {
            rb_set_status($t['id'], false, 'Backup completo non inviato: questa destinazione accetta solo backup senza account.');
            continue;
        }
        try {
            $rm = rb_send($t, $file, $keep);
            rb_set_status($t['id'], true, 'Inviato ' . $file . ($rm ? ' · eliminati ' . $rm . ' backup più vecchi' : ''));
            app_log('backup_inviato', $t['name'] . ': ' . $file, 'info', '');
        } catch (Exception $e) {
            rb_cleanup_tmp();
            rb_set_status($t['id'], false, $e->getMessage());
            app_log('backup_invio_fallito', $t['name'] . ': ' . $e->getMessage(), 'alert', '');
        }
    }
}
