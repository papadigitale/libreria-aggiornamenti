<?php
/* Firewall (solo Admin): protezione accessi, IP consentiti, nazioni, Cloudflare, trappola */
require_once APP_ROOT . '/inc/countries.php';
if (!fw_ready()) {
    echo '<div class="alert warn">Il database non è ancora aggiornato alla versione 1.5.</div>';
    return;
}
$c = fw_client();
list($cc, $cc_src) = fw_client_country(true);
$st = fw_stats(7);
$cfg = fw_geo_config();
$countries = fw_countries();
$cf_seen = (int)setting('fw_cf_seen', '0');
$me_white = fw_whitelisted($c['ip']);
$hdr_cf = isset($_SERVER['HTTP_CF_CONNECTING_IP']) ? (string)$_SERVER['HTTP_CF_CONNECTING_IP'] : '';
$hdr_xff = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? (string)$_SERVER['HTTP_X_FORWARDED_FOR'] : '';
$num = function ($k, $min, $max) {
    return '<input class="input" type="number" min="' . $min . '" max="' . $max . '" name="' . h($k) . '" value="' . h(setting($k)) . '">';
};
?>
<?php if ($c['proxy_hint']): ?>
<div class="alert warn">Il sito riceve le visite da un proxy della rete di casa (<?= h($c['remote']) ?>, probabilmente Nginx Proxy Manager) ma non sa di essere dietro un proxy:
  così vede tutti i visitatori con l'indirizzo del proxy e non può bloccare i singoli IP. Attiva qui sotto <b>"Il sito è dietro un reverse proxy"</b>.</div>
<?php endif; ?>
<?php if (setting('fw_enabled', '1') !== '1'): ?>
<div class="alert warn">Il firewall è spento: il sito blocca solo l'accesso dopo troppi errori (come prima della versione 1.5).</div>
<?php endif; ?>
<?php if (fw_siege_active()): ?>
<div class="alert error">Attacco distribuito in corso: fino alle <?= date('H:i', (int)setting('fw_siege_until')) ?> possono entrare solo gli IP sempre
  consentiti e i dispositivi da cui si è già entrati negli ultimi 30 giorni.
  <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="fw_siege_end"><button class="btn ghost small" type="submit">Termina adesso</button></form></div>
<?php endif; ?>

<div class="kpis">
  <a class="kpi" href="gestione.php?sez=blocchi"><b><?= number_format($st['total'], 0, ',', '.') ?></b><span>richieste fermate in 7 giorni</span></a>
  <a class="kpi" href="gestione.php?sez=blocchi"><b><?= $st['active'] ?></b><span>IP bloccati ora</span></a>
  <div class="kpi"><b><?= (isset($st['by']['brute']) ? $st['by']['brute'] : 0) + (isset($st['by']['user']) ? $st['by']['user'] : 0) ?></b><span>attacchi all'accesso</span></div>
  <div class="kpi"><b><?= isset($st['by']['scanner']) ? $st['by']['scanner'] : 0 ?></b><span>programmi in cerca di falle</span></div>
  <div class="kpi"><b><?= (isset($st['by']['country']) ? $st['by']['country'] : 0) + (isset($st['by']['direct']) ? $st['by']['direct'] : 0) ?></b><span>fermati per nazione o senza Cloudflare</span></div>
</div>

<div class="adm-grid2">
  <div class="card">
    <div class="ct"><?= icon('shield', 18) ?> Come ti vede il sito adesso</div>
    <div class="fixrow"><span>Il tuo indirizzo IP</span><b><?= h($c['ip']) ?></b></div>
    <div class="fixrow"><span>Nazione</span><b><?= h(fw_country_name($cc)) ?><?= $cc !== '' && $cc !== 'LAN' ? ' (' . h($cc) . ')' : '' ?></b></div>
    <div class="fixrow"><span>Nazione letta da</span><b><?= $cc_src !== '' ? h($cc_src) : 'nessuna fonte' ?></b></div>
    <div class="fixrow"><span>Arrivi passando da Cloudflare</span><b><?= $c['via_cf'] ? 'sì' : 'no' ?></b></div>
    <div class="fixrow"><span>Sempre consentito (mai bloccato)</span><b><?= $me_white ? 'sì' : 'no' ?></b></div>
    <details class="hint" style="margin-top:10px"><summary>Dettagli tecnici</summary>
      <p>Collegamento al server (REMOTE_ADDR): <code><?= h($c['remote']) ?></code><?= ip_is_local($c['remote']) ? ' – rete locale, di solito Nginx Proxy Manager' : '' ?><br>
      X-Forwarded-For: <code><?= h($hdr_xff !== '' ? $hdr_xff : '—') ?></code><br>
      CF-Connecting-IP: <code><?= h($hdr_cf !== '' ? $hdr_cf : '—') ?></code><br>
      Ultima visita arrivata da Cloudflare: <?= $cf_seen ? h(date('d/m/Y H:i', $cf_seen)) : 'mai vista' ?></p>
      <p>L'IP del visitatore si legge partendo dal server e risalendo solo attraverso i passaggi fidati (rete locale e Cloudflare):
        un indirizzo scritto a mano da un malintenzionato in X-Forwarded-For non viene creduto.</p>
    </details>
  </div>
  <div class="card">
    <div class="ct">Da dove arrivano gli attacchi (7 giorni)</div>
    <?php if (!$st['countries']): ?><p class="sub">Nessun evento registrato.</p><?php endif; ?>
    <?php $maxc = $st['countries'] ? max(1, (int)$st['countries'][0]['n']) : 1; foreach ($st['countries'] as $r): ?>
    <div class="bar"><span><?= h(fw_country_name($r['country'])) ?></span><i style="width:<?= max(4, round((int)$r['n'] / $maxc * 100)) ?>%"></i><b><?= (int)$r['n'] ?></b></div>
    <?php endforeach; ?>
    <p class="hint" style="margin-top:12px"><a class="link" href="gestione.php?sez=blocchi">IP bloccati e registro completo →</a></p>
  </div>
</div>

<form method="post" class="card stack" id="fwform">
  <?= csrf_field() ?><input type="hidden" name="action" value="fw_save">
  <div class="ct"><?= icon('lock', 18) ?> Firewall</div>
  <?= render_setting('fw_enabled') ?>

  <div class="ct sep">Protezione dell'accesso (brute force)</div>
  <p class="hint">Dopo <b><?= setting_int('sec_max_attempts') ?></b> accessi errati in <b><?= setting_int('sec_lock_minutes') ?></b> minuti
    (si cambia in <a class="link" href="gestione.php?sez=sicurezza">Sicurezza e accessi</a>) l'IP viene bloccato su tutto il sito.
    Se ci riprova il blocco si allunga: <?= h(fw_duration_text(fw_block_minutes(1))) ?>, poi 1 ora, 1 giorno, 1 settimana.
    In più viene sempre bloccato il nome utente attaccato, anche se gli errori arrivano da tanti IP diversi.</p>
  <?= render_setting('fw_escalate') ?>
  <?= render_setting('fw_permanent') ?>
  <div class="row2"><div><label class="lab"><?= h(setting_defaults()['fw_unknown_max'][1]) ?></label><?= $num('fw_unknown_max', 0, 50) ?></div>
    <div><label class="lab"><?= h(setting_defaults()['fw_siege'][1]) ?></label><?= $num('fw_siege', 0, 100000) ?></div></div>
  <?= render_setting('fw_banned_names') ?>
  <p class="hint">Un nome per riga. Non mettere qui i nomi degli utenti veri della libreria (verrebbero ignorati comunque).
    Durante un attacco distribuito, per 30 minuti entra solo chi è già entrato da quel dispositivo negli ultimi 30 giorni.</p>

  <div class="ct sep">Come arrivano le visite</div>
  <?php if (TRUST_PROXY): ?>
  <p class="hint">Il server è già configurato come dietro a un reverse proxy (LIBRERIA_TRUST_PROXY=1): l'IP dei visitatori viene letto dal proxy.</p>
  <?php else: ?>
  <?= render_setting('fw_proxy') ?>
  <p class="hint">Attivalo se davanti al sito c'è Nginx Proxy Manager o un altro proxy della rete di casa: l'IP reale viene letto da X-Forwarded-For
    solo quando arriva da quel proxy o da Cloudflare, quindi non si può falsificare. Lascialo spento se il sito è raggiungibile direttamente.</p>
  <?php endif; ?>

  <div class="ct sep">IP sempre consentiti</div>
  <?= render_setting('fw_lan_allow') ?>
  <?= render_setting('fw_whitelist') ?>
  <p class="hint">Mai bloccati, nemmeno dalle nazioni. Esempi: <code>93.45.12.8</code>, <code>93.45.12.0/24</code>, <code>2a01:1234::/32</code>, <code>192.168.1.*</code>.
    <?php if (!$me_white): ?><button class="btn ghost small" type="submit" name="add_me" value="1">Aggiungi il mio IP (<?= h($c['ip']) ?>)</button><?php endif; ?></p>

  <div class="ct sep">Blocco per nazione</div>
  <div class="row2"><div><?= render_setting('fw_geo_mode') ?></div><div><?= render_setting('fw_geo_scope') ?></div></div>
  <div class="cpick" data-cpick>
    <div class="toolbar" style="margin-top:4px">
      <input class="input" type="search" placeholder="Cerca una nazione…" data-cpick-search style="max-width:260px">
      <span class="muted" data-cpick-count></span>
      <button class="btn ghost small" type="button" data-cpick-only>Mostra solo le scelte</button>
      <button class="btn ghost small" type="button" data-cpick-none>Togli tutte</button>
    </div>
    <div class="cgrid">
      <?php foreach ($countries as $code => $name): ?>
      <label class="check"><input type="checkbox" name="geo[]" value="<?= h($code) ?>" <?= in_array($code, $cfg['list'], true) ? 'checked' : '' ?>><span><?= h($name) ?> <small class="muted"><?= h($code) ?></small></span></label>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="row2"><div><?= render_setting('fw_geo_unknown') ?></div><div style="padding-top:22px"><?= render_setting('fw_geo_tor') ?></div></div>
  <p class="hint">Con <b>Consenti solo</b> (es. solo Italia) entrano solo le nazioni spuntate; con <b>Blocca</b> restano fuori solo quelle spuntate.
    La rete di casa e gli IP sempre consentiti entrano comunque. Con <b>solo alla pagina di accesso</b> chi è già entrato può continuare a usare il sito anche all'estero.
    Ricorda che con una VPN si può fingere un'altra nazione: il blocco per nazione toglie di mezzo la maggior parte dei programmi automatici, ma la difesa vera resta la password con la verifica in due passaggi.</p>

  <div class="ct sep">Cloudflare</div>
  <?= render_setting('fw_cf_only') ?>
  <p class="hint">Se il dominio passa da Cloudflare (nuvola arancione), chi scopre l'indirizzo di casa tua potrebbe collegarsi direttamente saltando Cloudflare.
    Con questa opzione quelle richieste vengono rifiutate (la rete di casa entra sempre).
    <?= $cf_seen ? 'L\'ultima visita passata da Cloudflare è del ' . h(date('d/m/Y H:i', $cf_seen)) . '.' : '<b>Finora nessuna visita è arrivata da Cloudflare</b>: attivala solo se il sito è davvero dietro Cloudflare.' ?></p>

  <div class="ct sep">Trappola e registro</div>
  <?= render_setting('fw_honeypot') ?>
  <p class="hint">Il sito non è WordPress: chi cerca <code>wp-login.php</code>, <code>xmlrpc.php</code>, <code>.env</code>, <code>.git</code>, <code>phpmyadmin</code>
    e simili è un programma di attacco e viene bloccato subito. Serve il modulo <code>mod_rewrite</code> di Apache (già attivo con l'installazione Proxmox e Docker).</p>
  <div class="row2"><div><label class="lab"><?= h(setting_defaults()['fw_events_days'][1]) ?></label><?= $num('fw_events_days', 7, 3650) ?></div><div></div></div>
  <div class="savebar"><button class="btn primary" type="submit">Salva il firewall</button></div>
</form>

<div class="card">
  <div class="ct">Database delle nazioni</div>
  <?php if ($cf_seen > time() - 7 * 86400): ?>
  <p class="sub">Il tuo sito passa da Cloudflare, che indica già la nazione di ogni visitatore: il database serve solo come riserva
    (per esempio se un giorno togli Cloudflare).</p>
  <?php else: ?>
  <p class="sub">Senza Cloudflare la nazione si ricava da un database gratuito che resta sul tuo server (nessun servizio esterno vede i visitatori).</p>
  <?php endif; ?>
  <div class="fixrow"><span>Stato</span><b><?= fw_geo_ok() ? 'presente, aggiornato il ' . h(date('d/m/Y', strtotime(setting('fw_geo_db_date', date('Y-m-d'))))) : 'non scaricato' ?></b></div>
  <form method="post" class="inline-form" style="margin-top:12px"><?= csrf_field() ?><input type="hidden" name="action" value="fw_geo_update">
    <button class="btn ghost" type="submit"><?= fw_geo_ok() ? 'Aggiorna adesso' : 'Scarica adesso' ?></button>
    <span class="muted">circa 5 MB, ci vuole qualche secondo. Si aggiorna da solo ogni mese se l'opzione qui sotto è attiva.</span></form>
  <form method="post" class="inline-form" style="margin-top:10px"><?= csrf_field() ?><input type="hidden" name="action" value="fw_geo_auto">
    <label class="check switch"><input type="checkbox" name="fw_geo_auto" value="1" <?= setting('fw_geo_auto', '1') === '1' ? 'checked' : '' ?> data-autosubmit><span><?= h(setting_defaults()['fw_geo_auto'][1]) ?></span></label></form>
  <p class="hint"><a class="link" href="https://db-ip.com" rel="noopener" target="_blank">IP Geolocation by DB-IP</a> (licenza CC BY 4.0).</p>
</div>

<div class="card">
  <div class="ct">Se il firewall ti chiude fuori</div>
  <p class="sub">Dal server (console del container Proxmox, o <code>docker exec</code>) togli tutti i blocchi con:</p>
  <div class="cmd">php <?= h(dirname(APP_ROOT)) ?>/strumenti/sblocca_firewall.php</div>
</div>
