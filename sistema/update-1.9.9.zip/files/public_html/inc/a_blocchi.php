<?php
/* IP bloccati e registro del firewall (solo Admin) */
if (!fw_ready()) {
    echo '<div class="alert warn">Il database non è ancora aggiornato alla versione 1.5.</div>';
    return;
}
$reasons = fw_reasons();
$now = now();
$st = db()->prepare('SELECT * FROM fw_blocks WHERE active = 1 AND (expires_at IS NULL OR expires_at > ?) ORDER BY created_at DESC LIMIT 500');
$st->execute(array($now));
$blocks = $st->fetchAll();
$kind = isset($reasons[get('tipo')]) ? get('tipo') : '';
$q = str_cut(get('ip'), 64);
$where = array('1 = 1');
$args = array();
if ($kind !== '') {
    $where[] = 'kind = ?';
    $args[] = $kind;
}
if ($q !== '') {
    $where[] = 'ip LIKE ?';
    $args[] = $q . '%';
}
$st = db()->prepare('SELECT * FROM fw_events WHERE ' . implode(' AND ', $where) . ' ORDER BY last_at DESC LIMIT 200');
$st->execute($args);
$events = $st->fetchAll();
$durations = array('60' => '1 ora', '1440' => '1 giorno', '10080' => '1 settimana', '43200' => '30 giorni', '0' => 'Per sempre');
?>
<div class="card">
  <div class="ct"><?= icon('lock', 18) ?> Blocca un IP o una rete</div>
  <form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="fw_block">
    <input class="input" name="ip" placeholder="es. 45.95.147.12 oppure 45.95.147.0/24" required style="max-width:280px">
    <select class="input" name="minutes" style="max-width:150px"><?php foreach ($durations as $k => $v): ?><option value="<?= $k ?>" <?= $k === '0' ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?></select>
    <input class="input" name="note" placeholder="Nota (facoltativa)" maxlength="200" style="max-width:260px">
    <button class="btn primary" type="submit">Blocca</button>
  </form>
</div>

<div class="tbl-wrap">
  <table class="tbl">
    <thead><tr><th>IP</th><th>Nazione</th><th>Motivo</th><th>Dal</th><th>Fino a</th><th>Richieste fermate</th><th class="act"></th></tr></thead>
    <tbody>
    <?php if (!$blocks): ?><tr><td colspan="7" class="empty-row">Nessun IP bloccato in questo momento.</td></tr><?php endif; ?>
    <?php foreach ($blocks as $b): ?>
      <tr>
        <td><b><?= h($b['ip']) ?></b><?php if ((int)$b['level'] > 1): ?> <span class="pill"><?= (int)$b['level'] ?>° blocco</span><?php endif; ?></td>
        <td class="muted"><?= h(fw_country_name((string)$b['country'])) ?></td>
        <td><?= h(isset($reasons[$b['reason']]) ? $reasons[$b['reason']] : $b['reason']) ?><small class="muted"><?= h($b['detail']) ?><?= $b['created_by'] ? ' · da ' . h($b['created_by']) : '' ?></small></td>
        <td class="muted"><?= h(fmt_dt($b['created_at'])) ?></td>
        <td><?= $b['expires_at'] ? h(fmt_dt($b['expires_at'])) : '<b>per sempre</b>' ?></td>
        <td class="muted"><?= (int)$b['hits'] ?><?= $b['last_hit'] ? ' · ultima ' . h(fmt_dt($b['last_hit'])) : '' ?></td>
        <td class="act"><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="fw_unblock"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
          <button class="btn ghost small" type="submit">Sblocca</button></form></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card" style="margin-top:22px">
  <div class="ct">Registro del firewall</div>
  <form method="get" class="toolbar"><input type="hidden" name="sez" value="blocchi">
    <select class="input" name="tipo" style="max-width:240px"><option value="">Tutti gli eventi</option>
      <?php foreach ($reasons as $k => $v): if ($k === 'blocked') { continue; } ?><option value="<?= h($k) ?>" <?= $k === $kind ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?></select>
    <input class="input" name="ip" value="<?= h($q) ?>" placeholder="IP (anche solo l'inizio)" style="max-width:220px">
    <button class="btn ghost" type="submit">Filtra</button>
  </form>
  <form method="post" class="inline" data-confirm="Svuotare tutto il registro del firewall? I blocchi restano."><?= csrf_field() ?><input type="hidden" name="action" value="fw_events_clear">
    <button class="btn ghost small" type="submit" style="margin-top:8px">Svuota il registro</button></form>
</div>
<div class="tbl-wrap">
  <table class="tbl">
    <thead><tr><th>Quando</th><th>IP</th><th>Nazione</th><th>Evento</th><th>Volte</th><th class="act"></th></tr></thead>
    <tbody>
    <?php if (!$events): ?><tr><td colspan="6" class="empty-row">Nessun evento.</td></tr><?php endif; ?>
    <?php foreach ($events as $e): ?>
      <tr>
        <td class="muted"><?= h(fmt_dt($e['last_at'])) ?><?= $e['last_at'] !== $e['created_at'] ? '<small>dal ' . h(fmt_dt($e['created_at'])) . '</small>' : '' ?></td>
        <td><a class="rt" href="gestione.php?sez=blocchi&amp;ip=<?= h(rawurlencode($e['ip'])) ?>"><?= h($e['ip']) ?></a></td>
        <td class="muted"><?= h(fw_country_name((string)$e['country'])) ?></td>
        <td><?= h(isset($reasons[$e['kind']]) ? $reasons[$e['kind']] : $e['kind']) ?><small class="muted"><?= h($e['detail']) ?><?= $e['path'] ? ' · ' . h($e['path']) : '' ?></small></td>
        <td><?= (int)$e['hits'] ?></td>
        <td class="act"><?php if (!fw_whitelisted($e['ip']) && !fw_block_find($e['ip'])): ?>
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="fw_block"><input type="hidden" name="ip" value="<?= h($e['ip']) ?>">
            <input type="hidden" name="minutes" value="0"><input type="hidden" name="note" value="Dal registro: <?= h(str_cut((string)$e['detail'], 120)) ?>">
            <button class="btn ghost small" type="submit">Blocca</button></form><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
