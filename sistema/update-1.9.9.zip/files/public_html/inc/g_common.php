<?php
/* Funzioni comuni alle sezioni del pannello Gestione */

function render_setting($key, $override_label = '')
{
    $defs = setting_defaults();
    if (!isset($defs[$key])) {
        return '';
    }
    $d = $defs[$key];
    $label = $override_label !== '' ? $override_label : $d[1];
    $val = setting($key);
    $id = 'st-' . $key;
    $type = $d[3];
    $html = '';
    if ($type === 'bool') {
        return '<label class="check switch"><input type="checkbox" name="' . h($key) . '" value="1" ' . ($val === '1' ? 'checked' : '') . '><span>' . h($label) . '</span></label>';
    }
    $html .= '<label class="lab" for="' . h($id) . '">' . h($label) . '</label>';
    if ($type === 'color') {
        $html .= '<div class="colorrow"><input type="color" id="' . h($id) . '" name="' . h($key) . '" value="' . h($val) . '" data-var="' . h(str_replace(array('color_', '_'), array('', '-'), $key)) . '">'
               . '<input class="input hex" value="' . h($val) . '" maxlength="7" aria-label="Codice colore" data-hex-for="' . h($id) . '"></div>';
    } elseif ($type === 'textarea') {
        $html .= '<textarea class="input" id="' . h($id) . '" name="' . h($key) . '" rows="3">' . h($val) . '</textarea>';
    } elseif ($type === 'code') {
        $html .= '<textarea class="input mono" id="' . h($id) . '" name="' . h($key) . '" rows="6" spellcheck="false" placeholder="/* es. .h1{letter-spacing:.02em} */">' . h($val) . '</textarea>';
    } elseif ($type === 'number') {
        $html .= '<input class="input" type="number" inputmode="numeric" id="' . h($id) . '" name="' . h($key) . '" value="' . h($val) . '">';
    } elseif ($type === 'select') {
        $html .= '<select class="input" id="' . h($id) . '" name="' . h($key) . '">';
        foreach ($d[4] as $k => $v) {
            $html .= '<option value="' . h($k) . '" ' . ((string)$k === $val ? 'selected' : '') . '>' . h($v) . '</option>';
        }
        $html .= '</select>';
    } elseif ($type === 'font') {
        $html .= '<select class="input" id="' . h($id) . '" name="' . h($key) . '" data-font-select>';
        foreach (font_options() as $k => $f) {
            $html .= '<option value="' . h($k) . '" ' . ($k === $val ? 'selected' : '') . ' data-stack="' . h($f[1]) . '">' . h($f[0]) . '</option>';
        }
        $html .= '</select>';
    } else {
        $html .= '<input class="input" id="' . h($id) . '" name="' . h($key) . '" value="' . h($val) . '" maxlength="500">';
    }
    return $html;
}

function settings_form_open($group, $multipart = false)
{
    return '<form method="post" class="card stack"' . ($multipart ? ' enctype="multipart/form-data"' : '') . '>' . csrf_field()
         . '<input type="hidden" name="action" value="settings"><input type="hidden" name="group" value="' . h($group) . '">';
}

function fmt_bytes($n)
{
    if ($n > 1048576) {
        return number_format($n / 1048576, 1, ',', '.') . ' MB';
    }
    return number_format(max(1, $n / 1024), 0, ',', '.') . ' KB';
}

function fmt_dt($s)
{
    return $s ? date('d/m/Y H:i', strtotime($s)) : '—';
}
