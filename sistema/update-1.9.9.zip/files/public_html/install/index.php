<?php
/*
 * INSTALLAZIONE GUIDATA (stile WordPress)
 *   1 Benvenuto e controllo requisiti
 *   2 Database
 *   3 Il tuo sito (nome, stile, ricerca online)
 *   4 Account amministratore  -> qui avviene l'installazione vera e propria
 *   5 Ripristino da un backup (facoltativo)
 *   6 Fine
 * Funziona solo finche' il sito non e' installato (file data/installed.lock).
 */
define('IS_INSTALLER', true);
require_once dirname(__FILE__) . '/../../CONF/bootstrap.php';

$STEPS = array(1 => 'Benvenuto', 2 => 'Database', 3 => 'Il sito', 4 => 'Amministratore', 5 => 'Ripristino', 6 => 'Fine');

if (!isset($_SESSION['inst']) || !is_array($_SESSION['inst'])) {
    $_SESSION['inst'] = array();
}
$I = &$_SESSION['inst'];
$done = !empty($I['done']);
$locked = is_file(INSTALL_LOCK_FILE);

/* ---------- Funzioni dell'installazione ---------- */
function inst_val($key, $default = '')
{
    global $I;
    if (isset($_POST[$key]) && is_string($_POST[$key])) {
        return trim($_POST[$key]);
    }
    return isset($I[$key]) ? $I[$key] : $default;
}

function inst_pdo($cfg, $with_db = true)
{
    if (DB_DRIVER === 'sqlite') { // solo modalita' di prova
        $p = new PDO('sqlite:' . DB_SQLITE_FILE, null, null, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC));
        $p->exec('PRAGMA foreign_keys = ON');
        return $p;
    }
    $dsn = 'mysql:host=' . $cfg['db_host'] . ';port=' . (int)$cfg['db_port'] . ($with_db ? ';dbname=' . $cfg['db_name'] : '') . ';charset=utf8mb4';
    $p = new PDO($dsn, $cfg['db_user'], $cfg['db_pass'], array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_TIMEOUT => 6));
    $p->exec("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'");
    return $p;
}

function inst_db_error($e)
{
    $m = $e->getMessage();
    if (stripos($m, 'Access denied') !== false) {
        $who = preg_match("/for user '([^']*)'@'([^']*)'/", $m, $mm) ? ' Il server database ha rifiutato l\'utente "' . $mm[1] . '" collegato da ' . $mm[2]
             . ': se il database è su un altro computer, l\'utente deve essere autorizzato per questo indirizzo (non solo per localhost).' : '';
        return 'Nome utente o password del database non corretti (oppure l\'utente non ha i permessi su questo database).' . $who;
    }
    if (stripos($m, 'Unknown database') !== false) {
        return 'Il database indicato non esiste. Spunta "Crea il database se non esiste" oppure crealo prima.';
    }
    if (stripos($m, 'getaddrinfo') !== false || stripos($m, 'Name or service') !== false || stripos($m, 'php_network_getaddresses') !== false) {
        return 'Indirizzo del server database non trovato. Con Docker usa il nome del servizio (es. "db"), altrimenti l\'IP del server.';
    }
    if (stripos($m, 'refused') !== false || stripos($m, 'timed out') !== false || stripos($m, 'No route') !== false) {
        return 'Il server database non risponde: controlla indirizzo, porta e che sia acceso e raggiungibile dalla rete.';
    }
    return 'Errore del database: ' . $m;
}

function inst_tables_exist($pdo)
{
    try {
        $n = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
        return (int)$n;
    } catch (Exception $e) {
        return -1;
    }
}

// Istruzioni SQL dal file di installazione (senza l'utente admin predefinito)
function inst_sql_statements()
{
    $sql = file_get_contents(dirname(APP_ROOT) . '/sql/libreria.sql');
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    $out = array();
    foreach (preg_split('/;\s*\n/', $sql) as $st) {
        $st = trim($st);
        if ($st === '' || stripos($st, 'INSERT INTO users') === 0) {
            continue;
        }
        if (DB_DRIVER === 'sqlite') {
            $st = inst_sqlite($st);
            if ($st === '') {
                continue;
            }
        }
        $out[] = $st;
    }
    return $out;
}

// Solo per la modalita' di prova senza MySQL
function inst_sqlite($st)
{
    if (stripos($st, 'SET ') === 0) {
        return '';
    }
    $st = preg_replace('/\)\s*ENGINE=[^;]*$/s', ')', $st);
    $lines = array();
    foreach (explode("\n", $st) as $l) {
        if (preg_match('/^\s*KEY /', $l) || preg_match('/^\s*PRIMARY KEY \(id\)/', $l)) {
            continue;
        }
        $lines[] = $l;
    }
    $st = implode("\n", $lines);
    $st = preg_replace('/(\w+)\s+INT UNSIGNED NOT NULL AUTO_INCREMENT/', '$1 INTEGER PRIMARY KEY AUTOINCREMENT', $st);
    $st = preg_replace('/UNIQUE KEY \w+ /', 'UNIQUE ', $st);
    $st = preg_replace('/CONSTRAINT \w+ /', '', $st);
    $st = preg_replace('/,\s*\n\)/', "\n)", $st);
    return str_replace(array('NOW()', 'TINYINT(1)', 'UNSIGNED'), array("datetime('now')", 'INTEGER', ''), $st);
}

function inst_write_config($I)
{
    $esc = function ($v) {
        return var_export((string)$v, true);
    };
    $php = "<?php\n// Scritto dall'installazione guidata il " . date('d/m/Y H:i') . ". Puoi modificarlo a mano.\n"
         . "define('DB_HOST', " . $esc($I['db_host']) . ");\n"
         . "define('DB_PORT', " . (int)$I['db_port'] . ");\n"
         . "define('DB_NAME', " . $esc($I['db_name']) . ");\n"
         . "define('DB_USER', " . $esc($I['db_user']) . ");\n"
         . "define('DB_PASS', " . $esc($I['db_pass']) . ");\n"
         . "define('APP_TIMEZONE', " . $esc($I['timezone']) . ");\n";
    if (@file_put_contents(LOCAL_CONFIG_FILE, $php) === false) {
        throw new Exception('Impossibile scrivere ' . LOCAL_CONFIG_FILE . ': la cartella data non è scrivibile dal web server.');
    }
    @chmod(LOCAL_CONFIG_FILE, 0640);
}

function inst_prepare_dirs()
{
    $deny = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n";
    foreach (array(DATA_DIR, COVERS_DIR, UPLOADS_DIR, BACKUP_DIR) as $d) {
        if (!is_dir($d)) {
            @mkdir($d, 0775, true);
        }
        if (is_dir($d) && !is_file($d . '/.htaccess')) {
            @file_put_contents($d . '/.htaccess', $deny);
        }
    }
}

function inst_password_problem($pw, $user)
{
    if (str_len($pw) < 10) {
        return 'La password deve avere almeno 10 caratteri.';
    }
    if (strcasecmp($pw, $user) === 0) {
        return 'La password non può essere uguale al nome utente.';
    }
    if (in_array(strtolower($pw), array('password', 'password1', '1234567890', 'qwertyuiop', 'admin12345', 'libreria123'), true)) {
        return 'Questa password è troppo comune: scegline un\'altra.';
    }
    return '';
}

// Esegue l'installazione vera e propria (fine del passo 4)
function inst_run($I)
{
    $pdo = inst_pdo($I);
    $fresh = $I['db_mode'] !== 'use';
    if ($fresh) {
        $pdo->exec(DB_DRIVER === 'sqlite' ? 'PRAGMA foreign_keys = OFF' : 'SET FOREIGN_KEY_CHECKS = 0');
        foreach (inst_sql_statements() as $st) {
            $pdo->exec($st);
        }
        $pdo->exec(DB_DRIVER === 'sqlite' ? 'PRAGMA foreign_keys = ON' : 'SET FOREIGN_KEY_CHECKS = 1');
    }
    // tabelle aggiunte dalle versioni successive (etichette, campi, sezioni, pagine...)
    require_once APP_ROOT . '/inc/migrate.php';
    $mig = db_migrate($pdo, DB_DRIVER);
    if (!$mig[0]) {
        throw new Exception($mig[1]);
    }
    $now = date('Y-m-d H:i:s');
    $hash = pw_hash($I['adm_pass']);
    $st = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $st->execute(array($I['adm_user']));
    $id = $st->fetchColumn();
    if ($id) {
        $pdo->prepare("UPDATE users SET display_name = ?, password_hash = ?, role = 'admin', active = 1, must_change_pw = 0, totp_secret = NULL, totp_enabled = 0, updated_at = ? WHERE id = ?")
            ->execute(array($I['adm_name'], $hash, $now, $id));
    } else {
        $pdo->prepare("INSERT INTO users (username, display_name, password_hash, role, active, must_change_pw, created_at, updated_at) VALUES (?, ?, ?, 'admin', 1, 0, ?, ?)")
            ->execute(array($I['adm_user'], $I['adm_name'], $hash, $now, $now));
    }
    // impostazioni scelte nella procedura
    $presets = theme_presets();
    $set = array('brand_title' => $I['site_title'], 'brand_kicker' => $I['site_kicker'], 'lookup_lang' => $I['lookup_lang'],
        'google_api_key' => $I['google_key'], 'guest_enabled' => $I['guest'] ? '1' : '0', 'theme_preset' => $I['preset']);
    if (isset($presets[$I['preset']])) {
        $set = array_merge($presets[$I['preset']][1], $set);
    }
    $sel = $pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key = ?');
    $upd = $pdo->prepare('UPDATE settings SET setting_value = ?, updated_at = ? WHERE setting_key = ?');
    $ins = $pdo->prepare('INSERT INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?)');
    foreach ($set as $k => $v) {
        $sel->execute(array($k));
        if ((int)$sel->fetchColumn() > 0) {
            $upd->execute(array((string)$v, $now, $k));
        } else {
            $ins->execute(array($k, (string)$v, $now));
        }
    }
    $pdo->prepare('INSERT INTO logs (created_at, username, ip, level, action, detail) VALUES (?,?,?,?,?,?)')
        ->execute(array($now, $I['adm_user'], client_ip(), 'warn', 'installazione', 'Installazione guidata completata' . ($fresh ? '' : ' (database esistente)')));
    inst_prepare_dirs();
    if (DB_DRIVER !== 'sqlite') {
        inst_write_config($I);
    }
    @file_put_contents(INSTALL_LOCK_FILE, date('c') . " installazione guidata\n");
}

/* ---------- Stato e gestione dei passi ---------- */
$error = '';
$info = '';
$step = (int)get('passo', isset($I['step']) ? (string)$I['step'] : '1');

if ($locked && !$done) {
    $step = 0; // gia' installato
} elseif ($done) {
    $step = max(5, min(6, $step));
} else {
    $max_reached = isset($I['max']) ? (int)$I['max'] : 1;
    $step = max(1, min(4, $step, $max_reached));
}
$need_token = INSTALL_TOKEN !== '' && empty($I['token_ok']) && !$done && !$locked;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step > 0) {
    check_csrf();
    $act = post('act');
    try {
        if ($act === 'token') {
            if (hash_equals(INSTALL_TOKEN, post('token'))) {
                $I['token_ok'] = 1;
                redirect('index.php?passo=1');
            }
            $error = 'Codice non corretto. Lo trovi nel file .env (LIBRERIA_INSTALL_TOKEN) o nel docker-compose.';
        } elseif ($need_token) {
            $error = 'Inserisci prima il codice di installazione.';
        } elseif ($act === 'step1') {
            $I['max'] = max(isset($I['max']) ? $I['max'] : 1, 2);
            redirect('index.php?passo=2');
        } elseif ($act === 'step2') {
            $cfg = array('db_host' => inst_val('db_host'), 'db_port' => (int)inst_val('db_port', '3306'), 'db_name' => inst_val('db_name'),
                'db_user' => inst_val('db_user'), 'db_pass' => isset($_POST['db_pass']) ? (string)$_POST['db_pass'] : '');
            if ($cfg['db_pass'] === '' && !empty($I['db_pass']) && post('keep_pass') === '1') {
                $cfg['db_pass'] = $I['db_pass'];
            }
            if ($cfg['db_pass'] === '' && getenv('LIBRERIA_DB_PASS')) {
                $cfg['db_pass'] = getenv('LIBRERIA_DB_PASS'); // password gia' indicata nel docker-compose (.env)
            }
            if (!preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $cfg['db_name'])) {
                throw new Exception('Nome del database non valido (lettere, numeri, _ e -).');
            }
            if ($cfg['db_host'] === '' || preg_match('/\s/', $cfg['db_host'])) {
                throw new Exception('Indica l\'indirizzo del server database.');
            }
            try {
                $pdo = inst_pdo($cfg);
            } catch (PDOException $e) {
                // database mancante: MySQL risponde "Unknown database" oppure, se l'utente non ha ancora permessi
                // su quel nome, "Access denied ... to database": in entrambi i casi si prova a crearlo
                $missing = stripos($e->getMessage(), 'Unknown database') !== false || stripos($e->getMessage(), 'to database') !== false;
                if (post('create_db') === '1' && $missing) {
                    $p0 = inst_pdo($cfg, false);
                    $p0->exec('CREATE DATABASE IF NOT EXISTS `' . $cfg['db_name'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                    $pdo = inst_pdo($cfg);
                } else {
                    throw new Exception(inst_db_error($e));
                }
            }
            $users = inst_tables_exist($pdo);
            $I = array_merge($I, $cfg);
            if ($users >= 0 && post('db_mode') === '') {
                $I['existing'] = $users;
                $info = 'existing';
            } else {
                $I['db_mode'] = $users >= 0 ? (post('db_mode') === 'use' ? 'use' : 'reset') : 'new';
                $I['max'] = max($I['max'], 3);
                redirect('index.php?passo=3');
            }
        } elseif ($act === 'step3') {
            $title = str_cut(inst_val('site_title'), 80);
            if ($title === '') {
                throw new Exception('Scrivi il nome del sito.');
            }
            $tz = inst_val('timezone', 'Europe/Rome');
            $I['site_title'] = $title;
            $I['site_kicker'] = str_cut(inst_val('site_kicker'), 40);
            $I['preset'] = isset(theme_presets()[post('preset')]) ? post('preset') : 'classica';
            $I['lookup_lang'] = post('lookup_lang') === '' ? '' : 'it';
            $I['google_key'] = str_cut(preg_replace('/\s/', '', inst_val('google_key')), 100);
            $I['timezone'] = in_array($tz, timezone_identifiers_list(), true) ? $tz : 'Europe/Rome';
            $I['guest'] = post('guest') === '1';
            $I['max'] = max($I['max'], 4);
            redirect('index.php?passo=4');
        } elseif ($act === 'step4') {
            $u = strtolower(inst_val('adm_user'));
            $pw = isset($_POST['adm_pass']) ? (string)$_POST['adm_pass'] : '';
            if (!preg_match('/^[a-z0-9._\-]{3,60}$/', $u)) {
                throw new Exception('Nome utente non valido: 3-60 caratteri tra lettere minuscole, numeri, punto, trattino.');
            }
            if ($pw !== (isset($_POST['adm_pass2']) ? (string)$_POST['adm_pass2'] : '')) {
                throw new Exception('Le due password non coincidono.');
            }
            if (($p = inst_password_problem($pw, $u)) !== '') {
                throw new Exception($p);
            }
            $I['adm_user'] = $u;
            $I['adm_name'] = str_cut(inst_val('adm_name'), 100);
            $I['adm_pass'] = $pw;
            inst_run($I);
            unset($I['adm_pass'], $I['db_pass']);
            $I['done'] = 1;
            redirect('index.php?passo=5');
        } elseif ($act === 'restore' && $done) {
            require_once APP_ROOT . '/inc/data_tools.php';
            if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
                throw new Exception(isset($_FILES['file']) && in_array($_FILES['file']['error'], array(UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE), true)
                    ? 'Il file è troppo grande per le impostazioni di PHP (upload_max_filesize).' : 'Scegli il file di backup (.zip o .json).');
            }
            if (!backup_dir_ready()) {
                throw new Exception('La cartella data/backup non è scrivibile.');
            }
            $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION)) === 'json' ? 'json' : 'zip';
            $name = 'libreria_' . date('Ymd_His') . '_caricato_' . substr(random_token(2), 0, 4) . '.' . $ext;
            move_uploaded_file($_FILES['file']['tmp_name'], BACKUP_DIR . '/' . $name);
            $full = backup_is_full(BACKUP_DIR . '/' . $name);
            $n = backup_restore(BACKUP_DIR . '/' . $name, $full && post('with_users') === '1');
            $users = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
            app_log('backup_ripristinato', 'Durante l\'installazione: ' . $name . ' (' . $n . ' libri)', 'warn', $I['adm_user']);
            $I['restored'] = array('books' => $n, 'full' => $full && post('with_users') === '1', 'users' => $users);
            redirect('index.php?passo=6');
        } elseif ($act === 'skip' && $done) {
            redirect('index.php?passo=6');
        } elseif ($act === 'finish' && $done) {
            $st = db()->prepare('SELECT * FROM users WHERE username = ?');
            $st->execute(array($I['adm_user']));
            $u = $st->fetch();
            session_regenerate_id(true);
            $_SESSION = array();
            if ($u) {
                $_SESSION['uid'] = (int)$u['id'];
                $_SESSION['role'] = $u['role'];
                $_SESSION['username'] = $u['username'];
                $_SESSION['last_seen'] = time();
                app_log('login', 'Primo accesso dopo l\'installazione', 'info', $u['username']);
            }
            redirect('../libreria.php');
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
$I['step'] = $step;

/* ---------- Pagina ---------- */
$checks = array(
    array('PHP 7.0 o successivo', version_compare(PHP_VERSION, '7.0.0', '>='), 'Versione attuale: ' . PHP_VERSION, true),
    array('Collegamento a MySQL/MariaDB (pdo_mysql)', extension_loaded('pdo_mysql') || DB_DRIVER === 'sqlite', '', true),
    array('Immagini e copertine (gd)', extension_loaded('gd'), 'Senza, le copertine vengono salvate così come arrivano.', false),
    array('Backup ZIP (zip)', class_exists('ZipArchive'), 'Senza, i backup non includono le copertine.', false),
    array('Connessioni internet (curl)', function_exists('curl_init'), 'Senza, la ricerca dei libri usa un metodo più lento.', false),
    array('Testi accentati (mbstring)', function_exists('mb_strlen'), '', false),
    array('Cartella data scrivibile', is_dir(DATA_DIR) ? is_writable(DATA_DIR) : @mkdir(DATA_DIR, 0775, true), DATA_DIR, true),
);
$blocking = false;
foreach ($checks as $c) {
    if ($c[3] && !$c[1]) {
        $blocking = true;
    }
}
$env = function ($k, $d) {
    $v = getenv($k);
    return ($v === false || $v === '') ? $d : $v;
};
$max_upload = ini_get('upload_max_filesize');

header('Content-Type: text/html; charset=utf-8');
?><!doctype html>
<html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex"><title>Installazione · Libreria di Casa</title>
<link rel="stylesheet" href="../css/style.css?v=<?= (int)@filemtime(APP_ROOT . '/css/style.css') ?>">
<style>
@font-face{font-family:"Libreria Pagella";src:url(../fonts/pagella-regular.woff) format("woff");font-weight:400;font-display:swap}
@font-face{font-family:"Libreria Lora";src:url(../fonts/lora.woff) format("woff");font-weight:400 700;font-display:swap}
@font-face{font-family:"Libreria Inter";src:url(../fonts/inter-regular.woff) format("woff");font-weight:400;font-display:swap}
@font-face{font-family:"Libreria Inter";src:url(../fonts/inter-semibold.woff) format("woff");font-weight:600;font-display:swap}
:root{--head:"Libreria Pagella",Palatino,Georgia,serif;--body:"Libreria Lora",Georgia,serif;--ui:"Libreria Inter",system-ui,sans-serif}
.inst{max-width:620px;margin:0 auto;padding:max(18px,env(safe-area-inset-top)) 18px 40px}
.inst-head{display:flex;gap:12px;align-items:center;margin-bottom:18px}
.steps-bar{display:flex;gap:4px;margin:6px 0 4px}
.steps-bar i{flex:1;height:5px;border-radius:3px;background:var(--line)}
.steps-bar i.on{background:var(--primary)}
.step-name{font:600 11px var(--ui);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}
.req{display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px dashed var(--line);font-size:14px}
.req small{display:block;color:var(--muted);font-size:12px}
.req b{white-space:nowrap}
.presets-inst{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.presets-inst label{position:relative;display:block;cursor:pointer}
.presets-inst input{position:absolute;opacity:0}
.presets-inst span{display:flex;flex-direction:column;gap:8px;min-height:80px;padding:12px;border:1.5px solid rgba(0,0,0,.1)}
.presets-inst input:checked+span{outline:2.5px solid var(--primary);outline-offset:2px}
.presets-inst em{display:flex;gap:5px}.presets-inst em i{width:16px;height:16px;border-radius:50%;box-shadow:inset 0 0 0 1px rgba(0,0,0,.15)}
.inst .btn{margin-top:16px}
.inst code{font-size:13px;word-break:normal;white-space:nowrap}
</style></head>
<body><div class="inst">
  <div class="inst-head"><span class="logo"><svg class="i" width="20" height="20" viewBox="0 0 24 24"><path d="M4 4h4v16H4zM10 4h4v16h-4zM16.5 4.5l3.5 1-4 15-3.5-1z"/></svg></span>
    <div><div class="kick">Installazione guidata</div><div class="brandname">Libreria di Casa</div></div></div>
<?php if ($step > 0): ?>
  <div class="steps-bar"><?php foreach ($STEPS as $n => $lab): ?><i class="<?= $n <= $step ? 'on' : '' ?>"></i><?php endforeach; ?></div>
  <div class="step-name">Passo <?= $step ?> di 6 · <?= h($STEPS[$step]) ?></div>
<?php endif; ?>
<?php if ($error !== ''): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>

<?php if ($step === 0): ?>
  <div class="card">
    <h1 class="h1">Il sito è già installato</h1>
    <p class="sub">Per sicurezza l'installazione guidata non si può ripetere. Se devi davvero rifarla, cancella il file
      <code>data/installed.lock</code> (e, se vuoi cambiare database, <code>data/config.local.php</code>) e ricarica questa pagina.</p>
    <a class="btn primary" href="../index.php">Vai all'accesso</a>
  </div>

<?php elseif ($need_token): ?>
  <form method="post" class="card stack"><?= csrf_field() ?><input type="hidden" name="act" value="token">
    <h1 class="h1">Codice di installazione</h1>
    <p class="sub">Questo server richiede un codice per avviare l'installazione (impostato in <code>LIBRERIA_INSTALL_TOKEN</code>).</p>
    <label class="lab" for="tk">Codice</label><input class="input" id="tk" name="token" autocomplete="off" required>
    <button class="btn primary" type="submit">Continua</button>
  </form>

<?php elseif ($step === 1): ?>
  <form method="post" class="card stack"><?= csrf_field() ?><input type="hidden" name="act" value="step1">
    <h1 class="h1">Benvenuto!</h1>
    <p class="sub">In pochi passi configuri il database, il nome e lo stile del sito e il tuo account di amministratore.
      Alla fine potrai ripristinare i dati da un backup della tua vecchia libreria.</p>
    <div class="ct" style="margin-top:16px">Controllo del server</div>
    <?php foreach ($checks as $c): ?>
      <div class="req"><span><?= h($c[0]) ?><?php if ($c[2] !== ''): ?><small><?= h($c[2]) ?></small><?php endif; ?></span>
        <b class="<?= $c[1] ? 'ok-text' : ($c[3] ? 'err-text' : 'warn-text') ?>"><?= $c[1] ? 'OK' : ($c[3] ? 'Manca' : 'Consigliato') ?></b></div>
    <?php endforeach; ?>
    <div class="req"><span>Dimensione massima dei file caricati<small>Serve per ripristinare backup grandi</small></span><b><?= h($max_upload) ?></b></div>
    <?php if ($blocking): ?>
      <div class="alert error">Risolvi i punti segnati "Manca" e ricarica la pagina.</div>
    <?php else: ?>
      <button class="btn primary" type="submit">Iniziamo</button>
    <?php endif; ?>
  </form>

<?php elseif ($step === 2): ?>
  <form method="post" class="card stack" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="act" value="step2">
    <h1 class="h1">Database</h1>
    <p class="sub">Dove salvare la libreria (MySQL o MariaDB). Con il <code>docker-compose.yml</code> fornito i valori sono già compilati:
      basta confermare.</p>
    <?php if ($info === 'existing'): ?>
      <div class="alert warn">In questo database c'è già una Libreria di Casa (<?= (int)$I['existing'] ?> utenti). Cosa vuoi fare?</div>
      <label class="check"><input type="radio" name="db_mode" value="use" checked> <span><b>Usa i dati esistenti</b> (libri, utenti e impostazioni restano; l'account del passo 4 diventa/resta Admin)</span></label>
      <label class="check"><input type="radio" name="db_mode" value="reset"> <span><b>Cancella tutto e ricomincia</b> (tutti i dati di quel database andranno persi)</span></label>
      <input type="hidden" name="keep_pass" value="1">
    <?php else: ?>
      <input type="hidden" name="db_mode" value="">
    <?php endif; ?>
    <label class="lab" for="dh">Server del database</label>
    <input class="input" id="dh" name="db_host" required value="<?= h(inst_val('db_host', $env('LIBRERIA_DB_HOST', 'localhost'))) ?>">
    <p class="hint">Con Docker: il nome del servizio (es. <code>db</code>). Su un altro computer/NAS: il suo IP (es. 192.168.1.50).</p>
    <div class="row2">
      <div><label class="lab" for="dp">Porta</label><input class="input" id="dp" name="db_port" inputmode="numeric" value="<?= h(inst_val('db_port', $env('LIBRERIA_DB_PORT', '3306'))) ?>"></div>
      <div><label class="lab" for="dn">Nome database</label><input class="input" id="dn" name="db_name" required value="<?= h(inst_val('db_name', $env('LIBRERIA_DB_NAME', 'libreria'))) ?>"></div>
    </div>
    <label class="lab" for="du">Utente</label>
    <input class="input" id="du" name="db_user" required autocapitalize="none" value="<?= h(inst_val('db_user', $env('LIBRERIA_DB_USER', 'libreria'))) ?>">
    <label class="lab" for="dw">Password</label>
    <input class="input" id="dw" name="db_pass" type="password" value=""
      placeholder="<?= $info === 'existing' ? 'già inserita' : (getenv('LIBRERIA_DB_PASS') ? 'già impostata in fase di installazione: lascia vuoto' : '') ?>">
    <label class="check"><input type="checkbox" name="create_db" value="1" checked> Crea il database se non esiste (serve un utente con i permessi)</label>
    <button class="btn primary" type="submit"><?= $info === 'existing' ? 'Conferma e continua' : 'Verifica e continua' ?></button>
    <a class="btn link" href="index.php?passo=1">Indietro</a>
  </form>

<?php elseif ($step === 3): $pr = inst_val('preset', 'classica'); ?>
  <form method="post" class="card stack"><?= csrf_field() ?><input type="hidden" name="act" value="step3">
    <h1 class="h1">Il tuo sito</h1>
    <label class="lab" for="st">Nome del sito</label>
    <input class="input" id="st" name="site_title" required maxlength="80" value="<?= h(inst_val('site_title', 'Libreria di Casa')) ?>">
    <label class="lab" for="sk">Sopratitolo (piccolo, sopra al nome)</label>
    <input class="input" id="sk" name="site_kicker" maxlength="40" value="<?= h(inst_val('site_kicker', 'La mia')) ?>">
    <label class="lab">Stile grafico (potrai cambiarlo in ogni dettaglio da Gestione → Aspetto)</label>
    <div class="presets-inst">
      <?php foreach (theme_presets() as $k => $p): $c = $p[1]; ?>
      <label><input type="radio" name="preset" value="<?= h($k) ?>" <?= $pr === $k ? 'checked' : '' ?>>
        <span style="background:<?= h($c['color_bg']) ?>;color:<?= h($c['color_ink']) ?>;border-radius:<?= (int)$c['radius'] ?>px">
          <em><i style="background:<?= h($c['color_primary']) ?>"></i><i style="background:<?= h($c['color_accent']) ?>"></i><i style="background:<?= h($c['color_panel']) ?>"></i></em>
          <?= h($p[0]) ?></span></label>
      <?php endforeach; ?>
    </div>
    <label class="lab" for="ll">Lingua preferita per i dati dei libri</label>
    <select class="input" id="ll" name="lookup_lang">
      <option value="it" <?= inst_val('lookup_lang', 'it') === 'it' ? 'selected' : '' ?>>Italiano (trame solo in italiano)</option>
      <option value="" <?= inst_val('lookup_lang', 'it') === '' ? 'selected' : '' ?>>Tutte le lingue</option>
    </select>
    <label class="lab" for="gk">Chiave API Google Books (facoltativa, consigliata)</label>
    <input class="input" id="gk" name="google_key" autocomplete="off" placeholder="AIza…" value="<?= h(inst_val('google_key')) ?>">
    <p class="hint">Senza chiave Google limita le ricerche (errore 429). Si crea gratis su console.cloud.google.com → Books API → Credenziali → Chiave API.
      Puoi aggiungerla anche dopo.</p>
    <label class="lab" for="tz">Fuso orario</label>
    <select class="input" id="tz" name="timezone">
      <?php $tzs = inst_val('timezone', APP_TIMEZONE); foreach (timezone_identifiers_list() as $z): if (!preg_match('#^(Europe|America|Asia|Africa|Australia|Atlantic|Pacific|UTC)#', $z)) { continue; } ?>
      <option <?= $z === $tzs ? 'selected' : '' ?>><?= h($z) ?></option>
      <?php endforeach; ?>
    </select>
    <label class="check"><input type="checkbox" name="guest" value="1" <?= !empty($I['guest']) ? 'checked' : '' ?>> Consenti l'accesso come ospite (solo consultazione)</label>
    <button class="btn primary" type="submit">Continua</button>
    <a class="btn link" href="index.php?passo=2">Indietro</a>
  </form>

<?php elseif ($step === 4): ?>
  <form method="post" class="card stack" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="act" value="step4">
    <h1 class="h1">Account amministratore</h1>
    <p class="sub">È l'utente con il controllo completo del sito. Altri utenti (Admin o Gestore) potrai crearli dopo da Gestione → Utenti.</p>
    <label class="lab" for="au">Nome utente (per l'accesso)</label>
    <input class="input" id="au" name="adm_user" required autocapitalize="none" pattern="[a-zA-Z0-9._\-]{3,60}" value="<?= h(inst_val('adm_user', 'admin')) ?>">
    <label class="lab" for="an">Nome visualizzato</label>
    <input class="input" id="an" name="adm_name" maxlength="100" value="<?= h(inst_val('adm_name', 'Amministratore')) ?>">
    <label class="lab" for="ap">Password (almeno 10 caratteri)</label>
    <input class="input" id="ap" name="adm_pass" type="password" required minlength="10" autocomplete="new-password">
    <label class="lab" for="ap2">Ripeti la password</label>
    <input class="input" id="ap2" name="adm_pass2" type="password" required minlength="10" autocomplete="new-password">
    <div class="card" style="background:var(--bg)">
      <div class="fk">Riepilogo</div>
      <div class="fr row"><span>Database</span><span class="sub"><?= h($I['db_user'] . '@' . $I['db_host'] . ':' . $I['db_port'] . '/' . $I['db_name']) ?></span></div>
      <div class="fr row"><span>Dati esistenti</span><span class="sub"><?= $I['db_mode'] === 'use' ? 'mantenuti' : ($I['db_mode'] === 'reset' ? 'cancellati e ricreati' : 'nuova libreria') ?></span></div>
      <div class="fr row"><span>Sito</span><span class="sub"><?= h($I['site_title']) ?> · <?= h(theme_presets()[$I['preset']][0]) ?></span></div>
    </div>
    <button class="btn primary" type="submit">Installa</button>
    <a class="btn link" href="index.php?passo=3">Indietro</a>
  </form>

<?php elseif ($step === 5): ?>
  <div class="alert success">Installazione completata! Il sito è pronto.</div>
  <form method="post" enctype="multipart/form-data" class="card stack"><?= csrf_field() ?><input type="hidden" name="act" value="restore">
    <h1 class="h1">Vuoi ripristinare i dati?</h1>
    <p class="sub">Se avevi già una Libreria di Casa (per esempio su UwAmp), carica qui un suo backup: libri, copertine, generi, stati di lettura e ruote.
      Il backup si crea dal vecchio sito in <b>Gestione → Dati e backup</b>; il <b>backup completo</b> porta anche utenti e impostazioni.</p>
    <label class="lab" for="bf">File di backup (.zip o .json, massimo <?= h($max_upload) ?>)</label>
    <input class="input" id="bf" type="file" name="file" accept=".zip,.json" required>
    <label class="check"><input type="checkbox" name="with_users" value="1" checked> Se è un backup completo, aggiungi anche gli altri utenti e le impostazioni del sito
      (il tuo account appena creato resta com'è)</label>
    <button class="btn primary" type="submit">Ripristina il backup</button>
  </form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="skip">
    <button class="btn ghost" type="submit">No grazie, parto da una libreria vuota</button></form>

<?php elseif ($step === 6): $r = isset($I['restored']) ? $I['restored'] : null; ?>
  <form method="post" class="card stack"><?= csrf_field() ?><input type="hidden" name="act" value="finish">
    <h1 class="h1">Tutto pronto!</h1>
    <?php if ($r): ?>
      <div class="alert success">Ripristinati <?= (int)$r['books'] ?> libri<?= $r['full'] ? ', con utenti e impostazioni (' . (int)$r['users'] . ' utenti in tutto)' : '' ?>.</div>
    <?php endif; ?>
    <p class="sub">Accedi con l'utente <b><?= h($I['adm_user']) ?></b>. Alcuni consigli per iniziare:</p>
    <ol class="steps">
      <li><b>Gestione → Ricerca online → Prova adesso</b>: verifica che il server raggiunga le piattaforme dei libri.</li>
      <li><b>Gestione → Sicurezza</b>: limita gli indirizzi IP ammessi alla tua rete (es. <code>192.168.1.*</code>).</li>
      <li>Per usare la fotocamera del telefono serve l'HTTPS: vedi la guida (reverse proxy).</li>
      <li>Sul telefono: menu del browser → <b>Aggiungi a schermata Home</b>.</li>
    </ol>
    <button class="btn primary" type="submit">Entra nella libreria</button>
  </form>
<?php endif; ?>
</div></body></html>
