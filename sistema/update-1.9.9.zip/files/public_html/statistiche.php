<?php
/* Le mie letture: statistiche dell'anno, obiettivo, trofei, classifica di famiglia, importazione da Goodreads */
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/reading.php';
require_user();
$uid = current_uid();
if (!reading_ready()) {
    page_start('Statistiche', 'statistiche', array('back' => 'libreria.php'));
    echo '<div class="alert warn">Il database non è ancora aggiornato alla versione 1.6.</div>';
    page_end();
    exit;
}
$tab = in_array(get('v'), array('classifica', 'goodreads'), true) ? get('v') : 'mie';
$years = reading_years($uid);
$year = (int)get('anno') ? (int)get('anno') : (int)date('Y');
if ($year < 1900 || $year > (int)date('Y') + 1) {
    $year = (int)date('Y');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $a = post('action');
    if ($a === 'obiettivo') {
        $y = (int)post('anno');
        reading_goal_save($uid, $y, (int)post('books'));
        flash((int)post('books') > 0 ? 'Obiettivo ' . $y . ': ' . (int)post('books') . ' libri. Buone letture!' . reading_trophies_flash($uid) : 'Obiettivo ' . $y . ' tolto.');
        redirect('statistiche.php?anno=' . $y);
    }
    if ($a === 'gr_upload' || $a === 'gr_import' || $a === 'gr_cancel') {
        require_once APP_ROOT . '/inc/goodreads.php';
        if ($a === 'gr_cancel') {
            if (!empty($_SESSION['gr_token'])) {
                @unlink(gr_temp_path($uid, $_SESSION['gr_token']));
            }
            unset($_SESSION['gr_token']);
            redirect('statistiche.php?v=goodreads');
        }
        if ($a === 'gr_upload') {
            $f = isset($_FILES['csv']) ? $_FILES['csv'] : null;
            if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 20 * 1048576) {
                flash('Scegli il file goodreads_library_export.csv (al massimo 20 MB).', 'error');
                redirect('statistiche.php?v=goodreads');
            }
            list($rows, $err) = gr_parse($f['tmp_name']);
            if ($err !== '') {
                flash($err, 'error');
                redirect('statistiche.php?v=goodreads');
            }
            $rows = gr_match($rows);
            $token = bin2hex(random_bytes(8));
            if (!is_dir(DATA_DIR . '/uploads')) {
                @mkdir(DATA_DIR . '/uploads', 0775, true);
            }
            file_put_contents(gr_temp_path($uid, $token), json_encode($rows));
            $_SESSION['gr_token'] = $token;
            redirect('statistiche.php?v=goodreads');
        }
        $token = isset($_SESSION['gr_token']) ? $_SESSION['gr_token'] : '';
        $path = $token !== '' ? gr_temp_path($uid, $token) : '';
        $rows = $path !== '' && is_file($path) ? json_decode((string)file_get_contents($path), true) : null;
        if (!is_array($rows)) {
            flash('Carica di nuovo il file di Goodreads.', 'error');
            redirect('statistiche.php?v=goodreads');
        }
        @set_time_limit(300);
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $res = gr_import($uid, gr_match($rows), array('add_missing' => post('add_missing') === '1' && can_edit(), 'toread' => post('toread') === '1'));
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            flash('Importazione non riuscita: ' . $e->getMessage(), 'error');
            redirect('statistiche.php?v=goodreads');
        }
        @unlink($path);
        unset($_SESSION['gr_token']);
        app_log('goodreads_import', 'Letture importate da Goodreads: ' . $res['reads'] . ' letture, ' . $res['current'] . ' in corso, ' . $res['toread'] . ' da leggere, '
            . $res['created'] . ' libri aggiunti in libreria');
        flash('Importazione completata: ' . $res['reads'] . ' letture, ' . $res['current'] . ' in corso, ' . $res['toread'] . ' da leggere'
            . ($res['created'] ? ', ' . $res['created'] . ' libri aggiunti alla libreria' : '') . ($res['already'] ? ' (' . $res['already'] . ' erano già nel diario)' : '')
            . ($res['skipped'] ? '. ' . $res['skipped'] . ' libri saltati perché non sono in libreria' : '') . '.' . reading_trophies_flash($uid));
        redirect('statistiche.php');
    }
}

$mesi = array('Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic');
$fmt = function ($n, $dec = 0) { return number_format($n, $dec, ',', '.'); };
$dmy = function ($d) { return date('d/m/Y', strtotime($d)); };
$mini = function ($s, $extra = '') {
    $b = array('id' => $s['book_id'], 'title' => $s['title'], 'authors' => $s['authors'], 'cover_file' => $s['cover_file'], 'isbn13' => $s['isbn13']);
    return '<a class="minibook" href="libro.php?id=' . (int)$s['book_id'] . '">' . book_cover_html($b, 'cover mini') . '<div><b>' . h($s['title']) . '</b><small>'
        . h($s['authors']) . '</small>' . $extra . '</div></a>';
};

page_start('Le mie letture', 'statistiche', array('back' => 'libreria.php'));
?>
<div class="st-tabs" role="tablist">
  <a href="statistiche.php?anno=<?= $year ?>" class="<?= $tab === 'mie' ? 'on' : '' ?>">Le mie statistiche</a>
  <a href="statistiche.php?v=classifica&amp;anno=<?= $year ?>" class="<?= $tab === 'classifica' ? 'on' : '' ?>">Classifica di famiglia</a>
  <a href="statistiche.php?v=goodreads" class="<?= $tab === 'goodreads' ? 'on' : '' ?>"><?= icon('cloud', 15) ?> Importa da Goodreads</a>
</div>

<?php if ($tab !== 'goodreads'): ?>
<nav class="yearpick" aria-label="Anno">
  <?php foreach ($years as $y): ?><a href="statistiche.php?<?= $tab === 'classifica' ? 'v=classifica&amp;' : '' ?>anno=<?= $y ?>" class="<?= $y === $year ? 'on' : '' ?>"><?= $y ?></a><?php endforeach; ?>
</nav>
<?php endif; ?>

<?php if ($tab === 'mie'):
    $s = reading_stats($uid, $year);
    $is_now = $year === (int)date('Y');
?>
<?php if (!$s['all_books'] && !$s['reading_now']): ?>
<div class="card gr-cta">
  <div class="ct">Usi Goodreads?</div>
  <p class="hint" style="margin-top:0">Porta qui in un colpo solo i libri che hai già letto, con date, voti e recensioni: le statistiche partono subito con la tua storia.</p>
  <a class="btn primary" href="statistiche.php?v=goodreads"><?= icon('cloud', 18) ?> Importa da Goodreads</a>
</div>
<?php endif; ?>
<div class="kgrid">
  <div class="kbox"><b><?= $fmt($s['books']) ?></b><span>libri letti nel <?= $year ?></span></div>
  <div class="kbox"><b><?= $fmt($s['pages']) ?></b><span>pagine lette</span></div>
  <div class="kbox"><b><?= $fmt($s['days_read']) ?></b><span>giorni di lettura</span></div>
  <div class="kbox"><b><?= $fmt($is_now ? $s['streak_now'] : $s['streak_best_year']) ?></b><span><?= $is_now ? 'giorni di fila (serie attuale)' : 'giorni di fila (serie migliore)' ?></span></div>
</div>

<form method="post" class="card">
  <?= csrf_field() ?><input type="hidden" name="action" value="obiettivo"><input type="hidden" name="anno" value="<?= $year ?>">
  <div class="ct">Obiettivo <?= $year ?></div>
  <?php if ($s['goal']): $gp = min(100, $s['books'] / $s['goal'] * 100); ?>
  <div class="goal-line"><b><?= $s['books'] ?> di <?= $s['goal'] ?> libri</b><span class="muted"><?= round($gp) ?>%</span></div>
  <div class="pbar"><i style="width:<?= round($gp, 1) ?>%"></i></div>
  <p class="hint"><?php
    if ($s['books'] >= $s['goal']) {
        echo '<b>Obiettivo raggiunto!</b>';
    } elseif ($is_now) {
        $diff = $s['goal_diff'];
        echo abs($diff) < 0.5 ? 'Sei in perfetto orario.' : ($diff > 0 ? 'Sei in anticipo di ' . $fmt(round($diff)) . ' ' . (round($diff) == 1 ? 'libro' : 'libri') . '.'
            : 'Sei indietro di ' . $fmt(round(-$diff)) . ' ' . (round(-$diff) == 1 ? 'libro' : 'libri') . ': ' . 'ne mancano ' . ($s['goal'] - $s['books']) . '.');
    } else {
        echo 'Non raggiunto: mancavano ' . ($s['goal'] - $s['books']) . ' libri.';
    } ?></p>
  <?php else: ?>
  <p class="hint" style="margin-top:0">Quanti libri vuoi leggere nel <?= $year ?>? Come la "Reading Challenge" di Goodreads.</p>
  <?php endif; ?>
  <div class="row-btn" style="margin-top:10px"><input class="input" type="number" name="books" min="0" max="1000" value="<?= $s['goal'] ? $s['goal'] : '' ?>" placeholder="es. 24" aria-label="Libri da leggere">
    <button class="btn ghost small" type="submit"><?= $s['goal'] ? 'Cambia' : 'Imposta' ?></button></div>
</form>

<?php if ($is_now && $s['reading_now']): ?>
<div class="card">
  <div class="ct">Sto leggendo</div>
  <?php foreach ($s['reading_now'] as $r): $lp = reading_last_point($r['id']); $tp = (int)$r['book_pages'];
    $pc = $lp ? ($lp['percent'] !== null ? (float)$lp['percent'] : ($tp && $lp['page'] !== null ? $lp['page'] / $tp * 100 : 0)) : 0;
    echo $mini($r, '<small>' . ($lp && $lp['page'] !== null ? 'pagina ' . (int)$lp['page'] . ($tp ? ' di ' . $tp : '') : ($lp ? rating_text($pc) . '%' : 'appena iniziato')) . '</small><div class="pbar sm"><i style="width:' . min(100, round($pc, 1)) . '%"></i></div>');
  endforeach; ?>
</div>
<?php endif; ?>

<div class="card">
  <div class="ct">Pagine lette mese per mese</div>
  <?php $mx = max(1, max($s['months_pages'])); ?>
  <div class="mbars" role="img" aria-label="Pagine lette per mese nel <?= $year ?>">
    <?php foreach ($s['months_pages'] as $m => $p): ?>
    <div class="mb" title="<?= h($mesi[$m - 1]) ?>: <?= $fmt($p) ?> pagine, <?= $s['months_books'][$m] ?> libri finiti">
      <?php if ($s['months_books'][$m]): ?><em><?= $s['months_books'][$m] ?></em><?php endif; ?>
      <i style="height:<?= $p ? max(2, round($p / $mx * 100)) : 0 ?>%"></i><small><?= h(substr($mesi[$m - 1], 0, 1)) ?></small></div>
    <?php endforeach; ?>
  </div>
  <p class="hint">Il numero sopra la colonna indica i libri finiti in quel mese.</p>
</div>

<div class="card">
  <div class="ct">Il mio <?= $year ?> giorno per giorno</div>
  <div class="heat-wrap"><div class="heat" role="img" aria-label="Calendario delle pagine lette">
  <?php
    $t0 = mktime(12, 0, 0, 1, 1, $year);
    $start = $t0 - ((int)date('N', $t0) - 1) * 86400;
    $t1 = mktime(12, 0, 0, 12, 31, $year);
    for ($t = $start; $t <= $t1 + (7 - (int)date('N', $t1)) * 86400; $t += 86400) {
        $d = date('Y-m-d', $t);
        if ((int)date('Y', $t) !== $year) {
            echo '<i class="x"></i>';
            continue;
        }
        $p = isset($s['heat'][$d]) ? $s['heat'][$d] : 0;
        $l = $p <= 0 ? '' : ($p <= 15 ? 'l1' : ($p <= 40 ? 'l2' : ($p <= 80 ? 'l3' : 'l4')));
        echo '<i class="' . $l . '" title="' . h(date('d/m', $t)) . ': ' . $p . ' pagine"></i>';
    }
  ?>
  </div></div>
  <div class="heat-leg">meno <i style="background:var(--soft)"></i><i class="l1"></i><i class="l2"></i><i class="l3"></i><i class="l4"></i> più</div>
</div>

<div class="card facts">
  <div class="ct">Record e curiosità</div>
  <?php
    $facts = array();
    if ($s['best_week']) {
        $facts['Settimana in cui hai letto di più'] = $dmy($s['best_week']['from']) . ' – ' . $dmy($s['best_week']['to']) . ' · ' . $fmt($s['best_week']['pages']) . ' pagine';
    }
    if ($s['best_day']) {
        $facts['Giorno record'] = $dmy($s['best_day']['day']) . ' · ' . $fmt($s['best_day']['pages']) . ' pagine';
    }
    if ($s['top_book'] && $s['top_book']['book']) {
        $facts['Libro con più pagine lette nell\'anno'] = $s['top_book']['book']['title'] . ' · ' . $fmt($s['top_book']['pages']) . ' pagine';
    }
    if ($s['longest']) {
        $facts['Il libro più lungo'] = $s['longest']['title'] . ' · ' . $fmt($s['longest']['book_pages']) . ' pagine';
    }
    if ($s['fastest']) {
        $facts['Lettura più veloce'] = $s['fastest']['title'] . ' · ' . ($s['fastest']['days'] == 1 ? 'in un giorno' : 'in ' . $s['fastest']['days'] . ' giorni');
    }
    if ($s['avg_days']) {
        $facts['Tempo medio per finire un libro'] = $fmt($s['avg_days'], $s['avg_days'] < 10 ? 1 : 0) . ' giorni';
    }
    if ($s['pages']) {
        $facts['Media di pagine al giorno'] = $fmt($s['avg_day'], 1) . ' (' . $fmt($s['avg_reading_day']) . ' nei giorni in cui leggi)';
    }
    $facts['Serie migliore'] = $fmt($s['streak_best_year']) . ' giorni di fila nel ' . $year . ' · ' . $fmt($s['streak_best']) . ' in assoluto';
    if ($s['avg_rating']) {
        $facts['Voto medio'] = rating_text(round($s['avg_rating'], 2)) . ' su 5';
    }
    $facts['Da sempre'] = $fmt($s['all_books']) . ' libri letti · ' . $fmt($s['all_pages']) . ' pagine';
    foreach ($facts as $k => $v): ?>
    <div class="fact"><span><?= h($k) ?></span><b><?= h($v) ?></b></div>
  <?php endforeach; ?>
</div>

<?php if ($s['genres'] || $s['authors']): ?>
<div class="row2 two-cards">
  <div class="card"><div class="ct">Generi</div>
    <?php if (!$s['genres']): ?><p class="hint">I libri letti non hanno un genere.</p><?php endif; ?>
    <?php foreach ($s['genres'] as $g => $n): ?><div class="fact"><span><?= h($g) ?></span><b><?= $n ?></b></div><?php endforeach; ?></div>
  <div class="card"><div class="ct">Autori</div>
    <?php foreach ($s['authors'] as $g => $n): ?><div class="fact"><span><?= h($g) ?></span><b><?= $n ?></b></div><?php endforeach; ?></div>
</div>
<?php endif; ?>

<?php if ($s['top_rated']): ?>
<div class="card"><div class="ct">I preferiti del <?= $year ?></div>
  <?php foreach ($s['top_rated'] as $r) { echo $mini($r, stars_html($r['rating'])); } ?></div>
<?php endif; ?>

<div class="card"><div class="ct">Libri letti nel <?= $year ?> (<?= count($s['finished']) ?>)</div>
  <?php if (!$s['finished']): ?><p class="hint" style="margin-top:0">Ancora nessuno. Segna i libri come "Letto" dalla loro scheda o, per tanti libri insieme, da Gestione → Tutti i libri.
    Oppure <a class="link" href="statistiche.php?v=goodreads">importali da Goodreads</a>.</p><?php endif; ?>
  <?php foreach ($s['finished'] as $r) { echo $mini($r, '<small>finito il ' . h($dmy($r['finished_at'])) . ($r['book_pages'] ? ' · ' . (int)$r['book_pages'] . ' pagine' : '') . '</small>' . ($r['rating'] !== null ? stars_html($r['rating']) : '')); } ?>
</div>

<p class="hint" style="text-align:center;margin-top:16px"><a class="link" href="statistiche.php?v=goodreads">Importa le letture da Goodreads</a></p>

<div class="card"><div class="ct">I miei trofei</div>
  <div class="tlist">
  <?php $lv = reading_levels(); $medals = array('primo' => '1', 'libri_anno' => '📚', 'pagine' => '📖', 'serie' => '🔥', 'maratoneta' => '🏃', 'divoratore' => '🍽', 'esploratore' => '🧭', 'obiettivo' => '🎯', 'ritorno' => '↺', 'critico' => '✎');
  foreach (reading_trophies_board($uid) as $code => $t):
    $cls = $t['level'] ? 'l' . min(5, $t['levels'] === 1 ? 3 : $t['level']) : 'off'; ?>
    <div class="trophy <?= $cls ?>">
      <div class="medal" aria-hidden="true"><?= h($medals[$code]) ?></div>
      <b><?= h($t['name']) ?></b>
      <?php if ($t['level'] && $t['levels'] > 1): ?><span class="lvl"><?= h($lv[$t['level']]) ?></span><?php endif; ?>
      <small><?= h($t['next'] !== null ? ($t['level'] ? 'Prossimo: ' : '') . $t['text'] : $t['text']) ?></small>
      <?php if ($t['next'] !== null && $t['value'] > 0 && $t['next'] > 1): ?>
      <div class="pbar sm"><i style="width:<?= min(100, round($t['value'] / $t['next'] * 100)) ?>%"></i></div>
      <small><?= $fmt(min($t['value'], $t['next'])) ?> / <?= $fmt($t['next']) ?></small>
      <?php elseif ($t['date']): ?><small>il <?= h($dmy($t['date'])) ?></small><?php endif; ?>
    </div>
  <?php endforeach; ?>
  </div>
</div>

<?php elseif ($tab === 'classifica'):
    $rows = reading_leaderboard($year);
    $sort = in_array(get('per'), array('libri', 'pagine', 'giorni', 'serie', 'trofei'), true) ? get('per') : 'libri';
    $key = array('libri' => 'books', 'pagine' => 'pages', 'giorni' => 'days', 'serie' => 'streak', 'trofei' => 'trophies');
    $k = $key[$sort];
    usort($rows, function ($a, $b) use ($k) { return $b[$k] === $a[$k] ? ($b['pages'] - $a['pages']) : $b[$k] - $a[$k]; });
    $head = array('libri' => 'Libri', 'pagine' => 'Pagine', 'giorni' => 'Giorni', 'serie' => 'Serie', 'trofei' => 'Trofei');
?>
<div class="card">
  <div class="ct">Classifica di famiglia · <?= $year ?></div>
  <div class="lb-wrap"><table class="lb">
    <tr><th>Lettore</th><?php foreach ($head as $hk => $hv): ?><th><a href="statistiche.php?v=classifica&amp;anno=<?= $year ?>&amp;per=<?= $hk ?>" class="<?= $hk === $sort ? 'ok-text' : '' ?>" style="display:inline"><?= h($hv) ?><?= $hk === $sort ? ' ▾' : '' ?></a></th><?php endforeach; ?></tr>
    <?php foreach ($rows as $i => $r): ?>
    <tr class="<?= $r['uid'] === $uid ? 'me' : '' ?>">
      <td><span class="rank r<?= $i + 1 ?>"><?= $i + 1 ?></span><?= h($r['name']) ?><?= $r['goal'] ? '<small class="muted"> · obiettivo ' . $r['goal'] . '</small>' : '' ?></td>
      <td><?= $fmt($r['books']) ?></td><td><?= $fmt($r['pages']) ?></td><td><?= $fmt($r['days']) ?></td><td><?= $fmt($r['streak']) ?></td><td><?= $fmt($r['trophies']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <p class="hint">Libri finiti e pagine lette nel <?= $year ?>; "Serie" è la serie più lunga di giorni di lettura consecutivi dell'anno; i trofei sono quelli conquistati in tutto.
    Tocca un'intestazione per cambiare l'ordine.</p>
</div>

<?php else:
    require_once APP_ROOT . '/inc/goodreads.php';
    $token = isset($_SESSION['gr_token']) ? $_SESSION['gr_token'] : '';
    $rows = $token !== '' && is_file(gr_temp_path($uid, $token)) ? json_decode((string)file_get_contents(gr_temp_path($uid, $token)), true) : null;
?>
<?php if (!is_array($rows)): ?>
<form method="post" enctype="multipart/form-data" class="card stack">
  <?= csrf_field() ?><input type="hidden" name="action" value="gr_upload">
  <div class="ct">Porta qui le tue letture di Goodreads</div>
  <ol class="hint steps" style="margin-top:0;padding-left:18px;line-height:1.6">
    <li>Su <b>goodreads.com</b> (dal computer) apri <b>My Books</b> e, nella colonna a sinistra in basso, <b>Import and export</b>.</li>
    <li>Premi <b>Export Library</b>: dopo qualche istante compare il link <b>Your export</b>. Scarica il file <code>goodreads_library_export.csv</code>.</li>
    <li>Caricalo qui sotto: prima di importare vedrai un riepilogo.</li>
  </ol>
  <input class="input" type="file" name="csv" accept=".csv,text/csv" required>
  <button class="btn primary" type="submit">Carica e controlla</button>
  <p class="hint">Si importano solo le tue letture: libri letti con la data, voto e recensione, letture in corso e, se vuoi, i "da leggere".
    I libri si riconoscono in libreria dall'ISBN o da titolo e autore. Puoi ripetere l'importazione: le letture già presenti non vengono duplicate.</p>
</form>
<?php else: $sm = gr_summary($rows); ?>
<form method="post" class="card stack">
  <?= csrf_field() ?><input type="hidden" name="action" value="gr_import">
  <div class="ct">Riepilogo del file</div>
  <div class="fact"><span>Libri letti</span><b><?= $sm['read'] ?> (<?= $sm['read_dated'] ?> con la data)</b></div>
  <div class="fact"><span>In lettura</span><b><?= $sm['current'] ?></b></div>
  <div class="fact"><span>Da leggere</span><b><?= $sm['toread'] ?></b></div>
  <div class="fact"><span>Con voto · con recensione</span><b><?= $sm['rated'] ?> · <?= $sm['reviews'] ?></b></div>
  <div class="fact"><span>Trovati nella libreria di casa</span><b class="ok-text" style="display:inline"><?= $sm['found'] ?></b></div>
  <div class="fact"><span>Non presenti in libreria</span><b><?= $sm['missing'] ?></b></div>
  <?php if ($sm['missing']): ?>
  <details><summary class="hint" style="cursor:pointer">Vedi quelli non presenti</summary>
    <ul class="hint" style="padding-left:18px"><?php foreach ($sm['missing_list'] as $m): ?><li><?= h($m['title']) ?> – <?= h($m['author']) ?></li><?php endforeach; ?>
    <?php if ($sm['missing'] > count($sm['missing_list'])): ?><li>… e altri <?= $sm['missing'] - count($sm['missing_list']) ?></li><?php endif; ?></ul></details>
  <?php if (can_edit()): ?>
  <label class="check"><input type="checkbox" name="add_missing" value="1"><span>Aggiungi alla libreria anche i libri che non ci sono (con i dati di Goodreads, senza copertina)</span></label>
  <?php endif; ?>
  <?php endif; ?>
  <label class="check"><input type="checkbox" name="toread" value="1" checked><span>Importa anche i libri "da leggere"</span></label>
  <button class="btn primary" type="submit">Importa le mie letture</button>
</form>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="gr_cancel"><button class="btn link" type="submit">Annulla e carica un altro file</button></form>
<?php endif; ?>
<?php endif; ?>
<?php page_end(); ?>
