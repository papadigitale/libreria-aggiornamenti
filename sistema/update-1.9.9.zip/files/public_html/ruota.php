<?php
require_once dirname(__FILE__) . '/../CONF/bootstrap.php';
require_once APP_ROOT . '/inc/layout.php';
require_once APP_ROOT . '/inc/wheel.php';
require_user();

$uid = current_uid();
$u = current_user();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    if (post('action') === 'spin_del') {
        if (wheel_spin_remove($uid, (int)post('id'))) {
            flash('Libro tolto dalla lista: potrà uscire di nuovo dalla ruota.');
        }
    } elseif (post('action') === 'spins_clear') {
        wheel_spins_clear($uid);
        flash('Lista delle estrazioni svuotata: tutti i libri possono uscire di nuovo.');
    }
    redirect('ruota.php#estrazioni');
}
$ws = wheel_settings_get($uid);
$pool = wheel_pool($uid, $ws);
$history = wheel_history($uid, 200);
$excluded = db()->prepare('SELECT COUNT(*) FROM user_books WHERE user_id = ? AND wheel_excluded = 1');
$excluded->execute(array($uid));
$excluded = (int)$excluded->fetchColumn();
$manual_count = count(wheel_item_ids($uid));

$state = array(
    'settings' => $ws,
    'total' => count($pool),
    'items' => wheel_display($pool),
    'max' => WHEEL_MAX_SEGMENTS,
    'colors' => array(safe_color(setting('color_primary'), '#7a1f2b'), safe_color(setting('color_accent'), '#b8893b'),
        safe_color(setting('color_ink'), '#2b1d14'), safe_color(setting('color_soft'), '#efe2cb')),
);

function outcome_tag($h)
{
    if ($h['my_status'] === 'letto') {
        return array('Letto', 'done');
    }
    if ($h['outcome'] === 'in_lettura' || $h['my_status'] === 'in_lettura') {
        return array('In lettura', 'reading');
    }
    if ($h['outcome'] === 'escluso') {
        return array('Escluso', '');
    }
    return array('Estratto', '');
}

page_start(setting('wheel_title'), 'ruota');
$name = $u['display_name'] !== '' ? $u['display_name'] : $u['username'];
?>
<h1 class="h1"><?= h(setting('wheel_title')) ?></h1>
<div class="sub">La ruota di <?= h($name) ?> · <span data-count><?= count($pool) ?></span> <span data-count-label><?= count($pool) === 1 ? 'libro' : 'libri' ?></span> in gioco</div>

<div class="wheel-src" data-wheel-settings>
  <div class="seg" role="radiogroup" aria-label="Libri sulla ruota">
    <?php foreach (wheel_sources() as $k => $lab): ?>
    <label><input type="radio" name="source" value="<?= h($k) ?>" <?= $ws['source'] === $k ? 'checked' : '' ?>><span><?= h($lab) ?></span></label>
    <?php endforeach; ?>
  </div>
  <div class="row2 wheel-filters">
    <select class="input" name="category_id" aria-label="Genere">
      <option value="">Tutti i generi</option>
      <?php foreach (categories_all() as $c): ?>
      <option value="<?= (int)$c['id'] ?>" <?= (int)$ws['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="input" name="max_pages" aria-label="Lunghezza">
      <option value="">Qualsiasi lunghezza</option>
      <?php foreach (array(150, 200, 300, 400, 500, 700) as $p): ?>
      <option value="<?= $p ?>" <?= (int)$ws['max_pages'] === $p ? 'selected' : '' ?>>Fino a <?= $p ?> pagine</option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn ghost pick-btn" type="button" data-open-picker <?= $ws['source'] === 'manual' ? '' : 'hidden' ?>>
    <?= icon('edit', 16) ?> <span>Scegli i libri della ruota (<b data-manual-count><?= $manual_count ?></b>)</span></button>
</div>

<div class="stage" data-stage>
  <svg class="pointer" viewBox="0 0 34 46" aria-hidden="true"><circle cx="17" cy="12" r="11" class="p-fill"/><path d="M7.5 17 L17 44 L26.5 17 Z" class="p-fill"/><circle cx="17" cy="12" r="4" class="p-dot"/></svg>
  <div class="ring"></div>
  <canvas aria-label="Ruota con i titoli dei libri" role="img"></canvas>
  <button class="hub" type="button" data-spin aria-label="Gira la ruota"><?= icon('books', 30) ?></button>
  <div class="stage-empty" data-empty hidden></div>
</div>
<p class="hint wheel-note" data-sample-note hidden>Ci sono più di <?= WHEEL_MAX_SEGMENTS ?> libri: la ruota ne mostra <?= WHEEL_MAX_SEGMENTS ?> scelti a caso, ma l'estrazione è fatta su tutti.</p>

<button class="btn primary spin-btn" type="button" data-spin><?= icon('spin', 20) ?> <?= h(setting('wheel_spin_btn')) ?></button>
<p class="hint center">Oppure tocca il centro della ruota</p>

<div class="sechead" id="estrazioni"><span>Ultime estrazioni<?= $history ? ' (' . count($history) . ')' : '' ?></span>
  <?php if ($excluded > 0): ?><a class="link" href="libreria.php?stato=esclusi">Esclusi (<?= $excluded ?>)</a><?php endif; ?></div>
<?php if ($history): ?><p class="hint" style="margin-top:-4px">I libri di questa lista non escono più dalla ruota. Toccando ✕ un libro torna tra quelli che possono essere estratti.</p><?php endif; ?>
<div class="hist" data-history>
  <?php if (!$history): ?><p class="sub">Qui comparirà lo storico delle tue estrazioni.</p><?php endif; ?>
  <?php foreach ($history as $hrow): $t = outcome_tag($hrow); ?>
  <div class="hrow-wrap">
  <a class="hrow" href="libro.php?id=<?= (int)$hrow['book_id'] ?>">
    <?= book_cover_html($hrow, 'cover mini') ?>
    <span class="htext"><b><?= h($hrow['title']) ?></b><small><?= h($hrow['authors']) ?> · <?= h(date('d/m', strtotime($hrow['created_at']))) ?></small></span>
    <span class="tag <?= h($t[1]) ?>"><?= h($t[0]) ?></span>
  </a>
  <form method="post" class="hdel" data-confirm="Togliere &quot;<?= h($hrow['title']) ?>&quot; dalla lista? Potrà uscire di nuovo dalla ruota.">
    <?= csrf_field() ?><input type="hidden" name="action" value="spin_del"><input type="hidden" name="id" value="<?= (int)$hrow['id'] ?>">
    <button class="iconbtn sm" type="submit" aria-label="Togli dalla lista" title="Togli dalla lista"><?= icon('x', 15) ?></button></form>
  </div>
  <?php endforeach; ?>
</div>
<?php if (count($history) > 1): ?>
<form method="post" data-confirm="Svuotare tutta la lista? Tutti i libri potranno uscire di nuovo dalla ruota."><?= csrf_field() ?><input type="hidden" name="action" value="spins_clear">
  <button class="btn link" type="submit">Svuota la lista</button></form>
<?php endif; ?>

<!-- Risultato dell'estrazione -->
<div class="veil" data-veil></div>
<div class="sheet" data-result role="dialog" aria-modal="true" aria-labelledby="res-title">
  <div class="grab"></div>
  <div class="eyebrow">La ruota ha scelto</div>
  <h2 class="h2 center" id="res-title" data-r="t"></h2>
  <div class="res">
    <div data-r="cover"></div>
    <div class="fields">
      <div class="fr"><span class="fk">Autore</span><span class="fv" data-r="a"></span></div>
      <div class="fr"><span class="fk">Pagine</span><span class="fv" data-r="p"></span></div>
      <div class="fr"><span class="fk">Editore</span><span class="fv" data-r="e"></span></div>
      <div class="fr"><span class="fk">Anno edizione</span><span class="fv" data-r="y"></span></div>
    </div>
  </div>
  <button class="btn primary" type="button" data-outcome="in_lettura">Inizio a leggerlo</button>
  <button class="btn ghost" type="button" data-outcome="rigirata">Gira ancora</button>
  <button class="btn link" type="button" data-outcome="escluso">Escludi questo libro dalla mia ruota</button>
</div>

<!-- Scelta manuale dei libri -->
<div class="sheet tall" data-picker role="dialog" aria-modal="true" aria-label="Scegli i libri della ruota">
  <div class="grab"></div>
  <div class="picker-head">
    <h2 class="h2">Libri della mia ruota</h2>
    <div class="searchbox"><?= icon('search', 18) ?><input type="search" placeholder="Cerca nella libreria…" data-picker-q></div>
    <div class="chips" data-picker-filter>
      <button type="button" class="chip on" data-f="">Tutti</button>
      <button type="button" class="chip" data-f="nonletti">Non letti</button>
      <button type="button" class="chip" data-f="letto">Letti</button>
      <button type="button" class="chip" data-f="sel">Selezionati</button>
    </div>
  </div>
  <div class="picker-list" data-picker-list><p class="sub">Caricamento…</p></div>
  <div class="picker-foot">
    <button class="btn ghost" type="button" data-picker-all>Seleziona visibili</button>
    <button class="btn primary" type="button" data-picker-save><span>Salva (<b data-n>0</b>)</span></button>
  </div>
</div>

<script type="application/json" id="wheel-state"><?= json_encode($state, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?></script>
<?php page_end(array('js/ruota.js')); ?>
