<?php
/*
 * Posta per la Libreria di Casa: messaggi tra gli utenti del sito, in stile casella di posta.
 *  - Icona della busta accanto alla campanella, con il numero delle conversazioni da leggere.
 *  - Cartelle In arrivo, Inviati, Bozze, Archiviati, Cestino; selezione singola e multipla per archiviare, eliminare,
 *    segnare come da leggere o come letto. Ognuno ha le sue cartelle: quello che fa uno non cambia niente per gli altri.
 *  - Ogni conversazione si legge come una chat; si allegano un'immagine e un libro della libreria.
 *  - Tutti scrivono a una persona; Admin e Gestori anche a più persone (una conversazione a testa o di gruppo) o a tutti.
 *  - Avviso nella campanella e, con il plugin «Notifiche email», un'email (una sola per conversazione finché non la si legge).
 *  - «Consiglialo a…» nella scheda di ogni libro. Bozze salvate da sole mentre si scrive.
 *  - «Mi piace» (cuore) ai messaggi ricevuti, con avviso a chi li ha scritti (1.2.0).
 *  - Cestino svuotato a mano o dopo un numero di giorni scelto in Gestione → Plugin → Posta.
 */
require_once __DIR__ . '/dati.php';
require_once __DIR__ . '/pagine.php';

$plugin->on_activate(function ($plugin, $prima) {
    ps_crea_tabelle($plugin);
    ps_dir_img($plugin);
});

$plugin->on_remove(function ($plugin, $cancella) {
    if ($cancella) {
        foreach (array('conversazioni', 'partecipanti', 'messaggi', 'bozze', 'mipiace') as $t) {
            db()->exec('DROP TABLE IF EXISTS ' . ps_t($plugin, $t));
        }
        foreach ((array)glob(ps_dir_img($plugin) . '/*.{jpg,png}', GLOB_BRACE) as $f) {
            @unlink($f);
        }
    }
});

/* ---------------- Stile, script e busta ---------------- */

$ps_mie_pagine = function () use ($plugin) {
    $s = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '');
    return $s === 'plg.php' && get('p') === $plugin->id;
};

// La busta: preparata in un <template>, lo script la mette accanto alla campanella (niente JavaScript in linea)
$ps_busta = function () use ($plugin) {
    if (!is_user()) {
        return '';
    }
    $n = ps_non_lette($plugin, current_uid());
    $on = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '') === 'plg.php' && get('p') === $plugin->id;
    return '<template id="ps-busta-t"><a class="iconbtn ps-busta' . ($on ? ' on' : '') . '" href="' . h($plugin->site_url('posta')) . '" data-ps-busta aria-label="Posta' . ($n ? ': ' . $n . ' da leggere' : '') . '" title="Posta">'
        . ps_icona('mail', 21) . '<em class="bell-n" data-ps-busta-n' . ($n ? '' : ' hidden') . '>' . ($n > 99 ? '99+' : $n) . '</em></a></template>'
        . $plugin->js('file/busta.js');
};

$plugin->on('html_testa', function ($html) use ($plugin, $ps_mie_pagine) {
    if (!is_user()) {
        return $html;
    }
    return $html . $plugin->css('file/busta.css') . ($ps_mie_pagine() ? $plugin->css('file/stile.css') : '');
});
$plugin->on('admin_testa', function ($html) use ($plugin) {
    return is_user() ? $html . $plugin->css('file/busta.css') : $html;
});
$plugin->on('html_fondo', function ($html) use ($plugin, $ps_mie_pagine, $ps_busta) {
    return $html . $ps_busta() . ($ps_mie_pagine() && is_user() ? $plugin->js('file/posta.js') : '');
});
$plugin->on('admin_fondo', function ($html) use ($ps_busta) {
    return $html . $ps_busta();
});

/* ---------------- «Consiglialo a…» nella scheda del libro ---------------- */

$plugin->on('scheda_libro', function ($html, $libro) use ($plugin) {
    if (!is_user() || empty($libro['id']) || !ps_destinatari_possibili(current_uid())) {
        return $html;
    }
    return $html . '<div class="card ps-consiglia"><span>' . ps_icona('mail', 20) . '<span><b>Ti è piaciuto?</b><small>Mandalo a qualcuno nella Posta</small></span></span>'
        . '<a class="btn ghost small" href="' . h($plugin->site_url('scrivi', array('libro' => (int)$libro['id']))) . '">Consiglialo a…</a></div>';
});

/* ---------------- Pagine ---------------- */

$ps_salva = function ($plugin) {
    ps_salva($plugin);
};
$plugin->site_page('posta', 'Posta', function ($plugin) {
    ps_pagina_posta($plugin);
}, array('ruolo' => 'utente', 'salva' => $ps_salva));

$plugin->site_page('leggi', 'Posta', function ($plugin) {
    ps_pagina_leggi($plugin);
}, array('ruolo' => 'utente', 'salva' => $ps_salva));

$plugin->site_page('scrivi', 'Nuovo messaggio', function ($plugin) {
    ps_pagina_scrivi($plugin);
}, array('ruolo' => 'utente', 'salva' => $ps_salva));

$plugin->site_page('img', 'Immagine', function ($plugin) {
    ps_img($plugin);
}, array('ruolo' => 'utente', 'grezza' => true));

$plugin->admin_page('impostazioni', 'Posta', function ($plugin) {
    ps_pannello($plugin);
}, array('salva' => function ($plugin) {
    ps_pannello_salva($plugin);
}));

/* ---------------- Chiamate dello script ---------------- */

// numero sulla busta
$plugin->api('conta', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    session_write_close();
    return array('n' => ps_non_lette($plugin, current_uid()));
});

// ricerca di un libro da allegare
$plugin->api('libri', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    session_write_close();
    return array('libri' => ps_cerca_libri(get('q')));
});

// "mi piace" a un messaggio (1.2.0)
$plugin->api('mipiace', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    $r = ps_mipiace_cambia($plugin, current_uid(), (int)post('mid'));
    return $r[0] ? array('messo' => $r[1], 'n' => $r[2], 'nomi' => $r[3]) : array('ok' => false, 'error' => $r[1]);
}, array('metodo' => 'POST'));

// bozza salvata da sola mentre si scrive
$plugin->api('bozza', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    $uid = current_uid();
    $cid = (int)post('cid');
    if ($cid) {
        $p = ps_part($plugin, $cid, $uid);
        if (!$p || $p['cartella'] === 'eliminata') {
            return array('ok' => false);
        }
    }
    $possibili = ps_destinatari_possibili($uid);
    $dest = array();
    foreach (isset($_POST['a']) ? (array)$_POST['a'] : array() as $x) {
        if (isset($possibili[(int)$x])) {
            $dest[] = (int)$x;
        }
    }
    $tutti = can_edit() && post('tutti') === '1';
    $d = ps_dati_form();
    $bz = (int)post('bozza') ? ps_bozza($plugin, (int)post('bozza'), $uid) : null;
    $img = $bz && $bz['immagine'] && post('togli_img') !== '1' ? (string)$bz['immagine'] : '';
    $id = ps_bozza_salva($plugin, $uid, $bz ? $bz['id'] : 0, array('conv_id' => $cid, 'destinatari' => $tutti ? array() : $dest,
        'modo' => $tutti ? 'tutti' : (post('modo') === 'gruppo' ? 'gruppo' : 'separati'), 'oggetto' => $cid ? '' : $d['oggetto'], 'testo' => $d['testo'],
        'libro_id' => $d['libro'], 'immagine' => $img));
    return array('id' => $id);
}, array('metodo' => 'POST'));

/* ---------------- Lavoro quotidiano ---------------- */

$plugin->on('ogni_giorno', function () use ($plugin) {
    ps_manutenzione($plugin);
});
