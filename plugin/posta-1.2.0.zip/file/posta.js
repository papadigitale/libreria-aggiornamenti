// Posta: selezione dei messaggi, bozze salvate da sole, allegati (immagine e libro), destinatari, chat
(function () {
  'use strict';
  var cfg = {};
  try { cfg = JSON.parse(document.getElementById('app-config').textContent); } catch (e) { /* niente */ }
  var API = 'api.php?action=plg&p=posta&f=';
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  /* ---------- Elenco: selezione singola e multipla ---------- */
  $$('[data-ps-elenco]').forEach(function (f) {
    var tutti = $('[data-ps-tutti]', f);
    var caselle = $$('input[name="c[]"], input[name="b[]"]', f);
    var quanti = $('[data-ps-quanti]', f);
    function aggiorna() {
      var n = caselle.filter(function (c) { return c.checked; }).length;
      $$('[data-ps-azione]', f).forEach(function (b) { b.disabled = !n; });
      caselle.forEach(function (c) { c.closest('.ps-riga').classList.toggle('sel', c.checked); });
      if (tutti) { tutti.checked = n > 0 && n === caselle.length; tutti.indeterminate = n > 0 && n < caselle.length; }
      if (quanti) { quanti.textContent = n ? (n === 1 ? '1 selezionata' : n + ' selezionate') : ''; }
      f.classList.toggle('con-sel', n > 0);
    }
    if (tutti) {
      tutti.addEventListener('change', function () { caselle.forEach(function (c) { c.checked = tutti.checked; }); aggiorna(); });
    }
    caselle.forEach(function (c) { c.addEventListener('change', aggiorna); });
    aggiorna();
  });

  // conferma prima di eliminare per sempre
  $$('[data-ps-conferma-elimina]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      var s = e.submitter;
      if (s && s.value === 'elimina') {
        var n = $$('input[name="c[]"]', f).filter(function (c) { return c.type === 'hidden' || c.checked; }).length;
        if (!window.confirm('Eliminare per sempre ' + (n === 1 ? 'questa conversazione' : 'le ' + n + ' conversazioni selezionate') + '? Non la vedrai più (gli altri partecipanti la conservano).')) {
          e.preventDefault(); e.stopPropagation();
        }
      }
    });
  });

  /* ---------- Destinatari (Admin e Gestori) ---------- */
  var dest = $('[data-ps-dest]');
  if (dest) {
    var tutti = $('[data-ps-dest-tutti]', dest);
    var lista = $$('input[name="a[]"]', dest);
    var modo = $('[data-ps-modo]');
    var hint = $('[data-ps-modo-hint]');
    var filtro = $('[data-ps-dest-filtro]', dest);
    var aggiornaDest = function () {
      var n = lista.filter(function (c) { return c.checked; }).length;
      if (tutti) { lista.forEach(function (c) { c.disabled = tutti.checked; if (tutti.checked) { c.checked = true; } }); }
      if (modo) {
        modo.hidden = !(n > 1 || (tutti && tutti.checked));
        var g = $('input[name="modo"]:checked', modo);
        if (hint) {
          hint.textContent = g && g.value === 'gruppo'
            ? 'Una sola conversazione: tutti vedono il messaggio e le risposte di tutti.'
            : 'Ognuno riceve il suo messaggio e ti risponde in privato; negli Inviati trovi una conversazione per persona.';
        }
      }
    };
    lista.forEach(function (c) { c.addEventListener('change', aggiornaDest); });
    if (tutti) { tutti.addEventListener('change', function () { if (!tutti.checked) { lista.forEach(function (c) { c.checked = false; }); } aggiornaDest(); }); }
    $$('input[name="modo"]').forEach(function (r) { r.addEventListener('change', aggiornaDest); });
    if (filtro) {
      filtro.addEventListener('input', function () {
        var q = filtro.value.trim().toLowerCase();
        $$('.ps-dest-u', dest).forEach(function (l) { l.hidden = q !== '' && l.getAttribute('data-nome').indexOf(q) === -1; });
      });
    }
    aggiornaDest();
    // i campi disattivati non vengono inviati: con "Tutti" basta la casella Tutti
  }

  /* ---------- Moduli di scrittura: bozze, allegati ---------- */
  $$('[data-ps-form]').forEach(function (f) {
    var idBozza = $('[data-ps-bozza-id]', f);
    var salvata = $('[data-ps-salvata]', f);
    var timer = null, inCorso = null, inviando = false, cambiato = false;

    function salva() {
      timer = null;
      if (inviando || !cambiato) { return Promise.resolve(); }
      cambiato = false;
      var fd = new FormData(f);
      // "action" del modulo coprirebbe quello dell'indirizzo
      fd.delete('immagine'); fd.delete('op'); fd.delete('action'); fd.set('csrf', cfg.csrf || '');
      inCorso = fetch(API + 'bozza', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf || '' } })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.ok) {
            if (idBozza) { idBozza.value = j.id || 0; }
            if (salvata && j.id) { salvata.hidden = false; salvata.textContent = 'Bozza salvata'; clearTimeout(salvata._t); salvata._t = setTimeout(function () { salvata.hidden = true; }, 2500); }
          }
        }).catch(function () { cambiato = true; })
        .then(function () { inCorso = null; });
      return inCorso;
    }
    function presto() { cambiato = true; clearTimeout(timer); timer = setTimeout(salva, 1500); }
    f.addEventListener('input', function (e) { if (e.target.type !== 'file' && e.target.type !== 'search') { presto(); } });
    f.addEventListener('change', function (e) { if (e.target.type === 'checkbox' || e.target.type === 'radio' || e.target.tagName === 'SELECT') { presto(); } });
    window.addEventListener('pagehide', function () { if (timer && !inviando) { clearTimeout(timer); salva(); } });

    // all'invio: aspetta la bozza in corso (altrimenti tornerebbe dopo l'invio)
    f.addEventListener('submit', function (e) {
      if (e.defaultPrevented) { return; }
      clearTimeout(timer); timer = null;
      if (inCorso && !f._pronto) {
        e.preventDefault();
        var s = e.submitter;
        inCorso.then(function () { f._pronto = true; if (f.requestSubmit) { f.requestSubmit(s || undefined); } else { f.submit(); } });
        return;
      }
      inviando = true;
    });

    // immagine
    var file = $('[data-ps-file]', f);
    var chip = $('[data-ps-img-chip]', f);
    var prev = $('[data-ps-img-prev]', f);
    var nome = $('[data-ps-img-nome]', f);
    var togliCampo = $('[data-ps-img-togli-campo]', f);
    if (file && chip) {
      file.addEventListener('change', function () {
        var x = file.files && file.files[0];
        if (!x) { return; }
        if (x.size > 10 * 1048576) { window.alert('L\'immagine è troppo grande (massimo 10 MB).'); file.value = ''; return; }
        if (!/^image\/(jpeg|png|webp|gif)$/.test(x.type)) { window.alert('Puoi allegare solo foto e immagini JPEG, PNG, WebP o GIF.'); file.value = ''; return; }
        if (prev) { prev.src = URL.createObjectURL(x); }
        if (nome) { nome.textContent = x.name; }
        chip.hidden = false;
        if (togliCampo) { togliCampo.value = '0'; }
      });
      $('[data-ps-img-togli]', f).addEventListener('click', function () {
        file.value = ''; chip.hidden = true;
        if (togliCampo) { togliCampo.value = '1'; }
        presto();
      });
    }

    // libro
    var apri = $$('[data-ps-libro-apri]', f);
    var box = $('[data-ps-libro-box]', f);
    var q = $('[data-ps-libro-q]', f);
    var ris = $('[data-ps-libri]', f);
    var lchip = $('[data-ps-libro-chip]', f);
    var lid = $('[data-ps-libro-id]', f);
    var lnome = $('[data-ps-libro-nome]', f);
    if (box && q) {
      apri.forEach(function (b) { b.addEventListener('click', function () { box.hidden = !box.hidden; if (!box.hidden) { q.focus(); } }); });
      var tq = null;
      q.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); } if (e.key === 'Escape') { box.hidden = true; } });
      q.addEventListener('input', function () {
        clearTimeout(tq);
        tq = setTimeout(function () {
          var v = q.value.trim();
          if (v.length < 2) { ris.innerHTML = ''; return; }
          fetch(API + 'libri&q=' + encodeURIComponent(v), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
            ris.innerHTML = '';
            if (!j || !j.ok || !j.libri.length) { var p = document.createElement('p'); p.className = 'ps-nessuno'; p.textContent = 'Nessun libro trovato nella libreria.'; ris.appendChild(p); return; }
            j.libri.forEach(function (b) {
              var bt = document.createElement('button'); bt.type = 'button'; bt.className = 'ps-libro-ris';
              var c = document.createElement('span'); c.className = 'ps-mini';
              if (b.copertina) { var im = document.createElement('img'); im.src = b.copertina; im.alt = ''; c.appendChild(im); }
              var t = document.createElement('span'); var tb = document.createElement('b'); tb.textContent = b.titolo; t.appendChild(tb);
              if (b.autori) { var sm = document.createElement('small'); sm.textContent = b.autori; t.appendChild(sm); }
              bt.appendChild(c); bt.appendChild(t);
              bt.addEventListener('click', function () {
                lid.value = b.id; lnome.textContent = b.titolo; lchip.hidden = false; box.hidden = true; q.value = ''; ris.innerHTML = '';
                var ogg = $('[data-ps-oggetto]', f);
                if (ogg && ogg.value.trim() === '') { ogg.value = 'Ti consiglio «' + b.titolo + '»'; }
                presto();
              });
              ris.appendChild(bt);
            });
          }).catch(function () { /* fuori linea */ });
        }, 300);
      });
      $('[data-ps-libro-togli]', f).addEventListener('click', function () { lid.value = 0; lchip.hidden = true; presto(); });
    }

    // risposta: la casella cresce mentre si scrive; Ctrl+Invio invia
    $$('[data-ps-cresce]', f).forEach(function (t) {
      var cresci = function () { t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight + 2, 220) + 'px'; };
      t.addEventListener('input', cresci); cresci();
    });
    var testo = $('[data-ps-testo]', f);
    if (testo) {
      testo.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); if (f.requestSubmit) { f.requestSubmit(); } else { f.submit(); } }
      });
    }
  });

  /* ---------- "Mi piace" (cuore) ai messaggi ricevuti ---------- */
  function cuoreAggiorna(f, j) {
    var b = $('[data-ps-cuore]', f);
    if (!b) { return; }
    b.classList.toggle('pieno', j.messo);
    b.setAttribute('aria-pressed', j.messo ? 'true' : 'false');
    var i = $('i', b); if (i) { i.textContent = j.messo ? '♥' : '♡'; }
    var tit = j.n ? 'Piace a ' + j.nomi.map(function (x, k) { return x; }).join(', ') : 'Mi piace';
    b.title = tit;
    var n = $('[data-ps-cuore-n]', b);
    if (n) { n.hidden = j.n < 2; n.textContent = j.n; }
    var t = $('[data-ps-cuore-testo]', b);
    if (t) { t.textContent = j.messo ? (j.n > 1 ? 'Piace a te e ad altri ' + (j.n - 1) : 'Ti piace') : (j.n ? tit : 'Mi piace'); }
    if (j.messo) { b.classList.remove('batte'); void b.offsetWidth; b.classList.add('batte'); }
  }
  function cuoreInvia(f) {
    if (f._occupato) { return; }
    f._occupato = true;
    var fd = new FormData(); fd.append('csrf', cfg.csrf || ''); fd.append('mid', f.querySelector('input[name=mid]').value);
    fetch(API + 'mipiace', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf || '' } })
      .then(function (r) { return r.json(); }).then(function (j) { if (j && j.ok) { cuoreAggiorna(f, j); } })
      .catch(function () { /* fuori linea */ }).then(function () { f._occupato = false; });
  }
  $$('[data-ps-cuore-form]').forEach(function (f) {
    f.addEventListener('submit', function (e) { e.preventDefault(); e.stopPropagation(); cuoreInvia(f); });
  });
  // doppio tocco (o doppio clic) sul messaggio: mette il cuore, come su Instagram
  $$('[data-ps-doppio]').forEach(function (el) {
    var f = $('[data-ps-cuore-form]', el);
    if (!f) { return; }
    var ultimo = 0;
    var metti = function (e) {
      if (e && e.target.closest && e.target.closest('a, button, input, textarea, summary')) { return; }
      var b = $('[data-ps-cuore]', f);
      var pop = document.createElement('span'); pop.className = 'ps-cuore-pop'; pop.textContent = '♥'; el.appendChild(pop);
      setTimeout(function () { pop.remove(); }, 900);
      if (b && !b.classList.contains('pieno')) { cuoreInvia(f); }
    };
    el.addEventListener('dblclick', function (e) { metti(e); if (window.getSelection) { window.getSelection().removeAllRanges(); } });
    el.addEventListener('touchend', function (e) {
      var ora = Date.now();
      if (ora - ultimo < 320) { e.preventDefault(); metti(e); ultimo = 0; } else { ultimo = ora; }
    });
  });

  /* ---------- Conversazione: apri dai messaggi nuovi ---------- */
  var chat = $('[data-ps-chat]');
  if (chat) {
    var nuovi = $('[data-ps-nuovi]');
    if (chat.classList.contains('ps-mails')) {
      // posta classica: dal primo messaggio nuovo, o dall'ultimo se la conversazione è lunga
      var ultimo = $('[data-ps-ultimo]');
      var dove = nuovi || ($$('.ps-mail', chat).length > 2 ? ultimo : null);
      if (dove && dove.scrollIntoView) { dove.scrollIntoView({ block: 'start' }); }
    } else {
      var d = nuovi || $('[data-ps-fondo]');
      if (d && d.scrollIntoView) { d.scrollIntoView({ block: nuovi ? 'center' : 'end' }); }
    }
  }
})();
