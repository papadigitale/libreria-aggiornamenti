<?php
/*
 * Pagine della Lista dei desideri:
 *  - "mia"   : la propria lista (aggiunta, modifica, condivisione)          plg.php?p=lista-desideri&s=mia
 *  - "lista" : la lista di un altro, dentro il sito (&u=) o con il link (&t=) plg.php?p=lista-desideri&s=lista
 * Prefisso: ld_
 */

function ld_cuori($n, $max = 3)
{
    $n = max(1, min($max, (int)$n));
    return '<span class="ld-cuori" title="Priorità ' . $n . ' su ' . $max . '" aria-label="Priorità ' . $n . ' su ' . $max . '">'
        . str_repeat('<b>♥</b>', $n) . str_repeat('<i>♥</i>', $max - $n) . '</span>';
}

function ld_cover($plugin, $v, $token = '')
{
    if (!empty($v['copertina'])) {
        $p = array('i' => (int)$v['id']);
        if ($token !== '') {
            $p['t'] = $token;
        }
        return '<div class="ld-cop has-img"><img src="' . h($plugin->site_url('copertina', $p)) . '" alt="Copertina di ' . h($v['titolo']) . '" loading="lazy"></div>';
    }
    $c = cover_palette($v['titolo']);
    return '<div class="ld-cop typo" style="background:linear-gradient(160deg,' . $c[0] . ',' . $c[1] . ');color:' . $c[2] . '"><span>' . h(str_cut((string)$v['titolo'], 70)) . '</span></div>';
}

function ld_dettagli($v)
{
    $h = '<b class="ld-tit">' . h($v['titolo']) . '</b>';
    $sub = array_filter(array((string)$v['autori'], trim((string)$v['editore'] . ((string)$v['anno'] !== '' ? ' ' . $v['anno'] : ''))));
    if ($sub) {
        $h .= '<small class="ld-sub">' . h(implode(' · ', $sub)) . '</small>';
    }
    if (!empty($v['isbn13'])) {
        $h .= '<small class="ld-isbn">ISBN ' . h($v['isbn13']) . '</small>';
    }
    $h .= '<div class="ld-meta">' . ld_cuori($v['priorita']) . ((string)$v['prezzo'] !== '' ? '<span class="ld-prezzo">' . h($v['prezzo']) . '</span>' : '') . '</div>';
    if ((string)$v['nota'] !== '') {
        $h .= '<p class="ld-nota">' . nl2br(h($v['nota'])) . '</p>';
    }
    $l = ld_link_sicuro($v['link']);
    if ($l !== '') {
        $h .= '<a class="link ld-shop" href="' . h($l) . '" target="_blank" rel="noopener noreferrer nofollow">' . h(parse_url($l, PHP_URL_HOST)) . ' ↗</a>';
    }
    return $h;
}

/* ================= La mia lista ================= */

function ld_pagina_mia($plugin)
{
    $uid = current_uid();
    $lista = ld_lista($plugin, $uid);
    $voci = ld_voci($plugin, $uid);
    $back = $plugin->site_url('mia');
    echo '<h1 class="h1">La mia lista dei desideri</h1>'
        . '<p class="sub">I libri che vorresti. La vedi solo tu finché non la condividi, e non compare nella Libreria.</p>';

    // aggiunta: ISBN o titolo
    $q = trim((string)get('cerca'));
    echo '<div class="card ld-add"><form method="get" action="plg.php" class="ld-cerca"><input type="hidden" name="p" value="' . h($plugin->id) . '"><input type="hidden" name="s" value="mia">'
        . '<label class="lab" for="ld-q">Aggiungi un libro</label><div class="row-btn"><input class="input" id="ld-q" name="cerca" value="' . h($q) . '" placeholder="ISBN o titolo, anche con l\'autore" required minlength="2" maxlength="150">'
        . '<button class="btn primary" type="submit" data-ld-cerca>' . icon('search', 18) . ' Cerca</button></div></form>'
        . '<details class="ld-manuale"' . ($q !== '' ? '' : '') . '><summary>Non lo trovi? Scrivilo a mano</summary>'
        . $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="aggiungi_manuale"><input type="hidden" name="back" value="' . h($back) . '">'
        . '<div class="row2"><div><label class="lab">Titolo</label><input class="input" name="titolo" required maxlength="255"></div>'
        . '<div><label class="lab">Autore</label><input class="input" name="autori" maxlength="255"></div></div>'
        . '<button class="btn ghost small" type="submit">Aggiungi alla lista</button></form></details></div>';

    if ($q !== '') {
        ld_risultati($plugin, $q, $back);
    }

    // la lista
    $mod = (int)get('modifica');
    echo '<div class="sechead"><span>' . (count($voci) === 1 ? '1 libro' : count($voci) . ' libri') . ' nella lista</span></div>';
    if (!$voci) {
        echo '<div class="card"><p class="sub">La lista è vuota: cerca un libro qui sopra per aggiungerlo.</p></div>';
    }
    echo '<div class="ld-grid">';
    foreach ($voci as $v) {
        echo '<div class="card ld-voce" id="v' . (int)$v['id'] . '">' . ld_cover($plugin, $v) . '<div class="ld-info">' . ld_dettagli($v);
        $badge = array();
        if (ld_in_libreria($v)) {
            $badge[] = '<span class="tag ok">Già in libreria</span>';
        }
        if ((int)$lista['mostra_prenotati'] && $v['regalo_da']) {
            $badge[] = '<span class="tag gift">' . icon('gift', 13) . ' Qualcuno ci sta pensando</span>';
        }
        echo $badge ? '<div class="ld-badge">' . implode(' ', $badge) . '</div>' : '';
        echo '<details class="ld-mod"' . ($mod === (int)$v['id'] ? ' open' : '') . '><summary>Modifica</summary>' . $plugin->form_start('class="stack"')
            . '<input type="hidden" name="op" value="modifica"><input type="hidden" name="id" value="' . (int)$v['id'] . '"><input type="hidden" name="back" value="' . h($back) . '">'
            . '<label class="lab">Priorità</label><div class="seg ld-prio">';
        foreach (array(1 => 'Mi piacerebbe', 2 => 'Lo vorrei', 3 => 'Lo desidero tanto') as $k => $t) {
            echo '<label><input type="radio" name="priorita" value="' . $k . '"' . ((int)$v['priorita'] === $k ? ' checked' : '') . '><span><b class="ld-h">' . str_repeat('♥', $k) . '</b>&nbsp;' . h($t) . '</span></label>';
        }
        echo '</div><label class="lab">Nota (edizione, lingua, copertina rigida…)</label><textarea class="input" name="nota" rows="2" maxlength="500">' . h((string)$v['nota']) . '</textarea>'
            . '<div class="row2"><div><label class="lab">Dove si trova (link)</label><input class="input" type="url" name="link" maxlength="500" value="' . h((string)$v['link']) . '" placeholder="https://…"></div>'
            . '<div><label class="lab">Prezzo indicativo</label><input class="input" name="prezzo" maxlength="20" value="' . h((string)$v['prezzo']) . '" placeholder="es. 18 €"></div></div>'
            . '<button class="btn primary small" type="submit">Salva</button></form></details>';
        echo '<div class="ld-act">' . $plugin->form_start('class="ld-inline"') . '<input type="hidden" name="op" value="ricevuto"><input type="hidden" name="id" value="' . (int)$v['id'] . '"><input type="hidden" name="back" value="' . h($back) . '">'
            . '<button class="btn ghost small" type="submit">' . icon('check', 15) . ' Ricevuto</button></form>'
            . $plugin->form_start('class="ld-inline" data-confirm="Togliere «' . h($v['titolo']) . '» dalla lista?"') . '<input type="hidden" name="op" value="elimina"><input type="hidden" name="id" value="' . (int)$v['id'] . '"><input type="hidden" name="back" value="' . h($back) . '">'
            . '<button class="btn link small" type="submit">Togli</button></form></div>';
        echo '</div></div>';
    }
    echo '</div>';

    // ricevuti
    $ric = ld_voci($plugin, $uid, true);
    if ($ric) {
        echo '<details class="card ld-ricevuti"><summary>Ricevuti (' . count($ric) . ')</summary><ul class="ld-rlist">';
        foreach ($ric as $v) {
            $add = '';
            if (can_edit() && !ld_in_libreria($v)) {
                $add = '<a class="btn primary small" href="aggiungi.php?' . h(!empty($v['isbn13']) ? 'isbn=' . rawurlencode($v['isbn13']) : 'titolo=' . rawurlencode($v['titolo'])) . '">' . icon('plus', 15) . ' Aggiungi alla libreria</a>';
            } elseif (ld_in_libreria($v)) {
                $add = '<span class="tag ok">In libreria</span>';
            }
            echo '<li><span><b>' . h($v['titolo']) . '</b><small>' . h((string)$v['autori']) . ' · ricevuto il ' . h(date('d/m/Y', strtotime($v['ricevuto_il']))) . '</small></span><span class="ld-act">' . $add
                . $plugin->form_start('class="ld-inline"') . '<input type="hidden" name="op" value="rimetti"><input type="hidden" name="id" value="' . (int)$v['id'] . '"><input type="hidden" name="back" value="' . h($back) . '"><button class="btn link small" type="submit">Rimetti nella lista</button></form>'
                . $plugin->form_start('class="ld-inline"') . '<input type="hidden" name="op" value="elimina"><input type="hidden" name="id" value="' . (int)$v['id'] . '"><input type="hidden" name="back" value="' . h($back) . '"><button class="btn link small" type="submit">Elimina</button></form></span></li>';
        }
        echo '</ul></details>';
    }

    ld_box_condivisione($plugin, $uid, $lista, $back);

    // liste degli altri
    $altre = ld_condivise_con_me($plugin, $uid);
    echo '<div class="card"><div class="ct">' . icon('heart', 18) . ' Liste condivise con te</div>';
    if (!$altre) {
        echo '<p class="sub">Nessuno ha ancora condiviso la sua lista con te.</p>';
    } else {
        echo '<p class="sub">Apri una lista e premi «Lo regalo io» sul libro che vuoi regalare: gli altri lo vedranno prenotato, il festeggiato no.</p><ul class="ld-altre">';
        foreach ($altre as $u) {
            echo '<li><a href="' . h($plugin->site_url('lista', array('u' => (int)$u['id']))) . '"><span class="ld-av">' . h(mb_strtoupper(mb_substr(ld_nome($u), 0, 1, 'UTF-8'), 'UTF-8')) . '</span>'
                . '<span><b>' . h(ld_nome($u)) . '</b><small>' . ($u['n'] === 1 ? '1 libro' : $u['n'] . ' libri') . '</small></span>' . icon('back', 16) . '</a></li>';
        }
        echo '</ul>';
    }
    echo '</div>';
}

// Risultati della ricerca online (ISBN o titolo)
function ld_risultati($plugin, $q, $back)
{
    require_once APP_ROOT . '/inc/lookup.php';
    $isbn = isbn_to13($q);
    if ($isbn !== '') {
        $r = lookup_isbn($isbn);
        $res = $r['ok'] ? array($r['book']) : array();
        $err = $r['ok'] ? '' : (isset($r['error']) ? $r['error'] : 'Nessun libro trovato con questo ISBN.');
    } else {
        $r = lookup_title($q);
        $res = $r['ok'] ? array_slice($r['results'], 0, 12) : array();
        $err = $r['ok'] ? '' : (isset($r['error']) ? $r['error'] : 'Nessun risultato.');
    }
    echo '<div class="card ld-ris"><div class="ct">Risultati per «' . h($q) . '»</div>';
    if (!$res) {
        echo '<p class="sub">' . h($err) . ' Puoi scriverlo a mano con «Non lo trovi?».</p></div>';
        return;
    }
    echo '<div class="ld-ris-list">';
    foreach ($res as $b) {
        $covers = array_slice(array_values(array_filter((array)$b['covers'])), 0, 4);
        echo '<div class="ld-ris-i">';
        if ($covers) {
            echo '<div class="ld-cop has-img"><img src="' . h($plugin->site_url('anteprima', array('u' => $covers[0]))) . '" alt="" loading="lazy"></div>';
        } else {
            $c = cover_palette($b['title']);
            echo '<div class="ld-cop typo" style="background:linear-gradient(160deg,' . $c[0] . ',' . $c[1] . ');color:' . $c[2] . '"><span>' . h(str_cut($b['title'], 60)) . '</span></div>';
        }
        $gia = ld_in_libreria(array('isbn13' => $b['isbn13'], 'titolo' => $b['title'], 'autori' => $b['authors']));
        echo '<div class="ld-info"><b class="ld-tit">' . h($b['title']) . '</b><small class="ld-sub">' . h(implode(' · ', array_filter(array($b['authors'], trim($b['publisher'] . ' ' . $b['year']))))) . '</small>'
            . ($b['isbn13'] !== '' ? '<small class="ld-isbn">ISBN ' . h($b['isbn13']) . '</small>' : '') . ($gia ? '<span class="tag ok">Già in libreria</span>' : '')
            . $plugin->form_start('class="ld-inline"') . '<input type="hidden" name="op" value="aggiungi"><input type="hidden" name="back" value="' . h($back) . '">';
        foreach (array('isbn13' => $b['isbn13'], 'titolo' => $b['title'], 'autori' => $b['authors'], 'editore' => $b['publisher'], 'anno' => $b['year']) as $k => $val) {
            echo '<input type="hidden" name="' . $k . '" value="' . h((string)$val) . '">';
        }
        echo '<input type="hidden" name="copertine" value="' . h(implode("\n", $covers)) . '"><button class="btn primary small" type="submit">' . icon('plus', 15) . ' Aggiungi alla lista</button></form></div></div>';
    }
    echo '</div></div>';
}

function ld_chiudi_sessione()
{
    // la ricerca online puo' durare qualche secondo: le altre pagine non devono restare in attesa
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
}

function ld_box_condivisione($plugin, $uid, $lista, $back)
{
    $con = ld_condivisa_con($plugin, $uid);
    $altri = ld_altri_utenti($uid);
    echo '<div class="card ld-share" id="condividi"><div class="ct">' . icon('link', 18) . ' Condividi la tua lista</div>';

    // dentro il sito
    echo $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="condividi"><input type="hidden" name="back" value="' . h($back . '#condividi') . '">'
        . '<div class="lab">Dentro il sito</div>'
        . '<label class="check switch"><input type="checkbox" name="tutti" value="1"' . ((int)$lista['tutti'] ? ' checked' : '') . ' data-ld-tutti><span>Con tutti gli utenti registrati</span></label>';
    if ($altri) {
        echo '<div class="ld-utenti" data-ld-utenti' . ((int)$lista['tutti'] ? ' hidden' : '') . '><small class="muted">…oppure solo con:</small>';
        foreach ($altri as $u) {
            echo '<label class="check"><input type="checkbox" name="con[]" value="' . (int)$u['id'] . '"' . (in_array((int)$u['id'], $con, true) ? ' checked' : '') . '> ' . h(ld_nome($u)) . '</label>';
        }
        echo '</div>';
    }
    echo '<label class="check"><input type="checkbox" name="mostra_prenotati" value="1"' . ((int)$lista['mostra_prenotati'] ? ' checked' : '') . '> Fammi vedere quali libri qualcuno ha già prenotato (senza dirmi chi). Lascialo spento per avere la sorpresa.</label>'
        . '<button class="btn ghost small" type="submit">Salva la condivisione</button></form>';

    // link segreto
    echo '<div class="ld-sep"></div><div class="lab">Con un link (WhatsApp, email, messaggi)</div>'
        . '<p class="hint">Chi riceve il link vede la lista anche senza account, in sola lettura: nient\'altro del sito. Chi ha un account può anche premere «Lo regalo io». Puoi cambiare o togliere il link quando vuoi.</p>';
    $tok = (string)$lista['token'];
    $scaduto = $tok !== '' && $lista['token_scade'] && $lista['token_scade'] < date('Y-m-d');
    if ($tok === '') {
        echo $plugin->form_start() . '<input type="hidden" name="op" value="link_crea"><input type="hidden" name="back" value="' . h($back . '#condividi') . '">'
            . '<button class="btn primary small" type="submit">' . icon('link', 15) . ' Crea il link</button></form>';
    } else {
        $url = ld_link_pubblico($plugin, $tok);
        $me = current_user();
        $testo = 'La mia lista dei desideri di libri' . ($me ? ' (' . ld_nome($me) . ')' : '') . ': ' . $url;
        echo '<div class="ld-link"><input class="input" readonly value="' . h($url) . '" data-ld-link aria-label="Link della lista">'
            . '<button class="btn ghost small" type="button" data-ld-copia>Copia</button></div>'
            . ($scaduto ? '<p class="alert error">Il link è scaduto il ' . h(date('d/m/Y', strtotime($lista['token_scade']))) . ': chi lo apre non vede più la lista. Cambia la scadenza o creane uno nuovo.</p>' : '')
            . '<div class="ld-share-btn"><a class="btn primary small ld-wa" href="https://wa.me/?text=' . h(rawurlencode($testo)) . '" target="_blank" rel="noopener noreferrer">Invia con WhatsApp</a>'
            . '<button class="btn ghost small" type="button" data-ld-condividi data-titolo="La mia lista dei desideri" data-testo="' . h($testo) . '" hidden>Condividi…</button></div>'
            . $plugin->form_start('class="ld-scad"') . '<input type="hidden" name="op" value="link_scadenza"><input type="hidden" name="back" value="' . h($back . '#condividi') . '">'
            . '<label class="lab" for="ld-scad">Il link vale fino al (vuoto = sempre)</label><div class="row-btn"><input class="input" type="date" id="ld-scad" name="scade" value="' . h((string)$lista['token_scade']) . '" min="' . date('Y-m-d') . '">'
            . '<button class="btn ghost small" type="submit">Salva</button></div></form>'
            . '<div class="ld-act">' . $plugin->form_start('class="ld-inline" data-confirm="Creare un link nuovo? Quello vecchio smetterà di funzionare."') . '<input type="hidden" name="op" value="link_crea"><input type="hidden" name="back" value="' . h($back . '#condividi') . '">'
            . '<button class="btn link small" type="submit">Cambia il link</button></form>'
            . $plugin->form_start('class="ld-inline" data-confirm="Togliere il link? Chi lo ha ricevuto non vedrà più la lista."') . '<input type="hidden" name="op" value="link_togli"><input type="hidden" name="back" value="' . h($back . '#condividi') . '">'
            . '<button class="btn link small danger" type="submit">Togli il link</button></form></div>';
    }
    echo '</div>';
}

function ld_salva_mia($plugin)
{
    $uid = current_uid();
    $op = post('op');
    $T = ld_t($plugin, 'voci');
    $mia = function () use ($plugin, $uid) {
        $v = ld_voce($plugin, (int)post('id'));
        return $v && (int)$v['user_id'] === $uid ? $v : null;
    };
    switch ($op) {
        case 'aggiungi':
        case 'aggiungi_manuale':
            if (ld_conta($plugin, $uid) >= LD_MAX_VOCI) {
                flash('La lista è piena (' . LD_MAX_VOCI . ' libri): togline qualcuno.', 'error');
                return;
            }
            $titolo = str_cut(trim(post('titolo')), 255);
            if ($titolo === '') {
                flash('Scrivi il titolo del libro.', 'error');
                return;
            }
            $isbn = $op === 'aggiungi' ? isbn_to13(post('isbn13')) : '';
            if ($isbn !== '') {
                $st = db()->prepare('SELECT COUNT(*) FROM ' . $T . ' WHERE user_id = ? AND isbn13 = ? AND ricevuto_il IS NULL');
                $st->execute(array($uid, $isbn));
                if ((int)$st->fetchColumn()) {
                    flash('«' . $titolo . '» è già nella tua lista.');
                    return;
                }
            }
            $cop = $op === 'aggiungi' ? ld_salva_copertina($plugin, preg_split('/\R/', (string)post('copertine'))) : '';
            $anno = preg_match('/^\d{4}$/', post('anno')) ? post('anno') : null;
            db()->prepare('INSERT INTO ' . $T . ' (user_id, isbn13, titolo, autori, editore, anno, copertina, priorita, created_at, updated_at) VALUES (?,?,?,?,?,?,?,2,?,?)')
                ->execute(array($uid, $isbn !== '' ? $isbn : null, $titolo, str_cut(trim(post('autori')), 255), str_cut(trim(post('editore')), 150), $anno, $cop !== '' ? $cop : null, now(), now()));
            $id = (int)db()->lastInsertId();
            flash('«' . $titolo . '» è nella tua lista dei desideri.');
            redirect($plugin->site_url('mia', array('modifica' => $id)) . '#v' . $id);
            break;
        case 'modifica':
            $v = $mia();
            if ($v) {
                $p = (int)post('priorita');
                db()->prepare('UPDATE ' . $T . ' SET priorita = ?, nota = ?, link = ?, prezzo = ?, updated_at = ? WHERE id = ?')
                    ->execute(array($p >= 1 && $p <= 3 ? $p : 2, str_cut(trim(str_replace("\r", '', post('nota'))), 500), ld_link_sicuro(post('link')),
                        str_cut(trim(post('prezzo')), 20), now(), (int)$v['id']));
                flash('Salvato.');
                redirect($plugin->site_url('mia') . '#v' . (int)$v['id']);
            }
            break;
        case 'ricevuto':
            $v = $mia();
            if ($v) {
                db()->prepare('UPDATE ' . $T . ' SET ricevuto_il = ?, updated_at = ? WHERE id = ?')->execute(array(now(), now(), (int)$v['id']));
                flash('Che bello! «' . $v['titolo'] . '» è tra i ricevuti' . (can_edit() && !ld_in_libreria($v) ? ': da lì puoi aggiungerlo alla libreria.' : '.'));
            }
            break;
        case 'rimetti':
            $v = $mia();
            if ($v) {
                db()->prepare('UPDATE ' . $T . ' SET ricevuto_il = NULL, regalo_da = NULL, regalo_il = NULL, updated_at = ? WHERE id = ?')->execute(array(now(), (int)$v['id']));
                flash('«' . $v['titolo'] . '» è di nuovo nella lista.');
            }
            break;
        case 'elimina':
            $v = $mia();
            if ($v) {
                ld_cancella_copertina($plugin, $v['copertina']);
                db()->prepare('DELETE FROM ' . $T . ' WHERE id = ?')->execute(array((int)$v['id']));
                flash('«' . $v['titolo'] . '» tolto dalla lista.');
            }
            break;
        case 'condividi':
            $tutti = post('tutti') === '1' ? 1 : 0;
            $prima_l = ld_lista($plugin, $uid);
            $prima = (int)$prima_l['tutti'] ? array_map(function ($u) { return (int)$u['id']; }, ld_altri_utenti($uid)) : ld_condivisa_con($plugin, $uid);
            ld_lista_salva($plugin, $uid, array('tutti' => $tutti, 'mostra_prenotati' => post('mostra_prenotati') === '1' ? 1 : 0));
            $C = ld_t($plugin, 'condivisioni');
            db()->prepare('DELETE FROM ' . $C . ' WHERE owner_id = ?')->execute(array($uid));
            $validi = array_map(function ($u) { return (int)$u['id']; }, ld_altri_utenti($uid));
            $n = 0;
            if (!$tutti && isset($_POST['con']) && is_array($_POST['con'])) {
                $ins = db()->prepare('INSERT INTO ' . $C . ' (owner_id, user_id, created_at) VALUES (?,?,?)');
                foreach (array_unique(array_map('intval', $_POST['con'])) as $u) {
                    if (in_array($u, $validi, true)) {
                        $ins->execute(array($uid, $u, now()));
                        $n++;
                    }
                }
            }
            // avviso nella campanella di chi la vede per la prima volta (Libreria 1.9.14 o successiva)
            $ora = $tutti ? $validi : ld_condivisa_con($plugin, $uid);
            $nuovi = array_values(array_diff($ora, $prima));
            if ($nuovi && method_exists($plugin, 'notifica') && ld_conta($plugin, $uid) > 0) {
                $me = current_user();
                $plugin->notifica(ld_nome($me) . ' ha condiviso con te la sua lista dei desideri', $plugin->site_url('lista', array('u' => $uid)),
                    array('to' => $nuovi, 'actor' => $uid, 'gruppo' => 'lista:' . $uid, 'sostituisci' => true));
            }
            flash($tutti ? 'La tua lista è visibile a tutti gli utenti registrati.' : ($n ? 'Lista condivisa con ' . ($n === 1 ? '1 persona' : $n . ' persone') . '.' : 'La tua lista non è condivisa con nessuno dentro il sito.'));
            break;
        case 'link_crea':
            ld_lista_salva($plugin, $uid, array('token' => ld_nuovo_token()));
            $plugin->log('Nuovo link della lista dei desideri');
            flash('Ecco il link della tua lista: mandalo a chi vuoi.');
            break;
        case 'link_togli':
            ld_lista_salva($plugin, $uid, array('token' => null, 'token_scade' => null));
            flash('Link tolto: chi lo aveva non vede più la lista.');
            break;
        case 'link_scadenza':
            $d = post('scade');
            $ok = preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && strtotime($d) !== false;
            ld_lista_salva($plugin, $uid, array('token_scade' => $ok ? $d : null));
            flash($ok ? 'Il link vale fino al ' . date('d/m/Y', strtotime($d)) . '.' : 'Il link vale sempre, finché non lo togli.');
            break;
    }
}

/* ================= La lista di un altro (dentro il sito o con il link) ================= */

function ld_pagina_lista($plugin)
{
    $token = (string)get('t');
    $viewer = is_user() ? current_uid() : 0;
    if ($token !== '') {
        $owner = ld_token_proprietario($plugin, $token);
        if (!$owner) {
            $plugin->tentativo_errato();
            http_response_code(404);
            echo '<div class="card ld-404"><div class="ct">Lista non disponibile</div><p class="sub">Il link non è valido, è scaduto oppure è stato tolto da chi te lo ha mandato. Chiedigliene uno nuovo.</p></div>';
            return;
        }
    } else {
        if (!$viewer) {
            redirect('index.php');
        }
        $owner = (int)get('u');
        if ($owner === $viewer) {
            redirect($plugin->site_url('mia'));
        }
        if (!ld_puo_vedere($plugin, $owner, $viewer)) {
            echo '<div class="card"><div class="ct">Lista non disponibile</div><p class="sub">Questa lista non è condivisa con te.</p>'
                . '<a class="btn ghost small" href="' . h($plugin->site_url('mia')) . '">Torna alla tua lista</a></div>';
            return;
        }
    }
    $u = ld_utente($owner);
    $voci = ld_voci($plugin, $owner);
    $proprietario = $viewer === $owner;
    // "Lo regalo io": chi ha un account e non e' il festeggiato
    $puo_regalare = $viewer && !$proprietario;
    $back = $plugin->site_url('lista', $token !== '' ? array('t' => $token) : array('u' => $owner));
    if ($viewer && $token === '') {
        echo '<p><a class="link" href="' . h($plugin->site_url('mia')) . '">← La mia lista</a></p>';
    }
    echo '<h1 class="h1">I desideri di ' . h(ld_nome($u)) . '</h1>';
    if ($proprietario) {
        echo '<div class="alert">Questa è la tua lista, come la vede chi riceve il link. <a class="link" href="' . h($plugin->site_url('mia')) . '">Modificala</a></div>';
    } elseif ($puo_regalare) {
        echo '<p class="sub">Premi «Lo regalo io» sul libro che vuoi regalare: gli altri lo vedranno prenotato, ' . h(ld_nome($u)) . ' no.</p>';
    } else {
        echo '<p class="sub">Vuoi regalare uno di questi libri? Accordati con chi ti ha mandato il link: i libri già prenotati da qualcuno sono segnati.</p>';
    }
    if (!$voci) {
        echo '<div class="card"><p class="sub">Per ora la lista è vuota.</p></div>';
        return;
    }
    echo '<div class="ld-grid">';
    foreach ($voci as $v) {
        $mio = $viewer && (int)$v['regalo_da'] === $viewer;
        echo '<div class="card ld-voce' . ($v['regalo_da'] && !$proprietario ? ' preso' : '') . '">' . ld_cover($plugin, $v, $token) . '<div class="ld-info">' . ld_dettagli($v);
        if (!$proprietario) {
            if ($mio) {
                echo '<div class="ld-gift mine">' . icon('gift', 15) . ' Lo regali tu</div>';
            } elseif ($v['regalo_da']) {
                echo '<div class="ld-gift">' . icon('gift', 15) . ' Già prenotato' . ($viewer ? ' da ' . h(ld_nome(ld_utente($v['regalo_da']))) : '') . '</div>';
            }
            if ($puo_regalare && (!$v['regalo_da'] || $mio)) {
                echo $plugin->form_start('class="ld-inline"') . '<input type="hidden" name="op" value="' . ($mio ? 'annulla' : 'regalo') . '"><input type="hidden" name="id" value="' . (int)$v['id'] . '">'
                    . '<input type="hidden" name="t" value="' . h($token) . '"><input type="hidden" name="u" value="' . (int)$owner . '"><input type="hidden" name="back" value="' . h($back) . '">'
                    . '<button class="btn ' . ($mio ? 'link' : 'primary') . ' small" type="submit">' . ($mio ? 'Non lo regalo più' : icon('gift', 15) . ' Lo regalo io') . '</button></form>';
            }
        }
        echo '</div></div>';
    }
    echo '</div>';
    if (!$viewer) {
        echo '<p class="sub ld-foot">Hai un account su questo sito? <a class="link" href="index.php">Accedi</a> e poi riapri questo link per dire «Lo regalo io».</p>';
    }
}

function ld_salva_lista($plugin)
{
    $uid = current_uid();
    if (!is_user()) {
        return;
    }
    $v = ld_voce($plugin, (int)post('id'));
    if (!$v || $v['ricevuto_il'] || (int)$v['user_id'] === $uid) {
        return;
    }
    // stessa verifica della pagina: link valido oppure lista condivisa con chi preme
    $tok = (string)post('t');
    $ok = $tok !== '' ? ld_token_proprietario($plugin, $tok) === (int)$v['user_id'] : ld_puo_vedere($plugin, $v['user_id'], $uid);
    if (!$ok) {
        if ($tok !== '') {
            $plugin->tentativo_errato();
        }
        flash('Operazione non consentita.', 'error');
        return;
    }
    $T = ld_t($plugin, 'voci');
    if (post('op') === 'regalo') {
        $st = db()->prepare('UPDATE ' . $T . ' SET regalo_da = ?, regalo_il = ? WHERE id = ? AND regalo_da IS NULL');
        $st->execute(array($uid, now(), (int)$v['id']));
        flash($st->rowCount() ? 'Segnato: «' . $v['titolo'] . '» lo regali tu. Gli altri lo vedranno prenotato.' : 'Qualcuno lo ha appena prenotato.', $st->rowCount() ? 'success' : 'error');
    } elseif (post('op') === 'annulla') {
        db()->prepare('UPDATE ' . $T . ' SET regalo_da = NULL, regalo_il = NULL WHERE id = ? AND regalo_da = ?')->execute(array((int)$v['id'], $uid));
        flash('Prenotazione tolta: «' . $v['titolo'] . '» è di nuovo libero.');
    }
}

/* ================= Immagini ================= */

// Copertina salvata: la vede chi puo' vedere la lista (dentro il sito o con il link)
function ld_copertina($plugin)
{
    $v = ld_voce($plugin, (int)get('i'));
    $ok = false;
    if ($v) {
        $tok = (string)get('t');
        if ($tok !== '') {
            $ok = ld_token_proprietario($plugin, $tok) === (int)$v['user_id'];
            if (!$ok) {
                $plugin->tentativo_errato('copertina');
            }
        } elseif (is_user()) {
            $ok = ld_puo_vedere($plugin, $v['user_id'], current_uid());
        }
    }
    $f = $ok && $v['copertina'] && preg_match('/^c[a-f0-9]{20}\.jpg$/', $v['copertina']) ? ld_dir_copertine($plugin) . '/' . $v['copertina'] : '';
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if ($f === '' || !is_file($f)) {
        header('HTTP/1.1 404 Not Found');
        return;
    }
    ld_chiudi_sessione();
    header('Content-Type: image/jpeg');
    header('Content-Length: ' . filesize($f));
    header('Cache-Control: private, max-age=86400');
    header('X-Content-Type-Options: nosniff');
    readfile($f);
}

// Anteprima delle copertine trovate online (solo dai siti di copertine conosciuti)
function ld_anteprima($plugin)
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    $u = (string)get('u');
    if (!is_user() || !preg_match('#^https?://#i', $u) || strlen($u) > 600) {
        header('HTTP/1.1 404 Not Found');
        return;
    }
    ld_chiudi_sessione();
    $r = http_get($u, setting_int('lookup_timeout', 3, 30), 6291456, 'trusted');
    $info = (int)$r['code'] === 200 ? @getimagesizefromstring($r['body']) : false;
    if (!$info || !in_array($info['mime'], array('image/jpeg', 'image/png', 'image/gif', 'image/webp'), true)) {
        header('HTTP/1.1 404 Not Found');
        return;
    }
    header('Content-Type: ' . $info['mime']);
    header('Cache-Control: private, max-age=86400');
    header('X-Content-Type-Options: nosniff');
    echo $r['body'];
}
