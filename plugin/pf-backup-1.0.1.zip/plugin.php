<?php
/*
 * PF Backup — backup completo del sito per la Libreria di Casa.
 *  - Fotografia di tutto: database intero (anche le tabelle dei plugin) e tutti i file dei dati (copertine, logo, sfondi, media,
 *    plugin e loro dati), con i programmi del sito come opzione. Il ripristino rimette il sito com'era: utenti, aspetto, plugin, messaggi.
 *  - Backup a mano o pianificati (ogni 12 ore, giorno, settimana, 15 giorni, mese), sul server o su uno storage remoto:
 *    Google Drive, Dropbox, OneDrive, Amazon S3 e compatibili, FTP, SFTP, Nextcloud/WebDAV, cartella o NAS.
 *  - Password facoltativa (ZIP cifrato AES-256), copia di sicurezza automatica prima di ogni ripristino, log di ogni operazione.
 *  - Il backup del sito che c'era gia' (Gestione → Strumenti → Backup) resta com'e'.
 * Gestione → Plugin → PF Backup (solo Admin).
 */
require_once APP_ROOT . '/inc/crypto.php';
require_once __DIR__ . '/motore.php';
require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/pannello.php';

$plugin->on_activate(function ($plugin, $prima) {
    pfb_archivio($plugin);
    pfb_dir($plugin, 'log');
    pfb_dir($plugin, 'lavoro');
});

$plugin->on_remove(function ($plugin, $cancella) {
    if ($cancella) {
        // i backup vengono cancellati solo se l'Admin ha chiesto di togliere anche i dati del plugin
        foreach (array('archivio', 'log', 'lavoro', 'caricamenti') as $d) {
            foreach ((array)glob(pfb_dir($plugin, $d) . '/{,.}*', GLOB_BRACE) as $f) {
                if (is_file($f)) {
                    @unlink($f);
                }
            }
        }
    }
});

/* ---------------- Pagine ---------------- */

$plugin->admin_page('backup', 'PF Backup', function ($plugin) {
    pfb_pannello($plugin);
}, array('salva' => function ($plugin) {
    pfb_salva($plugin);
}));

$plugin->on('admin_testa', function ($html) use ($plugin) {
    return isset($_GET['sez']) && $_GET['sez'] === 'plg-' . $plugin->id . '-backup' ? $html . $plugin->css('file/stile.css') : $html;
});
$plugin->on('admin_fondo', function ($html) use ($plugin) {
    return isset($_GET['sez']) && $_GET['sez'] === 'plg-' . $plugin->id . '-backup' ? $html . $plugin->js('file/pfb.js') : $html;
});

// scaricare un backup dal server (solo Admin)
$plugin->site_page('scarica', 'Scarica il backup', function ($plugin) {
    pfb_scarica_file($plugin);
}, array('ruolo' => 'admin', 'grezza' => true));

/* ---------------- Lavori pianificati ---------------- */

$plugin->on('lavori_periodici', function ($da_cron) use ($plugin) {
    pfb_pianificati($plugin, (bool)$da_cron);
});

/* ---------------- Chiamate dal pannello (solo Admin) ---------------- */

// avvia un lavoro: risponde subito al browser e lavora dopo
$pfb_avvia = function ($plugin, $tipo, $titolo, $fn) {
    if (pfb_lock_occupato($plugin)) {
        return array('ok' => false, 'error' => 'C\'è già un backup o un ripristino in corso: aspetta che finisca.');
    }
    @file_put_contents(pfb_stato_file($plugin), json_encode(array('tipo' => $tipo, 'titolo' => $titolo, 'perc' => 0, 'testo' => 'Avvio…', 'finito' => 0,
        'aggiornato' => time(), 'inizio' => time())));
    pfb_rilascia(array('ok' => true, 'avviato' => true));
    pfb_esegui($plugin, $tipo, $titolo, $fn);
    exit;
};

$plugin->api('avvia', function ($plugin) use ($pfb_avvia) {
    $cont = in_array(post('contenuto'), array('completo', 'db', 'file'), true) ? post('contenuto') : 'completo';
    $dove = post('dove') === 'remoto' ? 'remoto' : 'locale';
    if ($dove === 'remoto' && !pfb_storage_attivo($plugin)) {
        return array('ok' => false, 'error' => 'Scegli prima uno storage remoto (scheda Storage remoto).');
    }
    $nomi = array('completo' => 'database e file', 'db' => 'solo database', 'file' => 'solo file');
    return $pfb_avvia($plugin, 'backup', 'Backup manuale (' . $nomi[$cont] . ')', function ($plugin) use ($cont, $dove) {
        return pfb_lavoro_backup($plugin, $cont, $dove, 'manuale');
    });
}, array('metodo' => 'POST', 'ruolo' => 'admin'));

$plugin->api('stato', function ($plugin) {
    session_write_close();
    $s = pfb_stato($plugin);
    return array('stato' => $s ? array_intersect_key($s, array_flip(array('tipo', 'titolo', 'perc', 'testo', 'finito', 'ok', 'errore', 'esito', 'log', 'inizio'))) : null);
}, array('ruolo' => 'admin'));

$plugin->api('ripristina', function ($plugin) use ($pfb_avvia) {
    $nome = (string)post('nome');
    $pw = (string)post('password_backup');
    $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
    $st->execute(array(current_uid()));
    $hash = (string)$st->fetchColumn();
    $st->closeCursor(); // con SQLite una lettura lasciata a meta' blocca le tabelle durante il ripristino
    unset($st);
    if (!password_verify((string)post('password_admin'), $hash)) {
        if (function_exists('fw_event')) {
            app_log('ripristino_password', 'Password sbagliata per il ripristino con PF Backup', 'warn');
        }
        return array('ok' => false, 'error' => 'La tua password non è corretta.');
    }
    if (!pfb_nome_ok($nome) || !is_file(pfb_archivio($plugin) . '/' . $nome)) {
        return array('ok' => false, 'error' => 'Backup non trovato sul server.');
    }
    if ($pw === '' && pfb_password($plugin) !== '') {
        $pw = pfb_password($plugin); // prima si prova la password impostata in questo sito
    }
    try {
        $m = pfb_leggi_manifest(pfb_archivio($plugin) . '/' . $nome, $pw);
    } catch (Exception $e) {
        return array('ok' => false, 'error' => $e->getMessage(), 'serve_password' => stripos($e->getMessage(), 'password') !== false || stripos($e->getMessage(), 'cifrato') !== false);
    }
    if (($perche = pfb_compatibile($m)) !== '') {
        return array('ok' => false, 'error' => $perche);
    }
    return $pfb_avvia($plugin, 'ripristino', 'Ripristino da ' . $nome, function ($plugin) use ($nome, $pw) {
        return pfb_ripristina($plugin, $nome, $pw);
    });
}, array('metodo' => 'POST', 'ruolo' => 'admin'));

$plugin->api('invia', function ($plugin) use ($pfb_avvia) {
    $nome = (string)post('nome');
    $s = pfb_storage_attivo($plugin);
    if (!$s) {
        return array('ok' => false, 'error' => 'Scegli prima uno storage remoto (scheda Storage remoto).');
    }
    if (!pfb_nome_ok($nome) || !is_file(pfb_archivio($plugin) . '/' . $nome)) {
        return array('ok' => false, 'error' => 'Backup non trovato sul server.');
    }
    return $pfb_avvia($plugin, 'invio', 'Invio di ' . $nome . ' a ' . pfb_storage_nome($s), function ($plugin) use ($nome, $s) {
        pfb_invia($plugin, $nome, $s);
        return $nome . ' copiato su ' . pfb_storage_nome($s) . '.';
    });
}, array('metodo' => 'POST', 'ruolo' => 'admin'));

$plugin->api('scarica_remoto', function ($plugin) use ($pfb_avvia) {
    $nome = (string)post('nome');
    $s = pfb_storage($plugin, (string)post('storage'));
    if (!$s || !pfb_nome_ok($nome)) {
        return array('ok' => false, 'error' => 'Storage o backup non validi.');
    }
    return $pfb_avvia($plugin, 'scaricamento', 'Scaricamento di ' . $nome . ' da ' . pfb_storage_nome($s), function ($plugin) use ($nome, $s) {
        pfb_scarica_da_storage($plugin, $s, $nome);
        return $nome . ' scaricato sul server: ora si può ripristinare.';
    });
}, array('metodo' => 'POST', 'ruolo' => 'admin'));

$plugin->api('elenco_remoto', function ($plugin) {
    session_write_close();
    $s = pfb_storage($plugin, (string)get('storage'));
    if (!$s) {
        return array('ok' => false, 'error' => 'Storage non trovato.');
    }
    try {
        $l = pfb_storage_call($plugin, $s, 'lista');
    } catch (Exception $e) {
        return array('ok' => false, 'error' => $e->getMessage());
    }
    $loc = pfb_locali($plugin);
    $out = array();
    foreach ($l as $n => $x) {
        $out[] = array('nome' => $n, 'dimensione' => $x['dimensione'] > 0 ? pfb_mb($x['dimensione']) : '—', 'data' => $x['data'] ? date('d/m/Y H:i', $x['data']) : '', 'sul_server' => isset($loc[$n]),
            'bloccato' => in_array($n, pfb_bloccati($plugin), true));
    }
    usort($out, function ($a, $b) { return strcmp($b['nome'], $a['nome']); });
    return array('backup' => $out, 'storage' => pfb_storage_nome($s));
}, array('ruolo' => 'admin'));

// caricamento di un backup a pezzi (anche file grandi, oltre i limiti di caricamento di PHP)
$plugin->api('carica', function ($plugin) {
    return pfb_carica_pezzo($plugin);
}, array('metodo' => 'POST', 'ruolo' => 'admin'));

// storage: prova e collegamento degli account
$plugin->api('storage', function ($plugin) {
    session_write_close();
    $s = pfb_storage($plugin, (string)post('id'));
    if (!$s) {
        return array('ok' => false, 'error' => 'Storage non trovato.');
    }
    try {
        switch (post('fai')) {
            case 'prova':
                return array('messaggio' => pfb_storage_call($plugin, $s, 'prova'));
            case 'avvia':
                if (!in_array($s['tipo'], array('gdrive', 'onedrive'), true)) {
                    break;
                }
                $a = pfb_storage_call($plugin, $s, 'avvia');
                return array('codice' => $a['codice'], 'url' => $a['url'], 'intervallo' => max(3, (int)$a['intervallo']));
            case 'verifica':
                if (!in_array($s['tipo'], array('gdrive', 'onedrive'), true)) {
                    break;
                }
                return array('collegato' => (bool)pfb_storage_call($plugin, $s, 'verifica'));
            case 'dropbox_link':
                return array('url' => pfb_dropbox_link($plugin, $s));
            case 'dropbox_codice':
                pfb_dropbox_codice($plugin, $s, (string)post('codice'));
                return array('collegato' => true);
        }
    } catch (Exception $e) {
        return array('ok' => false, 'error' => $e->getMessage());
    }
    return array('ok' => false, 'error' => 'Operazione non valida.');
}, array('metodo' => 'POST', 'ruolo' => 'admin'));

/* ---------------- Bacheca ---------------- */

// la Bacheca non segnala "nessun backup" se i backup li fa PF Backup
$plugin->on('ultimo_backup', function ($r) use ($plugin) {
    return pfb_ultimo_backup($plugin, $r);
});

