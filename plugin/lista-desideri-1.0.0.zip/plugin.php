<?php
/*
 * Lista dei desideri per la Libreria di Casa.
 *  - Ognuno ha la sua lista (menu ☰ → La mia lista dei desideri, e un riquadro in Il mio account). Non compare mai nella Libreria.
 *  - Si condivide dentro il sito (con tutti gli utenti registrati o con alcuni) e con un link segreto (WhatsApp, email…),
 *    che apre la lista in sola lettura anche senza account. Il link si cambia, si toglie e può scadere.
 *  - Chi ha un account preme «Lo regalo io»: gli altri vedono il libro prenotato, il festeggiato no.
 */
require_once __DIR__ . '/dati.php';
require_once __DIR__ . '/pagine.php';

$plugin->on_activate(function ($plugin, $prima) {
    ld_crea_tabelle($plugin);
});

$plugin->on_remove(function ($plugin, $cancella) {
    if ($cancella) {
        foreach (array('voci', 'liste', 'condivisioni') as $t) {
            db()->exec('DROP TABLE IF EXISTS ' . ld_t($plugin, $t));
        }
        foreach ((array)glob(ld_dir_copertine($plugin) . '/*.jpg') as $f) {
            @unlink($f);
        }
    }
});

/* ---------------- Stile e script, solo nelle pagine del plugin e nell'account ---------------- */

$ld_mie_pagine = function () use ($plugin) {
    $s = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '');
    return ($s === 'plg.php' && get('p') === $plugin->id) || $s === 'account.php';
};
$plugin->on('html_testa', function ($html) use ($plugin, $ld_mie_pagine) {
    return $ld_mie_pagine() ? $html . $plugin->css('file/stile.css') : $html;
});
$plugin->on('html_fondo', function ($html) use ($plugin, $ld_mie_pagine) {
    return $ld_mie_pagine() ? $html . $plugin->js('file/lista.js') : $html;
});

/* ---------------- Riquadro in Il mio account ---------------- */

$plugin->on('pagina_account', function ($html) use ($plugin) {
    if (!is_user()) {
        return $html;
    }
    $uid = current_uid();
    $n = ld_conta($plugin, $uid);
    $l = ld_lista($plugin, $uid);
    $con = count(ld_condivisa_con($plugin, $uid));
    $stato = array();
    if ((int)$l['tutti']) {
        $stato[] = 'visibile a tutti gli utenti';
    } elseif ($con) {
        $stato[] = 'condivisa con ' . ($con === 1 ? '1 persona' : $con . ' persone');
    }
    if ((string)$l['token'] !== '' && (!$l['token_scade'] || $l['token_scade'] >= date('Y-m-d'))) {
        $stato[] = 'con un link attivo';
    }
    $altre = count(ld_condivise_con_me($plugin, $uid));
    return $html . '<div class="card ld-account"><div class="ct">' . icon('heart', 18) . ' La mia lista dei desideri</div>'
        . '<p class="sub">' . ($n === 1 ? '1 libro' : $n . ' libri') . ' · ' . ($stato ? h(implode(', ', $stato)) : 'privata, la vedi solo tu') . '</p>'
        . ($altre ? '<p class="sub">' . ($altre === 1 ? '1 persona ha' : $altre . ' persone hanno') . ' condiviso la sua lista con te.</p>' : '')
        . '<a class="btn ghost small" href="' . h($plugin->site_url('mia')) . '">Apri la lista</a></div>';
});

/* ---------------- Pagine ---------------- */

$plugin->site_page('mia', 'La mia lista dei desideri', function ($plugin) {
    ld_pagina_mia($plugin);
}, array('ruolo' => 'utente', 'menu' => true, 'icona' => 'heart', 'salva' => function ($plugin) {
    ld_salva_mia($plugin);
}));

// lista di un altro: dentro il sito (&u=) o con il link segreto (&t=, anche senza account)
$plugin->site_page('lista', 'Lista dei desideri', function ($plugin) {
    ld_pagina_lista($plugin);
}, array('pubblica' => true, 'salva' => function ($plugin) {
    ld_salva_lista($plugin);
}));

$plugin->site_page('copertina', 'Copertina', function ($plugin) {
    ld_copertina($plugin);
}, array('pubblica' => true, 'grezza' => true));

$plugin->site_page('anteprima', 'Anteprima', function ($plugin) {
    ld_anteprima($plugin);
}, array('ruolo' => 'utente', 'grezza' => true));
