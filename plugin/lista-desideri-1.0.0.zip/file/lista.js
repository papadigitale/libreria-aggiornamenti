// Lista dei desideri: copia del link, condivisione del telefono, scelta "con tutti"
(function () {
  'use strict';
  var link = document.querySelector('[data-ld-link]');
  var copia = document.querySelector('[data-ld-copia]');
  if (link && copia) {
    copia.addEventListener('click', function () {
      var fatto = function () { copia.textContent = 'Copiato!'; setTimeout(function () { copia.textContent = 'Copia'; }, 1800); };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(link.value).then(fatto, function () { link.select(); document.execCommand('copy'); fatto(); });
      } else { link.select(); document.execCommand('copy'); fatto(); }
    });
    link.addEventListener('focus', function () { link.select(); });
  }
  var sh = document.querySelector('[data-ld-condividi]');
  if (sh && navigator.share) {
    sh.hidden = false;
    sh.addEventListener('click', function () {
      navigator.share({ title: sh.getAttribute('data-titolo'), text: sh.getAttribute('data-testo') }).catch(function () {});
    });
  }
  var tutti = document.querySelector('[data-ld-tutti]'), utenti = document.querySelector('[data-ld-utenti]');
  if (tutti && utenti) {
    tutti.addEventListener('change', function () { utenti.hidden = tutti.checked; });
  }
  // la ricerca online puo' durare qualche secondo
  document.querySelectorAll('form.ld-cerca').forEach(function (f) {
    f.addEventListener('submit', function () {
      var b = f.querySelector('[data-ld-cerca]');
      if (b) { b.disabled = true; b.lastChild.textContent = ' Cerco…'; }
    });
  });
})();
