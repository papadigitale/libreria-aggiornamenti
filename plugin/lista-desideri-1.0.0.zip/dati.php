<?php
/*
 * Lista dei desideri: tabelle, permessi, link segreti, copertine. Prefisso delle funzioni: ld_
 */
require_once APP_ROOT . '/inc/books.php';

define('LD_MAX_VOCI', 300);

function ld_t($plugin, $n)
{
    return $plugin->table($n);
}

function ld_crea_tabelle($plugin)
{
    $pdo = db();
    $sqlite = DB_DRIVER === 'sqlite';
    $id = $sqlite ? 'id INTEGER PRIMARY KEY AUTOINCREMENT' : 'id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY';
    $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ld_t($plugin, 'voci') . ' (' . $id . ', user_id INT NOT NULL, isbn13 VARCHAR(13) NULL,'
        . ' titolo VARCHAR(255) NOT NULL, autori VARCHAR(255) NULL, editore VARCHAR(150) NULL, anno VARCHAR(4) NULL, copertina VARCHAR(80) NULL,'
        . ' priorita TINYINT NOT NULL DEFAULT 2, nota VARCHAR(500) NULL, link VARCHAR(500) NULL, prezzo VARCHAR(20) NULL,'
        . ' regalo_da INT NULL, regalo_il DATETIME NULL, ricevuto_il DATETIME NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL)' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ld_t($plugin, 'liste') . ' (user_id INT NOT NULL PRIMARY KEY, tutti TINYINT NOT NULL DEFAULT 0,'
        . ' token VARCHAR(64) NULL, token_scade DATE NULL, mostra_prenotati TINYINT NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL)' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ld_t($plugin, 'condivisioni') . ' (' . $id . ', owner_id INT NOT NULL, user_id INT NOT NULL,'
        . ' created_at DATETIME NOT NULL, UNIQUE (owner_id, user_id))' . $tail);
    try {
        $pdo->exec('CREATE INDEX ' . ld_t($plugin, 'voci') . '_utente ON ' . ld_t($plugin, 'voci') . ' (user_id, ricevuto_il)');
    } catch (Exception $e) {
        // indice gia' presente
    }
}

/* ---------------- Liste e voci ---------------- */

function ld_lista($plugin, $uid)
{
    $st = db()->prepare('SELECT * FROM ' . ld_t($plugin, 'liste') . ' WHERE user_id = ?');
    $st->execute(array((int)$uid));
    $r = $st->fetch();
    return $r ? $r : array('user_id' => (int)$uid, 'tutti' => 0, 'token' => null, 'token_scade' => null, 'mostra_prenotati' => 0, 'updated_at' => null);
}

function ld_lista_salva($plugin, $uid, $campi)
{
    $l = ld_lista($plugin, $uid);
    $v = array_merge($l, $campi);
    $T = ld_t($plugin, 'liste');
    $st = db()->prepare('SELECT COUNT(*) FROM ' . $T . ' WHERE user_id = ?');
    $st->execute(array((int)$uid));
    $args = array((int)$v['tutti'], $v['token'], $v['token_scade'], (int)$v['mostra_prenotati'], now(), (int)$uid);
    if ((int)$st->fetchColumn()) {
        db()->prepare('UPDATE ' . $T . ' SET tutti = ?, token = ?, token_scade = ?, mostra_prenotati = ?, updated_at = ? WHERE user_id = ?')->execute($args);
    } else {
        db()->prepare('INSERT INTO ' . $T . ' (tutti, token, token_scade, mostra_prenotati, updated_at, user_id) VALUES (?,?,?,?,?,?)')->execute($args);
    }
}

function ld_voci($plugin, $uid, $ricevuti = false)
{
    $st = db()->prepare('SELECT * FROM ' . ld_t($plugin, 'voci') . ' WHERE user_id = ? AND ricevuto_il IS ' . ($ricevuti ? 'NOT NULL ORDER BY ricevuto_il DESC' : 'NULL ORDER BY priorita DESC, created_at DESC, id DESC'));
    $st->execute(array((int)$uid));
    return $st->fetchAll();
}

function ld_voce($plugin, $id)
{
    $st = db()->prepare('SELECT * FROM ' . ld_t($plugin, 'voci') . ' WHERE id = ?');
    $st->execute(array((int)$id));
    $r = $st->fetch();
    return $r ? $r : null;
}

function ld_conta($plugin, $uid)
{
    $st = db()->prepare('SELECT COUNT(*) FROM ' . ld_t($plugin, 'voci') . ' WHERE user_id = ? AND ricevuto_il IS NULL');
    $st->execute(array((int)$uid));
    return (int)$st->fetchColumn();
}

function ld_utente($uid)
{
    $st = db()->prepare('SELECT id, username, display_name, role, active FROM users WHERE id = ?');
    $st->execute(array((int)$uid));
    $u = $st->fetch();
    return $u && (int)$u['active'] === 1 && in_array($u['role'], user_roles(), true) ? $u : null;
}

function ld_nome($u)
{
    return $u ? ((string)$u['display_name'] !== '' ? $u['display_name'] : $u['username']) : 'qualcuno';
}

// Altri utenti registrati e attivi (per scegliere con chi condividere)
function ld_altri_utenti($uid)
{
    $in = "'" . implode("','", user_roles()) . "'";
    $st = db()->prepare('SELECT id, username, display_name FROM users WHERE active = 1 AND id <> ? AND role IN (' . $in . ') ORDER BY display_name, username');
    $st->execute(array((int)$uid));
    return $st->fetchAll();
}

function ld_condivisa_con($plugin, $owner)
{
    $st = db()->prepare('SELECT user_id FROM ' . ld_t($plugin, 'condivisioni') . ' WHERE owner_id = ?');
    $st->execute(array((int)$owner));
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

// Puo' $viewer vedere la lista di $owner dentro il sito?
function ld_puo_vedere($plugin, $owner, $viewer)
{
    if ((int)$owner === (int)$viewer) {
        return true;
    }
    if (!ld_utente($owner) || !ld_utente($viewer)) {
        return false;
    }
    $l = ld_lista($plugin, $owner);
    return (int)$l['tutti'] === 1 || in_array((int)$viewer, ld_condivisa_con($plugin, $owner), true);
}

// Liste che altri hanno condiviso con $uid (con tutti o con lui)
function ld_condivise_con_me($plugin, $uid)
{
    $L = ld_t($plugin, 'liste');
    $C = ld_t($plugin, 'condivisioni');
    $st = db()->prepare('SELECT DISTINCT u.id, u.username, u.display_name FROM users u LEFT JOIN ' . $L . ' l ON l.user_id = u.id '
        . 'LEFT JOIN ' . $C . ' c ON c.owner_id = u.id AND c.user_id = ? WHERE u.id <> ? AND u.active = 1 AND (l.tutti = 1 OR c.id IS NOT NULL) ORDER BY u.display_name, u.username');
    $st->execute(array((int)$uid, (int)$uid));
    $out = array();
    foreach ($st->fetchAll() as $u) {
        $u['n'] = ld_conta($plugin, $u['id']);
        if ($u['n'] > 0) {
            $out[] = $u;
        }
    }
    return $out;
}

/* ---------------- Link segreto ---------------- */

function ld_nuovo_token()
{
    return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
}

// Proprietario della lista aperta con il link, oppure 0 (link sbagliato, revocato o scaduto)
function ld_token_proprietario($plugin, $token)
{
    $token = (string)$token;
    if (!preg_match('/^[A-Za-z0-9_\-]{40,64}$/', $token)) {
        return 0;
    }
    $st = db()->prepare('SELECT user_id, token, token_scade FROM ' . ld_t($plugin, 'liste') . ' WHERE token = ?');
    $st->execute(array($token));
    $r = $st->fetch();
    if (!$r || !hash_equals((string)$r['token'], $token) || !ld_utente($r['user_id'])) {
        return 0;
    }
    if ($r['token_scade'] && $r['token_scade'] < date('Y-m-d')) {
        return 0;
    }
    return (int)$r['user_id'];
}

// Indirizzo completo del sito (per il link da mandare): https se il sito ha un nome di dominio
function ld_indirizzo_sito()
{
    $host = isset($_SERVER['HTTP_HOST']) ? strtolower((string)$_SERVER['HTTP_HOST']) : '';
    if (!preg_match('/^[a-z0-9.\-]+(:\d+)?$/', $host)) {
        return '';
    }
    $nome = preg_replace('/:\d+$/', '', $host);
    $https = is_https() || ($nome !== 'localhost' && !filter_var($nome, FILTER_VALIDATE_IP) && strpos($nome, '.') !== false);
    $dir = isset($_SERVER['SCRIPT_NAME']) ? rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') : '';
    return ($https ? 'https://' : 'http://') . $host . $dir . '/';
}

function ld_link_pubblico($plugin, $token)
{
    return ld_indirizzo_sito() . $plugin->site_url('lista', array('t' => $token));
}

/* ---------------- Copertine ---------------- */

function ld_dir_copertine($plugin)
{
    $d = $plugin->data_dir() . '/copertine';
    if (!is_dir($d)) {
        @mkdir($d, 0775, true);
        @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return $d;
}

// Scarica la copertina (solo dai siti di copertine conosciuti) e la salva rimpicciolita. Restituisce il nome del file o ''.
function ld_salva_copertina($plugin, $urls)
{
    foreach (array_slice((array)$urls, 0, 4) as $u) {
        $u = trim((string)$u);
        if (!preg_match('#^https?://#i', $u) || strlen($u) > 600) {
            continue;
        }
        $r = http_get($u, setting_int('lookup_timeout', 3, 30), 6291456, 'trusted');
        if ((int)$r['code'] !== 200) {
            continue;
        }
        $info = @getimagesizefromstring($r['body']);
        if (!$info || $info[0] < 60 || $info[1] < 60 || !in_array($info[2], array(IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, defined('IMAGETYPE_WEBP') ? IMAGETYPE_WEBP : -1), true)) {
            continue;
        }
        if (!function_exists('imagecreatefromstring')) {
            return '';
        }
        $src = @imagecreatefromstring($r['body']);
        if (!$src) {
            continue;
        }
        $w = imagesx($src);
        $hh = imagesy($src);
        $nw = min(400, $w);
        $nh = (int)round($hh * $nw / $w);
        $dst = imagecreatetruecolor($nw, $nh);
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $hh);
        $nome = 'c' . random_token(10) . '.jpg';
        $ok = imagejpeg($dst, ld_dir_copertine($plugin) . '/' . $nome, 84);
        img_free($src);
        img_free($dst);
        if ($ok) {
            return $nome;
        }
    }
    return '';
}

function ld_cancella_copertina($plugin, $nome)
{
    if ($nome && preg_match('/^c[a-f0-9]{20}\.jpg$/', $nome)) {
        @unlink(ld_dir_copertine($plugin) . '/' . $nome);
    }
}

/* ---------------- Utilita' ---------------- */

// Il libro desiderato e' gia' in libreria? (stesso ISBN, oppure stesso titolo e autore)
function ld_in_libreria($v)
{
    if (!empty($v['isbn13']) && books_with_isbn($v['isbn13'])) {
        return true;
    }
    $st = db()->prepare('SELECT COUNT(*) FROM books WHERE LOWER(title) = LOWER(?) AND LOWER(COALESCE(authors, \'\')) = LOWER(?)');
    $st->execute(array((string)$v['titolo'], (string)$v['autori']));
    return (int)$st->fetchColumn() > 0;
}

function ld_link_sicuro($u)
{
    $u = trim((string)$u);
    return preg_match('#^https?://[^\s<>"\']+$#i', $u) && strlen($u) <= 500 ? $u : '';
}
