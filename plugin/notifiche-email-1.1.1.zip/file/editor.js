// Pulsanti Grassetto / Corsivo sopra messaggio e firma (Email di fine lettura): mettono ** o * intorno al testo selezionato
(function () {
  var wrap = function (el, mark) {
    var a = el.selectionStart, b = el.selectionEnd, v = el.value, sel = v.slice(a, b);
    var lead = sel.match(/^\s*/)[0], core = sel.trim(), trail = core ? sel.match(/\s*$/)[0] : '';
    var before = v.slice(0, a), after = v.slice(b);
    // selezione gia' racchiusa dallo stesso segno: si toglie
    if (core && core.length > 2 * mark.length && core.slice(0, mark.length) === mark && core.slice(-mark.length) === mark
        && (mark === '**' || core.slice(0, 2) !== '**')) {
      var inner = core.slice(mark.length, core.length - mark.length);
      el.value = before + lead + inner + trail + after;
      el.setSelectionRange(a + lead.length, a + lead.length + inner.length);
    } else {
      var txt = core || 'testo';
      el.value = before + lead + mark + txt + mark + trail + after;
      var s = a + lead.length + mark.length;
      el.setSelectionRange(s, s + txt.length);
    }
    el.focus();
  };
  document.querySelectorAll('[data-nl-wrap]').forEach(function (btn) {
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); }); // la selezione resta nel campo
    btn.addEventListener('click', function () {
      var el = document.getElementById(btn.getAttribute('data-nl-target'));
      if (el) { wrap(el, btn.getAttribute('data-nl-wrap')); }
    });
  });
  document.querySelectorAll('[data-nl-fmt]').forEach(function (el) {
    el.addEventListener('keydown', function (e) {
      var k = (e.key || '').toLowerCase();
      if ((e.ctrlKey || e.metaKey) && !e.altKey && (k === 'b' || k === 'i')) {
        e.preventDefault();
        wrap(el, k === 'b' ? '**' : '*');
      }
    });
  });
})();
