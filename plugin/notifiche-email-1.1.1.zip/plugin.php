<?php
/*
 * Notifiche email (SMTP) per la Libreria di Casa.
 *
 * Invia email con il server SMTP che scegli (Gmail, iCloud, Aruba, Libero, il server del NAS…):
 *   - avvisi di sicurezza (blocchi, attacchi, password sbagliate negli aggiornamenti, plugin bloccati), entro un paio di minuti;
 *   - accessi al sito (da un dispositivo nuovo oppure sempre);
 *   - libri aggiunti (un'email sola anche se ne aggiungi molti insieme);
 *   - riepilogo giornaliero: libri aggiunti, prestiti scaduti, avvisi del giorno, ultimo backup, plugin in errore.
 * La password del server di posta e' salvata cifrata. Le impostazioni sono in Gestione → Plugin → Notifiche email.
 */
require_once __DIR__ . '/smtp.php';
require_once __DIR__ . '/lettura.php';
require_once APP_ROOT . '/inc/crypto.php';

/* ---------------- Impostazioni ---------------- */

function ne_cfg($plugin)
{
    $url = (string)$plugin->setting('sito_url', '');
    $host = (string)parse_url($url, PHP_URL_HOST);
    $pw = (string)$plugin->setting('password', '');
    return array(
        'host' => $plugin->setting('host', ''),
        'port' => (int)$plugin->setting('port', '587'),
        'sicurezza' => $plugin->setting('sicurezza', 'starttls'),
        'utente' => $plugin->setting('utente', ''),
        'password' => $pw !== '' ? sec_decrypt($pw, 'plg-notifiche-email') : '',
        'mittente' => $plugin->setting('mittente', ''),
        'nome_mittente' => $plugin->setting('nome_mittente', setting('brand_title')),
        'certificati_locali' => $plugin->setting('certificati_locali', '0') === '1',
        'dominio' => $host !== '' ? $host : 'libreria.local',
    );
}

function ne_destinatari($plugin)
{
    $out = array();
    foreach (preg_split('/[\s,;]+/', (string)$plugin->setting('destinatari', '')) as $e) {
        if (ne_email_ok($e) && !in_array(strtolower($e), array_map('strtolower', $out), true)) {
            $out[] = $e;
        }
    }
    return array_slice($out, 0, 10);
}

function ne_pronto($plugin)
{
    return $plugin->setting('host', '') !== '' && ne_email_ok($plugin->setting('mittente', '')) && ne_destinatari($plugin);
}

/* ---------------- Registro degli invii (ultimi 50, in data/plugin_dati/notifiche-email) ---------------- */

function ne_registro_file($plugin)
{
    return $plugin->data_dir() . '/invii.json';
}

function ne_registro($plugin)
{
    $d = json_decode((string)@file_get_contents(ne_registro_file($plugin)), true);
    return is_array($d) ? $d : array();
}

function ne_registra($plugin, $tipo, $oggetto, $ok, $errore, $n)
{
    $r = ne_registro($plugin);
    array_unshift($r, array('t' => time(), 'tipo' => $tipo, 'oggetto' => str_cut($oggetto, 150), 'ok' => $ok ? 1 : 0, 'errore' => str_cut((string)$errore, 300), 'n' => (int)$n));
    @file_put_contents(ne_registro_file($plugin), json_encode(array_slice($r, 0, 50), JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/* ---------------- Composizione e invio ---------------- */

function ne_tipi()
{
    return array('prova' => 'Prova', 'sicurezza' => 'Sicurezza', 'accesso' => 'Accesso', 'libri' => 'Libri aggiunti', 'riepilogo' => 'Riepilogo giornaliero',
        'lettura' => 'Libro finito', 'anteprima' => 'Anteprima libro finito');
}

/*
 * $righe: elenco di array(titolo, testo) oppure stringhe semplici.
 * $forza: anche oltre il limite orario (solo per la prova).
 */
function ne_invia($plugin, $tipo, $oggetto, $intro, $righe, $forza = false)
{
    if (!ne_pronto($plugin)) {
        return array(false, 'Notifiche non ancora configurate (server, mittente e destinatari).');
    }
    $sito = setting('brand_title');
    $url = (string)$plugin->setting('sito_url', '');
    $text = $intro . "\n\n";
    $html_rows = '';
    foreach ($righe as $r) {
        if (is_array($r)) {
            $text .= '- ' . $r[0] . ($r[1] !== '' ? ': ' . $r[1] : '') . "\n";
            $html_rows .= '<tr><td style="padding:8px 0;border-top:1px solid #e8e4dc;vertical-align:top"><b style="color:#23201c">' . h($r[0]) . '</b>'
                . ($r[1] !== '' ? '<br><span style="color:#6f6a63;font-size:13px">' . h($r[1]) . '</span>' : '') . '</td></tr>';
        } else {
            $text .= $r . "\n";
            $html_rows .= '<tr><td style="padding:6px 0;color:#23201c">' . h($r) . '</td></tr>';
        }
    }
    if ($url !== '') {
        $text .= "\nApri il sito: " . $url . "\n";
    }
    $text .= "\n— " . $sito . " · notifica automatica (si cambia in Gestione → Plugin → Notifiche email)\n";
    $html = '<!doctype html><html><body style="margin:0;background:#f2f0ec;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f2f0ec;padding:24px 12px"><tr><td align="center">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:12px;padding:24px 26px">'
        . '<tr><td style="font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#6f6a63">' . h($sito) . '</td></tr>'
        . '<tr><td style="font-size:20px;font-weight:600;color:#23201c;padding:6px 0 10px">' . h($oggetto) . '</td></tr>'
        . '<tr><td style="font-size:14px;color:#3a3631;padding-bottom:8px;line-height:1.5">' . nl2br(h($intro)) . '</td></tr>'
        . ($html_rows !== '' ? '<tr><td><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;line-height:1.45">' . $html_rows . '</table></td></tr>' : '')
        . ($url !== '' ? '<tr><td style="padding-top:18px"><a href="' . h($url) . '" style="display:inline-block;background:#2f6fe0;color:#ffffff;text-decoration:none;padding:10px 16px;border-radius:8px;font-size:14px">Apri la Libreria</a></td></tr>' : '')
        . '</table><p style="font-size:12px;color:#8a847c;max-width:560px;margin:14px auto 0">Notifica automatica della Libreria di Casa. Le notifiche si scelgono in Gestione → Plugin → Notifiche email.</p>'
        . '</td></tr></table></body></html>';
    return ne_spedisci($plugin, $tipo, ne_destinatari($plugin), $oggetto, '[' . $sito . '] ' . $oggetto, $text, $html, array(), $forza);
}

// Invio vero e proprio, con il limite orario e il registro (usato da tutte le notifiche)
function ne_spedisci($plugin, $tipo, $to, $oggetto, $oggetto_email, $text, $html, $inline = array(), $forza = false)
{
    // al massimo 30 email all'ora: un attacco lungo non deve riempire la casella
    $ora = 0;
    foreach (ne_registro($plugin) as $x) {
        if ($x['t'] > time() - 3600 && $x['ok']) {
            $ora++;
        }
    }
    if ($ora >= 30 && !$forza) {
        ne_registra($plugin, $tipo, $oggetto, false, 'Limite di 30 email all\'ora raggiunto: email non inviata.', 0);
        return array(false, 'Limite orario raggiunto.');
    }
    $res = ne_smtp_send(ne_cfg($plugin), $to, $oggetto_email, $text, $html, $dialogo, $inline);
    ne_registra($plugin, $tipo, $oggetto, $res[0], $res[1], count($to));
    if ($tipo === 'prova') {
        $plugin->save_setting('ultimo_dialogo', implode("\n", array_slice($dialogo, 0, 40)));
    }
    if (!$res[0] && $tipo !== 'prova') {
        $plugin->log('Email "' . $oggetto . '" non inviata: ' . $res[1], 'warn');
    }
    return $res;
}

// Server e mittente impostati (per le email agli utenti non servono i destinatari degli avvisi)
function ne_server_pronto($plugin)
{
    return $plugin->setting('host', '') !== '' && ne_email_ok($plugin->setting('mittente', ''));
}

// Consegna subito la pagina al browser e chiude la connessione: l'email parte dopo, senza far aspettare chi naviga
function ne_rilascia()
{
    static $fatto = false;
    if ($fatto) {
        return;
    }
    $fatto = true;
    @ignore_user_abort(true);
    if (function_exists('set_time_limit')) {
        @set_time_limit(90);
    }
    if (function_exists('fastcgi_finish_request')) {
        @fastcgi_finish_request(); // PHP-FPM
        return;
    }
    if (PHP_SAPI === 'cli' || headers_sent()) {
        return;
    }
    // Apache (mod_php): pagina intera con la sua lunghezza e "Connection: close", poi si continua in silenzio
    $buf = '';
    while (ob_get_level() > 0) {
        $buf = ob_get_clean() . $buf;
    }
    if (function_exists('apache_setenv')) {
        @apache_setenv('no-gzip', '1');
    }
    header('Connection: close');
    header('Content-Length: ' . strlen($buf));
    echo $buf;
    @flush();
}

function ne_dopo($callback)
{
    register_shutdown_function(function () use ($callback) {
        ne_rilascia();
        try {
            $callback();
        } catch (Throwable $e) {
            // un errore della posta non deve toccare il sito
        }
    });
}

/* ---------------- Avvisi di sicurezza (letti dal log, al massimo ogni 2 minuti) ---------------- */

function ne_controlla_avvisi($plugin)
{
    if ($plugin->setting('ev_sicurezza', '1') !== '1' || !ne_pronto($plugin) || time() - (int)$plugin->setting('ultimo_controllo', '0') < 120) {
        return;
    }
    $lock = @fopen($plugin->data_dir() . '/controllo.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
        return;
    }
    $plugin->save_setting('ultimo_controllo', (string)time());
    $pdo = db();
    $last = (int)$plugin->setting('ultimo_log', '0');
    $max = (int)$pdo->query('SELECT COALESCE(MAX(id), 0) FROM logs')->fetchColumn();
    if ($max > $last) {
        $st = $pdo->prepare("SELECT created_at, username, ip, action, detail FROM logs WHERE id > ? AND id <= ? AND level = 'alert' AND action NOT LIKE 'plugin_notifiche-email%' ORDER BY id LIMIT 40");
        $st->execute(array($last, $max));
        $rows = $st->fetchAll();
        $plugin->save_setting('ultimo_log', (string)$max);
        if ($rows) {
            $righe = array();
            foreach ($rows as $r) {
                $righe[] = array(date('d/m H:i', strtotime($r['created_at'])) . ' · ' . str_replace('_', ' ', $r['action']),
                    trim($r['detail'] . ($r['ip'] ? ' — IP ' . $r['ip'] : '') . ($r['username'] ? ' — utente ' . $r['username'] : '')));
            }
            ne_invia($plugin, 'sicurezza', count($rows) === 1 ? 'Avviso di sicurezza' : count($rows) . ' avvisi di sicurezza',
                'Sul sito sono stati registrati questi eventi importanti. Se non li riconosci, controlla Gestione → Sicurezza → IP bloccati e registro.', $righe);
        }
    }
    flock($lock, LOCK_UN);
    fclose($lock);
}

// C'e' qualcosa da fare? (controllo velocissimo: altrimenti la pagina va come sempre)
function ne_lavoro_dovuto($plugin)
{
    $avvisi = $plugin->setting('ev_sicurezza', '1') === '1' && ne_pronto($plugin) && time() - (int)$plugin->setting('ultimo_controllo', '0') >= 120;
    $coda = $plugin->setting('lt_attivo', '0') === '1' && $plugin->setting('lt_coda', '[]') !== '[]' && $plugin->setting('lt_coda', '') !== '';
    return $avvisi || $coda;
}

$plugin->on('html_testa', function ($html) use ($plugin) {
    if (ne_lavoro_dovuto($plugin)) {
        ne_dopo(function () use ($plugin) { ne_controlla_avvisi($plugin); nl_coda_lavora($plugin); });
    }
    return $html;
});
$plugin->on('admin_testa', function ($html) use ($plugin) {
    if (ne_lavoro_dovuto($plugin)) {
        ne_dopo(function () use ($plugin) { ne_controlla_avvisi($plugin); nl_coda_lavora($plugin); });
    }
    return $html . $plugin->css('file/stile.css');
});

/* ---------------- Accessi ---------------- */

$plugin->on('accesso', function ($u) use ($plugin) {
    $mode = $plugin->setting('ev_accessi', 'nuovi');
    if ($mode === 'mai' || !ne_pronto($plugin)) {
        return;
    }
    $ip = client_ip();
    $noti = json_decode((string)$plugin->setting('ip_noti', '{}'), true);
    $noti = is_array($noti) ? $noti : array();
    $list = isset($noti[$u['username']]) ? (array)$noti[$u['username']] : array();
    $nuovo = !in_array($ip, $list, true);
    if ($nuovo) {
        array_unshift($list, $ip);
        $noti[$u['username']] = array_slice($list, 0, 20);
        $plugin->save_setting('ip_noti', json_encode($noti));
    }
    if ($mode === 'sempre' || $nuovo) {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? str_cut($_SERVER['HTTP_USER_AGENT'], 160) : '';
        $nome = $u['display_name'] !== '' ? $u['display_name'] : $u['username'];
        ne_dopo(function () use ($plugin, $nome, $u, $ip, $ua, $nuovo) {
            ne_invia($plugin, 'accesso', ($nuovo ? 'Accesso da un dispositivo nuovo: ' : 'Accesso: ') . $nome,
                $nuovo ? 'È stato fatto un accesso da un indirizzo mai visto prima per questo utente. Se non sei stato tu, cambia subito la password.' : 'È stato fatto un accesso al sito.',
                array(array('Utente', $u['username'] . ' (' . $u['role'] . ')'), array('Quando', date('d/m/Y H:i')), array('Indirizzo IP', $ip), array('Dispositivo', $ua)));
        });
    }
});

/* ---------------- Libri aggiunti (un'email per volta, anche con molti libri) ---------------- */

$plugin->on('libro_salvato', function ($id, $nuovo) use ($plugin) {
    static $ids = null;
    if (!$nuovo || $plugin->setting('ev_libri', '0') !== '1' || !ne_pronto($plugin)) {
        return;
    }
    if ($ids === null) {
        $ids = new ArrayObject();
        $coda = $ids;
        ne_dopo(function () use ($plugin, $coda) {
            $righe = array();
            foreach (array_slice($coda->getArrayCopy(), 0, 25) as $bid) {
                $b = book_get($bid);
                if ($b) {
                    $righe[] = array($b['title'], trim($b['authors'] . ($b['pub_year'] ? ' · ' . $b['pub_year'] : '')));
                }
            }
            if (count($coda) > 25) {
                $righe[] = '… e altri ' . (count($coda) - 25) . ' libri.';
            }
            $chi = current_user();
            ne_invia($plugin, 'libri', count($coda) === 1 ? 'Nuovo libro: ' . (isset($righe[0][0]) ? $righe[0][0] : '') : count($coda) . ' libri aggiunti',
                'Aggiunti alla libreria' . ($chi ? ' da ' . ($chi['display_name'] !== '' ? $chi['display_name'] : $chi['username']) : '') . '.', $righe);
        });
    }
    $ids[] = (int)$id;
});

/* ---------------- Riepilogo giornaliero ---------------- */

function ne_riepilogo($plugin, $forza = false)
{
    $pdo = db();
    $da = date('Y-m-d H:i:s', time() - 86400);
    $righe = array();
    $succ = false;
    $st = $pdo->prepare('SELECT title, authors FROM books WHERE created_at >= ? ORDER BY created_at DESC');
    $st->execute(array($da));
    $nuovi = $st->fetchAll();
    if ($nuovi) {
        $succ = true;
        $righe[] = array('Libri aggiunti nelle ultime 24 ore: ' . count($nuovi), implode(' · ', array_map(function ($b) { return $b['title']; }, array_slice($nuovi, 0, 12)))
            . (count($nuovi) > 12 ? ' …' : ''));
    }
    if ((int)setting('db_version', '1') >= 5 && $plugin->setting('ev_prestiti', '1') === '1') {
        $st = $pdo->prepare('SELECT b.title, l.borrower, l.due_at FROM loans l JOIN books b ON b.id = l.book_id WHERE l.returned_at IS NULL AND l.due_at IS NOT NULL AND l.due_at < ? ORDER BY l.due_at');
        $st->execute(array(date('Y-m-d')));
        $sc = $st->fetchAll();
        if ($sc) {
            $succ = true;
            foreach (array_slice($sc, 0, 10) as $l) {
                $righe[] = array('Prestito scaduto: ' . $l['title'], $l['borrower'] . ' · doveva tornare il ' . date('d/m/Y', strtotime($l['due_at'])));
            }
            if (count($sc) > 10) {
                $righe[] = '… e altri ' . (count($sc) - 10) . ' prestiti scaduti.';
            }
        }
    }
    $st = $pdo->prepare("SELECT level, COUNT(*) AS n FROM logs WHERE created_at >= ? AND level IN ('alert', 'warn') GROUP BY level");
    $st->execute(array($da));
    $lv = array('alert' => 0, 'warn' => 0);
    foreach ($st->fetchAll() as $r) {
        $lv[$r['level']] = (int)$r['n'];
    }
    if ($lv['alert'] || $lv['warn']) {
        $succ = $succ || $lv['alert'] > 0;
        $righe[] = array('Registro del sito', $lv['alert'] . ' avvisi importanti e ' . $lv['warn'] . ' segnalazioni nelle ultime 24 ore');
    }
    require_once APP_ROOT . '/inc/data_tools.php';
    $bk = array_values(array_filter(backup_list(), function ($b) { return strpos($b['name'], 'prima') === false; }));
    $ult = $bk ? $bk[0]['time'] : 0;
    if (!$ult || $ult < time() - 7 * 86400) {
        $succ = true;
    }
    $righe[] = array('Ultimo backup', $ult ? date('d/m/Y H:i', $ult) . ($ult < time() - 7 * 86400 ? ' — più di una settimana fa' : '') : 'nessun backup');
    if (function_exists('plugins_rows')) {
        foreach (plugins_rows() as $p) {
            if ($p['status'] !== 'ok') {
                $succ = true;
                $righe[] = array('Plugin con problemi: ' . $p['name'], (string)$p['error']);
            }
        }
    }
    if (!$succ && $plugin->setting('riepilogo_sempre', '0') !== '1' && !$forza) {
        return array(true, 'Niente da segnalare oggi.');
    }
    $n = (int)$pdo->query('SELECT COUNT(*) FROM books')->fetchColumn();
    return ne_invia($plugin, 'riepilogo', 'Riepilogo del ' . date('d/m/Y'), 'Com\'è andata la libreria nelle ultime 24 ore (' . $n . ' libri in tutto).', $righe);
}

$plugin->on('ogni_giorno', function () use ($plugin) {
    if ($plugin->setting('ev_riepilogo', '1') === '1' && ne_pronto($plugin)) {
        ne_riepilogo($plugin);
    }
    ne_controlla_avvisi($plugin);
    nl_coda_lavora($plugin);
});

/* ---------------- Pagina del pannello ---------------- */

$plugin->admin_page('impostazioni', 'Notifiche email', function ($plugin) {
    // indirizzo del sito per i collegamenti nelle email (preso da qui, dove scrive solo l'Admin)
    $host = isset($_SERVER['HTTP_HOST']) && preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    if ($host !== '') {
        $dir = rtrim(str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/')), '/');
        $url = (is_https() ? 'https://' : 'http://') . $host . $dir . '/';
        if ($url !== $plugin->setting('sito_url', '')) {
            $plugin->save_setting('sito_url', $url);
        }
    }
    $s = function ($k, $d = '') use ($plugin) { return h($plugin->setting($k, $d)); };
    $sel = function ($k, $v, $d) use ($plugin) { return $plugin->setting($k, $d) === $v ? ' selected' : ''; };
    $chk = function ($k, $d) use ($plugin) { return $plugin->setting($k, $d) === '1' ? ' checked' : ''; };
    $ready = ne_pronto($plugin);
    $reg = ne_registro($plugin);
    $tipi = ne_tipi();
    echo '<div class="ne-head"><img src="' . h($plugin->url('file/icona.png')) . '" alt="" width="56" height="56">'
        . '<div><b>' . ($ready ? 'Attive' : 'Da configurare') . '</b><span class="sub">' . ($ready ? 'Pronte: le email arrivano a ' . h(implode(', ', ne_destinatari($plugin))) . '.'
            : 'Da configurare: imposta il server di posta e chi deve ricevere le email.') . '</span></div></div>';

    echo '<div class="adm-grid2"><div class="card">' . $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="server">'
        . '<div class="ct">Server di posta (SMTP)</div>'
        . '<label class="lab">Server</label><input class="input" name="host" value="' . $s('host') . '" placeholder="es. smtp.gmail.com" autocomplete="off">'
        . '<div class="ne-row"><div><label class="lab">Porta</label><input class="input" name="port" type="number" min="1" max="65535" value="' . $s('port', '587') . '"></div>'
        . '<div><label class="lab">Cifratura</label><select class="input" name="sicurezza">'
        . '<option value="starttls"' . $sel('sicurezza', 'starttls', 'starttls') . '>STARTTLS (porta 587)</option>'
        . '<option value="ssl"' . $sel('sicurezza', 'ssl', 'starttls') . '>SSL/TLS (porta 465)</option>'
        . '<option value="nessuna"' . $sel('sicurezza', 'nessuna', 'starttls') . '>Nessuna (solo rete di casa)</option></select></div></div>'
        . '<label class="lab">Nome utente</label><input class="input" name="utente" value="' . $s('utente') . '" autocomplete="off" placeholder="di solito il tuo indirizzo email">'
        . '<label class="lab">Password</label><input class="input" type="password" name="password" autocomplete="new-password" placeholder="'
            . ($plugin->setting('password', '') !== '' ? '•••••••• (salvata cifrata: lascia vuoto per non cambiarla)' : 'password o "password per le app"') . '">'
        . ($plugin->setting('password', '') !== '' ? '<label class="check"><input type="checkbox" name="togli_password" value="1"> Cancella la password salvata</label>' : '')
        . '<label class="lab">Indirizzo del mittente</label><input class="input" type="email" name="mittente" value="' . $s('mittente') . '" placeholder="es. libreria@tuodominio.it">'
        . '<label class="lab">Nome del mittente</label><input class="input" name="nome_mittente" value="' . $s('nome_mittente', setting('brand_title')) . '">'
        . '<label class="check"><input type="checkbox" name="certificati_locali" value="1"' . $chk('certificati_locali', '0') . '> Server della rete di casa con certificato fatto in proprio (non controllare chi lo ha emesso)</label>'
        . '<div class="savebar"><button class="btn primary small" type="submit">Salva il server</button></div></form>'
        . '<details class="ne-help"><summary>Impostazioni dei servizi più comuni</summary><table class="tbl compact">'
        . '<tr><td><b>Gmail</b></td><td><code>smtp.gmail.com</code> · 587 STARTTLS · serve una <i>password per le app</i> (Account Google → Sicurezza → Verifica in due passaggi → Password per le app)</td></tr>'
        . '<tr><td><b>iCloud</b></td><td><code>smtp.mail.me.com</code> · 587 STARTTLS · password specifica per le app (account.apple.com)</td></tr>'
        . '<tr><td><b>Aruba</b></td><td><code>smtps.aruba.it</code> · 465 SSL/TLS · indirizzo email e sua password</td></tr>'
        . '<tr><td><b>Libero</b></td><td><code>smtp.libero.it</code> · 465 SSL/TLS · indirizzo email e sua password</td></tr>'
        . '<tr><td><b>NAS / server di casa</b></td><td>indirizzo del NAS · 25 o 587 · se il certificato è fatto in proprio spunta l\'opzione qui sopra</td></tr>'
        . '</table><p class="hint">Con Gmail e iCloud il mittente deve essere il tuo indirizzo (o un alias già configurato nel servizio).</p></details>'
        . '</div>';

    echo '<div class="card">' . $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="notifiche">'
        . '<div class="ct">Chi riceve e cosa</div>'
        . '<label class="lab">Destinatari (uno per riga, al massimo 10)</label><textarea class="input" name="destinatari" rows="3" placeholder="tuo@indirizzo.it">' . $s('destinatari') . '</textarea>'
        . '<label class="check"><input type="checkbox" name="ev_sicurezza" value="1"' . $chk('ev_sicurezza', '1') . '> <span><b>Avvisi di sicurezza</b>, entro un paio di minuti: blocchi del firewall, attacchi, password sbagliate negli aggiornamenti, plugin bloccati</span></label>'
        . '<label class="lab">Accessi al sito</label><select class="input" name="ev_accessi">'
        . '<option value="nuovi"' . $sel('ev_accessi', 'nuovi', 'nuovi') . '>Solo da un dispositivo o indirizzo nuovo</option>'
        . '<option value="sempre"' . $sel('ev_accessi', 'sempre', 'nuovi') . '>A ogni accesso</option>'
        . '<option value="mai"' . $sel('ev_accessi', 'mai', 'nuovi') . '>Mai</option></select>'
        . '<label class="check"><input type="checkbox" name="ev_libri" value="1"' . $chk('ev_libri', '0') . '> <span><b>Libri aggiunti</b> (un\'email sola anche se ne aggiungi molti insieme)</span></label>'
        . '<label class="check"><input type="checkbox" name="ev_riepilogo" value="1"' . $chk('ev_riepilogo', '1') . '> <span><b>Riepilogo giornaliero</b>: libri aggiunti, avvisi, ultimo backup, plugin con problemi</span></label>'
        . '<label class="check"><input type="checkbox" name="ev_prestiti" value="1"' . $chk('ev_prestiti', '1') . '> <span>Nel riepilogo anche i <b>prestiti scaduti</b></span></label>'
        . '<label class="check"><input type="checkbox" name="riepilogo_sempre" value="1"' . $chk('riepilogo_sempre', '0') . '> <span>Manda il riepilogo anche quando non c\'è niente da segnalare</span></label>'
        . '<div class="savebar"><button class="btn primary small" type="submit">Salva le notifiche</button></div></form>'
        . '<div class="ct sep">Prova</div><div class="row-btn">'
        . $plugin->form_start() . '<input type="hidden" name="op" value="prova"><button class="btn ghost small" type="submit"' . ($ready ? '' : ' disabled') . '>Invia un\'email di prova</button></form>'
        . $plugin->form_start() . '<input type="hidden" name="op" value="riepilogo"><button class="btn ghost small" type="submit"' . ($ready ? '' : ' disabled') . '>Invia ora il riepilogo</button></form></div>';
    $dial = (string)$plugin->setting('ultimo_dialogo', '');
    if ($dial !== '') {
        echo '<details class="ne-help"><summary>Dialogo con il server dell\'ultima prova</summary><pre class="ne-log">' . h($dial) . '</pre></details>';
    }
    echo '</div></div>';

    echo '<div class="card ne-invii"><div class="ct">Ultimi invii</div>';
    if (!$reg) {
        echo '<p class="sub">Ancora nessuna email.</p>';
    } else {
        echo '<table class="tbl compact"><thead><tr><th>Quando</th><th>Tipo</th><th>Oggetto</th><th>Esito</th></tr></thead><tbody>';
        foreach (array_slice($reg, 0, 25) as $r) {
            echo '<tr><td>' . h(date('d/m H:i', $r['t'])) . '</td><td>' . h(isset($tipi[$r['tipo']]) ? $tipi[$r['tipo']] : $r['tipo']) . '</td><td>' . h($r['oggetto']) . '</td><td>'
                . ($r['ok'] ? '<span class="ok-text">inviata</span>' : '<span class="err-text">non inviata</span> <small class="muted">' . h($r['errore']) . '</small>') . '</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';
}, array(
    'salva' => function ($plugin) {
        $op = post('op');
        if ($op === 'server') {
            $port = (int)post('port');
            $sec = in_array(post('sicurezza'), array('ssl', 'starttls', 'nessuna'), true) ? post('sicurezza') : 'starttls';
            $host = trim(post('host'));
            if ($host !== '' && !preg_match('/^[A-Za-z0-9.\-]{1,200}$/', $host) && !filter_var($host, FILTER_VALIDATE_IP)) {
                flash('Il nome del server non è valido.', 'error');
                return;
            }
            if (post('mittente') !== '' && !ne_email_ok(post('mittente'))) {
                flash('L\'indirizzo del mittente non è valido.', 'error');
                return;
            }
            $plugin->save_setting('host', $host);
            $plugin->save_setting('port', (string)($port >= 1 && $port <= 65535 ? $port : ($sec === 'ssl' ? 465 : 587)));
            $plugin->save_setting('sicurezza', $sec);
            $plugin->save_setting('utente', str_cut(trim(post('utente')), 200));
            $plugin->save_setting('mittente', trim(post('mittente')));
            $plugin->save_setting('nome_mittente', str_cut(ne_header_safe(post('nome_mittente')), 80));
            $plugin->save_setting('certificati_locali', post('certificati_locali') === '1' ? '1' : '0');
            $pw = isset($_POST['password']) ? (string)$_POST['password'] : '';
            if ($pw !== '') {
                $plugin->save_setting('password', sec_encrypt(str_cut($pw, 500), 'plg-notifiche-email'));
            } elseif (post('togli_password') === '1') {
                $plugin->save_setting('password', '');
            }
            $plugin->log('Impostazioni del server di posta aggiornate (' . $host . ':' . $port . ')', 'warn');
            flash('Server di posta salvato.' . ($sec === 'nessuna' && post('utente') !== '' ? ' Attenzione: senza cifratura la password viaggia in chiaro, usala solo nella rete di casa.' : ''));
        } elseif ($op === 'notifiche') {
            $list = array();
            foreach (preg_split('/[\s,;]+/', (string)post('destinatari')) as $e) {
                if ($e !== '' && !ne_email_ok($e)) {
                    flash('Indirizzo non valido: ' . $e, 'error');
                    return;
                }
                if ($e !== '') {
                    $list[] = $e;
                }
            }
            $plugin->save_setting('destinatari', implode("\n", array_slice(array_unique($list), 0, 10)));
            foreach (array('ev_sicurezza', 'ev_libri', 'ev_riepilogo', 'ev_prestiti', 'riepilogo_sempre') as $k) {
                $plugin->save_setting($k, post($k) === '1' ? '1' : '0');
            }
            $plugin->save_setting('ev_accessi', in_array(post('ev_accessi'), array('nuovi', 'sempre', 'mai'), true) ? post('ev_accessi') : 'nuovi');
            flash('Notifiche salvate.');
        } elseif ($op === 'prova') {
            $r = ne_invia($plugin, 'prova', 'Email di prova', 'Se leggi questo messaggio, le notifiche della Libreria funzionano.',
                array(array('Server', $plugin->setting('host') . ':' . $plugin->setting('port') . ' (' . $plugin->setting('sicurezza') . ')'), array('Inviata il', date('d/m/Y H:i'))), true);
            flash($r[0] ? 'Email di prova inviata: controlla la casella (anche lo spam).' : 'Invio non riuscito: ' . $r[1], $r[0] ? 'success' : 'error');
        } elseif ($op === 'riepilogo') {
            $r = ne_riepilogo($plugin, true);
            flash($r[0] ? 'Riepilogo inviato.' : 'Invio non riuscito: ' . $r[1], $r[0] ? 'success' : 'error');
        }
    },
));

/* ---------------- Attivazione ---------------- */

$plugin->on_activate(function ($plugin, $prima) {
    if ($prima === '') {
        // non si mandano gli avvisi gia' presenti nel log; gli indirizzi degli ultimi accessi sono gia' "noti"
        $plugin->save_setting('ultimo_log', (string)(int)db()->query('SELECT COALESCE(MAX(id), 0) FROM logs')->fetchColumn());
        $noti = array();
        foreach (db()->query('SELECT username, last_login_ip FROM users WHERE last_login_ip IS NOT NULL')->fetchAll() as $u) {
            $noti[$u['username']] = array($u['last_login_ip']);
        }
        if (function_exists('client_ip') && current_user()) {
            $cu = current_user();
            $noti[$cu['username']] = array_values(array_unique(array_merge(array(client_ip()), isset($noti[$cu['username']]) ? $noti[$cu['username']] : array())));
        }
        $plugin->save_setting('ip_noti', json_encode($noti));
    }
});
