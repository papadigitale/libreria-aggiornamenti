<?php
/*
 * Client SMTP essenziale (nessuna libreria esterna): SSL/TLS (porta 465), STARTTLS (porta 587) o senza cifratura,
 * autenticazione PLAIN o LOGIN, messaggi in testo + HTML in UTF-8. Certificati controllati con CONF/cacert.pem.
 */

// Toglie a capo e caratteri di controllo: nessuno puo' aggiungere intestazioni nascoste
function ne_header_safe($s)
{
    return trim(preg_replace('/[\x00-\x1F\x7F]+/', ' ', (string)$s));
}

function ne_mime_word($s)
{
    $s = ne_header_safe($s);
    return preg_match('/[^\x20-\x7E]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s;
}

function ne_email_ok($e)
{
    return is_string($e) && strlen($e) <= 254 && filter_var($e, FILTER_VALIDATE_EMAIL) !== false && !preg_match('/[\r\n<>,;]/', $e);
}

function ne_smtp_read($fp, &$log)
{
    $data = '';
    while (($line = fgets($fp, 2048)) !== false) {
        $data .= $line;
        if (strlen($line) < 4 || $line[3] === ' ') {
            break;
        }
    }
    $meta = stream_get_meta_data($fp);
    if ($data === '' && !empty($meta['timed_out'])) {
        throw new Exception('Il server SMTP non risponde (tempo scaduto).');
    }
    $log[] = 'S: ' . trim($data);
    return array((int)substr($data, 0, 3), $data);
}

function ne_smtp_cmd($fp, $cmd, $expect, &$log, $hide = false)
{
    fwrite($fp, $cmd . "\r\n");
    $log[] = 'C: ' . ($hide ? '(dato nascosto)' : $cmd);
    list($code, $text) = ne_smtp_read($fp, $log);
    if (!in_array($code, (array)$expect, true)) {
        throw new Exception('Il server SMTP ha risposto: ' . trim(preg_replace('/\s+/', ' ', $text)));
    }
    return $text;
}

/*
 * $cfg: host, port, sicurezza (ssl|starttls|nessuna), utente, password, mittente, nome_mittente, certificati_locali (bool)
 * Esito: array(true, '') oppure array(false, 'motivo'); $log riceve il dialogo con il server (password escluse)
 */
function ne_smtp_send($cfg, $to, $subject, $text, $html, &$log = null, $inline = array())
{
    $log = array();
    $host = ne_header_safe($cfg['host']);
    $port = (int)$cfg['port'];
    $to = array_values(array_filter((array)$to, 'ne_email_ok'));
    if ($host === '' || $port < 1 || $port > 65535) {
        return array(false, 'Server SMTP o porta non impostati.');
    }
    if (!ne_email_ok($cfg['mittente'])) {
        return array(false, 'Indirizzo del mittente non valido.');
    }
    if (!$to) {
        return array(false, 'Nessun destinatario valido.');
    }
    $sec = in_array($cfg['sicurezza'], array('ssl', 'starttls', 'nessuna'), true) ? $cfg['sicurezza'] : 'starttls';
    $ssl = array('verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $host, 'SNI_enabled' => true);
    $ca = dirname(APP_ROOT) . '/CONF/cacert.pem';
    if (is_file($ca)) {
        $ssl['cafile'] = $ca;
    }
    if (!empty($cfg['certificati_locali'])) {
        // server della rete di casa con certificato fatto in proprio: si cifra comunque, ma senza controllare chi lo ha emesso
        $ssl['verify_peer'] = false;
        $ssl['verify_peer_name'] = false;
        $ssl['allow_self_signed'] = true;
    }
    $ctx = stream_context_create(array('ssl' => $ssl));
    $errno = 0;
    $errstr = '';
    $fp = @stream_socket_client(($sec === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) {
        return array(false, 'Connessione a ' . $host . ':' . $port . ' non riuscita: ' . ($errstr !== '' ? $errstr : 'errore ' . $errno)
            . ($sec === 'ssl' ? ' (porta e tipo di cifratura sono giusti?)' : ''));
    }
    stream_set_timeout($fp, 20);
    $domain = isset($cfg['dominio']) && preg_match('/^[A-Za-z0-9.\-]{1,200}$/', $cfg['dominio']) ? $cfg['dominio'] : 'libreria.local';
    try {
        list($code, $greet) = ne_smtp_read($fp, $log);
        if ($code !== 220) {
            throw new Exception('Il server SMTP non è pronto: ' . trim($greet));
        }
        $caps = ne_smtp_cmd($fp, 'EHLO ' . $domain, 250, $log);
        if ($sec === 'starttls') {
            if (stripos($caps, 'STARTTLS') === false) {
                throw new Exception('Il server non offre STARTTLS: prova "SSL/TLS" sulla porta 465.');
            }
            ne_smtp_cmd($fp, 'STARTTLS', 220, $log);
            $method = STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT') ? STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT : 0);
            if (!@stream_socket_enable_crypto($fp, true, $method)) {
                throw new Exception('Cifratura TLS non riuscita: il certificato del server non è valido (per un server di casa attiva "certificato fatto in proprio").');
            }
            $caps = ne_smtp_cmd($fp, 'EHLO ' . $domain, 250, $log);
        }
        if ((string)$cfg['utente'] !== '') {
            if (preg_match('/AUTH[ =][^\r\n]*PLAIN/i', $caps)) {
                ne_smtp_cmd($fp, 'AUTH PLAIN ' . base64_encode("\0" . $cfg['utente'] . "\0" . $cfg['password']), 235, $log, true);
            } else {
                ne_smtp_cmd($fp, 'AUTH LOGIN', 334, $log);
                ne_smtp_cmd($fp, base64_encode($cfg['utente']), 334, $log, true);
                ne_smtp_cmd($fp, base64_encode($cfg['password']), 235, $log, true);
            }
        }
        ne_smtp_cmd($fp, 'MAIL FROM:<' . $cfg['mittente'] . '>', 250, $log);
        foreach ($to as $r) {
            ne_smtp_cmd($fp, 'RCPT TO:<' . $r . '>', array(250, 251), $log);
        }
        ne_smtp_cmd($fp, 'DATA', 354, $log);
        $msg = ne_build_message($cfg, $to, $subject, $text, $html, $domain, $inline);
        // "dot stuffing": una riga che inizia con il punto ne riceve uno in piu'
        $msg = preg_replace('/^\./m', '..', $msg);
        fwrite($fp, $msg . "\r\n.\r\n");
        $log[] = 'C: (messaggio, ' . strlen($msg) . ' byte)';
        list($code, $resp) = ne_smtp_read($fp, $log);
        if ($code !== 250) {
            throw new Exception('Messaggio rifiutato: ' . trim($resp));
        }
        @fwrite($fp, "QUIT\r\n");
        fclose($fp);
        return array(true, '');
    } catch (Exception $e) {
        @fwrite($fp, "QUIT\r\n");
        @fclose($fp);
        return array(false, $e->getMessage());
    }
}

/*
 * $inline: immagini dentro l'email (copertina, stelle): array di array(cid, tipo mime, dati binari).
 * Nell'HTML si richiamano con <img src="cid:...">: arrivano con l'email, senza scaricare niente dal sito.
 */
function ne_build_message($cfg, $to, $subject, $text, $html, $domain, $inline = array())
{
    $b = 'ldc' . bin2hex(random_bytes(12));
    $from_name = ne_header_safe(isset($cfg['nome_mittente']) ? $cfg['nome_mittente'] : '');
    $h = array(
        'Date: ' . date('r'),
        'From: ' . ($from_name !== '' ? ne_mime_word($from_name) . ' ' : '') . '<' . $cfg['mittente'] . '>',
        'To: ' . implode(', ', array_map(function ($e) { return '<' . $e . '>'; }, $to)),
        'Subject: ' . ne_mime_word($subject),
        'Message-ID: <' . bin2hex(random_bytes(10)) . '@' . $domain . '>',
        'MIME-Version: 1.0',
        'X-Mailer: Libreria di Casa',
        'Auto-Submitted: auto-generated',
    );
    $rel = 'ldr' . bin2hex(random_bytes(12));
    $h[] = $inline ? 'Content-Type: multipart/related; boundary="' . $rel . '"' : 'Content-Type: multipart/alternative; boundary="' . $b . '"';
    $qp = function ($s) {
        // a capo sempre CRLF prima della codifica: cosi' restano a capo veri e non diventano =0A
        return quoted_printable_encode(str_replace("\n", "\r\n", str_replace(array("\r\n", "\r"), "\n", $s)));
    };
    $alt = '--' . $b . "\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n" . $qp($text) . "\r\n"
        . '--' . $b . "\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n" . $qp($html) . "\r\n"
        . '--' . $b . '--';
    if (!$inline) {
        return implode("\r\n", $h) . "\r\n\r\n" . $alt;
    }
    $out = implode("\r\n", $h) . "\r\n\r\n--" . $rel . "\r\nContent-Type: multipart/alternative; boundary=\"" . $b . "\"\r\n\r\n" . $alt . "\r\n";
    foreach ($inline as $im) {
        $cid = preg_replace('/[^A-Za-z0-9.\-@]/', '', $im[0]);
        $ext = $im[1] === 'image/png' ? 'png' : 'jpg';
        $out .= '--' . $rel . "\r\nContent-Type: " . $im[1] . '; name="' . $cid . '.' . $ext . "\"\r\nContent-Transfer-Encoding: base64\r\n"
            . 'Content-ID: <' . $cid . ">\r\nContent-Disposition: inline; filename=\"" . $cid . '.' . $ext . "\"\r\n\r\n"
            . rtrim(chunk_split(base64_encode($im[2]), 76, "\r\n")) . "\r\n";
    }
    return $out . '--' . $rel . '--';
}
