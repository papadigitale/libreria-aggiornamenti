<?php
/*
 * Email di fine lettura: quando un utente segna un libro come finito riceve un riepilogo con
 * copertina, voto (stelle), date di inizio e fine, giorni, pagine al giorno, recensione e libri letti nell'anno.
 * L'impaginazione (ordine dei blocchi, testi, colori, carattere, allineamento) si sceglie in
 * Gestione → Plugin → Email di fine lettura, con l'anteprima.
 * Copertina e stelle viaggiano dentro l'email (immagini "inline"): si vedono anche se il sito non e' raggiungibile da fuori.
 */

/* ---------------- Modello (impaginazione) ---------------- */

function nl_blocchi_nomi()
{
    return array(
        'copertina'  => 'Copertina del libro',
        'stelle'     => 'Stelle del voto (se c\'è)',
        'titolo'     => 'Titolo e autore',
        'messaggio'  => 'Messaggio',
        'date'       => 'Data di inizio e di fine',
        'durata'     => 'Giorni di lettura',
        'ritmo'      => 'Pagine lette al giorno',
        'recensione' => 'La tua recensione (se c\'è)',
        'anno'       => 'Libri letti quest\'anno e obiettivo',
        'pulsante'   => 'Pulsante "Apri la scheda del libro"',
        'firma'      => 'Firma in fondo',
    );
}

function nl_modello_base()
{
    $acc = function_exists('safe_color') ? safe_color(setting('color_primary'), '#7a1f2b') : '#7a1f2b';
    return array(
        'blocchi' => array('copertina' => 1, 'stelle' => 1, 'titolo' => 1, 'messaggio' => 1, 'date' => 1, 'durata' => 1, 'ritmo' => 1,
            'recensione' => 1, 'anno' => 1, 'pulsante' => 1, 'firma' => 1),
        'oggetto' => 'Hai finito «{titolo}»!',
        'messaggio' => "Complimenti {nome}!\nHai finito di leggere questo libro: ecco il riepilogo della tua lettura.",
        'firma' => 'Buone letture da {sito}',
        'copertina' => 'media',
        'ombra' => 1,
        'allinea' => 'centro',
        'carattere' => 'serif',
        'sfondo' => '#f3ebdd',
        'scheda' => '#fffdf8',
        'testo' => '#2b1d14',
        'accento' => $acc,
        'stelle_colore' => '#e0a526',
    );
}

// Il modello salvato, completato con i valori predefiniti (le chiavi nuove delle versioni future si aggiungono da sole)
function nl_modello($plugin)
{
    $base = nl_modello_base();
    $m = json_decode((string)$plugin->setting('lt_modello', ''), true);
    if (!is_array($m)) {
        return $base;
    }
    $out = array_merge($base, array_intersect_key($m, $base));
    $bl = array();
    foreach ((array)$m['blocchi'] as $k => $on) {
        if (isset($base['blocchi'][$k])) {
            $bl[$k] = $on ? 1 : 0;
        }
    }
    foreach ($base['blocchi'] as $k => $on) {
        if (!isset($bl[$k])) {
            $bl[$k] = 0;
        }
    }
    $out['blocchi'] = $bl;
    return $out;
}

function nl_colore($c, $d)
{
    return is_string($c) && preg_match('/^#[0-9a-fA-F]{6}$/', $c) ? strtolower($c) : $d;
}

/* ---------------- Dati della lettura ---------------- */

function nl_dati($sid)
{
    $st = db()->prepare('SELECT s.*, b.title, b.authors, b.pages, b.cover_file, b.pub_year, u.username, u.display_name'
        . (users_email_ready() ? ', u.email, u.email_notify' : '') . ' FROM reading_sessions s JOIN books b ON b.id = s.book_id JOIN users u ON u.id = s.user_id WHERE s.id = ?');
    $st->execute(array((int)$sid));
    $r = $st->fetch();
    if (!$r) {
        return null;
    }
    $r['nome'] = $r['display_name'] !== '' ? $r['display_name'] : $r['username'];
    $r['giorni'] = 0;
    $r['media'] = 0;
    if ($r['started_at'] && $r['finished_at'] && !(int)$r['date_unknown']) {
        $a = strtotime(substr($r['started_at'], 0, 10));
        $b = strtotime(substr($r['finished_at'], 0, 10));
        $r['giorni'] = max(1, (int)round(($b - $a) / 86400) + 1);
        $r['media'] = (int)$r['pages'] > 0 ? round((int)$r['pages'] / $r['giorni'], 1) : 0;
    }
    $anno = $r['finished_at'] ? substr($r['finished_at'], 0, 4) : date('Y');
    $st = db()->prepare("SELECT COUNT(*) FROM reading_sessions WHERE user_id = ? AND status = 'letto' AND finished_at >= ? AND finished_at <= ?");
    $st->execute(array((int)$r['user_id'], $anno . '-01-01 00:00:00', $anno . '-12-31 23:59:59'));
    $r['anno'] = $anno;
    $r['anno_letti'] = (int)$st->fetchColumn();
    $st = db()->prepare('SELECT books FROM reading_goals WHERE user_id = ? AND year = ?');
    $st->execute(array((int)$r['user_id'], (int)$anno));
    $r['obiettivo'] = (int)$st->fetchColumn();
    return $r;
}

// Lettura di esempio per l'anteprima quando nessuno ha ancora finito un libro
function nl_dati_esempio()
{
    return array('id' => 0, 'user_id' => 0, 'book_id' => 0, 'title' => 'Il nome della rosa', 'authors' => 'Umberto Eco', 'pages' => 503, 'cover_file' => '',
        'pub_year' => 1980, 'started_at' => date('Y-m-d', time() - 13 * 86400) . ' 21:00:00', 'finished_at' => date('Y-m-d') . ' 22:30:00', 'date_unknown' => 0,
        'rating' => 4.25, 'review' => 'Un giallo medievale che non si dimentica: biblioteca, labirinto e un finale indimenticabile.', 'nome' => 'Francesco',
        'giorni' => 14, 'media' => 35.9, 'anno' => date('Y'), 'anno_letti' => 12, 'obiettivo' => 20, 'username' => 'esempio');
}

function nl_voto_testo($r)
{
    $r = (float)$r;
    $int = floor($r);
    $fr = $r - $int;
    $q = $fr >= 0.74 ? '¾' : ($fr >= 0.49 ? '½' : ($fr >= 0.24 ? '¼' : ''));
    return ($int > 0 || $q === '' ? (string)$int : '') . $q . ' su 5';
}

function nl_data($dt)
{
    $mesi = array('gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre');
    $t = strtotime($dt);
    return (int)date('j', $t) . ' ' . $mesi[(int)date('n', $t) - 1] . ' ' . date('Y', $t);
}

/*
 * Formattazione semplice nei testi del modello: **grassetto** e *corsivo* (come nelle pagine del sito).
 * Il testo viene prima protetto (h), poi si applicano solo questi due segni: niente HTML scritto a mano.
 */
function nl_formatta($testo)
{
    $t = h($testo);
    $t = preg_replace('/\*\*(?=\S)([^\n*]+?)(?<=\S)\*\*/u', '<b>$1</b>', $t);
    $t = preg_replace('/\*(?=\S)([^\n*]+?)(?<=\S)\*/u', '<i>$1</i>', $t);
    return nl2br($t);
}

// Per la versione solo testo dell'email: via gli asterischi della formattazione
function nl_senza_segni($testo)
{
    $t = preg_replace('/\*\*(?=\S)([^\n*]+?)(?<=\S)\*\*/u', '$1', (string)$testo);
    return preg_replace('/\*(?=\S)([^\n*]+?)(?<=\S)\*/u', '$1', $t);
}

function nl_sostituisci($testo, $d)
{
    return strtr((string)$testo, array(
        '{nome}' => $d['nome'], '{titolo}' => $d['title'], '{autore}' => (string)$d['authors'], '{pagine}' => (string)(int)$d['pages'],
        '{giorni}' => (string)$d['giorni'], '{media}' => str_replace('.', ',', (string)$d['media']),
        '{inizio}' => $d['started_at'] ? nl_data($d['started_at']) : '', '{fine}' => $d['finished_at'] ? nl_data($d['finished_at']) : '',
        '{voto}' => $d['rating'] ? nl_voto_testo($d['rating']) : '', '{anno_letti}' => (string)$d['anno_letti'], '{sito}' => setting('brand_title'),
    ));
}

/* ---------------- Immagini: copertina e stelle ---------------- */

function nl_copertina_jpg($file, $w)
{
    if ($file === '' || !preg_match('/^[a-z0-9_\-]+\.(jpg|png|webp)$/', (string)$file) || !is_file(COVERS_DIR . '/' . $file) || !function_exists('imagecreatefromstring')) {
        return null;
    }
    $src = @imagecreatefromstring(file_get_contents(COVERS_DIR . '/' . $file));
    if (!$src) {
        return null;
    }
    $sw = imagesx($src);
    $sh = imagesy($src);
    $w = min($w, $sw);
    $h = max(1, (int)round($sh * $w / $sw));
    $dst = imagecreatetruecolor($w, $h);
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $w, $h, $sw, $sh);
    ob_start();
    imagejpeg($dst, null, 84);
    $out = ob_get_clean();
    img_free($src);
    img_free($dst);
    return $out;
}

// Cinque stelle disegnate con il riempimento esatto (anche a quarti), PNG trasparente a doppia risoluzione
function nl_stelle_png($voto, $colore)
{
    if (!function_exists('imagecreatetruecolor')) {
        return null;
    }
    $S = 4;                // disegno 4 volte piu' grande, poi riduco: bordi morbidi
    $star = 34;            // lato di ogni stella nell'immagine finale (doppia risoluzione: 17 px a schermo)
    $gap = 8;
    $W = 5 * $star + 4 * $gap;
    $big = imagecreatetruecolor($W * $S, $star * $S);
    imagealphablending($big, false);
    imagesavealpha($big, true);
    $tr = imagecolorallocatealpha($big, 0, 0, 0, 127);
    imagefill($big, 0, 0, $tr);
    imagealphablending($big, true);
    $hex = ltrim(nl_colore($colore, '#e0a526'), '#');
    $full = imagecolorallocate($big, hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)));
    $empty = imagecolorallocate($big, 222, 214, 200);
    $pts = function ($ox) use ($S, $star) {
        $p = array();
        $cx = $ox + $star * $S / 2;
        $cy = $star * $S / 2 + $S;
        for ($i = 0; $i < 10; $i++) {
            $r = ($i % 2 ? 0.40 : 1) * ($star * $S / 2);
            $a = -M_PI / 2 + $i * M_PI / 5;
            $p[] = (int)round($cx + $r * cos($a));
            $p[] = (int)round($cy + $r * sin($a));
        }
        return $p;
    };
    $v = max(0, min(5, (float)$voto));
    for ($i = 0; $i < 5; $i++) {
        $ox = $i * ($star + $gap) * $S;
        $p = $pts($ox);
        imagefilledpolygon($big, $p, $empty);
        $fill = max(0, min(1, $v - $i));
        if ($fill > 0) {
            // stella piena solo fino alla frazione del voto
            $layer = imagecreatetruecolor($star * $S, $star * $S);
            imagealphablending($layer, false);
            imagesavealpha($layer, true);
            imagefill($layer, 0, 0, imagecolorallocatealpha($layer, 0, 0, 0, 127));
            imagealphablending($layer, true);
            $lp = $pts(0);
            imagefilledpolygon($layer, $lp, imagecolorallocate($layer, hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))));
            imagecopy($big, $layer, $ox, 0, 0, 0, (int)round($star * $S * $fill), $star * $S);
            img_free($layer);
        }
    }
    $out = imagecreatetruecolor($W, $star);
    imagealphablending($out, false);
    imagesavealpha($out, true);
    imagefill($out, 0, 0, imagecolorallocatealpha($out, 0, 0, 0, 127));
    imagecopyresampled($out, $big, 0, 0, 0, 0, $W, $star, $W * $S, $star * $S);
    ob_start();
    imagepng($out, null, 9);
    $png = ob_get_clean();
    img_free($big);
    img_free($out);
    return $png;
}

/* ---------------- Composizione dell'email ---------------- */

/*
 * $modo: 'email' (immagini con cid:) oppure 'anteprima' (immagini dentro la pagina, data:)
 * Esito: array(oggetto, html completo, html interno per l'anteprima, testo semplice, immagini inline)
 */
function nl_componi($plugin, $d, $modo = 'email')
{
    $m = nl_modello($plugin);
    $font = $m['carattere'] === 'sans' ? '-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif' : 'Georgia,\'Times New Roman\',serif';
    $sfondo = nl_colore($m['sfondo'], '#f3ebdd');
    $scheda = nl_colore($m['scheda'], '#fffdf8');
    $testo = nl_colore($m['testo'], '#2b1d14');
    $acc = nl_colore($m['accento'], '#7a1f2b');
    $al = $m['allinea'] === 'sinistra' ? 'left' : 'center';
    $cw = array('piccola' => 120, 'media' => 170, 'grande' => 230);
    $cw = isset($cw[$m['copertina']]) ? $cw[$m['copertina']] : 170;
    $inline = array();
    $img = function ($cid, $mime, $data) use (&$inline, $modo) {
        if ($modo === 'email') {
            $inline[] = array($cid, $mime, $data);
            return 'cid:' . $cid;
        }
        return 'data:' . $mime . ';base64,' . base64_encode($data);
    };
    $url = (string)$plugin->setting('sito_url', '');
    $rows = '';
    $txt = '';
    $row = function ($html, $pad = '8px 0') use (&$rows, $al) {
        $rows .= '<tr><td align="' . $al . '" style="padding:' . $pad . ';text-align:' . $al . '">' . $html . '</td></tr>';
    };
    $stat = function ($label, $value) use ($testo, $acc) {
        return '<span style="display:inline-block;margin:0 10px 4px 0;font-size:13px;color:' . $testo . ';opacity:.75">' . h($label) . '</span>'
            . '<span style="display:inline-block;font-size:16px;font-weight:bold;color:' . $acc . '">' . h($value) . '</span>';
    };
    foreach ($m['blocchi'] as $k => $on) {
        if (!$on) {
            continue;
        }
        if ($k === 'copertina') {
            $jpg = nl_copertina_jpg((string)$d['cover_file'], $cw * 2);
            if ($jpg) {
                $row('<img src="' . h($img('copertina@libreria', 'image/jpeg', $jpg)) . '" width="' . $cw . '" alt="Copertina di ' . h($d['title']) . '" style="display:inline-block;width:' . $cw
                    . 'px;max-width:100%;height:auto;border-radius:4px;' . ((int)$m['ombra'] ? 'box-shadow:0 6px 18px rgba(0,0,0,.22);' : '') . 'border:0">', '6px 0 14px');
            } elseif ($modo === 'anteprima') {
                $row('<span style="display:inline-block;width:' . $cw . 'px;height:' . round($cw * 1.5) . 'px;background:' . $acc . ';color:#fff;border-radius:4px;font-size:13px;line-height:' . round($cw * 1.5) . 'px">copertina</span>', '6px 0 14px');
            }
        } elseif ($k === 'stelle' && (float)$d['rating'] > 0) {
            $png = nl_stelle_png($d['rating'], $m['stelle_colore']);
            $row(($png ? '<img src="' . h($img('stelle@libreria', 'image/png', $png)) . '" width="117" height="17" alt="' . h(nl_voto_testo($d['rating'])) . '" style="display:inline-block;border:0;vertical-align:middle">' : '')
                . '<span style="font-size:13px;color:' . $testo . ';opacity:.7;margin-left:8px;vertical-align:middle">' . h(nl_voto_testo($d['rating'])) . '</span>', '2px 0 10px');
            $txt .= 'Voto: ' . nl_voto_testo($d['rating']) . "\n";
        } elseif ($k === 'titolo') {
            $row('<div style="font-size:24px;line-height:1.25;font-weight:bold;color:' . $testo . '">' . h($d['title']) . '</div>'
                . ($d['authors'] !== '' ? '<div style="font-size:15px;color:' . $testo . ';opacity:.7;margin-top:4px">' . h($d['authors']) . ($d['pub_year'] ? ' · ' . (int)$d['pub_year'] : '') . '</div>' : ''), '4px 0 10px');
            $txt .= $d['title'] . ($d['authors'] !== '' ? ' — ' . $d['authors'] : '') . "\n";
        } elseif ($k === 'messaggio' && trim($m['messaggio']) !== '') {
            $msg = nl_sostituisci($m['messaggio'], $d);
            $row('<div style="font-size:15px;line-height:1.55;color:' . $testo . '">' . nl_formatta($msg) . '</div>', '6px 0 12px');
            $txt .= "\n" . nl_senza_segni($msg) . "\n";
        } elseif ($k === 'date' && ($d['started_at'] || $d['finished_at']) && !(int)$d['date_unknown']) {
            $h2 = '';
            if ($d['started_at']) {
                $h2 .= $stat('Iniziato', nl_data($d['started_at'])) . '<br>';
                $txt .= 'Iniziato: ' . nl_data($d['started_at']) . "\n";
            }
            if ($d['finished_at']) {
                $h2 .= $stat('Finito', nl_data($d['finished_at']));
                $txt .= 'Finito: ' . nl_data($d['finished_at']) . "\n";
            }
            $row($h2, '6px 0');
        } elseif ($k === 'durata' && $d['giorni'] > 0) {
            $row($stat('Letto in', $d['giorni'] === 1 ? '1 giorno' : $d['giorni'] . ' giorni'), '4px 0');
            $txt .= 'Letto in: ' . $d['giorni'] . ($d['giorni'] === 1 ? ' giorno' : ' giorni') . "\n";
        } elseif ($k === 'ritmo' && $d['media'] > 0) {
            $v = str_replace('.', ',', (string)$d['media']);
            $row($stat('In media', $v . ' pagine al giorno') . '<br><span style="font-size:12px;color:' . $testo . ';opacity:.6">' . (int)$d['pages'] . ' pagine in tutto</span>', '4px 0');
            $txt .= 'In media: ' . $v . ' pagine al giorno (' . (int)$d['pages'] . " pagine in tutto)\n";
        } elseif ($k === 'recensione' && trim((string)$d['review']) !== '') {
            $row('<div style="font-size:15px;line-height:1.55;font-style:italic;color:' . $testo . ';border-' . ($al === 'center' ? 'top' : 'left') . ':3px solid ' . $acc . ';padding:'
                . ($al === 'center' ? '12px 6px 0' : '2px 0 2px 12px') . ';margin-top:6px">«' . nl2br(h(trim($d['review']))) . '»</div>', '10px 0');
            $txt .= "\nLa tua recensione: " . trim($d['review']) . "\n";
        } elseif ($k === 'anno') {
            $t = $d['anno_letti'] === 1 ? 'il primo libro finito nel ' . $d['anno'] : $d['anno_letti'] . ' libri finiti nel ' . $d['anno'];
            $bar = '';
            if ($d['obiettivo'] > 0) {
                $pc = min(100, round($d['anno_letti'] / $d['obiettivo'] * 100));
                $t .= ' · obiettivo ' . $d['obiettivo'];
                $bar = '<table role="presentation" cellpadding="0" cellspacing="0" width="220" align="' . $al . '" style="margin-top:6px;' . ($al === 'center' ? 'margin-left:auto;margin-right:auto;' : '') . '"><tr>'
                    . '<td width="' . max(1, round(220 * $pc / 100)) . '" style="background:' . $acc . ';height:6px;font-size:0;border-radius:3px">&nbsp;</td>'
                    . ($pc < 100 ? '<td style="background:#e2d5bf;height:6px;font-size:0">&nbsp;</td>' : '') . '</tr></table>';
            }
            $row('<div style="font-size:14px;color:' . $testo . '">Con questo sono <b>' . h($t) . '</b></div>' . $bar, '12px 0 4px');
            $txt .= 'Con questo sono ' . $t . "\n";
        } elseif ($k === 'pulsante' && $url !== '' && (int)$d['book_id'] > 0) {
            $row('<a href="' . h($url . 'libro.php?id=' . (int)$d['book_id']) . '" style="display:inline-block;background:' . $acc . ';color:#ffffff;text-decoration:none;padding:11px 18px;border-radius:8px;font-size:14px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">Apri la scheda del libro</a>', '16px 0 4px');
            $txt .= "\nScheda del libro: " . $url . 'libro.php?id=' . (int)$d['book_id'] . "\n";
        } elseif ($k === 'firma' && trim($m['firma']) !== '') {
            $f = nl_sostituisci($m['firma'], $d);
            $row('<div style="font-size:13px;color:' . $testo . ';opacity:.6">' . nl_formatta($f) . '</div>', '18px 0 0');
            $txt .= "\n" . nl_senza_segni($f) . "\n";
        }
    }
    $inner = '<div style="background:' . $sfondo . ';padding:26px 12px;font-family:' . $font . '">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:540px;margin:0 auto;background:' . $scheda . ';border-radius:14px">'
        . '<tr><td style="padding:26px 28px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-family:' . $font . '">' . $rows . '</table></td></tr></table>'
        . '<p style="max-width:540px;margin:12px auto 0;font-size:11px;color:#8a847c;text-align:center;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">'
        . 'Ricevi questa email perché hai finito un libro nella ' . h(setting('brand_title')) . '. Puoi non riceverle più da «Il mio account».</p></div>';
    $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head><body style="margin:0;padding:0;background:' . $sfondo . '">' . $inner . '</body></html>';
    $oggetto = ne_header_safe(nl_senza_segni(nl_sostituisci($m['oggetto'], $d)));
    $txt .= "\n— " . setting('brand_title') . " · puoi non ricevere più queste email da «Il mio account»\n";
    return array($oggetto !== '' ? $oggetto : 'Hai finito un libro', $html, $inner, $txt, $inline);
}

/* ---------------- Destinatari e invio ---------------- */

function nl_destinatari($plugin, $d)
{
    $to = array();
    if (!empty($d['email']) && (int)$d['email_notify'] === 1 && ne_email_ok($d['email'])) {
        $to[] = $d['email'];
    }
    if ($plugin->setting('lt_copia', '0') === '1') {
        foreach (ne_destinatari($plugin) as $e) {
            if (!in_array(strtolower($e), array_map('strtolower', $to), true)) {
                $to[] = $e;
            }
        }
    }
    return $to;
}

function nl_invia($plugin, $sid)
{
    $d = nl_dati($sid);
    if (!$d || $d['status'] !== 'letto') {
        return array(false, 'Lettura non trovata o non finita.');
    }
    $to = nl_destinatari($plugin, $d);
    list($ogg, $html, , $txt, $inline) = nl_componi($plugin, $d, 'email');
    if (!$to) {
        ne_registra($plugin, 'lettura', $ogg . ' (' . $d['nome'] . ')', false, 'L\'utente non ha un indirizzo email (o non vuole ricevere email) e la copia agli amministratori è spenta.', 0);
        return array(false, 'Nessun destinatario.');
    }
    return ne_spedisci($plugin, 'lettura', $to, $ogg . ' (' . $d['nome'] . ')', $ogg, $txt, $html, $inline);
}

/* ---------------- Coda: si aspetta qualche minuto, cosi' entra anche il voto dato subito dopo ---------------- */

function nl_coda($plugin)
{
    $q = json_decode((string)$plugin->setting('lt_coda', '[]'), true);
    return is_array($q) ? $q : array();
}

function nl_accoda($plugin, $sid, $pronto = false)
{
    $fatti = json_decode((string)$plugin->setting('lt_inviate', '[]'), true);
    if (in_array((int)$sid, is_array($fatti) ? $fatti : array(), true)) {
        return; // gia' inviata (es. libro segnato di nuovo come finito)
    }
    $q = nl_coda($plugin);
    $q[(string)(int)$sid] = array('t' => isset($q[(string)(int)$sid]) ? $q[(string)(int)$sid]['t'] : time(), 'pronto' => $pronto ? 1 : 0);
    $plugin->save_setting('lt_coda', json_encode($q));
}

function nl_coda_lavora($plugin)
{
    if ($plugin->setting('lt_attivo', '0') !== '1' || !ne_server_pronto($plugin)) {
        return;
    }
    $q = nl_coda($plugin);
    if (!$q) {
        return;
    }
    $lock = @fopen($plugin->data_dir() . '/lettura.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
        return;
    }
    load_settings(true);
    $q = nl_coda($plugin);
    $wait = (int)$plugin->setting('lt_ritardo', '10') * 60;
    $fatti = json_decode((string)$plugin->setting('lt_inviate', '[]'), true);
    $fatti = is_array($fatti) ? $fatti : array();
    foreach ($q as $sid => $it) {
        if (!$it['pronto'] && $it['t'] > time() - $wait) {
            continue;
        }
        unset($q[$sid]);
        $plugin->save_setting('lt_coda', json_encode($q)); // tolta subito: niente doppioni se l'invio e' lento
        if ($it['t'] < time() - 7 * 86400) {
            continue; // troppo vecchia (es. server di posta spento per giorni)
        }
        nl_invia($plugin, (int)$sid);
        array_unshift($fatti, (int)$sid);
        $plugin->save_setting('lt_inviate', json_encode(array_slice($fatti, 0, 500)));
    }
    flock($lock, LOCK_UN);
    fclose($lock);
}

$plugin->on('lettura_terminata', function ($uid, $sid, $bid) use ($plugin) {
    if ($plugin->setting('lt_attivo', '0') !== '1') {
        return;
    }
    nl_accoda($plugin, $sid, (int)$plugin->setting('lt_ritardo', '10') === 0);
    ne_dopo(function () use ($plugin) { nl_coda_lavora($plugin); });
});

// voto salvato poco dopo la fine: l'email parte subito, con le stelle
$plugin->on('lettura_valutata', function ($uid, $sid, $bid) use ($plugin) {
    $q = nl_coda($plugin);
    if (isset($q[(string)(int)$sid])) {
        nl_accoda($plugin, $sid, true);
        ne_dopo(function () use ($plugin) { nl_coda_lavora($plugin); });
    }
});

/* ---------------- Pagina del pannello ---------------- */

$plugin->on('admin_fondo', function ($html) use ($plugin) {
    return get('sez') === 'plg-notifiche-email-lettura' ? $html . $plugin->js('file/editor.js') : $html;
});

$plugin->admin_page('lettura', 'Email di fine lettura', function ($plugin) {
    $m = nl_modello($plugin);
    $nomi = nl_blocchi_nomi();
    $on = $plugin->setting('lt_attivo', '0') === '1';
    $sel = function ($v, $cur) { return $v === $cur ? ' selected' : ''; };
    // letture finite di recente, per l'anteprima
    $recenti = db()->query("SELECT s.id, b.title, u.username, u.display_name, s.finished_at FROM reading_sessions s JOIN books b ON b.id = s.book_id JOIN users u ON u.id = s.user_id "
        . "WHERE s.status = 'letto' ORDER BY s.finished_at DESC, s.id DESC LIMIT 25")->fetchAll();
    $sid = (int)get('lettura');
    $d = $sid ? nl_dati($sid) : null;
    if (!$d && $recenti) {
        $d = nl_dati((int)$recenti[0]['id']);
    }
    if (!$d) {
        $d = nl_dati_esempio();
    }
    $utenti = users_email_ready() ? db()->query('SELECT username, display_name, email, email_notify FROM users WHERE active = 1 ORDER BY username')->fetchAll() : array();

    echo '<div class="ne-head"><img src="' . h($plugin->url('file/icona.png')) . '" alt="" width="56" height="56"><div><b>' . ($on ? 'Attiva' : 'Spenta') . '</b><span class="sub">'
        . ($on ? 'Chi finisce un libro riceve il riepilogo della lettura.' : 'Accendila qui sotto: chi finisce un libro riceverà il riepilogo della lettura.')
        . (ne_server_pronto($plugin) ? '' : ' <b>Prima imposta il server di posta</b> nella pagina <a class="link" href="' . h($plugin->admin_url('impostazioni')) . '">Notifiche email</a>.') . '</span></div></div>';
    if (!users_email_ready()) {
        echo '<div class="alert error">Per l\'email agli utenti serve la Libreria di Casa 1.9.2 (campo email degli utenti).</div>';
    }

    echo '<div class="nl-grid"><div>';
    // --- quando e a chi
    echo '<div class="card">' . $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="lt_invio">'
        . '<div class="ct">Quando e a chi</div>'
        . '<label class="check"><input type="checkbox" name="lt_attivo" value="1"' . ($on ? ' checked' : '') . '> <span><b>Manda l\'email quando un utente segna un libro come finito</b></span></label>'
        . '<label class="lab">Attesa prima dell\'invio</label><select class="input" name="lt_ritardo">';
    foreach (array(0 => 'Subito', 5 => '5 minuti', 10 => '10 minuti', 30 => '30 minuti') as $v => $t) {
        echo '<option value="' . $v . '"' . $sel((string)$v, $plugin->setting('lt_ritardo', '10')) . '>' . $t . '</option>';
    }
    echo '</select><p class="hint">Con l\'attesa, se il lettore dà il voto subito dopo aver finito, le stelle entrano nell\'email (che in quel caso parte appena salva il voto).</p>'
        . '<label class="check"><input type="checkbox" name="lt_copia" value="1"' . ($plugin->setting('lt_copia', '0') === '1' ? ' checked' : '') . '> <span>Manda una copia anche ai destinatari degli avvisi (Notifiche email)</span></label>'
        . '<div class="savebar"><button class="btn primary small" type="submit">Salva</button></div></form>';
    if ($utenti) {
        echo '<div class="ct sep">Chi la riceve</div><table class="tbl compact">';
        foreach ($utenti as $u) {
            $ok = $u['email'] && (int)$u['email_notify'];
            echo '<tr><td>' . h($u['display_name'] !== '' ? $u['display_name'] : $u['username']) . '</td><td>'
                . ($ok ? '<span class="ok-text">' . h($u['email']) . '</span>' : '<span class="muted">' . ($u['email'] ? 'non vuole email' : 'senza email') . '</span>') . '</td></tr>';
        }
        echo '</table><p class="hint">L\'email si aggiunge in Gestione → Utenti oppure da ognuno in «Il mio account».</p>';
    }
    echo '</div>';

    // --- impaginazione
    echo '<div class="card">' . $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="lt_modello">'
        . '<div class="ct">Impaginazione</div><p class="sub">Scegli quali blocchi mostrare e in che ordine (1 = in alto).</p><table class="tbl compact nl-blocchi"><tbody>';
    $i = 0;
    $n = count($m['blocchi']);
    foreach ($m['blocchi'] as $k => $v) {
        $i++;
        echo '<tr><td><label class="check"><input type="checkbox" name="b_on[' . h($k) . ']" value="1"' . ($v ? ' checked' : '') . '> ' . h($nomi[$k]) . '</label></td>'
            . '<td class="num"><select class="input" name="b_pos[' . h($k) . ']" aria-label="Posizione">';
        for ($p = 1; $p <= $n; $p++) {
            echo '<option value="' . $p . '"' . ($p === $i ? ' selected' : '') . '>' . $p . '</option>';
        }
        echo '</select></td></tr>';
    }
    echo '</tbody></table>'
        . '<label class="lab">Oggetto</label><input class="input" name="oggetto" maxlength="150" value="' . h($m['oggetto']) . '">'
        . '<label class="lab" for="nl-msg">Messaggio</label>' . '<div class="nl-tools" role="toolbar" aria-label="Formattazione"><button type="button" class="nl-tb" data-nl-wrap="**" data-nl-target="nl-msg" title="Grassetto (Ctrl+B)"><b>G</b></button><button type="button" class="nl-tb" data-nl-wrap="*" data-nl-target="nl-msg" title="Corsivo (Ctrl+I)"><i>C</i></button><span class="nl-tb-hint">seleziona il testo e premi un pulsante</span></div>'
        . '<textarea class="input" id="nl-msg" name="messaggio" rows="4" maxlength="1500" data-nl-fmt>' . h($m['messaggio']) . '</textarea>'
        . '<label class="lab" for="nl-firma">Firma</label>' . '<div class="nl-tools" role="toolbar" aria-label="Formattazione"><button type="button" class="nl-tb" data-nl-wrap="**" data-nl-target="nl-firma" title="Grassetto (Ctrl+B)"><b>G</b></button><button type="button" class="nl-tb" data-nl-wrap="*" data-nl-target="nl-firma" title="Corsivo (Ctrl+I)"><i>C</i></button><span class="nl-tb-hint">seleziona il testo e premi un pulsante</span></div>'
        . '<input class="input" id="nl-firma" name="firma" maxlength="200" value="' . h($m['firma']) . '" data-nl-fmt>'
        . '<p class="hint">Formattazione: <code>**grassetto**</code> e <code>*corsivo*</code> (anche con i pulsanti). Si possono usare: <code>{nome}</code> <code>{titolo}</code> <code>{autore}</code> <code>{pagine}</code> <code>{giorni}</code> <code>{media}</code> '
        . '<code>{inizio}</code> <code>{fine}</code> <code>{voto}</code> <code>{anno_letti}</code> <code>{sito}</code></p>'
        . '<div class="ne-row"><div><label class="lab">Copertina</label><select class="input" name="copertina">'
        . '<option value="piccola"' . $sel('piccola', $m['copertina']) . '>Piccola</option><option value="media"' . $sel('media', $m['copertina']) . '>Media</option><option value="grande"' . $sel('grande', $m['copertina']) . '>Grande</option></select></div>'
        . '<div><label class="lab">Allineamento</label><select class="input" name="allinea"><option value="centro"' . $sel('centro', $m['allinea']) . '>Al centro</option><option value="sinistra"' . $sel('sinistra', $m['allinea']) . '>A sinistra</option></select></div></div>'
        . '<div class="ne-row"><div><label class="lab">Carattere</label><select class="input" name="carattere"><option value="serif"' . $sel('serif', $m['carattere']) . '>Classico (con grazie)</option><option value="sans"' . $sel('sans', $m['carattere']) . '>Moderno (senza grazie)</option></select></div>'
        . '<div><label class="check" style="margin-top:28px"><input type="checkbox" name="ombra" value="1"' . ((int)$m['ombra'] ? ' checked' : '') . '> Ombra sotto la copertina</label></div></div>'
        . '<div class="nl-colori">';
    foreach (array('sfondo' => 'Sfondo', 'scheda' => 'Scheda', 'testo' => 'Testo', 'accento' => 'Accento', 'stelle_colore' => 'Stelle') as $k => $t) {
        echo '<label><input type="color" name="' . $k . '" value="' . h(nl_colore($m[$k], '#000000')) . '"><span>' . $t . '</span></label>';
    }
    echo '</div><div class="savebar"><button class="btn primary small" type="submit">Salva e aggiorna l\'anteprima</button></div></form>'
        . $plugin->form_start('data-confirm="Tornare all\'impaginazione predefinita?"') . '<input type="hidden" name="op" value="lt_base"><button class="btn link small" type="submit">Ripristina l\'impaginazione predefinita</button></form>'
        . '</div></div>';

    // --- anteprima
    list($ogg, , $inner) = nl_componi($plugin, $d, 'anteprima');
    echo '<div class="card nl-prev"><div class="ct">Anteprima</div>';
    if ($recenti) {
        echo '<form method="get" class="row-btn"><input type="hidden" name="sez" value="plg-notifiche-email-lettura"><select class="input" name="lettura" aria-label="Lettura per l\'anteprima">';
        foreach ($recenti as $r) {
            echo '<option value="' . (int)$r['id'] . '"' . ((int)$d['id'] === (int)$r['id'] ? ' selected' : '') . '>' . h(str_cut($r['title'], 50) . ' — ' . ($r['display_name'] !== '' ? $r['display_name'] : $r['username'])) . '</option>';
        }
        echo '</select><button class="btn ghost small" type="submit">Mostra</button></form>';
    } else {
        echo '<p class="hint">Nessuno ha ancora finito un libro: l\'anteprima usa una lettura di esempio.</p>';
    }
    echo '<div class="nl-subject"><span>Oggetto</span> ' . h($ogg) . '</div><div class="nl-frame">' . $inner . '</div>';
    if ((int)$d['id'] > 0) {
        echo $plugin->form_start('class="row-btn"') . '<input type="hidden" name="op" value="lt_prova"><input type="hidden" name="sid" value="' . (int)$d['id'] . '">'
            . '<button class="btn ghost small" type="submit"' . (ne_server_pronto($plugin) && ne_destinatari($plugin) ? '' : ' disabled') . '>Invia questa anteprima ai destinatari degli avvisi</button></form>';
    }
    echo '</div></div>';
}, array(
    'salva' => function ($plugin) {
        $op = post('op');
        if ($op === 'lt_invio') {
            $plugin->save_setting('lt_attivo', post('lt_attivo') === '1' ? '1' : '0');
            $plugin->save_setting('lt_ritardo', in_array(post('lt_ritardo'), array('0', '5', '10', '30'), true) ? post('lt_ritardo') : '10');
            $plugin->save_setting('lt_copia', post('lt_copia') === '1' ? '1' : '0');
            flash('Impostazioni salvate.');
        } elseif ($op === 'lt_modello') {
            $base = nl_modello_base();
            $pos = isset($_POST['b_pos']) && is_array($_POST['b_pos']) ? $_POST['b_pos'] : array();
            $ons = isset($_POST['b_on']) && is_array($_POST['b_on']) ? $_POST['b_on'] : array();
            $ord = array();
            $i = 0;
            foreach (nl_modello($plugin)['blocchi'] as $k => $v) {
                $i++;
                $np = isset($pos[$k]) ? (int)$pos[$k] : 99;
                // a parita' di posizione vince il blocco appena spostato (es. "Titolo" messo al 1° posto va sopra la copertina)
                $ord[$k] = array($np, $np !== $i ? 0 : 1, $i);
            }
            uasort($ord, function ($a, $b) { return $a[0] !== $b[0] ? $a[0] - $b[0] : ($a[1] !== $b[1] ? $a[1] - $b[1] : $a[2] - $b[2]); });
            $bl = array();
            foreach ($ord as $k => $x) {
                $bl[$k] = !empty($ons[$k]) ? 1 : 0;
            }
            $m = array('blocchi' => $bl,
                'oggetto' => str_cut(ne_header_safe(post('oggetto')), 150),
                'messaggio' => str_cut(str_replace("\r", '', (string)post('messaggio')), 1500),
                'firma' => str_cut(ne_header_safe(post('firma')), 200),
                'copertina' => in_array(post('copertina'), array('piccola', 'media', 'grande'), true) ? post('copertina') : 'media',
                'ombra' => post('ombra') === '1' ? 1 : 0,
                'allinea' => post('allinea') === 'sinistra' ? 'sinistra' : 'centro',
                'carattere' => post('carattere') === 'sans' ? 'sans' : 'serif');
            foreach (array('sfondo', 'scheda', 'testo', 'accento', 'stelle_colore') as $k) {
                $m[$k] = nl_colore(post($k), $base[$k]);
            }
            $plugin->save_setting('lt_modello', json_encode($m, JSON_UNESCAPED_UNICODE));
            flash('Impaginazione salvata.');
        } elseif ($op === 'lt_base') {
            $plugin->save_setting('lt_modello', '');
            flash('Impaginazione predefinita ripristinata.');
        } elseif ($op === 'lt_prova') {
            $d = nl_dati((int)post('sid'));
            if (!$d) {
                flash('Lettura non trovata.', 'error');
                return;
            }
            list($ogg, $html, , $txt, $inline) = nl_componi($plugin, $d, 'email');
            $r = ne_spedisci($plugin, 'anteprima', ne_destinatari($plugin), 'Anteprima: ' . $ogg, '[Anteprima] ' . $ogg, $txt, $html, $inline, true);
            flash($r[0] ? 'Anteprima inviata ai destinatari degli avvisi.' : 'Invio non riuscito: ' . $r[1], $r[0] ? 'success' : 'error');
        }
    },
));
