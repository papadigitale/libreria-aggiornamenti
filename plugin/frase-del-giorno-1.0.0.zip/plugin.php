<?php
/*
 * Frase del giorno per la Libreria di Casa.
 *  - Ogni giorno una frase famosa da un libro o da una poesia, la stessa per tutti:
 *    dalla citazione del giorno di Wikiquote (solo quella di oggi, niente archivio sul server),
 *    dalla raccolta dei classici dentro il plugin (frasi.txt) o dalle frasi aggiunte dall'Admin.
 *  - Un messaggio all'apertura dell'app (una volta al giorno o a ogni apertura), con il link al libro se c'e' nella Libreria.
 *  - Un avviso nella campanella (e sul telefono) all'ora scelta.
 *  - Ognuno puo' spegnere il messaggio o l'avviso (Il mio account o la pagina Frase del giorno).
 *  - Decide solo l'Admin: Gestione → Plugin → Frase del giorno (con l'anteprima dell'aspetto).
 */
require_once __DIR__ . '/motore.php';
require_once __DIR__ . '/pannello.php';

$plugin->on_activate(function ($plugin, $prima) {
    fdg_crea_tabelle($plugin);
});

$plugin->on_remove(function ($plugin, $cancella) {
    if ($cancella) {
        foreach (array('frasi', 'preferenze') as $t) {
            db()->exec('DROP TABLE IF EXISTS ' . $plugin->table($t));
        }
    }
});

/* ---------------- Sul sito ---------------- */

$fdg_sito = function () use ($plugin) {
    return is_user() && !empty(fdg_imp($plugin)['attivo']);
};

$plugin->on('html_testa', function ($html) use ($plugin, $fdg_sito) {
    return $fdg_sito() ? $html . $plugin->css('file/frase.css') : $html;
});

$plugin->on('html_fondo', function ($html) use ($plugin, $fdg_sito) {
    if (!$fdg_sito()) {
        return $html;
    }
    return $html . fdg_popup($plugin) . $plugin->js('file/frase.js');
});

// Il messaggio all'apertura: solo se va mostrato in questa pagina, a questo utente, adesso
function fdg_popup($plugin)
{
    $imp = fdg_imp($plugin);
    $prova = is_admin() && get('fdg') === 'prova';
    if (!$prova && $imp['popup'] === 'mai') {
        return '';
    }
    $s = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '');
    if (!$prova && (($s === 'plg.php' && get('p') === $plugin->id) || ($imp['dove'] === 'libreria' && $s !== 'libreria.php'))) {
        return '';
    }
    $p = fdg_pref($plugin, current_uid());
    if (!$prova && (!$p['popup'] || ($imp['popup'] === 'giorno' && $p['visto'] === date('Y-m-d')))) {
        return '';
    }
    $f = fdg_oggi($plugin);
    if (!$f) {
        return '';
    }
    $asp = fdg_asp($plugin);
    $box = fdg_box_html($plugin, $f, $asp, 'popup', array(
        'libro' => !empty($imp['link_libro']) ? fdg_libro($f) : null,
        'puo_aggiungere' => !empty($imp['link_aggiungi']) && can_edit(),
        'condividi' => !empty($imp['condividi']),
        'basta' => !$prova,
    ));
    $modo = $prova ? 'prova' : $imp['popup'];
    return str_replace('<div class="fdg fdg-popup"', '<div class="fdg fdg-popup" data-fdg-popup data-modo="' . h($modo) . '" data-giorno="' . h($f['d'])
        . '" data-ritardo="' . max(0, min(10, (int)$imp['ritardo'])) . '"', $box);
}

/* ---------------- Il mio account: le due scelte di ognuno ---------------- */

$plugin->on('pagina_account', function ($html) use ($plugin, $fdg_sito) {
    if (!$fdg_sito()) {
        return $html;
    }
    $imp = fdg_imp($plugin);
    $p = fdg_pref($plugin, current_uid());
    return $html . '<div class="card fdg-acc"><div class="ct">' . fdg_icona(18) . ' Frase del giorno</div>'
        . fdg_form_pref($plugin, $p, $imp)
        . '<a class="btn ghost small" href="' . h($plugin->site_url('oggi')) . '">Leggi la frase di oggi</a></div>';
});

function fdg_icona($n = 20)
{
    return '<svg class="i fdg-i" width="' . (int)$n . '" height="' . (int)$n . '" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 11H6.5a.5.5 0 0 1-.5-.5V8a3 3 0 0 1 3-3M10 11v2.5A4.5 4.5 0 0 1 5.5 18M18 11h-3.5a.5.5 0 0 1-.5-.5V8a3 3 0 0 1 3-3M18 11v2.5a4.5 4.5 0 0 1-4.5 4.5"/></svg>';
}

function fdg_form_pref($plugin, $p, $imp)
{
    $h = '<form method="post" action="' . h($plugin->site_url('oggi')) . '" class="fdg-pref" data-fdg-pref>' . csrf_field()
        . '<input type="hidden" name="action" value="plg_salva"><input type="hidden" name="op" value="pref">'
        . '<input type="hidden" name="back" value="' . h($plugin->site_url('oggi', array('salvato' => 1))) . '">';
    if ($imp['popup'] !== 'mai') {
        $h .= '<label class="check switch"><input type="checkbox" name="popup" value="1"' . ($p['popup'] ? ' checked' : '') . '><span>Mostrami la frase quando apro l\'app</span></label>';
    } else {
        $h .= '<input type="hidden" name="popup" value="' . ($p['popup'] ? '1' : '0') . '">';
    }
    if (!empty($imp['avviso'])) {
        $h .= '<label class="check switch"><input type="checkbox" name="avviso" value="1"' . ($p['avviso'] ? ' checked' : '') . '><span>Avvisami nella campanella'
            . ' (alle ' . h($imp['ora']) . ')</span></label>';
    } else {
        $h .= '<input type="hidden" name="avviso" value="' . ($p['avviso'] ? '1' : '0') . '">';
    }
    return $h . '<noscript><button class="btn small" type="submit">Salva</button></noscript><span class="fdg-salvato" data-fdg-salvato hidden>Salvato</span></form>';
}

/* ---------------- Pagina «Frase del giorno» (dall'avviso o dal menu) ---------------- */

$plugin->site_page('oggi', 'Frase del giorno', function ($plugin) {
    fdg_pagina_oggi($plugin);
}, array('ruolo' => 'utente', 'menu' => !empty(fdg_imp($plugin)['menu']) && !empty(fdg_imp($plugin)['attivo']), 'icona' => 'page', 'salva' => function ($plugin) {
    if (post('op') === 'pref' && is_user()) {
        fdg_pref_salva($plugin, current_uid(), array('popup' => post('popup') === '1' ? 1 : 0, 'avviso' => post('avviso') === '1' ? 1 : 0));
    }
}));

function fdg_pagina_oggi($plugin)
{
    $imp = fdg_imp($plugin);
    $asp = fdg_asp($plugin);
    echo '<div class="fdg-pg"><h1 class="h1">Frase del giorno</h1>';
    if (get('salvato') === '1') {
        echo '<div class="alert success" role="status">Scelte salvate.</div>';
    }
    $f = !empty($imp['attivo']) ? fdg_oggi($plugin) : null;
    if (!$f) {
        echo '<p class="sub">Oggi non c\'è nessuna frase.</p></div>';
        return;
    }
    if (is_user()) {
        $p = fdg_pref($plugin, current_uid());
        if ($p['visto'] !== $f['d']) {
            fdg_pref_salva($plugin, current_uid(), array('visto' => $f['d']));
        }
    }
    echo fdg_box_html($plugin, $f, $asp, 'pagina', array(
        'libro' => !empty($imp['link_libro']) ? fdg_libro($f) : null,
        'puo_aggiungere' => !empty($imp['link_aggiungi']) && can_edit(),
        'condividi' => !empty($imp['condividi']),
    ));
    $st = json_decode((string)$plugin->setting('storico', '[]'), true);
    $prima = array();
    foreach (is_array($st) ? $st : array() as $x) {
        if (isset($x['d'], $x['t']) && $x['d'] < $f['d']) {
            $prima[] = $x;
        }
    }
    if ($prima) {
        echo '<h2 class="fdg-h2">I giorni scorsi</h2><div class="fdg-prima">';
        foreach (array_slice($prima, 0, 7) as $x) {
            echo '<figure class="fdg-p"><time>' . h(fdg_data_lunga($x['d'])) . '</time><blockquote>' . nl2br(h($x['t'])) . '</blockquote>'
                . '<figcaption>— ' . h($x['a']) . ($x['o'] !== '' ? ', <i>' . h($x['o']) . '</i>' : '') . '</figcaption></figure>';
        }
        echo '</div>';
    }
    if (is_user() && ($imp['popup'] !== 'mai' || !empty($imp['avviso']))) {
        echo '<div class="card fdg-acc"><div class="ct">Le mie scelte</div>' . fdg_form_pref($plugin, fdg_pref($plugin, current_uid()), $imp) . '</div>';
    }
    echo '</div>';
}

/* ---------------- Chiamate dello script ---------------- */

$plugin->api('vista', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    fdg_pref_salva($plugin, current_uid(), array('visto' => date('Y-m-d')));
    return array('vista' => true);
}, array('metodo' => 'POST'));

$plugin->api('basta', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    fdg_pref_salva($plugin, current_uid(), array('popup' => 0, 'visto' => date('Y-m-d')));
    return array('spento' => true);
}, array('metodo' => 'POST'));

$plugin->api('pref', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    fdg_pref_salva($plugin, current_uid(), array('popup' => post('popup') === '1' ? 1 : 0, 'avviso' => post('avviso') === '1' ? 1 : 0));
    return array('salvato' => true);
}, array('metodo' => 'POST'));

/* ---------------- Pannello (solo Admin) ---------------- */

$plugin->admin_page('frase', 'Frase del giorno', function ($plugin) {
    fdg_pannello($plugin);
}, array('salva' => function ($plugin) {
    fdg_pannello_salva($plugin);
}));

$plugin->on('admin_testa', function ($html) use ($plugin) {
    $sez = isset($_GET['sez']) ? (string)$_GET['sez'] : '';
    return $sez === 'plg-' . $plugin->id . '-frase' ? $html . $plugin->css('file/frase.css') . $plugin->css('file/pannello.css') : $html;
});
$plugin->on('admin_fondo', function ($html) use ($plugin) {
    $sez = isset($_GET['sez']) ? (string)$_GET['sez'] : '';
    return $sez === 'plg-' . $plugin->id . '-frase' ? $html . $plugin->js('file/pannello.js') : $html;
});

/* ---------------- Avviso all'ora scelta ---------------- */

$plugin->on('lavori_periodici', function () use ($plugin) {
    fdg_avviso($plugin);
});
$plugin->on('ogni_giorno', function () use ($plugin) {
    fdg_avviso($plugin);
});
