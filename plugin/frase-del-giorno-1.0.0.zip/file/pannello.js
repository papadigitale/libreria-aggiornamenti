/* Frase del giorno — pannello: anteprima che segue le scelte, altra frase, telefono/computer, ricerca nella raccolta */
(function () {
  'use strict';
  var pan = document.querySelector('.fdg-pan');
  if (!pan) { return; }
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // ---- ricerca nella raccolta ----
  var cerca = $('[data-fdg-cerca]', pan);
  if (cerca) {
    var nessuna = $('[data-fdg-nessuna]', pan);
    cerca.addEventListener('input', function () {
      var q = cerca.value.trim().toLowerCase();
      var n = 0;
      $$('[data-fdg-r]', pan).forEach(function (tr) {
        var si = q === '' || tr.getAttribute('data-fdg-r').indexOf(q) !== -1;
        tr.hidden = !si;
        if (si) { n++; }
      });
      if (nessuna) { nessuna.hidden = n > 0; }
    });
  }

  // ---- anteprima ----
  var form = $('[data-fdg-modulo]', pan);
  var stage = $('[data-fdg-stage]', pan);
  var box = stage ? $('.fdg', stage) : null;
  if (!form || !box) { return; }
  var campioni = [];
  try { campioni = JSON.parse($('#fdg-campioni').textContent) || []; } catch (e) { campioni = []; }
  var quale = 0;
  var timer = null;
  var batti = null;
  var p = $('.fdg-q p', box);
  var originale = p ? p.innerHTML : '';

  function val(n) {
    var el = form.elements[n];
    if (!el) { return ''; }
    if (el.length !== undefined && !el.tagName) { // gruppo di radio
      for (var i = 0; i < el.length; i++) { if (el[i].checked) { return el[i].value; } }
      return '';
    }
    return el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value;
  }
  function applica() {
    var stile = val('stile') || 'carta';
    box.setAttribute('data-stile', stile);
    ['forma', 'animazione', 'carattere', 'dimensione', 'ornamento', 'angoli', 'velo', 'chiusura'].forEach(function (k) {
      var a = { animazione: 'anim', carattere: 'car', dimensione: 'dim', ornamento: 'orn', chiusura: 'chiudi' }[k] || k;
      box.setAttribute('data-' + a, val(k));
    });
    if (stile === 'mio') {
      box.style.setProperty('--fdg-bg', val('c_sfondo'));
      box.style.setProperty('--fdg-ink', val('c_testo'));
      box.style.setProperty('--fdg-acc', val('c_accento'));
    } else {
      ['--fdg-bg', '--fdg-ink', '--fdg-acc'].forEach(function (v) { box.style.removeProperty(v); });
    }
    var t = $('[data-fdg-titolo]', box);
    if (t) { t.textContent = val('titolo').trim() || 'La frase del giorno'; }
    var d = $('[data-fdg-data]', box);
    if (d) { d.hidden = val('data') !== '1'; }
    $$('[data-fdg-per]', form).forEach(function (x) { x.hidden = x.getAttribute('data-fdg-per') !== stile; });
    $$('[data-fdg-per-sorpresa]', form).forEach(function (x) { x.hidden = val('sorpresa') !== '1'; });
  }
  function scrivi() {
    if (!p) { return; }
    var nodi = [];
    (function giro(n) {
      Array.prototype.forEach.call(n.childNodes, function (c) {
        if (c.nodeType === 3) { nodi.push([c, c.nodeValue]); c.nodeValue = ''; } else { giro(c); }
      });
    })(p);
    var tot = nodi.reduce(function (s, x) { return s + x[1].length; }, 0);
    var passo = Math.max(14, Math.min(38, 2400 / Math.max(1, tot)));
    var i = 0, j = 0;
    box.classList.add('scrive');
    batti = function () {
      if (i >= nodi.length) { box.classList.remove('scrive'); batti = null; conto(); return; }
      var x = nodi[i];
      j++;
      x[0].nodeValue = x[1].slice(0, j);
      if (j >= x[1].length) { i++; j = 0; }
      timer = setTimeout(batti, passo);
    };
    batti();
  }
  function conto() {
    var sec = parseInt(box.getAttribute('data-chiudi'), 10) || 0;
    box.classList.remove('conto');
    if (sec > 0) {
      void box.offsetWidth;
      box.style.setProperty('--fdg-t', sec + 's');
      box.classList.add('conto');
      timer = setTimeout(function () { chiudi(true); }, sec * 1000);
    }
  }
  function rivedi() {
    clearTimeout(timer);
    box.classList.remove('aperto', 'chiude', 'conto', 'scrive');
    if (p) { p.innerHTML = originale; }
    void box.offsetWidth;
    box.classList.add('aperto');
    if (box.getAttribute('data-anim') === 'scrittura') { scrivi(); } else { conto(); }
  }
  // nell'anteprima la chiusura si vede, poi il messaggio riappare
  function chiudi(riapri) {
    clearTimeout(timer);
    box.classList.add('chiude');
    timer = setTimeout(function () {
      box.classList.remove('aperto', 'chiude', 'conto');
      if (riapri !== false) { timer = setTimeout(rivedi, 700); }
    }, 320);
  }
  function capolettera(t) {
    var righe = t.split('\n');
    var h = righe.map(esc).join('<br>');
    var m = /^(\W*)(\w)/u.exec(righe[0]);
    if (m) {
      var pre = esc(m[1] + m[2]);
      h = esc(m[1]) + '<span class="fdg-cap">' + esc(m[2]) + '</span>' + h.slice(pre.length);
    }
    return h;
  }
  function altra() {
    if (!campioni.length) { return; }
    quale = (quale + 1) % campioni.length;
    var c = campioni[quale];
    originale = capolettera(c.t);
    var a = $('[data-fdg-autore]', box);
    var o = $('[data-fdg-opera]', box);
    if (a) { a.textContent = c.a; }
    if (o) {
      o.textContent = c.o || '';
      var virg = o.previousSibling;
      if (virg && virg.nodeType === 3) { virg.nodeValue = c.o ? ', ' : ''; }
    }
    rivedi();
  }

  form.addEventListener('input', function (e) {
    applica();
    if (e.target.name === 'animazione' || e.target.name === 'forma' || e.target.name === 'chiusura') { rivedi(); }
  });
  form.addEventListener('change', function (e) {
    applica();
    if (e.target.name === 'stile' || e.target.name === 'ornamento' || e.target.name === 'velo') { rivedi(); }
  });
  var bRiv = $('[data-fdg-rivedi]', pan);
  if (bRiv) { bRiv.addEventListener('click', rivedi); }
  var bAltra = $('[data-fdg-altra]', pan);
  if (bAltra) { bAltra.addEventListener('click', altra); }
  $$('[data-fdg-schermo]', pan).forEach(function (b) {
    b.addEventListener('click', function () {
      stage.setAttribute('data-schermo', b.getAttribute('data-fdg-schermo'));
      $$('[data-fdg-schermo]', pan).forEach(function (x) { x.classList.toggle('on', x === b); });
      rivedi();
    });
  });
  // nell'anteprima link e pulsanti non portano da nessuna parte
  stage.addEventListener('click', function (e) {
    var t = e.target.closest('a,button,[data-fdg-chiudi]');
    if (!t) { return; }
    e.preventDefault();
    if (t.hasAttribute('data-fdg-chiudi') || t.hasAttribute('data-fdg-basta')) { chiudi(true); }
  });
  applica();
  setTimeout(rivedi, 250);
})();
