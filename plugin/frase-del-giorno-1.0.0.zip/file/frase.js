// Frase del giorno: il messaggio all'apertura, «Condividi», «Non mostrarmela più», le scelte in Il mio account
(function () {
  'use strict';
  var cfg = {};
  try { cfg = JSON.parse(document.getElementById('app-config').textContent); } catch (e) { /* niente */ }
  var API = 'api.php?action=plg&p=frase-del-giorno&f=';
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function manda(nome, dati) {
    var fd = new FormData();
    fd.append('csrf', cfg.csrf || '');
    Object.keys(dati || {}).forEach(function (k) { fd.append(k, dati[k]); });
    return fetch(API + nome, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf || '' } })
      .then(function (r) { return r.json(); });
  }
  function ss(k, v) {
    try {
      if (v === undefined) { return window.sessionStorage.getItem(k); }
      window.sessionStorage.setItem(k, v);
    } catch (e) { /* memoria del browser non disponibile */ }
    return null;
  }
  function avviso(t) {
    var a = document.createElement('div');
    a.className = 'fdg-toast';
    a.setAttribute('role', 'status');
    a.textContent = t;
    document.body.appendChild(a);
    setTimeout(function () { a.classList.add('via'); }, 2600);
    setTimeout(function () { a.remove(); }, 3200);
  }
  function testoFrase(root) {
    var q = root.querySelector('[data-fdg-testo]');
    var a = root.querySelector('[data-fdg-autore]');
    var o = root.querySelector('[data-fdg-opera]');
    var t = q ? q.innerText.replace(/\s*\n\s*/g, ' / ').trim() : '';
    return '«' + t + '» — ' + (a ? a.textContent : '') + (o && o.textContent ? ', ' + o.textContent : '');
  }
  function condividi(root) {
    var t = testoFrase(root);
    if (navigator.share) {
      navigator.share({ text: t }).catch(function () { /* annullato */ });
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(t).then(function () { avviso('Frase copiata'); });
    }
  }
  // la frase che si scrive da sola, lettera per lettera (le righe a capo restano)
  function scrivi(root, fine) {
    var p = root.querySelector('.fdg-q p');
    if (!p) { return; }
    var nodi = [];
    (function giro(n) {
      Array.prototype.forEach.call(n.childNodes, function (c) {
        if (c.nodeType === 3) { nodi.push([c, c.nodeValue]); c.nodeValue = ''; } else { giro(c); }
      });
    })(p);
    var tot = nodi.reduce(function (s, x) { return s + x[1].length; }, 0);
    var passo = Math.max(14, Math.min(38, 2400 / Math.max(1, tot)));
    var i = 0, j = 0;
    root.classList.add('scrive');
    (function batti() {
      if (!document.body.contains(p)) { return; }
      if (i >= nodi.length) { root.classList.remove('scrive'); if (fine) { fine(); } return; }
      var x = nodi[i];
      j++;
      x[0].nodeValue = x[1].slice(0, j);
      if (j >= x[1].length) { i++; j = 0; }
      setTimeout(batti, passo);
    })();
  }

  // ---- il messaggio all'apertura ----
  var box = document.querySelector('[data-fdg-popup]');
  if (box) {
    var modo = box.getAttribute('data-modo');
    var giorno = box.getAttribute('data-giorno') || '';
    var chiave = modo === 'apertura' ? 'fdg-aperta' : 'fdg-vista';
    var gia = modo !== 'prova' && ss(chiave) === giorno;
    if (!gia) {
      var timer = null;
      var prima = null;
      var chiudi = function () {
        if (box.hidden || box.classList.contains('chiude')) { return; }
        clearTimeout(timer);
        box.classList.add('chiude');
        setTimeout(function () { box.hidden = true; box.classList.remove('aperto', 'chiude', 'conto'); }, 300);
        if (prima && prima.focus) { try { prima.focus(); } catch (e) { /* niente */ } }
      };
      var apri = function () {
        prima = document.activeElement;
        if (modo !== 'prova') { ss(chiave, giorno); }
        box.hidden = false;
        void box.offsetWidth;
        box.classList.add('aperto');
        var x = box.querySelector('.fdg-x');
        if (x) { try { x.focus({ preventScroll: true }); } catch (e) { x.focus(); } }
        var sec = parseInt(box.getAttribute('data-chiudi'), 10) || 0;
        var conta = function () {
          if (sec > 0) {
            box.style.setProperty('--fdg-t', sec + 's');
            box.classList.add('conto');
            timer = setTimeout(chiudi, sec * 1000);
          }
        };
        var calmo = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (box.getAttribute('data-anim') === 'scrittura' && !calmo) { scrivi(box, conta); } else { conta(); }
        if (modo === 'giorno') { manda('vista', {}).catch(function () { /* riprova domani */ }); }
      };
      // un tocco dentro il riquadro ferma la chiusura automatica
      box.addEventListener('pointerdown', function (e) {
        if (e.target.closest('.fdg-box')) { clearTimeout(timer); box.classList.remove('conto'); }
      });
      $$('[data-fdg-chiudi]', box).forEach(function (b) { b.addEventListener('click', chiudi); });
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !box.hidden) { chiudi(); } });
      var basta = box.querySelector('[data-fdg-basta]');
      if (basta) {
        basta.addEventListener('click', function () {
          basta.disabled = true;
          manda('basta', {}).then(function () {
            chiudi();
            avviso('Va bene: non la vedrai più all\'apertura. Si riaccende da Il mio account.');
          }).catch(function () { basta.disabled = false; });
        });
      }
      var r = parseInt(box.getAttribute('data-ritardo'), 10) || 0;
      setTimeout(apri, Math.max(150, r * 1000));
    }
  }

  // ---- Condividi (nel messaggio e nella pagina) ----
  $$('[data-fdg-condividi]').forEach(function (b) {
    b.addEventListener('click', function () { condividi(b.closest('.fdg')); });
  });

  // ---- le scelte di ognuno (Il mio account, pagina Frase del giorno): si salvano da sole ----
  $$('[data-fdg-pref]').forEach(function (f) {
    var ok = f.querySelector('[data-fdg-salvato]');
    $$('input[type=checkbox]', f).forEach(function (c) {
      c.addEventListener('change', function () {
        var d = {};
        $$('input[name=popup],input[name=avviso]', f).forEach(function (x) {
          d[x.name] = x.type === 'checkbox' ? (x.checked ? '1' : '0') : x.value;
        });
        manda('pref', d).then(function (j) {
          if (j && j.salvato && ok) { ok.hidden = false; clearTimeout(ok._t); ok._t = setTimeout(function () { ok.hidden = true; }, 1800); }
        }).catch(function () { f.submit(); });
      });
    });
  });
})();
