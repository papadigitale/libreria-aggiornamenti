<?php
/*
 * Frase del giorno — motore: impostazioni, scelta della frase di oggi (Wikiquote, raccolta dei classici, frasi dell'Admin),
 * preferenze di ogni utente, avviso nella campanella, libro corrispondente nella Libreria, riquadro della frase.
 */

/* ---------------- Tabelle ---------------- */

function fdg_crea_tabelle($plugin)
{
    $pdo = db();
    $sqlite = DB_DRIVER === 'sqlite';
    $id = $sqlite ? 'id INTEGER PRIMARY KEY AUTOINCREMENT' : 'id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY';
    $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . $plugin->table('frasi') . ' (' . $id . ', testo TEXT NOT NULL, autore VARCHAR(150) NOT NULL,'
        . ' opera VARCHAR(200) NULL, libro VARCHAR(200) NULL, attiva TINYINT NOT NULL DEFAULT 1, created_at DATETIME NOT NULL)' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . $plugin->table('preferenze') . ' (user_id INT NOT NULL PRIMARY KEY, popup TINYINT NOT NULL DEFAULT 1,'
        . ' avviso TINYINT NOT NULL DEFAULT 1, visto DATE NULL)' . $tail);
}

/* ---------------- Impostazioni ---------------- */

function fdg_imp_predefinite()
{
    return array(
        'attivo' => 1,
        'fonte_web' => 1, 'web_solo_opere' => 1, 'fonte_raccolta' => 1, 'fonte_mie' => 1,
        'avviso' => 1, 'ora' => '08:00', 'testo_avviso' => 'La frase del giorno: «{inizio}» — {autore}',
        'popup' => 'giorno', 'dove' => 'tutte', 'ritardo' => 1,
        'link_libro' => 1, 'link_aggiungi' => 1, 'menu' => 1, 'condividi' => 1,
    );
}

function fdg_asp_predefinito()
{
    return array(
        'stile' => 'carta', 'sorpresa' => 0, 'sorpresa_stili' => array('carta', 'notte', 'acquerello', 'lavagna', 'salvia'),
        'forma' => 'scheda', 'carattere' => 'classico', 'dimensione' => 'm', 'ornamento' => 'virgolette', 'animazione' => 'sfoglia',
        'velo' => 1, 'chiusura' => 0, 'titolo' => 'La frase del giorno', 'data' => 1, 'angoli' => 'morbidi',
        'c_sfondo' => '#fbf6ea', 'c_testo' => '#2b2118', 'c_accento' => '#9a3b2f',
    );
}

function fdg_json_setting($plugin, $k, $def)
{
    $j = json_decode((string)$plugin->setting($k, ''), true);
    return is_array($j) ? array_merge($def, array_intersect_key($j, $def)) : $def;
}

function fdg_imp($plugin)
{
    static $c = array();
    if (!isset($c[$plugin->id]) || !empty($GLOBALS['FDG_RILEGGI'])) {
        $c[$plugin->id] = fdg_json_setting($plugin, 'imp', fdg_imp_predefinite());
    }
    return $c[$plugin->id];
}

function fdg_asp($plugin)
{
    $a = fdg_json_setting($plugin, 'aspetto', fdg_asp_predefinito());
    if (!is_array($a['sorpresa_stili'])) {
        $a['sorpresa_stili'] = fdg_asp_predefinito()['sorpresa_stili'];
    }
    return $a;
}

function fdg_salva_json($plugin, $k, $v)
{
    $plugin->save_setting($k, json_encode($v, JSON_UNESCAPED_UNICODE));
    $GLOBALS['FDG_RILEGGI'] = true;
}

// Scelte possibili dell'aspetto (chiave => etichetta)
function fdg_stili()
{
    return array(
        'carta' => 'Carta avorio', 'notte' => 'Notte e oro', 'acquerello' => 'Acquerello', 'lavagna' => 'Lavagna',
        'salvia' => 'Salvia', 'inchiostro' => 'Inchiostro', 'tema' => 'Colori del sito', 'mio' => 'I miei colori',
    );
}
function fdg_forme()
{
    return array('scheda' => 'Scheda al centro', 'striscia' => 'Striscia in basso', 'biglietto' => 'Biglietto in alto');
}
function fdg_caratteri()
{
    return array('classico' => 'Classico (Georgia)', 'elegante' => 'Elegante (Palatino)', 'moderno' => 'Moderno (senza grazie)',
        'macchina' => 'Macchina da scrivere', 'sito' => 'Come i titoli del sito');
}
function fdg_dimensioni()
{
    return array('s' => 'Piccola', 'm' => 'Media', 'l' => 'Grande');
}
function fdg_ornamenti()
{
    return array('virgolette' => 'Virgolette grandi', 'capolettera' => 'Capolettera', 'fregio' => 'Fregio ❦', 'nessuno' => 'Nessuno');
}
function fdg_animazioni()
{
    return array('sfoglia' => 'Pagina che si apre', 'dissolvenza' => 'Dissolvenza', 'scivola' => 'Scivola dal basso', 'scrittura' => 'Si scrive da sola', 'nessuna' => 'Nessuna');
}
function fdg_angoli()
{
    return array('morbidi' => 'Morbidi', 'tondi' => 'Molto tondi', 'vivi' => 'Vivi');
}
function fdg_chiusure()
{
    return array(0 => 'Solo con un tocco', 8 => 'Dopo 8 secondi', 15 => 'Dopo 15 secondi', 30 => 'Dopo 30 secondi');
}

function fdg_colore($c, $def)
{
    return preg_match('/^#[0-9a-fA-F]{6}$/', (string)$c) ? strtolower($c) : $def;
}

/* ---------------- Preferenze di ogni utente ---------------- */

function fdg_pref($plugin, $uid)
{
    static $c = array();
    if (!empty($GLOBALS['FDG_PREF_NUOVE'])) {
        $c = array();
        $GLOBALS['FDG_PREF_NUOVE'] = false;
    }
    if (!isset($c[(int)$uid])) {
        $r = false;
        try {
            $st = db()->prepare('SELECT popup, avviso, visto FROM ' . $plugin->table('preferenze') . ' WHERE user_id = ?');
            $st->execute(array((int)$uid));
            $r = $st->fetch();
            $st->closeCursor();
        } catch (Exception $e) {
            $r = false;
        }
        $c[(int)$uid] = $r ? array('popup' => (int)$r['popup'], 'avviso' => (int)$r['avviso'], 'visto' => (string)$r['visto'])
            : array('popup' => 1, 'avviso' => 1, 'visto' => '');
    }
    return $c[(int)$uid];
}

function fdg_pref_salva($plugin, $uid, $campi)
{
    $p = array_merge(fdg_pref($plugin, $uid), $campi);
    $T = $plugin->table('preferenze');
    $st = db()->prepare('SELECT COUNT(*) FROM ' . $T . ' WHERE user_id = ?');
    $st->execute(array((int)$uid));
    $c = (int)$st->fetchColumn();
    $st->closeCursor();
    $visto = $p['visto'] !== '' ? $p['visto'] : null;
    if ($c) {
        db()->prepare('UPDATE ' . $T . ' SET popup = ?, avviso = ?, visto = ? WHERE user_id = ?')->execute(array((int)$p['popup'], (int)$p['avviso'], $visto, (int)$uid));
    } else {
        db()->prepare('INSERT INTO ' . $T . ' (user_id, popup, avviso, visto) VALUES (?,?,?,?)')->execute(array((int)$uid, (int)$p['popup'], (int)$p['avviso'], $visto));
    }
    $GLOBALS['FDG_PREF_NUOVE'] = true;
}

// Quanti hanno spento il messaggio e quanti l'avviso
function fdg_spenti($plugin)
{
    try {
        $r = db()->query('SELECT SUM(CASE WHEN popup = 0 THEN 1 ELSE 0 END) AS p, SUM(CASE WHEN avviso = 0 THEN 1 ELSE 0 END) AS a FROM ' . $plugin->table('preferenze'))->fetch();
        return array((int)$r['p'], (int)$r['a']);
    } catch (Exception $e) {
        return array(0, 0);
    }
}

/* ---------------- Le frasi ---------------- */

// Raccolta dei classici (frasi.txt): id "r<n>" => frase
function fdg_raccolta()
{
    static $l = null;
    if ($l !== null) {
        return $l;
    }
    $l = array();
    $righe = @file(__DIR__ . '/frasi.txt', FILE_IGNORE_NEW_LINES);
    $n = 0;
    foreach ((array)$righe as $r) {
        $r = trim($r);
        if ($r === '' || $r[0] === '#') {
            continue;
        }
        $p = array_map('trim', explode(' | ', $r));
        if (count($p) < 3) {
            continue;
        }
        $n++;
        $l['r' . $n] = array('t' => str_replace(' / ', "\n", $p[0]), 'a' => $p[1], 'o' => $p[2], 'l' => isset($p[3]) && $p[3] !== '' ? $p[3] : $p[2], 'fonte' => 'raccolta', 'id' => 'r' . $n);
    }
    return $l;
}

// Frasi aggiunte dall'Admin: id "m<n>" => frase
function fdg_mie($plugin, $solo_attive = true)
{
    $l = array();
    try {
        $st = db()->query('SELECT * FROM ' . $plugin->table('frasi') . ($solo_attive ? ' WHERE attiva = 1' : '') . ' ORDER BY id DESC');
        foreach ($st->fetchAll() as $r) {
            $l['m' . $r['id']] = array('t' => (string)$r['testo'], 'a' => (string)$r['autore'], 'o' => (string)$r['opera'],
                'l' => (string)$r['libro'] !== '' ? (string)$r['libro'] : (string)$r['opera'], 'fonte' => 'mie', 'id' => 'm' . $r['id'], 'attiva' => (int)$r['attiva']);
        }
    } catch (Exception $e) {
        // tabella non ancora pronta
    }
    return $l;
}

function fdg_esclusi($plugin)
{
    $j = json_decode((string)$plugin->setting('esclusi', '[]'), true);
    return is_array($j) ? $j : array();
}

function fdg_frase_per_id($plugin, $id)
{
    $r = fdg_raccolta();
    if (isset($r[$id])) {
        return $r[$id];
    }
    $m = fdg_mie($plugin, false);
    return isset($m[$id]) ? $m[$id] : null;
}

// La frase di oggi (la stessa per tutti): scelta una volta al giorno e tenuta nelle impostazioni
function fdg_oggi($plugin)
{
    $oggi = date('Y-m-d');
    $o = json_decode((string)$plugin->setting('oggi', ''), true);
    if (is_array($o) && isset($o['d'], $o['t']) && $o['d'] === $oggi) {
        return $o;
    }
    $f = fdg_scegli($plugin);
    if (!$f) {
        return null;
    }
    fdg_imposta_oggi($plugin, $f);
    return json_decode((string)$plugin->setting('oggi', ''), true);
}

function fdg_imposta_oggi($plugin, $f)
{
    $oggi = date('Y-m-d');
    $asp = fdg_asp($plugin);
    $prima = json_decode((string)$plugin->setting('oggi', ''), true);
    $stile = '';
    if (!empty($asp['sorpresa'])) {
        $pool = array_values(array_intersect($asp['sorpresa_stili'], array_keys(fdg_stili())));
        if (count($pool) > 1 && is_array($prima) && !empty($prima['stile'])) {
            $pool = array_values(array_diff($pool, array($prima['stile'])));
        }
        $stile = $pool ? $pool[mt_rand(0, count($pool) - 1)] : '';
    }
    $o = array('d' => $oggi, 't' => $f['t'], 'a' => $f['a'], 'o' => $f['o'], 'l' => isset($f['l']) ? $f['l'] : $f['o'],
        'fonte' => $f['fonte'], 'id' => isset($f['id']) ? $f['id'] : '', 'url' => isset($f['url']) ? $f['url'] : '', 'stile' => $stile);
    $plugin->save_setting('oggi', json_encode($o, JSON_UNESCAPED_UNICODE));
    // le ultime frasi (per non ripeterle e per la pagina «Frase del giorno»)
    $st = json_decode((string)$plugin->setting('storico', '[]'), true);
    $st = is_array($st) ? $st : array();
    $st = array_values(array_filter($st, function ($x) use ($oggi) {
        return isset($x['d']) && $x['d'] !== $oggi;
    }));
    array_unshift($st, array('d' => $oggi, 't' => $o['t'], 'a' => $o['a'], 'o' => $o['o'], 'fonte' => $o['fonte']));
    $plugin->save_setting('storico', json_encode(array_slice($st, 0, 14), JSON_UNESCAPED_UNICODE));
    if ($o['id'] !== '') {
        $u = json_decode((string)$plugin->setting('usate', '[]'), true);
        $u = is_array($u) ? array_values(array_diff($u, array($o['id']))) : array();
        array_unshift($u, $o['id']);
        $plugin->save_setting('usate', json_encode(array_slice($u, 0, 160)));
    }
}

// Sceglie a caso tra le fonti accese (la probabilita' segue quante frasi ha ogni fonte)
function fdg_scegli($plugin, $senza_web = false)
{
    $imp = fdg_imp($plugin);
    $locali = array();
    if (!empty($imp['fonte_raccolta'])) {
        $locali = array_diff_key(fdg_raccolta(), array_flip(fdg_esclusi($plugin)));
    }
    if (!empty($imp['fonte_mie'])) {
        $locali = $locali + fdg_mie($plugin);
    }
    // non ripetere quelle uscite di recente (finche' ne restano abbastanza)
    $u = json_decode((string)$plugin->setting('usate', '[]'), true);
    if (is_array($u) && $u && count($locali) > 3) {
        $quante = min(count($u), max(0, (int)floor(count($locali) * 0.7)));
        $fresche = array_diff_key($locali, array_flip(array_slice($u, 0, $quante)));
        if ($fresche) {
            $locali = $fresche;
        }
    }
    $web = !$senza_web && !empty($imp['fonte_web']);
    $peso_web = $web ? 365 : 0;
    $tot = $peso_web + count($locali);
    if ($tot <= 0) {
        return null;
    }
    if ($peso_web && mt_rand(1, $tot) <= $peso_web) {
        $w = fdg_wikiquote($plugin);
        if ($w[0]) {
            return $w[1];
        }
        $plugin->save_setting('ultimo_errore_web', date('Y-m-d H:i') . ' — ' . $w[1]);
    }
    if (!$locali) {
        return null;
    }
    $k = array_keys($locali);
    return $locali[$k[mt_rand(0, count($k) - 1)]];
}

/* ---------------- Wikiquote (citazione del giorno) ---------------- */

function fdg_mesi()
{
    return array(1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre');
}

function fdg_wq_pagina($ts = null)
{
    $ts = $ts === null ? time() : $ts;
    return 'Template:Qotd/' . (int)date('j', $ts) . fdg_mesi()[(int)date('n', $ts)];
}

// array(true, frase) oppure array(false, motivo)
function fdg_wikiquote($plugin, $ts = null)
{
    if (!is_file(APP_ROOT . '/inc/http.php')) {
        return array(false, 'Funzione per le richieste web non disponibile');
    }
    require_once APP_ROOT . '/inc/http.php';
    $pag = fdg_wq_pagina($ts);
    $url = 'https://it.wikiquote.org/w/api.php?action=query&prop=revisions&rvprop=content&rvslots=main&format=json&formatversion=2&titles=' . rawurlencode($pag);
    $j = http_get_json($url, 8);
    if (!$j) {
        return array(false, 'Wikiquote non risponde');
    }
    $testo = isset($j['query']['pages'][0]['revisions'][0]['slots']['main']['content']) ? (string)$j['query']['pages'][0]['revisions'][0]['slots']['main']['content']
        : (isset($j['query']['pages'][0]['revisions'][0]['content']) ? (string)$j['query']['pages'][0]['revisions'][0]['content'] : '');
    if ($testo === '') {
        return array(false, 'Nessuna citazione per oggi su Wikiquote (' . $pag . ')');
    }
    $f = fdg_wq_leggi($testo);
    if (!$f) {
        return array(false, 'Citazione di Wikiquote in un formato non riconosciuto');
    }
    if (!empty(fdg_imp($plugin)['web_solo_opere']) && $f['o'] === '') {
        return array(false, 'La citazione di oggi su Wikiquote non indica un libro (' . $f['a'] . ')');
    }
    $f['fonte'] = 'web';
    $f['id'] = '';
    $f['l'] = $f['o'];
    $f['url'] = 'https://it.wikiquote.org/wiki/' . rawurlencode(str_replace(' ', '_', $f['a']));
    return array(true, $f);
}

// Legge il modello {{Cdg|capolettera|citazione|...|autore|opera}} (anche con i nomi: citazione=, autore=, opera=)
function fdg_wq_leggi($wiki)
{
    $p = stripos($wiki, '{{cdg');
    if ($p === false) {
        return null;
    }
    // fino alle graffe che chiudono il modello
    $liv = 0;
    $fine = -1;
    $n = strlen($wiki);
    for ($i = $p; $i < $n - 1; $i++) {
        $d = substr($wiki, $i, 2);
        if ($d === '{{') {
            $liv++;
            $i++;
        } elseif ($d === '}}') {
            $liv--;
            $i++;
            if ($liv === 0) {
                $fine = $i - 1;
                break;
            }
        }
    }
    if ($fine < 0) {
        return null;
    }
    $corpo = substr($wiki, $p + 2, $fine - $p - 2);
    // parametri separati da | fuori da [[ ]] e {{ }}
    $parti = array();
    $cur = '';
    $q = 0;
    $l = strlen($corpo);
    for ($i = 0; $i < $l; $i++) {
        $d = substr($corpo, $i, 2);
        if ($d === '[[' || $d === '{{') {
            $q++;
            $cur .= $d;
            $i++;
            continue;
        }
        if (($d === ']]' || $d === '}}') && $q > 0) {
            $q--;
            $cur .= $d;
            $i++;
            continue;
        }
        if ($corpo[$i] === '|' && $q === 0) {
            $parti[] = $cur;
            $cur = '';
            continue;
        }
        $cur .= $corpo[$i];
    }
    $parti[] = $cur;
    array_shift($parti); // nome del modello
    $pos = array();
    $nom = array();
    foreach ($parti as $x) {
        if (preg_match('/^\s*([a-z]+)\s*=(.*)$/s', $x, $m)) {
            $nom[strtolower($m[1])] = $m[2];
        } else {
            $pos[count($pos) + 1] = $x;
        }
    }
    $g = function ($nome, $num) use ($nom, $pos) {
        return isset($nom[$nome]) ? $nom[$nome] : (isset($pos[$num]) ? $pos[$num] : '');
    };
    $testo = fdg_wq_pulisci($g('capolettera', 1) . $g('citazione', 2), true);
    $autore = fdg_wq_pulisci($g('autore', 4));
    $opera = fdg_wq_pulisci($g('opera', 5));
    if ($testo === '' || $autore === '') {
        return null;
    }
    $testo = trim($testo, " \t\n«»\"“”");
    return array('t' => str_cut($testo, 600), 'a' => str_cut($autore, 150), 'o' => str_cut($opera, 200));
}

function fdg_wq_pulisci($s, $versi = false)
{
    $s = preg_replace('#<ref[^>]*/>|<ref[^>]*>.*?</ref>#is', '', (string)$s);
    $s = preg_replace('#<!--.*?-->#s', '', $s);
    $s = preg_replace('#<br\s*/?>#i', $versi ? "\n" : ' ', $s);
    for ($i = 0; $i < 4; $i++) {
        $s = preg_replace('/\{\{[^{}]*\}\}/', '', $s);
    }
    $s = preg_replace('/\[\[(?:File|Immagine|Image):[^\]]*\]\]/i', '', $s);
    $s = preg_replace('/\[\[[^\]|]*\|([^\]]*)\]\]/', '$1', $s);
    $s = preg_replace('/\[\[([^\]]*)\]\]/', '$1', $s);
    $s = preg_replace('/\[https?:[^\s\]]+\s+([^\]]*)\]/', '$1', $s);
    $s = str_replace(array("'''", "''"), '', $s);
    $s = html_entity_decode(strip_tags($s), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $s = preg_replace('/[ \t\x{00A0}]+/u', ' ', $s);
    $s = preg_replace('/ *\n */', "\n", $s);
    return trim($s);
}

/* ---------------- Il libro nella Libreria ---------------- */

function fdg_norm($s)
{
    $s = mb_strtolower((string)$s, 'UTF-8');
    $s = strtr($s, array('à' => 'a', 'á' => 'a', 'â' => 'a', 'ä' => 'a', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i',
        'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'ö' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'ç' => 'c', 'ñ' => 'n', '’' => "'"));
    $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
    $s = ' ' . trim($s) . ' ';
    $s = preg_replace('/^ (il|lo|la|i|gli|le|l|un|uno|una|the|a|an|el|les|der|die|das) /', ' ', $s);
    return trim(preg_replace('/ +/', ' ', $s));
}

// array(id, titolo) del libro della frase, se c'e' nella Libreria
function fdg_libro($f)
{
    $chiave = isset($f['l']) && $f['l'] !== '' ? $f['l'] : (isset($f['o']) ? $f['o'] : '');
    $chiave = preg_replace('/\s*\(.*\)$/', '', $chiave);
    $nk = fdg_norm($chiave);
    if (strlen($nk) < 3) {
        return null;
    }
    $parole = explode(' ', $nk);
    usort($parole, function ($a, $b) {
        return strlen($b) - strlen($a);
    });
    $cognome = '';
    $na = fdg_norm(isset($f['a']) ? $f['a'] : '');
    if ($na !== '') {
        $pa = explode(' ', $na);
        $cognome = end($pa);
    }
    try {
        $st = db()->prepare('SELECT id, title, authors FROM books WHERE title LIKE ? LIMIT 60');
        $st->execute(array('%' . $parole[0] . '%'));
        $righe = $st->fetchAll();
        $st->closeCursor();
    } catch (Exception $e) {
        return null;
    }
    $meglio = null;
    foreach ($righe as $r) {
        $nt = fdg_norm($r['title']);
        if ($nt === '') {
            continue;
        }
        $ok = $nt === $nk || strpos(' ' . $nt . ' ', ' ' . $nk . ' ') !== false || (strlen($nt) >= 6 && strpos(' ' . $nk . ' ', ' ' . $nt . ' ') !== false);
        if (!$ok) {
            continue;
        }
        $nau = fdg_norm($r['authors']);
        if ($nau !== '' && $cognome !== '' && strpos(' ' . $nau . ' ', ' ' . $cognome . ' ') === false
            && strpos(' ' . $nau . ' ', ' ' . explode(' ', $na)[0] . ' ') === false) {
            continue;
        }
        if (!$meglio || strlen($r['title']) < strlen($meglio[1])) {
            $meglio = array((int)$r['id'], (string)$r['title']);
        }
    }
    return $meglio;
}

/* ---------------- Avviso nella campanella ---------------- */

function fdg_inizio($t, $max = 70)
{
    $t = preg_replace('/\s+/', ' ', str_replace("\n", ' / ', (string)$t));
    if (mb_strlen($t, 'UTF-8') <= $max) {
        return $t;
    }
    $c = mb_substr($t, 0, $max, 'UTF-8');
    $sp = mb_strrpos($c, ' ', 0, 'UTF-8');
    return rtrim($sp > $max * 0.6 ? mb_substr($c, 0, $sp, 'UTF-8') : $c, ' ,;:.') . '…';
}

function fdg_testo_avviso($plugin, $f)
{
    $t = (string)fdg_imp($plugin)['testo_avviso'];
    $t = $t !== '' ? $t : fdg_imp_predefinite()['testo_avviso'];
    return str_replace(array('{inizio}', '{autore}', '{opera}'), array(fdg_inizio($f['t']), $f['a'], $f['o']), $t);
}

// Chiamata dai lavori periodici: all'ora scelta (o alla prima occasione dopo), una volta al giorno
function fdg_avviso($plugin, $forza = false)
{
    $imp = fdg_imp($plugin);
    $oggi = date('Y-m-d');
    if (!$forza && (empty($imp['attivo']) || empty($imp['avviso']) || $plugin->setting('avviso_del', '') === $oggi || date('H:i') < (string)$imp['ora'])) {
        return 0;
    }
    $plugin->save_setting('avviso_del', $oggi);
    $f = fdg_oggi($plugin);
    if (!$f) {
        return 0;
    }
    $st = db()->query('SELECT id FROM users WHERE active = 1');
    $tutti = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    $st->closeCursor();
    $no = array();
    try {
        $no = array_map('intval', db()->query('SELECT user_id FROM ' . $plugin->table('preferenze') . ' WHERE avviso = 0')->fetchAll(PDO::FETCH_COLUMN));
    } catch (Exception $e) {
        $no = array();
    }
    $a = array_values(array_diff($tutti, $no));
    if (!$a) {
        return 0;
    }
    $n = $plugin->notifica(fdg_testo_avviso($plugin, $f), $plugin->site_url('oggi'), array('to' => $a, 'gruppo' => 'frase-' . $oggi, 'sostituisci' => true));
    $plugin->save_setting('avviso_ora', date('Y-m-d H:i'));
    return $n;
}

/* ---------------- Il riquadro della frase ---------------- */

function fdg_data_lunga($d)
{
    $t = strtotime($d);
    return $t ? (int)date('j', $t) . ' ' . fdg_mesi()[(int)date('n', $t)] : '';
}

/*
 * HTML del riquadro. $ctx: 'popup' (sul sito), 'anteprima' (pannello), 'pagina' (pagina Frase del giorno)
 * $extra: libro (array id,titolo o null), puo_aggiungere, condividi, basta (pulsante «Non mostrarla più»)
 */
function fdg_box_html($plugin, $f, $asp, $ctx, $extra = array())
{
    $stile = !empty($f['stile']) && $ctx !== 'anteprima' ? $f['stile'] : $asp['stile'];
    $stile = isset(fdg_stili()[$stile]) ? $stile : 'carta';
    $vars = '';
    if ($stile === 'mio') {
        $vars = ' style="--fdg-bg:' . h(fdg_colore($asp['c_sfondo'], '#fbf6ea')) . ';--fdg-ink:' . h(fdg_colore($asp['c_testo'], '#2b2118'))
            . ';--fdg-acc:' . h(fdg_colore($asp['c_accento'], '#9a3b2f')) . '"';
    }
    $att = ' data-stile="' . h($stile) . '" data-forma="' . h($asp['forma']) . '" data-car="' . h($asp['carattere']) . '" data-dim="' . h($asp['dimensione'])
        . '" data-orn="' . h($asp['ornamento']) . '" data-anim="' . h($asp['animazione']) . '" data-angoli="' . h($asp['angoli']) . '"'
        . ' data-velo="' . (!empty($asp['velo']) ? '1' : '0') . '" data-chiudi="' . (int)$asp['chiusura'] . '"';
    $testo = (string)$f['t'];
    $righe = explode("\n", $testo);
    $q = '';
    foreach ($righe as $i => $r) {
        $q .= ($i ? '<br>' : '') . h($r);
    }
    // capolettera: la prima lettera in un elemento a parte
    {
        if (preg_match('/^(\W*)(\w)/u', $righe[0], $m)) {
            $q = h($m[1]) . '<span class="fdg-cap">' . h($m[2]) . '</span>' . substr($q, strlen(h($m[1] . $m[2])));
        }
    }
    $titolo = (string)$asp['titolo'] !== '' ? $asp['titolo'] : 'La frase del giorno';
    $h = '<div class="fdg fdg-' . h($ctx) . '"' . $att . $vars . ($ctx === 'popup' ? ' hidden role="dialog" aria-modal="true" aria-labelledby="fdg-tit"' : '') . '>';
    if ($ctx !== 'pagina') {
        $h .= '<div class="fdg-velo" data-fdg-chiudi></div>';
    }
    $h .= '<div class="fdg-box"><span class="fdg-carta" aria-hidden="true"></span>';
    if ($ctx !== 'pagina') {
        $h .= '<button class="fdg-x" type="button" data-fdg-chiudi aria-label="Chiudi">' . icon('x', 18) . '</button>';
    }
    $h .= '<p class="fdg-l" id="fdg-tit"><span data-fdg-titolo>' . h($titolo) . '</span><time data-fdg-data' . (empty($asp['data']) ? ' hidden' : '') . ' datetime="' . h($f['d']) . '">' . h(fdg_data_lunga($f['d'])) . '</time></p>';
    $h .= '<span class="fdg-orn" aria-hidden="true">❦</span>';
    $h .= '<svg class="fdg-virg" viewBox="0 0 52 34" aria-hidden="true"><path d="M21 3C11.5 5 4 12.5 4 22.5a8 8 0 1 0 8-8c-.7 0-1.4.1-2 .3C11.3 10.6 15.3 7.6 22 6zM47 3c-9.5 2-17 9.5-17 19.5a8 8 0 1 0 8-8c-.7 0-1.4.1-2 .3C37.3 10.6 41.3 7.6 48 6z"/></svg>';
    $h .= '<blockquote class="fdg-q" data-fdg-testo><p>' . $q . '</p></blockquote>';
    $h .= '<p class="fdg-a">— <b data-fdg-autore>' . h($f['a']) . '</b>' . ((string)$f['o'] !== '' ? ', <i data-fdg-opera>' . h($f['o']) . '</i>' : '<i data-fdg-opera></i>') . '</p>';
    $az = '';
    $libro = isset($extra['libro']) ? $extra['libro'] : null;
    if ($libro) {
        $az .= '<a class="fdg-btn fdg-lib" href="libro.php?id=' . (int)$libro[0] . '">' . icon('books', 16) . '<span>Ce l\'hai in libreria</span>' . icon('chev', 14) . '</a>';
    } elseif (!empty($extra['puo_aggiungere'])) {
        $cerca = preg_replace('/\s*\(.*\)$/', '', (string)$f['l']) . ' ' . $f['a'];
        $az .= '<a class="fdg-btn fdg-lib" href="aggiungi.php?titolo=' . h(rawurlencode(trim($cerca))) . '">' . icon('plus', 16) . '<span>Aggiungilo alla libreria</span></a>';
    }
    if (!empty($extra['condividi'])) {
        $az .= '<button class="fdg-btn" type="button" data-fdg-condividi>' . fdg_icona_condividi() . '<span>Condividi</span></button>';
    }
    if ($az !== '') {
        $h .= '<div class="fdg-az">' . $az . '</div>';
    }
    if ($f['fonte'] === 'web') {
        $h .= '<p class="fdg-fonte">Da <a href="' . h($f['url'] !== '' ? $f['url'] : 'https://it.wikiquote.org/') . '" target="_blank" rel="noopener">Wikiquote</a> · testo con licenza CC BY-SA</p>';
    }
    if (!empty($extra['basta'])) {
        $h .= '<p class="fdg-piede"><button type="button" class="fdg-basta" data-fdg-basta>Non mostrarmela più all\'apertura</button></p>';
    }
    $h .= '<span class="fdg-tempo" aria-hidden="true"></span></div></div>';
    return $h;
}

function fdg_icona_condividi()
{
    return '<svg class="i fdg-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V3.5M7.5 8 12 3.5 16.5 8M8 11.5H6.5A1.5 1.5 0 0 0 5 13v6.5A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5V13a1.5 1.5 0 0 0-1.5-1.5H16"/></svg>';
}
