<?php
/*
 * Frase del giorno — pannello (Gestione → Plugin → Frase del giorno): Oggi · Aspetto · Frasi · Impostazioni
 */

function fdg_url($plugin, $tab, $extra = array())
{
    return $plugin->admin_url('frase', array_merge(array('tab' => $tab), $extra));
}

function fdg_sel($name, $opzioni, $val, $attr = '')
{
    $h = '<select class="input" name="' . h($name) . '"' . ($attr !== '' ? ' ' . $attr : '') . '>';
    foreach ($opzioni as $k => $t) {
        $h .= '<option value="' . h($k) . '"' . ((string)$k === (string)$val ? ' selected' : '') . '>' . h($t) . '</option>';
    }
    return $h . '</select>';
}

function fdg_chk($name, $val, $testo, $attr = '')
{
    return '<label class="check switch"><input type="checkbox" name="' . h($name) . '" value="1"' . (!empty($val) ? ' checked' : '') . ($attr !== '' ? ' ' . $attr : '') . '><span>' . $testo . '</span></label>';
}

function fdg_op($plugin, $op, $tab, $campi = array())
{
    $h = '<input type="hidden" name="op" value="' . h($op) . '"><input type="hidden" name="back" value="' . h(fdg_url($plugin, $tab)) . '">';
    foreach ($campi as $k => $v) {
        $h .= '<input type="hidden" name="' . h($k) . '" value="' . h($v) . '">';
    }
    return $h;
}

function fdg_fonte_nome($f)
{
    $n = array('web' => 'Wikiquote (citazione del giorno)', 'raccolta' => 'Raccolta dei classici', 'mie' => 'Le tue frasi');
    return isset($n[$f]) ? $n[$f] : $f;
}

function fdg_pannello($plugin)
{
    $schede = array('oggi' => 'Oggi', 'aspetto' => 'Aspetto', 'frasi' => 'Frasi', 'impostazioni' => 'Impostazioni');
    $tab = isset($schede[(string)get('tab')]) ? (string)get('tab') : 'oggi';
    echo '<div class="fdg-pan">';
    echo '<nav class="fdg-tabs" aria-label="Schede">';
    foreach ($schede as $k => $t) {
        echo '<a href="' . h(fdg_url($plugin, $k)) . '"' . ($k === $tab ? ' class="on" aria-current="page"' : '') . '>' . h($t) . '</a>';
    }
    echo '</nav>';
    if (empty(fdg_imp($plugin)['attivo'])) {
        echo '<div class="alert warn">La frase del giorno è <b>spenta</b>: nessuno vede il messaggio e non parte l\'avviso. Si accende in Impostazioni.</div>';
    }
    if ($tab === 'aspetto') {
        fdg_scheda_aspetto($plugin);
    } elseif ($tab === 'frasi') {
        fdg_scheda_frasi($plugin);
    } elseif ($tab === 'impostazioni') {
        fdg_scheda_impostazioni($plugin);
    } else {
        fdg_scheda_oggi($plugin);
    }
    echo '</div>';
}

/* ================= Oggi ================= */

function fdg_scheda_oggi($plugin)
{
    $imp = fdg_imp($plugin);
    $asp = fdg_asp($plugin);
    $f = fdg_oggi($plugin);
    echo '<div class="card"><div class="ct">' . fdg_icona(18) . ' Oggi, ' . h(fdg_data_lunga(date('Y-m-d'))) . '</div>';
    if (!$f) {
        echo '<p class="sub">Nessuna frase: tutte le fonti sono spente o vuote (scheda Impostazioni).</p></div>';
        return;
    }
    $libro = fdg_libro($f);
    echo '<div class="fdg-mostra">' . fdg_box_html($plugin, $f, $asp, 'pagina', array('libro' => !empty($imp['link_libro']) ? $libro : null,
        'puo_aggiungere' => !empty($imp['link_aggiungi']), 'condividi' => !empty($imp['condividi']))) . '</div>';
    echo '<p class="sub fdg-info">Fonte: <b>' . h(fdg_fonte_nome($f['fonte'])) . '</b>'
        . (!empty($f['stile']) ? ' · stile a sorpresa: <b>' . h(fdg_stili()[$f['stile']] ?? $f['stile']) . '</b>' : '')
        . ' · ' . ($libro ? 'il libro c\'è nella Libreria: <a href="libro.php?id=' . (int)$libro[0] . '" target="_blank">' . h($libro[1]) . '</a>' : 'il libro non c\'è nella Libreria') . '</p>';
    echo '<div class="fdg-riga">' . $plugin->form_start('class="fdg-inline"') . fdg_op($plugin, 'cambia', 'oggi')
        . '<button class="btn small" type="submit">' . admin_icon('shuffle', 16) . ' Cambia la frase di oggi</button></form>'
        . '<a class="btn ghost small" href="libreria.php?fdg=prova" target="_blank" rel="noopener">' . admin_icon('eye', 16) . ' Prova il messaggio sul sito</a></div>';
    echo '<p class="hint">«Prova il messaggio» lo mostra solo a te, anche se l\'hai già visto oggi.</p></div>';

    // avviso
    list($sp, $sa) = fdg_spenti($plugin);
    echo '<div class="card"><div class="ct">' . admin_icon('bell', 18) . ' Avviso nella campanella</div>';
    if (empty($imp['avviso'])) {
        echo '<p class="sub">Spento (scheda Impostazioni).</p>';
    } elseif ($plugin->setting('avviso_del', '') === date('Y-m-d')) {
        $ora = substr((string)$plugin->setting('avviso_ora', ''), 11, 5);
        echo '<p class="sub">Mandato oggi' . ($ora !== '' ? ' alle <b>' . h($ora) . '</b>' : '') . '. Il prossimo domani alle ' . h($imp['ora']) . '.</p>';
    } else {
        echo '<p class="sub">Partirà oggi alle <b>' . h($imp['ora']) . '</b> (o alla prima visita al sito dopo quell\'ora).</p>';
    }
    echo '<p class="sub fdg-anteprima-avviso">' . admin_icon('bell', 15) . ' <span>' . h(fdg_testo_avviso($plugin, $f)) . '</span></p>';
    echo '<p class="hint">Hanno spento il messaggio all\'apertura: <b>' . $sp . '</b> · hanno spento l\'avviso: <b>' . $sa . '</b>.</p>';
    echo $plugin->form_start('class="fdg-inline" data-confirm="Mando adesso l\'avviso con la frase di oggi a tutti quelli che non l\'hanno spento?"') . fdg_op($plugin, 'avviso_ora', 'oggi')
        . '<button class="btn ghost small" type="submit">Manda l\'avviso adesso</button></form></div>';

    // Wikiquote
    if (!empty($imp['fonte_web'])) {
        $err = (string)$plugin->setting('ultimo_errore_web', '');
        echo '<div class="card"><div class="ct">' . admin_icon('cloud', 18) . ' Wikiquote</div>'
            . '<p class="sub">Il sito chiede a Wikiquote solo la citazione del giorno e la tiene fino a mezzanotte: nessun archivio sul server. Quando Wikiquote non risponde'
            . (!empty($imp['web_solo_opere']) ? ' o la citazione non viene da un libro' : '') . ', la frase arriva dalla raccolta.</p>'
            . ($err !== '' ? '<p class="hint">Ultima volta che non è servita: ' . h($err) . '</p>' : '')
            . $plugin->form_start('class="fdg-inline"') . fdg_op($plugin, 'prova_web', 'oggi')
            . '<button class="btn ghost small" type="submit">Prova adesso il collegamento</button></form></div>';
    }

    $st = json_decode((string)$plugin->setting('storico', '[]'), true);
    $st = is_array($st) ? array_slice($st, 1, 7) : array();
    if ($st) {
        echo '<div class="card"><div class="ct">' . admin_icon('list', 18) . ' I giorni scorsi</div><table class="tbl fdg-tbl"><tbody>';
        foreach ($st as $x) {
            echo '<tr><td class="fdg-d">' . h(fdg_data_lunga($x['d'])) . '</td><td>' . h(fdg_inizio($x['t'], 90)) . '<br><small class="muted">' . h($x['a'])
                . ($x['o'] !== '' ? ', ' . h($x['o']) : '') . ' · ' . h(fdg_fonte_nome($x['fonte'])) . '</small></td></tr>';
        }
        echo '</tbody></table></div>';
    }
}

/* ================= Aspetto (con anteprima) ================= */

function fdg_campioni($plugin)
{
    $l = array();
    $o = fdg_oggi($plugin);
    if ($o) {
        $l[] = array('t' => $o['t'], 'a' => $o['a'], 'o' => $o['o']);
    }
    $r = array_values(fdg_raccolta());
    mt_srand(crc32(date('Y-m-d')));
    shuffle($r);
    mt_srand();
    foreach ($r as $x) {
        if (mb_strlen($x['t'], 'UTF-8') <= 220) {
            $l[] = array('t' => $x['t'], 'a' => $x['a'], 'o' => $x['o']);
        }
        if (count($l) >= 10) {
            break;
        }
    }
    return $l;
}

function fdg_scheda_aspetto($plugin)
{
    $a = fdg_asp($plugin);
    $f = fdg_oggi($plugin);
    if (!$f) {
        $r = fdg_raccolta();
        $f = reset($r);
        $f['d'] = date('Y-m-d');
    }
    $f['stile'] = '';
    echo '<div class="fdg-asp">';
    // modulo
    echo '<div class="card fdg-asp-f">' . $plugin->form_start('class="stack" data-fdg-modulo') . fdg_op($plugin, 'asp_salva', 'aspetto');
    echo '<div class="ct">' . admin_icon('brush', 18) . ' Stile</div><div class="fdg-stili">';
    foreach (fdg_stili() as $k => $t) {
        echo '<label class="fdg-st"><input type="radio" name="stile" value="' . h($k) . '"' . ($a['stile'] === $k ? ' checked' : '') . '>'
            . '<span class="fdg-st-c" data-stile="' . h($k) . '"><i>Aa</i><b></b></span><small>' . h($t) . '</small></label>';
    }
    echo '</div>';
    echo '<div class="fdg-colori" data-fdg-per="mio"' . ($a['stile'] !== 'mio' ? ' hidden' : '') . '>'
        . '<label><input type="color" name="c_sfondo" value="' . h(fdg_colore($a['c_sfondo'], '#fbf6ea')) . '"> Sfondo</label>'
        . '<label><input type="color" name="c_testo" value="' . h(fdg_colore($a['c_testo'], '#2b2118')) . '"> Testo</label>'
        . '<label><input type="color" name="c_accento" value="' . h(fdg_colore($a['c_accento'], '#9a3b2f')) . '"> Accento</label></div>';
    echo fdg_chk('sorpresa', $a['sorpresa'], '<b>Stile a sorpresa</b>: ogni giorno uno stile diverso tra quelli scelti qui sotto', 'data-fdg-sorpresa');
    echo '<div class="fdg-sorpresa" data-fdg-per-sorpresa' . (empty($a['sorpresa']) ? ' hidden' : '') . '>';
    foreach (fdg_stili() as $k => $t) {
        echo '<label class="check"><input type="checkbox" name="sorpresa_stili[]" value="' . h($k) . '"' . (in_array($k, $a['sorpresa_stili'], true) ? ' checked' : '') . '> <span>' . h($t) . '</span></label>';
    }
    echo '</div>';
    echo '<div class="fdg-griglia">'
        . '<label class="lab">Dove compare' . fdg_sel('forma', fdg_forme(), $a['forma']) . '</label>'
        . '<label class="lab">Animazione' . fdg_sel('animazione', fdg_animazioni(), $a['animazione']) . '</label>'
        . '<label class="lab">Carattere della frase' . fdg_sel('carattere', fdg_caratteri(), $a['carattere']) . '</label>'
        . '<label class="lab">Grandezza' . fdg_sel('dimensione', fdg_dimensioni(), $a['dimensione']) . '</label>'
        . '<label class="lab">Ornamento' . fdg_sel('ornamento', fdg_ornamenti(), $a['ornamento']) . '</label>'
        . '<label class="lab">Angoli' . fdg_sel('angoli', fdg_angoli(), $a['angoli']) . '</label>'
        . '<label class="lab">Chiusura' . fdg_sel('chiusura', fdg_chiusure(), (int)$a['chiusura']) . '</label>'
        . '<label class="lab">Titolo<input class="input" name="titolo" maxlength="60" value="' . h($a['titolo']) . '" placeholder="La frase del giorno"></label>'
        . '</div>';
    echo fdg_chk('velo', $a['velo'], 'Scurisci la pagina dietro il messaggio');
    echo fdg_chk('data', $a['data'], 'Mostra la data');
    echo '<div class="fdg-riga"><button class="btn primary small" type="submit">Salva l\'aspetto</button></div></form>';
    echo $plugin->form_start('class="fdg-inline fdg-reset" data-confirm="Rimetto l\'aspetto iniziale (Carta avorio, scheda al centro)?"') . fdg_op($plugin, 'asp_reset', 'aspetto')
        . '<button class="btn link small" type="submit">Rimetti l\'aspetto iniziale</button></form>';
    echo '</div>';
    // anteprima
    echo '<div class="fdg-asp-p"><div class="card"><div class="ct">' . admin_icon('eye', 18) . ' Anteprima</div>'
        . '<div class="fdg-comandi"><button class="btn small" type="button" data-fdg-rivedi>' . admin_icon('spin', 16) . ' Rivedi</button>'
        . '<button class="btn ghost small" type="button" data-fdg-altra>' . admin_icon('shuffle', 16) . ' Altra frase</button>'
        . '<span class="fdg-schermi" role="group" aria-label="Schermo"><button type="button" class="on" data-fdg-schermo="tel">Telefono</button><button type="button" data-fdg-schermo="pc">Computer</button></span></div>'
        . '<div class="fdg-stage" data-fdg-stage data-schermo="tel"><div class="fdg-finta" aria-hidden="true"><span class="ft-h"></span><span class="ft-t"></span>'
        . '<span class="ft-r"><i></i><i></i><i></i></span><span class="ft-r"><i></i><i></i><i></i></span><span class="ft-r"><i></i><i></i><i></i></span></div>'
        . fdg_box_html($plugin, $f, $a, 'anteprima', array('libro' => array(0, ''), 'condividi' => !empty(fdg_imp($plugin)['condividi']), 'basta' => true))
        . '</div><p class="hint">Cambia le scelte a sinistra: l\'anteprima si aggiorna subito. Le modifiche valgono sul sito solo dopo «Salva l\'aspetto».</p></div></div>';
    echo '<script type="application/json" id="fdg-campioni">' . json_encode(fdg_campioni($plugin), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>';
    echo '</div>';
}

/* ================= Frasi ================= */

function fdg_scheda_frasi($plugin)
{
    $mie = fdg_mie($plugin, false);
    $esc = fdg_esclusi($plugin);
    $rac = fdg_raccolta();
    echo '<div class="card">' . $plugin->form_start('class="stack"') . fdg_op($plugin, 'mia_nuova', 'frasi')
        . '<div class="ct">' . admin_icon('plus', 18) . ' Aggiungi una frase</div>'
        . '<label class="lab">Frase<textarea class="input" name="testo" rows="3" maxlength="600" required placeholder="Per i versi vai a capo"></textarea></label>'
        . '<div class="fdg-griglia"><label class="lab">Autore<input class="input" name="autore" maxlength="150" required></label>'
        . '<label class="lab">Opera<input class="input" name="opera" maxlength="200" placeholder="es. I promessi sposi"></label>'
        . '<label class="lab">Libro da cercare nella Libreria<input class="input" name="libro" maxlength="200" placeholder="se diverso dall\'opera (es. Canti per L\'infinito)"></label></div>'
        . '<div class="fdg-riga"><button class="btn primary small" type="submit">Aggiungi</button></div></form></div>';

    echo '<div class="card"><div class="ct">' . admin_icon('edit', 18) . ' Le tue frasi (' . count($mie) . ')</div>';
    if (!$mie) {
        echo '<p class="sub">Non ne hai ancora aggiunte.</p>';
    } else {
        echo '<table class="tbl fdg-tbl"><tbody>';
        foreach ($mie as $id => $x) {
            echo '<tr' . (!$x['attiva'] ? ' class="fdg-spenta"' : '') . '><td>' . h(fdg_inizio($x['t'], 110)) . '<br><small class="muted">' . h($x['a']) . ($x['o'] !== '' ? ', ' . h($x['o']) : '') . '</small></td>'
                . '<td class="act">' . fdg_azioni($plugin, $id, $x['attiva'] ? 'spegni' : 'accendi') . '</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';

    echo '<div class="card"><div class="ct">' . admin_icon('books', 18) . ' Raccolta dei classici (' . count($rac) . ($esc ? ', ' . count(array_intersect(array_keys($rac), $esc)) . ' escluse' : '') . ')</div>'
        . '<p class="sub">Frasi da romanzi, poemi e poesie di autori di pubblico dominio (le opere straniere in una traduzione libera). Quelle escluse non escono mai.</p>'
        . '<input class="input fdg-cerca" type="search" placeholder="Cerca per parola, autore od opera" data-fdg-cerca aria-label="Cerca nella raccolta">'
        . '<table class="tbl fdg-tbl" data-fdg-raccolta><tbody>';
    foreach ($rac as $id => $x) {
        $fuori = in_array($id, $esc, true);
        echo '<tr' . ($fuori ? ' class="fdg-spenta"' : '') . ' data-fdg-r="' . h(mb_strtolower($x['t'] . ' ' . $x['a'] . ' ' . $x['o'], 'UTF-8')) . '"><td>' . nl2br(h($x['t'])) . '<br><small class="muted">' . h($x['a']) . ', ' . h($x['o']) . '</small></td>'
            . '<td class="act">' . fdg_azioni($plugin, $id, $fuori ? 'includi' : 'escludi') . '</td></tr>';
    }
    echo '</tbody></table><p class="sub" data-fdg-nessuna hidden>Nessuna frase trovata.</p></div>';
}

function fdg_azioni($plugin, $id, $altro)
{
    $t = array('spegni' => 'Spegni', 'accendi' => 'Riaccendi', 'escludi' => 'Escludi', 'includi' => 'Includi');
    $op = $altro === 'spegni' || $altro === 'accendi' ? 'mia_attiva' : 'escludi';
    $h = '<span class="fdg-act">' . $plugin->form_start('class="fdg-inline"') . fdg_op($plugin, 'usa', 'oggi', array('id' => $id))
        . '<button class="btn ghost small" type="submit" title="Usala come frase di oggi">Usa oggi</button></form>'
        . $plugin->form_start('class="fdg-inline"') . fdg_op($plugin, $op, 'frasi', array('id' => $id))
        . '<button class="btn link small" type="submit">' . h($t[$altro]) . '</button></form>';
    if ($id[0] === 'm') {
        $h .= $plugin->form_start('class="fdg-inline" data-confirm="Elimino questa frase?"') . fdg_op($plugin, 'mia_elimina', 'frasi', array('id' => $id))
            . '<button class="btn link small danger" type="submit" title="Elimina">' . admin_icon('trash', 16) . '</button></form>';
    }
    return $h . '</span>';
}

/* ================= Impostazioni ================= */

function fdg_ore()
{
    $l = array();
    for ($m = 0; $m < 24 * 60; $m += 15) {
        $k = sprintf('%02d:%02d', intdiv($m, 60), $m % 60);
        $l[$k] = $k;
    }
    return $l;
}

function fdg_scheda_impostazioni($plugin)
{
    $i = fdg_imp($plugin);
    $n = count(fdg_raccolta());
    $nm = count(fdg_mie($plugin));
    echo '<div class="card">' . $plugin->form_start('class="stack"') . fdg_op($plugin, 'imp_salva', 'impostazioni');
    echo '<div class="ct">' . admin_icon('gear', 18) . ' Impostazioni</div>';
    echo fdg_chk('attivo', $i['attivo'], '<b>Frase del giorno accesa</b>');
    echo '<div class="fdg-gruppi">';
    echo '<fieldset><legend>Da dove arrivano le frasi</legend>'
        . fdg_chk('fonte_web', $i['fonte_web'], 'Wikiquote: la citazione del giorno (serve la connessione)')
        . '<span class="fdg-sotto">' . fdg_chk('web_solo_opere', $i['web_solo_opere'], 'Solo se è tratta da un\'opera (altrimenti si usa la raccolta)') . '</span>'
        . fdg_chk('fonte_raccolta', $i['fonte_raccolta'], 'Raccolta dei classici (' . $n . ' frasi)')
        . fdg_chk('fonte_mie', $i['fonte_mie'], 'Le tue frasi (' . $nm . ')')
        . '<p class="hint">Ogni giorno la frase si sceglie a caso tra le fonti accese, senza ripetere quelle uscite di recente.</p></fieldset>';
    echo '<fieldset><legend>Messaggio all\'apertura</legend>'
        . '<label class="lab">Quando' . fdg_sel('popup', array('giorno' => 'Una volta al giorno (la prima apertura)', 'apertura' => 'A ogni apertura dell\'app', 'mai' => 'Mai (solo l\'avviso)'), $i['popup']) . '</label>'
        . '<label class="lab">In quale pagina' . fdg_sel('dove', array('tutte' => 'In qualsiasi pagina si apra', 'libreria' => 'Solo nella Libreria'), $i['dove']) . '</label>'
        . '<label class="lab">Dopo' . fdg_sel('ritardo', array(0 => 'Subito', 1 => '1 secondo', 2 => '2 secondi', 3 => '3 secondi', 5 => '5 secondi'), (int)$i['ritardo']) . '</label>'
        . '<p class="hint">Lo vedono tutti gli utenti; ognuno può spegnerlo da Il mio account o dal messaggio stesso.</p></fieldset>';
    echo '<fieldset><legend>Avviso nella campanella</legend>'
        . fdg_chk('avviso', $i['avviso'], 'Manda l\'avviso ogni giorno (anche sul telefono, a chi ha acceso gli avvisi)')
        . '<label class="lab">Alle' . fdg_sel('ora', fdg_ore(), $i['ora']) . '</label>'
        . '<label class="lab">Testo<input class="input" name="testo_avviso" maxlength="160" value="' . h($i['testo_avviso']) . '"></label>'
        . '<p class="hint">{inizio} = l\'inizio della frase, {autore}, {opera}. Parte all\'ora scelta con i lavori automatici del sito; senza il cron del server, alla prima visita dopo quell\'ora.</p></fieldset>';
    echo '<fieldset><legend>Nel messaggio e nel sito</legend>'
        . fdg_chk('link_libro', $i['link_libro'], 'Link «Ce l\'hai in libreria» quando il libro c\'è')
        . fdg_chk('link_aggiungi', $i['link_aggiungi'], 'Link «Aggiungilo alla libreria» quando non c\'è (solo per chi può aggiungere libri)')
        . fdg_chk('condividi', $i['condividi'], 'Pulsante «Condividi» (o copia la frase)')
        . fdg_chk('menu', $i['menu'], 'Pagina «Frase del giorno» nel menu ☰ del sito') . '</fieldset>';
    echo '</div><div class="fdg-riga"><button class="btn primary small" type="submit">Salva</button></div></form></div>';
}

/* ================= Salvataggi ================= */

function fdg_pannello_salva($plugin)
{
    $op = (string)post('op');
    $si = function ($k) {
        return post($k) === '1' ? 1 : 0;
    };
    if ($op === 'imp_salva') {
        $i = fdg_imp($plugin);
        foreach (array('attivo', 'fonte_web', 'web_solo_opere', 'fonte_raccolta', 'fonte_mie', 'avviso', 'link_libro', 'link_aggiungi', 'menu', 'condividi') as $k) {
            $i[$k] = $si($k);
        }
        $i['popup'] = in_array(post('popup'), array('giorno', 'apertura', 'mai'), true) ? post('popup') : 'giorno';
        $i['dove'] = post('dove') === 'libreria' ? 'libreria' : 'tutte';
        $i['ritardo'] = max(0, min(10, (int)post('ritardo')));
        $i['ora'] = isset(fdg_ore()[(string)post('ora')]) ? (string)post('ora') : '08:00';
        $t = trim(str_cut((string)post('testo_avviso'), 160));
        $i['testo_avviso'] = $t !== '' ? $t : fdg_imp_predefinite()['testo_avviso'];
        $prima = fdg_imp($plugin);
        fdg_salva_json($plugin, 'imp', $i);
        // se l'ora dell'avviso si sposta piu' avanti ed era gia' partito per oggi, resta partito; se si accende ora, parte all'ora scelta
        if (empty($prima['avviso']) && $i['avviso'] && date('H:i') < $i['ora']) {
            $plugin->save_setting('avviso_del', '');
        }
        flash('Impostazioni salvate.');
        return;
    }
    if ($op === 'asp_salva') {
        $a = fdg_asp($plugin);
        $a['stile'] = isset(fdg_stili()[(string)post('stile')]) ? (string)post('stile') : 'carta';
        $a['forma'] = isset(fdg_forme()[(string)post('forma')]) ? (string)post('forma') : 'scheda';
        $a['carattere'] = isset(fdg_caratteri()[(string)post('carattere')]) ? (string)post('carattere') : 'classico';
        $a['dimensione'] = isset(fdg_dimensioni()[(string)post('dimensione')]) ? (string)post('dimensione') : 'm';
        $a['ornamento'] = isset(fdg_ornamenti()[(string)post('ornamento')]) ? (string)post('ornamento') : 'virgolette';
        $a['animazione'] = isset(fdg_animazioni()[(string)post('animazione')]) ? (string)post('animazione') : 'sfoglia';
        $a['angoli'] = isset(fdg_angoli()[(string)post('angoli')]) ? (string)post('angoli') : 'morbidi';
        $a['chiusura'] = isset(fdg_chiusure()[(int)post('chiusura')]) ? (int)post('chiusura') : 0;
        $a['titolo'] = trim(str_cut((string)post('titolo'), 60));
        $a['velo'] = $si('velo');
        $a['data'] = $si('data');
        $a['sorpresa'] = $si('sorpresa');
        $ss = isset($_POST['sorpresa_stili']) && is_array($_POST['sorpresa_stili']) ? array_map('strval', $_POST['sorpresa_stili']) : array();
        $a['sorpresa_stili'] = array_values(array_intersect(array_keys(fdg_stili()), $ss));
        if ($a['sorpresa'] && count($a['sorpresa_stili']) < 2) {
            $a['sorpresa'] = 0;
            flash_add('Per lo stile a sorpresa scegli almeno due stili: per ora resta spento.', 'warn');
        }
        foreach (array('c_sfondo' => '#fbf6ea', 'c_testo' => '#2b2118', 'c_accento' => '#9a3b2f') as $k => $d) {
            $a[$k] = fdg_colore(post($k), $d);
        }
        $prima = fdg_asp($plugin);
        fdg_salva_json($plugin, 'aspetto', $a);
        // lo stile del giorno segue subito le nuove scelte
        $o = json_decode((string)$plugin->setting('oggi', ''), true);
        if (is_array($o) && ($a['sorpresa'] !== (int)$prima['sorpresa'] || $a['sorpresa_stili'] !== $prima['sorpresa_stili'] || (!$a['sorpresa'] && !empty($o['stile']))
            || ($a['sorpresa'] && !in_array((string)$o['stile'], $a['sorpresa_stili'], true)))) {
            $o['stile'] = $a['sorpresa'] && $a['sorpresa_stili'] ? $a['sorpresa_stili'][mt_rand(0, count($a['sorpresa_stili']) - 1)] : '';
            $plugin->save_setting('oggi', json_encode($o, JSON_UNESCAPED_UNICODE));
        }
        flash('Aspetto salvato.');
        return;
    }
    if ($op === 'asp_reset') {
        fdg_salva_json($plugin, 'aspetto', fdg_asp_predefinito());
        $o = json_decode((string)$plugin->setting('oggi', ''), true);
        if (is_array($o)) {
            $o['stile'] = '';
            $plugin->save_setting('oggi', json_encode($o, JSON_UNESCAPED_UNICODE));
        }
        flash('Aspetto iniziale rimesso.');
        return;
    }
    if ($op === 'cambia') {
        $o = fdg_oggi($plugin);
        $nuova = null;
        for ($i = 0; $i < 6; $i++) {
            $x = fdg_scegli($plugin, $o && $o['fonte'] === 'web');
            if ($x && (!$o || $x['t'] !== $o['t'])) {
                $nuova = $x;
                break;
            }
        }
        if ($nuova) {
            fdg_imposta_oggi($plugin, $nuova);
            flash('Nuova frase di oggi: ' . fdg_inizio($nuova['t'], 60) . ' (' . $nuova['a'] . ').');
        } else {
            flash('Non ho trovato un\'altra frase: controlla le fonti in Impostazioni.', 'warn');
        }
        return;
    }
    if ($op === 'usa') {
        $f = fdg_frase_per_id($plugin, (string)post('id'));
        if ($f) {
            fdg_imposta_oggi($plugin, $f);
            flash('Frase di oggi cambiata: ' . fdg_inizio($f['t'], 60) . ' (' . $f['a'] . ').');
        }
        return;
    }
    if ($op === 'avviso_ora') {
        $n = fdg_avviso($plugin, true);
        flash($n ? 'Avviso mandato (' . $n . ($n === 1 ? ' persona' : ' persone') . ').' : 'Nessun avviso mandato: nessuno lo riceve (spento, o tutti l\'hanno spento).', $n ? 'success' : 'warn');
        return;
    }
    if ($op === 'prova_web') {
        $w = fdg_wikiquote($plugin);
        if ($w[0]) {
            flash('Wikiquote risponde. Citazione di oggi: «' . fdg_inizio($w[1]['t'], 90) . '» — ' . $w[1]['a'] . ($w[1]['o'] !== '' ? ', ' . $w[1]['o'] : '') . '.');
        } else {
            flash('Wikiquote: ' . $w[1] . '.', 'warn');
        }
        return;
    }
    if ($op === 'mia_nuova') {
        $t = trim(str_replace("\r", '', str_cut((string)post('testo'), 600)));
        $a = trim(str_cut((string)post('autore'), 150));
        if ($t === '' || $a === '') {
            flash('Scrivi la frase e l\'autore.', 'error');
            return;
        }
        db()->prepare('INSERT INTO ' . $plugin->table('frasi') . ' (testo, autore, opera, libro, attiva, created_at) VALUES (?,?,?,?,1,?)')
            ->execute(array($t, $a, trim(str_cut((string)post('opera'), 200)), trim(str_cut((string)post('libro'), 200)), now()));
        flash('Frase aggiunta.');
        return;
    }
    $id = (string)post('id');
    if ($op === 'mia_attiva' && preg_match('/^m(\d+)$/', $id, $m)) {
        db()->prepare('UPDATE ' . $plugin->table('frasi') . ' SET attiva = 1 - attiva WHERE id = ?')->execute(array((int)$m[1]));
        return;
    }
    if ($op === 'mia_elimina' && preg_match('/^m(\d+)$/', $id, $m)) {
        db()->prepare('DELETE FROM ' . $plugin->table('frasi') . ' WHERE id = ?')->execute(array((int)$m[1]));
        flash('Frase eliminata.');
        return;
    }
    if ($op === 'escludi' && isset(fdg_raccolta()[$id])) {
        $e = fdg_esclusi($plugin);
        $e = in_array($id, $e, true) ? array_values(array_diff($e, array($id))) : array_merge($e, array($id));
        $plugin->save_setting('esclusi', json_encode($e));
        return;
    }
}
