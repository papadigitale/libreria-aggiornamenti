// Ricordi di lettura: il riquadro "Accadde oggi" si nasconde per la giornata
(function () {
  'use strict';
  var box = document.querySelector('[data-rl-box]');
  if (!box) { return; }
  var chiave = 'rl-chiuso', oggi = box.getAttribute('data-rl-box');
  try { if (localStorage.getItem(chiave) === oggi) { box.hidden = true; return; } } catch (e) { /* senza memoria del browser resta visibile */ }
  var x = box.querySelector('[data-rl-chiudi]');
  if (x) {
    x.addEventListener('click', function () {
      box.hidden = true;
      try { localStorage.setItem(chiave, oggi); } catch (e) { /* niente */ }
    });
  }
})();
