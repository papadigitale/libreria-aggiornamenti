<?php
/*
 * Ricordi di lettura: "Accadde oggi" in cima alla Libreria e una pagina con i ricordi del mese.
 *  - personali: i libri che chi guarda ha finito in questo giorno (o in questa settimana) negli anni passati;
 *  - di casa: i libri aggiunti alla libreria in questa data negli anni passati.
 * Non crea tabelle: legge solo le letture e i libri. Prefisso delle funzioni: rl_
 */
require_once APP_ROOT . '/inc/books.php';
require_once APP_ROOT . '/inc/reading.php';

function rl_anni($n)
{
    return $n === 1 ? '1 anno fa' : $n . ' anni fa';
}

// Letture finite (con la data nota) dell'utente, negli anni passati, nei giorni indicati ('m-d')
function rl_letture($uid, $giorni)
{
    if (!function_exists('reading_ready') || !reading_ready() || !$uid) {
        return array();
    }
    $st = db()->prepare("SELECT s.finished_at, s.rating, b.id, b.title, b.authors, b.cover_file FROM reading_sessions s JOIN books b ON b.id = s.book_id "
        . "WHERE s.user_id = ? AND s.status = 'letto' AND s.finished_at IS NOT NULL AND s.date_unknown = 0 AND s.finished_at < ? ORDER BY s.finished_at DESC");
    $st->execute(array((int)$uid, date('Y') . '-01-01 00:00:00'));
    $out = array();
    foreach ($st->fetchAll() as $r) {
        if (in_array(date('m-d', strtotime($r['finished_at'])), $giorni, true)) {
            $out[] = $r;
        }
    }
    return $out;
}

function rl_arrivi($giorni)
{
    $st = db()->prepare('SELECT id, title, authors, cover_file, created_at FROM books WHERE created_at < ? ORDER BY created_at DESC LIMIT 2000');
    $st->execute(array(date('Y') . '-01-01 00:00:00'));
    $out = array();
    foreach ($st->fetchAll() as $r) {
        if (in_array(date('m-d', strtotime($r['created_at'])), $giorni, true)) {
            $out[] = $r;
        }
    }
    return $out;
}

function rl_giorni($quanti)
{
    $g = array();
    for ($i = 0; $i < $quanti; $i++) {
        $g[] = date('m-d', strtotime('-' . $i . ' days'));
    }
    return $g;
}

function rl_voce($b, $testo)
{
    return '<a class="rl-i" href="libro.php?id=' . (int)$b['id'] . '">' . book_cover_html($b, 'cover rl-cop')
        . '<span class="rl-t"><small>' . h($testo) . '</small><b>' . h($b['title']) . '</b><span class="rl-a">' . h((string)$b['authors']) . '</span>'
        . (!empty($b['rating']) && function_exists('stars_html') ? stars_html((float)$b['rating'], 'sm') : '') . '</span></a>';
}

/* ---------------- "Accadde oggi" in cima alla Libreria ---------------- */

$plugin->on('pagina_libreria', function ($html, $ricerca) use ($plugin) {
    if ($ricerca !== '' || !is_logged() || get('p') !== '') {
        return $html;
    }
    $max = max(1, min(6, (int)$plugin->setting('quanti', '3')));
    // se oggi non c'e' niente, si guarda alla settimana appena passata
    $giorni = rl_giorni(1);
    $voci = array();
    $anno = (int)date('Y');
    if (is_user() && $plugin->setting('letture', '1') === '1') {
        $l = rl_letture(current_uid(), $giorni);
        if (!$l && $plugin->setting('settimana', '1') === '1') {
            $l = rl_letture(current_uid(), rl_giorni(7));
            $quando = 'in questi giorni';
        }
        foreach (array_slice($l, 0, $max) as $b) {
            $n = $anno - (int)date('Y', strtotime($b['finished_at']));
            $voci[] = rl_voce($b, (isset($quando) ? rl_anni($n) . ', ' . $quando : rl_anni($n) . ' oggi') . ' hai finito');
        }
    }
    if (count($voci) < $max && $plugin->setting('arrivi', '1') === '1') {
        foreach (array_slice(rl_arrivi($giorni), 0, $max - count($voci)) as $b) {
            $voci[] = rl_voce($b, 'In casa da ' . ($anno - (int)date('Y', strtotime($b['created_at']))) . ($anno - (int)date('Y', strtotime($b['created_at'])) === 1 ? ' anno' : ' anni') . ' oggi');
        }
    }
    if (!$voci) {
        return $html;
    }
    return $html . '<section class="rl-box" data-rl-box="' . h(date('Y-m-d')) . '"><div class="rl-head"><span>' . icon('page', 16) . ' Accadde oggi</span>'
        . (is_user() ? '<a class="link" href="' . h($plugin->site_url('ricordi')) . '">Tutti i ricordi</a>' : '')
        . '<button class="rl-x" type="button" data-rl-chiudi aria-label="Nascondi per oggi" title="Nascondi per oggi">×</button></div>'
        . '<div class="rl-list">' . implode('', $voci) . '</div></section>';
});

$plugin->on('html_testa', function ($html) use ($plugin) {
    $s = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '');
    return $s === 'libreria.php' || ($s === 'plg.php' && get('p') === $plugin->id) ? $html . $plugin->css('file/stile.css') : $html;
});
$plugin->on('html_fondo', function ($html) use ($plugin) {
    return basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '') === 'libreria.php' ? $html . $plugin->js('file/ricordi.js') : $html;
});

/* ---------------- Pagina: i ricordi del mese, anno per anno ---------------- */

$plugin->site_page('ricordi', 'Ricordi di lettura', function ($plugin) {
    $mesi = array(1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre');
    $m = (int)get('m') >= 1 && (int)get('m') <= 12 ? (int)get('m') : (int)date('n');
    $giorni = array();
    for ($d = 1; $d <= 31; $d++) {
        $giorni[] = sprintf('%02d-%02d', $m, $d);
    }
    $per_anno = array();
    foreach (rl_letture(current_uid(), $giorni) as $b) {
        $per_anno[(int)date('Y', strtotime($b['finished_at']))][] = $b;
    }
    krsort($per_anno);
    $prec = $m === 1 ? 12 : $m - 1;
    $succ = $m === 12 ? 1 : $m + 1;
    echo '<h1 class="h1">Ricordi di ' . h($mesi[$m]) . '</h1><p class="sub">I libri che hai finito a ' . h($mesi[$m]) . ' negli anni passati.</p>'
        . '<div class="rl-nav"><a class="btn ghost small" href="' . h($plugin->site_url('ricordi', array('m' => $prec))) . '">← ' . h(ucfirst($mesi[$prec])) . '</a>'
        . '<a class="btn ghost small" href="' . h($plugin->site_url('ricordi', array('m' => $succ))) . '">' . h(ucfirst($mesi[$succ])) . ' →</a></div>';
    if (!$per_anno) {
        echo '<div class="card"><p class="sub">Nessuna lettura finita a ' . h($mesi[$m]) . ' negli anni passati (contano le letture con la data).</p></div>';
        return;
    }
    foreach ($per_anno as $anno => $lista) {
        echo '<div class="card"><div class="ct">' . (int)$anno . ' <small class="muted">· ' . h(rl_anni((int)date('Y') - $anno)) . ' · ' . (count($lista) === 1 ? '1 libro' : count($lista) . ' libri') . '</small></div><div class="rl-list">';
        foreach ($lista as $b) {
            echo rl_voce($b, 'finito il ' . date('d/m', strtotime($b['finished_at'])));
        }
        echo '</div></div>';
    }
}, array('ruolo' => 'utente', 'menu' => true, 'icona' => 'page'));

/* ---------------- Impostazioni (Admin) ---------------- */

$plugin->admin_page('impostazioni', 'Ricordi di lettura', function ($plugin) {
    $c = function ($k, $t) use ($plugin) {
        return '<label class="check"><input type="checkbox" name="' . $k . '" value="1"' . ($plugin->setting($k, '1') === '1' ? ' checked' : '') . '> ' . h($t) . '</label>';
    };
    echo '<div class="card">' . $plugin->form_start('class="stack"') . '<div class="ct">«Accadde oggi» in cima alla Libreria</div>'
        . $c('letture', 'Le letture finite in questo giorno negli anni passati (ognuno vede le sue)')
        . $c('settimana', 'Se oggi non c\'è niente, mostra quelle di questa settimana')
        . $c('arrivi', 'I libri entrati in casa in questa data (li vedono tutti)')
        . '<label class="lab">Quanti libri al massimo</label><input class="input" type="number" name="quanti" min="1" max="6" value="' . (int)$plugin->setting('quanti', '3') . '" style="max-width:120px">'
        . '<button class="btn primary small" type="submit">Salva</button></form>'
        . '<p class="hint">Il riquadro si chiude con × per tutta la giornata. Contano solo le letture con la data (non quelle segnate «data sconosciuta»).</p></div>';
}, array('ruolo' => 'admin', 'salva' => function ($plugin) {
    foreach (array('letture', 'settimana', 'arrivi') as $k) {
        $plugin->save_setting($k, post($k) === '1' ? '1' : '0');
    }
    $plugin->save_setting('quanti', (string)max(1, min(6, (int)post('quanti'))));
    flash('Impostazioni salvate.');
}));
