<?php
/*
 * PF Backup — pannello (Gestione → Plugin → PF Backup), a schede come WPvivid:
 * Backup e ripristino · Pianifica · Storage remoto · Impostazioni · Log
 */

function pfb_schede()
{
    return array('backup' => 'Backup e ripristino', 'pianifica' => 'Pianifica', 'storage' => 'Storage remoto', 'impostazioni' => 'Impostazioni', 'log' => 'Log');
}

function pfb_url_scheda($plugin, $tab, $extra = array())
{
    return $plugin->admin_url('backup', array_merge(array('tab' => $tab), $extra));
}

function pfb_icona_storage($tipo, $size = 18)
{
    $c = array('gdrive' => '#1fa463', 'dropbox' => '#0061fe', 'onedrive' => '#0364b8', 's3' => '#e7891c', 'ftp' => '#b07c1f', 'sftp' => '#8a5a12', 'webdav' => '#0082c9',
        'cartella' => '#6c757d', 'server' => '#5b6472');
    $p = array(
        'gdrive' => '<path d="M8 3h8l6 10-4 7H6l-4-7z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M8 3l6 10h8M2 13h12l-4 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>',
        'dropbox' => '<path d="M7 3l5 3.2-5 3.2-5-3.2zM17 3l5 3.2-5 3.2-5-3.2zM2 12.6l5-3.2 5 3.2-5 3.2zM22 12.6l-5-3.2-5 3.2 5 3.2zM7 17l5 3.2 5-3.2-5-3.2z" fill="currentColor"/>',
        'onedrive' => '<path d="M6.5 19A4.5 4.5 0 0 1 6 10a6 6 0 0 1 11.5-1.5A4.8 4.8 0 1 1 18 19z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>',
        's3' => '<ellipse cx="12" cy="6" rx="8" ry="3" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3" fill="none" stroke="currentColor" stroke-width="1.8"/>',
        'ftp' => '<path d="M3 6h7l2 2h9v11H3z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M8 14h8M13 11l3 3-3 3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'sftp' => '<path d="M3 6h7l2 2h9v11H3z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><rect x="9" y="12" width="6" height="5" rx="1" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M10.5 12v-1.5a1.5 1.5 0 0 1 3 0V12" fill="none" stroke="currentColor" stroke-width="1.6"/>',
        'webdav' => '<path d="M6.5 19A4.5 4.5 0 0 1 6 10a6 6 0 0 1 11.5-1.5A4.8 4.8 0 1 1 18 19z" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="14" r="2.4" fill="none" stroke="currentColor" stroke-width="1.6"/>',
        'cartella' => '<path d="M3 6h7l2 2h9v11H3z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>',
        'server' => '<rect x="3" y="4" width="18" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="3" y="13" width="18" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M7 7.5h.01M7 16.5h.01" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>',
    );
    return '<svg class="pfb-ic" width="' . (int)$size . '" height="' . (int)$size . '" viewBox="0 0 24 24" aria-hidden="true" style="color:' . $c[$tipo] . '">' . $p[$tipo] . '</svg>';
}

function pfb_pannello($plugin)
{
    $tab = array_key_exists((string)get('tab'), pfb_schede()) ? (string)get('tab') : 'backup';
    echo '<div class="pfb" data-pfb data-api="api.php?action=plg&amp;p=' . h($plugin->id) . '&amp;f=" data-log-url="' . h(pfb_url_scheda($plugin, 'log')) . '">';
    echo '<nav class="pfb-tabs" aria-label="Schede di PF Backup">';
    foreach (pfb_schede() as $k => $t) {
        echo '<a href="' . h(pfb_url_scheda($plugin, $k)) . '"' . ($k === $tab ? ' class="on" aria-current="page"' : '') . '>' . h($t) . '</a>';
    }
    echo '</nav>';
    if (!class_exists('ZipArchive')) {
        echo '<div class="alert error">Manca l\'estensione <b>zip</b> di PHP: PF Backup non può creare backup.</div>';
    }
    $fn = 'pfb_scheda_' . $tab;
    $fn($plugin);
    echo pfb_finestre($plugin);
    echo '</div>';
}

/* ================= Backup e ripristino ================= */

function pfb_scheda_backup($plugin)
{
    $att = pfb_storage_attivo($plugin);
    $imp = pfb_imp($plugin);
    $p = pfb_pian($plugin);
    $pross = pfb_pian_prossimo($plugin);
    $ult = (int)$plugin->setting('pian_ultimo', '0');
    $locali = pfb_locali($plugin);
    $pw = pfb_password($plugin) !== '';
    echo '<div class="pfb-top"><div class="card pfb-esegui">';
    echo '<div class="ct">' . admin_icon('upload', 18) . ' Esegui il backup adesso</div>';
    echo '<p class="pfb-dir">Cartella dei backup sul server: <code>' . h(str_replace('\\', '/', pfb_archivio($plugin))) . '</code></p>';
    echo '<div class="pfb-col2"><div class="pfb-scelte"><span class="lab">Cosa salvare</span>'
        . '<label class="check"><input type="radio" name="pfb-cont" value="completo" checked> <span>Database + file (tutto il sito)</span></label>'
        . '<label class="check"><input type="radio" name="pfb-cont" value="file"> <span>Solo i file (copertine, immagini, media, plugin…)</span></label>'
        . '<label class="check"><input type="radio" name="pfb-cont" value="db"> <span>Solo il database</span></label></div>';
    echo '<div class="pfb-scelte"><span class="lab">Dove</span>'
        . '<label class="check"><input type="radio" name="pfb-dove" value="locale" checked> <span>Sul server</span></label>'
        . '<label class="check"><input type="radio" name="pfb-dove" value="remoto"' . ($att ? '' : ' disabled') . '> <span>Sul server e nello storage remoto: '
        . ($att ? pfb_icona_storage($att['tipo'], 16) . ' <b>' . h(pfb_storage_nome($att)) . '</b>' : '<a class="link" href="' . h(pfb_url_scheda($plugin, 'storage')) . '">aggiungine uno</a>') . '</span></label></div></div>';
    echo '<div class="pfb-azione"><button class="btn primary" type="button" data-pfb-avvia>' . admin_icon('upload', 18) . ' Esegui il backup</button>'
        . '<p class="hint">' . ($imp['programmi'] ? 'Con «Database + file» o «Solo i file» si salvano anche i programmi del sito (per spostarlo su un altro server). ' : '')
        . ($pw ? admin_icon('lock', 13) . ' I backup sono cifrati con la password.' : 'I backup non sono cifrati: puoi mettere una password in Impostazioni.') . '</p></div>';
    echo '<div class="pfb-prog" data-pfb-prog hidden><div class="pfb-prog-t"><b data-pfb-prog-titolo>Backup</b><span data-pfb-prog-perc>0%</span></div>'
        . '<div class="pfb-bar"><i data-pfb-prog-bar></i></div><p data-pfb-prog-testo></p><div class="row-btn" data-pfb-prog-fine hidden>'
        . '<a class="btn ghost small" href="' . h(pfb_url_scheda($plugin, 'backup')) . '">Aggiorna l\'elenco</a><a class="btn link small" data-pfb-prog-log href="#">Vedi il log</a></div></div>';
    echo '</div>';
    echo '<div class="card pfb-pian"><div class="ct">' . admin_icon('chart', 18) . ' Pianifica il backup</div>'
        . '<div class="fr row"><span>Stato</span><span>' . (!empty($p['on']) ? '<span class="ok-text">attiva</span>' : 'spenta') . '</span></div>'
        . (!empty($p['on']) ? '<div class="fr row"><span>Frequenza</span><span>' . h(pfb_freq()[$p['freq']]) . ', alle ' . h($p['ora']) . '</span></div>' : '')
        . '<div class="fr row"><span>Ora del server</span><span>' . h(date('d/m/Y H:i')) . '</span></div>'
        . '<div class="fr row"><span>Ultimo backup pianificato</span><span>' . ($ult ? h(date('d/m/Y H:i', $ult)) : '—') . '</span></div>'
        . '<div class="fr row"><span>Prossimo</span><span>' . ($pross ? h(date('d/m/Y H:i', $pross)) : '—') . '</span></div>'
        . '<a class="btn link small" href="' . h(pfb_url_scheda($plugin, 'pianifica')) . '">Cambia la pianificazione</a></div></div>';

    // elenco
    $sub = get('vista') === 'carica' ? 'carica' : 'elenco';
    echo '<nav class="pfb-sub"><a href="' . h(pfb_url_scheda($plugin, 'backup')) . '"' . ($sub === 'elenco' ? ' class="on"' : '') . '>Backup</a>'
        . '<a href="' . h(pfb_url_scheda($plugin, 'backup', array('vista' => 'carica'))) . '"' . ($sub === 'carica' ? ' class="on"' : '') . '>Carica</a></nav>';
    if ($sub === 'carica') {
        echo '<div class="card"><div class="ct">' . admin_icon('upload', 18) . ' Carica un backup</div>'
            . '<p class="sub">Un backup di PF Backup scaricato in precedenza, anche di un altro sito (per spostare la libreria su questo server). Si carica a pezzi: vanno bene anche file grandi.</p>'
            . '<input class="input" type="file" accept=".zip,application/zip" data-pfb-file><div class="pfb-prog" data-pfb-car hidden><div class="pfb-bar"><i data-pfb-car-bar></i></div><p data-pfb-car-testo></p></div>'
            . '<button class="btn primary small" type="button" data-pfb-carica disabled>Carica</button></div>';
        return;
    }
    echo '<div class="card pfb-elenco">';
    if (!$locali) {
        echo '<p class="sub">Nessun backup sul server, per ora.</p>';
    } else {
        $st_nomi = array();
        foreach (pfb_storage_tutti($plugin) as $s) {
            $st_nomi[$s['id']] = $s;
        }
        echo $plugin->form_start('data-pfb-elenco data-confirm="Eliminare i backup selezionati dal server?"') . '<input type="hidden" name="op" value="elimina"><input type="hidden" name="back" value="' . h(pfb_url_scheda($plugin, 'backup')) . '">';
        echo '<table class="tbl pfb-tbl"><thead><tr><th class="pfb-cb"><input type="checkbox" data-pfb-tutti aria-label="Seleziona tutti"></th><th>Backup</th><th>Dove</th><th>Scarica</th><th>Ripristina</th><th class="act">Elimina</th></tr></thead><tbody>';
        $bl = pfb_bloccati($plugin);
        foreach ($locali as $n => $m) {
            $blocc = in_array($n, $bl, true) || !empty($m['bloccato']);
            $tipo = array('completo' => 'Database + file', 'db' => 'Solo database', 'file' => 'Solo file');
            $orig = array('manuale' => 'Manuale', 'pianificato' => 'Pianificato', 'sicurezza' => 'Copia di sicurezza', 'caricato' => 'Caricato', 'scaricato' => 'Dallo storage');
            echo '<tr data-nome="' . h($n) . '"><td class="pfb-cb"><input type="checkbox" name="sel[]" value="' . h($n) . '"' . ($blocc ? ' disabled' : '') . ' aria-label="Seleziona ' . h($n) . '"></td>'
                . '<td><b>' . h(date('d/m/Y H:i', $m['data'])) . '</b><br><small class="muted">' . h(isset($tipo[$m['contenuto'] ?? '']) ? $tipo[$m['contenuto']] : '') . ' · '
                . h(isset($orig[$m['origine']]) ? $orig[$m['origine']] : $m['origine']) . (!empty($m['cifrato']) ? ' · ' . admin_icon('lock', 12) . ' cifrato' : '')
                . (!empty($m['programmi']) ? ' · con i programmi' : '') . (!empty($m['app_version']) ? ' · v' . h($m['app_version']) : '') . '</small><br>'
                . '<span class="pfb-azioni-r"><button class="pfb-lucchetto' . ($blocc ? ' on' : '') . '" type="submit" form="pfb-bl-' . h(md5($n)) . '" title="' . ($blocc ? 'Bloccato: si cancella solo a mano. Clic per sbloccare' : 'Clic per bloccarlo: non verrà cancellato in automatico') . '">'
                . admin_icon('lock', 13) . ($blocc ? ' bloccato' : ' blocca') . '</button>'
                . (!empty($m['log']) && is_file(pfb_dir($plugin, 'log') . '/' . $m['log']) ? '<a class="link" href="' . h(pfb_url_scheda($plugin, 'log', array('vedi' => $m['log']))) . '">Log</a>' : '')
                . ($att && !in_array($att['id'], (array)($m['remoto'] ?? array()), true) ? '<button class="btn link small" type="button" data-pfb-invia="' . h($n) . '">Invia allo storage</button>' : '')
                . '</span></td>';
            echo '<td class="pfb-dove"><span title="Sul server">' . pfb_icona_storage('server') . '</span>';
            foreach ((array)($m['remoto'] ?? array()) as $sid) {
                if (isset($st_nomi[$sid])) {
                    echo '<span title="' . h(pfb_storage_nome($st_nomi[$sid])) . '">' . pfb_icona_storage($st_nomi[$sid]['tipo']) . '</span>';
                }
            }
            echo '</td><td><a class="link" href="' . h($plugin->site_url('scarica', array('f' => $n))) . '">' . admin_icon('down', 14) . ' Scarica (' . h(pfb_mb($m['dimensione'])) . ')</a></td>'
                . '<td><button class="btn link small" type="button" data-pfb-ripristina="' . h($n) . '" data-cifrato="' . (!empty($m['cifrato']) ? '1' : '0') . '">' . admin_icon('upload', 14) . ' Ripristina</button></td>'
                . '<td class="act">' . ($blocc ? '<span class="muted" title="Bloccato">—</span>' : '<button class="btn link small pfb-del" type="submit" name="sel[]" value="' . h($n) . '" title="Elimina">' . admin_icon('trash', 15) . '</button>') . '</td></tr>';
        }
        echo '</tbody></table><button class="btn ghost small" type="submit" data-pfb-sel-elimina disabled>' . admin_icon('trash', 14) . ' Elimina i selezionati</button></form>';
        foreach ($locali as $n => $m) {
            $blocc = in_array($n, $bl, true) || !empty($m['bloccato']);
            echo $plugin->form_start('id="pfb-bl-' . h(md5($n)) . '" hidden') . '<input type="hidden" name="op" value="' . ($blocc ? 'sblocca' : 'blocca') . '"><input type="hidden" name="nome" value="' . h($n) . '">'
                . '<input type="hidden" name="back" value="' . h(pfb_url_scheda($plugin, 'backup')) . '"></form>';
        }
    }
    echo '</div>';
    // backup nello storage remoto
    $tutti = pfb_storage_tutti($plugin);
    if ($tutti) {
        echo '<div class="card pfb-remoti"><div class="ct">' . admin_icon('cloud', 18) . ' Backup negli storage remoti</div>'
            . '<p class="sub">Per ripristinare un backup che non è più sul server, prima scaricalo qui.</p><div class="row-btn">'
            . '<select class="input" data-pfb-rem-st aria-label="Storage">';
        foreach ($tutti as $s) {
            echo '<option value="' . h($s['id']) . '"' . ($att && $att['id'] === $s['id'] ? ' selected' : '') . '>' . h(pfb_storage_nome($s)) . '</option>';
        }
        echo '</select><button class="btn ghost small" type="button" data-pfb-rem-mostra>Mostra i backup</button></div><div data-pfb-rem-lista></div></div>';
    }
}

/* ================= Pianifica ================= */

function pfb_scheda_pianifica($plugin)
{
    $p = pfb_pian($plugin);
    $att = pfb_storage_attivo($plugin);
    $lav = (int)setting('cron_last', '0') > time() - 3 * 3600;
    echo $plugin->form_start('class="card stack pfb-pianifica"') . '<input type="hidden" name="op" value="pianifica"><input type="hidden" name="back" value="' . h(pfb_url_scheda($plugin, 'pianifica')) . '">';
    echo '<div class="ct">' . admin_icon('chart', 18) . ' Impostazioni di pianificazione</div>';
    echo '<label class="check switch"><input type="checkbox" name="on" value="1"' . (!empty($p['on']) ? ' checked' : '') . '><span><b>Attiva la pianificazione del backup</b></span></label>';
    echo '<p class="hint">' . ($lav ? '<span class="ok-text">' . admin_icon('check', 13) . ' I lavori automatici del server sono attivi:</span> il backup parte all\'ora scelta, anche di notte.'
        : 'I lavori automatici del server (cron) non risultano attivi: il backup partirà alla prima visita al sito dopo l\'ora scelta. Vedi la guida, capitolo «Lavori automatici del server».') . '</p>';
    echo '<div class="pfb-grid"><fieldset><legend>Frequenza</legend>';
    foreach (pfb_freq() as $k => $t) {
        echo '<label class="check"><input type="radio" name="freq" value="' . h($k) . '"' . ($p['freq'] === $k ? ' checked' : '') . ' data-pfb-freq> <span>' . h($t) . '</span></label>';
    }
    echo '</fieldset><fieldset><legend>Quando</legend><label class="lab" for="pfb-ora">Ora</label><input class="input" id="pfb-ora" type="time" name="ora" value="' . h($p['ora']) . '">';
    echo '<div data-pfb-solo="settimana"><label class="lab" for="pfb-gs">Giorno della settimana</label><select class="input" id="pfb-gs" name="giorno_sett">';
    foreach (array(1 => 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica') as $k => $t) {
        echo '<option value="' . $k . '"' . ((int)$p['giorno_sett'] === $k ? ' selected' : '') . '>' . $t . '</option>';
    }
    echo '</select></div><div data-pfb-solo="mese"><label class="lab" for="pfb-gm">Giorno del mese</label><select class="input" id="pfb-gm" name="giorno_mese">';
    for ($i = 1; $i <= 28; $i++) {
        echo '<option value="' . $i . '"' . ((int)$p['giorno_mese'] === $i ? ' selected' : '') . '>' . $i . '</option>';
    }
    echo '</select></div><p class="hint" data-pfb-solo="12ore">Alle ore scelte e 12 ore dopo.</p><p class="hint" data-pfb-solo="15giorni">Ogni 15 giorni all\'ora scelta, dal primo backup.</p></fieldset>';
    echo '<fieldset><legend>Cosa salvare</legend>';
    foreach (array('completo' => 'Database + file (tutto il sito)', 'file' => 'Solo i file', 'db' => 'Solo il database') as $k => $t) {
        echo '<label class="check"><input type="radio" name="contenuto" value="' . $k . '"' . ($p['contenuto'] === $k ? ' checked' : '') . '> <span>' . h($t) . '</span></label>';
    }
    echo '</fieldset><fieldset><legend>Dove</legend>'
        . '<label class="check"><input type="radio" name="dove" value="locale"' . ($p['dove'] === 'locale' ? ' checked' : '') . '> <span>Sul server</span></label>'
        . '<label class="check"><input type="radio" name="dove" value="remoto"' . ($p['dove'] === 'remoto' ? ' checked' : '') . ($att ? '' : ' disabled') . '> <span>Invia allo storage remoto'
        . ($att ? ': ' . pfb_icona_storage($att['tipo'], 15) . ' ' . h(pfb_storage_nome($att)) : ' (aggiungine uno nella scheda Storage remoto)') . '</span></label>'
        . '<p class="hint">Se tenere anche la copia sul server dopo l\'invio si sceglie in Impostazioni.</p></fieldset></div>';
    echo '<button class="btn primary small" type="submit">Salva</button></form>';
}

/* ================= Storage remoto ================= */

function pfb_campi_storage($tipo)
{
    $c = array(
        'gdrive' => array(array('cartella', 'Nome della cartella su Google Drive', 'text', 'PF Backup')),
        'dropbox' => array(array('cartella', 'Sottocartella (dentro la cartella dell\'app)', 'text', '')),
        'onedrive' => array(array('cartella', 'Sottocartella (dentro la cartella dell\'app)', 'text', '')),
        's3' => array(array('endpoint', 'Indirizzo (endpoint)', 'url', 'https://s3.eu-south-1.amazonaws.com'), array('regione', 'Regione', 'text', 'eu-south-1'),
            array('bucket', 'Bucket', 'text', ''), array('chiave', 'Access key', 'text', ''), array('secret', 'Secret key', 'password', ''),
            array('cartella', 'Cartella dentro il bucket (facoltativa)', 'text', 'libreria'), array('path_style', 'Indirizzi «path-style» (MinIO e alcuni servizi compatibili)', 'check', ''),
            array('insicuro', 'Accetta certificati fatti in proprio (solo in casa)', 'check', '')),
        'ftp' => array(array('host', 'Server', 'text', 'ftp.esempio.it'), array('porta', 'Porta', 'number', '21'), array('utente', 'Utente', 'text', ''), array('pass', 'Password', 'password', ''),
            array('cartella', 'Cartella', 'text', 'backup/libreria'), array('tls', 'Connessione cifrata (FTPS)', 'check', ''), array('insicuro', 'Accetta certificati fatti in proprio', 'check', '')),
        'sftp' => array(array('host', 'Server', 'text', '192.168.1.10'), array('porta', 'Porta', 'number', '22'), array('utente', 'Utente', 'text', ''), array('pass', 'Password', 'password', ''),
            array('chiave_ssh', 'Oppure chiave privata SSH (al posto della password)', 'textarea', ''), array('passphrase', 'Passphrase della chiave', 'password', ''),
            array('cartella', 'Cartella (senza / iniziale: dentro la home)', 'text', 'backup/libreria'), array('impronta', 'Impronta del server (SHA256:…), consigliata', 'text', '')),
        'webdav' => array(array('url', 'Indirizzo WebDAV della cartella', 'url', 'https://cloud.esempio.it/remote.php/dav/files/UTENTE/Backup'), array('utente', 'Utente', 'text', ''),
            array('pass', 'Password (meglio una «password per app»)', 'password', ''), array('insicuro', 'Accetta certificati fatti in proprio', 'check', '')),
        'cartella' => array(array('percorso', 'Percorso della cartella sul server (anche una condivisione del NAS montata)', 'text', '/mnt/nas/backup-libreria')),
    );
    return isset($c[$tipo]) ? $c[$tipo] : array();
}

function pfb_scheda_storage($plugin)
{
    $tipi = pfb_storage_tipi();
    $sel = array_key_exists((string)get('tipo'), $tipi) ? (string)get('tipo') : 'gdrive';
    $mod = get('modifica') ? pfb_storage($plugin, (string)get('modifica')) : null;
    if ($mod) {
        $sel = $mod['tipo'];
    }
    echo '<nav class="pfb-prov" aria-label="Tipi di storage">';
    foreach ($tipi as $k => $t) {
        echo '<a href="' . h(pfb_url_scheda($plugin, 'storage', array('tipo' => $k))) . '"' . ($k === $sel ? ' class="on"' : '') . '>' . pfb_icona_storage($k) . '<span>' . h($t[0]) . '</span></a>';
    }
    echo '</nav>';
    // modulo
    $oauth = in_array($sel, array('gdrive', 'dropbox', 'onedrive'), true);
    $app_ok = $sel === 'gdrive' ? pfb_app($plugin, 'google_id') !== '' && pfb_app($plugin, 'google_secret') !== '' : ($sel === 'dropbox' ? pfb_app($plugin, 'dropbox_key') !== '' : ($sel === 'onedrive' ? pfb_app($plugin, 'ms_id') !== '' : true));
    echo $plugin->form_start('class="card stack pfb-st-form"') . '<input type="hidden" name="op" value="st_salva"><input type="hidden" name="tipo" value="' . h($sel) . '">'
        . '<input type="hidden" name="id" value="' . h($mod ? $mod['id'] : '') . '"><input type="hidden" name="back" value="' . h(pfb_url_scheda($plugin, 'storage')) . '">';
    echo '<div class="ct">' . pfb_icona_storage($sel) . ' ' . ($mod ? 'Modifica' : 'Aggiungi') . ' ' . h($tipi[$sel][0]) . '</div>';
    if ($oauth) {
        $chi = array('gdrive' => 'Google', 'dropbox' => 'Dropbox', 'onedrive' => 'Microsoft');
        echo '<p class="sub">' . ($sel === 'dropbox' ? 'Dai un nome e salva; poi premi <b>Autenticati con Dropbox</b> nell\'elenco: si apre Dropbox, consenti l\'accesso e copia qui il codice.'
            : 'Dai un nome e salva; poi premi <b>Autenticati</b> nell\'elenco: il sito ti mostra un codice da inserire nella pagina di ' . $chi[$sel] . ', e il collegamento si completa da solo.')
            . ' Il sito vede solo i file che crea lui.</p>';
        if (!$app_ok) {
            echo '<div class="alert warn">Prima, una volta sola, inserisci le chiavi dell\'app ' . $chi[$sel] . ' qui sotto (riquadro «Chiavi delle app»).</div>';
        }
    }
    echo '<label class="lab" for="pfb-alias">Nome (alias) dello storage</label><input class="input" id="pfb-alias" name="nome" maxlength="60" required value="' . h($mod ? $mod['nome'] : '') . '" placeholder="es. Backup della libreria">';
    foreach (pfb_campi_storage($sel) as $c) {
        list($k, $lab, $tipo, $esempio) = $c;
        $segreto = in_array($k, pfb_campi_segreti(), true);
        $val = $mod && !$segreto ? pfb_scfg($mod, $k) : ($mod ? '' : ($tipo === 'number' ? $esempio : ''));
        $ha = $mod && $segreto && isset($mod['cfg'][$k]) && $mod['cfg'][$k] !== '';
        if ($tipo === 'check') {
            echo '<label class="check"><input type="checkbox" name="c_' . h($k) . '" value="1"' . ($mod && pfb_scfg($mod, $k) === '1' ? ' checked' : '') . '> <span>' . h($lab) . '</span></label>';
        } elseif ($tipo === 'textarea') {
            echo '<label class="lab" for="pfb-c-' . h($k) . '">' . h($lab) . '</label><textarea class="input" id="pfb-c-' . h($k) . '" name="c_' . h($k) . '" rows="3" autocomplete="off" spellcheck="false" placeholder="'
                . ($ha ? 'Salvata (cifrata). Scrivine una nuova solo per cambiarla' : '-----BEGIN OPENSSH PRIVATE KEY-----') . '"></textarea>';
        } else {
            echo '<label class="lab" for="pfb-c-' . h($k) . '">' . h($lab) . '</label><input class="input" id="pfb-c-' . h($k) . '" name="c_' . h($k) . '" type="' . ($tipo === 'password' ? 'password' : ($tipo === 'number' ? 'number' : 'text')) . '"'
                . ' value="' . h($val) . '" autocomplete="off" placeholder="' . h($ha ? 'Salvata (cifrata). Scrivine una nuova solo per cambiarla' : $esempio) . '">';
        }
    }
    if ($sel === 's3') {
        echo '<p class="hint">Esempi di indirizzo: Amazon <code>https://s3.eu-south-1.amazonaws.com</code> · DigitalOcean <code>https://fra1.digitaloceanspaces.com</code> · Backblaze <code>https://s3.eu-central-003.backblazeb2.com</code> · Wasabi <code>https://s3.eu-south-1.wasabisys.com</code> · MinIO <code>http://IP:9000</code> (con path-style).</p>';
    }
    echo '<div class="row-btn"><button class="btn primary small" type="submit">' . ($mod ? 'Salva' : 'Aggiungi') . '</button>' . ($mod ? '<a class="btn link small" href="' . h(pfb_url_scheda($plugin, 'storage')) . '">Annulla</a>' : '') . '</div></form>';

    // elenco
    $tutti = pfb_storage_tutti($plugin);
    $att = (string)$plugin->setting('storage_attivo', '');
    echo '<div class="card"><div class="ct">' . admin_icon('cloud', 18) . ' Storage</div><p class="sub">Scegli lo storage in cui salvare i backup (uno solo).</p>';
    if (!$tutti) {
        echo '<p class="sub">Nessuno storage aggiunto.</p>';
    } else {
        echo $plugin->form_start() . '<input type="hidden" name="op" value="st_attivo"><input type="hidden" name="back" value="' . h(pfb_url_scheda($plugin, 'storage')) . '">'
            . '<table class="tbl pfb-tbl"><thead><tr><th>#</th><th class="pfb-cb">Usa</th><th>Storage</th><th>Nome</th><th>Account / collegamento</th><th class="act">Azioni</th></tr></thead><tbody>';
        foreach ($tutti as $i => $s) {
            $oa = in_array($s['tipo'], array('gdrive', 'dropbox', 'onedrive'), true);
            $coll = !$oa || (isset($s['cfg']['refresh_token']) && $s['cfg']['refresh_token'] !== '');
            $lbl = array('gdrive' => 'Autenticati con Google Drive', 'dropbox' => 'Autenticati con Dropbox', 'onedrive' => 'Autenticati con OneDrive');
            echo '<tr><td>' . ($i + 1) . '</td><td class="pfb-cb"><input type="radio" name="attivo" value="' . h($s['id']) . '"' . ($att === $s['id'] ? ' checked' : '') . ($coll ? '' : ' disabled') . ' aria-label="Usa ' . h($s['nome']) . '"></td>'
                . '<td>' . pfb_icona_storage($s['tipo']) . ' ' . h(pfb_storage_tipi()[$s['tipo']][0]) . '</td><td><b>' . h($s['nome']) . '</b></td><td class="pfb-acc">'
                . ($oa ? ($coll ? h(isset($s['cfg']['account']) ? $s['cfg']['account'] : 'collegato') : '<span class="err-text">da autenticare</span>') : h(pfb_scfg($s, 'host') . pfb_scfg($s, 'bucket') . pfb_scfg($s, 'percorso') . preg_replace('#^https?://#', '', pfb_scfg($s, 'url'))))
                . '</td><td class="act"><span class="pfb-act">'
                . ($oa ? '<button class="btn ' . ($coll ? 'link' : 'primary') . ' small" type="button" data-pfb-oauth="' . h($s['id']) . '" data-tipo="' . h($s['tipo']) . '">' . h($coll ? 'Ricollega' : $lbl[$s['tipo']]) . '</button>' : '')
                . ($coll ? '<button class="btn link small" type="button" data-pfb-prova="' . h($s['id']) . '">Prova</button>' : '')
                . '<a class="btn link small" href="' . h(pfb_url_scheda($plugin, 'storage', array('modifica' => $s['id']))) . '" title="Modifica">' . admin_icon('gear', 15) . '</a>'
                . '<button class="btn link small" type="submit" form="pfb-st-del-' . h($s['id']) . '" title="Elimina">' . admin_icon('trash', 15) . '</button></span></td></tr>';
        }
        echo '</tbody></table><button class="btn primary small" type="submit">Salva le modifiche</button></form>';
        foreach ($tutti as $s) {
            echo $plugin->form_start('id="pfb-st-del-' . h($s['id']) . '" hidden data-confirm="Togliere lo storage «' . h($s['nome']) . '»? I backup che ci sono restano lì."')
                . '<input type="hidden" name="op" value="st_elimina"><input type="hidden" name="id" value="' . h($s['id']) . '"><input type="hidden" name="back" value="' . h(pfb_url_scheda($plugin, 'storage')) . '"></form>';
        }
    }
    echo '<div class="alert" data-pfb-st-esito hidden></div></div>';
    pfb_card_app($plugin);
}

// Chiavi delle app di Google, Dropbox e Microsoft (una volta per sito)
function pfb_card_app($plugin)
{
    $g = pfb_app($plugin, 'google_id');
    echo '<details class="card pfb-app"' . (get('app') === '1' ? ' open' : '') . '><summary><b>' . admin_icon('lock', 16) . ' Chiavi delle app (Google Drive, Dropbox, OneDrive) — una volta sola</b></summary>';
    echo $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="app_salva"><input type="hidden" name="back" value="' . h(pfb_url_scheda($plugin, 'storage', array('app' => '1'))) . '">';
    echo '<p class="sub">Per il collegamento «con un clic» il sito si presenta a Google, Dropbox e Microsoft con una sua «app». La crei una volta sola sul loro sito
        (passi qui sotto e nella guida) e ne copi qui le chiavi. Servono solo per gli storage che usi.</p>';
    echo '<div class="pfb-grid">';
    echo '<fieldset><legend>' . pfb_icona_storage('gdrive', 16) . ' Google Drive</legend><label class="lab">ID client</label><input class="input" name="google_id" value="' . h($g) . '" autocomplete="off" placeholder="…apps.googleusercontent.com">'
        . '<label class="lab">Client secret</label><input class="input" type="password" name="google_secret" autocomplete="off" placeholder="' . (pfb_app($plugin, 'google_secret') !== '' ? 'Salvato (cifrato)' : 'GOCSPX-…') . '">'
        . '<details class="pfb-come"><summary>Come si crea</summary><ol><li>console.cloud.google.com → crea un progetto (es. «Libreria PF Backup»).</li><li><b>API e servizi → Libreria</b> → «Google Drive API» → Abilita.</li>'
        . '<li><b>Schermata consenso OAuth</b>: tipo Esterno, nome dell\'app, la tua email; aggiungi te stesso tra gli utenti di test oppure pubblica l\'app (con gli utenti di test il collegamento scade dopo 7 giorni).</li>'
        . '<li><b>Credenziali → Crea credenziali → ID client OAuth</b> → tipo <b>«TV e dispositivi con input limitato»</b>.</li><li>Copia qui ID client e client secret.</li></ol></details></fieldset>';
    echo '<fieldset><legend>' . pfb_icona_storage('dropbox', 16) . ' Dropbox</legend><label class="lab">App key</label><input class="input" name="dropbox_key" value="' . h(pfb_app($plugin, 'dropbox_key')) . '" autocomplete="off">'
        . '<details class="pfb-come"><summary>Come si crea</summary><ol><li>dropbox.com/developers/apps → <b>Create app</b>.</li><li>API: Scoped access · Access: <b>App folder</b> · nome (es. «Libreria PF Backup»).</li>'
        . '<li>Scheda <b>Permissions</b>: spunta files.metadata.read, files.content.write, files.content.read, account_info.read → Submit.</li><li>Copia qui la <b>App key</b> (il secret non serve).</li></ol></details></fieldset>';
    echo '<fieldset><legend>' . pfb_icona_storage('onedrive', 16) . ' Microsoft OneDrive</legend><label class="lab">ID applicazione (client)</label><input class="input" name="ms_id" value="' . h(pfb_app($plugin, 'ms_id')) . '" autocomplete="off" placeholder="00000000-0000-…">'
        . '<details class="pfb-come"><summary>Come si crea</summary><ol><li>portal.azure.com → <b>Registrazioni app</b> → Nuova registrazione.</li><li>Tipi di account: <b>account in qualsiasi directory e account Microsoft personali</b>; nessun URI di reindirizzamento.</li>'
        . '<li><b>Autenticazione</b> → «Consenti flussi client pubblici»: <b>Sì</b> → Salva.</li><li><b>Autorizzazioni API</b> → Microsoft Graph → delegate: Files.ReadWrite.AppFolder.</li><li>Copia qui l\'<b>ID applicazione (client)</b>.</li></ol></details></fieldset>';
    echo '</div><button class="btn primary small" type="submit">Salva le chiavi</button></form></details>';
}

/* ================= Impostazioni ================= */

function pfb_scheda_impostazioni($plugin)
{
    $imp = pfb_imp($plugin);
    $pw = pfb_password($plugin) !== '';
    $back = pfb_url_scheda($plugin, 'impostazioni');
    echo '<div class="pfb-grid2">';
    echo $plugin->form_start('class="card stack"') . '<input type="hidden" name="op" value="impostazioni"><input type="hidden" name="back" value="' . h($back) . '">';
    echo '<div class="ct">' . admin_icon('gear', 18) . ' Impostazioni generali</div>';
    echo '<div class="row-btn"><select class="input pfb-num" name="conserva" aria-label="Backup da tenere sul server">';
    for ($i = 1; $i <= 30; $i++) {
        echo '<option' . ($imp['conserva'] === $i ? ' selected' : '') . '>' . $i . '</option>';
    }
    echo '</select><span>backup da tenere sul server</span></div><div class="row-btn"><select class="input pfb-num" name="conserva_remoto" aria-label="Backup da tenere nello storage">';
    for ($i = 1; $i <= 30; $i++) {
        echo '<option' . ($imp['conserva_remoto'] === $i ? ' selected' : '') . '>' . $i . '</option>';
    }
    echo '</select><span>backup da tenere nello storage remoto</span></div><p class="hint">I backup bloccati non contano e non vengono mai cancellati in automatico. Le copie di sicurezza fatte prima di un ripristino sono a parte (ne restano 3).</p>';
    echo '<label class="check"><input type="checkbox" name="tieni_locale" value="1"' . ($imp['tieni_locale'] ? ' checked' : '') . '> <span>Tieni la copia sul server anche dopo averla inviata allo storage remoto</span></label>';
    echo '<label class="check"><input type="checkbox" name="programmi" value="1"' . ($imp['programmi'] ? ' checked' : '') . '> <span>Includi i programmi del sito nei backup con i file (servono per spostarlo su un server nuovo)</span></label>';
    $ne = !empty($GLOBALS['PLG_OBJ']['notifiche-email']) && empty($GLOBALS['PLG_FAILED']['notifiche-email']);
    echo '<label class="lab" for="pfb-email">Email con l\'esito</label><select class="input" id="pfb-email" name="email"' . ($ne ? '' : ' disabled') . '>';
    foreach (array('no' => 'Nessuna', 'errori' => 'Solo quando qualcosa non va', 'sempre' => 'A ogni backup') as $k => $t) {
        echo '<option value="' . $k . '"' . ($imp['email'] === $k ? ' selected' : '') . '>' . $t . '</option>';
    }
    echo '</select><p class="hint">' . ($ne ? 'Con il plugin «Notifiche email», agli indirizzi impostati lì.' : 'Serve il plugin «Notifiche email» attivo.') . ' Se qualcosa non va, l\'avviso arriva comunque nella campanella degli Admin.</p>';
    echo '<button class="btn primary small" type="submit">Salva</button></form>';

    echo '<div class="stack">';
    echo $plugin->form_start('class="card stack"') . '<input type="hidden" name="op" value="password"><input type="hidden" name="back" value="' . h($back) . '">';
    echo '<div class="ct">' . admin_icon('lock', 18) . ' Password dei backup</div>';
    if (!pfb_cifratura_ok()) {
        echo '<div class="alert warn">Il PHP di questo server non sa cifrare gli ZIP: la password non si può usare.</div>';
    }
    echo '<p class="sub">' . ($pw ? '<span class="ok-text">' . admin_icon('check', 13) . ' I nuovi backup sono cifrati (AES-256).</span>' : 'I backup non sono cifrati.')
        . ' Consigliata se i backup vanno nel cloud: dentro ci sono utenti, impostazioni e la chiave dei segreti del sito.</p>';
    echo '<input class="input" type="password" name="pw1" autocomplete="new-password" minlength="8" placeholder="' . ($pw ? 'Nuova password' : 'Password (almeno 8 caratteri)') . '"' . (pfb_cifratura_ok() ? '' : ' disabled') . '>'
        . '<input class="input" type="password" name="pw2" autocomplete="new-password" placeholder="Ripeti la password"' . (pfb_cifratura_ok() ? '' : ' disabled') . '>'
        . '<p class="hint"><b>Scrivila in un posto sicuro</b> (per esempio il gestore delle password): senza, un backup cifrato non si può aprire, nemmeno da noi. Cambiarla non tocca i backup già fatti.</p>'
        . '<div class="row-btn"><button class="btn primary small" type="submit"' . (pfb_cifratura_ok() ? '' : ' disabled') . '>' . ($pw ? 'Cambia la password' : 'Imposta la password') . '</button>';
    echo '</div></form>';
    if ($pw) {
        echo $plugin->form_start('class="pfb-togli" data-confirm="Togliere la password? I prossimi backup non saranno cifrati."') . '<input type="hidden" name="op" value="password_togli"><input type="hidden" name="back" value="' . h($back) . '"><button class="btn link small" type="submit">Togli la password</button></form>';
    }
    $loc = pfb_locali($plugin);
    $dim = array_sum(array_map(function ($m) { return $m['dimensione']; }, $loc));
    echo '<div class="card"><div class="ct">' . admin_icon('data', 18) . ' Spazio sul server</div>'
        . '<div class="fr row"><span>Backup di PF Backup</span><span>' . count($loc) . ' · ' . h(pfb_mb($dim)) . '</span></div>'
        . '<div class="fr row"><span>Log</span><span>' . h(pfb_mb(pfb_dimensione_dir(pfb_dir($plugin, 'log')))) . '</span></div>'
        . '<div class="fr row"><span>Spazio libero sul disco</span><span>' . h(($f = @disk_free_space(pfb_archivio($plugin))) ? pfb_mb($f) : '—') . '</span></div>'
        . $plugin->form_start('data-confirm="Eliminare tutti i backup non bloccati dal server? Quelli negli storage remoti restano."') . '<input type="hidden" name="op" value="elimina_tutti"><input type="hidden" name="back" value="' . h($back) . '">'
        . '<button class="btn danger-ghost small" type="submit">Elimina dal server tutti i backup non bloccati</button></form></div>';
    echo '</div></div>';
}

/* ================= Log ================= */

function pfb_scheda_log($plugin)
{
    $dir = pfb_dir($plugin, 'log');
    $vedi = basename((string)get('vedi'));
    if ($vedi !== '' && preg_match('/^[0-9_a-z]+\.log$/', $vedi) && is_file($dir . '/' . $vedi)) {
        echo '<div class="card"><div class="ct">' . admin_icon('log', 18) . ' ' . h($vedi) . '</div><pre class="pfb-log">' . h((string)file_get_contents($dir . '/' . $vedi)) . '</pre>'
            . '<a class="btn link small" href="' . h(pfb_url_scheda($plugin, 'log')) . '">← Tutti i log</a></div>';
        return;
    }
    $f = (array)glob($dir . '/*.log');
    rsort($f);
    echo '<div class="card"><div class="ct">' . admin_icon('log', 18) . ' Log delle operazioni</div>';
    if (!$f) {
        echo '<p class="sub">Nessuna operazione, per ora.</p></div>';
        return;
    }
    $tipi = array('backup' => 'Backup', 'ripristino' => 'Ripristino', 'invio' => 'Invio allo storage', 'scaricamento' => 'Scaricamento dallo storage');
    echo '<table class="tbl pfb-tbl"><thead><tr><th>Data</th><th>Operazione</th><th>Esito</th><th class="act"></th></tr></thead><tbody>';
    foreach (array_slice($f, 0, 100) as $p) {
        $n = basename($p);
        $righe = file($p, FILE_IGNORE_NEW_LINES);
        $prima = $righe ? preg_replace('/^\S+ \S+\s+== /', '', $righe[0]) : '';
        $ultima = $righe ? end($righe) : '';
        $ok = strpos($ultima, '== Fatto') !== false;
        $ko = strpos($ultima, 'Non riuscito') !== false;
        preg_match('/^(\d{8})_(\d{6})_[a-f0-9]+_([a-z]+)\.log$/', $n, $m);
        $data = $m ? DateTime::createFromFormat('Ymd His', $m[1] . ' ' . $m[2]) : null;
        echo '<tr><td>' . ($data ? h($data->format('d/m/Y H:i')) : '') . '</td><td>' . h($m && isset($tipi[$m[3]]) ? $tipi[$m[3]] : '') . '<br><small class="muted">' . h(str_cut(preg_replace('/ \(Libreria di Casa.*$/', '', $prima), 90)) . '</small></td>'
            . '<td>' . ($ok ? '<span class="ok-text">riuscito</span>' : ($ko ? '<span class="err-text">non riuscito</span>' : '<span class="muted">in corso o interrotto</span>')) . '</td>'
            . '<td class="act"><a class="link" href="' . h(pfb_url_scheda($plugin, 'log', array('vedi' => $n))) . '">Apri</a></td></tr>';
    }
    echo '</tbody></table></div>';
}

/* ================= Finestre (avanzamento, ripristino, collegamento) ================= */

function pfb_finestre($plugin)
{
    return '<div class="pfb-modal" data-pfb-rip hidden><div class="pfb-box" role="dialog" aria-modal="true" aria-labelledby="pfb-rip-t">'
        . '<h3 id="pfb-rip-t">' . admin_icon('warn', 18) . ' Ripristinare il sito?</h3><p class="sub">Il sito tornerà <b>esattamente com\'era</b> nel backup <b data-pfb-rip-nome></b>: libri, utenti e password, aspetto, plugin, messaggi. '
        . 'Quello che è stato fatto dopo andrà perso. Prima viene fatta da sola una copia di sicurezza dello stato attuale; durante il ripristino gli altri vedono «Torniamo subito». Alla fine si rientra con gli utenti del backup.</p>'
        . '<div data-pfb-rip-pwb hidden><label class="lab" for="pfb-rip-pwb">Password del backup</label><input class="input" id="pfb-rip-pwb" type="password" autocomplete="off" data-pfb-rip-pwbi></div>'
        . '<label class="lab" for="pfb-rip-pwa">La tua password (per conferma)</label><input class="input" id="pfb-rip-pwa" type="password" autocomplete="current-password" data-pfb-rip-pwa>'
        . '<label class="check"><input type="checkbox" data-pfb-rip-ok> <span>Ho capito: il sito torna alla data del backup</span></label>'
        . '<div class="alert error" data-pfb-rip-err hidden></div><div class="row-btn"><button class="btn danger-ghost small" type="button" data-pfb-rip-vai disabled>Ripristina</button>'
        . '<button class="btn link small" type="button" data-pfb-chiudi>Annulla</button></div></div></div>'
        . '<div class="pfb-modal" data-pfb-oa hidden><div class="pfb-box" role="dialog" aria-modal="true" aria-labelledby="pfb-oa-t"><h3 id="pfb-oa-t" data-pfb-oa-titolo>Collegamento</h3>'
        . '<div data-pfb-oa-codice hidden><p class="sub">1. Apri <a class="link" target="_blank" rel="noopener" data-pfb-oa-url href="#"></a> (anche dal telefono) ed entra con il tuo account.<br>2. Inserisci questo codice:</p>'
        . '<p class="pfb-codice" data-pfb-oa-cod></p><p class="hint" data-pfb-oa-attesa>In attesa della conferma… la finestra si aggiorna da sola.</p></div>'
        . '<div data-pfb-oa-dropbox hidden><p class="sub">1. <a class="btn ghost small" target="_blank" rel="noopener" data-pfb-oa-durl href="#">Apri Dropbox</a> e premi <b>Consenti</b>.<br>2. Copia il codice che Dropbox ti mostra e incollalo qui:</p>'
        . '<div class="row-btn"><input class="input" data-pfb-oa-dcod autocomplete="off" placeholder="codice di Dropbox"><button class="btn primary small" type="button" data-pfb-oa-dvai>Collega</button></div></div>'
        . '<div class="alert" data-pfb-oa-msg hidden></div><div class="row-btn"><button class="btn link small" type="button" data-pfb-chiudi>Chiudi</button></div></div></div>';
}

/* ================= Salvataggi del pannello ================= */

function pfb_salva($plugin)
{
    switch (post('op')) {
        case 'pianifica':
            $p = array('on' => post('on') === '1' ? 1 : 0, 'freq' => array_key_exists(post('freq'), pfb_freq()) ? post('freq') : 'giorno',
                'ora' => preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', post('ora')) ? post('ora') : '02:30', 'giorno_sett' => max(1, min(7, (int)post('giorno_sett'))),
                'giorno_mese' => max(1, min(28, (int)post('giorno_mese'))), 'contenuto' => in_array(post('contenuto'), array('completo', 'db', 'file'), true) ? post('contenuto') : 'completo',
                'dove' => post('dove') === 'remoto' && pfb_storage_attivo($plugin) ? 'remoto' : 'locale');
            $plugin->save_setting('pianificazione', json_encode($p));
            $plugin->save_setting('pian_da', (string)time());
            $pr = pfb_pian_prossimo($plugin);
            flash($p['on'] ? 'Pianificazione salvata: prossimo backup il ' . date('d/m/Y \a\l\l\e H:i', $pr) . '.' : 'Pianificazione spenta.');
            return;
        case 'impostazioni':
            $plugin->save_setting('conserva', (string)max(1, min(30, (int)post('conserva'))));
            $plugin->save_setting('conserva_remoto', (string)max(1, min(30, (int)post('conserva_remoto'))));
            $plugin->save_setting('tieni_locale', post('tieni_locale') === '1' ? '1' : '0');
            $plugin->save_setting('programmi', post('programmi') === '1' ? '1' : '0');
            if (in_array(post('email'), array('no', 'errori', 'sempre'), true)) {
                $plugin->save_setting('email', post('email'));
            }
            flash('Impostazioni salvate.');
            return;
        case 'password':
            $a = (string)(isset($_POST['pw1']) ? $_POST['pw1'] : '');
            if (strlen($a) < 8 || $a !== (string)(isset($_POST['pw2']) ? $_POST['pw2'] : '')) {
                flash(strlen($a) < 8 ? 'La password deve avere almeno 8 caratteri.' : 'Le due password non sono uguali.', 'error');
                return;
            }
            if (!pfb_cifratura_ok()) {
                flash('Il PHP di questo server non sa cifrare gli ZIP.', 'error');
                return;
            }
            $plugin->save_setting('password', sec_encrypt($a, 'plg-pf-backup-pw'));
            app_log('pf_backup_password', 'Password dei backup di PF Backup impostata o cambiata', 'warn');
            flash('Password salvata: i prossimi backup saranno cifrati. Conservala in un posto sicuro.');
            return;
        case 'password_togli':
            $plugin->save_setting('password', '');
            app_log('pf_backup_password', 'Password dei backup di PF Backup tolta', 'warn');
            flash('Password tolta: i prossimi backup non saranno cifrati.');
            return;
        case 'blocca':
        case 'sblocca':
            if (pfb_nome_ok(post('nome'))) {
                pfb_blocca($plugin, post('nome'), post('op') === 'blocca');
                flash(post('op') === 'blocca' ? 'Backup bloccato: si cancella solo a mano.' : 'Backup sbloccato.');
            }
            return;
        case 'elimina':
            $n = 0;
            foreach (isset($_POST['sel']) ? (array)$_POST['sel'] : array() as $nome) {
                if (pfb_nome_ok($nome) && !in_array($nome, pfb_bloccati($plugin), true)) {
                    pfb_elimina_locale($plugin, $nome);
                    $n++;
                }
            }
            flash($n === 1 ? 'Backup eliminato dal server.' : $n . ' backup eliminati dal server.');
            return;
        case 'elimina_tutti':
            $n = 0;
            foreach (pfb_locali($plugin) as $nome => $m) {
                if (!in_array($nome, pfb_bloccati($plugin), true) && empty($m['bloccato'])) {
                    pfb_elimina_locale($plugin, $nome);
                    $n++;
                }
            }
            flash($n . ' backup eliminati dal server.');
            return;
        case 'st_salva':
            pfb_salva_storage($plugin);
            return;
        case 'st_attivo':
            $id = (string)post('attivo');
            $s = pfb_storage($plugin, $id);
            $plugin->save_setting('storage_attivo', $s ? $id : '');
            flash($s ? 'I backup andranno su ' . pfb_storage_nome($s) . '.' : 'Nessuno storage scelto.');
            return;
        case 'st_elimina':
            pfb_storage_togli($plugin, (string)post('id'));
            flash('Storage tolto.');
            return;
        case 'app_salva':
            $a = pfb_json_setting($plugin, 'app', array());
            $a['google_id'] = str_cut(trim(post('google_id')), 200);
            if (trim(post('google_secret')) !== '') {
                $a['google_secret'] = sec_encrypt(trim(post('google_secret')), 'plg-pf-backup-app');
            }
            $a['dropbox_key'] = str_cut(trim(post('dropbox_key')), 100);
            $a['ms_id'] = str_cut(trim(post('ms_id')), 100);
            $plugin->save_setting('app', json_encode($a));
            flash('Chiavi delle app salvate.');
            return;
    }
}

function pfb_salva_storage($plugin)
{
    $tipo = (string)post('tipo');
    if (!array_key_exists($tipo, pfb_storage_tipi())) {
        return;
    }
    $id = (string)post('id');
    $s = $id !== '' ? pfb_storage($plugin, $id) : null;
    if (!$s) {
        $s = array('id' => substr(bin2hex(random_bytes(6)), 0, 10), 'tipo' => $tipo, 'nome' => '', 'cfg' => array(), 'creato' => date('c'));
    }
    $s['nome'] = str_cut(trim(post('nome')), 60);
    foreach (pfb_campi_storage($tipo) as $c) {
        $k = $c[0];
        $v = isset($_POST['c_' . $k]) ? trim((string)$_POST['c_' . $k]) : '';
        if ($c[2] === 'check') {
            $s['cfg'][$k] = $v === '1' ? '1' : '0';
        } elseif (in_array($k, pfb_campi_segreti(), true)) {
            if ($v !== '') {
                pfb_scfg_set($s, $k, $k === 'chiave_ssh' ? str_replace("\r\n", "\n", (string)$_POST['c_' . $k]) : $v);
            }
        } else {
            $s['cfg'][$k] = str_cut($v, 500);
        }
    }
    pfb_storage_salva($plugin, $s);
    if ((string)$plugin->setting('storage_attivo', '') === '' && !in_array($tipo, array('gdrive', 'dropbox', 'onedrive'), true)) {
        $plugin->save_setting('storage_attivo', $s['id']);
    }
    $oa = in_array($tipo, array('gdrive', 'dropbox', 'onedrive'), true);
    flash($oa && (!isset($s['cfg']['refresh_token']) || $s['cfg']['refresh_token'] === '') ? 'Storage salvato: ora premi «Autenticati» nell\'elenco.' : 'Storage salvato: premi «Prova» per controllarlo.');
}

/* ================= Scaricare e caricare file ================= */

function pfb_scarica_file($plugin)
{
    $n = basename((string)get('f'));
    $p = pfb_archivio($plugin) . '/' . $n;
    if (!pfb_nome_ok($n) || !is_file($p)) {
        header('HTTP/1.1 404 Not Found');
        echo 'Backup non trovato.';
        return;
    }
    session_write_close();
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (function_exists('set_time_limit')) {
        @set_time_limit(0);
    }
    header('Content-Type: application/zip');
    header('Content-Length: ' . filesize($p));
    header('Content-Disposition: attachment; filename="' . $n . '"');
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    $fh = fopen($p, 'rb');
    while (!feof($fh)) {
        echo fread($fh, 1048576);
        @flush();
    }
    fclose($fh);
}

// Un pezzo del caricamento: token, offset, totale, nome originale; l'ultimo pezzo controlla il backup e lo mette nell'archivio
function pfb_carica_pezzo($plugin)
{
    $tok = preg_replace('/[^a-f0-9]/', '', (string)post('token'));
    $off = (int)post('offset');
    $tot = (int)post('totale');
    if (strlen($tok) !== 32 || $tot <= 0 || $off < 0 || !isset($_FILES['pezzo']) || $_FILES['pezzo']['error'] !== UPLOAD_ERR_OK) {
        return array('ok' => false, 'error' => 'Pezzo del caricamento non valido (il server limita la dimensione: riprova).');
    }
    $libero = @disk_free_space(pfb_archivio($plugin));
    if ($off === 0 && $libero !== false && $libero < $tot * 1.2) {
        return array('ok' => false, 'error' => 'Spazio insufficiente sul server per questo file (' . pfb_mb($tot) . ').');
    }
    $part = pfb_dir($plugin, 'caricamenti') . '/' . $tok . '.part';
    $ora = is_file($part) ? filesize($part) : 0;
    if ($off !== $ora) {
        return array('ok' => false, 'error' => 'Il caricamento si è interrotto: ricomincia.', 'riprendi' => $ora);
    }
    $in = fopen($_FILES['pezzo']['tmp_name'], 'rb');
    $out = fopen($part, 'ab');
    stream_copy_to_stream($in, $out);
    fclose($in);
    fclose($out);
    clearstatcache();
    $ora = filesize($part);
    if ($ora < $tot) {
        return array('ricevuti' => $ora);
    }
    // finito: e' un backup di PF Backup?
    try {
        $z = new ZipArchive();
        if ($z->open($part) !== true || $z->statName('manifest.json') === false) {
            throw new Exception('Il file non è un backup di PF Backup.');
        }
        $man = $z->getFromName('manifest.json');
        $z->close();
        $m = $man !== false ? json_decode($man, true) : null;
        $orig = basename((string)post('nome'));
        $nome = pfb_nome_ok($orig) ? $orig : pfb_nuovo_nome(is_array($m) && isset($m['contenuto']) ? $m['contenuto'] : 'completo', 'caricato');
        if (is_file(pfb_archivio($plugin) . '/' . $nome)) {
            $nome = pfb_nuovo_nome(is_array($m) && isset($m['contenuto']) ? $m['contenuto'] : 'completo', 'caricato');
        }
        rename($part, pfb_archivio($plugin) . '/' . $nome);
        pfb_meta_salva($plugin, $nome, array('creato' => is_array($m) && !empty($m['creato']) ? $m['creato'] : date('c'), 'origine' => 'caricato',
            'contenuto' => is_array($m) ? (string)$m['contenuto'] : (preg_match('/_(completo|db|file)[_.]/', $nome, $x) ? $x[1] : ''), 'app_version' => is_array($m) ? (string)$m['app_version'] : '', 'cifrato' => $m === null ? 1 : (int)$m['cifrato'],
            'programmi' => is_array($m) ? (int)$m['programmi'] : 0, 'remoto' => array(), 'bloccato' => 0, 'sito' => is_array($m) ? (string)$m['sito'] : ''));
        $plugin->log('Backup caricato: ' . $nome);
        return array('fatto' => true, 'nome' => $nome);
    } catch (Exception $e) {
        @unlink($part);
        return array('ok' => false, 'error' => $e->getMessage());
    }
}
