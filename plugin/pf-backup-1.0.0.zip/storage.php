<?php
/*
 * PF Backup — storage remoti. Prefisso: pfb_
 * Ogni tipo offre: prova, put($percorso, $nome), lista() -> nome => [nome, dimensione, data], prendi($nome, $dest), elimina($nome).
 * Google Drive e OneDrive si collegano con un codice da inserire sul sito di Google/Microsoft; Dropbox con un codice da copiare.
 * Le chiavi delle "app" (Google, Dropbox, Microsoft) si inseriscono una volta per sito, nella scheda Storage remoto.
 * Password, token e chiavi sono salvati cifrati.
 */

function pfb_storage_tipi()
{
    return array(
        'gdrive' => array('Google Drive', 'gdrive'),
        'dropbox' => array('Dropbox', 'dropbox'),
        'onedrive' => array('Microsoft OneDrive', 'onedrive'),
        's3' => array('Amazon S3 e compatibili', 's3'),
        'ftp' => array('FTP', 'ftp'),
        'sftp' => array('SFTP', 'sftp'),
        'webdav' => array('Nextcloud / WebDAV', 'webdav'),
        'cartella' => array('Cartella o NAS', 'cartella'),
    );
}

// Campi che si salvano cifrati
function pfb_campi_segreti()
{
    return array('pass', 'secret', 'refresh_token', 'chiave_ssh', 'passphrase');
}

// Indirizzi dei servizi (per le prove si possono cambiare con variabili d'ambiente)
function pfb_url($k)
{
    $m = array(
        'g_oauth' => array('LIBRERIA_TEST_PFB_G_OAUTH', 'https://oauth2.googleapis.com'),
        'g_api' => array('LIBRERIA_TEST_PFB_G_API', 'https://www.googleapis.com'),
        'd_www' => array('LIBRERIA_TEST_PFB_D_WWW', 'https://www.dropbox.com'),
        'd_api' => array('LIBRERIA_TEST_PFB_D_API', 'https://api.dropboxapi.com'),
        'd_content' => array('LIBRERIA_TEST_PFB_D_CONTENT', 'https://content.dropboxapi.com'),
        'ms_login' => array('LIBRERIA_TEST_PFB_MS_LOGIN', 'https://login.microsoftonline.com'),
        'ms_graph' => array('LIBRERIA_TEST_PFB_MS_GRAPH', 'https://graph.microsoft.com'),
    );
    $e = getenv($m[$k][0]);
    return $e ? rtrim($e, '/') : $m[$k][1];
}

/* ---------------- Archivio degli storage ---------------- */

function pfb_storage_tutti($plugin)
{
    $l = json_decode((string)$plugin->setting('storage', '[]'), true);
    return is_array($l) ? $l : array();
}

function pfb_storage($plugin, $id)
{
    foreach (pfb_storage_tutti($plugin) as $s) {
        if ($s['id'] === $id) {
            return $s;
        }
    }
    return null;
}

function pfb_storage_salva($plugin, $s)
{
    $l = pfb_storage_tutti($plugin);
    $trovato = false;
    foreach ($l as $k => $x) {
        if ($x['id'] === $s['id']) {
            $l[$k] = $s;
            $trovato = true;
        }
    }
    if (!$trovato) {
        $l[] = $s;
    }
    $plugin->save_setting('storage', json_encode(array_values($l), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function pfb_storage_togli($plugin, $id)
{
    $l = array_values(array_filter(pfb_storage_tutti($plugin), function ($x) use ($id) { return $x['id'] !== $id; }));
    $plugin->save_setting('storage', json_encode($l, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    if ($plugin->setting('storage_attivo', '') === $id) {
        $plugin->save_setting('storage_attivo', '');
    }
}

function pfb_storage_attivo($plugin)
{
    $id = (string)$plugin->setting('storage_attivo', '');
    return $id !== '' ? pfb_storage($plugin, $id) : null;
}

function pfb_storage_nome($s)
{
    $t = pfb_storage_tipi();
    return (isset($t[$s['tipo']]) ? $t[$s['tipo']][0] : $s['tipo']) . ((string)$s['nome'] !== '' ? ' «' . $s['nome'] . '»' : '');
}

function pfb_scfg($s, $k)
{
    $v = isset($s['cfg'][$k]) ? $s['cfg'][$k] : '';
    if ($v !== '' && is_string($v) && in_array($k, pfb_campi_segreti(), true)) {
        require_once APP_ROOT . '/inc/crypto.php';
        return (string)sec_decrypt($v, 'plg-pf-backup-st');
    }
    return is_scalar($v) ? (string)$v : '';
}

function pfb_scfg_set(&$s, $k, $v)
{
    if (in_array($k, pfb_campi_segreti(), true) && $v !== '') {
        require_once APP_ROOT . '/inc/crypto.php';
        $v = sec_encrypt($v, 'plg-pf-backup-st');
    }
    $s['cfg'][$k] = $v;
}

// Chiavi delle app (Google: client_id + secret; Dropbox: app_key; Microsoft: client_id)
function pfb_app($plugin, $k)
{
    $a = pfb_json_setting($plugin, 'app', array());
    $v = isset($a[$k]) ? (string)$a[$k] : '';
    if ($v !== '' && $k === 'google_secret') {
        require_once APP_ROOT . '/inc/crypto.php';
        return (string)sec_decrypt($v, 'plg-pf-backup-app');
    }
    return $v;
}

function pfb_storage_call($plugin, $s, $op)
{
    $args = array_slice(func_get_args(), 3);
    $fn = 'pfb_' . $s['tipo'] . '_' . $op;
    if (!function_exists($fn)) {
        throw new Exception('Operazione non disponibile per questo storage.');
    }
    array_unshift($args, $plugin, $s);
    try {
        return call_user_func_array($fn, $args);
    } finally {
        foreach (isset($GLOBALS['PFB_TMP']) ? $GLOBALS['PFB_TMP'] : array() as $f) {
            @unlink($f);
        }
        $GLOBALS['PFB_TMP'] = array();
    }
}

// Data di un backup dal suo nome (pfb_AAAAMMGG_HHMMSS_...)
function pfb_data_da_nome($n)
{
    return preg_match('/^pfb_(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})_/', $n, $m) ? mktime((int)$m[4], (int)$m[5], (int)$m[6], (int)$m[2], (int)$m[3], (int)$m[1]) : 0;
}

function pfb_voce($nome, $dim, $extra = array())
{
    return array('nome' => $nome, 'dimensione' => (int)$dim, 'data' => pfb_data_da_nome($nome)) + $extra;
}

/* ---------------- curl ---------------- */

/*
 * $o: opzioni curl. $o['_file'] = percorso dove scrivere la risposta (download).
 * Se $GLOBALS['PFB_PROGRESSO'] e' una funzione, riceve (fatti, totale) durante invii e scaricamenti.
 */
function pfb_curl($url, $o = array(), $esterno = true)
{
    if (!function_exists('curl_init')) {
        throw new Exception('L\'estensione curl di PHP non è attiva.');
    }
    $ch = curl_init($url);
    $fh = null;
    if (isset($o['_file'])) {
        $fh = fopen($o['_file'], 'wb');
        if (!$fh) {
            throw new Exception('Non riesco a scrivere il file scaricato.');
        }
        unset($o['_file']);
        $o[CURLOPT_FILE] = $fh;
    } else {
        $o += array(CURLOPT_RETURNTRANSFER => true);
    }
    $base = array(CURLOPT_CONNECTTIMEOUT => 25, CURLOPT_TIMEOUT => 0, CURLOPT_USERAGENT => 'LibreriaDiCasa-PFBackup/' . APP_VERSION,
        CURLOPT_LOW_SPEED_LIMIT => 1, CURLOPT_LOW_SPEED_TIME => 120);
    if (defined('CA_BUNDLE') && is_file(CA_BUNDLE)) {
        $base[CURLOPT_CAINFO] = CA_BUNDLE;
    }
    if ($esterno && defined('HTTP_PROXY_URL') && HTTP_PROXY_URL !== '') {
        $base[CURLOPT_PROXY] = HTTP_PROXY_URL;
    }
    if (!empty($GLOBALS['PFB_PROGRESSO']) && defined('CURLOPT_XFERINFOFUNCTION')) {
        $cb = $GLOBALS['PFB_PROGRESSO'];
        $ult = 0;
        $base[CURLOPT_NOPROGRESS] = false;
        $base[CURLOPT_XFERINFOFUNCTION] = function ($c, $dt, $dn, $ut, $un) use ($cb, &$ult) {
            if (time() - $ult >= 1) {
                $ult = time();
                $ut > 0 ? $cb($un, $ut) : ($dt > 0 ? $cb($dn, $dt) : null);
            }
            return 0;
        };
    }
    curl_setopt_array($ch, $base);
    curl_setopt_array($ch, $o);
    $body = curl_exec($ch);
    $r = array('code' => (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE), 'body' => is_string($body) ? $body : '', 'error' => curl_errno($ch) ? curl_error($ch) : '',
        'errno' => curl_errno($ch));
    if (PHP_VERSION_ID < 80000) {
        curl_close($ch);
    }
    if ($fh) {
        fclose($fh);
    }
    return $r;
}

function pfb_curl_ha($proto)
{
    $v = function_exists('curl_version') ? curl_version() : array('protocols' => array());
    return in_array($proto, $v['protocols'], true);
}

function pfb_errore($r, $cosa)
{
    if ($r['error'] !== '') {
        throw new Exception($cosa . ': ' . $r['error']);
    }
    $msg = trim(strip_tags($r['body']));
    $j = json_decode($r['body'], true);
    if (is_array($j)) {
        foreach (array(array('error_description'), array('error', 'message'), array('error_summary'), array('error')) as $p) {
            $v = $j;
            foreach ($p as $k) {
                $v = is_array($v) && isset($v[$k]) ? $v[$k] : null;
            }
            if (is_string($v) && $v !== '') {
                $msg = $v;
                break;
            }
        }
    } elseif (preg_match('#<Message>([^<]+)</Message>#', $r['body'], $m)) {
        $msg = $m[1];
    }
    throw new Exception($cosa . ' (risposta ' . $r['code'] . ($msg !== '' ? ': ' . str_cut($msg, 220) : '') . ')');
}

function pfb_ok($r)
{
    return $r['errno'] === 0 && $r['code'] >= 200 && $r['code'] < 300;
}

/* ================= Google Drive ================= */

function pfb_gdrive_avvia($plugin, $s)
{
    if (pfb_app($plugin, 'google_id') === '' || pfb_app($plugin, 'google_secret') === '') {
        throw new Exception('Inserisci prima le chiavi dell\'app Google (in fondo a questa scheda).');
    }
    $r = pfb_curl(pfb_url('g_oauth') . '/device/code', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => pfb_app($plugin, 'google_id'), 'scope' => 'https://www.googleapis.com/auth/drive.file'))));
    $j = json_decode($r['body'], true);
    if (!isset($j['device_code'])) {
        pfb_errore($r, 'Google non ha accettato la richiesta (l\'app deve essere di tipo «TV e dispositivi con input limitato»)');
    }
    $s['cfg']['attesa'] = array('device_code' => $j['device_code'], 'codice' => $j['user_code'],
        'url' => isset($j['verification_url']) ? $j['verification_url'] : 'https://www.google.com/device', 'scade' => time() + (int)$j['expires_in'],
        'intervallo' => isset($j['interval']) ? (int)$j['interval'] : 5);
    pfb_storage_salva($plugin, $s);
    return $s['cfg']['attesa'];
}

// Restituisce true quando collegato, false se Google aspetta ancora la conferma
function pfb_gdrive_verifica($plugin, $s)
{
    $a = isset($s['cfg']['attesa']) ? $s['cfg']['attesa'] : null;
    if (!$a || $a['scade'] < time()) {
        throw new Exception('Il codice è scaduto: premi di nuovo «Autenticati con Google Drive».');
    }
    $r = pfb_curl(pfb_url('g_oauth') . '/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => pfb_app($plugin, 'google_id'), 'client_secret' => pfb_app($plugin, 'google_secret'), 'device_code' => $a['device_code'],
        'grant_type' => 'urn:ietf:params:oauth:grant-type:device_code'))));
    $j = json_decode($r['body'], true);
    if (isset($j['error']) && in_array($j['error'], array('authorization_pending', 'slow_down'), true)) {
        return false;
    }
    if (!isset($j['refresh_token'])) {
        pfb_errore($r, 'Collegamento a Google non riuscito');
    }
    unset($s['cfg']['attesa'], $s['cfg']['cartella_id']);
    pfb_scfg_set($s, 'refresh_token', $j['refresh_token']);
    $ab = pfb_curl(pfb_url('g_api') . '/drive/v3/about?fields=user(emailAddress)', array(CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $j['access_token'])));
    $u = json_decode($ab['body'], true);
    $s['cfg']['account'] = isset($u['user']['emailAddress']) ? $u['user']['emailAddress'] : 'account Google';
    pfb_storage_salva($plugin, $s);
    return true;
}

function pfb_gdrive_token($plugin, $s)
{
    $rt = pfb_scfg($s, 'refresh_token');
    if ($rt === '') {
        throw new Exception('Google Drive non è ancora autenticato.');
    }
    $r = pfb_curl(pfb_url('g_oauth') . '/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => pfb_app($plugin, 'google_id'), 'client_secret' => pfb_app($plugin, 'google_secret'), 'refresh_token' => $rt, 'grant_type' => 'refresh_token'))));
    $j = json_decode($r['body'], true);
    if (!isset($j['access_token'])) {
        pfb_errore($r, 'Accesso a Google Drive non riuscito (prova ad autenticarti di nuovo)');
    }
    return $j['access_token'];
}

function pfb_gdrive_cartella($plugin, &$s, $tok)
{
    $h = array('Authorization: Bearer ' . $tok);
    $ora = pfb_storage($plugin, $s['id']); // la cartella puo' essere stata creata poco fa, nello stesso lavoro
    if ($ora && !empty($ora['cfg']['cartella_id'])) {
        $s['cfg']['cartella_id'] = $ora['cfg']['cartella_id'];
    }
    $fid = isset($s['cfg']['cartella_id']) ? (string)$s['cfg']['cartella_id'] : '';
    if ($fid !== '') {
        $r = pfb_curl(pfb_url('g_api') . '/drive/v3/files/' . rawurlencode($fid) . '?fields=id,trashed', array(CURLOPT_HTTPHEADER => $h));
        $j = json_decode($r['body'], true);
        if ($r['code'] === 200 && empty($j['trashed'])) {
            return $fid;
        }
    }
    $nome = pfb_scfg($s, 'cartella') !== '' ? pfb_scfg($s, 'cartella') : 'PF Backup';
    $r = pfb_curl(pfb_url('g_api') . '/drive/v3/files', array(CURLOPT_POST => true, CURLOPT_HTTPHEADER => array_merge($h, array('Content-Type: application/json')),
        CURLOPT_POSTFIELDS => json_encode(array('name' => $nome, 'mimeType' => 'application/vnd.google-apps.folder'))));
    $j = json_decode($r['body'], true);
    if (!isset($j['id'])) {
        pfb_errore($r, 'Creazione della cartella su Google Drive non riuscita');
    }
    $s['cfg']['cartella_id'] = $j['id'];
    $salva = $ora ? $ora : $s; // si salva sopra la versione piu' recente dello storage
    $salva['cfg']['cartella_id'] = $j['id'];
    pfb_storage_salva($plugin, $salva);
    return $j['id'];
}

function pfb_gdrive_elenco($plugin, &$s)
{
    $tok = pfb_gdrive_token($plugin, $s);
    $cart = pfb_gdrive_cartella($plugin, $s, $tok);
    $q = "'" . str_replace("'", "\\'", $cart) . "' in parents and trashed = false";
    $out = array();
    $pt = '';
    do {
        $r = pfb_curl(pfb_url('g_api') . '/drive/v3/files?pageSize=200&fields=nextPageToken,files(id,name,size)&q=' . rawurlencode($q) . ($pt !== '' ? '&pageToken=' . rawurlencode($pt) : ''),
            array(CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok)));
        $j = json_decode($r['body'], true);
        if ($r['code'] !== 200 || !isset($j['files'])) {
            pfb_errore($r, 'Elenco dei file su Google Drive non riuscito');
        }
        foreach ($j['files'] as $f) {
            if (pfb_nome_ok($f['name'])) {
                $out[$f['name']] = pfb_voce($f['name'], isset($f['size']) ? $f['size'] : 0, array('id' => $f['id']));
            }
        }
        $pt = isset($j['nextPageToken']) ? $j['nextPageToken'] : '';
    } while ($pt !== '');
    return array($tok, $out);
}

function pfb_gdrive_prova($plugin, $s)
{
    $l = pfb_gdrive_elenco($plugin, $s);
    return 'Collegato a Google Drive (' . (isset($s['cfg']['account']) ? $s['cfg']['account'] : 'account') . '): ' . count($l[1]) . ' backup nella cartella.';
}

function pfb_gdrive_put($plugin, $s, $path, $nome)
{
    $tok = pfb_gdrive_token($plugin, $s);
    $cart = pfb_gdrive_cartella($plugin, $s, $tok);
    $size = filesize($path);
    $r = pfb_curl(pfb_url('g_api') . '/upload/drive/v3/files?uploadType=resumable', array(CURLOPT_POST => true, CURLOPT_HEADER => true,
        CURLOPT_POSTFIELDS => json_encode(array('name' => $nome, 'parents' => array($cart))),
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: application/json; charset=UTF-8', 'X-Upload-Content-Type: application/zip',
            'X-Upload-Content-Length: ' . $size)));
    if ($r['code'] !== 200 || !preg_match('/^location:\s*(\S+)/mi', $r['body'], $m)) {
        pfb_errore($r, 'Avvio dell\'invio a Google Drive non riuscito');
    }
    $fh = fopen($path, 'rb');
    $r = pfb_curl(trim($m[1]), array(CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => $size,
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: application/zip')));
    fclose($fh);
    if ($r['code'] !== 200 && $r['code'] !== 201) {
        pfb_errore($r, 'Invio a Google Drive non riuscito');
    }
}

function pfb_gdrive_lista($plugin, $s)
{
    $l = pfb_gdrive_elenco($plugin, $s);
    return $l[1];
}

function pfb_gdrive_prendi($plugin, $s, $nome, $dest)
{
    $l = pfb_gdrive_elenco($plugin, $s);
    if (!isset($l[1][$nome])) {
        throw new Exception('Il backup non è (più) su Google Drive.');
    }
    $r = pfb_curl(pfb_url('g_api') . '/drive/v3/files/' . rawurlencode($l[1][$nome]['id']) . '?alt=media', array('_file' => $dest, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $l[0])));
    if (!pfb_ok($r)) {
        @unlink($dest);
        pfb_errore($r, 'Scaricamento da Google Drive non riuscito');
    }
}

function pfb_gdrive_elimina($plugin, $s, $nome)
{
    $l = pfb_gdrive_elenco($plugin, $s);
    if (isset($l[1][$nome])) {
        $r = pfb_curl(pfb_url('g_api') . '/drive/v3/files/' . rawurlencode($l[1][$nome]['id']), array(CURLOPT_CUSTOMREQUEST => 'DELETE',
            CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $l[0])));
        if (!in_array($r['code'], array(200, 204, 404), true)) {
            pfb_errore($r, 'Eliminazione da Google Drive non riuscita');
        }
    }
}

/* ================= Dropbox (codice da copiare, con PKCE: basta la "App key") ================= */

function pfb_dropbox_link($plugin, $s)
{
    if (pfb_app($plugin, 'dropbox_key') === '') {
        throw new Exception('Inserisci prima la App key di Dropbox (in fondo a questa scheda).');
    }
    $ver = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '=');
    $s['cfg']['attesa'] = array('verifier' => $ver, 'scade' => time() + 1800);
    pfb_storage_salva($plugin, $s);
    return pfb_url('d_www') . '/oauth2/authorize?' . http_build_query(array('client_id' => pfb_app($plugin, 'dropbox_key'), 'response_type' => 'code',
        'token_access_type' => 'offline', 'code_challenge' => rtrim(strtr(base64_encode(hash('sha256', $ver, true)), '+/', '-_'), '='), 'code_challenge_method' => 'S256'));
}

function pfb_dropbox_codice($plugin, $s, $codice)
{
    $a = isset($s['cfg']['attesa']) ? $s['cfg']['attesa'] : null;
    if (!$a || $a['scade'] < time()) {
        throw new Exception('Il collegamento è scaduto: premi di nuovo «Autenticati con Dropbox».');
    }
    $r = pfb_curl(pfb_url('d_api') . '/oauth2/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'code' => trim($codice), 'grant_type' => 'authorization_code', 'client_id' => pfb_app($plugin, 'dropbox_key'), 'code_verifier' => $a['verifier']))));
    $j = json_decode($r['body'], true);
    if (!isset($j['refresh_token'])) {
        pfb_errore($r, 'Collegamento a Dropbox non riuscito (codice sbagliato o scaduto?)');
    }
    unset($s['cfg']['attesa']);
    pfb_scfg_set($s, 'refresh_token', $j['refresh_token']);
    $s['cfg']['account'] = 'account Dropbox';
    $u = pfb_curl(pfb_url('d_api') . '/2/users/get_current_account', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => 'null',
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $j['access_token'], 'Content-Type: application/json')));
    $uj = json_decode($u['body'], true);
    if (isset($uj['email'])) {
        $s['cfg']['account'] = $uj['email'];
    }
    pfb_storage_salva($plugin, $s);
}

function pfb_dropbox_token($plugin, $s)
{
    $rt = pfb_scfg($s, 'refresh_token');
    if ($rt === '') {
        throw new Exception('Dropbox non è ancora autenticato.');
    }
    $r = pfb_curl(pfb_url('d_api') . '/oauth2/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'refresh_token' => $rt, 'grant_type' => 'refresh_token', 'client_id' => pfb_app($plugin, 'dropbox_key')))));
    $j = json_decode($r['body'], true);
    if (!isset($j['access_token'])) {
        pfb_errore($r, 'Accesso a Dropbox non riuscito (prova ad autenticarti di nuovo)');
    }
    return $j['access_token'];
}

function pfb_dropbox_dir($s)
{
    $d = trim(str_replace('\\', '/', pfb_scfg($s, 'cartella')), '/');
    return $d === '' ? '' : '/' . $d;
}

function pfb_dropbox_rpc($tok, $ep, $args)
{
    return pfb_curl(pfb_url('d_api') . '/2/' . $ep, array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($args, JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: application/json')));
}

function pfb_dropbox_put($plugin, $s, $path, $nome)
{
    $tok = pfb_dropbox_token($plugin, $s);
    $dest = pfb_dropbox_dir($s) . '/' . $nome;
    $size = filesize($path);
    $pezzo = 8 * 1048576;
    $h = function ($arg) use ($tok) {
        return array('Authorization: Bearer ' . $tok, 'Content-Type: application/octet-stream', 'Dropbox-API-Arg: ' . json_encode($arg, JSON_UNESCAPED_SLASHES));
    };
    $commit = array('path' => $dest, 'mode' => 'overwrite', 'mute' => true);
    $fh = fopen($path, 'rb');
    if ($size <= $pezzo) {
        $r = pfb_curl(pfb_url('d_content') . '/2/files/upload', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => (string)fread($fh, $pezzo + 1), CURLOPT_HTTPHEADER => $h($commit)));
        fclose($fh);
        if ($r['code'] !== 200) {
            pfb_errore($r, 'Invio a Dropbox non riuscito');
        }
        return;
    }
    $r = pfb_curl(pfb_url('d_content') . '/2/files/upload_session/start', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => fread($fh, $pezzo),
        CURLOPT_HTTPHEADER => $h(array('close' => false))));
    $j = json_decode($r['body'], true);
    if (!isset($j['session_id'])) {
        fclose($fh);
        pfb_errore($r, 'Invio a Dropbox non riuscito');
    }
    $off = ftell($fh);
    while ($size - $off > $pezzo) {
        $r = pfb_curl(pfb_url('d_content') . '/2/files/upload_session/append_v2', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => fread($fh, $pezzo),
            CURLOPT_HTTPHEADER => $h(array('cursor' => array('session_id' => $j['session_id'], 'offset' => $off), 'close' => false))));
        if ($r['code'] !== 200) {
            fclose($fh);
            pfb_errore($r, 'Invio a Dropbox interrotto');
        }
        $off = ftell($fh);
        if (!empty($GLOBALS['PFB_PROGRESSO'])) {
            call_user_func($GLOBALS['PFB_PROGRESSO'], $off, $size);
        }
    }
    $resto = (string)stream_get_contents($fh);
    fclose($fh);
    $r = pfb_curl(pfb_url('d_content') . '/2/files/upload_session/finish', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => $resto,
        CURLOPT_HTTPHEADER => $h(array('cursor' => array('session_id' => $j['session_id'], 'offset' => $off), 'commit' => $commit))));
    if ($r['code'] !== 200) {
        pfb_errore($r, 'Invio a Dropbox non completato');
    }
}

function pfb_dropbox_lista($plugin, $s)
{
    $tok = pfb_dropbox_token($plugin, $s);
    $r = pfb_dropbox_rpc($tok, 'files/list_folder', array('path' => pfb_dropbox_dir($s), 'limit' => 2000));
    if ($r['code'] === 409 && strpos($r['body'], 'not_found') !== false) {
        return array();
    }
    $j = json_decode($r['body'], true);
    if ($r['code'] !== 200 || !isset($j['entries'])) {
        pfb_errore($r, 'Elenco dei file su Dropbox non riuscito');
    }
    $out = array();
    foreach ($j['entries'] as $e) {
        if (isset($e['name']) && pfb_nome_ok($e['name'])) {
            $out[$e['name']] = pfb_voce($e['name'], isset($e['size']) ? $e['size'] : 0);
        }
    }
    return $out;
}

function pfb_dropbox_prova($plugin, $s)
{
    return 'Collegato a Dropbox (' . (isset($s['cfg']['account']) ? $s['cfg']['account'] : 'account') . '): ' . count(pfb_dropbox_lista($plugin, $s)) . ' backup.';
}

function pfb_dropbox_prendi($plugin, $s, $nome, $dest)
{
    $tok = pfb_dropbox_token($plugin, $s);
    $r = pfb_curl(pfb_url('d_content') . '/2/files/download', array('_file' => $dest, CURLOPT_POST => true, CURLOPT_POSTFIELDS => '',
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: text/plain', 'Dropbox-API-Arg: ' . json_encode(array('path' => pfb_dropbox_dir($s) . '/' . $nome), JSON_UNESCAPED_SLASHES))));
    if (!pfb_ok($r)) {
        $r['body'] = (string)@file_get_contents($dest, false, null, 0, 2000);
        @unlink($dest);
        pfb_errore($r, 'Scaricamento da Dropbox non riuscito');
    }
}

function pfb_dropbox_elimina($plugin, $s, $nome)
{
    $r = pfb_dropbox_rpc(pfb_dropbox_token($plugin, $s), 'files/delete_v2', array('path' => pfb_dropbox_dir($s) . '/' . $nome));
    if ($r['code'] !== 200 && !($r['code'] === 409 && strpos($r['body'], 'not_found') !== false)) {
        pfb_errore($r, 'Eliminazione da Dropbox non riuscita');
    }
}

/* ================= Microsoft OneDrive (codice da inserire su microsoft.com/devicelogin) ================= */

function pfb_onedrive_scope()
{
    return 'Files.ReadWrite.AppFolder offline_access';
}

function pfb_onedrive_avvia($plugin, $s)
{
    if (pfb_app($plugin, 'ms_id') === '') {
        throw new Exception('Inserisci prima l\'ID dell\'app Microsoft (in fondo a questa scheda).');
    }
    $r = pfb_curl(pfb_url('ms_login') . '/common/oauth2/v2.0/devicecode', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => pfb_app($plugin, 'ms_id'), 'scope' => pfb_onedrive_scope()))));
    $j = json_decode($r['body'], true);
    if (!isset($j['device_code'])) {
        pfb_errore($r, 'Microsoft non ha accettato la richiesta (nell\'app attiva «Consenti flussi client pubblici»)');
    }
    $s['cfg']['attesa'] = array('device_code' => $j['device_code'], 'codice' => $j['user_code'],
        'url' => isset($j['verification_uri']) ? $j['verification_uri'] : 'https://microsoft.com/devicelogin', 'scade' => time() + (int)$j['expires_in'],
        'intervallo' => isset($j['interval']) ? (int)$j['interval'] : 5);
    pfb_storage_salva($plugin, $s);
    return $s['cfg']['attesa'];
}

function pfb_onedrive_verifica($plugin, $s)
{
    $a = isset($s['cfg']['attesa']) ? $s['cfg']['attesa'] : null;
    if (!$a || $a['scade'] < time()) {
        throw new Exception('Il codice è scaduto: premi di nuovo «Autenticati con OneDrive».');
    }
    $r = pfb_curl(pfb_url('ms_login') . '/common/oauth2/v2.0/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => pfb_app($plugin, 'ms_id'), 'device_code' => $a['device_code'], 'grant_type' => 'urn:ietf:params:oauth:grant-type:device_code'))));
    $j = json_decode($r['body'], true);
    if (isset($j['error']) && in_array($j['error'], array('authorization_pending', 'slow_down'), true)) {
        return false;
    }
    if (!isset($j['refresh_token'])) {
        pfb_errore($r, 'Collegamento a OneDrive non riuscito');
    }
    unset($s['cfg']['attesa']);
    pfb_scfg_set($s, 'refresh_token', $j['refresh_token']);
    $d = pfb_curl(pfb_url('ms_graph') . '/v1.0/me/drive?$select=owner', array(CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $j['access_token'])));
    $dj = json_decode($d['body'], true);
    $s['cfg']['account'] = isset($dj['owner']['user']['displayName']) ? $dj['owner']['user']['displayName'] : 'account Microsoft';
    pfb_storage_salva($plugin, $s);
    return true;
}

// Microsoft cambia il refresh token a ogni uso: il nuovo si salva subito
function pfb_onedrive_token($plugin, $s)
{
    static $cache = array(); // un accesso vale un'ora: nello stesso lavoro si riusa
    if (isset($cache[$s['id']]) && $cache[$s['id']][1] > time() + 60) {
        return $cache[$s['id']][0];
    }
    $ora = pfb_storage($plugin, $s['id']); // il refresh token salvato piu' di recente (cambia a ogni uso)
    if ($ora) {
        $s = $ora;
    }
    $rt = pfb_scfg($s, 'refresh_token');
    if ($rt === '') {
        throw new Exception('OneDrive non è ancora autenticato.');
    }
    $r = pfb_curl(pfb_url('ms_login') . '/common/oauth2/v2.0/token', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(array(
        'client_id' => pfb_app($plugin, 'ms_id'), 'refresh_token' => $rt, 'grant_type' => 'refresh_token', 'scope' => pfb_onedrive_scope()))));
    $j = json_decode($r['body'], true);
    if (!isset($j['access_token'])) {
        pfb_errore($r, 'Accesso a OneDrive non riuscito (prova ad autenticarti di nuovo)');
    }
    if (!empty($j['refresh_token']) && $j['refresh_token'] !== $rt) {
        $nuovo = pfb_storage($plugin, $s['id']);
        if ($nuovo) {
            pfb_scfg_set($nuovo, 'refresh_token', $j['refresh_token']);
            pfb_storage_salva($plugin, $nuovo);
        }
    }
    $cache[$s['id']] = array($j['access_token'], time() + (isset($j['expires_in']) ? (int)$j['expires_in'] : 3000));
    return $j['access_token'];
}

function pfb_onedrive_percorso($s, $nome)
{
    $d = trim(str_replace('\\', '/', pfb_scfg($s, 'cartella')), '/');
    $p = ($d !== '' ? $d . '/' : '') . $nome;
    return implode('/', array_map('rawurlencode', explode('/', $p)));
}

function pfb_onedrive_put($plugin, $s, $path, $nome)
{
    $tok = pfb_onedrive_token($plugin, $s);
    $size = filesize($path);
    $base = pfb_url('ms_graph') . '/v1.0/me/drive/special/approot:/' . pfb_onedrive_percorso($s, $nome) . ':';
    if ($size <= 4 * 1048576) {
        $fh = fopen($path, 'rb');
        $r = pfb_curl($base . '/content', array(CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => $size,
            CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: application/zip')));
        fclose($fh);
        if (!pfb_ok($r)) {
            pfb_errore($r, 'Invio a OneDrive non riuscito');
        }
        return;
    }
    $r = pfb_curl($base . '/createUploadSession', array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode(array('item' => array('@microsoft.graph.conflictBehavior' => 'replace'))),
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok, 'Content-Type: application/json')));
    $j = json_decode($r['body'], true);
    if (empty($j['uploadUrl'])) {
        pfb_errore($r, 'Avvio dell\'invio a OneDrive non riuscito');
    }
    $pezzo = 32 * 327680; // multiplo di 320 KiB, circa 10 MB
    $fh = fopen($path, 'rb');
    $off = 0;
    while ($off < $size) {
        $dati = fread($fh, $pezzo);
        $fine = $off + strlen($dati) - 1;
        $r = pfb_curl($j['uploadUrl'], array(CURLOPT_CUSTOMREQUEST => 'PUT', CURLOPT_POSTFIELDS => $dati,
            CURLOPT_HTTPHEADER => array('Content-Length: ' . strlen($dati), 'Content-Range: bytes ' . $off . '-' . $fine . '/' . $size)));
        if (!pfb_ok($r)) {
            fclose($fh);
            pfb_errore($r, 'Invio a OneDrive interrotto');
        }
        $off = $fine + 1;
        if (!empty($GLOBALS['PFB_PROGRESSO'])) {
            call_user_func($GLOBALS['PFB_PROGRESSO'], $off, $size);
        }
    }
    fclose($fh);
}

function pfb_onedrive_lista($plugin, $s)
{
    $tok = pfb_onedrive_token($plugin, $s);
    $d = trim(str_replace('\\', '/', pfb_scfg($s, 'cartella')), '/');
    $url = pfb_url('ms_graph') . '/v1.0/me/drive/special/approot' . ($d !== '' ? ':/' . implode('/', array_map('rawurlencode', explode('/', $d))) . ':' : '') . '/children?$select=name,size&$top=999';
    $out = array();
    while ($url !== '') {
        $r = pfb_curl($url, array(CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok)));
        if ($r['code'] === 404) {
            return array();
        }
        $j = json_decode($r['body'], true);
        if ($r['code'] !== 200 || !isset($j['value'])) {
            pfb_errore($r, 'Elenco dei file su OneDrive non riuscito');
        }
        foreach ($j['value'] as $f) {
            if (isset($f['name']) && pfb_nome_ok($f['name'])) {
                $out[$f['name']] = pfb_voce($f['name'], isset($f['size']) ? $f['size'] : 0);
            }
        }
        $url = isset($j['@odata.nextLink']) ? $j['@odata.nextLink'] : '';
    }
    return $out;
}

function pfb_onedrive_prova($plugin, $s)
{
    return 'Collegato a OneDrive (' . (isset($s['cfg']['account']) ? $s['cfg']['account'] : 'account') . '): ' . count(pfb_onedrive_lista($plugin, $s)) . ' backup.';
}

function pfb_onedrive_prendi($plugin, $s, $nome, $dest)
{
    $tok = pfb_onedrive_token($plugin, $s);
    $r = pfb_curl(pfb_url('ms_graph') . '/v1.0/me/drive/special/approot:/' . pfb_onedrive_percorso($s, $nome) . ':/content', array('_file' => $dest,
        CURLOPT_FOLLOWLOCATION => true, CURLOPT_UNRESTRICTED_AUTH => false, CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $tok)));
    if (!pfb_ok($r)) {
        @unlink($dest);
        pfb_errore($r, 'Scaricamento da OneDrive non riuscito');
    }
}

function pfb_onedrive_elimina($plugin, $s, $nome)
{
    $r = pfb_curl(pfb_url('ms_graph') . '/v1.0/me/drive/special/approot:/' . pfb_onedrive_percorso($s, $nome), array(CURLOPT_CUSTOMREQUEST => 'DELETE',
        CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . pfb_onedrive_token($plugin, $s))));
    if (!in_array($r['code'], array(200, 204, 404), true)) {
        pfb_errore($r, 'Eliminazione da OneDrive non riuscita');
    }
}

/* ================= Amazon S3 e compatibili (firma AWS Signature V4) ================= */

function pfb_s3_base($s)
{
    $ep = rtrim(pfb_scfg($s, 'endpoint'), '/');
    $reg = pfb_scfg($s, 'regione') !== '' ? pfb_scfg($s, 'regione') : 'us-east-1';
    if ($ep === '') {
        $ep = 'https://s3.' . $reg . '.amazonaws.com';
    }
    if (!preg_match('#^https?://[A-Za-z0-9.\-:\[\]]+$#', $ep)) {
        throw new Exception('Indirizzo (endpoint) non valido: scrivilo come https://server');
    }
    $bucket = pfb_scfg($s, 'bucket');
    if (!preg_match('/^[a-z0-9][a-z0-9.\-]{1,61}[a-z0-9]$/', $bucket)) {
        throw new Exception('Nome del bucket non valido.');
    }
    if (pfb_scfg($s, 'chiave') === '' || pfb_scfg($s, 'secret') === '') {
        throw new Exception('Inserisci Access key e Secret key.');
    }
    $path_style = pfb_scfg($s, 'path_style') === '1';
    $p = parse_url($ep);
    $host = $path_style ? $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') : $bucket . '.' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    return array('scheme' => $p['scheme'], 'host' => $host, 'prefix' => $path_style ? '/' . $bucket : '', 'regione' => $reg,
        'cartella' => trim(str_replace('\\', '/', pfb_scfg($s, 'cartella')), '/'));
}

function pfb_s3_enc($p)
{
    return str_replace('%2F', '/', rawurlencode($p));
}

/*
 * Richiesta firmata. $key: chiave dell'oggetto (senza "/" iniziale) o '' per il bucket. $q: parametri della query.
 * $hash: sha256 esadecimale del corpo. $o: altre opzioni curl.
 */
function pfb_s3_req($s, $metodo, $key, $q, $hash, $o = array(), $ora = null)
{
    $b = pfb_s3_base($s);
    $ora = $ora === null ? time() : $ora;
    $amz = gmdate('Ymd\THis\Z', $ora);
    $giorno = gmdate('Ymd', $ora);
    $uri = $b['prefix'] . '/' . pfb_s3_enc($key);
    ksort($q);
    $qs = array();
    foreach ($q as $k => $v) {
        $qs[] = rawurlencode($k) . '=' . rawurlencode($v);
    }
    $qs = implode('&', $qs);
    $headers = array('host' => $b['host'], 'x-amz-content-sha256' => $hash, 'x-amz-date' => $amz);
    ksort($headers);
    $can_h = '';
    foreach ($headers as $k => $v) {
        $can_h .= $k . ':' . trim($v) . "\n";
    }
    $firmati = implode(';', array_keys($headers));
    $canonical = $metodo . "\n" . $uri . "\n" . $qs . "\n" . $can_h . "\n" . $firmati . "\n" . $hash;
    $scope = $giorno . '/' . $b['regione'] . '/s3/aws4_request';
    $da_firmare = "AWS4-HMAC-SHA256\n" . $amz . "\n" . $scope . "\n" . hash('sha256', $canonical);
    $k = hash_hmac('sha256', 'aws4_request', hash_hmac('sha256', 's3', hash_hmac('sha256', $b['regione'], hash_hmac('sha256', $giorno, 'AWS4' . pfb_scfg($s, 'secret'), true), true), true), true);
    $firma = hash_hmac('sha256', $da_firmare, $k);
    $auth = 'AWS4-HMAC-SHA256 Credential=' . pfb_scfg($s, 'chiave') . '/' . $scope . ', SignedHeaders=' . $firmati . ', Signature=' . $firma;
    $url = $b['scheme'] . '://' . $b['host'] . $uri . ($qs !== '' ? '?' . $qs : '');
    $h = array('Authorization: ' . $auth, 'x-amz-content-sha256: ' . $hash, 'x-amz-date: ' . $amz);
    if (isset($o[CURLOPT_HTTPHEADER])) {
        $h = array_merge($h, $o[CURLOPT_HTTPHEADER]);
    }
    $o[CURLOPT_HTTPHEADER] = $h;
    $o[CURLOPT_CUSTOMREQUEST] = $metodo;
    if (pfb_scfg($s, 'insicuro') === '1') {
        $o[CURLOPT_SSL_VERIFYPEER] = false;
        $o[CURLOPT_SSL_VERIFYHOST] = 0;
    }
    return pfb_curl($url, $o, !preg_match('/^(127\.|10\.|192\.168\.|localhost)/', $b['host']));
}

function pfb_s3_chiave($s, $nome)
{
    $b = pfb_s3_base($s);
    return ($b['cartella'] !== '' ? $b['cartella'] . '/' : '') . $nome;
}

function pfb_s3_put($plugin, $s, $path, $nome)
{
    $size = filesize($path);
    $fh = fopen($path, 'rb');
    $r = pfb_s3_req($s, 'PUT', pfb_s3_chiave($s, $nome), array(), hash_file('sha256', $path), array(CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh,
        CURLOPT_INFILESIZE => $size, CURLOPT_HTTPHEADER => array('Content-Type: application/zip')));
    fclose($fh);
    if (!pfb_ok($r)) {
        pfb_errore($r, 'Invio al bucket non riuscito');
    }
}

function pfb_s3_lista($plugin, $s)
{
    $b = pfb_s3_base($s);
    $out = array();
    $token = '';
    do {
        $q = array('list-type' => '2', 'prefix' => $b['cartella'] !== '' ? $b['cartella'] . '/' : '');
        if ($token !== '') {
            $q['continuation-token'] = $token;
        }
        $r = pfb_s3_req($s, 'GET', '', $q, hash('sha256', ''));
        if (!pfb_ok($r)) {
            pfb_errore($r, 'Elenco del bucket non riuscito');
        }
        $x = @simplexml_load_string($r['body']);
        if (!$x) {
            throw new Exception('Risposta del bucket non leggibile.');
        }
        foreach ($x->Contents as $c) {
            $n = basename((string)$c->Key);
            if (pfb_nome_ok($n)) {
                $out[$n] = pfb_voce($n, (int)$c->Size);
            }
        }
        $token = (string)$x->IsTruncated === 'true' ? (string)$x->NextContinuationToken : '';
    } while ($token !== '');
    return $out;
}

function pfb_s3_prova($plugin, $s)
{
    return 'Collegato al bucket ' . pfb_scfg($s, 'bucket') . ': ' . count(pfb_s3_lista($plugin, $s)) . ' backup.';
}

function pfb_s3_prendi($plugin, $s, $nome, $dest)
{
    $r = pfb_s3_req($s, 'GET', pfb_s3_chiave($s, $nome), array(), hash('sha256', ''), array('_file' => $dest));
    if (!pfb_ok($r)) {
        $r['body'] = (string)@file_get_contents($dest, false, null, 0, 2000);
        @unlink($dest);
        pfb_errore($r, 'Scaricamento dal bucket non riuscito');
    }
}

function pfb_s3_elimina($plugin, $s, $nome)
{
    $r = pfb_s3_req($s, 'DELETE', pfb_s3_chiave($s, $nome), array(), hash('sha256', ''));
    if (!in_array($r['code'], array(200, 204, 404), true)) {
        pfb_errore($r, 'Eliminazione dal bucket non riuscita');
    }
}

/* ================= FTP / FTPS / SFTP ================= */

function pfb_ftp_base($s)
{
    $sftp = $s['tipo'] === 'sftp';
    $host = trim(pfb_scfg($s, 'host'));
    if ($host === '' || !preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $host)) {
        throw new Exception('Indica l\'indirizzo del server.');
    }
    $port = (int)pfb_scfg($s, 'porta') ?: ($sftp ? 22 : 21);
    $proto = $sftp ? 'sftp' : 'ftp';
    if (!pfb_curl_ha($proto)) {
        throw new Exception('Il curl di questo server non supporta ' . strtoupper($proto) . '.');
    }
    $dir = trim(str_replace('\\', '/', pfb_scfg($s, 'cartella')), '/');
    $abs = substr(pfb_scfg($s, 'cartella'), 0, 1) === '/';
    $path = $sftp ? ($abs ? '/' . $dir : '/~/' . $dir) : '/' . $dir;
    $path = rtrim($path, '/') . '/';
    return array('url' => $proto . '://' . $host . ':' . $port . str_replace('%2F', '/', rawurlencode($path)), 'path' => $path, 'sftp' => $sftp);
}

function pfb_ftp_opts($s)
{
    $o = array(CURLOPT_USERPWD => pfb_scfg($s, 'utente') . ':' . pfb_scfg($s, 'pass'));
    if ($s['tipo'] === 'ftp' && pfb_scfg($s, 'tls') === '1') {
        $o[CURLOPT_USE_SSL] = CURLUSESSL_ALL;
        if (pfb_scfg($s, 'insicuro') === '1') {
            $o[CURLOPT_SSL_VERIFYPEER] = false;
            $o[CURLOPT_SSL_VERIFYHOST] = 0;
        }
    }
    if ($s['tipo'] === 'sftp') {
        $key = pfb_scfg($s, 'chiave_ssh');
        if (defined('CURLOPT_SSH_AUTH_TYPES')) {
            $o[CURLOPT_SSH_AUTH_TYPES] = $key !== '' ? CURLSSH_AUTH_PUBLICKEY : (CURLSSH_AUTH_PASSWORD | CURLSSH_AUTH_KEYBOARD);
        }
        if ($key !== '') {
            $kf = DATA_DIR . '/tmp-pfb-' . substr(md5(uniqid('', true)), 0, 8);
            file_put_contents($kf, $key);
            @chmod($kf, 0600);
            $GLOBALS['PFB_TMP'][] = $kf;
            $o[CURLOPT_SSH_PRIVATE_KEYFILE] = $kf;
            if (pfb_scfg($s, 'passphrase') !== '') {
                $o[CURLOPT_KEYPASSWD] = pfb_scfg($s, 'passphrase');
            }
            unset($o[CURLOPT_USERPWD]);
            $o[CURLOPT_USERNAME] = pfb_scfg($s, 'utente');
        }
        $fp = trim(pfb_scfg($s, 'impronta'));
        if ($fp !== '' && preg_match('/^SHA256:(.+)$/', $fp, $m) && defined('CURLOPT_SSH_HOST_PUBLIC_KEY_SHA256')) {
            $o[CURLOPT_SSH_HOST_PUBLIC_KEY_SHA256] = rtrim($m[1], '=');
        }
    }
    return $o;
}

function pfb_ftp_put($plugin, $s, $path, $nome)
{
    $b = pfb_ftp_base($s);
    $fh = fopen($path, 'rb');
    $r = pfb_curl($b['url'] . rawurlencode($nome), pfb_ftp_opts($s) + array(CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => filesize($path),
        CURLOPT_FTP_CREATE_MISSING_DIRS => true), false);
    fclose($fh);
    if ($r['errno']) {
        pfb_errore($r, 'Invio non riuscito');
    }
}

function pfb_ftp_lista($plugin, $s)
{
    $b = pfb_ftp_base($s);
    $r = pfb_curl($b['url'], pfb_ftp_opts($s) + array(CURLOPT_DIRLISTONLY => true, CURLOPT_FTP_CREATE_MISSING_DIRS => true), false);
    if ($r['errno']) {
        pfb_errore($r, 'Elenco dei file non riuscito');
    }
    $out = array();
    foreach (preg_split('/\r?\n/', $r['body']) as $l) {
        $l = basename(trim($l));
        if (pfb_nome_ok($l)) {
            $out[$l] = pfb_voce($l, 0);
        }
    }
    return $out;
}

function pfb_ftp_prova($plugin, $s)
{
    return 'Collegato a ' . pfb_scfg($s, 'host') . ': ' . count(pfb_ftp_lista($plugin, $s)) . ' backup nella cartella.';
}

function pfb_ftp_prendi($plugin, $s, $nome, $dest)
{
    $b = pfb_ftp_base($s);
    $r = pfb_curl($b['url'] . rawurlencode($nome), pfb_ftp_opts($s) + array('_file' => $dest), false);
    if ($r['errno']) {
        @unlink($dest);
        pfb_errore($r, 'Scaricamento non riuscito');
    }
}

function pfb_ftp_elimina($plugin, $s, $nome)
{
    if (!pfb_nome_ok($nome)) {
        return;
    }
    $b = pfb_ftp_base($s);
    // il comando parte dopo l'elenco della cartella, quindi da dentro la cartella (FTP) o con il percorso completo (SFTP, /~/ = cartella home)
    $cmd = $b['sftp'] ? 'rm "' . $b['path'] . $nome . '"' : 'DELE ' . $nome;
    $r = pfb_curl($b['url'], pfb_ftp_opts($s) + array(CURLOPT_DIRLISTONLY => true, CURLOPT_POSTQUOTE => array($cmd)), false);
    if ($r['errno']) {
        pfb_errore($r, 'Eliminazione di ' . $nome . ' non riuscita');
    }
}

// SFTP usa le stesse funzioni dell'FTP
function pfb_sftp_put($plugin, $s, $path, $nome)
{
    pfb_ftp_put($plugin, $s, $path, $nome);
}

function pfb_sftp_lista($plugin, $s)
{
    return pfb_ftp_lista($plugin, $s);
}

function pfb_sftp_prova($plugin, $s)
{
    return pfb_ftp_prova($plugin, $s);
}

function pfb_sftp_prendi($plugin, $s, $nome, $dest)
{
    pfb_ftp_prendi($plugin, $s, $nome, $dest);
}

function pfb_sftp_elimina($plugin, $s, $nome)
{
    pfb_ftp_elimina($plugin, $s, $nome);
}

/* ================= Nextcloud / WebDAV ================= */

function pfb_webdav_base($s)
{
    $u = trim(pfb_scfg($s, 'url'));
    if (!preg_match('#^https?://#i', $u)) {
        throw new Exception('Indica l\'indirizzo WebDAV completo (inizia con https://).');
    }
    return rtrim($u, '/') . '/';
}

function pfb_webdav_opts($s)
{
    $o = array(CURLOPT_USERPWD => pfb_scfg($s, 'utente') . ':' . pfb_scfg($s, 'pass'), CURLOPT_HTTPAUTH => CURLAUTH_BASIC);
    if (pfb_scfg($s, 'insicuro') === '1') {
        $o[CURLOPT_SSL_VERIFYPEER] = false;
        $o[CURLOPT_SSL_VERIFYHOST] = 0;
    }
    return $o;
}

function pfb_webdav_put($plugin, $s, $path, $nome)
{
    $base = pfb_webdav_base($s);
    $r = pfb_curl($base, pfb_webdav_opts($s) + array(CURLOPT_CUSTOMREQUEST => 'MKCOL'), false);
    if ($r['errno'] || $r['code'] === 401) {
        pfb_errore($r, $r['code'] === 401 ? 'Utente o password non accettati' : 'Collegamento non riuscito');
    }
    $fh = fopen($path, 'rb');
    $r = pfb_curl($base . rawurlencode($nome), pfb_webdav_opts($s) + array(CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => filesize($path)), false);
    fclose($fh);
    if (!pfb_ok($r)) {
        pfb_errore($r, 'Invio non riuscito');
    }
}

function pfb_webdav_lista($plugin, $s)
{
    $r = pfb_curl(pfb_webdav_base($s), pfb_webdav_opts($s) + array(CURLOPT_CUSTOMREQUEST => 'PROPFIND', CURLOPT_HTTPHEADER => array('Depth: 1', 'Content-Type: application/xml'),
        CURLOPT_POSTFIELDS => '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:getcontentlength/></d:prop></d:propfind>'), false);
    if ($r['code'] === 404) {
        return array();
    }
    if ($r['errno'] || $r['code'] !== 207) {
        pfb_errore($r, 'Elenco dei file non riuscito');
    }
    $out = array();
    if (preg_match_all('#<(?:[a-z0-9]+:)?response\b.*?</(?:[a-z0-9]+:)?response>#is', $r['body'], $resp)) {
        foreach ($resp[0] as $x) {
            if (!preg_match('#<(?:[a-z0-9]+:)?href>([^<]+)</#i', $x, $m)) {
                continue;
            }
            $n = rawurldecode(basename(rtrim(html_entity_decode($m[1]), '/')));
            if (pfb_nome_ok($n)) {
                $dim = preg_match('#getcontentlength>(\d+)<#i', $x, $d) ? (int)$d[1] : 0;
                $out[$n] = pfb_voce($n, $dim);
            }
        }
    }
    return $out;
}

function pfb_webdav_prova($plugin, $s)
{
    return 'Collegato: ' . count(pfb_webdav_lista($plugin, $s)) . ' backup nella cartella.';
}

function pfb_webdav_prendi($plugin, $s, $nome, $dest)
{
    $r = pfb_curl(pfb_webdav_base($s) . rawurlencode($nome), pfb_webdav_opts($s) + array('_file' => $dest), false);
    if (!pfb_ok($r)) {
        @unlink($dest);
        pfb_errore($r, 'Scaricamento non riuscito');
    }
}

function pfb_webdav_elimina($plugin, $s, $nome)
{
    $r = pfb_curl(pfb_webdav_base($s) . rawurlencode($nome), pfb_webdav_opts($s) + array(CURLOPT_CUSTOMREQUEST => 'DELETE'), false);
    if ($r['errno'] || ($r['code'] >= 300 && $r['code'] !== 404)) {
        pfb_errore($r, 'Eliminazione di ' . $nome . ' non riuscita');
    }
}

/* ================= Cartella del server o NAS montato ================= */

function pfb_cartella_dir($s)
{
    $d = rtrim(pfb_scfg($s, 'percorso'), "/\\");
    if ($d === '') {
        throw new Exception('Indica la cartella.');
    }
    if (!is_dir($d)) {
        throw new Exception('La cartella ' . $d . ' non esiste o non è raggiungibile (la condivisione del NAS è montata?).');
    }
    $real = realpath($d);
    $data = realpath(DATA_DIR);
    if ($real && $data && strpos($real . '/', $data . '/') === 0) {
        throw new Exception('Scegli una cartella fuori dalla cartella data del sito.');
    }
    if (!is_writable($d)) {
        throw new Exception('Il sito non può scrivere nella cartella ' . $d . ' (permessi).');
    }
    return $d;
}

function pfb_cartella_put($plugin, $s, $path, $nome)
{
    $d = pfb_cartella_dir($s);
    if (!@copy($path, $d . '/' . $nome . '.parziale') || !@rename($d . '/' . $nome . '.parziale', $d . '/' . $nome)) {
        @unlink($d . '/' . $nome . '.parziale');
        throw new Exception('Copia nella cartella ' . $d . ' non riuscita (spazio o permessi).');
    }
}

function pfb_cartella_lista($plugin, $s)
{
    $d = pfb_cartella_dir($s);
    $out = array();
    foreach ((array)scandir($d) as $n) {
        if (pfb_nome_ok($n)) {
            $out[$n] = pfb_voce($n, filesize($d . '/' . $n));
        }
    }
    return $out;
}

function pfb_cartella_prova($plugin, $s)
{
    return 'Cartella raggiungibile: ' . count(pfb_cartella_lista($plugin, $s)) . ' backup.';
}

function pfb_cartella_prendi($plugin, $s, $nome, $dest)
{
    if (!pfb_nome_ok($nome) || !@copy(pfb_cartella_dir($s) . '/' . $nome, $dest)) {
        throw new Exception('Copia dalla cartella non riuscita.');
    }
}

function pfb_cartella_elimina($plugin, $s, $nome)
{
    if (pfb_nome_ok($nome)) {
        @unlink(pfb_cartella_dir($s) . '/' . $nome);
    }
}

/* ---------------- Scaricare un backup dallo storage al server ---------------- */

function pfb_scarica_da_storage($plugin, $s, $nome)
{
    if (!pfb_nome_ok($nome)) {
        throw new Exception('Nome del backup non valido.');
    }
    $dest = pfb_archivio($plugin) . '/' . $nome;
    if (is_file($dest)) {
        return $nome;
    }
    pfb_passo(5, 'Scaricamento di ' . $nome . ' da ' . pfb_storage_nome($s) . '…');
    $GLOBALS['PFB_PROGRESSO'] = function ($fatto, $tot) {
        pfb_passo(5 + (int)(90 * $fatto / max(1, $tot)), 'Scaricamento: ' . pfb_mb($fatto) . ' di ' . pfb_mb($tot), false);
    };
    pfb_storage_call($plugin, $s, 'prendi', $nome, $dest . '.parziale');
    $GLOBALS['PFB_PROGRESSO'] = null;
    $z = new ZipArchive();
    if ($z->open($dest . '.parziale') !== true || $z->statName('manifest.json') === false) {
        @unlink($dest . '.parziale');
        throw new Exception('Il file scaricato non è un backup valido.');
    }
    $z->close();
    rename($dest . '.parziale', $dest);
    pfb_meta_salva($plugin, $nome, array('creato' => date('c', pfb_data_da_nome($nome) ?: time()), 'origine' => 'scaricato', 'contenuto' => preg_match('/_(completo|db|file)/', $nome, $m) ? $m[1] : '',
        'remoto' => array($s['id']), 'bloccato' => in_array($nome, pfb_bloccati($plugin), true) ? 1 : 0));
    pfb_log('Scaricato sul server (' . pfb_mb(filesize($dest)) . ').');
    return $nome;
}
