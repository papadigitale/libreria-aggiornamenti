/* PF Backup — pannello: avvio dei lavori, avanzamento, ripristino, caricamento a pezzi, storage */
(function () {
  'use strict';
  var root = document.querySelector('[data-pfb]');
  if (!root) { return; }
  var API = root.getAttribute('data-api').replace(/&amp;/g, '&');
  var csrf = (window.App && window.App.csrf) || '';
  function $(s, el) { return (el || root).querySelector(s); }
  function $$(s, el) { return Array.prototype.slice.call((el || root).querySelectorAll(s)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function leggi(r) { return r.text().then(function (t) { try { return JSON.parse(t); } catch (e) { return { ok: false, error: 'Risposta non valida dal server (' + r.status + ').' }; } }); }
  function post(f, dati) {
    var fd = dati instanceof FormData ? dati : new FormData();
    if (!(dati instanceof FormData)) { Object.keys(dati || {}).forEach(function (k) { fd.append(k, dati[k]); }); }
    fd.append('csrf', csrf);
    return fetch(API + f, { method: 'POST', body: fd, credentials: 'same-origin' }).then(leggi);
  }
  function get(f, q) {
    var u = API + f + (q ? '&' + Object.keys(q).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(q[k]); }).join('&') : '');
    return fetch(u, { credentials: 'same-origin', cache: 'no-store' }).then(leggi);
  }
  function scegli(nome) { var x = $('input[name="' + nome + '"]:checked'); return x ? x.value : ''; }

  /* ---------- avanzamento ---------- */
  var prog = $('[data-pfb-prog]');
  var timer = null, vistoLavoro = false;
  function mostra(s) {
    if (!prog || !s) { return; }
    prog.hidden = false;
    prog.classList.toggle('ok', !!s.finito && !!s.ok);
    prog.classList.toggle('ko', !!s.finito && !s.ok);
    $('[data-pfb-prog-titolo]').textContent = s.titolo || 'Lavoro';
    $('[data-pfb-prog-perc]').textContent = (s.finito ? (s.ok ? 'fatto' : 'non riuscito') : Math.round(s.perc || 0) + '%');
    $('[data-pfb-prog-bar]').style.width = (s.finito ? 100 : Math.max(2, s.perc || 0)) + '%';
    $('[data-pfb-prog-testo]').textContent = s.finito ? (s.ok ? (s.esito || 'Fatto.') : (s.errore || 'Qualcosa non è andato.')) : (s.testo || '');
    var fine = $('[data-pfb-prog-fine]');
    fine.hidden = !s.finito;
    var lg = $('[data-pfb-prog-log]');
    if (s.log) { lg.href = root.getAttribute('data-log-url').replace(/&amp;/g, '&') + '&vedi=' + encodeURIComponent(s.log); lg.hidden = false; } else { lg.hidden = true; }
    $$('[data-pfb-avvia],[data-pfb-invia],[data-pfb-ripristina],[data-pfb-rem-scarica]').forEach(function (b) { b.disabled = !s.finito; });
  }
  function segui() {
    clearTimeout(timer);
    get('stato').then(function (r) {
      var s = r && r.stato;
      if (!s) { if (vistoLavoro) { timer = setTimeout(segui, 1500); } return; }
      mostra(s);
      if (!s.finito) { vistoLavoro = true; timer = setTimeout(segui, 1000); return; }
      if (vistoLavoro && s.ok && s.tipo === 'ripristino') {
        $('[data-pfb-prog-testo]').textContent = (s.esito || 'Ripristino completato.') + ' Tra poco rientri con gli utenti del backup…';
        setTimeout(function () { window.location.href = 'logout.php?t=' + encodeURIComponent(csrf); }, 3500);
        return;
      }
      if (vistoLavoro && s.ok && (s.tipo === 'backup' || s.tipo === 'scaricamento')) {
        setTimeout(function () { window.location.reload(); }, 1800);
      }
    }).catch(function () {
      // durante il ripristino il sito puo' non rispondere per qualche istante
      if (vistoLavoro) { timer = setTimeout(segui, 2000); }
    });
  }
  function avviato(r) {
    if (!r.ok) { alertIn(prog, r.error); return; }
    vistoLavoro = true;
    mostra({ titolo: 'Avvio…', perc: 1, testo: 'Preparazione…', finito: 0 });
    if (prog) { prog.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    timer = setTimeout(segui, 700);
  }
  function alertIn(dopo, testo) {
    var a = document.createElement('div');
    a.className = 'alert error';
    a.textContent = testo || 'Errore.';
    if (dopo && dopo.parentNode) { dopo.parentNode.insertBefore(a, dopo); } else { root.insertBefore(a, root.firstChild); }
    setTimeout(function () { a.remove(); }, 9000);
  }
  if (prog) {
    // un lavoro gia' in corso (per esempio dopo aver ricaricato la pagina)?
    get('stato').then(function (r) { var s = r && r.stato; if (s && !s.finito) { vistoLavoro = true; mostra(s); timer = setTimeout(segui, 1000); } });
  }

  var bAvvia = $('[data-pfb-avvia]');
  if (bAvvia) {
    bAvvia.addEventListener('click', function () {
      bAvvia.disabled = true;
      post('avvia', { contenuto: scegli('pfb-cont'), dove: scegli('pfb-dove') }).then(function (r) { if (!r.ok) { bAvvia.disabled = false; } avviato(r); });
    });
  }
  root.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pfb-invia]');
    if (b) {
      b.disabled = true;
      post('invia', { nome: b.getAttribute('data-pfb-invia') }).then(avviato);
      return;
    }
    b = e.target.closest('[data-pfb-rem-scarica]');
    if (b) {
      b.disabled = true;
      post('scarica_remoto', { nome: b.getAttribute('data-pfb-rem-scarica'), storage: b.getAttribute('data-storage') }).then(avviato);
      return;
    }
    b = e.target.closest('.pfb-del');
    if (b) { $$('input[name="sel[]"]').forEach(function (c) { c.checked = false; }); }
    b = e.target.closest('[data-pfb-chiudi]');
    if (b) { var m = b.closest('.pfb-modal'); if (m) { chiudi(m); } }
  });

  /* ---------- selezione dei backup ---------- */
  var tutti = $('[data-pfb-tutti]'), selDel = $('[data-pfb-sel-elimina]');
  function contaSel() { if (selDel) { selDel.disabled = !$$('input[name="sel[]"]:checked').length; } }
  if (tutti) { tutti.addEventListener('change', function () { $$('input[name="sel[]"]:not(:disabled)').forEach(function (c) { c.checked = tutti.checked; }); contaSel(); }); }
  $$('input[name="sel[]"]').forEach(function (c) { c.addEventListener('change', contaSel); });

  /* ---------- finestre ---------- */
  function apri(m) { m.hidden = false; document.body.classList.add('pfb-aperta'); var i = m.querySelector('input:not([type=checkbox]):not([hidden])'); if (i) { setTimeout(function () { i.focus(); }, 30); } }
  function chiudi(m) { m.hidden = true; document.body.classList.remove('pfb-aperta'); if (m === oa) { oaFerma(); } }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { $$('.pfb-modal:not([hidden])').forEach(chiudi); } });
  $$('.pfb-modal').forEach(function (m) { m.addEventListener('click', function (e) { if (e.target === m) { chiudi(m); } }); });

  /* ---------- ripristino ---------- */
  var rip = $('[data-pfb-rip]'), ripNome = '';
  if (rip) {
    var pwb = $('[data-pfb-rip-pwbi]', rip), pwa = $('[data-pfb-rip-pwa]', rip), ok = $('[data-pfb-rip-ok]', rip), vai = $('[data-pfb-rip-vai]', rip), err = $('[data-pfb-rip-err]', rip);
    var pronto = function () { vai.disabled = !(ok.checked && pwa.value.length > 0); };
    ok.addEventListener('change', pronto);
    pwa.addEventListener('input', pronto);
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-pfb-ripristina]');
      if (!b) { return; }
      ripNome = b.getAttribute('data-pfb-ripristina');
      $('[data-pfb-rip-nome]', rip).textContent = ripNome;
      $('[data-pfb-rip-pwb]', rip).hidden = b.getAttribute('data-cifrato') !== '1';
      pwb.value = ''; pwa.value = ''; ok.checked = false; err.hidden = true; pronto();
      apri(rip);
    });
    vai.addEventListener('click', function () {
      vai.disabled = true; err.hidden = true;
      post('ripristina', { nome: ripNome, password_backup: pwb.value, password_admin: pwa.value }).then(function (r) {
        if (!r.ok) {
          err.textContent = r.error || 'Errore.'; err.hidden = false;
          if (r.serve_password) { $('[data-pfb-rip-pwb]', rip).hidden = false; pwb.focus(); }
          pronto();
          return;
        }
        chiudi(rip);
        avviato(r);
      }).catch(function () { err.textContent = 'Il server non risponde.'; err.hidden = false; pronto(); });
    });
  }

  /* ---------- backup negli storage remoti ---------- */
  var remMostra = $('[data-pfb-rem-mostra]');
  if (remMostra) {
    remMostra.addEventListener('click', function () {
      var st = $('[data-pfb-rem-st]').value, box = $('[data-pfb-rem-lista]');
      box.innerHTML = '<p class="sub">Carico l\'elenco…</p>';
      remMostra.disabled = true;
      get('elenco_remoto', { storage: st }).then(function (r) {
        remMostra.disabled = false;
        if (!r.ok) { box.innerHTML = '<div class="alert error">' + esc(r.error) + '</div>'; return; }
        if (!r.backup.length) { box.innerHTML = '<p class="sub">Nessun backup su ' + esc(r.storage) + '.</p>'; return; }
        box.innerHTML = '<table class="tbl pfb-tbl"><thead><tr><th>Backup</th><th>Dimensione</th><th class="act"></th></tr></thead><tbody>' + r.backup.map(function (b) {
          return '<tr><td><b>' + esc(b.data) + '</b><br><small class="muted">' + esc(b.nome) + (b.bloccato ? ' · bloccato' : '') + '</small></td><td>' + esc(b.dimensione) + '</td><td class="act">' +
            (b.sul_server ? '<span class="muted">già sul server</span>' : '<button class="btn link small" type="button" data-pfb-rem-scarica="' + esc(b.nome) + '" data-storage="' + esc(st) + '">Scarica sul server</button>') + '</td></tr>';
        }).join('') + '</tbody></table>';
      }).catch(function () { remMostra.disabled = false; box.innerHTML = '<div class="alert error">Il server non risponde.</div>'; });
    });
  }

  /* ---------- caricamento a pezzi ---------- */
  var file = $('[data-pfb-file]'), bCar = $('[data-pfb-carica]');
  if (file && bCar) {
    var PEZZO = 1536 * 1024; // sotto il limite piu' comune (2 MB) di upload_max_filesize
    file.addEventListener('change', function () { bCar.disabled = !file.files.length; });
    bCar.addEventListener('click', function () {
      var f = file.files[0];
      if (!f) { return; }
      var box = $('[data-pfb-car]'), bar = $('[data-pfb-car-bar]'), t = $('[data-pfb-car-testo]');
      var tok = Array.prototype.map.call(crypto.getRandomValues(new Uint8Array(16)), function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
      box.hidden = false; bCar.disabled = true; file.disabled = true;
      var errore = function (m) { t.textContent = m; box.classList.add('ko'); bCar.disabled = false; file.disabled = false; };
      var manda = function (off, tentativi) {
        var fd = new FormData();
        fd.append('token', tok); fd.append('offset', off); fd.append('totale', f.size); fd.append('nome', f.name);
        fd.append('pezzo', f.slice(off, off + PEZZO), 'pezzo');
        post('carica', fd).then(function (r) {
          if (!r.ok) {
            if (typeof r.riprendi === 'number' && tentativi < 3) { manda(r.riprendi, tentativi + 1); return; }
            errore(r.error || 'Caricamento non riuscito.'); return;
          }
          if (r.fatto) {
            bar.style.width = '100%'; box.classList.add('ok');
            t.textContent = 'Caricato: ' + r.nome + '. Ora lo trovi nell\'elenco dei backup.';
            setTimeout(function () { window.location.href = root.getAttribute('data-log-url').replace(/&amp;/g, '&').replace('tab=log', 'tab=backup'); }, 1800);
            return;
          }
          var n = r.ricevuti || off + PEZZO;
          bar.style.width = Math.round(n / f.size * 100) + '%';
          t.textContent = 'Caricati ' + (n / 1048576).toFixed(1) + ' MB di ' + (f.size / 1048576).toFixed(1) + ' MB…';
          manda(n, 0);
        }).catch(function () {
          if (tentativi < 3) { setTimeout(function () { manda(off, tentativi + 1); }, 2000); } else { errore('Il server non risponde: riprova.'); }
        });
      };
      manda(0, 0);
    });
  }

  /* ---------- pianificazione: campi per la frequenza scelta ---------- */
  function freq() {
    var v = scegli('freq');
    $$('[data-pfb-solo]').forEach(function (el) { el.hidden = el.getAttribute('data-pfb-solo') !== v; });
  }
  if ($('[data-pfb-freq]')) { $$('[data-pfb-freq]').forEach(function (r) { r.addEventListener('change', freq); }); freq(); }

  /* ---------- storage: prova e collegamento ---------- */
  var esito = $('[data-pfb-st-esito]');
  function mostraEsito(ok, testo) { if (!esito) { return; } esito.className = 'alert ' + (ok ? 'success' : 'error'); esito.textContent = testo; esito.hidden = false; }
  root.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pfb-prova]');
    if (!b) { return; }
    b.disabled = true; var t0 = b.textContent; b.textContent = 'Provo…';
    post('storage', { id: b.getAttribute('data-pfb-prova'), fai: 'prova' }).then(function (r) {
      b.disabled = false; b.textContent = t0;
      mostraEsito(r.ok, r.ok ? r.messaggio : r.error);
    }).catch(function () { b.disabled = false; b.textContent = t0; mostraEsito(false, 'Il server non risponde.'); });
  });

  var oa = $('[data-pfb-oa]'), oaTimer = null, oaId = '';
  function oaFerma() { clearTimeout(oaTimer); oaTimer = null; }
  function oaMsg(ok, testo) { var m = $('[data-pfb-oa-msg]', oa); m.className = 'alert ' + (ok ? 'success' : 'error'); m.textContent = testo; m.hidden = false; }
  function oaFatto() {
    oaFerma();
    $('[data-pfb-oa-codice]', oa).hidden = true; $('[data-pfb-oa-dropbox]', oa).hidden = true;
    oaMsg(true, 'Collegato! Ora puoi usarlo per i backup.');
    setTimeout(function () { window.location.reload(); }, 1500);
  }
  if (oa) {
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-pfb-oauth]');
      if (!b) { return; }
      oaId = b.getAttribute('data-pfb-oauth');
      var tipo = b.getAttribute('data-tipo');
      var nomi = { gdrive: 'Google Drive', dropbox: 'Dropbox', onedrive: 'OneDrive' };
      $('[data-pfb-oa-titolo]', oa).textContent = 'Collega ' + nomi[tipo];
      $('[data-pfb-oa-codice]', oa).hidden = true; $('[data-pfb-oa-dropbox]', oa).hidden = true; $('[data-pfb-oa-msg]', oa).hidden = true;
      apri(oa);
      if (tipo === 'dropbox') {
        post('storage', { id: oaId, fai: 'dropbox_link' }).then(function (r) {
          if (!r.ok) { oaMsg(false, r.error); return; }
          $('[data-pfb-oa-durl]', oa).href = r.url;
          $('[data-pfb-oa-dcod]', oa).value = '';
          $('[data-pfb-oa-dropbox]', oa).hidden = false;
        });
        return;
      }
      post('storage', { id: oaId, fai: 'avvia' }).then(function (r) {
        if (!r.ok) { oaMsg(false, r.error); return; }
        var a = $('[data-pfb-oa-url]', oa);
        a.href = r.url; a.textContent = r.url.replace(/^https?:\/\//, '');
        $('[data-pfb-oa-cod]', oa).textContent = r.codice;
        $('[data-pfb-oa-codice]', oa).hidden = false;
        var giro = function () {
          oaTimer = setTimeout(function () {
            post('storage', { id: oaId, fai: 'verifica' }).then(function (v) {
              if (oa.hidden) { return; }
              if (!v.ok) { oaFerma(); oaMsg(false, v.error); return; }
              if (v.collegato) { oaFatto(); } else { giro(); }
            }).catch(function () { if (!oa.hidden) { giro(); } });
          }, (r.intervallo || 5) * 1000);
        };
        giro();
      });
    });
    var dvai = $('[data-pfb-oa-dvai]', oa);
    dvai.addEventListener('click', function () {
      var c = $('[data-pfb-oa-dcod]', oa).value.trim();
      if (!c) { return; }
      dvai.disabled = true;
      post('storage', { id: oaId, fai: 'dropbox_codice', codice: c }).then(function (r) {
        dvai.disabled = false;
        if (!r.ok) { oaMsg(false, r.error); return; }
        oaFatto();
      });
    });
  }
})();
