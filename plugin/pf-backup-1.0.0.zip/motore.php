<?php
/*
 * PF Backup — motore: crea e ripristina la fotografia completa del sito. Prefisso: pfb_
 *
 * Un backup e' un file ZIP (facoltativamente cifrato AES-256 con una password) che contiene:
 *   manifest.json           versione del sito e del database, tipo di database, contenuto, elenco delle tabelle
 *   database/NNN_tabella.jsonl   per ogni tabella: la struttura (CREATE TABLE e indici) e tutte le righe
 *   dati/...                tutta la cartella data del sito (copertine, logo, sfondi, media, plugin e loro dati, chiavi),
 *                           tranne sessioni, backup, file temporanei, configurazione del server e chiave privata dell'autore
 *   programmi/...           (facoltativo) i programmi del sito, per spostarlo su un server nuovo
 * Il ripristino rimette database e dati come erano; i programmi non vengono mai sovrascritti.
 */

define('PFB_FORMATO', 1);
define('PFB_NOME_RE', '/^pfb_\d{8}_\d{6}_(completo|db|file)(_[a-z]+)?\.zip$/');

/* ---------------- Cartelle ---------------- */

function pfb_dir($plugin, $sub = '')
{
    $d = $plugin->data_dir() . ($sub !== '' ? '/' . $sub : '');
    if (!is_dir($d)) {
        @mkdir($d, 0770, true);
    }
    if ($sub === '' && !is_file($d . '/.htaccess')) {
        @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return $d;
}

function pfb_archivio($plugin)
{
    pfb_dir($plugin);
    return pfb_dir($plugin, 'archivio');
}

function pfb_nome_ok($n)
{
    return (bool)preg_match(PFB_NOME_RE, (string)$n);
}

/* ---------------- Impostazioni ---------------- */

function pfb_json_setting($plugin, $k, $def)
{
    $v = json_decode((string)$plugin->setting($k, ''), true);
    return is_array($v) ? $v + $def : $def;
}

function pfb_imp($plugin)
{
    return array(
        'conserva' => max(1, min(30, (int)$plugin->setting('conserva', '7'))),
        'conserva_remoto' => max(1, min(30, (int)$plugin->setting('conserva_remoto', '7'))),
        'tieni_locale' => $plugin->setting('tieni_locale', '1') === '1',
        'programmi' => $plugin->setting('programmi', '1') === '1',
        'email' => $plugin->setting('email', 'errori'),
    );
}

function pfb_pian($plugin)
{
    return pfb_json_setting($plugin, 'pianificazione', array('on' => 0, 'freq' => 'giorno', 'ora' => '02:30', 'giorno_sett' => 7, 'giorno_mese' => 1,
        'contenuto' => 'completo', 'dove' => 'locale'));
}

function pfb_password($plugin)
{
    $e = (string)$plugin->setting('password', '');
    if ($e === '') {
        return '';
    }
    require_once APP_ROOT . '/inc/crypto.php';
    return (string)sec_decrypt($e, 'plg-pf-backup-pw');
}

function pfb_cifratura_ok()
{
    return class_exists('ZipArchive') && defined('ZipArchive::EM_AES_256') && method_exists('ZipArchive', 'setEncryptionName');
}

/* ---------------- Schede dei backup (file .json accanto allo zip) ---------------- */

function pfb_meta($plugin, $nome)
{
    $f = pfb_archivio($plugin) . '/' . $nome . '.json';
    $m = is_file($f) ? json_decode((string)file_get_contents($f), true) : null;
    return is_array($m) ? $m : array('nome' => $nome, 'origine' => 'sconosciuta', 'remoto' => array(), 'bloccato' => 0);
}

function pfb_meta_salva($plugin, $nome, $m)
{
    $m['nome'] = $nome;
    @file_put_contents(pfb_archivio($plugin) . '/' . $nome . '.json', json_encode($m, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

// Backup sul server, dal piu' recente
function pfb_locali($plugin)
{
    $out = array();
    foreach ((array)glob(pfb_archivio($plugin) . '/pfb_*.zip') as $f) {
        $n = basename($f);
        if (!pfb_nome_ok($n)) {
            continue;
        }
        $m = pfb_meta($plugin, $n);
        $m['dimensione'] = filesize($f);
        $m['data'] = isset($m['creato']) ? strtotime($m['creato']) : filemtime($f);
        $out[$n] = $m;
    }
    uasort($out, function ($a, $b) { return $b['data'] - $a['data']; });
    return $out;
}

// Nomi bloccati ("da cancellare solo a mano"): valgono anche per lo storage remoto
function pfb_bloccati($plugin)
{
    $b = json_decode((string)$plugin->setting('bloccati', '[]'), true);
    return is_array($b) ? $b : array();
}

function pfb_blocca($plugin, $nome, $si)
{
    $b = array_values(array_diff(pfb_bloccati($plugin), array($nome)));
    if ($si) {
        $b[] = $nome;
    }
    $plugin->save_setting('bloccati', json_encode($b));
    if (is_file(pfb_archivio($plugin) . '/' . $nome)) {
        $m = pfb_meta($plugin, $nome);
        $m['bloccato'] = $si ? 1 : 0;
        pfb_meta_salva($plugin, $nome, $m);
    }
}

function pfb_elimina_locale($plugin, $nome)
{
    if (!pfb_nome_ok($nome)) {
        return;
    }
    @unlink(pfb_archivio($plugin) . '/' . $nome);
    @unlink(pfb_archivio($plugin) . '/' . $nome . '.json');
}

function pfb_dimensione_dir($d)
{
    $t = 0;
    if (!is_dir($d)) {
        return 0;
    }
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile()) {
            $t += $f->getSize();
        }
    }
    return $t;
}

function pfb_mb($b)
{
    return $b >= 1073741824 ? round($b / 1073741824, 2) . ' GB' : ($b >= 1048576 ? round($b / 1048576, 1) . ' MB' : max(1, round($b / 1024)) . ' KB');
}

/* ---------------- Lavoro in corso, avanzamento e log ---------------- */

function pfb_stato_file($plugin)
{
    return pfb_dir($plugin, 'lavoro') . '/stato.json';
}

function pfb_stato($plugin)
{
    $f = pfb_stato_file($plugin);
    $s = is_file($f) ? json_decode((string)file_get_contents($f), true) : null;
    if (!is_array($s)) {
        return null;
    }
    // un lavoro "in corso" il cui processo non c'e' piu' (server riavviato, tempo massimo): risulta interrotto
    if (empty($s['finito']) && !pfb_lock_occupato($plugin) && time() - (int)$s['aggiornato'] > 20) {
        $s['finito'] = 1;
        $s['ok'] = 0;
        $s['errore'] = 'Il lavoro si è interrotto (il server lo ha fermato o è stato riavviato). Riprova; se succede di nuovo guarda il log.';
    }
    return $s;
}

function pfb_lock_occupato($plugin)
{
    $h = @fopen(pfb_dir($plugin, 'lavoro') . '/lock', 'c');
    if (!$h) {
        return false;
    }
    $libero = flock($h, LOCK_EX | LOCK_NB);
    if ($libero) {
        flock($h, LOCK_UN);
    }
    fclose($h);
    return !$libero;
}

// Avanzamento visibile nel pannello; scrive anche nel log del lavoro
function pfb_passo($perc, $testo, $log = true)
{
    $j = &$GLOBALS['PFB_JOB'];
    if (!$j) {
        return;
    }
    $j['perc'] = max(0, min(100, (int)$perc));
    $j['testo'] = (string)$testo;
    $j['aggiornato'] = time();
    if ($log) {
        pfb_log($testo);
    }
    pfb_stato_scrivi();
    if (defined('MAINTENANCE_FILE') && !empty($j['manutenzione'])) {
        @touch(MAINTENANCE_FILE);
    }
}

function pfb_stato_scrivi()
{
    $j = $GLOBALS['PFB_JOB'];
    $f = pfb_stato_file($j['plugin']);
    $copia = $j;
    unset($copia['plugin'], $copia['lock']);
    @file_put_contents($f . '.tmp', json_encode($copia, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @rename($f . '.tmp', $f);
}

function pfb_log($testo)
{
    $j = $GLOBALS['PFB_JOB'];
    if (!$j) {
        return;
    }
    @file_put_contents(pfb_dir($j['plugin'], 'log') . '/' . $j['log'], date('Y-m-d H:i:s') . '  ' . $testo . "\n", FILE_APPEND | LOCK_EX);
}

/*
 * Esegue un lavoro (backup, ripristino, invio, scaricamento) con il lucchetto, l'avanzamento e il log.
 * $fn($plugin) fa il lavoro e restituisce il testo finale; un'eccezione = lavoro non riuscito.
 */
function pfb_esegui($plugin, $tipo, $titolo, $fn)
{
    $h = @fopen(pfb_dir($plugin, 'lavoro') . '/lock', 'c');
    if (!$h || !flock($h, LOCK_EX | LOCK_NB)) {
        throw new Exception('C\'è già un backup o un ripristino in corso: aspetta che finisca.');
    }
    if (function_exists('set_time_limit')) {
        @set_time_limit(0);
    }
    @ignore_user_abort(true);
    $id = date('Ymd_His') . '_' . substr(bin2hex(random_bytes(3)), 0, 6);
    $GLOBALS['PFB_JOB'] = array('plugin' => $plugin, 'lock' => $h, 'id' => $id, 'tipo' => $tipo, 'titolo' => $titolo, 'perc' => 0, 'testo' => 'Inizio…',
        'inizio' => time(), 'aggiornato' => time(), 'finito' => 0, 'ok' => 0, 'errore' => '', 'esito' => '', 'log' => $id . '_' . $tipo . '.log',
        'utente' => function_exists('current_uid') ? current_uid() : 0, 'manutenzione' => 0);
    pfb_log('== ' . $titolo . ' (Libreria di Casa ' . APP_VERSION . ', PHP ' . PHP_VERSION . ', ' . (PHP_SAPI === 'cli' ? 'lavori automatici' : 'dal pannello') . ')');
    pfb_stato_scrivi();
    $ok = false;
    $esito = '';
    try {
        $esito = (string)$fn($plugin);
        $ok = true;
    } catch (Throwable $e) {
        $esito = $e->getMessage();
        pfb_log('ERRORE: ' . $esito);
    }
    $j = &$GLOBALS['PFB_JOB'];
    if (!empty($j['manutenzione']) && defined('MAINTENANCE_FILE')) {
        @unlink(MAINTENANCE_FILE);
        $j['manutenzione'] = 0;
    }
    $j['finito'] = 1;
    $j['ok'] = $ok ? 1 : 0;
    $j['perc'] = $ok ? 100 : $j['perc'];
    $j['esito'] = $ok ? $esito : '';
    $j['errore'] = $ok ? '' : $esito;
    $j['testo'] = $ok ? $esito : 'Non riuscito: ' . $esito;
    $j['aggiornato'] = time();
    pfb_log($ok ? '== Fatto: ' . $esito : '== Non riuscito.');
    pfb_stato_scrivi();
    pfb_pulisci_log($plugin);
    flock($h, LOCK_UN);
    fclose($h);
    $GLOBALS['PFB_JOB'] = null;
    try {
        $plugin->log($titolo . ($ok ? ': ' . $esito : ' NON riuscito: ' . $esito), $ok ? 'info' : 'warn');
        if ($tipo !== 'ripristino' || !$ok) {
            pfb_avvisa($plugin, $titolo, $ok, $esito);
        }
    } catch (Throwable $e) {
        // gli avvisi non devono far fallire il lavoro
    }
    return array($ok, $esito);
}

function pfb_pulisci_log($plugin)
{
    $f = (array)glob(pfb_dir($plugin, 'log') . '/*.log');
    rsort($f);
    foreach (array_slice($f, 100) as $x) {
        @unlink($x);
    }
}

// Esito: campanella agli Admin quando qualcosa non va; email (plugin Notifiche email) secondo l'impostazione
function pfb_avvisa($plugin, $titolo, $ok, $esito)
{
    $imp = pfb_imp($plugin);
    if (!$ok) {
        $ids = db()->query("SELECT id FROM users WHERE role = 'admin' AND active = 1")->fetchAll(PDO::FETCH_COLUMN);
        $plugin->notifica('PF Backup: ' . $titolo . ' non riuscito — ' . str_cut($esito, 160), $plugin->admin_url('backup', array('tab' => 'log')),
            array('to' => array_map('intval', $ids), 'gruppo' => 'errore'));
    }
    if ($imp['email'] === 'sempre' || ($imp['email'] === 'errori' && !$ok)) {
        if (!empty($GLOBALS['PLG_OBJ']['notifiche-email']) && empty($GLOBALS['PLG_FAILED']['notifiche-email']) && function_exists('ne_invia')) {
            ne_invia($GLOBALS['PLG_OBJ']['notifiche-email'], 'pf-backup', 'PF Backup: ' . $titolo . ($ok ? ' riuscito' : ' NON riuscito'),
                $ok ? 'Il lavoro è andato a buon fine.' : 'Il lavoro non è riuscito: controlla il log in Gestione → Plugin → PF Backup.', array(array('Esito', $esito)), !$ok);
        }
    }
}

/* ---------------- Consegna subito la pagina e lavora dopo ---------------- */

function pfb_rilascia($json = null)
{
    @ignore_user_abort(true);
    if ($json !== null) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        $buf = json_encode($json, JSON_UNESCAPED_UNICODE);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
    } else {
        $buf = '';
        while (ob_get_level() > 0) {
            $buf = ob_get_clean() . $buf;
        }
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    if (function_exists('fastcgi_finish_request')) {
        echo $buf;
        @fastcgi_finish_request();
        return;
    }
    if (PHP_SAPI === 'cli' || headers_sent()) {
        echo $buf;
        return;
    }
    if (function_exists('apache_setenv')) {
        @apache_setenv('no-gzip', '1');
    }
    header('Connection: close');
    header('Content-Length: ' . strlen($buf));
    echo $buf;
    @flush();
}

/* ================= BACKUP ================= */

function pfb_nuovo_nome($contenuto, $origine)
{
    return 'pfb_' . date('Ymd_His') . '_' . $contenuto . ($origine !== '' ? '_' . $origine : '') . '.zip';
}

// Tabelle del database del sito (tutte: anche quelle dei plugin)
function pfb_tabelle()
{
    if (DB_DRIVER === 'sqlite') {
        return db()->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);
    }
    $out = array();
    foreach (db()->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM) as $r) {
        if (strtoupper($r[1]) === 'BASE TABLE') {
            $out[] = $r[0];
        }
    }
    sort($out);
    return $out;
}

function pfb_q($t)
{
    return '`' . str_replace('`', '``', $t) . '`';
}

// Struttura di una tabella: array(create, indici)
function pfb_struttura($t)
{
    if (DB_DRIVER === 'sqlite') {
        $st = db()->prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?");
        $st->execute(array($t));
        $c = (string)$st->fetchColumn();
        $st->closeCursor();
        $st = db()->prepare("SELECT sql FROM sqlite_master WHERE type = 'index' AND tbl_name = ? AND sql IS NOT NULL");
        $st->execute(array($t));
        return array($c, $st->fetchAll(PDO::FETCH_COLUMN));
    }
    $r = db()->query('SHOW CREATE TABLE ' . pfb_q($t))->fetch(PDO::FETCH_NUM);
    return array((string)$r[1], array());
}

// Scrive una tabella in un file JSONL: prima riga la struttura, poi una riga (array JSON) per ogni record. Restituisce il numero di righe.
function pfb_esporta_tabella($t, $file)
{
    list($crea, $indici) = pfb_struttura($t);
    $fh = fopen($file, 'wb');
    $pdo = db();
    $mysql = DB_DRIVER !== 'sqlite';
    if ($mysql) {
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false); // le righe arrivano una alla volta: niente memoria piena
    }
    try {
        $st = $pdo->query('SELECT * FROM ' . pfb_q($t));
        $cols = array();
        for ($i = 0; $i < $st->columnCount(); $i++) {
            $m = $st->getColumnMeta($i);
            $cols[] = $m['name'];
        }
        fwrite($fh, json_encode(array('tabella' => $t, 'colonne' => $cols, 'crea' => $crea, 'indici' => $indici), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
        $n = 0;
        while (($r = $st->fetch(PDO::FETCH_NUM)) !== false) {
            foreach ($r as $k => $v) {
                if (is_string($v) && !preg_match('//u', $v)) {
                    $r[$k] = array('b64' => base64_encode($v)); // dati non di testo: viaggiano in base64
                }
            }
            fwrite($fh, json_encode($r, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
            $n++;
        }
        $st->closeCursor();
    } finally {
        if ($mysql) {
            $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
        }
        fclose($fh);
    }
    return $n;
}

// File della cartella data che NON vanno nel backup (percorsi relativi, con "/")
function pfb_escluso($rel)
{
    $rel = ltrim(str_replace('\\', '/', $rel), '/');
    foreach (array('sessions/', 'backup/', 'updates/', 'geo/', 'repo/', 'plugin_dati/pf-backup/', 'tmp/', 'cache/') as $p) {
        if (strpos($rel . '/', $p) === 0) {
            return true;
        }
    }
    $base = basename($rel);
    if (in_array($rel, array('config.local.php', 'maintenance.lock', 'migrate.lock', 'periodic.lock', 'firma/chiave_privata.json'), true)) {
        return true;
    }
    return (bool)preg_match('/\.(sqlite|sqlite3|db|sqlite\.bak|parziale|tmp|lock)$/i', $base) && $base !== 'installed.lock'
        || strpos($base, 'tmp-') === 0;
}

// Elenco dei file da salvare: array(percorso_completo => nome_nello_zip)
function pfb_file_dati()
{
    $out = array();
    $base = rtrim(str_replace('\\', '/', DATA_DIR), '/');
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(DATA_DIR, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
    foreach ($it as $f) {
        if (!$f->isFile() || $f->isLink()) {
            continue;
        }
        $rel = substr(str_replace('\\', '/', $f->getPathname()), strlen($base) + 1);
        if (!pfb_escluso($rel)) {
            $out[$f->getPathname()] = 'dati/' . $rel;
        }
    }
    // chiave pubblica dell'autore (fuori da data nelle installazioni senza Docker)
    $pub = dirname(APP_ROOT) . '/CONF/firma_autore.json';
    if (is_file($pub)) {
        $out[$pub] = 'conf/firma_autore.json';
    }
    return $out;
}

function pfb_file_programmi()
{
    $out = array();
    $root = dirname(APP_ROOT);
    foreach (array('public_html', 'CONF', 'strumenti', 'sql', 'esempi') as $d) {
        if (!is_dir($root . '/' . $d)) {
            continue;
        }
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/' . $d, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $f) {
            if (!$f->isFile() || $f->isLink()) {
                continue;
            }
            $rel = substr(str_replace('\\', '/', $f->getPathname()), strlen(str_replace('\\', '/', $root)) + 1);
            if (in_array(basename($rel), array('config.local.php'), true)) {
                continue;
            }
            $out[$f->getPathname()] = 'programmi/' . $rel;
        }
    }
    return $out;
}

/*
 * Crea un backup. $contenuto: completo | db | file. $origine: manuale | pianificato | sicurezza.
 * Restituisce il nome del file nell'archivio.
 */
function pfb_crea($plugin, $contenuto, $origine, $con_programmi = null)
{
    if (!class_exists('ZipArchive')) {
        throw new Exception('Manca l\'estensione zip di PHP.');
    }
    $contenuto = in_array($contenuto, array('completo', 'db', 'file'), true) ? $contenuto : 'completo';
    $imp = pfb_imp($plugin);
    $con_programmi = $con_programmi === null ? $imp['programmi'] : (bool)$con_programmi;
    $pw = pfb_password($plugin);
    if ($pw !== '' && !pfb_cifratura_ok()) {
        throw new Exception('Il PHP di questo server non sa cifrare gli ZIP: togli la password in Impostazioni o aggiorna PHP.');
    }
    $nome = pfb_nuovo_nome($contenuto, $origine === 'manuale' ? '' : $origine);
    $arch = pfb_archivio($plugin);
    $tmp = pfb_dir($plugin, 'lavoro') . '/tmp-' . substr($nome, 4, 15);
    @mkdir($tmp, 0770, true);
    $libero = @disk_free_space($arch);
    pfb_passo(2, 'Backup ' . $nome . ($pw !== '' ? ' (cifrato con la password)' : '') . ($libero ? ' — spazio libero sul server: ' . pfb_mb($libero) : ''));
    try {
        $manifest = array('formato' => PFB_FORMATO, 'app' => 'libreria-di-casa', 'creato_da' => 'PF Backup ' . $plugin->version, 'app_version' => APP_VERSION,
            'db_version' => (int)setting('db_version', '1'), 'driver' => DB_DRIVER, 'creato' => date('c'), 'contenuto' => $contenuto, 'origine' => $origine,
            'sito' => setting('brand_title'), 'programmi' => 0, 'tabelle' => array(), 'file' => 0, 'cifrato' => $pw !== '' ? 1 : 0,
            'plugin' => db()->query('SELECT id, version FROM plugins')->fetchAll(PDO::FETCH_KEY_PAIR));
        $db_files = array();
        if ($contenuto !== 'file') {
            $tab = pfb_tabelle();
            foreach ($tab as $i => $t) {
                $f = $tmp . '/' . sprintf('%03d', $i) . '_' . preg_replace('/[^A-Za-z0-9_]/', '_', $t) . '.jsonl';
                $n = pfb_esporta_tabella($t, $f);
                $manifest['tabelle'][$t] = $n;
                $db_files[$f] = 'database/' . basename($f);
                pfb_passo(3 + (int)(30 * ($i + 1) / max(1, count($tab))), 'Database: ' . $t . ' (' . $n . ' righe)', false);
            }
            pfb_log('Database: ' . count($tab) . ' tabelle, ' . array_sum($manifest['tabelle']) . ' righe.');
        }
        $files = array();
        if ($contenuto !== 'db') {
            $files = pfb_file_dati();
            if ($con_programmi) {
                $files += pfb_file_programmi();
                $manifest['programmi'] = 1;
            }
            $manifest['file'] = count($files);
            pfb_log('File: ' . count($files) . ($con_programmi ? ' (compresi i programmi del sito)' : '') . ', ' . pfb_mb(array_sum(array_map('filesize', array_keys($files)))) . '.');
        }
        $parz = $arch . '/' . $nome . '.parziale';
        @unlink($parz);
        $z = new ZipArchive();
        if ($z->open($parz, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new Exception('Non riesco a creare il file del backup (spazio o permessi della cartella data).');
        }
        $aggiungi = function ($nome_zip) use ($z, $pw) {
            if ($pw !== '') {
                $z->setEncryptionName($nome_zip, ZipArchive::EM_AES_256, $pw);
            }
            if (preg_match('/\.(jpe?g|png|webp|gif|mp4|mp3|m4a|pdf|zip|gz|woff2?)$/i', $nome_zip)) {
                $z->setCompressionName($nome_zip, ZipArchive::CM_STORE); // gia' compressi: si fa prima
            }
        };
        $z->addFromString('manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $aggiungi('manifest.json');
        foreach ($db_files + $files as $path => $nz) {
            $z->addFile($path, $nz);
            $aggiungi($nz);
        }
        // il lavoro vero (lettura e compressione) avviene alla chiusura: l'avanzamento arriva da libzip
        if (method_exists($z, 'registerProgressCallback')) {
            $z->registerProgressCallback(0.02, function ($r) {
                pfb_passo(35 + (int)(55 * $r), 'Compressione: ' . (int)(100 * $r) . '%', false);
            });
        }
        pfb_passo(35, 'Compressione di ' . (count($db_files) + count($files) + 1) . ' elementi…');
        if (!$z->close()) {
            throw new Exception('Scrittura del file del backup non riuscita (spazio esaurito?).');
        }
        // controllo: lo zip si riapre e il manifest si legge (con la password, se c'e')
        $v = new ZipArchive();
        if ($v->open($parz) !== true) {
            throw new Exception('Il file del backup appena creato non si apre.');
        }
        if ($pw !== '') {
            $v->setPassword($pw);
        }
        $man = $v->getFromName('manifest.json');
        $num = $v->numFiles;
        $v->close();
        if (!$man || $num !== count($db_files) + count($files) + 1) {
            throw new Exception('Controllo del backup non riuscito: il file è incompleto.');
        }
        rename($parz, $arch . '/' . $nome);
        pfb_meta_salva($plugin, $nome, array('creato' => date('c'), 'contenuto' => $contenuto, 'origine' => $origine, 'app_version' => APP_VERSION,
            'db_version' => $manifest['db_version'], 'cifrato' => $manifest['cifrato'], 'programmi' => $manifest['programmi'], 'remoto' => array(), 'bloccato' => 0,
            'log' => isset($GLOBALS['PFB_JOB']['log']) ? $GLOBALS['PFB_JOB']['log'] : ''));
        pfb_passo(92, 'Backup creato: ' . $nome . ' (' . pfb_mb(filesize($arch . '/' . $nome)) . ').');
        return $nome;
    } finally {
        foreach ((array)glob($tmp . '/*') as $f) {
            @unlink($f);
        }
        @rmdir($tmp);
        @unlink($arch . '/' . $nome . '.parziale');
    }
}

// Tiene solo gli ultimi N backup sul server (quelli bloccati e le copie di sicurezza non contano)
function pfb_pulisci_locali($plugin)
{
    $n = pfb_imp($plugin)['conserva'];
    $bl = pfb_bloccati($plugin);
    $i = 0;
    $s = 0;
    foreach (pfb_locali($plugin) as $nome => $m) {
        if (in_array($nome, $bl, true) || !empty($m['bloccato'])) {
            continue;
        }
        // copie di sicurezza fatte prima di un ripristino: se ne tengono le ultime 3, a parte
        if (strpos($nome, '_sicurezza') !== false) {
            if (++$s > 3) {
                pfb_elimina_locale($plugin, $nome);
            }
            continue;
        }
        if (++$i > $n) {
            pfb_elimina_locale($plugin, $nome);
            pfb_log('Eliminato il backup vecchio ' . $nome . ' (se ne tengono ' . $n . ').');
        }
    }
}

// Backup completo di un lavoro: crea, eventualmente manda allo storage, pulisce
function pfb_lavoro_backup($plugin, $contenuto, $dove, $origine)
{
    $nome = pfb_crea($plugin, $contenuto, $origine);
    $testo = 'Backup ' . $nome . ' creato';
    if ($dove === 'remoto') {
        $s = pfb_storage_attivo($plugin);
        if (!$s) {
            throw new Exception('Backup creato sul server, ma non c\'è uno storage remoto scelto (scheda Storage remoto).');
        }
        pfb_invia($plugin, $nome, $s);
        $testo .= ' e copiato su ' . pfb_storage_nome($s);
        if (!pfb_imp($plugin)['tieni_locale'] && !in_array($nome, pfb_bloccati($plugin), true)) {
            pfb_elimina_locale($plugin, $nome);
            pfb_log('Copia sul server eliminata (impostazione: non tenere la copia locale dopo l\'invio).');
        }
    }
    pfb_pulisci_locali($plugin);
    return $testo . '.';
}

// Manda un backup allo storage e tiene solo gli ultimi N lassu'
function pfb_invia($plugin, $nome, $s)
{
    $path = pfb_archivio($plugin) . '/' . $nome;
    if (!is_file($path)) {
        throw new Exception('Backup non trovato sul server: ' . $nome);
    }
    pfb_passo(93, 'Invio a ' . pfb_storage_nome($s) . ' (' . pfb_mb(filesize($path)) . ')…');
    $GLOBALS['PFB_PROGRESSO'] = function ($fatto, $tot) {
        if ($tot > 0) {
            pfb_passo(93 + (int)(6 * $fatto / $tot), 'Invio: ' . pfb_mb($fatto) . ' di ' . pfb_mb($tot), false);
        }
    };
    pfb_storage_call($plugin, $s, 'put', $path, $nome);
    $GLOBALS['PFB_PROGRESSO'] = null;
    pfb_log('Inviato a ' . pfb_storage_nome($s) . '.');
    $m = pfb_meta($plugin, $nome);
    $m['remoto'] = array_values(array_unique(array_merge(isset($m['remoto']) ? (array)$m['remoto'] : array(), array($s['id']))));
    pfb_meta_salva($plugin, $nome, $m);
    // pulizia dello storage
    try {
        $tutti = pfb_storage_call($plugin, $s, 'lista');
        $bl = pfb_bloccati($plugin);
        $n = pfb_imp($plugin)['conserva_remoto'];
        uasort($tutti, function ($a, $b) { return strcmp($b['nome'], $a['nome']); });
        $i = 0;
        foreach ($tutti as $x) {
            if (in_array($x['nome'], $bl, true) || strpos($x['nome'], '_sicurezza') !== false) {
                continue;
            }
            if (++$i > $n) {
                pfb_storage_call($plugin, $s, 'elimina', $x['nome']);
                pfb_log('Eliminato da ' . pfb_storage_nome($s) . ' il backup vecchio ' . $x['nome'] . '.');
            }
        }
    } catch (Exception $e) {
        pfb_log('Avviso: pulizia dello storage non riuscita: ' . $e->getMessage());
    }
}

/* ================= RIPRISTINO ================= */

// Legge il manifest di un backup (con la password, se cifrato). Eccezione con un messaggio chiaro se non va bene.
function pfb_leggi_manifest($path, $pw)
{
    $z = new ZipArchive();
    if ($z->open($path) !== true) {
        throw new Exception('Il file non è un backup valido (ZIP non leggibile).');
    }
    $st = $z->statName('manifest.json');
    if (!$st) {
        $z->close();
        throw new Exception('Questo ZIP non è un backup di PF Backup (manca manifest.json).');
    }
    if ($pw !== '') {
        $z->setPassword($pw);
    }
    $raw = $z->getFromName('manifest.json');
    $cifrato = isset($st['encryption_method']) && $st['encryption_method'] !== ZipArchive::EM_NONE;
    $z->close();
    if ($raw === false) {
        throw new Exception($cifrato ? ($pw === '' ? 'Il backup è cifrato: scrivi la sua password.' : 'Password del backup sbagliata.') : 'Il backup è danneggiato.');
    }
    $m = json_decode($raw, true);
    if (!is_array($m) || (isset($m['app']) && $m['app'] !== 'libreria-di-casa') || empty($m['formato'])) {
        throw new Exception('Il manifest del backup non è valido.');
    }
    return $m;
}

// Il backup si puo' ripristinare su questo sito? Restituisce '' oppure il motivo
function pfb_compatibile($m)
{
    if ((int)$m['formato'] > PFB_FORMATO) {
        return 'Il backup è stato fatto con una versione più nuova di PF Backup: aggiorna prima il plugin.';
    }
    if (version_compare((string)$m['app_version'], APP_VERSION, '>')) {
        return 'Il backup è della versione ' . $m['app_version'] . ' della Libreria, questo sito è alla ' . APP_VERSION . ': aggiorna prima il sito.';
    }
    if ($m['contenuto'] !== 'file' && $m['driver'] !== DB_DRIVER) {
        return 'Il backup è di un database ' . ($m['driver'] === 'sqlite' ? 'SQLite' : 'MySQL/MariaDB') . ', questo sito usa ' . (DB_DRIVER === 'sqlite' ? 'SQLite' : 'MySQL/MariaDB') . '.';
    }
    return '';
}

/*
 * Ripristino completo. Prima una copia di sicurezza dello stato attuale, poi manutenzione, database, file.
 * $sicurezza: false solo per le prove automatiche.
 */
function pfb_ripristina($plugin, $nome, $pw, $sicurezza = true)
{
    $path = pfb_archivio($plugin) . '/' . $nome;
    if (!pfb_nome_ok($nome) || !is_file($path)) {
        throw new Exception('Backup non trovato sul server.');
    }
    pfb_passo(1, 'Controllo del backup ' . $nome . '…');
    $m = pfb_leggi_manifest($path, $pw);
    $perche = pfb_compatibile($m);
    if ($perche !== '') {
        throw new Exception($perche);
    }
    pfb_log('Backup del ' . $m['creato'] . ', Libreria ' . $m['app_version'] . ', contenuto: ' . $m['contenuto'] . ', ' . count($m['tabelle']) . ' tabelle, ' . (int)$m['file'] . ' file.');
    if ($sicurezza) {
        pfb_passo(3, 'Copia di sicurezza dello stato attuale (per tornare indietro se servisse)…');
        $GLOBALS['PFB_SOTTO'] = true;
        $sic = pfb_crea($plugin, 'completo', 'sicurezza', false);
        $GLOBALS['PFB_SOTTO'] = false;
        pfb_blocca($plugin, $sic, false);
        pfb_log('Copia di sicurezza: ' . $sic);
    }
    // manutenzione: gli altri utenti vedono "Torniamo subito"
    $GLOBALS['PFB_JOB']['manutenzione'] = 1;
    @file_put_contents(MAINTENANCE_FILE, date('c') . " ripristino PF Backup\n");
    pfb_passo(30, 'Sito in manutenzione durante il ripristino.');

    // cose di PF Backup da tenere: il plugin stesso (file e riga) e, se il backup non le ha, le sue impostazioni
    $pdo = db();
    $mia_riga = $pdo->prepare('SELECT * FROM plugins WHERE id = ?');
    $mia_riga->execute(array($plugin->id));
    $mia_riga = $mia_riga->fetch(PDO::FETCH_ASSOC);
    $mie_imp = $pdo->prepare('SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE ?');
    $mie_imp->execute(array('plg.' . $plugin->id . '.%'));
    $mie_imp = $mie_imp->fetchAll(PDO::FETCH_KEY_PAIR);
    $chiave_prima = is_file(DATA_DIR . '/secret.key') ? trim((string)file_get_contents(DATA_DIR . '/secret.key')) : '';

    $z = new ZipArchive();
    if ($z->open($path) !== true) {
        throw new Exception('Il backup non si apre.');
    }
    if ($pw !== '') {
        $z->setPassword($pw);
    }
    $tmp = pfb_dir($plugin, 'lavoro') . '/rip-' . date('His');
    @mkdir($tmp, 0770, true);
    try {
        if ($m['contenuto'] !== 'file') {
            pfb_ripristina_db($plugin, $z, $tmp);
        }
        if ($m['contenuto'] !== 'db') {
            pfb_ripristina_file($plugin, $z);
        }
    } finally {
        $z->close();
        foreach ((array)glob($tmp . '/*') as $f) {
            @unlink($f);
        }
        @rmdir($tmp);
    }

    // PF Backup resta installato e attivo, con la versione di adesso
    if ($mia_riga) {
        $pdo->prepare('DELETE FROM plugins WHERE id = ?')->execute(array($plugin->id));
        $cols = array_keys($mia_riga);
        $pdo->prepare('INSERT INTO plugins (' . implode(', ', $cols) . ') VALUES (' . implode(', ', array_fill(0, count($cols), '?')) . ')')->execute(array_values($mia_riga));
    }
    $chiave_dopo = is_file(DATA_DIR . '/secret.key') ? trim((string)file_get_contents(DATA_DIR . '/secret.key')) : '';
    $st = $pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key LIKE ?');
    $st->execute(array('plg.' . $plugin->id . '.%'));
    $ci_sono = (int)$st->fetchColumn();
    $st->closeCursor();
    if (!$ci_sono && $chiave_prima === $chiave_dopo) {
        $ins = $pdo->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)');
        foreach ($mie_imp as $k => $v) {
            $ins->execute(array($k, $v));
        }
    }
    // database alla versione dei programmi di adesso
    if (function_exists('load_settings')) {
        load_settings(true);
    }
    require_once APP_ROOT . '/inc/migrate.php';
    $mig = db_migrate();
    if (!$mig[0]) {
        throw new Exception('Dati ripristinati, ma l\'aggiornamento del database non è riuscito: ' . $mig[1]);
    }
    if ((int)$m['db_version'] < (int)APP_DB_VERSION) {
        pfb_log('Database aggiornato dalla versione ' . $m['db_version'] . ' alla ' . APP_DB_VERSION . '.');
    }
    pfb_passo(99, 'Ripristino completato.');
    app_log('ripristino_pf_backup', 'Sito ripristinato dal backup ' . $nome . ' (PF Backup)', 'warn');
    return 'Sito ripristinato dal backup ' . $nome . ($sicurezza ? ' — lo stato di prima è nella copia di sicurezza' : '') . '.';
}

function pfb_ripristina_db($plugin, $z, $tmp)
{
    $pdo = db();
    $sqlite = DB_DRIVER === 'sqlite';
    $voci = array();
    for ($i = 0; $i < $z->numFiles; $i++) {
        $n = $z->getNameIndex($i);
        if (strpos($n, 'database/') === 0 && substr($n, -6) === '.jsonl') {
            $voci[] = $n;
        }
    }
    sort($voci);
    if (isset($GLOBALS['st_chk']) && $GLOBALS['st_chk'] instanceof PDOStatement) {
        $GLOBALS['st_chk']->closeCursor(); // programmi 1.9.18 e precedenti con SQLite: lettura rimasta aperta
    }
    $pdo->exec($sqlite ? 'PRAGMA foreign_keys = OFF' : 'SET FOREIGN_KEY_CHECKS = 0');
    try {
        foreach ($voci as $k => $n) {
            $file = $tmp . '/' . basename($n);
            $in = $z->getStream($n);
            if (!$in) {
                throw new Exception('Non riesco a leggere ' . $n . ' dal backup (password sbagliata?).');
            }
            $out = fopen($file, 'wb');
            stream_copy_to_stream($in, $out);
            fclose($in);
            fclose($out);
            $fh = fopen($file, 'rb');
            $h = json_decode((string)fgets($fh), true);
            if (!is_array($h) || empty($h['tabella']) || empty($h['crea'])) {
                fclose($fh);
                throw new Exception('Il file ' . $n . ' del backup è danneggiato.');
            }
            $t = $h['tabella'];
            $pdo->exec('DROP TABLE IF EXISTS ' . pfb_q($t));
            $pdo->exec($h['crea']);
            $righe = 0;
            if ($h['colonne']) {
                $ins = $pdo->prepare('INSERT INTO ' . pfb_q($t) . ' (' . implode(', ', array_map('pfb_q', $h['colonne'])) . ') VALUES ('
                    . implode(', ', array_fill(0, count($h['colonne']), '?')) . ')');
                $pdo->beginTransaction();
                while (($l = fgets($fh)) !== false) {
                    $r = json_decode($l, true);
                    if (!is_array($r)) {
                        continue;
                    }
                    foreach ($r as $c => $v) {
                        if (is_array($v) && isset($v['b64'])) {
                            $r[$c] = base64_decode($v['b64']);
                        }
                    }
                    $ins->execute($r);
                    if (++$righe % 1000 === 0) {
                        $pdo->commit();
                        $pdo->beginTransaction();
                    }
                }
                $pdo->commit();
            }
            fclose($fh);
            @unlink($file);
            foreach ((array)$h['indici'] as $sql) {
                try {
                    $pdo->exec($sql);
                } catch (Exception $e) {
                    // indice gia' presente
                }
            }
            pfb_passo(31 + (int)(40 * ($k + 1) / max(1, count($voci))), 'Database: ' . $t . ' (' . $righe . ' righe)', false);
        }
    } finally {
        $pdo->exec($sqlite ? 'PRAGMA foreign_keys = ON' : 'SET FOREIGN_KEY_CHECKS = 1');
    }
    pfb_log('Database ripristinato: ' . count($voci) . ' tabelle.');
}

/*
 * File: le cartelle del backup prendono il posto di quelle attuali (i file che nel backup non c'erano vengono tolti),
 * tranne le cose escluse dal backup (sessioni, backup, configurazione del server…) e PF Backup stesso.
 */
function pfb_ripristina_file($plugin, $z)
{
    $base = rtrim(str_replace('\\', '/', DATA_DIR), '/');
    $mio = 'plugins/' . $plugin->id . '/';
    $nel_backup = array();
    $tot = $z->numFiles;
    $fatti = 0;
    for ($i = 0; $i < $tot; $i++) {
        $n = $z->getNameIndex($i);
        if (strpos($n, 'dati/') === 0) {
            $rel = substr($n, 5);
        } elseif ($n === 'conf/firma_autore.json') {
            // la chiave pubblica dell'autore si scrive solo se il sito non ne ha gia' una
            $dest = dirname(APP_ROOT) . '/CONF/firma_autore.json';
            if (!is_file($dest) && is_writable(dirname($dest))) {
                @file_put_contents($dest, $z->getFromIndex($i));
            }
            continue;
        } else {
            continue;
        }
        if ($rel === '' || substr($rel, -1) === '/' || strpos($rel, '..') !== false || pfb_escluso($rel) || strpos($rel, $mio) === 0) {
            continue;
        }
        $dest = $base . '/' . $rel;
        @mkdir(dirname($dest), 0770, true);
        $in = $z->getStream($n);
        if (!$in) {
            throw new Exception('Non riesco a leggere ' . $n . ' dal backup.');
        }
        $out = @fopen($dest . '.pfbtmp', 'wb');
        if (!$out) {
            fclose($in);
            throw new Exception('Non riesco a scrivere ' . $rel . ' (permessi della cartella data).');
        }
        stream_copy_to_stream($in, $out);
        fclose($in);
        fclose($out);
        @rename($dest . '.pfbtmp', $dest);
        $nel_backup[$rel] = 1;
        if (++$fatti % 50 === 0) {
            pfb_passo(72 + (int)(24 * $i / max(1, $tot)), 'File: ' . $fatti . ' ripristinati', false);
        }
    }
    // togli i file che nel backup non c'erano (cartelle dei contenuti), ma mai quelli esclusi o di PF Backup
    $tolti = 0;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(DATA_DIR, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) {
        $rel = substr(str_replace('\\', '/', $f->getPathname()), strlen($base) + 1);
        if (!$f->isFile() || pfb_escluso($rel) || strpos($rel, $mio) === 0 || isset($nel_backup[$rel])) {
            continue;
        }
        if (preg_match('#^(covers|uploads|media|plugins|plugin_dati|firma)/#', $rel) && basename($rel) !== '.htaccess') {
            @unlink($f->getPathname());
            $tolti++;
        }
    }
    pfb_log('File ripristinati: ' . $fatti . ($tolti ? ', tolti ' . $tolti . ' file che nel backup non c\'erano' : '') . '.');
}

/* ================= PIANIFICAZIONE ================= */

function pfb_freq()
{
    return array('12ore' => 'Ogni 12 ore', 'giorno' => 'Ogni giorno', 'settimana' => 'Ogni settimana', '15giorni' => 'Ogni 15 giorni', 'mese' => 'Ogni mese');
}

// Prossima esecuzione dopo $da (timestamp), secondo la pianificazione
function pfb_prossimo($p, $da)
{
    list($h, $i) = array_map('intval', explode(':', preg_match('/^\d{2}:\d{2}$/', $p['ora']) ? $p['ora'] : '02:30'));
    $giorno = function ($t) use ($h, $i) {
        return mktime($h, $i, 0, (int)date('n', $t), (int)date('j', $t), (int)date('Y', $t));
    };
    $c = $giorno($da);
    switch ($p['freq']) {
        case '12ore':
            foreach (array($c, $c + 43200, $c + 86400) as $x) {
                if ($x > $da) {
                    return $x;
                }
            }
            return $c + 86400;
        case 'settimana':
            $gs = max(1, min(7, (int)$p['giorno_sett']));
            for ($k = 0; $k <= 7; $k++) {
                $x = $giorno(strtotime('+' . $k . ' day', $da));
                if ((int)date('N', $x) === $gs && $x > $da) {
                    return $x;
                }
            }
            return $c + 7 * 86400;
        case '15giorni':
            return $c > $da ? $c : $giorno(strtotime('+15 day', $da));
        case 'mese':
            $gm = max(1, min(28, (int)$p['giorno_mese']));
            $x = mktime($h, $i, 0, (int)date('n', $da), $gm, (int)date('Y', $da));
            return $x > $da ? $x : mktime($h, $i, 0, (int)date('n', $da) + 1, $gm, (int)date('Y', $da));
        default:
            return $c > $da ? $c : $giorno(strtotime('+1 day', $da));
    }
}

function pfb_pian_prossimo($plugin)
{
    $p = pfb_pian($plugin);
    if (empty($p['on'])) {
        return 0;
    }
    $ult = (int)$plugin->setting('pian_ultimo', '0');
    $da = (int)$plugin->setting('pian_da', '0'); // quando e' stata salvata la pianificazione
    return pfb_prossimo($p, max($ult, $da));
}

// Chiamata dai lavori periodici del sito: se e' l'ora, fa il backup pianificato
function pfb_pianificati($plugin, $da_cron)
{
    $p = pfb_pian($plugin);
    $prossimo = pfb_pian_prossimo($plugin);
    if (empty($p['on']) || !$prossimo || time() < $prossimo || pfb_lock_occupato($plugin)) {
        return;
    }
    $plugin->save_setting('pian_ultimo', (string)time());
    if (!$da_cron) {
        pfb_rilascia(); // durante una visita: prima si consegna la pagina
    }
    pfb_esegui($plugin, 'backup', 'Backup pianificato (' . strtolower(pfb_freq()[$p['freq']] ?? $p['freq']) . ')', function ($plugin) use ($p) {
        return pfb_lavoro_backup($plugin, $p['contenuto'], $p['dove'], 'pianificato');
    });
}
