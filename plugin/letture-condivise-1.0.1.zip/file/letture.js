// Letture condivise: cuore e commenti senza ricaricare la pagina, «Mostra altri», nascondere un libro dalla sua scheda
(function () {
  'use strict';
  var cfg = {};
  try { cfg = JSON.parse(document.getElementById('app-config').textContent); } catch (e) { /* niente */ }
  var API = 'api.php?action=plg&p=letture-condivise&f=';
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  function manda(nome, dati) {
    var fd = new FormData();
    fd.append('csrf', cfg.csrf || '');
    Object.keys(dati).forEach(function (k) { fd.append(k, dati[k]); });
    return fetch(API + nome, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf || '' } })
      .then(function (r) { return r.json(); });
  }
  function avviso(t) {
    var a = document.createElement('div');
    a.className = 'lc-toast';
    a.textContent = t;
    document.body.appendChild(a);
    setTimeout(function () { a.classList.add('via'); }, 2600);
    setTimeout(function () { a.remove(); }, 3200);
  }

  /* ---------- Cuore ---------- */
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    if (f.matches('[data-lc-cuore]')) {
      ev.preventDefault();
      var b = $('button', f), e = f.querySelector('input[name=e]').value;
      if (b.disabled) { return; }
      b.disabled = true;
      var prima = b.classList.contains('on');
      b.classList.toggle('on', !prima);
      if (!prima) { b.classList.remove('batte'); void b.offsetWidth; b.classList.add('batte'); }
      manda('cuore', { e: e }).then(function (j) {
        b.disabled = false;
        if (j.ok === false) { b.classList.toggle('on', prima); avviso(j.error || 'Non riuscito.'); return; }
        b.classList.toggle('on', !!j.messo);
        b.setAttribute('aria-pressed', j.messo ? 'true' : 'false');
        b.title = j.messo ? 'Togli il mi piace' : 'Mi piace';
        $('[data-lc-n]', b).textContent = j.n ? j.n : '';
        var art = f.closest('[data-lc-e]'), chi = art && $('[data-lc-chi]', art);
        if (chi) { chi.textContent = j.chi || ''; chi.hidden = !j.n; }
      }).catch(function () { b.disabled = false; b.classList.toggle('on', prima); avviso('Connessione non riuscita.'); });
      return;
    }

    /* ---------- Commento ---------- */
    if (f.matches('[data-lc-cform]')) {
      ev.preventDefault();
      var ta = $('textarea', f), btn = $('button', f);
      var testo = ta.value.trim();
      if (!testo || btn.disabled) { return; }
      btn.disabled = true;
      manda('commenta', { e: f.querySelector('input[name=e]').value, testo: testo, back: f.querySelector('input[name=back]').value }).then(function (j) {
        btn.disabled = false;
        if (j.ok === false) { avviso(j.error || 'Non riuscito.'); return; }
        var art = f.closest('[data-lc-e]'), lista = $('[data-lc-clist]', art);
        var tmp = document.createElement('div');
        tmp.innerHTML = j.html;
        var c = tmp.firstElementChild;
        c.classList.add('lc-nuovo');
        lista.appendChild(c);
        ta.value = '';
        ta.style.height = '';
      }).catch(function () { btn.disabled = false; avviso('Connessione non riuscita.'); });
      return;
    }

    /* ---------- Eliminare un commento ---------- */
    if (f.matches('[data-lc-cdel]')) {
      ev.preventDefault();
      if (!window.confirm('Eliminare il commento?')) { return; }
      var riga = f.closest('[data-lc-c]');
      manda('elimina', { c: f.querySelector('input[name=c]').value }).then(function (j) {
        if (j.ok === false) { avviso(j.error || 'Non riuscito.'); return; }
        riga.remove();
      }).catch(function () { avviso('Connessione non riuscita.'); });
      return;
    }

    /* ---------- Nascondere un libro (scheda del libro) ---------- */
    if (f.matches('[data-lc-nascondi]')) {
      ev.preventDefault();
      var op = f.querySelector('input[name=op]');
      manda('nascondi', { book: f.querySelector('input[name=book]').value, op: op.value }).then(function (j) {
        if (j.ok === false) { avviso('Non riuscito.'); return; }
        var box = f.closest('[data-lc-scheda]');
        op.value = j.nascosto ? 'mostra_libro' : 'nascondi_libro';
        $('button', f).textContent = j.nascosto ? 'Mostra' : 'Nascondi';
        $('[data-lc-scheda-t]', box).textContent = j.nascosto ? 'Gli altri non vedono la tua lettura di questo libro.' : 'Gli altri vedono la tua lettura di questo libro.';
        box.classList.toggle('nascosto', !!j.nascosto);
      }).catch(function () { avviso('Connessione non riuscita.'); });
    }
  });

  /* ---------- Apri il campo del commento ---------- */
  document.addEventListener('click', function (ev) {
    var a = ev.target.closest('[data-lc-apri]');
    if (a) {
      var art = a.closest('[data-lc-e]'), f = art && $('[data-lc-cform]', art);
      if (f) {
        ev.preventDefault();
        f.hidden = false;
        $('textarea', f).focus();
      }
      return;
    }
    // «Mostra altri»: aggiunge gli aggiornamenti successivi senza ricaricare
    var piu = ev.target.closest('[data-lc-piu]');
    if (piu) {
      ev.preventDefault();
      if (piu.classList.contains('carica')) { return; }
      piu.classList.add('carica');
      piu.textContent = 'Carico…';
      fetch(piu.href, { credentials: 'same-origin' }).then(function (r) { return r.text(); }).then(function (t) {
        var doc = new DOMParser().parseFromString(t, 'text/html');
        var feeds = $$('[data-lc-feed]'), nuovo = $$('[data-lc-feed]', doc);
        var qui = feeds[feeds.length - 1], la = nuovo[nuovo.length - 1];
        if (!qui || !la) { window.location.href = piu.href; return; }
        var giorni = $$('.lc-giorno', qui), ultimo = giorni.length ? giorni[giorni.length - 1].textContent : '';
        Array.prototype.slice.call(la.children).forEach(function (el, i) {
          if (i === 0 && el.classList.contains('lc-giorno') && el.textContent === ultimo) { return; }
          if (el.id && document.getElementById(el.id)) { return; }
          qui.appendChild(el);
        });
        var vecchio = piu.closest('.lc-piu'), nuovoPiu = $$('.lc-piu', doc);
        if (nuovoPiu.length) { vecchio.replaceWith(nuovoPiu[nuovoPiu.length - 1]); } else { vecchio.remove(); }
      }).catch(function () { window.location.href = piu.href; });
    }
  });

  /* ---------- Il campo del commento cresce mentre si scrive; Invio manda dal computer ---------- */
  var fine = window.matchMedia && window.matchMedia('(pointer:fine)').matches;
  document.addEventListener('input', function (ev) {
    var ta = ev.target;
    if (ta.matches && ta.matches('[data-lc-cform] textarea')) {
      ta.style.height = 'auto';
      ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
    }
  });
  document.addEventListener('keydown', function (ev) {
    var ta = ev.target;
    if (ev.key === 'Enter' && ta.matches && ta.matches('[data-lc-cform] textarea') && ((fine && !ev.shiftKey) || ev.ctrlKey || ev.metaKey)) {
      ev.preventDefault();
      var f = ta.closest('form');
      if (f.requestSubmit) { f.requestSubmit(); } else { f.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true })); }
    }
  });

  // arrivando da un avviso: il campo del commento e' gia' aperto nella pagina dell'aggiornamento
  if (window.location.hash === '#scrivi') {
    var s = document.getElementById('scrivi');
    if (s) { s.hidden = false; }
  }
})();
