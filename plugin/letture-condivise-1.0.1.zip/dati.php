<?php
/*
 * Letture condivise — dati: tabelle, chi si vede, gli aggiornamenti (avanzamenti, inizi, libri finiti e lasciati),
 * i «mi piace» e i commenti.
 * Le letture vengono dal diario di lettura del sito (reading_sessions e reading_progress): il plugin non le copia.
 * Si vedono solo le letture di chi ha acceso «Mostra le mie letture e i miei voti agli altri» (Il mio account),
 * tranne i libri che ognuno ha nascosto. Le note degli avanzamenti si vedono solo se chi le scrive lo sceglie.
 */

function lc_t($plugin, $n)
{
    return $plugin->table($n);
}

function lc_crea_tabelle($plugin)
{
    $pdo = db();
    $sqlite = DB_DRIVER === 'sqlite';
    $id = $sqlite ? 'id INTEGER PRIMARY KEY AUTOINCREMENT' : 'id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY';
    $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . lc_t($plugin, 'mipiace') . ' (' . $id . ', tipo CHAR(1) NOT NULL, ref_id INT NOT NULL, user_id INT NOT NULL,'
        . ' created_at DATETIME NOT NULL, UNIQUE (tipo, ref_id, user_id))' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . lc_t($plugin, 'commenti') . ' (' . $id . ', tipo CHAR(1) NOT NULL, ref_id INT NOT NULL, user_id INT NOT NULL,'
        . ' testo TEXT NOT NULL, created_at DATETIME NOT NULL)' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . lc_t($plugin, 'nascosti') . ' (user_id INT NOT NULL, book_id INT NOT NULL, created_at DATETIME NOT NULL,'
        . ' PRIMARY KEY (user_id, book_id))' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . lc_t($plugin, 'preferenze') . ' (user_id INT NOT NULL PRIMARY KEY, note TINYINT NOT NULL DEFAULT 0,'
        . ' avvisi TINYINT NOT NULL DEFAULT 1, visto_at DATETIME NULL)' . $tail);
    try {
        $pdo->exec('CREATE INDEX ' . lc_t($plugin, 'commenti') . '_i1 ON ' . lc_t($plugin, 'commenti') . ' (tipo, ref_id)');
    } catch (Exception $e) {
        // indice gia' presente
    }
}

/* ---------------- Utenti e preferenze ---------------- */

function lc_utenti()
{
    static $c = null;
    if ($c === null) {
        $c = array();
        foreach (db()->query('SELECT id, username, display_name, role, active, share_reading FROM users')->fetchAll() as $u) {
            $c[(int)$u['id']] = $u;
        }
    }
    return $c;
}

function lc_utente($uid)
{
    $t = lc_utenti();
    $u = isset($t[(int)$uid]) ? $t[(int)$uid] : null;
    return $u && (int)$u['active'] === 1 && in_array($u['role'], user_roles(), true) ? $u : null;
}

function lc_nome($uid)
{
    $t = lc_utenti();
    if (!isset($t[(int)$uid])) {
        return 'utente eliminato';
    }
    return (string)$t[(int)$uid]['display_name'] !== '' ? $t[(int)$uid]['display_name'] : $t[(int)$uid]['username'];
}

function lc_iniziali($uid)
{
    $parts = preg_split('/\s+/u', trim(lc_nome($uid)));
    $ini = '';
    foreach ($parts as $p) {
        if ($p !== '' && mb_strlen($ini, 'UTF-8') < 2) {
            $ini .= mb_strtoupper(mb_substr($p, 0, 1, 'UTF-8'), 'UTF-8');
        }
    }
    return $ini !== '' ? $ini : '?';
}

// Un colore fisso per persona (tonalita' calde, leggibili in chiaro e in scuro)
function lc_colore($uid)
{
    $tinte = array(8, 28, 145, 200, 265, 330, 175, 45, 225, 350);
    return $tinte[(int)$uid % count($tinte)];
}

function lc_avatar($uid, $cls = '')
{
    return '<span class="lc-av' . ($cls !== '' ? ' ' . $cls : '') . '" style="--h:' . lc_colore($uid) . '" aria-hidden="true">' . h(lc_iniziali($uid)) . '</span>';
}

// Le letture di questa persona si possono mostrare a chi guarda?
function lc_visibile($uid, $vid)
{
    $u = lc_utente($uid);
    return $u && ((int)$u['share_reading'] === 1 || (int)$uid === (int)$vid);
}

function lc_pref($plugin, $uid)
{
    static $c = array();
    if (!isset($c[(int)$uid])) {
        $st = db()->prepare('SELECT note, avvisi, visto_at FROM ' . lc_t($plugin, 'preferenze') . ' WHERE user_id = ?');
        $st->execute(array((int)$uid));
        $r = $st->fetch();
        $st->closeCursor();
        $c[(int)$uid] = $r ? $r : array('note' => 0, 'avvisi' => 1, 'visto_at' => null);
    }
    return $c[(int)$uid];
}

function lc_pref_salva($plugin, $uid, $campi)
{
    $p = lc_pref($plugin, $uid);
    $p = array_merge($p, $campi);
    $T = lc_t($plugin, 'preferenze');
    $st = db()->prepare('SELECT COUNT(*) FROM ' . $T . ' WHERE user_id = ?');
    $st->execute(array((int)$uid));
    $c = (int)$st->fetchColumn();
    $st->closeCursor();
    if ($c) {
        db()->prepare('UPDATE ' . $T . ' SET note = ?, avvisi = ?, visto_at = ? WHERE user_id = ?')->execute(array((int)$p['note'], (int)$p['avvisi'], $p['visto_at'], (int)$uid));
    } else {
        db()->prepare('INSERT INTO ' . $T . ' (user_id, note, avvisi, visto_at) VALUES (?,?,?,?)')->execute(array((int)$uid, (int)$p['note'], (int)$p['avvisi'], $p['visto_at']));
    }
}

// Chi mostra le note degli avanzamenti (id => true)
function lc_con_note($plugin)
{
    static $c = null;
    if ($c === null) {
        $c = array();
        foreach (db()->query('SELECT user_id FROM ' . lc_t($plugin, 'preferenze') . ' WHERE note = 1')->fetchAll() as $r) {
            $c[(int)$r['user_id']] = true;
        }
    }
    return $c;
}

/* ---------------- Libri nascosti ---------------- */

function lc_nascosto($plugin, $uid, $bid)
{
    $st = db()->prepare('SELECT COUNT(*) FROM ' . lc_t($plugin, 'nascosti') . ' WHERE user_id = ? AND book_id = ?');
    $st->execute(array((int)$uid, (int)$bid));
    $n = (int)$st->fetchColumn();
    $st->closeCursor();
    return $n > 0;
}

function lc_nascondi($plugin, $uid, $bid, $si)
{
    $T = lc_t($plugin, 'nascosti');
    db()->prepare('DELETE FROM ' . $T . ' WHERE user_id = ? AND book_id = ?')->execute(array((int)$uid, (int)$bid));
    if ($si) {
        db()->prepare('INSERT INTO ' . $T . ' (user_id, book_id, created_at) VALUES (?,?,?)')->execute(array((int)$uid, (int)$bid, now()));
    }
}

function lc_nascosti_di($plugin, $uid)
{
    $st = db()->prepare('SELECT b.id, b.title, b.authors, b.cover_file FROM ' . lc_t($plugin, 'nascosti') . ' n JOIN books b ON b.id = n.book_id WHERE n.user_id = ? ORDER BY b.title');
    $st->execute(array((int)$uid));
    $r = $st->fetchAll();
    $st->closeCursor();
    return $r;
}

/* ---------------- Aggiornamenti ---------------- */

function lc_tipi_nomi()
{
    return array('p' => 'Avanzamenti', 'i' => 'Libri iniziati', 'f' => 'Libri finiti', 'a' => 'Libri lasciati');
}

// Tipi di aggiornamento accesi dall'Admin
function lc_tipi_attivi($plugin)
{
    $out = array();
    foreach (lc_tipi_nomi() as $k => $n) {
        if ($plugin->setting('tipo_' . $k, $k === 'a' ? '1' : '1') === '1') {
            $out[] = $k;
        }
    }
    return $out ? $out : array('p');
}

// Pezzo di SQL comune: utenti visibili e libri non nascosti (alias: x = tabella delle letture, u = users)
function lc_sql_visibili($plugin, $x)
{
    $in = "'" . implode("','", user_roles()) . "'";
    return ' JOIN users u ON u.id = ' . $x . '.user_id JOIN books b ON b.id = ' . $x . '.book_id'
        . ' WHERE u.active = 1 AND u.role IN (' . $in . ') AND (u.share_reading = 1 OR u.id = ?)'
        . ' AND NOT EXISTS (SELECT 1 FROM ' . lc_t($plugin, 'nascosti') . ' n WHERE n.user_id = ' . $x . '.user_id AND n.book_id = ' . $x . '.book_id)';
}

/*
 * Aggiornamenti in ordine di tempo, dal piu' recente.
 * $f: vid (chi guarda), uid (solo questa persona), book (solo questo libro), tipi, prima (data: solo fino a questa), salta (chiavi gia' mostrate con quella data), n
 * Restituisce array(elenco, cursore per i successivi o null)
 */
function lc_aggiornamenti($plugin, $f)
{
    $vid = (int)$f['vid'];
    $n = isset($f['n']) ? max(1, min(60, (int)$f['n'])) : 20;
    $tipi = isset($f['tipi']) ? $f['tipi'] : lc_tipi_attivi($plugin);
    $prima = isset($f['prima']) && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', (string)$f['prima']) ? $f['prima'] : '9999-12-31 23:59:59';
    $salta = isset($f['salta']) ? array_flip((array)$f['salta']) : array();
    $lim = $n + count($salta) + 1;
    $cond = '';
    $par = array();
    if (!empty($f['uid'])) {
        $cond .= ' AND u.id = ' . (int)$f['uid'];
    }
    if (!empty($f['book'])) {
        $cond .= ' AND b.id = ' . (int)$f['book'];
    }
    $libro = 'b.id AS book_id, b.title, b.authors, b.cover_file, b.pages AS b_pages';
    $tutti = array();
    $sorgente = "(s.source IS NULL OR s.source = 'manuale')";
    if (in_array('p', $tipi, true)) {
        $st = db()->prepare("SELECT 'p' AS tipo, x.id AS ref, x.user_id AS uid, x.session_id AS sid, x.page, x.percent, x.note, x.read_at AS t, $libro FROM reading_progress x"
            . lc_sql_visibili($plugin, 'x') . $cond . ' AND x.read_at <= ? ORDER BY x.read_at DESC, x.id DESC LIMIT ' . $lim);
        $st->execute(array($vid, $prima));
        $tutti = array_merge($tutti, $st->fetchAll());
        $st->closeCursor();
    }
    if (in_array('i', $tipi, true)) {
        $st = db()->prepare("SELECT 'i' AS tipo, s.id AS ref, s.user_id AS uid, s.id AS sid, s.started_at AS t, $libro FROM reading_sessions s"
            . lc_sql_visibili($plugin, 's') . $cond . " AND s.started_at IS NOT NULL AND $sorgente AND s.started_at <= ? ORDER BY s.started_at DESC, s.id DESC LIMIT " . $lim);
        $st->execute(array($vid, $prima));
        $tutti = array_merge($tutti, $st->fetchAll());
        $st->closeCursor();
    }
    foreach (array('f' => 'letto', 'a' => 'abbandonato') as $k => $stato) {
        if (!in_array($k, $tipi, true)) {
            continue;
        }
        $st = db()->prepare("SELECT '$k' AS tipo, s.id AS ref, s.user_id AS uid, s.id AS sid, s.rating, s.review, s.started_at, s.finished_at AS t, $libro FROM reading_sessions s"
            . lc_sql_visibili($plugin, 's') . $cond . " AND s.status = '$stato' AND s.finished_at IS NOT NULL AND s.date_unknown = 0 AND $sorgente AND s.finished_at <= ?"
            . ' ORDER BY s.finished_at DESC, s.id DESC LIMIT ' . $lim);
        $st->execute(array($vid, $prima));
        $tutti = array_merge($tutti, $st->fetchAll());
        $st->closeCursor();
    }
    $ordine = array('f' => 4, 'a' => 3, 'p' => 2, 'i' => 1);
    usort($tutti, function ($a, $b) use ($ordine) {
        if ($a['t'] !== $b['t']) {
            return strcmp($b['t'], $a['t']);
        }
        if ($a['tipo'] !== $b['tipo']) {
            return $ordine[$b['tipo']] - $ordine[$a['tipo']];
        }
        return (int)$b['ref'] - (int)$a['ref'];
    });
    // "ha iniziato" e il primo avanzamento allo stesso momento diventano un aggiornamento solo
    $primi = array();
    foreach ($tutti as $e) {
        if ($e['tipo'] === 'p') {
            $primi[$e['sid'] . '|' . $e['t']] = true;
        }
    }
    $out = array();
    $altri = false;
    foreach ($tutti as $e) {
        $e['chiave'] = $e['tipo'] . (int)$e['ref'];
        if (isset($salta[$e['chiave']])) {
            continue;
        }
        if ($e['tipo'] === 'i' && isset($primi[$e['sid'] . '|' . $e['t']])) {
            continue;
        }
        if (count($out) >= $n) {
            $altri = true;
            break;
        }
        $out[] = $e;
    }
    foreach ($out as $k => $e) {
        if ($e['tipo'] === 'p' && isset($primi[$e['sid'] . '|' . $e['t']])) {
            foreach ($tutti as $x) {
                if ($x['tipo'] === 'i' && $x['sid'] === $e['sid'] && $x['t'] === $e['t']) {
                    $out[$k]['inizio'] = true;
                }
            }
        }
    }
    $cursore = null;
    if ($altri && $out) {
        $ult = $out[count($out) - 1]['t'];
        $chiavi = array();
        foreach ($out as $e) {
            if ($e['t'] === $ult) {
                $chiavi[] = $e['chiave'];
            }
        }
        if ($ult === $prima) {
            $chiavi = array_merge(array_keys($salta), $chiavi);
        }
        $cursore = array('prima' => $ult, 'salta' => implode(',', $chiavi));
    }
    return array(lc_completa($plugin, $out, $vid), $cursore);
}

// Un aggiornamento solo, da una chiave come "p123" (null se non c'e' o non si puo' vedere)
function lc_aggiornamento($plugin, $chiave, $vid)
{
    if (!preg_match('/^([pifa])(\d{1,10})$/', (string)$chiave, $m)) {
        return null;
    }
    $libro = 'b.id AS book_id, b.title, b.authors, b.cover_file, b.pages AS b_pages';
    if ($m[1] === 'p') {
        $st = db()->prepare("SELECT 'p' AS tipo, x.id AS ref, x.user_id AS uid, x.session_id AS sid, x.page, x.percent, x.note, x.read_at AS t, $libro FROM reading_progress x"
            . lc_sql_visibili($plugin, 'x') . ' AND x.id = ?');
    } else {
        $st = db()->prepare("SELECT '" . $m[1] . "' AS tipo, s.id AS ref, s.user_id AS uid, s.id AS sid, s.status, s.rating, s.review, s.started_at,"
            . ' ' . ($m[1] === 'i' ? 's.started_at' : 's.finished_at') . " AS t, $libro FROM reading_sessions s" . lc_sql_visibili($plugin, 's') . ' AND s.id = ?');
    }
    $st->execute(array((int)$vid, (int)$m[2]));
    $e = $st->fetch();
    $st->closeCursor();
    if (!$e || $e['t'] === null || ($m[1] === 'f' && $e['status'] !== 'letto') || ($m[1] === 'a' && $e['status'] !== 'abbandonato')) {
        return null;
    }
    $e['chiave'] = $chiave;
    $l = lc_completa($plugin, array($e), $vid);
    return $l[0];
}

// Aggiunge cuori e commenti
function lc_completa($plugin, $elenco, $vid)
{
    if (!$elenco) {
        return $elenco;
    }
    $per = array();
    foreach ($elenco as $e) {
        $per[$e['tipo']][] = (int)$e['ref'];
    }
    $cuori = array();
    $comm = array();
    foreach ($per as $tipo => $ids) {
        $q = implode(',', array_map('intval', $ids));
        foreach (db()->query('SELECT ref_id, user_id FROM ' . lc_t($plugin, 'mipiace') . " WHERE tipo = '" . $tipo . "' AND ref_id IN (" . $q . ') ORDER BY id')->fetchAll() as $r) {
            $cuori[$tipo . $r['ref_id']][] = (int)$r['user_id'];
        }
        foreach (db()->query('SELECT id, ref_id, user_id, testo, created_at FROM ' . lc_t($plugin, 'commenti') . " WHERE tipo = '" . $tipo . "' AND ref_id IN (" . $q . ') ORDER BY id')->fetchAll() as $r) {
            $comm[$tipo . $r['ref_id']][] = $r;
        }
    }
    $note = lc_con_note($plugin);
    foreach ($elenco as $k => $e) {
        $c = $e['tipo'] . (int)$e['ref'];
        $elenco[$k]['cuori'] = isset($cuori[$c]) ? $cuori[$c] : array();
        $elenco[$k]['commenti'] = isset($comm[$c]) ? $comm[$c] : array();
        if ($e['tipo'] === 'p' && (int)$e['uid'] !== (int)$vid && empty($note[(int)$e['uid']])) {
            $elenco[$k]['note'] = null;
        }
    }
    return $elenco;
}

// Novita' degli altri dopo l'ultima visita alla pagina
function lc_novita($plugin, $vid)
{
    $p = lc_pref($plugin, $vid);
    $da = $p['visto_at'] ? $p['visto_at'] : date('Y-m-d H:i:s', time() - 3 * 86400);
    $l = lc_aggiornamenti($plugin, array('vid' => $vid, 'n' => 30));
    $n = 0;
    $ultimo = null;
    foreach ($l[0] as $e) {
        if ((int)$e['uid'] === (int)$vid) {
            continue;
        }
        if ($ultimo === null) {
            $ultimo = $e;
        }
        if ($e['t'] > $da) {
            $n++;
        }
    }
    return array($n, $ultimo);
}

/* ---------------- Mi piace e commenti ---------------- */

function lc_testo_breve($e)
{
    $tit = '«' . str_cut($e['title'], 60) . '»';
    switch ($e['tipo']) {
        case 'p':
            return 'avanzamento in ' . $tit . ($e['page'] !== null ? ' (pagina ' . (int)$e['page'] . ')' : '');
        case 'i':
            return 'inizio di ' . $tit;
        case 'f':
            return 'lettura finita di ' . $tit;
        default:
            return 'lettura lasciata di ' . $tit;
    }
}

// Destinatari di un avviso: tolti chi l'ha causato e chi ha spento gli avvisi del plugin
function lc_destinatari($plugin, $ids, $actor)
{
    $out = array();
    foreach (array_unique(array_map('intval', $ids)) as $id) {
        if ($id !== (int)$actor && lc_utente($id) && (int)lc_pref($plugin, $id)['avvisi'] === 1) {
            $out[] = $id;
        }
    }
    return $out;
}

function lc_cuore_cambia($plugin, $vid, $chiave)
{
    $e = lc_aggiornamento($plugin, $chiave, $vid);
    if (!$e) {
        return array(false, 'Aggiornamento non trovato.');
    }
    if ((int)$e['uid'] === (int)$vid) {
        return array(false, 'Non puoi mettere mi piace ai tuoi aggiornamenti.');
    }
    $L = lc_t($plugin, 'mipiace');
    if (in_array((int)$vid, $e['cuori'], true)) {
        db()->prepare('DELETE FROM ' . $L . ' WHERE tipo = ? AND ref_id = ? AND user_id = ?')->execute(array($e['tipo'], (int)$e['ref'], (int)$vid));
        $messo = false;
        $e['cuori'] = array_values(array_diff($e['cuori'], array((int)$vid)));
    } else {
        db()->prepare('INSERT INTO ' . $L . ' (tipo, ref_id, user_id, created_at) VALUES (?,?,?,?)')->execute(array($e['tipo'], (int)$e['ref'], (int)$vid, now()));
        $messo = true;
        $e['cuori'][] = (int)$vid;
        $to = lc_destinatari($plugin, array($e['uid']), $vid);
        if ($to) {
            $nome = lc_nome($vid);
            $plugin->notifica('♥ A ' . $nome . ' piace il tuo ' . lc_testo_breve($e), $plugin->site_url('voce', array('e' => $chiave)),
                array('to' => $to, 'actor' => (int)$vid, 'book' => (int)$e['book_id'], 'gruppo' => 'c' . $chiave,
                    'testo_gruppo' => '♥ {n} mi piace al tuo ' . lc_testo_breve($e) . ', l\'ultimo da ' . $nome));
        }
    }
    return array(true, $messo, $e);
}

function lc_commenta($plugin, $vid, $chiave, $testo)
{
    if ($plugin->setting('commenti', '1') !== '1') {
        return array(false, 'I commenti sono spenti.');
    }
    $testo = trim(preg_replace("/\r\n?/", "\n", (string)$testo));
    if ($testo === '') {
        return array(false, 'Scrivi qualcosa.');
    }
    if (mb_strlen($testo, 'UTF-8') > 1000) {
        return array(false, 'Il commento è troppo lungo (al massimo 1000 caratteri).');
    }
    $e = lc_aggiornamento($plugin, $chiave, $vid);
    if (!$e) {
        return array(false, 'Aggiornamento non trovato.');
    }
    db()->prepare('INSERT INTO ' . lc_t($plugin, 'commenti') . ' (tipo, ref_id, user_id, testo, created_at) VALUES (?,?,?,?,?)')
        ->execute(array($e['tipo'], (int)$e['ref'], (int)$vid, $testo, now()));
    $cid = (int)db()->lastInsertId();
    $nome = lc_nome($vid);
    $ant = str_cut(trim(preg_replace('/\s+/u', ' ', $testo)), 60);
    $link = $plugin->site_url('voce', array('e' => $chiave));
    // a chi ha scritto l'aggiornamento
    $to = lc_destinatari($plugin, array($e['uid']), $vid);
    if ($to) {
        $plugin->notifica('💬 ' . $nome . ' ha commentato il tuo ' . lc_testo_breve($e) . ': «' . $ant . '»', $link,
            array('to' => $to, 'actor' => (int)$vid, 'book' => (int)$e['book_id'], 'gruppo' => 'm' . $chiave,
                'testo_gruppo' => '💬 {n} commenti al tuo ' . lc_testo_breve($e) . ', l\'ultimo da ' . $nome));
    }
    // a chi aveva gia' commentato
    $altri = array();
    foreach ($e['commenti'] as $c) {
        if ((int)$c['user_id'] !== (int)$e['uid']) {
            $altri[] = (int)$c['user_id'];
        }
    }
    $to = lc_destinatari($plugin, $altri, $vid);
    if ($to) {
        $di = ((int)$e['uid'] === (int)$vid ? 'sua lettura' : 'lettura di ' . lc_nome($e['uid'])) . ' di «' . str_cut($e['title'], 60) . '»';
        $plugin->notifica('💬 ' . $nome . ' ha risposto nei commenti della ' . $di . ': «' . $ant . '»', $link,
            array('to' => $to, 'actor' => (int)$vid, 'book' => (int)$e['book_id'], 'gruppo' => 'r' . $chiave,
                'testo_gruppo' => '💬 {n} nuove risposte nei commenti della ' . $di));
    }
    return array(true, $cid, $e);
}

function lc_commento($plugin, $cid)
{
    $st = db()->prepare('SELECT * FROM ' . lc_t($plugin, 'commenti') . ' WHERE id = ?');
    $st->execute(array((int)$cid));
    $r = $st->fetch();
    $st->closeCursor();
    return $r ? $r : null;
}

// Si cancella il proprio commento; chi ha scritto l'aggiornamento e l'Admin cancellano anche quelli degli altri
function lc_commento_elimina($plugin, $vid, $cid)
{
    $c = lc_commento($plugin, $cid);
    if (!$c) {
        return array(false, 'Commento non trovato.');
    }
    $e = lc_aggiornamento($plugin, $c['tipo'] . $c['ref_id'], $vid);
    $puo = (int)$c['user_id'] === (int)$vid || is_admin() || ($e && (int)$e['uid'] === (int)$vid);
    if (!$puo) {
        return array(false, 'Non puoi eliminare questo commento.');
    }
    db()->prepare('DELETE FROM ' . lc_t($plugin, 'commenti') . ' WHERE id = ?')->execute(array((int)$cid));
    return array(true, $c['tipo'] . $c['ref_id']);
}

// Cuori e commenti di aggiornamenti che non esistono piu' (avanzamento cancellato, libro eliminato)
function lc_manutenzione($plugin)
{
    foreach (array('mipiace', 'commenti') as $t) {
        $T = lc_t($plugin, $t);
        db()->exec('DELETE FROM ' . $T . " WHERE tipo = 'p' AND NOT EXISTS (SELECT 1 FROM reading_progress x WHERE x.id = " . $T . '.ref_id)');
        db()->exec('DELETE FROM ' . $T . " WHERE tipo IN ('i','f','a') AND NOT EXISTS (SELECT 1 FROM reading_sessions s WHERE s.id = " . $T . '.ref_id)');
    }
    db()->exec('DELETE FROM ' . lc_t($plugin, 'nascosti') . ' WHERE NOT EXISTS (SELECT 1 FROM books b WHERE b.id = ' . lc_t($plugin, 'nascosti') . '.book_id)');
}

/* ---------------- Profilo ---------------- */

function lc_sta_leggendo($plugin, $uid, $vid)
{
    $st = db()->prepare("SELECT s.id AS sid, s.started_at, b.id AS book_id, b.title, b.authors, b.cover_file, b.pages AS b_pages FROM reading_sessions s"
        . lc_sql_visibili($plugin, 's') . " AND s.user_id = ? AND s.status = 'in_lettura' ORDER BY COALESCE(s.updated_at, s.started_at, s.created_at) DESC, s.id DESC LIMIT 12");
    $st->execute(array((int)$vid, (int)$uid));
    $r = $st->fetchAll();
    $st->closeCursor();
    foreach ($r as $k => $x) {
        $r[$k]['punto'] = reading_last_point($x['sid']);
    }
    return $r;
}

function lc_letti($plugin, $uid, $vid, $n = 18)
{
    $st = db()->prepare("SELECT s.id AS sid, s.finished_at, s.rating, b.id AS book_id, b.title, b.authors, b.cover_file FROM reading_sessions s"
        . lc_sql_visibili($plugin, 's') . " AND s.user_id = ? AND s.status = 'letto' ORDER BY COALESCE(s.finished_at, s.created_at) DESC, s.id DESC LIMIT " . (int)$n);
    $st->execute(array((int)$vid, (int)$uid));
    $r = $st->fetchAll();
    $st->closeCursor();
    return $r;
}

function lc_conta_letti($plugin, $uid, $vid)
{
    $st = db()->prepare("SELECT COUNT(*) AS tot, SUM(CASE WHEN s.finished_at >= ? THEN 1 ELSE 0 END) AS anno FROM reading_sessions s"
        . lc_sql_visibili($plugin, 's') . " AND s.user_id = ? AND s.status = 'letto'");
    $st->execute(array(date('Y') . '-01-01 00:00:00', (int)$vid, (int)$uid));
    $r = $st->fetch();
    $st->closeCursor();
    return array((int)$r['tot'], (int)$r['anno']);
}

// Persone che condividono le letture, con quanti libri stanno leggendo (chi guarda per primo)
function lc_persone($plugin, $vid)
{
    $in = "'" . implode("','", user_roles()) . "'";
    $st = db()->prepare("SELECT u.id, (SELECT COUNT(*) FROM reading_sessions s WHERE s.user_id = u.id AND s.status = 'in_lettura'"
        . ' AND NOT EXISTS (SELECT 1 FROM ' . lc_t($plugin, 'nascosti') . ' n WHERE n.user_id = s.user_id AND n.book_id = s.book_id)) AS leggendo'
        . ' FROM users u WHERE u.active = 1 AND u.role IN (' . $in . ') AND (u.share_reading = 1 OR u.id = ?)');
    $st->execute(array((int)$vid));
    $r = $st->fetchAll();
    $st->closeCursor();
    usort($r, function ($a, $b) use ($vid) {
        if ((int)$a['id'] === (int)$vid || (int)$b['id'] === (int)$vid) {
            return (int)$a['id'] === (int)$vid ? -1 : 1;
        }
        if ((int)$a['leggendo'] !== (int)$b['leggendo']) {
            return (int)$b['leggendo'] - (int)$a['leggendo'];
        }
        return strcasecmp(lc_nome($a['id']), lc_nome($b['id']));
    });
    return $r;
}
