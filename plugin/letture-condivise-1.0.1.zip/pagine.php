<?php
/*
 * Letture condivise — pagine: «Letture di tutti» (gli aggiornamenti di tutti), il profilo di ogni persona,
 * un aggiornamento con tutti i suoi commenti, le impostazioni dell'Admin.
 */

function lc_icona($n, $s = 18)
{
    $p = array(
        'cuore'   => '<path d="M12 20.5s-7.5-4.6-7.5-10.3A4.2 4.2 0 0 1 12 7.6a4.2 4.2 0 0 1 7.5 2.6c0 5.7-7.5 10.3-7.5 10.3z"/>',
        'fumetto' => '<path d="M20 12.2c0 3.9-3.6 7-8 7-1.1 0-2.2-.2-3.1-.6L4.5 20l1.1-3.6C4.6 15.2 4 13.8 4 12.2c0-3.9 3.6-7 8-7s8 3.1 8 7z"/>',
        'libro'   => '<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H11v15H5.5A1.5 1.5 0 0 0 4 20.5zM20 5.5A1.5 1.5 0 0 0 18.5 4H13v15h5.5a1.5 1.5 0 0 1 1.5 1.5z"/>',
        'occhio'  => '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
        'chiuso'  => '<path d="M3 3l18 18M10.6 6.1A9.6 9.6 0 0 1 12 6c6 0 9.5 6 9.5 6a16 16 0 0 1-3 3.6M6.4 7.6C3.9 9.3 2.5 12 2.5 12S6 18 12 18c1.6 0 3-.4 4.2-1"/>',
        'chev'    => '<path d="M9 5l7 7-7 7"/>',
        'indietro' => '<path d="M15 5l-7 7 7 7"/>',
        'x'       => '<path d="M6 6l12 12M18 6L6 18"/>',
        'gear'    => '<circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.4M12 18.8v2.4M4.2 7.5l2 1.2M17.8 15.3l2 1.2M4.2 16.5l2-1.2M17.8 8.7l2-1.2"/>',
    );
    return '<svg class="i lc-i lc-i-' . $n . '" width="' . (int)$s . '" height="' . (int)$s . '" viewBox="0 0 24 24" aria-hidden="true">' . (isset($p[$n]) ? $p[$n] : '') . '</svg>';
}

function lc_quando($dt)
{
    if (!$dt) {
        return '';
    }
    $s = time() - strtotime($dt);
    if ($s < 90) {
        return 'adesso';
    }
    if ($s < 3600) {
        return (int)round($s / 60) . ' min fa';
    }
    if ($s < 86400) {
        return (int)round($s / 3600) . ' h fa';
    }
    if ($s < 172800) {
        return 'ieri';
    }
    if ($s < 6 * 86400) {
        return (int)floor($s / 86400) . ' giorni fa';
    }
    return date('d/m' . (date('Y', strtotime($dt)) !== date('Y') ? '/Y' : ''), strtotime($dt));
}

function lc_perc($p)
{
    return rtrim(rtrim(number_format((float)$p, 1, ',', ''), '0'), ',') . '%';
}

function lc_inizio($plugin)
{
    require_once APP_ROOT . '/inc/reading.php';
    $cfg = array('commenti' => $plugin->setting('commenti', '1') === '1');
    echo '<div class="lc" data-lc>';
    echo '<script type="application/json" id="lc-config">' . json_encode($cfg) . '</script>';
}

function lc_fine()
{
    echo '</div>';
}

// Frase dell'aggiornamento: "ha segnato pagina 120 di 340"
function lc_frase($e)
{
    switch ($e['tipo']) {
        case 'p':
            $tot = (int)$e['b_pages'];
            if ($e['page'] !== null) {
                $f = 'pagina ' . (int)$e['page'] . ($tot > 0 ? ' di ' . $tot : '');
            } else {
                $f = 'il ' . lc_perc($e['percent']);
            }
            if ($e['percent'] !== null && (float)$e['percent'] >= 100) {
                return 'ha raggiunto l\'ultima pagina';
            }
            return !empty($e['inizio']) ? 'ha iniziato a leggere · ' . $f : 'ha segnato ' . $f;
        case 'i':
            return 'ha iniziato a leggere';
        case 'f':
            return 'ha finito di leggere';
        default:
            return 'ha messo da parte';
    }
}

function lc_e_html($plugin, $e, $vid, $back, $tutti_commenti = false)
{
    $mio = (int)$e['uid'] === (int)$vid;
    $prof = $plugin->site_url('profilo', array('u' => (int)$e['uid']));
    $voce = $plugin->site_url('voce', array('e' => $e['chiave']));
    $h = '<article class="lc-e lc-e-' . h($e['tipo']) . '" id="e-' . h($e['chiave']) . '" data-lc-e="' . h($e['chiave']) . '">';
    $h .= '<header class="lc-e-h"><a href="' . h($prof) . '">' . lc_avatar($e['uid']) . '</a><div class="lc-e-chi">'
        . '<p><a class="lc-nome" href="' . h($prof) . '">' . h($mio ? 'Tu' : lc_nome($e['uid'])) . '</a> <span>' . h($mio ? preg_replace('/^ha /', 'hai ', lc_frase($e)) : lc_frase($e)) . '</span></p>'
        . '<a class="lc-quando" href="' . h($voce) . '"><time datetime="' . h(str_replace(' ', 'T', $e['t'])) . '" title="' . h(date('d/m/Y H:i', strtotime($e['t']))) . '">' . h(lc_quando($e['t'])) . '</time></a></div></header>';
    // il libro
    $h .= '<a class="lc-libro" href="libro.php?id=' . (int)$e['book_id'] . '"><span class="lc-cop">' . book_cover_html(array('title' => $e['title'], 'authors' => $e['authors'], 'cover_file' => $e['cover_file']), 'cover xs') . '</span>'
        . '<span class="lc-libro-t"><b>' . h($e['title']) . '</b><small>' . h(str_cut((string)$e['authors'], 80)) . '</small>';
    if ($e['tipo'] === 'p' && $e['percent'] !== null) {
        $p = max(0, min(100, (float)$e['percent']));
        $h .= '<span class="lc-bar"><span class="progress"><i style="width:' . round($p, 1) . '%"></i></span><em>' . h(lc_perc($p)) . '</em></span>';
    } elseif ($e['tipo'] === 'f' && $e['rating'] !== null && (float)$e['rating'] > 0) {
        $h .= '<span class="lc-stelle">' . stars_html($e['rating'], 'sm') . '</span>';
    }
    $h .= '</span></a>';
    if ($e['tipo'] === 'p' && (string)$e['note'] !== '') {
        $h .= '<blockquote class="lc-nota">' . nl2br(h($e['note'])) . '</blockquote>';
    } elseif ($e['tipo'] === 'f' && trim((string)$e['review']) !== '') {
        $r = trim((string)$e['review']);
        $lungo = mb_strlen($r, 'UTF-8') > 280;
        $h .= '<blockquote class="lc-nota">' . nl2br(h($tutti_commenti || !$lungo ? $r : str_cut($r, 270))) . ($lungo && !$tutti_commenti ? ' <a class="link" href="' . h($voce) . '">continua</a>' : '') . '</blockquote>';
    }
    // cuore e commenti
    $n = count($e['cuori']);
    $messo = in_array((int)$vid, $e['cuori'], true);
    $nc = count($e['commenti']);
    $comm_on = $plugin->setting('commenti', '1') === '1';
    $h .= '<footer class="lc-e-piede">';
    if ($mio) {
        if ($n) {
            $h .= '<span class="lc-btn lc-cuore mio pieno" title="I mi piace al tuo aggiornamento">' . lc_icona('cuore', 19) . '<span data-lc-n>' . $n . '</span></span>';
        }
    } else {
        $h .= $plugin->form_start('class="lc-fcuore" data-lc-cuore') . '<input type="hidden" name="op" value="cuore"><input type="hidden" name="e" value="' . h($e['chiave']) . '">'
            . '<input type="hidden" name="back" value="' . h($back) . '">'
            . '<button class="lc-btn lc-cuore' . ($messo ? ' on' : '') . '" type="submit" aria-pressed="' . ($messo ? 'true' : 'false') . '" title="' . ($messo ? 'Togli il mi piace' : 'Mi piace') . '">'
            . lc_icona('cuore', 19) . '<span data-lc-n>' . ($n ? $n : '') . '</span></button></form>';
    }
    if ($comm_on) {
        $h .= '<a class="lc-btn lc-cbtn" href="' . h($voce) . '#scrivi" data-lc-apri>' . lc_icona('fumetto', 19) . '<span class="lc-cbtn-t">Commenta</span></a>';
    }
    $h .= '</footer>';
    $h .= '<p class="lc-chi-cuori" data-lc-chi' . ($n ? '' : ' hidden') . '>' . h(lc_chi_cuori($e['cuori'], $vid)) . '</p>';
    // commenti
    if ($comm_on || $nc) {
        $lista = $e['commenti'];
        $nasc = 0;
        if (!$tutti_commenti && count($lista) > 2) {
            $nasc = count($lista) - 2;
            $lista = array_slice($lista, -2);
        }
        $h .= '<div class="lc-comm" data-lc-comm>';
        if ($nasc) {
            $h .= '<a class="lc-altri" href="' . h($voce) . '">' . ($nasc === 1 ? 'Vedi l\'altro commento' : 'Vedi gli altri ' . $nasc . ' commenti') . '</a>';
        }
        $h .= '<div class="lc-clist" data-lc-clist>';
        foreach ($lista as $c) {
            $h .= lc_commento_html($plugin, $c, $e, $vid, $back);
        }
        $h .= '</div>';
        if ($comm_on) {
            $h .= $plugin->form_start('class="lc-cform" data-lc-cform' . ($tutti_commenti ? ' id="scrivi"' : ' hidden'))
                . '<input type="hidden" name="op" value="commenta"><input type="hidden" name="e" value="' . h($e['chiave']) . '"><input type="hidden" name="back" value="' . h($back) . '">'
                . lc_avatar($vid, 'sm') . '<textarea class="input" name="testo" rows="1" maxlength="1000" placeholder="Scrivi un commento…" aria-label="Commento" required></textarea>'
                . '<button class="lc-invia" type="submit" title="Invia" aria-label="Invia"><svg class="i" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12l16-8-6 16-2.5-6.5z"/></svg></button></form>';
        }
        $h .= '</div>';
    }
    return $h . '</article>';
}

function lc_chi_cuori($ids, $vid)
{
    $nomi = array();
    foreach ($ids as $id) {
        $nomi[] = (int)$id === (int)$vid ? 'te' : lc_nome($id);
    }
    if (!$nomi) {
        return '';
    }
    if (count($nomi) > 3) {
        return 'Piace a ' . implode(', ', array_slice($nomi, 0, 2)) . ' e ad altri ' . (count($nomi) - 2);
    }
    $ult = array_pop($nomi);
    return 'Piace a ' . ($nomi ? implode(', ', $nomi) . ' e ' : '') . $ult;
}

function lc_commento_html($plugin, $c, $e, $vid, $back)
{
    $puo = (int)$c['user_id'] === (int)$vid || is_admin() || (int)$e['uid'] === (int)$vid;
    $h = '<div class="lc-c" data-lc-c="' . (int)$c['id'] . '"><a href="' . h($plugin->site_url('profilo', array('u' => (int)$c['user_id']))) . '">' . lc_avatar($c['user_id'], 'sm') . '</a>'
        . '<div class="lc-c-b"><p><b>' . h((int)$c['user_id'] === (int)$vid ? 'Tu' : lc_nome($c['user_id'])) . '</b> <time title="' . h(date('d/m/Y H:i', strtotime($c['created_at']))) . '">' . h(lc_quando($c['created_at'])) . '</time></p>'
        . '<div class="lc-c-t">' . nl2br(h($c['testo'])) . '</div></div>';
    if ($puo) {
        $h .= $plugin->form_start('class="lc-cdel" data-lc-cdel') . '<input type="hidden" name="op" value="elimina_commento"><input type="hidden" name="c" value="' . (int)$c['id'] . '">'
            . '<input type="hidden" name="back" value="' . h($back) . '"><button type="submit" title="Elimina il commento" aria-label="Elimina il commento">' . lc_icona('x', 14) . '</button></form>';
    }
    return $h . '</div>';
}

function lc_elenco_html($plugin, $elenco, $vid, $back)
{
    $h = '';
    $giorno = '';
    foreach ($elenco as $e) {
        $g = substr($e['t'], 0, 10);
        if ($g !== $giorno) {
            $giorno = $g;
            $oggi = date('Y-m-d');
            $et = $g === $oggi ? 'Oggi' : ($g === date('Y-m-d', time() - 86400) ? 'Ieri' : lc_data_lunga($g));
            $h .= '<h3 class="lc-giorno">' . h($et) . '</h3>';
        }
        $h .= lc_e_html($plugin, $e, $vid, $back);
    }
    return $h;
}

function lc_data_lunga($g)
{
    $mesi = array('', 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre');
    $gg = array('domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato');
    $t = strtotime($g);
    return ucfirst($gg[(int)date('w', $t)]) . ' ' . (int)date('j', $t) . ' ' . $mesi[(int)date('n', $t)] . (date('Y', $t) !== date('Y') ? ' ' . date('Y', $t) : '');
}

function lc_altri_link($plugin, $slug, $params, $cur)
{
    if (!$cur) {
        return '';
    }
    return '<div class="lc-piu"><a class="btn ghost small" href="' . h($plugin->site_url($slug, array_merge($params, array('prima' => $cur['prima'], 'salta' => $cur['salta'])))) . '" data-lc-piu>Mostra altri</a></div>';
}

function lc_salta_get()
{
    $s = (string)get('salta');
    return $s === '' ? array() : array_filter(explode(',', $s), function ($k) { return preg_match('/^[pifa]\d{1,10}$/', $k); });
}

/* ---------------- Letture di tutti ---------------- */

function lc_pagina_tutti($plugin)
{
    $vid = current_uid();
    lc_inizio($plugin);
    $tipi_on = lc_tipi_attivi($plugin);
    $filtri = array('' => 'Tutto');
    if (in_array('p', $tipi_on, true)) {
        $filtri['p'] = 'Avanzamenti';
    }
    if (in_array('f', $tipi_on, true)) {
        $filtri['f'] = 'Libri finiti';
    }
    if (in_array('i', $tipi_on, true)) {
        $filtri['i'] = 'Iniziati';
    }
    $tipo = isset($filtri[(string)get('tipo')]) ? (string)get('tipo') : '';
    $chi = (int)get('chi');
    echo '<h1 class="h1">Letture di tutti</h1><p class="sub">A che punto sono gli altri con i loro libri: metti un cuore o scrivi un commento.</p>';

    $me = lc_utente($vid);
    if ($me && (int)$me['share_reading'] !== 1) {
        echo '<div class="lc-avviso">' . lc_icona('chiuso', 18) . '<span>Le tue letture <b>non sono visibili</b> agli altri: vedi solo quelle di chi le condivide.</span>'
            . '<a class="link" href="' . h($plugin->site_url('profilo', array('u' => $vid, 'imp' => 1))) . '#impostazioni">Cambia</a></div>';
    }

    // le persone
    $persone = lc_persone($plugin, $vid);
    if (count($persone) > 1) {
        echo '<div class="lc-persone">';
        foreach ($persone as $p) {
            $mio = (int)$p['id'] === (int)$vid;
            echo '<a class="lc-pers' . ($chi === (int)$p['id'] ? ' on' : '') . '" href="' . h($plugin->site_url('profilo', array('u' => (int)$p['id']))) . '">' . lc_avatar($p['id'], 'md')
                . '<b>' . h($mio ? 'Tu' : lc_nome($p['id'])) . '</b><small>' . ((int)$p['leggendo'] ? ((int)$p['leggendo'] === 1 ? 'legge 1 libro' : 'legge ' . (int)$p['leggendo'] . ' libri') : '&nbsp;') . '</small></a>';
        }
        echo '</div>';
    }

    if (count($filtri) > 2) {
        echo '<div class="chips lc-filtri">';
        foreach ($filtri as $k => $n) {
            echo '<a class="chip' . ($k === $tipo ? ' on' : '') . '" href="' . h($plugin->site_url('tutti', $k !== '' ? array('tipo' => $k) : array())) . '">' . h($n) . '</a>';
        }
        echo '</div>';
    }

    $par = $tipo !== '' ? array('tipo' => $tipo) : array();
    $f = array('vid' => $vid, 'n' => 20, 'prima' => get('prima'), 'salta' => lc_salta_get());
    if ($tipo !== '') {
        $f['tipi'] = array($tipo);
    }
    list($elenco, $cur) = lc_aggiornamenti($plugin, $f);
    $back = $plugin->site_url('tutti', $par + (get('prima') ? array('prima' => get('prima'), 'salta' => get('salta')) : array()));
    echo '<div class="lc-feed" data-lc-feed>';
    if (!$elenco) {
        echo '<div class="lc-vuoto">' . lc_icona('libro', 40) . '<p>' . (get('prima') ? 'Non c\'è altro.' : 'Ancora nessun aggiornamento. Quando qualcuno segna a che pagina è arrivato, lo trovi qui.') . '</p></div>';
    } else {
        echo lc_elenco_html($plugin, $elenco, $vid, $back);
    }
    echo '</div>' . lc_altri_link($plugin, 'tutti', $par, $cur);
    if (!get('prima')) {
        lc_pref_salva($plugin, $vid, array('visto_at' => now()));
    }
    lc_fine();
}

/* ---------------- Profilo ---------------- */

function lc_pagina_profilo($plugin)
{
    $vid = current_uid();
    $uid = (int)get('u') ? (int)get('u') : $vid;
    $mio = $uid === (int)$vid;
    lc_inizio($plugin);
    echo '<a class="lc-torna" href="' . h($plugin->site_url('tutti')) . '">' . lc_icona('indietro', 16) . ' Letture di tutti</a>';
    $u = lc_utente($uid);
    if (!$u || !lc_visibile($uid, $vid)) {
        echo '<div class="lc-vuoto">' . lc_icona('chiuso', 40) . '<p>' . ($u ? h(lc_nome($uid)) . ' non condivide le sue letture.' : 'Persona non trovata.') . '</p></div>';
        lc_fine();
        return;
    }
    list($tot, $anno) = lc_conta_letti($plugin, $uid, $vid);
    $leggendo = lc_sta_leggendo($plugin, $uid, $vid);
    echo '<div class="lc-prof">' . lc_avatar($uid, 'big') . '<div><h1 class="h1">' . h(lc_nome($uid)) . ($mio ? ' <small>(tu)</small>' : '') . '</h1>'
        . '<p class="sub">' . ($tot === 1 ? '1 libro letto' : $tot . ' libri letti') . ' · ' . $anno . ' nel ' . date('Y') . ($leggendo ? ' · ne sta leggendo ' . count($leggendo) : '') . '</p></div></div>';

    if ($mio) {
        lc_impostazioni_html($plugin, $vid);
    }

    if ($leggendo) {
        echo '<h2 class="lc-h2">Sta leggendo</h2><div class="lc-leggendo">';
        foreach ($leggendo as $r) {
            $pt = $r['punto'];
            $perc = $pt && $pt['percent'] !== null ? max(0, min(100, (float)$pt['percent'])) : null;
            $tx = $pt ? reading_point_text($pt, (int)$r['b_pages']) : 'Appena iniziato';
            echo '<a class="lc-lg" href="libro.php?id=' . (int)$r['book_id'] . '"><span class="lc-cop">' . book_cover_html($r, 'cover xs') . '</span><span class="lc-libro-t"><b>' . h($r['title']) . '</b><small>' . h(str_cut((string)$r['authors'], 80)) . '</small>'
                . ($perc !== null ? '<span class="lc-bar"><span class="progress"><i style="width:' . round($perc, 1) . '%"></i></span><em>' . h(lc_perc($perc)) . '</em></span>' : '')
                . '<small class="lc-pt">' . h($tx) . ($pt ? ' · ' . h(lc_quando($pt['read_at'])) : '') . '</small></span></a>';
        }
        echo '</div>';
    }

    $f = array('vid' => $vid, 'uid' => $uid, 'n' => 10, 'prima' => get('prima'), 'salta' => lc_salta_get());
    list($elenco, $cur) = lc_aggiornamenti($plugin, $f);
    if ($elenco) {
        $back = $plugin->site_url('profilo', array('u' => $uid) + (get('prima') ? array('prima' => get('prima'), 'salta' => get('salta')) : array()));
        echo '<h2 class="lc-h2">Ultimi aggiornamenti</h2><div class="lc-feed" data-lc-feed>' . lc_elenco_html($plugin, $elenco, $vid, $back) . '</div>' . lc_altri_link($plugin, 'profilo', array('u' => $uid), $cur);
    }

    if (!get('prima')) {
        $letti = lc_letti($plugin, $uid, $vid, 18);
        if ($letti) {
            echo '<h2 class="lc-h2">Libri letti' . ($tot > count($letti) ? ' <small>(gli ultimi ' . count($letti) . ' di ' . $tot . ')</small>' : '') . '</h2><div class="lc-letti">';
            foreach ($letti as $r) {
                echo '<a class="lc-lt" href="libro.php?id=' . (int)$r['book_id'] . '" title="' . h($r['title']) . '">' . book_cover_html($r, 'cover') . '<b>' . h(str_cut($r['title'], 50)) . '</b>'
                    . ($r['rating'] !== null && (float)$r['rating'] > 0 ? stars_html($r['rating'], 'sm') : '') . ($r['finished_at'] ? '<small>' . h(date('d/m/Y', strtotime($r['finished_at']))) . '</small>' : '') . '</a>';
            }
            echo '</div>';
        }
    }
    if (!$leggendo && !$elenco && $tot === 0) {
        echo '<div class="lc-vuoto">' . lc_icona('libro', 40) . '<p>' . ($mio ? 'Non hai ancora letture da mostrare.' : h(lc_nome($uid)) . ' non ha ancora letture da mostrare.') . '</p></div>';
    }
    lc_fine();
}

function lc_impostazioni_html($plugin, $vid)
{
    $me = lc_utente($vid);
    $p = lc_pref($plugin, $vid);
    $nasc = lc_nascosti_di($plugin, $vid);
    $back = $plugin->site_url('profilo', array('u' => $vid, 'imp' => 1));
    echo '<details class="card lc-imp" id="impostazioni"' . (get('imp') ? ' open' : '') . '><summary>' . lc_icona('gear', 18) . '<b>Cosa vedono gli altri</b><span class="lc-imp-s">'
        . ((int)$me['share_reading'] === 1 ? 'Letture visibili' . ($nasc ? ' · ' . count($nasc) . ' libri nascosti' : '') : 'Letture nascoste') . '</span></summary>';
    echo $plugin->form_start('class="lc-imp-f"') . '<input type="hidden" name="op" value="impostazioni"><input type="hidden" name="back" value="' . h($back) . '">'
        . '<label class="check switch"><input type="checkbox" name="condividi" value="1"' . ((int)$me['share_reading'] === 1 ? ' checked' : '') . '><span>Mostra le mie letture e i miei voti agli altri<small>Avanzamenti, libri iniziati e finiti, voti e recensioni. Spenta, nessuno vede le tue letture (è la stessa scelta di Il mio account).</small></span></label>'
        . '<label class="check switch"><input type="checkbox" name="note" value="1"' . ((int)$p['note'] === 1 ? ' checked' : '') . '><span>Mostra anche le note degli avanzamenti<small>Quello che scrivi nel campo «Nota» quando segni la pagina.</small></span></label>'
        . '<label class="check switch"><input type="checkbox" name="avvisi" value="1"' . ((int)$p['avvisi'] === 1 ? ' checked' : '') . '><span>Avvisami di mi piace e commenti<small>Nella campanella e sul telefono, se hai acceso le notifiche.</small></span></label>'
        . '<button class="btn primary small" type="submit">Salva</button></form>';
    echo '<div class="lc-nasc"><p class="lc-nasc-t">Libri nascosti</p>';
    if ($nasc) {
        foreach ($nasc as $b) {
            echo $plugin->form_start('class="lc-nasc-r"') . '<input type="hidden" name="op" value="mostra_libro"><input type="hidden" name="book" value="' . (int)$b['id'] . '"><input type="hidden" name="back" value="' . h($back) . '">'
                . '<span class="lc-cop">' . book_cover_html($b, 'cover xs') . '</span><span class="lc-libro-t"><b>' . h($b['title']) . '</b><small>' . h(str_cut((string)$b['authors'], 60)) . '</small></span>'
                . '<button class="btn ghost small" type="submit">' . lc_icona('occhio', 15) . ' Mostra</button></form>';
        }
    } else {
        echo '<p class="sub">Nessuno. Per nascondere un libro apri la sua scheda e tocca <b>Nascondi</b> nel riquadro «Letture di tutti».</p>';
    }
    echo '</div></details>';
}

/* ---------------- Un aggiornamento con tutti i commenti ---------------- */

function lc_pagina_voce($plugin)
{
    $vid = current_uid();
    $k = (string)get('e');
    lc_inizio($plugin);
    echo '<a class="lc-torna" href="' . h($plugin->site_url('tutti')) . '">' . lc_icona('indietro', 16) . ' Letture di tutti</a>';
    $e = lc_aggiornamento($plugin, $k, $vid);
    if (!$e) {
        echo '<div class="lc-vuoto">' . lc_icona('chiuso', 40) . '<p>Questo aggiornamento non c\'è più o non è visibile.</p></div>';
        lc_fine();
        return;
    }
    echo '<div class="lc-feed lc-una" data-lc-feed>' . lc_e_html($plugin, $e, $vid, $plugin->site_url('voce', array('e' => $k)), true) . '</div>';
    lc_fine();
}

/* ---------------- Moduli (senza JavaScript) ---------------- */

function lc_salva($plugin)
{
    $vid = current_uid();
    switch (post('op')) {
        case 'cuore':
            $r = lc_cuore_cambia($plugin, $vid, (string)post('e'));
            if (!$r[0]) {
                flash($r[1], 'error');
            }
            break;
        case 'commenta':
            $r = lc_commenta($plugin, $vid, (string)post('e'), (string)post('testo'));
            if (!$r[0]) {
                flash($r[1], 'error');
            }
            break;
        case 'elimina_commento':
            $r = lc_commento_elimina($plugin, $vid, (int)post('c'));
            flash($r[0] ? 'Commento eliminato.' : $r[1], $r[0] ? 'success' : 'error');
            break;
        case 'impostazioni':
            $share = post('condividi') === '1' ? 1 : 0;
            $prima = lc_utente($vid);
            db()->prepare('UPDATE users SET share_reading = ?, updated_at = ? WHERE id = ?')->execute(array($share, now(), $vid));
            if ($prima && $share !== (int)$prima['share_reading']) {
                app_log('riservatezza', $share ? 'Letture e voti di nuovo visibili agli altri' : 'Letture e voti nascosti agli altri', 'info');
            }
            lc_pref_salva($plugin, $vid, array('note' => post('note') === '1' ? 1 : 0, 'avvisi' => post('avvisi') === '1' ? 1 : 0));
            flash('Impostazioni salvate.', 'success');
            break;
        case 'mostra_libro':
        case 'nascondi_libro':
            lc_nascondi($plugin, $vid, (int)post('book'), post('op') === 'nascondi_libro');
            flash(post('op') === 'nascondi_libro' ? 'Il libro non compare più nelle letture di tutti.' : 'Il libro compare di nuovo nelle letture di tutti.', 'success');
            break;
    }
}

/* ---------------- Gestione (Admin) ---------------- */

function lc_pannello($plugin)
{
    echo '<div class="card"><div class="ct">Letture condivise</div><p class="sub">Gli utenti vedono gli avanzamenti di lettura degli altri, mettono un cuore e scrivono commenti. '
        . 'Si vedono solo le letture di chi ha acceso «Mostra le mie letture e i miei voti agli altri» (Il mio account), e ognuno può nascondere singoli libri.</p>';
    echo $plugin->form_start() . '<input type="hidden" name="back" value="' . h($plugin->admin_url('impostazioni')) . '">';
    echo '<p class="lab" style="margin-top:14px">Cosa compare</p>';
    foreach (lc_tipi_nomi() as $k => $n) {
        echo '<label class="check switch"><input type="checkbox" name="tipo_' . $k . '" value="1"' . ($plugin->setting('tipo_' . $k, '1') === '1' ? ' checked' : '') . '><span>' . h($n) . '</span></label>';
    }
    echo '<p class="lab" style="margin-top:14px">Opzioni</p>'
        . '<label class="check switch"><input type="checkbox" name="commenti" value="1"' . ($plugin->setting('commenti', '1') === '1' ? ' checked' : '') . '><span>Commenti agli aggiornamenti</span></label>'
        . '<label class="check switch"><input type="checkbox" name="in_libreria" value="1"' . ($plugin->setting('in_libreria', '1') === '1' ? ' checked' : '') . '><span>Riquadro «Letture di tutti» in cima alla Libreria (con le novità)</span></label>'
        . '<label class="check switch"><input type="checkbox" name="in_scheda" value="1"' . ($plugin->setting('in_scheda', '1') === '1' ? ' checked' : '') . '><span>Riquadro nella scheda del libro (per nasconderlo dalle letture di tutti)</span></label>'
        . '<button class="btn primary small" type="submit" style="margin-top:12px">Salva</button></form></div>';
    echo '<div class="card"><div class="ct">Dove si trova</div><p class="sub">Menu ☰ del sito → <b>Letture di tutti</b>. Ogni persona ha il suo profilo con quello che sta leggendo e i libri letti; '
        . 'dal proprio profilo si sceglie cosa mostrare (letture, note, avvisi) e si rivedono i libri nascosti.</p></div>';
}

function lc_pannello_salva($plugin)
{
    foreach (array_keys(lc_tipi_nomi()) as $k) {
        $plugin->save_setting('tipo_' . $k, post('tipo_' . $k) === '1' ? '1' : '0');
    }
    foreach (array('commenti', 'in_libreria', 'in_scheda') as $k) {
        $plugin->save_setting($k, post($k) === '1' ? '1' : '0');
    }
    flash('Impostazioni salvate.', 'success');
}
