// Posta: mette la busta accanto alla campanella e tiene aggiornato il numero dei messaggi da leggere
(function () {
  'use strict';
  var t = document.getElementById('ps-busta-t');
  if (!t || !t.content) { return; }
  var posti = document.querySelectorAll('[data-bell]');
  if (!posti.length) { posti = document.querySelectorAll('.topright, .adm-top'); }
  posti.forEach(function (p) {
    var b = t.content.firstElementChild.cloneNode(true);
    if (p.hasAttribute('data-bell')) { p.parentNode.insertBefore(b, p); } else { p.insertBefore(b, p.firstChild); }
  });
  if (!window.fetch) { return; }
  function badge(n) {
    document.querySelectorAll('[data-ps-busta-n]').forEach(function (e) { e.hidden = !n; e.textContent = n > 99 ? '99+' : String(n); });
    document.querySelectorAll('[data-ps-busta]').forEach(function (a) { a.setAttribute('aria-label', 'Posta' + (n ? ': ' + n + ' da leggere' : '')); });
  }
  function conta() {
    if (document.hidden) { return; }
    fetch('api.php?action=plg&p=posta&f=conta', { credentials: 'same-origin' }).then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.ok && typeof j.n === 'number') { badge(j.n); } }).catch(function () { /* fuori linea */ });
  }
  setInterval(conta, 90000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) { conta(); } });
})();
