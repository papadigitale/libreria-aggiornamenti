<?php
/* Pagine del sito: "Sfide di lettura" (elenco, dettaglio, classifica) e "I miei sticker". Prefisso: sl_ */

function sl_medaglia($livello, $size = 28, $s = null)
{
    $img = $s ? sl_immagine($s) : null;
    if ($img) {
        return '<span class="sl-med sl-' . h($livello) . ($img['modo'] === 'libera' ? ' sl-med-libera' : ' sl-med-img') . '" style="width:' . (int)$size . 'px;height:' . (int)$size . 'px" aria-hidden="true">'
            . '<img src="' . h($img['thumb']) . '" alt="" loading="lazy"></span>';
    }
    return '<span class="sl-med sl-' . h($livello) . '" style="width:' . (int)$size . 'px;height:' . (int)$size . 'px" aria-hidden="true">' . icon('award', (int)round($size * .62)) . '</span>';
}

function sl_barra($p)
{
    return '<div class="sl-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int)$p['pct'] . '"><i style="width:' . (int)$p['pct'] . '%"></i></div>';
}

function sl_periodo($s)
{
    $f = $s['tipo'] === 'maratona' ? 'd/m/Y H:i' : 'd/m/Y';
    return 'dal ' . date($f, strtotime($s['inizio'])) . ' al ' . date($f, strtotime($s['fine']));
}

function sl_html_traguardi($plugin, $limite = 6)
{
    $t = sl_traguardi($plugin, $limite);
    if (!$t) {
        return '';
    }
    $h = '<div class="sl-feed"><div class="sl-feed-t">' . icon('award', 16) . ' Ultimi traguardi</div>';
    foreach ($t as $r) {
        $h .= '<a class="sl-feed-i" href="' . h($plugin->site_url('sfide', array('id' => (int)$r['sfida_id']))) . '">' . sl_medaglia($r['livello'], 24, $r)
            . '<span><b>' . h(sl_nome($r)) . '</b> ha completato «' . h($r['titolo']) . '»<small>' . h(sl_quando($r['completata_il'])) . '</small></span></a>';
    }
    return $h . '</div>';
}

function sl_card($plugin, $s, $uid)
{
    $stato = sl_stato($s);
    $is = sl_iscrizione($plugin, $s['id'], $uid);
    $n_isc = count(sl_iscritti($plugin, $s['id']));
    $h = '<div class="card sl-card sl-st-' . h($stato) . '"><div class="sl-head">' . sl_medaglia($s['livello'], 40, $s) . '<div class="sl-ht">'
        . '<a href="' . h($plugin->site_url('sfide', array('id' => (int)$s['id']))) . '"><b>' . h($s['titolo']) . '</b></a>'
        . '<small>' . h(sl_tipi()[$s['tipo']][0]) . ' · ' . h(sl_periodo($s)) . '</small></div></div>'
        . '<p class="sl-goal">' . h(sl_obiettivo_testo($s)) . '</p>';
    if ($is && $stato !== 'prossima') {
        $p = sl_progresso($plugin, $s, $uid);
        $h .= sl_barra($p) . '<div class="sl-prog"><span>' . h(sl_unita_testo($p['valore'], $p['unita'])) . ' di ' . h(sl_unita_testo($p['obiettivo'], $p['unita']))
            . ($s['tipo'] === 'famiglia' ? ' (tutti insieme)' : '') . '</span>'
            . ($is['completata_il'] ? '<span class="sl-done">' . icon('check', 14) . ' Completata</span>' : '') . '</div>';
    }
    $h .= '<div class="sl-foot"><small>' . $n_isc . ($n_isc === 1 ? ' partecipante' : ' partecipanti') . '</small>';
    if ($stato !== 'conclusa' && !$is) {
        $h .= $plugin->form_start('class="sl-inline"') . '<input type="hidden" name="op" value="partecipa"><input type="hidden" name="id" value="' . (int)$s['id'] . '">'
            . '<button class="btn primary small" type="submit">Partecipa</button></form>';
    } elseif ($is && $is['completata_il']) {
        $h .= '<a class="btn ghost small" href="' . h($plugin->site_url('sticker')) . '">' . icon('award', 15) . ' Il tuo sticker</a>';
    } else {
        $h .= '<a class="btn ghost small" href="' . h($plugin->site_url('sfide', array('id' => (int)$s['id']))) . '">Dettagli</a>';
    }
    return $h . '</div></div>';
}

function sl_pagina_sfide($plugin)
{
    $uid = current_uid();
    $nuove = sl_aggiorna($plugin, $uid);
    foreach ($nuove as $s) {
        echo '<div class="alert success">Hai completato la sfida «' . h($s['titolo']) . '»! <a class="link" href="' . h($plugin->site_url('sticker')) . '">Scarica il tuo sticker</a></div>';
    }
    $id = (int)get('id');
    if ($id) {
        $s = sl_sfida($plugin, $id);
        if ($s && (int)$s['attiva']) {
            sl_dettaglio($plugin, $s, $uid);
            return;
        }
    }
    $tutte = sl_sfide($plugin, true);
    $gruppi = array('in_corso' => array(), 'prossima' => array(), 'conclusa' => array());
    foreach ($tutte as $s) {
        $gruppi[sl_stato($s)][] = $s;
    }
    echo '<h1 class="h1">Sfide di lettura</h1><div class="sl-top"><p class="sub">Partecipa alle sfide: il progresso si aggiorna da solo con le letture che segni. Completandole vinci uno sticker da scaricare e condividere.</p>'
        . '<a class="btn ghost small" href="' . h($plugin->site_url('sticker')) . '">' . icon('award', 16) . ' I miei sticker</a></div>';
    echo sl_html_traguardi($plugin, 5);
    $titoli = array('in_corso' => 'In corso', 'prossima' => 'Prossime', 'conclusa' => 'Concluse');
    $vuoto = true;
    foreach ($gruppi as $k => $list) {
        if (!$list) {
            continue;
        }
        $vuoto = false;
        if ($k === 'conclusa') {
            $list = array_slice($list, 0, 12);
        }
        echo '<h2 class="h2 sl-h">' . h($titoli[$k]) . '</h2><div class="sl-grid">';
        foreach ($list as $s) {
            echo sl_card($plugin, $s, $uid);
        }
        echo '</div>';
    }
    if ($vuoto) {
        echo '<div class="card"><p class="sub">Non ci sono ancora sfide. ' . (can_edit() ? 'Creane una da Gestione → Plugin → Sfide di lettura.' : 'Presto ne arriverà una!') . '</p></div>';
    }
}

function sl_dettaglio($plugin, $s, $uid)
{
    $stato = sl_stato($s);
    $is = sl_iscrizione($plugin, $s['id'], $uid);
    $p = sl_progresso($plugin, $s, $uid);
    $st_txt = array('in_corso' => 'In corso', 'prossima' => 'Comincia il ' . date('d/m/Y', strtotime($s['inizio'])), 'conclusa' => 'Conclusa', 'spenta' => '');
    echo '<p><a class="link" href="' . h($plugin->site_url('sfide')) . '">← Tutte le sfide</a></p>';
    echo '<div class="card sl-det"><div class="sl-head">' . sl_medaglia($s['livello'], 56, $s) . '<div class="sl-ht"><b class="sl-tit">' . h($s['titolo']) . '</b>'
        . '<small>' . h(sl_tipi()[$s['tipo']][0]) . ' · ' . h(sl_livelli()[$s['livello']]) . ' · ' . h(sl_periodo($s)) . ' · ' . h($st_txt[$stato]) . '</small></div></div>'
        . ($s['descrizione'] ? '<p>' . nl2br(h($s['descrizione'])) . '</p>' : '') . '<p class="sl-goal">' . h(sl_obiettivo_testo($s)) . '</p>';
    if ($is) {
        echo sl_barra($p) . '<div class="sl-prog"><span>' . h(sl_unita_testo($p['valore'], $p['unita'])) . ' di ' . h(sl_unita_testo($p['obiettivo'], $p['unita'])) . '</span>'
            . ($is['completata_il'] ? '<span class="sl-done">' . icon('check', 14) . ' Completata il ' . h(date('d/m/Y', strtotime($is['completata_il']))) . '</span>' : '') . '</div>';
        if ($is['completata_il']) {
            echo '<p><a class="btn primary small" href="' . h($plugin->site_url('sticker')) . '">' . icon('award', 16) . ' Scarica il tuo sticker</a></p>';
        } elseif ($stato !== 'conclusa' && $s['tipo'] !== 'famiglia') {
            echo $plugin->form_start('class="sl-inline" data-confirm="Lasciare la sfida?"') . '<input type="hidden" name="op" value="lascia"><input type="hidden" name="id" value="' . (int)$s['id'] . '">'
                . '<button class="btn link small" type="submit">Lascia la sfida</button></form>';
        }
    } elseif ($stato !== 'conclusa') {
        echo $plugin->form_start('class="sl-inline"') . '<input type="hidden" name="op" value="partecipa"><input type="hidden" name="id" value="' . (int)$s['id'] . '">'
            . '<button class="btn primary" type="submit">Partecipa</button></form>';
    }
    echo '</div>';

    // dettagli del tipo
    if ($is && $s['tipo'] === 'bingo') {
        $vincenti = array();
        foreach ($p['vinte'] as $li) {
            $vincenti = array_merge($vincenti, $p['linee'][$li]);
        }
        echo '<div class="card"><div class="ct">La tua griglia</div><div class="sl-bingo" style="grid-template-columns:repeat(' . (int)$p['dim'] . ',1fr)">';
        foreach ($p['celle'] as $ci => $c) {
            $b = isset($p['piene'][$ci]) ? $p['piene'][$ci] : null;
            echo '<div class="sl-cell' . ($b ? ' on' : '') . (in_array($ci, $vincenti, true) ? ' win' : '') . '"><span>' . h(sl_casella_testo($c)) . '</span>'
                . ($b ? '<b><a href="libro.php?id=' . (int)$b['book_id'] . '">' . h(str_cut($b['title'], 50)) . '</a></b>' : '') . '</div>';
        }
        echo '</div><p class="hint">Ogni libro finito nel periodo riempie una sola casella: il sito lo mette dove serve di più.</p></div>';
    } elseif ($is && $s['tipo'] === 'alfabeto') {
        echo '<div class="card"><div class="ct">Le tue lettere</div><div class="sl-abc">';
        foreach ($p['lettere'] as $l => $b) {
            echo '<div class="sl-let' . ($b ? ' on' : '') . '" title="' . h($b ? $b['title'] : 'Ancora nessun libro') . '"><b>' . h($l) . '</b>' . ($b ? '<small>' . h(str_cut($b['title'], 22)) . '</small>' : '') . '</div>';
        }
        echo '</div><p class="hint">Conta la prima lettera del titolo' . (!empty(sl_regole($s)['articoli']) ? ', senza gli articoli (Il, La, Gli, L\'…)' : '') . '.</p></div>';
    }
    if ($is && $p['libri'] && $s['tipo'] !== 'bingo' && $s['tipo'] !== 'alfabeto') {
        echo '<div class="card"><div class="ct">I tuoi libri che contano</div><ul class="sl-list">';
        foreach ($p['libri'] as $b) {
            echo '<li><a href="libro.php?id=' . (int)$b['book_id'] . '">' . h($b['title']) . '</a><small>' . h($b['authors']) . ' · finito il ' . h(date('d/m/Y', strtotime($b['finished_at'])))
                . ((int)$b['pages'] ? ' · ' . (int)$b['pages'] . ' pagine' : '') . '</small></li>';
        }
        echo '</ul></div>';
    }
    if ($is && $s['tipo'] === 'maratona') {
        echo '<div class="card"><p class="hint">Contano le pagine che segni negli avanzamenti di lettura (scheda del libro → «A che pagina sei?») fra l\'inizio e la fine della maratona.</p></div>';
    }

    // classifica
    $isc = sl_iscritti($plugin, $s['id']);
    if ($isc) {
        $rows = array();
        foreach ($isc as $i) {
            $pp = $s['tipo'] === 'famiglia' ? null : sl_progresso($plugin, $s, (int)$i['user_id']);
            $val = $s['tipo'] === 'famiglia' ? (isset($p['contributi'][(int)$i['user_id']]) ? $p['contributi'][(int)$i['user_id']] : 0) : $pp['valore'];
            $rows[] = array('u' => $i, 'val' => $val, 'pct' => $pp ? $pp['pct'] : 0, 'fatto' => $i['completata_il']);
        }
        usort($rows, function ($a, $b) {
            if (($a['fatto'] ? 1 : 0) !== ($b['fatto'] ? 1 : 0)) {
                return $a['fatto'] ? -1 : 1;
            }
            if ($a['fatto'] && $b['fatto']) {
                return strcmp($a['fatto'], $b['fatto']);
            }
            return $b['val'] - $a['val'];
        });
        echo '<div class="card"><div class="ct">' . ($s['tipo'] === 'famiglia' ? 'Il contributo di ognuno' : 'Classifica') . '</div><ol class="sl-rank">';
        foreach ($rows as $k => $r) {
            echo '<li class="' . ((int)$r['u']['user_id'] === (int)$uid ? 'me' : '') . '"><span class="sl-pos">' . ($k + 1) . '</span><b>' . h(sl_nome($r['u'])) . '</b>'
                . '<span class="sl-rv">' . h(sl_unita_testo($r['val'], $p['unita'])) . ($r['fatto'] ? ' · ' . sl_medaglia($s['livello'], 20, $s) : '') . '</span></li>';
        }
        echo '</ol></div>';
    }
}

/* ---------------- I miei sticker ---------------- */

function sl_pagina_sticker($plugin)
{
    $uid = current_uid();
    sl_aggiorna($plugin, $uid);
    $st = db()->prepare('SELECT i.completata_il, s.* FROM ' . sl_t($plugin, 'iscrizioni') . ' i JOIN ' . sl_t($plugin, 'sfide') . ' s ON s.id = i.sfida_id '
        . 'WHERE i.user_id = ? AND i.completata_il IS NOT NULL ORDER BY i.completata_il DESC');
    $st->execute(array($uid));
    $vinti = $st->fetchAll();
    $me = current_user();
    echo '<p><a class="link" href="' . h($plugin->site_url('sfide')) . '">← Sfide di lettura</a></p><h1 class="h1">I miei sticker</h1>';
    if (!$vinti) {
        echo '<div class="card"><p class="sub">Non hai ancora sticker: completa una sfida per vincere il primo!</p>'
            . '<a class="btn primary small" href="' . h($plugin->site_url('sfide')) . '">Vai alle sfide</a></div>';
        return;
    }
    echo '<p class="sub">Scegli il formato e scarica lo sticker: verticale per lo stato di WhatsApp e le storie di Instagram, quadrato per un post, '
        . 'trasparente da usare come sticker. Dal telefono «Condividi» lo manda direttamente all\'app che vuoi.</p><div class="sl-stk-grid">';
    foreach ($vinti as $s) {
        $p = sl_progresso($plugin, $s, $uid);
        $dati = array(
            'titolo' => $s['titolo'], 'livello' => $s['livello'], 'livello_nome' => sl_livelli()[$s['livello']], 'disegno' => $s['disegno'] === 'immagine' ? 'pila' : $s['disegno'],
            'valore' => $s['tipo'] === 'bingo' ? 'Bingo!' : ($s['tipo'] === 'alfabeto' ? 'Alfabeto completo' : sl_unita_testo($p['valore'], $p['unita'])),
            'anno' => date('Y', strtotime($s['fine'])), 'data' => date('d/m/Y', strtotime($s['completata_il'])),
            'nome' => $me['display_name'] !== '' ? $me['display_name'] : $me['username'], 'sito' => setting('brand_title'),
            'file' => 'sticker-' . preg_replace('/[^a-z0-9]+/', '-', strtolower(iconv('UTF-8', 'ASCII//TRANSLIT', $s['titolo']))) ,
        );
        $img = sl_immagine($s);
        if ($img) {
            $dati['img'] = $img['url'];
            $dati['modo'] = $img['modo'];
        }
        echo '<div class="card sl-stk" data-sticker="' . h(json_encode($dati, JSON_UNESCAPED_UNICODE)) . '">'
            . '<div class="sl-stk-prev"><canvas width="1080" height="1920" aria-label="Sticker: ' . h($s['titolo']) . '"></canvas></div>'
            . '<b>' . h($s['titolo']) . '</b><small>' . h(sl_livelli()[$s['livello']]) . ' · completata il ' . h($dati['data']) . '</small>'
            . '<div class="seg sl-fmt" role="radiogroup" aria-label="Formato">'
            . '<label><input type="radio" name="fmt_' . (int)$s['id'] . '" value="storia" checked> Storia</label>'
            . '<label><input type="radio" name="fmt_' . (int)$s['id'] . '" value="quadrato"> Quadrato</label>'
            . '<label><input type="radio" name="fmt_' . (int)$s['id'] . '" value="sticker"> Sticker</label></div>'
            . '<label class="check"><input type="checkbox" data-sl-nome> Mostra il mio nome</label>'
            . '<div class="row-btn"><button class="btn primary small" type="button" data-sl-scarica>Scarica</button>'
            . '<button class="btn ghost small" type="button" data-sl-condividi hidden>Condividi</button></div></div>';
    }
    echo '</div>';
}
