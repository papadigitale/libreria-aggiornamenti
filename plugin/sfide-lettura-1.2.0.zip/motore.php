<?php
/*
 * Motore delle sfide: tipi, regole e calcolo del progresso dalle letture registrate nel sito
 * (letture finite con la data, avanzamenti di pagina). Nessuno deve segnare niente a mano.
 * Prefisso delle funzioni: sl_
 */
require_once APP_ROOT . '/inc/books.php';   // generi (category_name, categories_all)
require_once APP_ROOT . '/inc/extras.php';  // etichette (term_get, terms_by_taxonomy)
require_once APP_ROOT . '/inc/media.php';   // immagini degli sticker (libreria Media)

/* ---------------- Tabelle ---------------- */

function sl_t($plugin, $n)
{
    return $plugin->table($n);
}

function sl_crea_tabelle($plugin)
{
    $pdo = db();
    $sqlite = DB_DRIVER === 'sqlite';
    $id = $sqlite ? 'id INTEGER PRIMARY KEY AUTOINCREMENT' : 'id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY';
    $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . sl_t($plugin, 'sfide') . ' (' . $id . ', titolo VARCHAR(120) NOT NULL, descrizione TEXT NULL, tipo VARCHAR(20) NOT NULL,'
        . ' regole TEXT NULL, inizio DATETIME NOT NULL, fine DATETIME NOT NULL, livello VARCHAR(12) NOT NULL, disegno VARCHAR(20) NOT NULL,'
        . ' auto_iscrizione TINYINT NOT NULL DEFAULT 0, attiva TINYINT NOT NULL DEFAULT 1, creata_da INT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL)' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . sl_t($plugin, 'iscrizioni') . ' (' . $id . ', sfida_id INT NOT NULL, user_id INT NOT NULL, iscritto_il DATETIME NOT NULL,'
        . ' completata_il DATETIME NULL, UNIQUE (sfida_id, user_id))' . $tail);
}

/* ---------------- Tipi, livelli, disegni ---------------- */

function sl_tipi()
{
    return array(
        'libri'    => array('Numero di libri', 'Leggi un certo numero di libri nel periodo'),
        'pagine'   => array('Numero di pagine', 'Leggi un certo numero di pagine (dei libri finiti nel periodo)'),
        'genere'   => array('Genere o etichetta', 'Leggi un certo numero di libri di un genere o di un valore di etichetta'),
        'lunghi'   => array('Libri lunghi', 'Leggi libri oltre un certo numero di pagine'),
        'classici' => array('Classici', 'Leggi libri pubblicati prima di un certo anno'),
        'alfabeto' => array('Alfabeto', 'Un libro per ogni lettera: conta la prima lettera del titolo'),
        'bingo'    => array('Bingo', 'Una griglia di caselle, ognuna con una condizione: completa una riga o tutta la griglia'),
        'maratona' => array('Maratona', 'Leggi un certo numero di pagine in un periodo breve (contano gli avanzamenti di pagina)'),
        'famiglia' => array('Sfida di famiglia', 'Un obiettivo comune: i libri (o le pagine) di tutti i partecipanti si sommano'),
    );
}

function sl_livelli()
{
    return array('bronzo' => 'Bronzo', 'argento' => 'Argento', 'oro' => 'Oro', 'leggenda' => 'Leggenda');
}

function sl_disegni()
{
    return array('pila' => 'Pila di libri', 'libro' => 'Libro aperto', 'gufo' => 'Gufo lettore', 'lampada' => 'Lampada da lettura',
        'segnalibro' => 'Segnalibro', 'tazza' => 'Tazza e libro', 'occhiali' => 'Occhiali sul libro', 'stelle' => 'Libro di stelle');
}

// Modi di usare un'immagine caricata
function sl_modi_immagine()
{
    return array('medaglia' => 'Dentro la medaglia, con la cornice del livello', 'libera' => 'Da sola, al posto della medaglia (ideale per PNG trasparenti)');
}

// Immagine scelta per lo sticker di una sfida: array('url', 'modo', 'id') oppure null (si usa il disegno)
function sl_immagine($s)
{
    if (!isset($s['disegno']) || $s['disegno'] !== 'immagine') {
        return null;
    }
    $g = sl_regole($s);
    $m = !empty($g['img']) && function_exists('media_get') && media_ready() ? media_get((int)$g['img']) : null;
    if (!$m || $m['kind'] !== 'image' || !media_valid_name($m['filename']) || !is_file(MEDIA_DIR . '/' . $m['filename'])) {
        return null;
    }
    return array('url' => media_url($m['filename']), 'thumb' => (int)$m['has_thumb'] ? media_url($m['filename'], true) : media_url($m['filename']),
        'modo' => isset($g['img_modo']) && isset(sl_modi_immagine()[$g['img_modo']]) ? $g['img_modo'] : 'medaglia', 'id' => (int)$m['id']);
}

// Cartella "Sticker delle sfide" in Media (creata la prima volta)
function sl_cartella_media()
{
    $st = db()->prepare('SELECT id FROM media_folders WHERE name = ?');
    $st->execute(array('Sticker delle sfide'));
    $id = (int)$st->fetchColumn();
    if (!$id) {
        $ord = (int)db()->query('SELECT COALESCE(MAX(sort_order), 0) FROM media_folders')->fetchColumn() + 1;
        db()->prepare('INSERT INTO media_folders (name, sort_order, created_at) VALUES (?,?,?)')->execute(array('Sticker delle sfide', $ord, now()));
        $id = (int)db()->lastInsertId();
    }
    return $id;
}

// Condizioni delle caselle del bingo: chiave => array(testo, tipo del valore: '' | 'num' | 'anno' | 'genere' | 'termine' | 'testo')
function sl_criteri()
{
    return array(
        'libera'        => array('Un libro qualsiasi', ''),
        'genere'        => array('Un libro del genere…', 'genere'),
        'termine'       => array('Un libro con l\'etichetta…', 'termine'),
        'pagine_min'    => array('Più di … pagine', 'num'),
        'pagine_max'    => array('Meno di … pagine', 'num'),
        'prima_del'     => array('Pubblicato prima del …', 'anno'),
        'dopo_il'       => array('Pubblicato dal … in poi', 'anno'),
        'voto_min'      => array('Con un voto di almeno … stelle', 'num'),
        'riletto'       => array('Una rilettura', ''),
        'autore_nuovo'  => array('Un autore mai letto prima', ''),
        'veloce'        => array('Letto in … giorni o meno', 'num'),
        'parola'        => array('Con la parola … nel titolo', 'testo'),
        'recensione'    => array('Con una recensione scritta', ''),
    );
}

function sl_bingo_base()
{
    // 25 caselle pronte: per una griglia piu' piccola si usano le prime
    return array(
        array('pagine_min', '500'), array('prima_del', '1950'), array('autore_nuovo', ''), array('pagine_max', '200'), array('riletto', ''),
        array('voto_min', '5'), array('veloce', '7'), array('libera', ''), array('parola', 'notte'), array('recensione', ''),
        array('dopo_il', date('Y') - 1), array('libera', ''), array('pagine_min', '400'), array('parola', 'casa'), array('autore_nuovo', ''),
        array('prima_del', '1900'), array('veloce', '3'), array('voto_min', '4'), array('libera', ''), array('pagine_max', '150'),
        array('recensione', ''), array('parola', 'amore'), array('libera', ''), array('pagine_min', '700'), array('dopo_il', date('Y')),
    );
}

/* ---------------- Dati delle letture ---------------- */

// Letture finite (con data) di un utente in un periodo
function sl_letture($uid, $da, $a)
{
    static $cache = array();
    $k = $uid . '|' . $da . '|' . $a;
    if (isset($cache[$k])) {
        return $cache[$k];
    }
    $st = db()->prepare("SELECT s.id AS sid, s.book_id, s.started_at, s.finished_at, s.rating, s.review, b.title, b.authors, b.pages, b.category_id, b.pub_year, b.cover_file "
        . "FROM reading_sessions s JOIN books b ON b.id = s.book_id WHERE s.user_id = ? AND s.status = 'letto' AND s.date_unknown = 0 "
        . "AND s.finished_at >= ? AND s.finished_at <= ? ORDER BY s.finished_at, s.id");
    $st->execute(array((int)$uid, $da, $a));
    $rows = $st->fetchAll();
    $ids = array_unique(array_map(function ($r) { return (int)$r['book_id']; }, $rows));
    $terms = array();
    if ($ids) {
        foreach (db()->query('SELECT book_id, term_id FROM book_terms WHERE book_id IN (' . implode(',', $ids) . ')')->fetchAll() as $t) {
            $terms[(int)$t['book_id']][] = (int)$t['term_id'];
        }
    }
    foreach ($rows as &$r) {
        $r['terms'] = isset($terms[(int)$r['book_id']]) ? $terms[(int)$r['book_id']] : array();
    }
    unset($r);
    return $cache[$k] = $rows;
}

function sl_filtri_ok($r, $g)
{
    if (!empty($g['categoria']) && (int)$r['category_id'] !== (int)$g['categoria']) {
        return false;
    }
    if (!empty($g['termine']) && !in_array((int)$g['termine'], $r['terms'], true)) {
        return false;
    }
    if (!empty($g['pagine_min']) && (int)$r['pages'] < (int)$g['pagine_min']) {
        return false;
    }
    if (!empty($g['pagine_max']) && ((int)$r['pages'] <= 0 || (int)$r['pages'] > (int)$g['pagine_max'])) {
        return false;
    }
    if (!empty($g['anno_prima']) && (!(int)$r['pub_year'] || (int)$r['pub_year'] >= (int)$g['anno_prima'])) {
        return false;
    }
    if (!empty($g['anno_dopo']) && (int)$r['pub_year'] < (int)$g['anno_dopo']) {
        return false;
    }
    return true;
}

function sl_primo_autore($a)
{
    $a = trim(preg_split('/[,;&]| e /u', (string)$a)[0]);
    return mb_strtolower($a, 'UTF-8');
}

// Contesto per le caselle "riletto" e "autore nuovo"
function sl_storico($uid, $prima_di)
{
    static $cache = array();
    $k = $uid . '|' . $prima_di;
    if (isset($cache[$k])) {
        return $cache[$k];
    }
    $st = db()->prepare("SELECT s.book_id, s.finished_at, b.authors FROM reading_sessions s JOIN books b ON b.id = s.book_id WHERE s.user_id = ? AND s.status = 'letto' AND s.finished_at IS NOT NULL");
    $st->execute(array((int)$uid));
    $finiti = array();
    $autori = array();
    foreach ($st->fetchAll() as $r) {
        $finiti[(int)$r['book_id']][] = $r['finished_at'];
        if ($r['finished_at'] < $prima_di) {
            $autori[sl_primo_autore($r['authors'])] = 1;
        }
    }
    return $cache[$k] = array('finiti' => $finiti, 'autori' => $autori);
}

function sl_casella_ok($r, $c, $ctx)
{
    $v = isset($c[1]) ? (string)$c[1] : '';
    switch ($c[0]) {
        case 'libera':
            return true;
        case 'genere':
            return (int)$r['category_id'] === (int)$v;
        case 'termine':
            return in_array((int)$v, $r['terms'], true);
        case 'pagine_min':
            return (int)$r['pages'] > (int)$v;
        case 'pagine_max':
            return (int)$r['pages'] > 0 && (int)$r['pages'] < (int)$v;
        case 'prima_del':
            return (int)$r['pub_year'] > 0 && (int)$r['pub_year'] < (int)$v;
        case 'dopo_il':
            return (int)$r['pub_year'] >= (int)$v;
        case 'voto_min':
            return (float)$r['rating'] >= (float)str_replace(',', '.', $v) && (float)$r['rating'] > 0;
        case 'riletto':
            foreach (isset($ctx['finiti'][(int)$r['book_id']]) ? $ctx['finiti'][(int)$r['book_id']] : array() as $f) {
                if ($f < $r['finished_at']) {
                    return true;
                }
            }
            return false;
        case 'autore_nuovo':
            return trim((string)$r['authors']) !== '' && !isset($ctx['autori'][sl_primo_autore($r['authors'])]);
        case 'veloce':
            if (!$r['started_at']) {
                return false;
            }
            $g = (int)round((strtotime(substr($r['finished_at'], 0, 10)) - strtotime(substr($r['started_at'], 0, 10))) / 86400) + 1;
            return $g <= (int)$v;
        case 'parola':
            return $v !== '' && mb_stripos((string)$r['title'], $v, 0, 'UTF-8') !== false;
        case 'recensione':
            return trim((string)$r['review']) !== '';
    }
    return false;
}

function sl_casella_testo($c)
{
    $cr = sl_criteri();
    if (!isset($cr[$c[0]])) {
        return '?';
    }
    $t = $cr[$c[0]][0];
    $v = isset($c[1]) ? (string)$c[1] : '';
    if ($cr[$c[0]][1] === 'genere') {
        $v = function_exists('category_name') ? (string)category_name((int)$v) : $v;
    } elseif ($cr[$c[0]][1] === 'termine') {
        $tr = function_exists('term_get') ? term_get((int)$v) : null;
        $v = $tr ? $tr['name'] : '';
    }
    return strpos($t, '…') !== false ? str_replace('…', $v, $t) : $t;
}

// Abbinamento libri → caselle (un libro per casella): cammini aumentanti, per riempire piu' caselle possibile
function sl_abbina($libri, $celle, $ctx)
{
    $adj = array();
    foreach ($celle as $ci => $c) {
        $adj[$ci] = array();
        foreach ($libri as $li => $r) {
            if (sl_casella_ok($r, $c, $ctx)) {
                $adj[$ci][] = $li;
            }
        }
    }
    $libro_di = array();   // libro => casella
    $try = function ($ci, &$visti) use (&$try, &$adj, &$libro_di) {
        foreach ($adj[$ci] as $li) {
            if (isset($visti[$li])) {
                continue;
            }
            $visti[$li] = true;
            if (!isset($libro_di[$li]) || $try($libro_di[$li], $visti)) {
                $libro_di[$li] = $ci;
                return true;
            }
        }
        return false;
    };
    // prima le caselle con meno libri adatti
    $ordine = array_keys($celle);
    usort($ordine, function ($a, $b) use ($adj) { return count($adj[$a]) - count($adj[$b]); });
    foreach ($ordine as $ci) {
        $visti = array();
        $try($ci, $visti);
    }
    $out = array();
    foreach ($libro_di as $li => $ci) {
        $out[$ci] = $li;
    }
    return $out;
}

function sl_linee($n)
{
    $l = array();
    for ($i = 0; $i < $n; $i++) {
        $r = array();
        $c = array();
        for ($j = 0; $j < $n; $j++) {
            $r[] = $i * $n + $j;
            $c[] = $j * $n + $i;
        }
        $l[] = $r;
        $l[] = $c;
    }
    $d1 = array();
    $d2 = array();
    for ($i = 0; $i < $n; $i++) {
        $d1[] = $i * $n + $i;
        $d2[] = $i * $n + ($n - 1 - $i);
    }
    $l[] = $d1;
    $l[] = $d2;
    return $l;
}

function sl_lettera($titolo, $ignora_articoli)
{
    $t = trim((string)$titolo);
    if ($ignora_articoli) {
        $t = preg_replace('/^(il|lo|la|i|gli|le|un|uno|una|the|an?)\s+/iu', '', $t);
        $t = preg_replace('/^(l|un|dell|nell|all|sull)[\'’]\s*/iu', '', $t);
    }
    $t = ltrim($t, " \t\"'«»“”‘’¿¡(-–—.,:;!?0123456789");
    $c = mb_substr($t, 0, 1, 'UTF-8');
    $map = array('À' => 'A', 'Á' => 'A', 'È' => 'E', 'É' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Ò' => 'O', 'Ó' => 'O', 'Ù' => 'U', 'Ú' => 'U');
    $c = mb_strtoupper($c, 'UTF-8');
    return isset($map[$c]) ? $map[$c] : $c;
}

// Pagine lette in una finestra di tempo (maratona), dagli avanzamenti
function sl_pagine_finestra($uid, $da, $a)
{
    $pdo = db();
    $st = $pdo->prepare("SELECT s.id, s.started_at, s.finished_at, s.status, b.pages FROM reading_sessions s JOIN books b ON b.id = s.book_id WHERE s.user_id = ? "
        . "AND (s.finished_at IS NULL OR s.finished_at >= ?) AND (s.started_at IS NULL OR s.started_at <= ?)");
    $st->execute(array((int)$uid, $da, $a));
    $tot = 0;
    $per_libro = array();
    foreach ($st->fetchAll() as $s) {
        $pp = $pdo->prepare('SELECT page, read_at FROM reading_progress WHERE session_id = ? AND page IS NOT NULL ORDER BY read_at, id');
        $pp->execute(array((int)$s['id']));
        $prima = null;
        $primo_dentro = null;
        $fine = null;
        foreach ($pp->fetchAll() as $p) {
            if ($p['read_at'] < $da) {
                $prima = (int)$p['page'];
            } elseif ($p['read_at'] <= $a) {
                $primo_dentro = $primo_dentro === null ? (int)$p['page'] : $primo_dentro;
                $fine = max((int)$fine, (int)$p['page']);
            }
        }
        if ($s['status'] === 'letto' && $s['finished_at'] >= $da && $s['finished_at'] <= $a && (int)$s['pages'] > 0) {
            $fine = max((int)$fine, (int)$s['pages']);
        }
        if ($fine === null) {
            continue;
        }
        if ($prima === null) {
            // nessun avanzamento prima: se la lettura e' cominciata nella finestra si parte da zero, altrimenti dal primo segno nella finestra
            $prima = ($s['started_at'] && $s['started_at'] >= $da) ? 0 : (int)$primo_dentro;
        }
        $n = max(0, $fine - $prima);
        if ($n > 0) {
            $tot += $n;
            $per_libro[(int)$s['id']] = $n;
        }
    }
    return array($tot, $per_libro);
}

/* ---------------- Sfide e iscrizioni ---------------- */

function sl_regole($s)
{
    $r = json_decode((string)$s['regole'], true);
    return is_array($r) ? $r : array();
}

function sl_stato($s)
{
    $now = now();
    if (!(int)$s['attiva']) {
        return 'spenta';
    }
    return $s['inizio'] > $now ? 'prossima' : ($s['fine'] < $now ? 'conclusa' : 'in_corso');
}

function sl_sfida($plugin, $id)
{
    $st = db()->prepare('SELECT * FROM ' . sl_t($plugin, 'sfide') . ' WHERE id = ?');
    $st->execute(array((int)$id));
    $r = $st->fetch();
    return $r ? $r : null;
}

function sl_sfide($plugin, $solo_attive = false)
{
    return db()->query('SELECT * FROM ' . sl_t($plugin, 'sfide') . ($solo_attive ? ' WHERE attiva = 1' : '') . ' ORDER BY fine DESC, id DESC')->fetchAll();
}

function sl_iscrizione($plugin, $sid, $uid)
{
    $st = db()->prepare('SELECT * FROM ' . sl_t($plugin, 'iscrizioni') . ' WHERE sfida_id = ? AND user_id = ?');
    $st->execute(array((int)$sid, (int)$uid));
    $r = $st->fetch();
    return $r ? $r : null;
}

function sl_iscritti($plugin, $sid)
{
    $st = db()->prepare('SELECT i.*, u.username, u.display_name FROM ' . sl_t($plugin, 'iscrizioni') . ' i JOIN users u ON u.id = i.user_id WHERE i.sfida_id = ? AND u.active = 1');
    $st->execute(array((int)$sid));
    return $st->fetchAll();
}

function sl_iscrivi($plugin, $sid, $uid)
{
    if (!sl_iscrizione($plugin, $sid, $uid)) {
        try {
            db()->prepare('INSERT INTO ' . sl_t($plugin, 'iscrizioni') . ' (sfida_id, user_id, iscritto_il) VALUES (?,?,?)')->execute(array((int)$sid, (int)$uid, now()));
        } catch (Exception $e) {
            // gia' iscritto (due richieste insieme)
        }
    }
}

/*
 * Progresso di un utente in una sfida.
 * Esito: valore, obiettivo, pct, fatto, unita' ('libri'|'pagine'|'lettere'|'caselle'), libri (righe contate), e i dettagli del tipo
 */
function sl_progresso($plugin, $s, $uid)
{
    $g = sl_regole($s);
    $tipo = $s['tipo'];
    $n = max(1, (int)(isset($g['n']) ? $g['n'] : 1));
    $out = array('valore' => 0, 'obiettivo' => $n, 'unita' => 'libri', 'libri' => array(), 'fatto' => false);
    if (in_array($tipo, array('libri', 'genere', 'lunghi', 'classici', 'pagine'), true)) {
        foreach (sl_letture($uid, $s['inizio'], $s['fine']) as $r) {
            if (sl_filtri_ok($r, $g)) {
                $out['libri'][] = $r;
                $out['valore'] += $tipo === 'pagine' ? (int)$r['pages'] : 1;
            }
        }
        $out['unita'] = $tipo === 'pagine' ? 'pagine' : 'libri';
    } elseif ($tipo === 'alfabeto') {
        $lettere = preg_split('//u', (string)(isset($g['lettere']) && $g['lettere'] !== '' ? $g['lettere'] : 'ABCDEFGHILMNOPQRSTUVZ'), -1, PREG_SPLIT_NO_EMPTY);
        $lettere = array_values(array_unique(array_map(function ($c) { return mb_strtoupper($c, 'UTF-8'); }, $lettere)));
        $mappa = array_fill_keys($lettere, null);
        foreach (sl_letture($uid, $s['inizio'], $s['fine']) as $r) {
            $c = sl_lettera($r['title'], !empty($g['articoli']));
            if (array_key_exists($c, $mappa) && $mappa[$c] === null) {
                $mappa[$c] = $r;
                $out['libri'][] = $r;
            }
        }
        $out['lettere'] = $mappa;
        $out['valore'] = count(array_filter($mappa));
        $out['obiettivo'] = count($mappa);
        $out['unita'] = 'lettere';
    } elseif ($tipo === 'bingo') {
        $dim = in_array((int)(isset($g['dim']) ? $g['dim'] : 3), array(3, 4, 5), true) ? (int)$g['dim'] : 3;
        $celle = array_slice(isset($g['celle']) && is_array($g['celle']) ? $g['celle'] : sl_bingo_base(), 0, $dim * $dim);
        while (count($celle) < $dim * $dim) {
            $celle[] = array('libera', '');
        }
        $libri = sl_letture($uid, $s['inizio'], $s['fine']);
        $ab = sl_abbina($libri, $celle, sl_storico($uid, $s['inizio']));
        $piene = array();
        foreach ($ab as $ci => $li) {
            $piene[$ci] = $libri[$li];
            $out['libri'][] = $libri[$li];
        }
        $linee = sl_linee($dim);
        $vinte = array();
        foreach ($linee as $li => $l) {
            if (count(array_intersect($l, array_keys($piene))) === $dim) {
                $vinte[] = $li;
            }
        }
        $tutta = (isset($g['vittoria']) ? $g['vittoria'] : 'riga') === 'griglia';
        $out += array('dim' => $dim, 'celle' => $celle, 'piene' => $piene, 'linee' => $linee, 'vinte' => $vinte, 'tutta' => $tutta);
        $out['unita'] = 'caselle';
        if ($tutta) {
            $out['valore'] = count($piene);
            $out['obiettivo'] = $dim * $dim;
        } else {
            // per la riga: quante caselle mancano alla riga piu' vicina
            $best = 0;
            foreach ($linee as $l) {
                $best = max($best, count(array_intersect($l, array_keys($piene))));
            }
            $out['valore'] = $best;
            $out['obiettivo'] = $dim;
        }
    } elseif ($tipo === 'maratona') {
        list($tot, $per) = sl_pagine_finestra($uid, $s['inizio'], $s['fine']);
        $out['valore'] = $tot;
        $out['per_lettura'] = $per;
        $out['unita'] = 'pagine';
    } elseif ($tipo === 'famiglia') {
        $mis = isset($g['misura']) && $g['misura'] === 'pagine' ? 'pagine' : 'libri';
        $tot = 0;
        $contributi = array();
        foreach (sl_iscritti($plugin, $s['id']) as $i) {
            $c = 0;
            foreach (sl_letture((int)$i['user_id'], $s['inizio'], $s['fine']) as $r) {
                if (sl_filtri_ok($r, $g)) {
                    $c += $mis === 'pagine' ? (int)$r['pages'] : 1;
                    if ((int)$i['user_id'] === (int)$uid) {
                        $out['libri'][] = $r;
                    }
                }
            }
            $contributi[(int)$i['user_id']] = $c;
            $tot += $c;
        }
        $out['valore'] = $tot;
        $out['contributi'] = $contributi;
        $out['unita'] = $mis;
    }
    $out['fatto'] = $tipo === 'bingo' ? ($out['tutta'] ? $out['valore'] >= $out['obiettivo'] : count($out['vinte']) > 0) : $out['valore'] >= $out['obiettivo'];
    $out['pct'] = $out['obiettivo'] > 0 ? min(100, (int)floor($out['valore'] / $out['obiettivo'] * 100)) : 0;
    return $out;
}

function sl_unita_testo($v, $u)
{
    $sing = array('libri' => 'libro', 'pagine' => 'pagina', 'lettere' => 'lettera', 'caselle' => 'casella');
    return number_format((int)$v, 0, ',', '.') . ' ' . ((int)$v === 1 ? $sing[$u] : $u);
}

// Testo breve dell'obiettivo (es. "10 libri di Gialli entro il 31/08")
function sl_obiettivo_testo($s)
{
    $g = sl_regole($s);
    $n = (int)(isset($g['n']) ? $g['n'] : 1);
    $f = array();
    if (!empty($g['categoria'])) {
        $f[] = 'genere ' . category_name((int)$g['categoria']);
    }
    if (!empty($g['termine'])) {
        $t = term_get((int)$g['termine']);
        $f[] = $t ? $t['taxonomy_name'] . ' ' . $t['name'] : 'etichetta';
    }
    if (!empty($g['pagine_min'])) {
        $f[] = 'di almeno ' . (int)$g['pagine_min'] . ' pagine';
    }
    if (!empty($g['pagine_max'])) {
        $f[] = 'fino a ' . (int)$g['pagine_max'] . ' pagine';
    }
    if (!empty($g['anno_prima'])) {
        $f[] = 'pubblicati prima del ' . (int)$g['anno_prima'];
    }
    if (!empty($g['anno_dopo'])) {
        $f[] = 'pubblicati dal ' . (int)$g['anno_dopo'];
    }
    $ff = $f ? ' (' . implode(', ', $f) . ')' : '';
    switch ($s['tipo']) {
        case 'pagine':
            return sl_unita_testo($n, 'pagine') . $ff;
        case 'maratona':
            return sl_unita_testo($n, 'pagine') . ' tra il ' . date('d/m H:i', strtotime($s['inizio'])) . ' e il ' . date('d/m H:i', strtotime($s['fine']));
        case 'alfabeto':
            $l = preg_split('//u', (string)(isset($g['lettere']) && $g['lettere'] !== '' ? $g['lettere'] : 'ABCDEFGHILMNOPQRSTUVZ'), -1, PREG_SPLIT_NO_EMPTY);
            return 'Un libro per ognuna delle ' . count(array_unique($l)) . ' lettere';
        case 'bingo':
            $d = (int)(isset($g['dim']) ? $g['dim'] : 3);
            return 'Bingo ' . $d . '×' . $d . ': ' . ((isset($g['vittoria']) ? $g['vittoria'] : 'riga') === 'griglia' ? 'completa tutta la griglia' : 'completa una riga, una colonna o una diagonale');
        case 'famiglia':
            return 'Insieme ' . sl_unita_testo($n, isset($g['misura']) && $g['misura'] === 'pagine' ? 'pagine' : 'libri') . $ff;
    }
    return sl_unita_testo($n, 'libri') . $ff;
}

/*
 * Aggiorna le sfide di un utente: iscrizione automatica, completamenti (anche per tutta la famiglia).
 * Restituisce le sfide appena completate da questo utente.
 */
function sl_aggiorna($plugin, $uid)
{
    if (!$uid) {
        return array();
    }
    $nuove = array();
    $limite = date('Y-m-d H:i:s', time() - 30 * 86400); // si ricontrollano anche le sfide finite da poco (letture segnate in ritardo)
    foreach (sl_sfide($plugin, true) as $s) {
        if ($s['inizio'] > now() || $s['fine'] < $limite) {
            continue;
        }
        if ((int)$s['auto_iscrizione'] && $s['fine'] >= now()) {
            sl_iscrivi($plugin, $s['id'], $uid);
        }
        $is = sl_iscrizione($plugin, $s['id'], $uid);
        if (!$is || $is['completata_il']) {
            continue;
        }
        $p = sl_progresso($plugin, $s, $uid);
        if (!$p['fatto']) {
            continue;
        }
        $ora = now();
        if ($s['tipo'] === 'famiglia') {
            db()->prepare('UPDATE ' . sl_t($plugin, 'iscrizioni') . ' SET completata_il = ? WHERE sfida_id = ? AND completata_il IS NULL')->execute(array($ora, (int)$s['id']));
        } else {
            db()->prepare('UPDATE ' . sl_t($plugin, 'iscrizioni') . ' SET completata_il = ? WHERE id = ?')->execute(array($ora, (int)$is['id']));
        }
        $plugin->log('Sfida "' . $s['titolo'] . '" completata');
        // avviso nella campanella degli altri (Libreria 1.9.14 o successiva)
        if (method_exists($plugin, 'notifica')) {
            $u = db()->prepare('SELECT username, display_name FROM users WHERE id = ?');
            $u->execute(array((int)$uid));
            $nome = sl_nome($u->fetch() ?: array('username' => 'Qualcuno', 'display_name' => ''));
            $plugin->notifica($s['tipo'] === 'famiglia' ? 'Sfida di famiglia completata: «' . $s['titolo'] . '»! Lo sticker è per tutti i partecipanti'
                : $nome . ' ha completato la sfida «' . $s['titolo'] . '»', $plugin->site_url('sfide', array('id' => (int)$s['id'])),
                array('actor' => $s['tipo'] === 'famiglia' ? 0 : (int)$uid, 'gruppo' => 'sfida:' . (int)$s['id'] . ':' . (int)$uid, 'sostituisci' => true));
        }
        $nuove[] = $s;
    }
    return $nuove;
}

// Ultimi traguardi (visibili a tutti gli utenti registrati)
function sl_traguardi($plugin, $limite = 6, $giorni = 30)
{
    $st = db()->prepare('SELECT i.completata_il, i.sfida_id, s.titolo, s.livello, s.tipo, s.disegno, s.regole, u.username, u.display_name FROM ' . sl_t($plugin, 'iscrizioni') . ' i JOIN '
        . sl_t($plugin, 'sfide') . ' s ON s.id = i.sfida_id JOIN users u ON u.id = i.user_id WHERE i.completata_il IS NOT NULL AND i.completata_il >= ? AND u.active = 1 '
        . 'ORDER BY i.completata_il DESC LIMIT ' . (int)$limite);
    $st->execute(array(date('Y-m-d H:i:s', time() - $giorni * 86400)));
    return $st->fetchAll();
}

function sl_nome($u)
{
    return $u['display_name'] !== '' ? $u['display_name'] : $u['username'];
}

function sl_quando($dt)
{
    $d = time() - strtotime($dt);
    if ($d < 3600) {
        return 'poco fa';
    }
    if ($d < 86400) {
        return (int)floor($d / 3600) === 1 ? 'un\'ora fa' : (int)floor($d / 3600) . ' ore fa';
    }
    $g = (int)floor($d / 86400);
    return $g === 1 ? 'ieri' : $g . ' giorni fa';
}
