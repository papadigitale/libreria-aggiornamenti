<?php
/* Gestione → Plugin → Sfide di lettura: creazione e modifica delle sfide (Admin e Gestore). Prefisso: sl_ */

function sl_form_valori($s)
{
    $base = array('id' => 0, 'titolo' => '', 'descrizione' => '', 'tipo' => 'libri', 'livello' => 'argento', 'disegno' => 'pila', 'auto_iscrizione' => 0, 'attiva' => 1,
        'inizio' => date('Y-m-d') . ' 00:00:00', 'fine' => date('Y-12-31') . ' 23:59:59');
    $v = $s ? array_merge($base, $s) : $base;
    $g = $s ? sl_regole($s) : array();
    return array($v, $g + array('n' => 10, 'categoria' => 0, 'termine' => 0, 'pagine_min' => '', 'pagine_max' => '', 'anno_prima' => '', 'anno_dopo' => '',
        'lettere' => 'ABCDEFGHILMNOPQRSTUVZ', 'articoli' => 1, 'dim' => 3, 'vittoria' => 'riga', 'celle' => sl_bingo_base(), 'misura' => 'libri'));
}

function sl_pannello($plugin)
{
    $tutte = sl_sfide($plugin);
    $mod = (int)get('modifica');
    $s = $mod ? sl_sfida($plugin, $mod) : null;
    $nuova = get('nuova') === '1' || $s;
    if (get('copia')) {
        $s = sl_sfida($plugin, (int)get('copia'));
        if ($s) {
            $s['id'] = 0;
            $s['titolo'] .= ' (copia)';
            $nuova = true;
        }
    }
    echo '<div class="sl-adm-top"><p class="sub">Le sfide compaiono nel sito in <a class="link" href="' . h($plugin->site_url('sfide')) . '">Sfide di lettura</a> (menu ☰). '
        . 'Il progresso si calcola da solo con le letture finite nel periodo; i completamenti si vedono da tutti gli utenti registrati.</p>'
        . (!$nuova ? '<a class="btn primary" href="' . h($plugin->admin_url('gestione', array('nuova' => 1))) . '">' . icon('plus', 16) . ' Nuova sfida</a>' : '') . '</div>';
    if ($nuova) {
        sl_editor($plugin, $s);
        return;
    }
    if (!$tutte) {
        echo '<div class="card"><p class="sub">Nessuna sfida ancora. Crea la prima con «Nuova sfida».</p></div>';
        return;
    }
    $st_txt = array('in_corso' => 'In corso', 'prossima' => 'In programma', 'conclusa' => 'Conclusa', 'spenta' => 'Spenta');
    echo '<div class="card"><table class="tbl"><thead><tr><th>Sfida</th><th>Tipo</th><th>Periodo</th><th>Stato</th><th class="num">Partecipanti</th><th class="num">Completate</th><th class="act"></th></tr></thead><tbody>';
    foreach ($tutte as $r) {
        $isc = sl_iscritti($plugin, $r['id']);
        $comp = count(array_filter($isc, function ($i) { return $i['completata_il']; }));
        echo '<tr><td>' . sl_medaglia($r['livello'], 24, $r) . ' <b>' . h($r['titolo']) . '</b><br><small class="muted">' . h(sl_obiettivo_testo($r)) . '</small></td>'
            . '<td>' . h(sl_tipi()[$r['tipo']][0]) . '</td><td><small>' . h(sl_periodo($r)) . '</small></td><td>' . h($st_txt[sl_stato($r)]) . '</td>'
            . '<td class="num">' . count($isc) . '</td><td class="num">' . $comp . '</td><td class="act">'
            . '<a class="btn ghost small" href="' . h($plugin->admin_url('gestione', array('modifica' => (int)$r['id']))) . '">Modifica</a> '
            . '<a class="btn link small" href="' . h($plugin->admin_url('gestione', array('copia' => (int)$r['id']))) . '">Duplica</a></td></tr>';
    }
    echo '</tbody></table></div>';
}

function sl_sel($name, $opts, $cur, $attr = '')
{
    $h = '<select class="input" name="' . h($name) . '" ' . $attr . '>';
    foreach ($opts as $k => $v) {
        $h .= '<option value="' . h($k) . '"' . ((string)$k === (string)$cur ? ' selected' : '') . '>' . h($v) . '</option>';
    }
    return $h . '</select>';
}

function sl_editor($plugin, $s)
{
    list($v, $g) = sl_form_valori($s);
    $cat = array(0 => 'Qualsiasi genere');
    foreach (categories_all() as $c) {
        $cat[(int)$c['id']] = $c['name'];
    }
    $ter = array(0 => 'Qualsiasi');
    $tax = taxonomies_all();
    foreach (terms_by_taxonomy() as $tid => $list) {
        foreach ($list as $t) {
            $ter[(int)$t['id']] = (isset($tax[$tid]) ? $tax[$tid]['name'] . ': ' : '') . $t['name'];
        }
    }
    $tipi = array();
    foreach (sl_tipi() as $k => $t) {
        $tipi[$k] = $t[0];
    }
    $dt = function ($x) { return date('Y-m-d\TH:i', strtotime($x)); };
    $d = function ($x) { return date('Y-m-d', strtotime($x)); };
    $meta = array('tipi' => array_map(function ($t) { return $t[1]; }, sl_tipi()), 'crit' => array_map(function ($c) { return $c[1]; }, sl_criteri()));
    echo '<div class="card sl-editor">' . $plugin->form_start('class="stack" enctype="multipart/form-data" data-sl-editor data-sl-meta="' . h(json_encode($meta, JSON_UNESCAPED_UNICODE)) . '"') . '<input type="hidden" name="op" value="salva"><input type="hidden" name="id" value="' . (int)$v['id'] . '">'
        . '<div class="ct">' . ($v['id'] ? 'Modifica la sfida' : 'Nuova sfida') . '</div>'
        . '<label class="lab">Titolo</label><input class="input" name="titolo" maxlength="120" required value="' . h($v['titolo']) . '" placeholder="es. 10 libri entro l\'estate">'
        . '<label class="lab">Descrizione (facoltativa)</label><textarea class="input" name="descrizione" rows="2" maxlength="1000">' . h((string)$v['descrizione']) . '</textarea>'
        . '<label class="lab">Tipo di sfida</label>' . sl_sel('tipo', $tipi, $v['tipo'], 'data-sl-tipo')
        . '<p class="hint" data-sl-tipo-desc></p>'
        . '<div class="sl-row2"><div data-sl-date><label class="lab">Inizio</label><input class="input" type="date" name="inizio_d" value="' . h($d($v['inizio'])) . '"></div>'
        . '<div data-sl-date><label class="lab">Fine</label><input class="input" type="date" name="fine_d" value="' . h($d($v['fine'])) . '"></div>'
        . '<div data-sl-ora hidden><label class="lab">Inizio (giorno e ora)</label><input class="input" type="datetime-local" name="inizio_t" value="' . h($dt($v['inizio'])) . '"></div>'
        . '<div data-sl-ora hidden><label class="lab">Fine (giorno e ora)</label><input class="input" type="datetime-local" name="fine_t" value="' . h($dt($v['fine'])) . '"></div></div>'

        // obiettivo numerico
        . '<div data-sl-per="libri pagine genere lunghi classici maratona famiglia"><label class="lab" data-sl-n-lab>Obiettivo</label>'
        . '<div class="sl-row2"><input class="input" type="number" name="n" min="1" max="100000" value="' . (int)$g['n'] . '">'
        . '<div data-sl-per="famiglia">' . sl_sel('misura', array('libri' => 'libri', 'pagine' => 'pagine'), $g['misura']) . '</div></div></div>'

        // filtri
        . '<div class="sl-filtri" data-sl-per="libri pagine genere lunghi classici famiglia"><div class="ct sep">Quali libri contano</div><div class="sl-row2">'
        . '<div><label class="lab">Genere</label>' . sl_sel('categoria', $cat, $g['categoria']) . '</div>'
        . '<div><label class="lab">Etichetta</label>' . sl_sel('termine', $ter, $g['termine']) . '</div>'
        . '<div><label class="lab">Almeno … pagine</label><input class="input" type="number" name="pagine_min" min="1" value="' . h((string)$g['pagine_min']) . '" placeholder="es. 500"></div>'
        . '<div><label class="lab">Al massimo … pagine</label><input class="input" type="number" name="pagine_max" min="1" value="' . h((string)$g['pagine_max']) . '"></div>'
        . '<div><label class="lab">Pubblicati prima del</label><input class="input" type="number" name="anno_prima" min="1000" max="2100" value="' . h((string)$g['anno_prima']) . '" placeholder="es. 1950"></div>'
        . '<div><label class="lab">Pubblicati dal</label><input class="input" type="number" name="anno_dopo" min="1000" max="2100" value="' . h((string)$g['anno_dopo']) . '"></div>'
        . '</div><p class="hint">Lascia vuoto quello che non serve: senza filtri conta qualsiasi libro finito nel periodo.</p></div>'

        // alfabeto
        . '<div data-sl-per="alfabeto"><label class="lab">Lettere</label><input class="input" name="lettere" maxlength="40" value="' . h((string)$g['lettere']) . '">'
        . '<label class="check"><input type="checkbox" name="articoli" value="1"' . (!empty($g['articoli']) ? ' checked' : '') . '> Ignora gli articoli all\'inizio del titolo (Il, La, Gli, L\'…)</label></div>'

        // bingo
        . '<div data-sl-per="bingo"><div class="sl-row2"><div><label class="lab">Griglia</label>' . sl_sel('dim', array(3 => '3 × 3', 4 => '4 × 4', 5 => '5 × 5'), $g['dim'], 'data-sl-dim') . '</div>'
        . '<div><label class="lab">Per vincere</label>' . sl_sel('vittoria', array('riga' => 'una riga, colonna o diagonale', 'griglia' => 'tutta la griglia'), $g['vittoria']) . '</div></div>'
        . '<label class="lab">Caselle</label><div class="sl-celle" data-sl-celle>';
    $crit = array();
    foreach (sl_criteri() as $k => $c) {
        $crit[$k] = str_replace('…', '___', $c[0]);
    }
    $celle = array_values($g['celle']);
    for ($i = 0; $i < 25; $i++) {
        $c = isset($celle[$i]) ? $celle[$i] : array('libera', '');
        echo '<div class="sl-cella" data-sl-cella="' . $i . '"><span>' . ($i + 1) . '</span>' . sl_sel('celle[' . $i . '][0]', $crit, $c[0], 'data-sl-crit')
            . '<input class="input" name="celle[' . $i . '][1]" value="' . h((string)(isset($c[1]) ? $c[1] : '')) . '" placeholder="valore" data-sl-val>'
            . sl_sel('celle_g[' . $i . ']', $cat, (int)(isset($c[1]) ? $c[1] : 0), 'data-sl-valg hidden')
            . sl_sel('celle_t[' . $i . ']', $ter, (int)(isset($c[1]) ? $c[1] : 0), 'data-sl-valt hidden') . '</div>';
    }
    echo '</div><p class="hint">Ogni libro finito nel periodo riempie una casella sola. Con "___" la condizione usa il valore accanto (pagine, anno, stelle, giorni o una parola).</p></div>'

        . '<div class="ct sep">Premio</div><div class="sl-premio"><div class="sl-premio-campi"><div class="sl-row2">'
        . '<div><label class="lab">Livello dello sticker</label>' . sl_sel('livello', sl_livelli(), $v['livello'], 'data-sl-prev') . '</div>'
        . '<div><label class="lab">Disegno</label>' . sl_sel('disegno', sl_disegni() + array('immagine' => 'Un\'immagine tua…'), $v['disegno'], 'data-sl-disegno data-sl-prev') . '</div></div>'
        . sl_editor_immagine($v, $g)
        . '</div><div class="sl-anteprima"><canvas width="1080" height="1080" data-sl-anteprima data-sito="' . h(setting('brand_title')) . '" aria-label="Anteprima dello sticker"></canvas>'
        . '<div class="seg sl-fmt" role="radiogroup" aria-label="Formato dell\'anteprima"><label><input type="radio" name="_prev_fmt" value="quadrato" checked data-sl-prev> Quadrato</label>'
        . '<label><input type="radio" name="_prev_fmt" value="storia" data-sl-prev> Storia</label><label><input type="radio" name="_prev_fmt" value="sticker" data-sl-prev> Sticker</label></div>'
        . '<small class="muted">Anteprima: il testo sotto la medaglia sarà il risultato di chi completa la sfida.</small></div></div>'
        . '<label class="check"><input type="checkbox" name="auto_iscrizione" value="1"' . ((int)$v['auto_iscrizione'] ? ' checked' : '') . '> Tutti gli utenti registrati partecipano in automatico</label>'
        . '<label class="check"><input type="checkbox" name="attiva" value="1"' . ((int)$v['attiva'] ? ' checked' : '') . '> Visibile nel sito</label>'
        . '<div class="savebar"><button class="btn primary" type="submit">Salva la sfida</button> <a class="btn link" href="' . h($plugin->admin_url('gestione')) . '">Annulla</a></div></form>';
    if ($v['id']) {
        echo $plugin->form_start('data-confirm="Eliminare la sfida con tutte le partecipazioni? Gli sticker già vinti spariranno."') . '<input type="hidden" name="op" value="elimina"><input type="hidden" name="id" value="' . (int)$v['id'] . '">'
            . '<button class="btn danger-ghost small" type="submit">Elimina la sfida</button></form>';
    }
    echo '</div>';
}

// Sezione "Un'immagine tua": caricamento (PNG anche trasparenti, JPG, WEBP) o scelta tra le immagini di Media
function sl_editor_immagine($v, $g)
{
    $scelta = !empty($g['img']) ? (int)$g['img'] : 0;
    $h = '<div class="sl-img" data-sl-img' . ($v['disegno'] === 'immagine' ? '' : ' hidden') . '>'
        . '<label class="lab" for="sl-img-file">Carica un\'immagine</label>'
        . '<input class="input" type="file" id="sl-img-file" name="sticker_img" accept="image/png,image/jpeg,image/webp" data-sl-file data-sl-prev>'
        . '<p class="hint">PNG con lo sfondo trasparente, JPG o WEBP, almeno 600 × 600 pixel. Finisce in Media, cartella «Sticker delle sfide», e puoi riusarla in altre sfide.</p>';
    $imgs = media_ready() ? media_list('all', '', 'image', 80) : array();
    $imgs = array_values(array_filter($imgs, function ($m) { return in_array(strtolower(pathinfo($m['filename'], PATHINFO_EXTENSION)), array('png', 'jpg', 'jpeg', 'webp'), true); }));
    // l'immagine già scelta resta in elenco anche se è vecchia
    if ($scelta && !in_array($scelta, array_map(function ($m) { return (int)$m['id']; }, $imgs), true)) {
        $m = media_get($scelta);
        if ($m && $m['kind'] === 'image') {
            array_unshift($imgs, $m);
        }
    }
    if ($imgs) {
        $h .= '<label class="lab">…oppure scegline una da Media</label><div class="sl-galleria">';
        foreach ($imgs as $m) {
            $t = (int)$m['has_thumb'] ? media_url($m['filename'], true) : media_url($m['filename']);
            $h .= '<label class="sl-gal" title="' . h($m['title']) . '"><input type="radio" name="img" value="' . (int)$m['id'] . '"' . ((int)$m['id'] === $scelta ? ' checked' : '')
                . ' data-full="' . h(media_url($m['filename'])) . '" data-sl-prev><img src="' . h($t) . '" alt="' . h($m['title']) . '" loading="lazy"></label>';
        }
        $h .= '</div>';
    }
    return $h . '<p class="alert error" data-sl-img-warn hidden>Carica un\'immagine o scegline una da Media.</p><label class="lab">Come usarla</label>' . sl_sel('img_modo', sl_modi_immagine(), isset($g['img_modo']) ? $g['img_modo'] : 'medaglia', 'data-sl-prev') . '</div>';
}

// Salva l'immagine caricata in Media; restituisce l'id, 0 se non c'è un file, o un messaggio di errore
function sl_carica_immagine()
{
    if (empty($_FILES['sticker_img']) || !is_array($_FILES['sticker_img']) || (int)$_FILES['sticker_img']['error'] === UPLOAD_ERR_NO_FILE) {
        return 0;
    }
    $f = $_FILES['sticker_img'];
    $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, array('png', 'jpg', 'jpeg', 'webp'), true)) {
        return 'Per lo sticker usa un\'immagine PNG, JPG o WEBP.';
    }
    if (!media_ready()) {
        return 'La libreria Media non è ancora pronta: aggiorna il sito.';
    }
    list($ok, $r) = media_store($f, sl_cartella_media());
    return $ok ? (int)$r : (string)$r;
}

function sl_salva_admin($plugin)
{
    $op = post('op');
    $T = sl_t($plugin, 'sfide');
    if ($op === 'elimina') {
        $s = sl_sfida($plugin, (int)post('id'));
        if ($s) {
            db()->prepare('DELETE FROM ' . sl_t($plugin, 'iscrizioni') . ' WHERE sfida_id = ?')->execute(array((int)$s['id']));
            db()->prepare('DELETE FROM ' . $T . ' WHERE id = ?')->execute(array((int)$s['id']));
            $plugin->log('Sfida "' . $s['titolo'] . '" eliminata', 'warn');
            flash('Sfida eliminata.');
        }
        redirect($plugin->admin_url('gestione'));
    }
    if ($op !== 'salva') {
        return;
    }
    $tipo = isset(sl_tipi()[post('tipo')]) ? post('tipo') : 'libri';
    $titolo = str_cut(trim(post('titolo')), 120);
    if ($titolo === '') {
        flash('Scrivi il titolo della sfida.', 'error');
        redirect($plugin->admin_url('gestione', array('nuova' => 1)));
    }
    if ($tipo === 'maratona') {
        $ini = date('Y-m-d H:i:s', strtotime(post('inizio_t')));
        $fin = date('Y-m-d H:i:s', strtotime(post('fine_t')));
    } else {
        $ini = date('Y-m-d', strtotime(post('inizio_d') ?: 'today')) . ' 00:00:00';
        $fin = date('Y-m-d', strtotime(post('fine_d') ?: 'today')) . ' 23:59:59';
    }
    if ($fin <= $ini) {
        flash('La fine deve venire dopo l\'inizio.', 'error');
        redirect($plugin->admin_url('gestione', (int)post('id') ? array('modifica' => (int)post('id')) : array('nuova' => 1)));
    }
    $num = function ($k, $min, $max) { $x = (int)post($k); return $x >= $min && $x <= $max ? $x : ''; };
    $g = array('n' => max(1, min(100000, (int)post('n'))));
    if (in_array($tipo, array('libri', 'pagine', 'genere', 'lunghi', 'classici', 'famiglia'), true)) {
        $g += array('categoria' => (int)post('categoria'), 'termine' => (int)post('termine'), 'pagine_min' => $num('pagine_min', 1, 100000),
            'pagine_max' => $num('pagine_max', 1, 100000), 'anno_prima' => $num('anno_prima', 1000, 2100), 'anno_dopo' => $num('anno_dopo', 1000, 2100));
    }
    if ($tipo === 'famiglia') {
        $g['misura'] = post('misura') === 'pagine' ? 'pagine' : 'libri';
    }
    if ($tipo === 'alfabeto') {
        $l = preg_replace('/[^\p{L}]/u', '', mb_strtoupper(post('lettere'), 'UTF-8'));
        $g['lettere'] = $l !== '' ? mb_substr(implode('', array_unique(preg_split('//u', $l, -1, PREG_SPLIT_NO_EMPTY))), 0, 40, 'UTF-8') : 'ABCDEFGHILMNOPQRSTUVZ';
        $g['articoli'] = post('articoli') === '1' ? 1 : 0;
    }
    if ($tipo === 'bingo') {
        $dim = in_array((int)post('dim'), array(3, 4, 5), true) ? (int)post('dim') : 3;
        $cr = sl_criteri();
        $celle = array();
        $in = isset($_POST['celle']) && is_array($_POST['celle']) ? $_POST['celle'] : array();
        for ($i = 0; $i < $dim * $dim; $i++) {
            $k = isset($in[$i][0]) && isset($cr[$in[$i][0]]) ? $in[$i][0] : 'libera';
            $tv = $cr[$k][1];
            $val = $tv === 'genere' ? (int)(isset($_POST['celle_g'][$i]) ? $_POST['celle_g'][$i] : 0)
                : ($tv === 'termine' ? (int)(isset($_POST['celle_t'][$i]) ? $_POST['celle_t'][$i] : 0)
                : str_cut(trim((string)(isset($in[$i][1]) ? $in[$i][1] : '')), 40));
            if (($tv === 'num' || $tv === 'anno') && !preg_match('/^\d+([.,]\d+)?$/', (string)$val)) {
                $k = 'libera';
                $val = '';
            }
            $celle[] = array($k, (string)$val);
        }
        $g += array('dim' => $dim, 'vittoria' => post('vittoria') === 'griglia' ? 'griglia' : 'riga', 'celle' => $celle);
    }
    $disegno = isset(sl_disegni()[post('disegno')]) || post('disegno') === 'immagine' ? post('disegno') : 'pila';
    if ($disegno === 'immagine') {
        $up = sl_carica_immagine();
        if (is_string($up)) {
            flash_add($up . ' La sfida è stata salvata con il disegno «Pila di libri».', 'error');
            $disegno = 'pila';
        } else {
            $img = $up ? $up : (int)post('img');
            $m = $img ? media_get($img) : null;
            if ($m && $m['kind'] === 'image') {
                $g['img'] = (int)$m['id'];
                $g['img_modo'] = isset(sl_modi_immagine()[post('img_modo')]) ? post('img_modo') : 'medaglia';
            } else {
                flash_add('Non hai scelto nessuna immagine: la sfida usa il disegno «Pila di libri».', 'error');
                $disegno = 'pila';
            }
        }
    }
    if ($tipo === 'lunghi' && empty($g['pagine_min'])) {
        $g['pagine_min'] = 500;
    }
    if ($tipo === 'classici' && empty($g['anno_prima'])) {
        $g['anno_prima'] = 1950;
    }
    $vals = array($titolo, str_cut(trim(str_replace("\r", '', (string)post('descrizione'))), 1000), $tipo, json_encode($g, JSON_UNESCAPED_UNICODE), $ini, $fin,
        isset(sl_livelli()[post('livello')]) ? post('livello') : 'argento', $disegno,
        post('auto_iscrizione') === '1' ? 1 : 0, post('attiva') === '1' ? 1 : 0, now());
    $id = (int)post('id');
    if ($id && sl_sfida($plugin, $id)) {
        db()->prepare('UPDATE ' . $T . ' SET titolo = ?, descrizione = ?, tipo = ?, regole = ?, inizio = ?, fine = ?, livello = ?, disegno = ?, auto_iscrizione = ?, attiva = ?, updated_at = ? WHERE id = ?')
            ->execute(array_merge($vals, array($id)));
        $plugin->log('Sfida "' . $titolo . '" modificata');
        flash('Sfida salvata.');
    } else {
        db()->prepare('INSERT INTO ' . $T . ' (titolo, descrizione, tipo, regole, inizio, fine, livello, disegno, auto_iscrizione, attiva, updated_at, creata_da, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
            ->execute(array_merge($vals, array(current_uid(), now())));
        $plugin->log('Nuova sfida "' . $titolo . '"');
        flash('Sfida creata: la trovi nel sito in «Sfide di lettura».');
    }
    redirect($plugin->admin_url('gestione'));
}
