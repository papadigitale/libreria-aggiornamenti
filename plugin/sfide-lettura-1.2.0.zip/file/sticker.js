/*
 * Sticker delle Sfide di lettura: disegnati nel browser (canvas), poi scaricati o condivisi.
 * Formati: storia 1080×1920 (stato di WhatsApp, storie), quadrato 1080×1080 (post), sticker 512×512 trasparente.
 * Tutti i disegni sono originali (medaglia + illustrazione a tema libri), nessuna immagine esterna.
 */
(function () {
  'use strict';
  var PAL = {
    bronzo:   { a: '#c27b3d', b: '#8a4f22', c: '#f3c999', d: '#fff3e3', t: 'BRONZO' },
    argento:  { a: '#aab5c1', b: '#5e6b78', c: '#e6ecf2', d: '#ffffff', t: 'ARGENTO' },
    oro:      { a: '#e2a828', b: '#93600b', c: '#ffe08a', d: '#fffaf0', t: 'ORO' },
    leggenda: { a: '#7c4ddb', b: '#3b1f7d', c: '#d8c6ff', d: '#f7f2ff', t: 'LEGGENDA' }
  };
  var INK = '#3a2a1f', PAPER = '#fffaf2', SERIF = 'Georgia, "Times New Roman", serif', SANS = 'system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif';

  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function star(c, x, y, r, inner, n) {
    c.beginPath();
    for (var i = 0; i < n * 2; i++) {
      var rad = i % 2 ? r * inner : r, a = -Math.PI / 2 + i * Math.PI / n;
      c[i ? 'lineTo' : 'moveTo'](x + rad * Math.cos(a), y + rad * Math.sin(a));
    }
    c.closePath();
  }
  function fillStroke(c, fill, stroke, lw) { if (fill) { c.fillStyle = fill; c.fill(); } if (stroke) { c.strokeStyle = stroke; c.lineWidth = lw || 3; c.stroke(); } }

  /* ---------- Illustrazioni (coordinate da -50 a 50, centro della medaglia) ---------- */
  var DIS = {
    pila: function (c, p) {
      var libri = [[-40, 14, 80, 20, '#7a1f2b'], [-34, -8, 70, 20, '#2f5d8a'], [-38, -30, 74, 20, p.a]];
      libri.forEach(function (b) {
        rr(c, b[0], b[1], b[2], b[3], 4); fillStroke(c, b[4], INK, 2.5);
        c.fillStyle = PAPER; c.fillRect(b[0] + b[2] - 10, b[1] + 3, 6, b[3] - 6);
        c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 2; c.beginPath(); c.moveTo(b[0] + 10, b[1] + 6); c.lineTo(b[0] + 10, b[1] + b[3] - 6); c.stroke();
      });
      star(c, 26, -42, 8, .45, 5); fillStroke(c, p.d, INK, 2);
    },
    libro: function (c, p) {
      c.lineJoin = 'round';
      c.beginPath(); c.moveTo(0, -20); c.bezierCurveTo(-16, -30, -34, -30, -46, -24); c.lineTo(-46, 28); c.bezierCurveTo(-34, 22, -16, 22, 0, 32); c.closePath(); fillStroke(c, PAPER, INK, 2.5);
      c.beginPath(); c.moveTo(0, -20); c.bezierCurveTo(16, -30, 34, -30, 46, -24); c.lineTo(46, 28); c.bezierCurveTo(34, 22, 16, 22, 0, 32); c.closePath(); fillStroke(c, PAPER, INK, 2.5);
      c.strokeStyle = p.b; c.lineWidth = 2;
      for (var i = 0; i < 4; i++) {
        c.beginPath(); c.moveTo(-38, -12 + i * 9); c.quadraticCurveTo(-20, -18 + i * 9, -6, -10 + i * 9); c.stroke();
        c.beginPath(); c.moveTo(38, -12 + i * 9); c.quadraticCurveTo(20, -18 + i * 9, 6, -10 + i * 9); c.stroke();
      }
      c.beginPath(); c.moveTo(0, -20); c.lineTo(0, 32); c.strokeStyle = INK; c.lineWidth = 2.5; c.stroke();
      [[-18, -40, 6], [0, -46, 8], [18, -40, 6]].forEach(function (s) { star(c, s[0], s[1], s[2], .45, 5); fillStroke(c, p.a, INK, 1.5); });
    },
    gufo: function (c, p) {
      c.beginPath(); c.moveTo(-26, -26); c.lineTo(-18, -44); c.lineTo(-8, -30); c.closePath(); fillStroke(c, '#7a4e33', INK, 2);
      c.beginPath(); c.moveTo(26, -26); c.lineTo(18, -44); c.lineTo(8, -30); c.closePath(); fillStroke(c, '#7a4e33', INK, 2);
      c.beginPath(); c.ellipse(0, 4, 32, 38, 0, 0, Math.PI * 2); fillStroke(c, '#8b5a3c', INK, 2.5);
      c.beginPath(); c.ellipse(0, 14, 20, 24, 0, 0, Math.PI * 2); fillStroke(c, '#e8c9a0', null);
      [-13, 13].forEach(function (x) {
        c.beginPath(); c.arc(x, -10, 11, 0, Math.PI * 2); fillStroke(c, PAPER, INK, 2);
        c.beginPath(); c.arc(x + 1, -9, 5, 0, Math.PI * 2); fillStroke(c, INK, null);
        c.beginPath(); c.arc(x + 3, -11, 1.6, 0, Math.PI * 2); fillStroke(c, '#fff', null);
      });
      c.strokeStyle = INK; c.lineWidth = 2.5; c.beginPath(); c.arc(-13, -10, 13, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); c.beginPath(); c.arc(13, -10, 13, Math.PI * 1.1, Math.PI * 1.9); c.stroke();
      c.beginPath(); c.moveTo(-5, 2); c.lineTo(5, 2); c.lineTo(0, 9); c.closePath(); fillStroke(c, '#e89a2c', INK, 1.5);
      rr(c, -30, 34, 60, 12, 3); fillStroke(c, '#7a1f2b', INK, 2); c.fillStyle = PAPER; c.fillRect(-27, 37, 54, 3);
    },
    lampada: function (c, p) {
      var g = c.createRadialGradient(0, 6, 4, 0, 18, 46); g.addColorStop(0, 'rgba(255,224,120,.9)'); g.addColorStop(1, 'rgba(255,224,120,0)');
      c.fillStyle = g; c.beginPath(); c.moveTo(-30, -8); c.lineTo(30, -8); c.lineTo(46, 34); c.lineTo(-46, 34); c.closePath(); c.fill();
      c.beginPath(); c.moveTo(-34, -6); c.lineTo(34, -6); c.lineTo(22, -32); c.lineTo(-22, -32); c.closePath(); fillStroke(c, '#2e6b4f', INK, 2.5);
      c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(-16, -28, 6, 18);
      rr(c, -3, -6, 6, 30, 2); fillStroke(c, p.b, INK, 2);
      c.beginPath(); c.ellipse(0, 26, 20, 6, 0, 0, Math.PI * 2); fillStroke(c, p.b, INK, 2);
      rr(c, -40, 32, 80, 12, 3); fillStroke(c, '#7a1f2b', INK, 2); c.fillStyle = PAPER; c.fillRect(-37, 35, 74, 3);
    },
    segnalibro: function (c, p) {
      rr(c, -36, -34, 72, 68, 6); fillStroke(c, PAPER, INK, 2.5);
      c.strokeStyle = p.c; c.lineWidth = 3;
      for (var i = 0; i < 5; i++) { c.beginPath(); c.moveTo(-26, -20 + i * 11); c.lineTo(i % 2 ? 10 : 18, -20 + i * 11); c.stroke(); }
      c.beginPath(); c.moveTo(14, -44); c.lineTo(34, -44); c.lineTo(34, 30); c.lineTo(24, 20); c.lineTo(14, 30); c.closePath(); fillStroke(c, '#b3261e', INK, 2.5);
      star(c, 24, -24, 7, .45, 5); fillStroke(c, p.c, null);
    },
    tazza: function (c, p) {
      c.strokeStyle = p.b; c.lineWidth = 3; c.lineCap = 'round';
      [-12, 0, 12].forEach(function (x) { c.beginPath(); c.moveTo(x, -26); c.bezierCurveTo(x - 6, -34, x + 6, -38, x, -46); c.stroke(); });
      c.beginPath(); c.moveTo(-26, -20); c.lineTo(26, -20); c.lineTo(22, 16); c.quadraticCurveTo(21, 22, 14, 22); c.lineTo(-14, 22); c.quadraticCurveTo(-21, 22, -22, 16); c.closePath(); fillStroke(c, PAPER, INK, 2.5);
      c.beginPath(); c.arc(30, -4, 10, -Math.PI / 2, Math.PI / 2); c.strokeStyle = INK; c.lineWidth = 4; c.stroke();
      c.fillStyle = p.a; c.fillRect(-23, -6, 46, 7);
      rr(c, -42, 24, 84, 14, 3); fillStroke(c, '#2f5d8a', INK, 2); c.fillStyle = PAPER; c.fillRect(-39, 27, 78, 3);
    },
    occhiali: function (c, p) {
      rr(c, -42, 4, 84, 30, 4); fillStroke(c, '#7a1f2b', INK, 2.5); c.fillStyle = PAPER; c.fillRect(-38, 26, 76, 5);
      c.strokeStyle = p.c; c.lineWidth = 2; c.strokeRect(-30, 10, 30, 10);
      c.lineWidth = 4; c.strokeStyle = INK;
      [-17, 17].forEach(function (x) { c.beginPath(); c.arc(x, -14, 13, 0, Math.PI * 2); c.fillStyle = 'rgba(200,230,255,.55)'; c.fill(); c.stroke(); });
      c.beginPath(); c.moveTo(-4, -16); c.quadraticCurveTo(0, -21, 4, -16); c.stroke();
      c.beginPath(); c.moveTo(-30, -16); c.lineTo(-40, -22); c.moveTo(30, -16); c.lineTo(40, -22); c.stroke();
      c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.arc(-21, -18, 5, Math.PI, Math.PI * 1.5); c.stroke(); c.beginPath(); c.arc(13, -18, 5, Math.PI, Math.PI * 1.5); c.stroke();
    },
    stelle: function (c, p) {
      c.save(); c.rotate(-0.14);
      rr(c, -30, -26, 60, 60, 5); fillStroke(c, '#2d2a6e', INK, 2.5);
      c.fillStyle = PAPER; c.fillRect(24, -22, 4, 52);
      star(c, -2, 4, 15, .45, 5); fillStroke(c, p.c, null);
      c.restore();
      [[-38, -34, 7], [36, -30, 9], [40, 22, 6], [-40, 26, 5]].forEach(function (s) { star(c, s[0], s[1], s[2], .42, 4); fillStroke(c, p.a, INK, 1.5); });
    }
  };

  /* ---------- Medaglia ---------- */
  /* ---------- Immagine caricata dall'Admin o dal Gestore ---------- */
  var cache = {};
  function carica(url) {
    if (!url) { return Promise.resolve(null); }
    if (!cache[url]) {
      cache[url] = new Promise(function (ok) {
        var im = new Image();
        im.onload = function () { im.trasp = trasparente(im); ok(im); };
        im.onerror = function () { ok(null); };
        im.src = url;
      });
    }
    return cache[url];
  }
  // true se il bordo dell'immagine e' (in buona parte) trasparente: PNG senza sfondo
  function trasparente(im) {
    try {
      var k = document.createElement('canvas'); k.width = 64; k.height = 64;
      var x = k.getContext('2d'); x.drawImage(im, 0, 0, 64, 64);
      var d = x.getImageData(0, 0, 64, 64).data, n = 0, t = 0;
      for (var i = 0; i < 64; i++) {
        [[i, 0], [i, 63], [0, i], [63, i]].forEach(function (q) { n++; if (d[(q[1] * 64 + q[0]) * 4 + 3] < 200) { t++; } });
      }
      return t / n > 0.05;
    } catch (e) { return false; }
  }
  // disegna l'immagine dentro il rettangolo (w x h) centrato in (x, y): contain = tutta visibile, altrimenti riempie
  function piazza(c, im, x, y, w, h, contain) {
    var r = contain ? Math.min(w / im.naturalWidth, h / im.naturalHeight) : Math.max(w / im.naturalWidth, h / im.naturalHeight);
    var iw = im.naturalWidth * r, ih = im.naturalHeight * r;
    c.drawImage(im, x - iw / 2, y - ih / 2, iw, ih);
    return [iw, ih];
  }
  // immagine da sola, al posto della medaglia (box quadrato di lato L centrato in cx, cy)
  function libera(c, cx, cy, L, im) {
    c.save();
    if (im.trasp) {
      c.shadowColor = 'rgba(0,0,0,.28)'; c.shadowBlur = L * .04; c.shadowOffsetY = L * .02;
      piazza(c, im, cx, cy, L, L, true);
    } else {
      // foto o immagine con lo sfondo: angoli arrotondati e bordo bianco, come un adesivo
      var r = Math.min(L / im.naturalWidth, L / im.naturalHeight), iw = im.naturalWidth * r, ih = im.naturalHeight * r, b = L * .025;
      c.shadowColor = 'rgba(0,0,0,.28)'; c.shadowBlur = L * .04; c.shadowOffsetY = L * .02;
      rr(c, cx - iw / 2 - b, cy - ih / 2 - b, iw + 2 * b, ih + 2 * b, L * .06); c.fillStyle = '#fff'; c.fill();
      c.shadowColor = 'transparent';
      rr(c, cx - iw / 2, cy - ih / 2, iw, ih, L * .045); c.clip();
      c.drawImage(im, cx - iw / 2, cy - ih / 2, iw, ih);
    }
    c.restore();
  }
  // medaglia o immagine libera; R = raggio della medaglia
  function figura(c, cx, cy, R, p, d, im) {
    if (im && d.modo === 'libera') { libera(c, cx, cy + R * .2, R * 2.4, im); } else { medaglia(c, cx, cy, R, p, d.disegno, im); }
  }

  function medaglia(c, cx, cy, R, p, disegno, im) {
    c.save(); c.translate(cx, cy);
    // nastri
    c.beginPath(); c.moveTo(-R * .45, R * .55); c.lineTo(-R * .72, R * 1.32); c.lineTo(-R * .5, R * 1.2); c.lineTo(-R * .38, R * 1.42); c.lineTo(-R * .1, R * .7); c.closePath(); fillStroke(c, p.b, null);
    c.beginPath(); c.moveTo(R * .45, R * .55); c.lineTo(R * .72, R * 1.32); c.lineTo(R * .5, R * 1.2); c.lineTo(R * .38, R * 1.42); c.lineTo(R * .1, R * .7); c.closePath(); fillStroke(c, p.a, null);
    // ombra
    c.shadowColor = 'rgba(0,0,0,.25)'; c.shadowBlur = R * .12; c.shadowOffsetY = R * .05;
    star(c, 0, 0, R, .9, 24); fillStroke(c, p.a, null);
    c.shadowColor = 'transparent';
    star(c, 0, 0, R, .9, 24); c.strokeStyle = p.b; c.lineWidth = R * .025; c.stroke();
    c.beginPath(); c.arc(0, 0, R * .8, 0, Math.PI * 2); fillStroke(c, p.b, null);
    var g = c.createRadialGradient(-R * .25, -R * .3, R * .1, 0, 0, R * .78); g.addColorStop(0, p.d); g.addColorStop(1, p.c);
    c.beginPath(); c.arc(0, 0, R * .74, 0, Math.PI * 2); fillStroke(c, g, null);
    // punti decorativi sul bordo interno
    c.fillStyle = p.b;
    for (var i = 0; i < 36; i++) { var a = i * Math.PI / 18; c.beginPath(); c.arc(Math.cos(a) * R * .77, Math.sin(a) * R * .77, R * .008, 0, Math.PI * 2); c.fill(); }
    if (im) {
      c.save(); c.beginPath(); c.arc(0, 0, R * .74, 0, Math.PI * 2); c.clip();
      if (im.trasp) { piazza(c, im, 0, 0, R * 1.2, R * 1.2, true); } else { piazza(c, im, 0, 0, R * 1.48, R * 1.48, false); }
      c.restore();
      c.beginPath(); c.arc(0, 0, R * .74, 0, Math.PI * 2); c.strokeStyle = p.b; c.lineWidth = R * .02; c.stroke();
      c.restore();
      return;
    }
    c.scale(R * .0105, R * .0105);
    c.lineJoin = 'round'; c.lineCap = 'round';
    (DIS[disegno] || DIS.pila)(c, p);
    c.restore();
  }

  /* ---------- Testi ---------- */
  function righe(c, testo, max, maxRighe) {
    var parole = String(testo).split(/\s+/), out = [], cur = '';
    parole.forEach(function (w) {
      var prova = cur ? cur + ' ' + w : w;
      if (c.measureText(prova).width > max && cur) { out.push(cur); cur = w; } else { cur = prova; }
    });
    if (cur) { out.push(cur); }
    if (out.length > maxRighe) { out = out.slice(0, maxRighe); out[maxRighe - 1] = out[maxRighe - 1].replace(/\s*\S*$/, '') + '…'; }
    return out;
  }
  function spaziato(c, testo, x, y, sp) {
    var w = 0, i;
    for (i = 0; i < testo.length; i++) { w += c.measureText(testo[i]).width + (i < testo.length - 1 ? sp : 0); }
    var cx = x - w / 2;
    c.textAlign = 'left';
    for (i = 0; i < testo.length; i++) { c.fillText(testo[i], cx, y); cx += c.measureText(testo[i]).width + sp; }
    c.textAlign = 'center';
  }

  function disegna(cv, d, fmt, conNome, im) {
    var p = PAL[d.livello] || PAL.argento;
    var W = fmt === 'storia' ? 1080 : (fmt === 'quadrato' ? 1080 : 512), H = fmt === 'storia' ? 1920 : (fmt === 'quadrato' ? 1080 : 512);
    cv.width = W; cv.height = H;
    var c = cv.getContext('2d');
    c.clearRect(0, 0, W, H);
    c.textAlign = 'center'; c.textBaseline = 'alphabetic';
    if (fmt === 'sticker') {
      if (im && d.modo === 'libera') { libera(c, 256, 190, 340, im); } else { medaglia(c, 256, 200, 168, p, d.disegno, im); }
      // fascia con il titolo
      c.save(); c.shadowColor = 'rgba(0,0,0,.25)'; c.shadowBlur = 10; c.shadowOffsetY = 4;
      rr(c, 24, 372, 464, conNome ? 112 : 92, 22); fillStroke(c, p.b, '#fff', 6); c.restore();
      c.fillStyle = '#fff'; c.font = 'bold 38px ' + SERIF;
      var t = righe(c, d.titolo, 420, 1)[0];
      c.fillText(t, 256, 420);
      c.font = '600 24px ' + SANS; c.fillStyle = 'rgba(255,255,255,.88)';
      c.fillText(d.valore + ' · ' + d.anno + (conNome ? '' : ''), 256, 452);
      if (conNome) { c.font = 'italic 24px ' + SERIF; c.fillText(d.nome, 256, 476); }
      return;
    }
    // sfondo
    var g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, p.d); g.addColorStop(.55, p.c); g.addColorStop(1, p.a);
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.fillStyle = 'rgba(255,255,255,.35)';
    for (var i = 0; i < 60; i++) { var x = (i * 173) % W, y = (i * 311) % H, r = 2 + (i % 4); star(c, x, y, r * 2, .4, 4); c.fill(); }
    c.fillStyle = INK;
    var top = fmt === 'storia' ? 230 : 110, cy = fmt === 'storia' ? 760 : 360, R = fmt === 'storia' ? 300 : 185;
    c.font = '700 40px ' + SANS; c.fillStyle = p.b;
    spaziato(c, 'SFIDA COMPLETATA', W / 2, top, 10);
    figura(c, W / 2, cy, R, p, d, im);
    var y = fmt === 'storia' ? cy + R * 1.58 + 40 : cy + R * 1.42 + 80;
    c.fillStyle = INK; c.font = 'bold ' + (fmt === 'storia' ? 76 : 60) + 'px ' + SERIF;
    righe(c, d.titolo, W - 160, fmt === 'storia' ? 3 : 2).forEach(function (l, k) { c.fillText(l, W / 2, y + k * (fmt === 'storia' ? 90 : 70)); y += 0; });
    var nr = righe(c, d.titolo, W - 160, fmt === 'storia' ? 3 : 2).length;
    y += nr * (fmt === 'storia' ? 90 : 70) + (fmt === 'storia' ? 20 : 4);
    c.font = '600 ' + (fmt === 'storia' ? 46 : 38) + 'px ' + SANS; c.fillStyle = p.b;
    c.fillText(d.valore + ' · ' + d.anno, W / 2, y);
    y += fmt === 'storia' ? 80 : 56;
    // etichetta del livello
    c.font = '800 ' + (fmt === 'storia' ? 30 : 26) + 'px ' + SANS;
    var lw = c.measureText(p.t).width + 60;
    rr(c, W / 2 - lw / 2, y - 40, lw, 56, 28); fillStroke(c, p.b, null);
    c.fillStyle = '#fff'; spaziato(c, p.t, W / 2, y - 2, 6);
    if (conNome) {
      y += fmt === 'storia' ? 100 : 70;
      c.fillStyle = INK; c.font = 'italic ' + (fmt === 'storia' ? 50 : 40) + 'px ' + SERIF;
      c.fillText(d.nome, W / 2, y);
    }
    c.font = '500 ' + (fmt === 'storia' ? 30 : 26) + 'px ' + SANS; c.fillStyle = 'rgba(43,29,20,.7)';
    c.fillText(d.sito + ' · ' + d.data, W / 2, H - (fmt === 'storia' ? 120 : 50));
  }

  // usato anche dall'anteprima nell'editor delle sfide
  window.SLSticker = { carica: carica, disegna: disegna };

  document.querySelectorAll('[data-sticker]').forEach(function (card) {
    var d;
    try { d = JSON.parse(card.getAttribute('data-sticker')); } catch (e) { return; }
    var cv = card.querySelector('canvas');
    var nome = card.querySelector('[data-sl-nome]');
    var fmt = function () { var r = card.querySelector('input[type=radio]:checked'); return r ? r.value : 'storia'; };
    var pronto = carica(d.img);
    var ridisegna = function () {
      pronto = pronto.then(function (im) { disegna(cv, d, fmt(), nome && nome.checked, im); card.setAttribute('data-fmt', fmt()); return im; });
      return pronto;
    };
    card.querySelectorAll('input[type=radio]').forEach(function (r) { r.addEventListener('change', ridisegna); });
    if (nome) { nome.addEventListener('change', ridisegna); }
    var blob = function () { return pronto.then(function () { return new Promise(function (ok) { cv.toBlob(function (b) { ok(b); }, 'image/png'); }); }); };
    var nomeFile = function () { return (d.file || 'sticker') + '-' + fmt() + '.png'; };
    card.querySelector('[data-sl-scarica]').addEventListener('click', function () {
      blob().then(function (b) {
        var a = document.createElement('a');
        a.href = URL.createObjectURL(b); a.download = nomeFile();
        document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
      });
    });
    var sh = card.querySelector('[data-sl-condividi]');
    if (sh && navigator.canShare && window.File) {
      try {
        if (navigator.canShare({ files: [new File([new Blob(['x'], { type: 'image/png' })], 'x.png', { type: 'image/png' })] })) {
          sh.hidden = false;
          sh.addEventListener('click', function () {
            blob().then(function (b) {
              var file = new File([b], nomeFile(), { type: 'image/png' });
              navigator.share({ files: [file], title: d.titolo, text: 'Sfida completata: ' + d.titolo }).catch(function () {});
            });
          });
        }
      } catch (e) { /* condivisione non disponibile */ }
    }
    ridisegna();
  });
})();
