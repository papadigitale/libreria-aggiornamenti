// Editor delle sfide (Gestione → Plugin → Sfide di lettura): mostra solo i campi del tipo scelto
(function () {
  var f = document.querySelector('[data-sl-editor]');
  if (!f) { return; }
  var meta = {};
  try { meta = JSON.parse(f.getAttribute('data-sl-meta')); } catch (e) { meta = { tipi: {}, crit: {} }; }
  var tipo = f.querySelector('[data-sl-tipo]');
  var dim = f.querySelector('[data-sl-dim]');
  var etichette = { libri: 'Quanti libri', genere: 'Quanti libri', lunghi: 'Quanti libri', classici: 'Quanti libri', pagine: 'Quante pagine', maratona: 'Quante pagine', famiglia: 'Obiettivo comune' };
  var aggiorna = function () {
    var t = tipo.value;
    f.querySelectorAll('[data-sl-per]').forEach(function (el) {
      el.hidden = el.getAttribute('data-sl-per').split(' ').indexOf(t) < 0;
    });
    f.querySelectorAll('[data-sl-date]').forEach(function (el) { el.hidden = t === 'maratona'; });
    f.querySelectorAll('[data-sl-ora]').forEach(function (el) { el.hidden = t !== 'maratona'; });
    var lab = f.querySelector('[data-sl-n-lab]');
    if (lab) { lab.textContent = etichette[t] || 'Obiettivo'; }
    var d = f.querySelector('[data-sl-tipo-desc]');
    if (d) { d.textContent = meta.tipi[t] || ''; }
    var pm = f.querySelector('[name=pagine_min]'), ap = f.querySelector('[name=anno_prima]');
    if (t === 'lunghi' && pm && !pm.value) { pm.value = 500; }
    if (t === 'classici' && ap && !ap.value) { ap.value = 1950; }
    celle();
  };
  var celle = function () {
    var n = dim ? parseInt(dim.value, 10) : 3;
    f.querySelectorAll('[data-sl-cella]').forEach(function (c) {
      var i = parseInt(c.getAttribute('data-sl-cella'), 10);
      c.hidden = i >= n * n;
      var k = c.querySelector('[data-sl-crit]').value, tv = meta.crit[k] || '';
      c.querySelector('[data-sl-val]').hidden = !(tv === 'num' || tv === 'anno' || tv === 'testo');
      c.querySelector('[data-sl-valg]').hidden = tv !== 'genere';
      c.querySelector('[data-sl-valt]').hidden = tv !== 'termine';
    });
    var box = f.querySelector('[data-sl-celle]');
    if (box) { box.style.gridTemplateColumns = 'repeat(' + n + ', minmax(0, 1fr))'; }
  };
  // ---- premio: immagine tua e anteprima dello sticker ----
  var dis = f.querySelector('[data-sl-disegno]'), box = f.querySelector('[data-sl-img]'), cv = f.querySelector('[data-sl-anteprima]');
  var file = f.querySelector('[data-sl-file]'), blobUrl = '';
  var immagine = function () {
    if (!dis || dis.value !== 'immagine') { return ''; }
    if (file && file.files && file.files[0]) {
      if (!blobUrl) { blobUrl = URL.createObjectURL(file.files[0]); }
      return blobUrl;
    }
    var r = f.querySelector('input[name=img]:checked');
    return r ? r.getAttribute('data-full') : '';
  };
  var timer = null;
  var anteprima = function () {
    if (box) { box.hidden = !dis || dis.value !== 'immagine'; }
    if (!cv || !window.SLSticker) { return; }
    var t = tipo.value, n = (f.querySelector('[name=n]') || {}).value || '';
    var modo = (f.querySelector('[name=img_modo]') || {}).value || 'medaglia';
    var fr = f.querySelector('input[name=_prev_fmt]:checked');
    var oggi = new Date();
    var d = {
      titolo: (f.querySelector('[name=titolo]').value || 'Titolo della sfida'), livello: f.querySelector('[name=livello]').value,
      disegno: dis && dis.value !== 'immagine' ? dis.value : 'pila', modo: modo,
      valore: t === 'bingo' ? 'Bingo!' : (t === 'alfabeto' ? 'Alfabeto completo' : n + ' ' + (t === 'pagine' || t === 'maratona' ? (n === '1' ? 'pagina' : 'pagine') : (n === '1' ? 'libro' : 'libri'))),
      anno: String(oggi.getFullYear()), data: ('0' + oggi.getDate()).slice(-2) + '/' + ('0' + (oggi.getMonth() + 1)).slice(-2) + '/' + oggi.getFullYear(),
      nome: '', sito: cv.getAttribute('data-sito') || ''
    };
    var url = immagine();
    window.SLSticker.carica(url).then(function (im) {
      if (url && !im) { d.disegno = 'pila'; }
      window.SLSticker.disegna(cv, d, fr ? fr.value : 'quadrato', false, im);
      cv.parentNode.setAttribute('data-fmt', fr ? fr.value : 'quadrato');
    });
  };
  var presto = function () { if (box) { box.hidden = !dis || dis.value !== 'immagine'; } clearTimeout(timer); timer = setTimeout(anteprima, 200); };
  if (file) {
    file.addEventListener('change', function () {
      if (blobUrl) { URL.revokeObjectURL(blobUrl); blobUrl = ''; }
      // un file nuovo ha la precedenza sulle immagini di Media
      if (file.files && file.files[0]) { f.querySelectorAll('input[name=img]').forEach(function (r) { r.checked = false; }); }
    });
  }
  f.querySelectorAll('input[name=img]').forEach(function (r) {
    r.addEventListener('change', function () { if (file) { file.value = ''; if (blobUrl) { URL.revokeObjectURL(blobUrl); blobUrl = ''; } } });
  });
  f.querySelectorAll('[data-sl-prev], [name=titolo], [name=n], [data-sl-tipo]').forEach(function (el) {
    el.addEventListener(el.tagName === 'INPUT' && (el.type === 'text' || el.type === 'number' || !el.type) ? 'input' : 'change', presto);
  });
  f.addEventListener('submit', function (e) {
    if (dis && dis.value === 'immagine' && !immagine()) {
      e.preventDefault();
      if (box) { box.hidden = false; }
      if (file) { file.focus(); }
      var w = f.querySelector('[data-sl-img-warn]');
      if (w) { w.hidden = false; }
    }
  });
  anteprima();

  tipo.addEventListener('change', aggiorna);
  if (dim) { dim.addEventListener('change', celle); }
  f.querySelectorAll('[data-sl-crit]').forEach(function (s) { s.addEventListener('change', celle); });
  aggiorna();
})();
