<?php
/*
 * Sfide di lettura (in stile Goodreads) per la Libreria di Casa.
 *  - Admin e Gestori creano le sfide in Gestione → Plugin → Sfide di lettura (tipi, numeri, periodi, filtri, bingo… tutto personalizzabile).
 *  - Gli utenti registrati (anche il ruolo «Registrato») partecipano dal sito: menu ☰ → Sfide di lettura.
 *  - Il progresso si calcola da solo dalle letture; chi completa una sfida vince uno sticker da scaricare o condividere
 *    (stato di WhatsApp, storie, post) e il traguardo compare a tutti gli utenti registrati.
 */
require_once __DIR__ . '/motore.php';
require_once __DIR__ . '/pagine.php';
require_once __DIR__ . '/pannello.php';

/* ---------------- Installazione ---------------- */

$plugin->on_activate(function ($plugin, $prima) {
    sl_crea_tabelle($plugin);
});

$plugin->on_remove(function ($plugin, $cancella) {
    if ($cancella) {
        db()->exec('DROP TABLE IF EXISTS ' . sl_t($plugin, 'iscrizioni'));
        db()->exec('DROP TABLE IF EXISTS ' . sl_t($plugin, 'sfide'));
    }
});

/* ---------------- Stili e script ---------------- */

$plugin->on('html_testa', function ($html) use ($plugin) {
    return $html . $plugin->css('file/stile.css');
});
$plugin->on('admin_testa', function ($html) use ($plugin) {
    return $html . $plugin->css('file/stile.css');
});
$plugin->on('html_fondo', function ($html) use ($plugin) {
    return basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '') === 'plg.php' && get('p') === $plugin->id && get('s') === 'sticker'
        ? $html . $plugin->js('file/sticker.js') : $html;
});
$plugin->on('admin_fondo', function ($html) use ($plugin) {
    return get('sez') === 'plg-' . $plugin->id . '-gestione' ? $html . $plugin->js('file/sticker.js') . $plugin->js('file/editor.js') : $html;
});

/* ---------------- Completamenti: dopo ogni lettura finita, voto o avanzamento ---------------- */

$sl_dopo_lettura = function ($uid) use ($plugin) {
    if ((int)$uid !== current_uid()) {
        return;
    }
    foreach (sl_aggiorna($plugin, (int)$uid) as $s) {
        flash_add('Sfida completata: «' . $s['titolo'] . '»! Il tuo sticker ti aspetta in Sfide di lettura → I miei sticker.');
    }
};
$plugin->on('lettura_terminata', $sl_dopo_lettura);
$plugin->on('lettura_valutata', $sl_dopo_lettura);
$plugin->on('avanzamento_salvato', $sl_dopo_lettura);

/* ---------------- Ultimi traguardi in cima alla Libreria (a tutti gli utenti registrati) ---------------- */

$plugin->on('pagina_libreria', function ($html, $ricerca) use ($plugin) {
    if (!is_user() || $ricerca !== '') {
        return $html;
    }
    // ogni tanto si ricontrollano le sfide di chi guarda (iscrizioni automatiche, letture segnate da altre pagine)
    if (empty($_SESSION['sl_ctrl']) || $_SESSION['sl_ctrl'] < time() - 300) {
        $_SESSION['sl_ctrl'] = time();
        foreach (sl_aggiorna($plugin, current_uid()) as $s) {
            $html .= '<div class="alert success">Sfida completata: «' . h($s['titolo']) . '»! <a class="link" href="' . h($plugin->site_url('sticker')) . '">Scarica il tuo sticker</a></div>';
        }
    }
    return $html . sl_html_traguardi($plugin, 3);
});

$plugin->on('bacheca', function ($html) use ($plugin) {
    $att = 0;
    foreach (sl_sfide($plugin, true) as $s) {
        $att += sl_stato($s) === 'in_corso' ? 1 : 0;
    }
    $t = sl_traguardi($plugin, 5, 7);
    return $html . '<div class="card"><div class="ct">' . icon('award', 18) . ' Sfide di lettura</div><p class="sub">' . $att . ($att === 1 ? ' sfida in corso' : ' sfide in corso')
        . ' · ' . count($t) . ' traguardi negli ultimi 7 giorni.</p>' . ($t ? sl_html_traguardi($plugin, 5) : '')
        . '<a class="link" href="' . h($plugin->admin_url('gestione')) . '">Gestisci le sfide</a></div>';
});

/* ---------------- Pagine del sito ---------------- */

$plugin->site_page('sfide', 'Sfide di lettura', function ($plugin) {
    sl_pagina_sfide($plugin);
}, array('ruolo' => 'utente', 'menu' => true, 'icona' => 'award', 'salva' => function ($plugin) {
    $s = sl_sfida($plugin, (int)post('id'));
    if (!$s || !(int)$s['attiva']) {
        return;
    }
    if (post('op') === 'partecipa' && sl_stato($s) !== 'conclusa') {
        sl_iscrivi($plugin, $s['id'], current_uid());
        $nuove = sl_aggiorna($plugin, current_uid());
        flash($nuove ? 'Sei dentro, e hai già completato «' . $s['titolo'] . '»! Scarica il tuo sticker.' : 'Partecipi a «' . $s['titolo'] . '». Buone letture!');
    } elseif (post('op') === 'lascia') {
        db()->prepare('DELETE FROM ' . sl_t($plugin, 'iscrizioni') . ' WHERE sfida_id = ? AND user_id = ? AND completata_il IS NULL')->execute(array((int)$s['id'], current_uid()));
        flash('Hai lasciato la sfida.');
    }
    redirect($plugin->site_url('sfide', array('id' => (int)$s['id'])));
}));

$plugin->site_page('sticker', 'I miei sticker', function ($plugin) {
    sl_pagina_sticker($plugin);
}, array('ruolo' => 'utente'));

/* ---------------- Gestione (Admin e Gestore) ---------------- */

$plugin->admin_page('gestione', 'Sfide di lettura', function ($plugin) {
    sl_pannello($plugin);
}, array('ruolo' => 'editore', 'salva' => function ($plugin) {
    sl_salva_admin($plugin);
}));
