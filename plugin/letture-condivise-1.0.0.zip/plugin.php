<?php
/*
 * Letture condivise per la Libreria di Casa: ognuno vede a che punto sono gli altri con i loro libri.
 *  - «Letture di tutti» (menu ☰): gli avanzamenti, i libri iniziati, finiti (con voto e recensione) e messi da parte,
 *    dal piu' recente, con il cuore «mi piace» e i commenti.
 *  - Il profilo di ogni persona: cosa sta leggendo (con la barra), gli ultimi aggiornamenti, i libri letti.
 *  - Avviso nella campanella (e sul telefono) a chi riceve un cuore o un commento; ognuno puo' spegnerlo.
 *  - Privacy: si vedono solo le letture di chi ha acceso «Mostra le mie letture e i miei voti agli altri»;
 *    ognuno puo' nascondere singoli libri e scegliere se mostrare le note degli avanzamenti (spente all'inizio).
 *  - Riquadro con le novita' in cima alla Libreria.
 * Le letture sono quelle del diario di lettura del sito: il plugin non ne fa copie.
 */
require_once __DIR__ . '/dati.php';
require_once __DIR__ . '/pagine.php';

$plugin->on_activate(function ($plugin, $prima) {
    lc_crea_tabelle($plugin);
});

$plugin->on_remove(function ($plugin, $cancella) {
    if ($cancella) {
        foreach (array('mipiace', 'commenti', 'nascosti', 'preferenze') as $t) {
            db()->exec('DROP TABLE IF EXISTS ' . lc_t($plugin, $t));
        }
    }
});

/* ---------------- Stile e script ---------------- */

$lc_dove = function () use ($plugin) {
    $s = basename(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '');
    if ($s === 'plg.php') {
        return get('p') === $plugin->id ? 'mie' : '';
    }
    return in_array($s, array('libreria.php', 'libro.php'), true) ? $s : '';
};

$plugin->on('html_testa', function ($html) use ($plugin, $lc_dove) {
    return is_user() && $lc_dove() !== '' ? $html . $plugin->css('file/stile.css') : $html;
});
$plugin->on('html_fondo', function ($html) use ($plugin, $lc_dove) {
    $d = $lc_dove();
    return is_user() && ($d === 'mie' || $d === 'libro.php') ? $html . $plugin->js('file/letture.js') : $html;
});

/* ---------------- Riquadro in cima alla Libreria ---------------- */

$plugin->on('pagina_libreria', function ($html, $ricerca = '') use ($plugin) {
    if (!is_user() || (string)$ricerca !== '' || $plugin->setting('in_libreria', '1') !== '1' || get('cat') || get('stato') || get('et')) {
        return $html;
    }
    $vid = current_uid();
    list($n, $ult) = lc_novita($plugin, $vid);
    if (!$ult) {
        return $html;
    }
    require_once APP_ROOT . '/inc/reading.php';
    $frase = lc_nome($ult['uid']) . ' ' . lc_frase($ult);
    return $html . '<a class="lc-strip" href="' . h($plugin->site_url('tutti')) . '">' . lc_avatar($ult['uid'], 'sm')
        . '<span class="lc-strip-i"><span class="lc-strip-l">Letture di tutti</span><span class="lc-strip-t">' . h($frase) . ' · <i>' . h($ult['title']) . '</i></span></span>'
        . ($n ? '<em class="lc-strip-n" title="Novità dall\'ultima visita">' . ($n > 9 ? '9+' : $n) . '</em>' : '') . lc_icona('chev', 16) . '</a>';
});

/* ---------------- Nella scheda del libro: nasconderlo dalle letture di tutti ---------------- */

$plugin->on('scheda_libro', function ($html, $libro) use ($plugin) {
    if (!is_user() || empty($libro['id']) || $plugin->setting('in_scheda', '1') !== '1') {
        return $html;
    }
    $vid = current_uid();
    $me = lc_utente($vid);
    if (!$me || (int)$me['share_reading'] !== 1) {
        return $html;
    }
    $st = db()->prepare('SELECT COUNT(*) FROM reading_sessions WHERE user_id = ? AND book_id = ?');
    $st->execute(array($vid, (int)$libro['id']));
    $ha = (int)$st->fetchColumn();
    $st->closeCursor();
    if (!$ha) {
        return $html;
    }
    $nasc = lc_nascosto($plugin, $vid, (int)$libro['id']);
    return $html . '<div class="card lc-scheda" data-lc-scheda>'
        . '<span class="lc-scheda-i">' . lc_icona($nasc ? 'chiuso' : 'occhio', 20) . '<span><b>Letture di tutti</b><small data-lc-scheda-t>'
        . ($nasc ? 'Gli altri non vedono la tua lettura di questo libro.' : 'Gli altri vedono la tua lettura di questo libro.') . '</small></span></span>'
        . '<form method="post" action="' . h($plugin->site_url('tutti')) . '" data-lc-nascondi>' . csrf_field() . '<input type="hidden" name="action" value="plg_salva">'
        . '<input type="hidden" name="op" value="' . ($nasc ? 'mostra_libro' : 'nascondi_libro') . '"><input type="hidden" name="book" value="' . (int)$libro['id'] . '">'
        . '<input type="hidden" name="back" value="' . h($plugin->site_url('profilo', array('u' => $vid, 'imp' => 1))) . '">'
        . '<button class="btn ghost small" type="submit">' . ($nasc ? 'Mostra' : 'Nascondi') . '</button></form></div>';
});

/* ---------------- Pagine ---------------- */

$lc_salva = function ($plugin) {
    lc_salva($plugin);
};
$plugin->site_page('tutti', 'Letture di tutti', function ($plugin) {
    lc_pagina_tutti($plugin);
}, array('ruolo' => 'utente', 'menu' => true, 'icona' => 'user', 'salva' => $lc_salva));

$plugin->site_page('profilo', 'Letture', function ($plugin) {
    lc_pagina_profilo($plugin);
}, array('ruolo' => 'utente', 'salva' => $lc_salva));

$plugin->site_page('voce', 'Letture di tutti', function ($plugin) {
    lc_pagina_voce($plugin);
}, array('ruolo' => 'utente', 'salva' => $lc_salva));

$plugin->admin_page('impostazioni', 'Letture condivise', function ($plugin) {
    lc_pannello($plugin);
}, array('salva' => function ($plugin) {
    lc_pannello_salva($plugin);
}));

/* ---------------- Chiamate dello script ---------------- */

// cuore a un aggiornamento (o toglierlo)
$plugin->api('cuore', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    $vid = current_uid();
    $r = lc_cuore_cambia($plugin, $vid, (string)post('e'));
    if (!$r[0]) {
        return array('ok' => false, 'error' => $r[1]);
    }
    return array('messo' => $r[1], 'n' => count($r[2]['cuori']), 'chi' => lc_chi_cuori($r[2]['cuori'], $vid));
}, array('metodo' => 'POST'));

// nuovo commento: restituisce il commento gia' pronto da mettere nella pagina
$plugin->api('commenta', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    require_once APP_ROOT . '/inc/reading.php';
    $vid = current_uid();
    $k = (string)post('e');
    $r = lc_commenta($plugin, $vid, $k, (string)post('testo'));
    if (!$r[0]) {
        return array('ok' => false, 'error' => $r[1]);
    }
    $c = lc_commento($plugin, $r[1]);
    $back = (string)post('back');
    $back = preg_match('#^plg\.php\?[A-Za-z0-9_=&%+.\-]*$#', $back) ? $back : $plugin->site_url('tutti');
    return array('html' => lc_commento_html($plugin, $c, $r[2], $vid, $back), 'n' => count($r[2]['commenti']) + 1);
}, array('metodo' => 'POST'));

$plugin->api('elimina', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    $r = lc_commento_elimina($plugin, current_uid(), (int)post('c'));
    return $r[0] ? array('eliminato' => true) : array('ok' => false, 'error' => $r[1]);
}, array('metodo' => 'POST'));

// nascondere o mostrare un libro (dalla scheda del libro)
$plugin->api('nascondi', function ($plugin) {
    if (!is_user()) {
        return array('ok' => false);
    }
    $bid = (int)post('book');
    $si = post('op') === 'nascondi_libro';
    lc_nascondi($plugin, current_uid(), $bid, $si);
    return array('nascosto' => $si);
}, array('metodo' => 'POST'));

/* ---------------- Lavoro quotidiano ---------------- */

$plugin->on('ogni_giorno', function () use ($plugin) {
    lc_manutenzione($plugin);
});
