<?php
/*
 * Posta: tabelle, conversazioni, cartelle, bozze, immagini. Prefisso delle funzioni: ps_
 *
 * Ogni conversazione ha i suoi partecipanti; ognuno ha la SUA cartella (arrivo, archivio, cestino, eliminata),
 * il punto fino a cui ha letto e il punto fino a cui ha eliminato: quello che fa uno non cambia niente per gli altri.
 * Un messaggio sparisce dal database solo quando l'hanno eliminato tutti i partecipanti.
 */
require_once APP_ROOT . '/inc/books.php';

define('PS_MAX_TESTO', 5000);
define('PS_MAX_OGGETTO', 150);
define('PS_PER_PAGINA', 40);
define('PS_MAX_ORA', 120);          // messaggi all'ora per utente (contro gli invii a raffica)
define('PS_MAX_IMG_MB', 10);

function ps_t($plugin, $n)
{
    return $plugin->table($n);
}

function ps_crea_tabelle($plugin)
{
    $pdo = db();
    $sqlite = DB_DRIVER === 'sqlite';
    $id = $sqlite ? 'id INTEGER PRIMARY KEY AUTOINCREMENT' : 'id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY';
    $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ps_t($plugin, 'conversazioni') . ' (' . $id . ', oggetto VARCHAR(200) NOT NULL, creata_da INT NOT NULL,'
        . ' gruppo TINYINT NOT NULL DEFAULT 0, ultimo_id INT NOT NULL DEFAULT 0, ultimo_at DATETIME NULL, created_at DATETIME NOT NULL)' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ps_t($plugin, 'partecipanti') . ' (' . $id . ', conv_id INT NOT NULL, user_id INT NOT NULL,'
        . " cartella VARCHAR(10) NOT NULL DEFAULT 'arrivo', letto_fino INT NOT NULL DEFAULT 0, da_leggere TINYINT NOT NULL DEFAULT 0,"
        . ' nascosti_fino INT NOT NULL DEFAULT 0, cestinata_il DATETIME NULL, email_fino INT NOT NULL DEFAULT 0, UNIQUE (conv_id, user_id))' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ps_t($plugin, 'messaggi') . ' (' . $id . ', conv_id INT NOT NULL, user_id INT NOT NULL, testo TEXT NOT NULL,'
        . ' libro_id INT NULL, libro_titolo VARCHAR(255) NULL, immagine VARCHAR(80) NULL, created_at DATETIME NOT NULL)' . $tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ps_t($plugin, 'bozze') . ' (' . $id . ', user_id INT NOT NULL, conv_id INT NULL, destinatari VARCHAR(2000) NULL,'
        . ' modo VARCHAR(10) NULL, oggetto VARCHAR(200) NULL, testo TEXT NULL, libro_id INT NULL, immagine VARCHAR(80) NULL, updated_at DATETIME NOT NULL)' . $tail);
    // 1.2.0: "mi piace" sui messaggi
    $pdo->exec('CREATE TABLE IF NOT EXISTS ' . ps_t($plugin, 'mipiace') . ' (' . $id . ', msg_id INT NOT NULL, user_id INT NOT NULL, created_at DATETIME NOT NULL,'
        . ' UNIQUE (msg_id, user_id))' . $tail);
    foreach (array('partecipanti' => 'user_id, cartella', 'messaggi' => 'conv_id, id', 'bozze' => 'user_id, conv_id') as $t => $cols) {
        try {
            $pdo->exec('CREATE INDEX ' . ps_t($plugin, $t) . '_i1 ON ' . ps_t($plugin, $t) . ' (' . $cols . ')');
        } catch (Exception $e) {
            // indice gia' presente
        }
    }
}

/* ---------------- Utenti ---------------- */

function ps_utenti_tutti()
{
    static $c = null;
    if ($c === null) {
        $c = array();
        $em = function_exists('users_email_ready') && users_email_ready();
        foreach (db()->query('SELECT id, username, display_name, role, active' . ($em ? ', email, email_notify' : '') . ' FROM users')->fetchAll() as $u) {
            $c[(int)$u['id']] = $u;
        }
    }
    return $c;
}

function ps_utente($uid)
{
    $t = ps_utenti_tutti();
    $u = isset($t[(int)$uid]) ? $t[(int)$uid] : null;
    return $u && (int)$u['active'] === 1 && in_array($u['role'], user_roles(), true) ? $u : null;
}

function ps_nome($uid)
{
    $t = ps_utenti_tutti();
    if (!isset($t[(int)$uid])) {
        return 'utente eliminato';
    }
    $u = $t[(int)$uid];
    return (string)$u['display_name'] !== '' ? $u['display_name'] : $u['username'];
}

function ps_iniziale($uid)
{
    return mb_strtoupper(mb_substr(ps_nome($uid), 0, 1, 'UTF-8'), 'UTF-8');
}

// Colore fisso per persona (per le iniziali)
function ps_colore($uid)
{
    $c = array('#b5523b', '#3f7d6e', '#5b6bb5', '#a0527f', '#8a6d2f', '#3d7fa6', '#7a5bb0', '#b0693a');
    return $c[(int)$uid % count($c)];
}

// A chi puo' scrivere l'utente collegato
function ps_destinatari_possibili($uid)
{
    $out = array();
    foreach (ps_utenti_tutti() as $id => $u) {
        if ($id !== (int)$uid && ps_utente($id)) {
            $out[$id] = ps_nome($id);
        }
    }
    asort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}

/* ---------------- Conversazioni ---------------- */

function ps_conv($plugin, $cid)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'conversazioni') . ' WHERE id = ?');
    $st->execute(array((int)$cid));
    $r = $st->fetch();
    return $r ? $r : null;
}

// La riga del partecipante (null se l'utente non fa parte della conversazione)
function ps_part($plugin, $cid, $uid)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'partecipanti') . ' WHERE conv_id = ? AND user_id = ?');
    $st->execute(array((int)$cid, (int)$uid));
    $r = $st->fetch();
    return $r ? $r : null;
}

function ps_partecipanti($plugin, $cid)
{
    $st = db()->prepare('SELECT user_id FROM ' . ps_t($plugin, 'partecipanti') . ' WHERE conv_id = ? ORDER BY id');
    $st->execute(array((int)$cid));
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

function ps_cartelle()
{
    return array(
        'arrivo'   => array('In arrivo', 'inbox'),
        'inviati'  => array('Inviati', 'send'),
        'bozze'    => array('Bozze', 'draft'),
        'archivio' => array('Archiviati', 'archive'),
        'cestino'  => array('Cestino', 'trash'),
    );
}

// Condizione SQL di una cartella (alias: p = partecipante, c = conversazione)
function ps_sql_cartella($plugin, $cartella)
{
    $M = ps_t($plugin, 'messaggi');
    switch ($cartella) {
        case 'inviati':
            return "p.cartella IN ('arrivo', 'archivio') AND EXISTS (SELECT 1 FROM " . $M . ' m WHERE m.conv_id = c.id AND m.user_id = p.user_id AND m.id > p.nascosti_fino)';
        case 'archivio':
            return "p.cartella = 'archivio'";
        case 'cestino':
            return "p.cartella = 'cestino'";
        default:
            return "p.cartella = 'arrivo' AND EXISTS (SELECT 1 FROM " . $M . ' m WHERE m.conv_id = c.id AND m.user_id <> p.user_id AND m.id > p.nascosti_fino)';
    }
}

function ps_conta_cartella($plugin, $uid, $cartella)
{
    $st = db()->prepare('SELECT COUNT(*) FROM ' . ps_t($plugin, 'partecipanti') . ' p JOIN ' . ps_t($plugin, 'conversazioni') . ' c ON c.id = p.conv_id'
        . ' WHERE p.user_id = ? AND ' . ps_sql_cartella($plugin, $cartella));
    $st->execute(array((int)$uid));
    return (int)$st->fetchColumn();
}

// Condizione SQL "da leggere" (per il conteggio)
function ps_sql_nonlette($plugin)
{
    return '(p.da_leggere = 1 OR EXISTS (SELECT 1 FROM ' . ps_t($plugin, 'messaggi') . ' m2 WHERE m2.conv_id = c.id AND m2.user_id <> p.user_id'
        . ' AND m2.id > p.letto_fino AND m2.id > p.nascosti_fino))';
}

// Conversazioni da leggere in arrivo (il numero sulla busta)
function ps_non_lette($plugin, $uid)
{
    try {
        $st = db()->prepare('SELECT COUNT(*) FROM ' . ps_t($plugin, 'partecipanti') . ' p JOIN ' . ps_t($plugin, 'conversazioni') . ' c ON c.id = p.conv_id'
            . ' WHERE p.user_id = ? AND ' . ps_sql_cartella($plugin, 'arrivo') . ' AND ' . ps_sql_nonlette($plugin));
        $st->execute(array((int)$uid));
        return (int)$st->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

// Elenco di una cartella, con i dati per le righe
function ps_elenco($plugin, $uid, $cartella, $pagina = 1)
{
    $C = ps_t($plugin, 'conversazioni');
    $M = ps_t($plugin, 'messaggi');
    $da = max(0, ((int)$pagina - 1) * PS_PER_PAGINA);
    $ord = $cartella === 'cestino' ? 'p.cestinata_il DESC, c.ultimo_at DESC' : 'c.ultimo_at DESC';
    $st = db()->prepare('SELECT c.*, p.cartella, p.letto_fino, p.da_leggere, p.nascosti_fino, p.cestinata_il FROM ' . ps_t($plugin, 'partecipanti') . ' p JOIN ' . $C . ' c ON c.id = p.conv_id'
        . ' WHERE p.user_id = ? AND ' . ps_sql_cartella($plugin, $cartella) . ' ORDER BY ' . $ord . ', c.id DESC LIMIT ' . (PS_PER_PAGINA + 1) . ' OFFSET ' . $da);
    $st->execute(array((int)$uid));
    $righe = $st->fetchAll();
    $altre = count($righe) > PS_PER_PAGINA;
    $righe = array_slice($righe, 0, PS_PER_PAGINA);
    foreach ($righe as &$r) {
        $vis = (int)$r['nascosti_fino'];
        // ultimo messaggio visibile (negli Inviati: il mio ultimo)
        $q = 'SELECT id, user_id, testo, immagine, libro_id, libro_titolo, created_at FROM ' . $M . ' WHERE conv_id = ? AND id > ?' . ($cartella === 'inviati' ? ' AND user_id = ?' : '') . ' ORDER BY id DESC LIMIT 1';
        $s2 = db()->prepare($q);
        $s2->execute($cartella === 'inviati' ? array((int)$r['id'], $vis, (int)$uid) : array((int)$r['id'], $vis));
        $r['ultimo'] = $s2->fetch();
        $s3 = db()->prepare('SELECT COUNT(*) FROM ' . $M . ' WHERE conv_id = ? AND user_id <> ? AND id > ? AND id > ?');
        $s3->execute(array((int)$r['id'], (int)$uid, (int)$r['letto_fino'], $vis));
        $r['nuovi'] = (int)$s3->fetchColumn();
        $r['da_leggere_ora'] = $r['nuovi'] > 0 || (int)$r['da_leggere'] === 1;
        $s4 = db()->prepare('SELECT COUNT(*) FROM ' . $M . ' WHERE conv_id = ? AND id > ?');
        $s4->execute(array((int)$r['id'], $vis));
        $r['totale'] = (int)$s4->fetchColumn();
        $r['altri'] = array_values(array_diff(ps_partecipanti($plugin, $r['id']), array((int)$uid)));
    }
    unset($r);
    return array($righe, $altre);
}

// Le persone da mostrare in una riga: "Da" (chi ha scritto l'ultimo messaggio) o "A" (negli Inviati)
function ps_chi($r, $uid, $cartella)
{
    $altri = $r['altri'];
    if (!$altri) {
        return 'solo tu';
    }
    if ($cartella === 'inviati' || !$r['ultimo'] || (int)$r['ultimo']['user_id'] === (int)$uid) {
        $primo = $altri[0];
        $nome = ($cartella === 'inviati' ? '' : 'Tu → ') . ps_nome($primo);
    } else {
        $primo = (int)$r['ultimo']['user_id'];
        $nome = ps_nome($primo);
    }
    $n = count($altri) - (in_array($primo, $altri, true) ? 1 : 0);
    return $nome . ($n > 0 ? ' +' . $n : '');
}

function ps_anteprima($m)
{
    if (!$m) {
        return '';
    }
    $t = trim(preg_replace('/\s+/u', ' ', (string)$m['testo']));
    if ($t === '') {
        $t = $m['immagine'] ? '📷 Immagine' : ($m['libro_id'] ? '📖 ' . (string)$m['libro_titolo'] : '');
    }
    return str_cut($t, 110);
}

function ps_messaggi($plugin, $cid, $dal, $limite = 300)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'messaggi') . ' WHERE conv_id = ? AND id > ? ORDER BY id DESC LIMIT ' . (int)$limite);
    $st->execute(array((int)$cid, (int)$dal));
    return array_reverse($st->fetchAll());
}

function ps_messaggio($plugin, $mid)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'messaggi') . ' WHERE id = ?');
    $st->execute(array((int)$mid));
    $r = $st->fetch();
    return $r ? $r : null;
}

/* ---------------- Scrivere ---------------- */

// Nuova conversazione: restituisce l'id
function ps_nuova_conv($plugin, $da, $a, $oggetto, $gruppo)
{
    $now = now();
    db()->prepare('INSERT INTO ' . ps_t($plugin, 'conversazioni') . ' (oggetto, creata_da, gruppo, ultimo_id, ultimo_at, created_at) VALUES (?,?,?,0,?,?)')
        ->execute(array(str_cut($oggetto, 200), (int)$da, $gruppo ? 1 : 0, $now, $now));
    $cid = (int)db()->lastInsertId();
    $ins = db()->prepare('INSERT INTO ' . ps_t($plugin, 'partecipanti') . " (conv_id, user_id, cartella) VALUES (?,?,'arrivo')");
    foreach (array_unique(array_merge(array((int)$da), array_map('intval', $a))) as $u) {
        $ins->execute(array($cid, $u));
    }
    return $cid;
}

// Quanti messaggi ha mandato l'utente nell'ultima ora
function ps_inviati_ora($plugin, $uid)
{
    $st = db()->prepare('SELECT COUNT(*) FROM ' . ps_t($plugin, 'messaggi') . ' WHERE user_id = ? AND created_at >= ?');
    $st->execute(array((int)$uid, date('Y-m-d H:i:s', time() - 3600)));
    return (int)$st->fetchColumn();
}

/*
 * Aggiunge un messaggio a una conversazione, la riporta "In arrivo" per gli altri e li avvisa (campanella ed email).
 * $avvisa: false per i messaggi "a tutti" separati (l'avviso lo manda chi chiama, uno per persona e basta).
 */
function ps_aggiungi($plugin, $cid, $da, $testo, $libro_id, $libro_titolo, $immagine)
{
    $now = now();
    db()->prepare('INSERT INTO ' . ps_t($plugin, 'messaggi') . ' (conv_id, user_id, testo, libro_id, libro_titolo, immagine, created_at) VALUES (?,?,?,?,?,?,?)')
        ->execute(array((int)$cid, (int)$da, $testo, $libro_id ? (int)$libro_id : null, $libro_titolo !== '' ? str_cut($libro_titolo, 255) : null, $immagine !== '' ? $immagine : null, $now));
    $mid = (int)db()->lastInsertId();
    db()->prepare('UPDATE ' . ps_t($plugin, 'conversazioni') . ' SET ultimo_id = ?, ultimo_at = ? WHERE id = ?')->execute(array($mid, $now, (int)$cid));
    $P = ps_t($plugin, 'partecipanti');
    // chi scrive ha letto tutto; se la conversazione era nel suo cestino torna in arrivo
    db()->prepare('UPDATE ' . $P . " SET letto_fino = ?, da_leggere = 0, cartella = CASE WHEN cartella IN ('cestino', 'eliminata') THEN 'arrivo' ELSE cartella END,"
        . ' cestinata_il = NULL WHERE conv_id = ? AND user_id = ?')->execute(array($mid, (int)$cid, (int)$da));
    // per gli altri torna in arrivo (anche se l'avevano archiviata o cestinata)
    db()->prepare('UPDATE ' . $P . " SET cartella = 'arrivo', cestinata_il = NULL WHERE conv_id = ? AND user_id <> ?")->execute(array((int)$cid, (int)$da));
    return $mid;
}

// Avvisi per un messaggio appena scritto
function ps_avvisa($plugin, $cid, $mid, $da, $oggetto, $testo)
{
    $altri = array_values(array_diff(ps_partecipanti($plugin, $cid), array((int)$da)));
    $altri = array_values(array_filter($altri, 'ps_utente'));
    if (!$altri) {
        return;
    }
    $nome = ps_nome($da);
    $ogg = str_cut($oggetto, 60);
    $plugin->notifica($nome . ' ti ha scritto: «' . $ogg . '»', $plugin->site_url('leggi', array('c' => (int)$cid)), array(
        'to' => $altri, 'actor' => (int)$da, 'gruppo' => 'c' . (int)$cid, 'testo_gruppo' => 'Nuovi messaggi ({n}) in «' . $ogg . '», l\'ultimo da ' . $nome));
    if ($plugin->setting('email', '1') === '1') {
        ps_email($plugin, $cid, $mid, $da, $altri, $oggetto, $testo);
    }
}

// Segna come lette le notifiche della campanella di una conversazione
function ps_notifiche_lette($plugin, $cid, $uid)
{
    try {
        db()->prepare('UPDATE notifications SET read_at = ? WHERE user_id = ? AND group_key = ? AND read_at IS NULL')
            ->execute(array(now(), (int)$uid, 'plg:' . $plugin->id . ':c' . (int)$cid));
    } catch (Exception $e) {
        // campanella non ancora pronta
    }
}

/* ---------------- Email (con il plugin "Notifiche email") ---------------- */

function ps_email_plugin()
{
    if (empty($GLOBALS['PLG_OBJ']['notifiche-email']) || !empty($GLOBALS['PLG_FAILED']['notifiche-email'])
        || !function_exists('ne_spedisci') || !function_exists('ne_server_pronto') || !function_exists('ne_email_ok')) {
        return null;
    }
    $ne = $GLOBALS['PLG_OBJ']['notifiche-email'];
    return ne_server_pronto($ne) ? $ne : null;
}

/*
 * Una email per ogni destinatario, ma solo la prima di una serie: finche' non legge la conversazione
 * non ne riceve altre (cosi' una chiacchierata non riempie la casella).
 */
function ps_email($plugin, $cid, $mid, $da, $altri, $oggetto, $testo)
{
    $ne = ps_email_plugin();
    if (!$ne) {
        return;
    }
    $P = ps_t($plugin, 'partecipanti');
    $lista = array();
    foreach ($altri as $u) {
        $ut = ps_utente($u);
        if (!$ut || !isset($ut['email']) || !ne_email_ok((string)$ut['email']) || (isset($ut['email_notify']) && !(int)$ut['email_notify'])) {
            continue;
        }
        $p = ps_part($plugin, $cid, $u);
        if (!$p || (int)$p['email_fino'] > (int)$p['letto_fino']) {
            continue; // ha gia' un'email per messaggi che non ha ancora letto
        }
        db()->prepare('UPDATE ' . $P . ' SET email_fino = ? WHERE id = ?')->execute(array((int)$mid, (int)$p['id']));
        $lista[] = array((string)$ut['email'], ps_nome($u));
    }
    if (!$lista) {
        return;
    }
    $sito = setting('brand_title');
    $url = rtrim((string)$ne->setting('sito_url', ''), '/');
    $link = $url !== '' ? $url . '/' . $plugin->site_url('leggi', array('c' => (int)$cid)) : '';
    $nome = ps_nome($da);
    $anteprima = $plugin->setting('email_testo', '0') === '1' ? str_cut(trim((string)$testo), 400) : '';
    $invia = function () use ($ne, $lista, $sito, $link, $nome, $oggetto, $anteprima) {
        foreach ($lista as $x) {
            $ogg = $nome . ' ti ha scritto: ' . str_cut($oggetto, 80);
            $txt = 'Ciao ' . $x[1] . ",\n\n" . $nome . ' ti ha mandato un messaggio nella ' . $sito . ":\n«" . $oggetto . "»\n"
                . ($anteprima !== '' ? "\n" . $anteprima . "\n" : '') . ($link !== '' ? "\nLeggilo qui: " . $link . "\n" : '')
                . "\nNon riceverai altre email per questa conversazione finché non la leggi.\n— " . $sito . "\n";
            $html = '<!doctype html><html><body style="margin:0;background:#f2f0ec;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">'
                . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f2f0ec;padding:24px 12px"><tr><td align="center">'
                . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:12px;padding:24px 26px">'
                . '<tr><td style="font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#6f6a63">' . h($sito) . ' · Posta</td></tr>'
                . '<tr><td style="font-size:20px;font-weight:600;color:#23201c;padding:6px 0 4px">' . h($nome) . ' ti ha scritto</td></tr>'
                . '<tr><td style="font-size:15px;color:#3a3631;padding-bottom:10px">«' . h($oggetto) . '»</td></tr>'
                . ($anteprima !== '' ? '<tr><td style="font-size:14px;color:#3a3631;line-height:1.5;background:#f7f4ee;border-radius:10px;padding:12px 14px">' . nl2br(h($anteprima)) . '</td></tr>' : '')
                . ($link !== '' ? '<tr><td style="padding-top:18px"><a href="' . h($link) . '" style="display:inline-block;background:#2f6fe0;color:#ffffff;text-decoration:none;padding:10px 16px;border-radius:8px;font-size:14px">Leggi il messaggio</a></td></tr>' : '')
                . '</table><p style="font-size:12px;color:#8a847c;max-width:560px;margin:14px auto 0">Non riceverai altre email per questa conversazione finché non la leggi. '
                . 'Le email del sito si spengono in Il mio account.</p></td></tr></table></body></html>';
            ne_spedisci($ne, 'posta', array($x[0]), 'Posta: ' . $ogg, '[' . $sito . '] ' . $ogg, $txt, $html);
        }
    };
    if (function_exists('ne_dopo')) {
        ne_dopo($invia);  // dopo aver risposto al browser: l'invio non rallenta la pagina
    } else {
        $invia();
    }
}

/* ---------------- Cartelle ---------------- */

// Sposta le conversazioni scelte (solo le proprie)
function ps_sposta($plugin, $uid, $ids, $op)
{
    $P = ps_t($plugin, 'partecipanti');
    $n = 0;
    foreach (array_unique(array_map('intval', (array)$ids)) as $cid) {
        $p = ps_part($plugin, $cid, $uid);
        if (!$p || $p['cartella'] === 'eliminata') {
            continue;
        }
        switch ($op) {
            case 'archivia':
                db()->prepare('UPDATE ' . $P . " SET cartella = 'archivio', cestinata_il = NULL WHERE id = ?")->execute(array((int)$p['id']));
                break;
            case 'arrivo':
            case 'ripristina':
                db()->prepare('UPDATE ' . $P . " SET cartella = 'arrivo', cestinata_il = NULL WHERE id = ?")->execute(array((int)$p['id']));
                break;
            case 'cestino':
                db()->prepare('UPDATE ' . $P . " SET cartella = 'cestino', cestinata_il = ? WHERE id = ?")->execute(array(now(), (int)$p['id']));
                break;
            case 'letto':
                $c = ps_conv($plugin, $cid);
                db()->prepare('UPDATE ' . $P . ' SET da_leggere = 0, letto_fino = ? WHERE id = ?')->execute(array($c ? (int)$c['ultimo_id'] : 0, (int)$p['id']));
                ps_notifiche_lette($plugin, $cid, $uid);
                break;
            case 'da_leggere':
                db()->prepare('UPDATE ' . $P . ' SET da_leggere = 1 WHERE id = ?')->execute(array((int)$p['id']));
                break;
            case 'elimina':
                ps_elimina_per_me($plugin, $p);
                break;
            default:
                continue 2;
        }
        $n++;
    }
    return $n;
}

// Eliminazione definitiva per un partecipante: i messaggi fin qui non li vedra' piu'
function ps_elimina_per_me($plugin, $p)
{
    $c = ps_conv($plugin, $p['conv_id']);
    $fino = $c ? (int)$c['ultimo_id'] : 0;
    db()->prepare('UPDATE ' . ps_t($plugin, 'partecipanti') . " SET cartella = 'eliminata', nascosti_fino = ?, letto_fino = ?, da_leggere = 0, cestinata_il = NULL WHERE id = ?")
        ->execute(array($fino, $fino, (int)$p['id']));
    ps_pulisci_conv($plugin, $p['conv_id']);
}

// Cancella dal database i messaggi che nessuno puo' piu' vedere (e la conversazione, se e' vuota per tutti)
function ps_pulisci_conv($plugin, $cid)
{
    ps_mipiace_pronto($plugin);
    $P = ps_t($plugin, 'partecipanti');
    $M = ps_t($plugin, 'messaggi');
    $st = db()->prepare('SELECT user_id, nascosti_fino FROM ' . $P . ' WHERE conv_id = ?');
    $st->execute(array((int)$cid));
    $min = null;
    foreach ($st->fetchAll() as $r) {
        if (!array_key_exists((int)$r['user_id'], ps_utenti_tutti())) {
            continue; // utente eliminato dal sito: non conta
        }
        $min = $min === null ? (int)$r['nascosti_fino'] : min($min, (int)$r['nascosti_fino']);
    }
    $c = ps_conv($plugin, $cid);
    if ($min === null || ($c && $min >= (int)$c['ultimo_id'])) {
        ps_cancella_immagini($plugin, 'SELECT immagine FROM ' . $M . ' WHERE conv_id = ? AND immagine IS NOT NULL', array((int)$cid));
        db()->prepare('DELETE FROM ' . ps_t($plugin, 'mipiace') . ' WHERE msg_id IN (SELECT id FROM ' . $M . ' WHERE conv_id = ?)')->execute(array((int)$cid));
        db()->prepare('DELETE FROM ' . $M . ' WHERE conv_id = ?')->execute(array((int)$cid));
        db()->prepare('DELETE FROM ' . $P . ' WHERE conv_id = ?')->execute(array((int)$cid));
        db()->prepare('DELETE FROM ' . ps_t($plugin, 'conversazioni') . ' WHERE id = ?')->execute(array((int)$cid));
        db()->prepare('UPDATE ' . ps_t($plugin, 'bozze') . ' SET conv_id = NULL WHERE conv_id = ?')->execute(array((int)$cid));
        return;
    }
    if ($min > 0) {
        ps_cancella_immagini($plugin, 'SELECT immagine FROM ' . $M . ' WHERE conv_id = ? AND id <= ? AND immagine IS NOT NULL', array((int)$cid, $min));
        db()->prepare('DELETE FROM ' . ps_t($plugin, 'mipiace') . ' WHERE msg_id IN (SELECT id FROM ' . $M . ' WHERE conv_id = ? AND id <= ?)')->execute(array((int)$cid, $min));
        db()->prepare('DELETE FROM ' . $M . ' WHERE conv_id = ? AND id <= ?')->execute(array((int)$cid, $min));
    }
}

function ps_cancella_immagini($plugin, $sql, $args)
{
    $st = db()->prepare($sql);
    $st->execute($args);
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $f) {
        ps_cancella_file($plugin, $f);
    }
}

// Svuotamento del cestino: a mano (tutto) o a tempo ($giorni)
function ps_svuota_cestino($plugin, $uid = 0, $giorni = 0)
{
    $P = ps_t($plugin, 'partecipanti');
    $w = array();
    $a = array();
    if ($uid) {
        $w[] = 'user_id = ?';
        $a[] = (int)$uid;
    }
    if ($giorni > 0) {
        $w[] = 'cestinata_il < ?';
        $a[] = date('Y-m-d H:i:s', time() - $giorni * 86400);
    }
    $st = db()->prepare('SELECT * FROM ' . $P . " WHERE cartella = 'cestino'" . ($w ? ' AND ' . implode(' AND ', $w) : ''));
    $st->execute($a);
    $n = 0;
    foreach ($st->fetchAll() as $p) {
        ps_elimina_per_me($plugin, $p);
        $n++;
    }
    return $n;
}

// Lavoro quotidiano: cestino a tempo, bozze vecchie, utenti eliminati
function ps_manutenzione($plugin)
{
    $g = (int)$plugin->setting('cestino_giorni', '30');
    if ($g > 0) {
        $n = ps_svuota_cestino($plugin, 0, $g);
        if ($n) {
            $plugin->log('Cestino svuotato in automatico: ' . $n . ' conversazioni più vecchie di ' . $g . ' giorni.');
        }
    }
    // bozze abbandonate da piu' di 180 giorni
    $B = ps_t($plugin, 'bozze');
    $st = db()->prepare('SELECT id, immagine FROM ' . $B . ' WHERE updated_at < ?');
    $st->execute(array(date('Y-m-d H:i:s', time() - 180 * 86400)));
    foreach ($st->fetchAll() as $b) {
        ps_bozza_elimina($plugin, $b['id'], 0);
    }
    // partecipanti di utenti eliminati dal sito
    $ids = array_keys(ps_utenti_tutti());
    $P = ps_t($plugin, 'partecipanti');
    $orfani = db()->query('SELECT DISTINCT conv_id FROM ' . $P . ($ids ? ' WHERE user_id NOT IN (' . implode(',', array_map('intval', $ids)) . ')' : ''))->fetchAll(PDO::FETCH_COLUMN);
    foreach ($orfani as $cid) {
        ps_pulisci_conv($plugin, $cid);
    }
}

/* ---------------- Bozze ---------------- */

function ps_bozza($plugin, $bid, $uid)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'bozze') . ' WHERE id = ? AND user_id = ?');
    $st->execute(array((int)$bid, (int)$uid));
    $r = $st->fetch();
    return $r ? $r : null;
}

function ps_bozza_risposta($plugin, $cid, $uid)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'bozze') . ' WHERE conv_id = ? AND user_id = ? ORDER BY id DESC LIMIT 1');
    $st->execute(array((int)$cid, (int)$uid));
    $r = $st->fetch();
    return $r ? $r : null;
}

function ps_bozze($plugin, $uid)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'bozze') . ' WHERE user_id = ? ORDER BY updated_at DESC, id DESC LIMIT 200');
    $st->execute(array((int)$uid));
    return $st->fetchAll();
}

function ps_conta_bozze($plugin, $uid)
{
    $st = db()->prepare('SELECT COUNT(*) FROM ' . ps_t($plugin, 'bozze') . ' WHERE user_id = ?');
    $st->execute(array((int)$uid));
    return (int)$st->fetchColumn();
}

/*
 * Salva (crea o aggiorna) una bozza. $d: conv_id, destinatari (array), modo, oggetto, testo, libro_id, immagine (null = non cambiare).
 * Restituisce l'id. Una bozza vuota viene cancellata (restituisce 0).
 */
function ps_bozza_salva($plugin, $uid, $bid, $d)
{
    $B = ps_t($plugin, 'bozze');
    $old = $bid ? ps_bozza($plugin, $bid, $uid) : null;
    if (!$old && !empty($d['conv_id'])) {
        $old = ps_bozza_risposta($plugin, $d['conv_id'], $uid);
    }
    $img = array_key_exists('immagine', $d) && $d['immagine'] !== null ? $d['immagine'] : ($old ? (string)$old['immagine'] : '');
    if ($old && $old['immagine'] && $img !== (string)$old['immagine']) {
        ps_cancella_file($plugin, $old['immagine']);
    }
    $dest = implode(',', array_map('intval', isset($d['destinatari']) ? (array)$d['destinatari'] : array()));
    $vuota = trim((string)$d['testo']) === '' && trim((string)$d['oggetto']) === '' && $img === '' && empty($d['libro_id']) && ($dest === '' || !empty($d['conv_id']));
    if ($vuota) {
        if ($old) {
            ps_bozza_elimina($plugin, $old['id'], $uid);
        }
        return 0;
    }
    $args = array(!empty($d['conv_id']) ? (int)$d['conv_id'] : null, str_cut($dest, 2000), isset($d['modo']) ? str_cut((string)$d['modo'], 10) : null,
        str_cut((string)$d['oggetto'], 200), str_cut((string)$d['testo'], PS_MAX_TESTO), !empty($d['libro_id']) ? (int)$d['libro_id'] : null, $img !== '' ? $img : null, now());
    if ($old) {
        $args[] = (int)$old['id'];
        db()->prepare('UPDATE ' . $B . ' SET conv_id = ?, destinatari = ?, modo = ?, oggetto = ?, testo = ?, libro_id = ?, immagine = ?, updated_at = ? WHERE id = ?')->execute($args);
        return (int)$old['id'];
    }
    if (ps_conta_bozze($plugin, $uid) >= 200) {
        return 0;
    }
    $args[] = (int)$uid;
    db()->prepare('INSERT INTO ' . $B . ' (conv_id, destinatari, modo, oggetto, testo, libro_id, immagine, updated_at, user_id) VALUES (?,?,?,?,?,?,?,?,?)')->execute($args);
    return (int)db()->lastInsertId();
}

// $tieni_img: il file dell'immagine passa a un messaggio (non va cancellato)
function ps_bozza_elimina($plugin, $bid, $uid, $tieni_img = false)
{
    $st = db()->prepare('SELECT * FROM ' . ps_t($plugin, 'bozze') . ' WHERE id = ?' . ($uid ? ' AND user_id = ?' : ''));
    $st->execute($uid ? array((int)$bid, (int)$uid) : array((int)$bid));
    $b = $st->fetch();
    if (!$b) {
        return;
    }
    if ($b['immagine'] && !$tieni_img) {
        ps_cancella_file($plugin, $b['immagine']);
    }
    db()->prepare('DELETE FROM ' . ps_t($plugin, 'bozze') . ' WHERE id = ?')->execute(array((int)$b['id']));
}

/* ---------------- Libri allegati ---------------- */

function ps_libro($id)
{
    if (!$id) {
        return null;
    }
    $st = db()->prepare('SELECT id, title, authors, cover_file, pub_year FROM books WHERE id = ?');
    $st->execute(array((int)$id));
    $r = $st->fetch();
    return $r ? $r : null;
}

function ps_cerca_libri($q)
{
    $q = trim((string)$q);
    if (mb_strlen($q, 'UTF-8') < 2) {
        return array();
    }
    // carattere di escape "!": la barra rovesciata in SQL e' interpretata in modo diverso da MySQL/MariaDB e SQLite (1.2.1)
    $like = '%' . str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $q) . '%';
    $st = db()->prepare("SELECT id, title, authors, cover_file FROM books WHERE title LIKE ? ESCAPE '!' OR authors LIKE ? ESCAPE '!' OR isbn13 = ? ORDER BY title LIMIT 8");
    $st->execute(array($like, $like, preg_replace('/[^0-9X]/i', '', $q)));
    $out = array();
    foreach ($st->fetchAll() as $b) {
        $out[] = array('id' => (int)$b['id'], 'titolo' => $b['title'], 'autori' => (string)$b['authors'], 'copertina' => $b['cover_file'] ? cover_url($b['cover_file']) : '');
    }
    return $out;
}

/* ---------------- Immagini ---------------- */

function ps_dir_img($plugin)
{
    $d = $plugin->data_dir() . '/immagini';
    if (!is_dir($d)) {
        @mkdir($d, 0775, true);
        @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return $d;
}

function ps_nome_file_ok($f)
{
    return (bool)preg_match('/^[a-f0-9]{32}\.(jpg|png)$/', (string)$f);
}

function ps_cancella_file($plugin, $f)
{
    if (ps_nome_file_ok($f)) {
        @unlink(ps_dir_img($plugin) . '/' . $f);
    }
}

/*
 * Salva un'immagine caricata: solo JPEG, PNG, WebP o GIF (mai SVG), ridisegnata da capo (niente dati nascosti, niente posizione GPS),
 * raddrizzata se la foto del telefono e' girata e rimpicciolita a 1600 px. Restituisce array(nome_file, errore).
 */
function ps_salva_immagine($plugin, $file)
{
    if (!is_array($file) || !isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return array('', '');
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return array('', in_array($file['error'], array(UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE), true) ? 'L\'immagine è troppo grande.' : 'Caricamento dell\'immagine non riuscito.');
    }
    if (!function_exists('imagecreatefromstring')) {
        return array('', 'Il server non può gestire le immagini (manca l\'estensione GD di PHP).');
    }
    if ($file['size'] > PS_MAX_IMG_MB * 1048576) {
        return array('', 'L\'immagine è troppo grande (massimo ' . PS_MAX_IMG_MB . ' MB).');
    }
    $info = @getimagesize($file['tmp_name']);
    if (!$info || !in_array($info[2], array(IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, defined('IMAGETYPE_WEBP') ? IMAGETYPE_WEBP : -1), true)) {
        return array('', 'Puoi allegare solo foto e immagini JPEG, PNG, WebP o GIF.');
    }
    if ($info[0] * $info[1] > 40000000) {
        return array('', 'L\'immagine ha troppi pixel.');
    }
    $src = @imagecreatefromstring((string)file_get_contents($file['tmp_name']));
    if (!$src) {
        return array('', 'Immagine non leggibile.');
    }
    // foto del telefono: raddrizzala
    if ($info[2] === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
        $ex = @exif_read_data($file['tmp_name']);
        $o = is_array($ex) && isset($ex['Orientation']) ? (int)$ex['Orientation'] : 1;
        $rot = array(3 => 180, 6 => -90, 8 => 90);
        if (isset($rot[$o])) {
            $r = imagerotate($src, $rot[$o], 0);
            if ($r) {
                imagedestroy($src);
                $src = $r;
            }
        }
    }
    $w = imagesx($src);
    $hh = imagesy($src);
    $max = 1600;
    $k = min(1, $max / max($w, $hh));
    $nw = max(1, (int)round($w * $k));
    $nh = max(1, (int)round($hh * $k));
    $trasp = in_array($info[2], array(IMAGETYPE_PNG, IMAGETYPE_GIF, defined('IMAGETYPE_WEBP') ? IMAGETYPE_WEBP : -1), true);
    $dst = imagecreatetruecolor($nw, $nh);
    if ($trasp) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
    } else {
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $hh);
    imagedestroy($src);
    $nome = bin2hex(random_bytes(16)) . ($trasp ? '.png' : '.jpg');
    $path = ps_dir_img($plugin) . '/' . $nome;
    $ok = $trasp ? imagepng($dst, $path, 7) : imagejpeg($dst, $path, 84);
    imagedestroy($dst);
    if (!$ok) {
        return array('', 'Non riesco a salvare l\'immagine (cartella dei dati non scrivibile?).');
    }
    return array($nome, '');
}

/* ---------------- Testo ---------------- */

// Testo di un messaggio: a capo e indirizzi web cliccabili
function ps_testo_html($t)
{
    $h = h((string)$t);
    $h = preg_replace_callback('#\bhttps?://[^\s<>"\']+#i', function ($m) {
        $u = rtrim($m[0], '.,;:!?)');
        $resto = substr($m[0], strlen($u));
        return '<a href="' . $u . '" target="_blank" rel="noopener noreferrer nofollow">' . $u . '</a>' . $resto;
    }, $h);
    return nl2br($h);
}

function ps_quando($dt, $breve = true)
{
    $t = strtotime((string)$dt);
    if (!$t) {
        return '';
    }
    if (date('Y-m-d', $t) === date('Y-m-d')) {
        return date('H:i', $t);
    }
    if (date('Y-m-d', $t) === date('Y-m-d', time() - 86400)) {
        return 'ieri' . ($breve ? '' : ' ' . date('H:i', $t));
    }
    $mesi = array(1 => 'gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic');
    return (int)date('j', $t) . ' ' . $mesi[(int)date('n', $t)] . (date('Y', $t) !== date('Y') ? ' ' . date('Y', $t) : '') . ($breve ? '' : ' ' . date('H:i', $t));
}

function ps_giorno($dt)
{
    $t = strtotime((string)$dt);
    if (date('Y-m-d', $t) === date('Y-m-d')) {
        return 'Oggi';
    }
    if (date('Y-m-d', $t) === date('Y-m-d', time() - 86400)) {
        return 'Ieri';
    }
    $g = array('domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato');
    $mesi = array(1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre');
    return ucfirst($g[(int)date('w', $t)]) . ' ' . (int)date('j', $t) . ' ' . $mesi[(int)date('n', $t)] . (date('Y', $t) !== date('Y') ? ' ' . date('Y', $t) : '');
}

/* ---------------- "Mi piace" (1.2.0) ---------------- */

// La tabella dei "mi piace" c'e'? (se l'aggiornamento non l'avesse ancora creata, la crea adesso)
function ps_mipiace_pronto($plugin)
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT 1 FROM ' . ps_t($plugin, 'mipiace') . ' LIMIT 1');
            $ok = true;
        } catch (Exception $e) {
            ps_crea_tabelle($plugin);
            $ok = true;
        }
    }
    return $ok;
}

// msg_id => array di user_id che hanno messo mi piace
function ps_mipiace_di($plugin, $ids)
{
    ps_mipiace_pronto($plugin);
    $ids = array_values(array_filter(array_map('intval', (array)$ids)));
    if (!$ids) {
        return array();
    }
    $out = array();
    $st = db()->query('SELECT msg_id, user_id FROM ' . ps_t($plugin, 'mipiace') . ' WHERE msg_id IN (' . implode(',', $ids) . ') ORDER BY id');
    foreach ($st->fetchAll() as $r) {
        $out[(int)$r['msg_id']][] = (int)$r['user_id'];
    }
    return $out;
}

/*
 * Mette o toglie il "mi piace" di $uid al messaggio $mid. Solo ai messaggi degli altri, nelle conversazioni di cui fa parte.
 * Esito: array(ok, messo, quanti, nomi) oppure array(false, errore)
 */
function ps_mipiace_cambia($plugin, $uid, $mid)
{
    ps_mipiace_pronto($plugin);
    $m = ps_messaggio($plugin, $mid);
    $p = $m ? ps_part($plugin, $m['conv_id'], $uid) : null;
    if (!$m || !$p || $p['cartella'] === 'eliminata' || (int)$m['id'] <= (int)$p['nascosti_fino']) {
        return array(false, 'Messaggio non trovato.');
    }
    if ((int)$m['user_id'] === (int)$uid) {
        return array(false, 'Non puoi mettere mi piace ai tuoi messaggi.');
    }
    $L = ps_t($plugin, 'mipiace');
    $st = db()->prepare('SELECT id FROM ' . $L . ' WHERE msg_id = ? AND user_id = ?');
    $st->execute(array((int)$mid, (int)$uid));
    $c = ps_conv($plugin, $m['conv_id']);
    if ($st->fetchColumn()) {
        db()->prepare('DELETE FROM ' . $L . ' WHERE msg_id = ? AND user_id = ?')->execute(array((int)$mid, (int)$uid));
        $messo = false;
    } else {
        db()->prepare('INSERT INTO ' . $L . ' (msg_id, user_id, created_at) VALUES (?,?,?)')->execute(array((int)$mid, (int)$uid, now()));
        $messo = true;
        if (ps_utente($m['user_id']) && $c) {
            $nome = ps_nome($uid);
            $ant = str_cut(trim(preg_replace('/\s+/u', ' ', (string)$m['testo'])), 50);
            $ogg = str_cut($c['oggetto'], 50);
            $plugin->notifica('♥ A ' . $nome . ' piace il tuo messaggio' . ($ant !== '' ? ' «' . $ant . '»' : '') . ' in «' . $ogg . '»',
                $plugin->site_url('leggi', array('c' => (int)$c['id'])), array('to' => array((int)$m['user_id']), 'actor' => (int)$uid,
                'gruppo' => 'l' . (int)$c['id'], 'testo_gruppo' => '♥ {n} mi piace ai tuoi messaggi in «' . $ogg . '», l\'ultimo da ' . $nome));
        }
    }
    $chi = ps_mipiace_di($plugin, array($mid));
    $chi = isset($chi[(int)$mid]) ? $chi[(int)$mid] : array();
    return array(true, $messo, count($chi), array_map('ps_nome', $chi));
}
