<?php
/*
 * Posta — aggiornamenti in diretta (1.3.0): i messaggi nuovi compaiono nella conversazione aperta senza ricaricare,
 * i cuori si aggiornano, l'elenco delle cartelle si rinfresca da solo. La pagina chiede ogni pochi secondi
 * (subito quando arriva un avviso) solo quello che è cambiato.
 */

function ps_live_nuovi($plugin, $uid)
{
    $cid = (int)get('c');
    $c = ps_conv($plugin, $cid);
    $p = $c ? ps_part($plugin, $cid, $uid) : null;
    if (!$c || !$p || $p['cartella'] === 'eliminata') {
        return array('ok' => false, 'via' => true);
    }
    $dopo = max((int)get('dopo'), (int)$p['nascosti_fino']);
    $f = array_key_exists((string)get('cart'), ps_cartelle()) ? (string)get('cart') : 'arrivo'; // "f" e' gia' il nome della funzione
    $classica = get('stile') === 'classica';
    $M = ps_t($plugin, 'messaggi');
    $st = db()->prepare('SELECT * FROM ' . $M . ' WHERE conv_id = ? AND id > ? ORDER BY id ASC LIMIT 100');
    $st->execute(array($cid, $dopo));
    $msgs = $st->fetchAll();
    $st->closeCursor();
    $altri = array_values(array_diff(ps_partecipanti($plugin, $cid), array($uid)));
    $back = $plugin->site_url('leggi', array('c' => $cid, 'f' => $f));
    $stato = array('giorno' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)get('giorno')) ? (string)get('giorno') : '', 'prec' => (int)get('prec'));
    $html = '';
    if ($msgs) {
        $lk = ps_mipiace_di($plugin, array_map(function ($m) { return $m['id']; }, $msgs));
        $n = count($msgs);
        foreach ($msgs as $i => $m) {
            $html .= $classica
                ? ps_mail_html($plugin, $m, $uid, $altri, $lk, $back, (int)$m['user_id'] !== (int)$uid, true, false, $i === $n - 1)
                : ps_msg_chat_html($plugin, $m, $uid, $altri, $lk, $back, $stato, 0);
        }
        $dopo = (int)$msgs[$n - 1]['id'];
    }
    // pagina in vista: la conversazione e' letta (come aprirla)
    if (get('vis') === '1' && ((int)$p['letto_fino'] < (int)$c['ultimo_id'] || (int)$p['da_leggere'])) {
        db()->prepare('UPDATE ' . ps_t($plugin, 'partecipanti') . ' SET letto_fino = ?, da_leggere = 0 WHERE id = ?')->execute(array((int)$c['ultimo_id'], (int)$p['id']));
        ps_notifiche_lette($plugin, $cid, $uid);
    }
    // cuori degli ultimi messaggi: si mandano solo se qualcosa e' cambiato
    $st = db()->prepare('SELECT id, user_id FROM ' . $M . ' WHERE conv_id = ? AND id > ? ORDER BY id DESC LIMIT 60');
    $st->execute(array($cid, (int)$p['nascosti_fino']));
    $recenti = $st->fetchAll();
    $st->closeCursor();
    $lk = ps_mipiace_di($plugin, array_map(function ($m) { return $m['id']; }, $recenti));
    ksort($lk);
    $cf = substr(md5(json_encode($lk)), 0, 12);
    $cuori = null;
    if ($cf !== (string)get('cf')) {
        $cuori = array();
        foreach ($recenti as $m) {
            $cuori[(int)$m['id']] = ps_cuore_html($plugin, $m, $uid, isset($lk[(int)$m['id']]) ? $lk[(int)$m['id']] : array(), $back, $classica);
        }
    }
    return array('html' => $html, 'quanti' => count($msgs), 'dopo' => $dopo, 'giorno' => $stato['giorno'], 'prec' => (int)$stato['prec'], 'cf' => $cf, 'cuori' => $cuori,
        'n' => ps_non_lette($plugin, $uid));
}

// Cambia quando arriva un messaggio, si legge una conversazione o se ne sposta una
function ps_live_firma($plugin, $uid)
{
    $st = db()->prepare('SELECT COALESCE(MAX(c.ultimo_id), 0), COALESCE(SUM(p.da_leggere), 0), COALESCE(SUM(p.letto_fino), 0), COUNT(*),'
        . " COALESCE(SUM(CASE WHEN p.cartella = 'arrivo' THEN 1 WHEN p.cartella = 'archivio' THEN 2 WHEN p.cartella = 'cestino' THEN 4 ELSE 0 END), 0)"
        . ' FROM ' . ps_t($plugin, 'partecipanti') . ' p JOIN ' . ps_t($plugin, 'conversazioni') . ' c ON c.id = p.conv_id WHERE p.user_id = ?');
    $st->execute(array((int)$uid));
    $r = $st->fetch(PDO::FETCH_NUM);
    $st->closeCursor();
    return substr(md5(implode('|', $r) . '|' . ps_conta_bozze($plugin, $uid)), 0, 12);
}
