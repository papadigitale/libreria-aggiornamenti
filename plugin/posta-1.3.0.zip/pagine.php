<?php
/*
 * Pagine della Posta:
 *   posta  : le cartelle (In arrivo, Inviati, Bozze, Archiviati, Cestino)   plg.php?p=posta&s=posta&f=arrivo
 *   leggi  : una conversazione, in stile chat, con la risposta in fondo       plg.php?p=posta&s=leggi&c=ID
 *   scrivi : nuovo messaggio (anche da una bozza o con un libro consigliato)  plg.php?p=posta&s=scrivi
 *   img    : le immagini allegate (solo a chi partecipa alla conversazione)
 * Prefisso: ps_
 */

function ps_icona($n, $size = 18)
{
    $p = array(
        'mail'    => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5l8.5 6.5 8.5-6.5"/>',
        'inbox'   => '<path d="M3 13l2.5-8h13L21 13v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M3 13h5l1.5 2.5h5L16 13h5"/>',
        'send'    => '<path d="M21 3L10 14"/><path d="M21 3l-7 18-4-7-7-4z"/>',
        'draft'   => '<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
        'archive' => '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9M10 13h4"/>',
        'trash'   => '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
        'pen'     => '<path d="M15 4l5 5L9 20H4v-5z"/><path d="M13 6l5 5"/>',
        'unread'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5l8.5 6.5 8.5-6.5"/><circle cx="19" cy="5" r="3" fill="currentColor" stroke="none"/>',
        'read'    => '<path d="M3 10l9-6 9 6v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M3.5 10.5l8.5 6 8.5-6"/>',
        'restore' => '<path d="M4 12a8 8 0 1 0 2.5-5.8"/><path d="M4 4v5h5"/>',
        'clip'    => '<path d="M20 11.5l-8.2 8.2a5 5 0 0 1-7.1-7.1l8.5-8.5a3.3 3.3 0 0 1 4.7 4.7l-8.5 8.5a1.7 1.7 0 0 1-2.4-2.4l7.8-7.8"/>',
        'image'   => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
        'book'    => '<path d="M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h10"/>',
        'back'    => '<path d="M15 5l-7 7 7 7"/>',
        'x'       => '<path d="M6 6l12 12M18 6L6 18"/>',
        'reply'   => '<path d="M10 8L4 13l6 5"/><path d="M4 13h10a6 6 0 0 1 6 6v1"/>',
        'users'   => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.3-5.5 6.5-5.5s5.7 2 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.8c1.8.7 3 2.5 3.5 5.2"/>',
    );
    return '<svg class="ps-i" width="' . (int)$size . '" height="' . (int)$size . '" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'
        . (isset($p[$n]) ? $p[$n] : '') . '</svg>';
}

function ps_avatar($uid, $size = 34)
{
    return '<span class="ps-av" style="width:' . (int)$size . 'px;height:' . (int)$size . 'px;background:' . ps_colore($uid) . '" aria-hidden="true">' . h(ps_iniziale($uid)) . '</span>';
}

function ps_cartella_get()
{
    $f = (string)get('f');
    return array_key_exists($f, ps_cartelle()) ? $f : 'arrivo';
}

function ps_back_ok($b)
{
    return preg_match('#^plg\.php\?[A-Za-z0-9_=&%+.\-]*$#', (string)$b) ? (string)$b : '';
}

/* ---------------- Impaginazione con il menu delle cartelle ---------------- */

function ps_inizio($plugin, $attiva)
{
    $uid = current_uid();
    $nl = ps_non_lette($plugin, $uid);
    $nb = ps_conta_bozze($plugin, $uid);
    $nc = ps_conta_cartella($plugin, $uid, 'cestino');
    echo '<div class="ps" data-ps-firma="' . h(ps_live_firma($plugin, $uid)) . '"><aside class="ps-side"><a class="btn primary ps-scrivi" href="' . h($plugin->site_url('scrivi')) . '">' . ps_icona('pen', 18) . ' Scrivi</a><nav class="ps-cartelle" aria-label="Cartelle">';
    foreach (ps_cartelle() as $k => $c) {
        $n = $k === 'arrivo' ? $nl : ($k === 'bozze' ? $nb : ($k === 'cestino' ? $nc : 0));
        echo '<a href="' . h($plugin->site_url('posta', array('f' => $k))) . '"' . ($k === $attiva ? ' class="on" aria-current="page"' : '') . '>'
            . ps_icona($c[1], 19) . '<span>' . h($c[0]) . '</span>' . ($n ? '<em' . ($k === 'arrivo' ? ' class="hot"' : '') . '>' . ($n > 99 ? '99+' : $n) . '</em>' : '') . '</a>';
    }
    echo '</nav></aside><section class="ps-main">';
}

function ps_fine()
{
    echo '</section></div>';
}

/* ================= Cartelle ================= */

function ps_pagina_posta($plugin)
{
    $uid = current_uid();
    $f = ps_cartella_get();
    $pg = max(1, (int)get('pg'));
    $nomi = ps_cartelle();
    ps_inizio($plugin, $f);
    $back = $plugin->site_url('posta', array('f' => $f) + ($pg > 1 ? array('pg' => $pg) : array()));
    echo '<div class="ps-head"><h1 class="h1">' . h($nomi[$f][0]) . '</h1></div>';

    if ($f === 'bozze') {
        ps_elenco_bozze($plugin, $uid, $back);
        ps_fine();
        return;
    }

    list($righe, $altre) = ps_elenco($plugin, $uid, $f, $pg);
    if ($f === 'cestino') {
        $g = (int)$plugin->setting('cestino_giorni', '30');
        echo '<p class="sub ps-nota">' . ($g > 0 ? 'Le conversazioni restano nel cestino ' . $g . ' giorni, poi si eliminano da sole.' : 'Il cestino si svuota solo a mano.')
            . ' Eliminarle qui le toglie solo a te: gli altri partecipanti le conservano.</p>';
    }
    if (!$righe) {
        $vuoto = array('arrivo' => 'Nessun messaggio in arrivo.', 'inviati' => 'Non hai ancora mandato messaggi.', 'archivio' => 'Nessuna conversazione archiviata.', 'cestino' => 'Il cestino è vuoto.');
        echo '<div class="ps-vuoto">' . ps_icona($nomi[$f][1], 40) . '<p>' . h($vuoto[$f]) . '</p>'
            . ($f === 'arrivo' ? '<a class="btn ghost small" href="' . h($plugin->site_url('scrivi')) . '">' . ps_icona('pen', 16) . ' Scrivi un messaggio</a>' : '') . '</div>';
        ps_fine();
        return;
    }

    $azioni = array(
        'arrivo'   => array('archivia' => array('archive', 'Archivia'), 'cestino' => array('trash', 'Elimina'), 'da_leggere' => array('unread', 'Da leggere'), 'letto' => array('read', 'Letto')),
        'inviati'  => array('archivia' => array('archive', 'Archivia'), 'cestino' => array('trash', 'Elimina')),
        'archivio' => array('arrivo' => array('inbox', 'In arrivo'), 'cestino' => array('trash', 'Elimina'), 'da_leggere' => array('unread', 'Da leggere'), 'letto' => array('read', 'Letto')),
        'cestino'  => array('ripristina' => array('restore', 'Ripristina'), 'elimina' => array('x', 'Elimina per sempre')),
    );
    echo $plugin->form_start('class="ps-elenco" data-ps-elenco' . ($f === 'cestino' ? ' data-ps-conferma-elimina' : '')) . '<input type="hidden" name="back" value="' . h($back) . '">';
    echo '<div class="ps-barra"><label class="ps-sel ps-tutti" title="Seleziona tutti"><input type="checkbox" data-ps-tutti aria-label="Seleziona tutti"></label>'
        . '<span class="ps-quanti" data-ps-quanti></span><div class="ps-azioni">';
    foreach ($azioni[$f] as $op => $a) {
        echo '<button class="ps-btn' . ($op === 'elimina' ? ' rosso' : '') . '" type="submit" name="op" value="' . h($op) . '" disabled data-ps-azione title="' . h($a[1]) . '">' . ps_icona($a[0], 17) . '<span>' . h($a[1]) . '</span></button>';
    }
    echo '</div>';
    if ($f === 'cestino') {
        echo '<button class="ps-btn rosso ps-svuota" type="submit" form="ps-svuota">' . ps_icona('trash', 17) . '<span>Svuota il cestino</span></button>';
    }
    echo '</div>';
    echo '<div class="ps-lista" role="list"><div class="ps-intest" aria-hidden="true"><span></span><span>' . ($f === 'inviati' ? 'A' : 'Da') . '</span><span>Oggetto</span><span>Data</span></div>';
    foreach ($righe as $r) {
        $nuovo = $f !== 'inviati' && $r['da_leggere_ora'];
        $chi = ps_chi($r, $uid, $f);
        $av = $f === 'inviati' || !$r['ultimo'] || (int)$r['ultimo']['user_id'] === $uid ? ($r['altri'] ? $r['altri'][0] : $uid) : (int)$r['ultimo']['user_id'];
        $quando = $r['ultimo'] ? $r['ultimo']['created_at'] : $r['ultimo_at'];
        echo '<div class="ps-riga' . ($nuovo ? ' nuovo' : '') . '" role="listitem"><label class="ps-sel"><input type="checkbox" name="c[]" value="' . (int)$r['id'] . '" aria-label="Seleziona «' . h($r['oggetto']) . '»"></label>'
            . '<a class="ps-apri" href="' . h($plugin->site_url('leggi', array('c' => (int)$r['id'], 'f' => $f))) . '">'
            . ($r['gruppo'] && count($r['altri']) > 1 ? '<span class="ps-av gruppo" style="width:34px;height:34px" aria-hidden="true">' . ps_icona('users', 18) . '</span>' : ps_avatar($av))
            . '<span class="ps-da">' . h($chi) . ($r['totale'] > 1 ? ' <small>' . (int)$r['totale'] . '</small>' : '') . '</span>'
            . '<span class="ps-ogg"><b>' . h($r['oggetto']) . '</b><span class="ps-ant"> — ' . h(ps_anteprima($r['ultimo'])) . '</span></span>'
            . '<span class="ps-data" title="' . h(date('d/m/Y H:i', strtotime($quando))) . '">' . ($nuovo && $r['nuovi'] ? '<i class="ps-pallino" aria-label="da leggere"></i>' : '') . h(ps_quando($quando)) . '</span></a></div>';
    }
    echo '</div></form>';
    if ($f === 'cestino') {
        echo $plugin->form_start('id="ps-svuota" data-confirm="Svuotare il cestino? Le conversazioni spariranno per sempre dalla tua posta."')
            . '<input type="hidden" name="op" value="svuota"><input type="hidden" name="back" value="' . h($back) . '"></form>';
    }
    if ($pg > 1 || $altre) {
        echo '<div class="ps-pagine">' . ($pg > 1 ? '<a class="btn ghost small" href="' . h($plugin->site_url('posta', array('f' => $f, 'pg' => $pg - 1))) . '">← Più recenti</a>' : '<span></span>')
            . '<span class="muted">Pagina ' . $pg . '</span>' . ($altre ? '<a class="btn ghost small" href="' . h($plugin->site_url('posta', array('f' => $f, 'pg' => $pg + 1))) . '">Meno recenti →</a>' : '<span></span>') . '</div>';
    }
    ps_fine();
}

function ps_elenco_bozze($plugin, $uid, $back)
{
    $bozze = ps_bozze($plugin, $uid);
    if (!$bozze) {
        echo '<div class="ps-vuoto">' . ps_icona('draft', 40) . '<p>Nessuna bozza. Mentre scrivi un messaggio viene salvata da sola.</p></div>';
        return;
    }
    echo $plugin->form_start('class="ps-elenco" data-ps-elenco') . '<input type="hidden" name="back" value="' . h($back) . '">'
        . '<div class="ps-barra"><label class="ps-sel ps-tutti" title="Seleziona tutte"><input type="checkbox" data-ps-tutti aria-label="Seleziona tutte"></label><span class="ps-quanti" data-ps-quanti></span>'
        . '<div class="ps-azioni"><button class="ps-btn rosso" type="submit" name="op" value="bozze_elimina" disabled data-ps-azione>' . ps_icona('trash', 17) . '<span>Elimina</span></button></div></div>'
        . '<div class="ps-lista" role="list"><div class="ps-intest" aria-hidden="true"><span></span><span>A</span><span>Oggetto</span><span>Data</span></div>';
    foreach ($bozze as $b) {
        $conv = $b['conv_id'] ? ps_conv($plugin, $b['conv_id']) : null;
        if ($conv) {
            $altri = array_values(array_diff(ps_partecipanti($plugin, $conv['id']), array($uid)));
            $a = $altri ? ps_nome($altri[0]) . (count($altri) > 1 ? ' +' . (count($altri) - 1) : '') : '—';
            $ogg = 'Risposta: ' . $conv['oggetto'];
            $link = $plugin->site_url('leggi', array('c' => (int)$conv['id']));
            $av = $altri ? $altri[0] : $uid;
        } else {
            $dest = array_values(array_filter(array_map('intval', explode(',', (string)$b['destinatari']))));
            $a = $dest ? ps_nome($dest[0]) . (count($dest) > 1 ? ' +' . (count($dest) - 1) : '') : ($b['modo'] === 'tutti' ? 'Tutti' : '(nessun destinatario)');
            $ogg = (string)$b['oggetto'] !== '' ? $b['oggetto'] : '(senza oggetto)';
            $link = $plugin->site_url('scrivi', array('b' => (int)$b['id']));
            $av = $dest ? $dest[0] : $uid;
        }
        $ant = trim(preg_replace('/\s+/u', ' ', (string)$b['testo']));
        echo '<div class="ps-riga bozza" role="listitem"><label class="ps-sel"><input type="checkbox" name="b[]" value="' . (int)$b['id'] . '" aria-label="Seleziona la bozza «' . h($ogg) . '»"></label>'
            . '<a class="ps-apri" href="' . h($link) . '">' . ps_avatar($av) . '<span class="ps-da"><i class="ps-tag-bozza">Bozza</i> ' . h($a) . '</span>'
            . '<span class="ps-ogg"><b>' . h($ogg) . '</b><span class="ps-ant"> — ' . h(str_cut($ant !== '' ? $ant : ($b['immagine'] ? '📷 Immagine' : ''), 100)) . '</span></span>'
            . '<span class="ps-data">' . h(ps_quando($b['updated_at'])) . '</span></a></div>';
    }
    echo '</div></form>';
}

/* ================= Conversazione ================= */

function ps_pagina_leggi($plugin)
{
    $uid = current_uid();
    $cid = (int)get('c');
    $c = ps_conv($plugin, $cid);
    $p = $c ? ps_part($plugin, $cid, $uid) : null;
    if (!$c || !$p || $p['cartella'] === 'eliminata') {
        echo '<div class="alert error">Conversazione non trovata: forse è stata eliminata.</div><a class="btn ghost small" href="' . h($plugin->site_url('posta')) . '">Torna alla posta</a>';
        return;
    }
    $f = array_key_exists((string)get('f'), ps_cartelle()) ? (string)get('f') : ($p['cartella'] === 'archivio' ? 'archivio' : ($p['cartella'] === 'cestino' ? 'cestino' : 'arrivo'));
    $tutti = get('tutti') === '1';
    $msgs = ps_messaggi($plugin, $cid, $p['nascosti_fino'], $tutti ? 5000 : 150);
    $tot = (int)db()->query('SELECT COUNT(*) FROM ' . ps_t($plugin, 'messaggi') . ' WHERE conv_id = ' . $cid . ' AND id > ' . (int)$p['nascosti_fino'])->fetchColumn();
    $primo_nuovo = 0;
    foreach ($msgs as $m) {
        if ((int)$m['user_id'] !== $uid && (int)$m['id'] > (int)$p['letto_fino']) {
            $primo_nuovo = (int)$m['id'];
            break;
        }
    }
    // aperta = letta
    db()->prepare('UPDATE ' . ps_t($plugin, 'partecipanti') . ' SET letto_fino = ?, da_leggere = 0 WHERE id = ?')->execute(array((int)$c['ultimo_id'], (int)$p['id']));
    ps_notifiche_lette($plugin, $cid, $uid);

    $altri = array_values(array_diff(ps_partecipanti($plugin, $cid), array($uid)));
    $attivi = array_values(array_filter($altri, 'ps_utente'));
    $back = $plugin->site_url('leggi', array('c' => $cid, 'f' => $f));
    $back_lista = $plugin->site_url('posta', array('f' => $f));
    ps_inizio($plugin, $f);

    echo '<div class="ps-conv">';
    echo '<div class="ps-chead"><a class="ps-indietro" href="' . h($back_lista) . '" aria-label="Torna a ' . h(ps_cartelle()[$f][0]) . '">' . ps_icona('back', 20) . '</a>'
        . '<div class="ps-ctit"><h1>' . h($c['oggetto']) . '</h1><p>' . ($altri ? 'Con ' . h(implode(', ', array_map('ps_nome', $altri))) : 'Solo tu')
        . ((int)$c['gruppo'] && count($altri) > 1 ? ' · <span class="ps-gr">' . ps_icona('users', 13) . ' gruppo</span>' : '') . '</p></div>';
    // azioni sulla conversazione
    echo $plugin->form_start('class="ps-cazioni"' . ($p['cartella'] === 'cestino' ? ' data-ps-conferma-elimina' : '')) . '<input type="hidden" name="c[]" value="' . $cid . '"><input type="hidden" name="back" value="' . h($back_lista) . '">';
    $bt = function ($op, $ic, $t, $cls = '') {
        return '<button class="ps-btn' . $cls . '" type="submit" name="op" value="' . $op . '" title="' . h($t) . '">' . ps_icona($ic, 17) . '<span>' . h($t) . '</span></button>';
    };
    if ($p['cartella'] === 'cestino') {
        echo $bt('ripristina', 'restore', 'Ripristina') . $bt('elimina', 'x', 'Elimina per sempre', ' rosso');
    } else {
        echo ($p['cartella'] === 'archivio' ? $bt('arrivo', 'inbox', 'In arrivo') : $bt('archivia', 'archive', 'Archivia'))
            . $bt('da_leggere', 'unread', 'Da leggere') . $bt('cestino', 'trash', 'Elimina');
    }
    echo '</form></div>';

    $classica = ps_stile($plugin) === 'classica';
    if ($classica) {
        ps_thread_classico($plugin, $c, $msgs, $tot, $uid, $altri, $primo_nuovo, $f);
    } else {
        ps_thread_chat($plugin, $c, $msgs, $tot, $uid, $altri, $primo_nuovo, $f);
    }

    // risposta
    if ($p['cartella'] === 'cestino') {
        echo '<div class="ps-nonrisp">La conversazione è nel cestino: ripristinala per rispondere.</div>';
    } elseif (!$attivi) {
        echo '<div class="ps-nonrisp">Non puoi rispondere: ' . ($altri ? 'gli altri partecipanti non sono più utenti attivi del sito.' : 'non ci sono altri partecipanti.') . '</div>';
    } else {
        $bz = ps_bozza_risposta($plugin, $cid, $uid);
        $lib = $bz && $bz['libro_id'] ? ps_libro($bz['libro_id']) : null;
        $testo = h($bz ? (string)$bz['testo'] : '');
        $file = '<input type="file" name="immagine" accept="image/jpeg,image/png,image/webp,image/gif" data-ps-file hidden>';
        echo $plugin->form_start('class="ps-risposta' . ($classica ? ' classica' : '') . '" enctype="multipart/form-data" data-ps-form data-ps-rispondi data-ps-bozza-conv="' . $cid . '"')
            . '<input type="hidden" name="op" value="rispondi"><input type="hidden" name="cid" value="' . $cid . '"><input type="hidden" name="back" value="' . h($back) . '">'
            . '<input type="hidden" name="bozza" value="' . ($bz ? (int)$bz['id'] : 0) . '" data-ps-bozza-id>';
        if ($classica) {
            // posta classica: riquadro di risposta con destinatari, testo ampio e pulsanti sotto
            $a = array_map('ps_nome', $attivi);
            echo '<div class="ps-rtesta">' . ps_icona('reply', 18) . '<b>' . (count($attivi) > 1 ? 'Rispondi a tutti' : 'Rispondi') . '</b><span>a ' . h(implode(', ', $a)) . '</span></div>'
                . '<textarea class="input" name="testo" rows="6" maxlength="' . PS_MAX_TESTO . '" placeholder="Scrivi la risposta…" data-ps-testo aria-label="Risposta">' . $testo . '</textarea>'
                . ps_allegati_html($plugin, $lib, $bz ? (string)$bz['immagine'] : '', $bz ? (int)$bz['id'] : 0)
                . '<div class="ps-rpiede"><button class="btn primary small" type="submit">' . ps_icona('send', 16) . ' Invia</button>'
                . '<label class="btn ghost small">' . ps_icona('image', 16) . ' Immagine' . $file . '</label>'
                . '<button class="btn ghost small" type="button" data-ps-libro-apri>' . ps_icona('book', 16) . ' Libro</button>'
                . '<span class="ps-salvata" data-ps-salvata hidden>Bozza salvata</span></div></form>';
        } else {
            echo ps_allegati_html($plugin, $lib, $bz ? (string)$bz['immagine'] : '', $bz ? (int)$bz['id'] : 0)
                . '<div class="ps-rriga">'
                . '<label class="ps-tondo" title="Allega un\'immagine">' . ps_icona('image', 20) . $file . '</label>'
                . '<button class="ps-tondo" type="button" title="Allega un libro" data-ps-libro-apri>' . ps_icona('book', 20) . '</button>'
                . '<textarea class="input" name="testo" rows="1" maxlength="' . PS_MAX_TESTO . '" placeholder="Scrivi una risposta…" data-ps-testo data-ps-cresce aria-label="Risposta">' . $testo . '</textarea>'
                . '<button class="ps-tondo invia" type="submit" title="Invia" aria-label="Invia">' . ps_icona('send', 20) . '</button></div>'
                . '<p class="ps-salvata" data-ps-salvata hidden>Bozza salvata</p></form>';
        }
    }
    echo '</div>';
    ps_fine();
}

// Stile della posta scelto in Gestione → Plugin → Posta: 'chat' (predefinito) o 'classica'
function ps_stile($plugin)
{
    return $plugin->setting('stile', 'chat') === 'classica' ? 'classica' : 'chat';
}

// Immagine, libro e testo di un messaggio (uguali nei due stili)
function ps_contenuto($plugin, $m)
{
    $h = '';
    if ($m['immagine']) {
        $u = $plugin->site_url('img', array('m' => (int)$m['id']));
        $h .= '<a class="ps-img" href="' . h($u) . '" target="_blank" rel="noopener"><img src="' . h($u) . '" alt="Immagine allegata" loading="lazy"></a>';
    }
    if ($m['libro_id']) {
        $h .= ps_scheda_libro($m['libro_id'], (string)$m['libro_titolo']);
    }
    if (trim((string)$m['testo']) !== '') {
        $h .= '<div class="ps-testo">' . ps_testo_html($m['testo']) . '</div>';
    }
    return $h;
}

function ps_link_precedenti($plugin, $c, $msgs, $tot, $f)
{
    if ($tot > count($msgs)) {
        echo '<a class="ps-prima" href="' . h($plugin->site_url('leggi', array('c' => (int)$c['id'], 'f' => $f, 'tutti' => 1))) . '">Mostra i ' . ($tot - count($msgs)) . ' messaggi precedenti</a>';
    }
}

// Stile chat: bolle, divise per giorno
function ps_thread_chat($plugin, $c, $msgs, $tot, $uid, $altri, $primo_nuovo, $f)
{
    $lk = ps_mipiace_di($plugin, array_map(function ($m) { return $m['id']; }, $msgs));
    $back = $plugin->site_url('leggi', array('c' => (int)$c['id'], 'f' => $f));
    $stato = array('giorno' => '', 'prec' => 0);
    $html = '';
    foreach ($msgs as $m) {
        $html .= ps_msg_chat_html($plugin, $m, $uid, $altri, $lk, $back, $stato, $primo_nuovo);
    }
    $ult = $msgs ? (int)end($msgs)['id'] : 0;
    echo '<div class="ps-chat" data-ps-chat' . ps_live_attr($c, $ult, $stato, $f, 'chat') . '>';
    ps_link_precedenti($plugin, $c, $msgs, $tot, $f);
    echo $html . '<span id="ps-fondo" data-ps-fondo></span></div>';
}

// Dati per gli aggiornamenti in diretta (1.3.0): conversazione, ultimo messaggio mostrato, giorno e autore dell'ultimo
function ps_live_attr($c, $ult, $stato, $f, $stile)
{
    return ' data-ps-live="' . (int)$c['id'] . '" data-ps-dopo="' . (int)$ult . '" data-ps-giorno="' . h($stato['giorno']) . '" data-ps-prec="' . (int)$stato['prec'] . '"'
        . ' data-ps-f="' . h($f) . '" data-ps-stile="' . h($stile) . '"';
}

// Una bolla della chat (con il separatore del giorno, se cambia). $stato: giorno e autore del messaggio precedente
function ps_msg_chat_html($plugin, $m, $uid, $altri, $lk, $back, &$stato, $primo_nuovo = 0)
{
    $h = '';
    $g = date('Y-m-d', strtotime($m['created_at']));
    if ($g !== $stato['giorno']) {
        $h .= '<div class="ps-giorno"><span>' . h(ps_giorno($m['created_at'])) . '</span></div>';
        $stato['giorno'] = $g;
        $stato['prec'] = 0;
    }
    if ((int)$m['id'] === (int)$primo_nuovo) {
        $h .= '<div class="ps-nuovi" id="ps-nuovi" data-ps-nuovi><span>Nuovi messaggi</span></div>';
        $stato['prec'] = 0;
    }
    $mio = (int)$m['user_id'] === (int)$uid;
    $seguito = (int)$stato['prec'] === (int)$m['user_id'];
    $h .= '<div class="ps-msg ' . ($mio ? 'mio' : 'altro') . ($seguito ? ' seguito' : '') . '" data-mid="' . (int)$m['id'] . '">';
    if (!$mio) {
        $h .= $seguito ? '<span class="ps-av vuoto" style="width:30px;height:30px"></span>' : ps_avatar($m['user_id'], 30);
    }
    $h .= '<div class="ps-bolla"' . ($mio ? '' : ' data-ps-doppio="' . (int)$m['id'] . '"') . '>';
    if (!$mio && !$seguito && count($altri) > 1) {
        $h .= '<b class="ps-autore" style="color:' . ps_colore($m['user_id']) . '">' . h(ps_nome($m['user_id'])) . '</b>';
    }
    $h .= ps_contenuto($plugin, $m);
    $h .= '<div class="ps-piede">' . ps_cuore_html($plugin, $m, $uid, isset($lk[(int)$m['id']]) ? $lk[(int)$m['id']] : array(), $back, false)
        . '<time datetime="' . h(date('c', strtotime($m['created_at']))) . '" title="' . h(date('d/m/Y H:i', strtotime($m['created_at']))) . '">' . h(date('H:i', strtotime($m['created_at']))) . '</time></div>';
    $h .= '</div></div>';
    $stato['prec'] = (int)$m['user_id'];
    return $h;
}

/*
 * Stile posta classica: un riquadro per messaggio, dal più vecchio al più recente, con mittente, destinatari e data completa.
 * Restano aperti l'ultimo messaggio e quelli da leggere; gli altri sono chiusi su una riga (si aprono con un clic).
 */
function ps_thread_classico($plugin, $c, $msgs, $tot, $uid, $altri, $primo_nuovo, $f)
{
    $lk = ps_mipiace_di($plugin, array_map(function ($m) { return $m['id']; }, $msgs));
    $back = $plugin->site_url('leggi', array('c' => (int)$c['id'], 'f' => $f));
    $n = count($msgs);
    $html = '';
    foreach ($msgs as $i => $m) {
        $nuovo = $primo_nuovo && (int)$m['id'] >= $primo_nuovo && (int)$m['user_id'] !== (int)$uid;
        $html .= ps_mail_html($plugin, $m, $uid, $altri, $lk, $back, $nuovo, $i === $n - 1 || $nuovo, (int)$m['id'] === (int)$primo_nuovo, $i === $n - 1);
    }
    $ult = $msgs ? (int)end($msgs)['id'] : 0;
    echo '<div class="ps-mails" data-ps-chat' . ps_live_attr($c, $ult, array('giorno' => '', 'prec' => 0), $f, 'classica') . '>';
    ps_link_precedenti($plugin, $c, $msgs, $tot, $f);
    echo $html . '<span id="ps-fondo" data-ps-fondo></span></div>';
}

// Un messaggio della posta classica (riquadro che si apre e si chiude)
function ps_mail_html($plugin, $m, $uid, $altri, $lk, $back, $nuovo, $aperto, $primo, $ultimo)
{
    $tutti = array_merge(array((int)$uid), $altri);
    $da = (int)$m['user_id'];
    $mio = $da === (int)$uid;
    $a = array();
    foreach ($tutti as $x) {
        if ((int)$x !== $da) {
            $a[] = (int)$x === (int)$uid ? 'me' : ps_nome($x);
        }
    }
    $t = strtotime($m['created_at']);
    $quando = ps_giorno($m['created_at']) . ', ' . date('H:i', $t);
    $attr = ' data-mid="' . (int)$m['id'] . '"' . ($primo ? ' id="ps-nuovi" data-ps-nuovi' : '') . ($ultimo ? ' data-ps-ultimo' : '');
    return '<details class="ps-mail' . ($mio ? ' mio' : '') . ($nuovo ? ' nuovo' : '') . '"' . ($aperto ? ' open' : '') . $attr . '>'
        . '<summary>' . ps_avatar($da, 36) . '<span class="ps-mtesta"><b>' . h($mio ? 'Tu' : ps_nome($da)) . '</b>'
        . '<small class="ps-ma">a ' . h(implode(', ', $a)) . '</small><small class="ps-mant">' . h(ps_anteprima($m)) . '</small></span>'
        . '<time datetime="' . h(date('c', $t)) . '" title="' . h(date('d/m/Y H:i', $t)) . '">' . ($nuovo ? '<i class="ps-pallino" aria-label="nuovo"></i>' : '') . h($quando) . '</time></summary>'
        . '<div class="ps-mcorpo"' . ($mio ? '' : ' data-ps-doppio="' . (int)$m['id'] . '"') . '>' . ps_contenuto($plugin, $m)
        . ps_cuore_html($plugin, $m, $uid, isset($lk[(int)$m['id']]) ? $lk[(int)$m['id']] : array(), $back, true) . '</div></details>';
}

/*
 * Cuore del "mi piace" (1.2.0). Messaggi degli altri: pulsante (funziona anche senza JavaScript); i propri: solo il cuore, se piace a qualcuno.
 * $chi: id di chi ha messo mi piace.
 */
function ps_cuore_html($plugin, $m, $uid, $chi, $back, $classica)
{
    $mio = (int)$m['user_id'] === (int)$uid;
    $messo = in_array((int)$uid, $chi, true);
    $n = count($chi);
    $nomi = array_map(function ($x) use ($uid) { return $x === (int)$uid ? 'te' : ps_nome($x); }, $chi);
    $titolo = $n ? 'Piace a ' . implode(', ', $nomi) : '';
    if ($mio) {
        if (!$n) {
            return '';
        }
        return '<span class="ps-cuore pieno fermo" title="' . h($titolo) . '" data-ps-cuore-box>♥' . ($classica ? ' <span>' . h($titolo) . '</span>' : ($n > 1 ? ' <b>' . $n . '</b>' : '')) . '</span>';
    }
    $etichetta = $classica ? '<span data-ps-cuore-testo>' . h($messo ? ($n > 1 ? 'Piace a te e ad altri ' . ($n - 1) : 'Ti piace') : ($n ? $titolo : 'Mi piace')) . '</span>' : ($n > 1 ? ' <b data-ps-cuore-n>' . $n . '</b>' : ' <b data-ps-cuore-n hidden></b>');
    return $plugin->form_start('class="ps-cuore-f" data-ps-cuore-form') . '<input type="hidden" name="op" value="mipiace"><input type="hidden" name="mid" value="' . (int)$m['id'] . '">'
        . '<input type="hidden" name="back" value="' . h($back) . '">'
        . '<button class="ps-cuore' . ($messo ? ' pieno' : '') . ($classica ? ' testo' : '') . '" type="submit" aria-pressed="' . ($messo ? 'true' : 'false') . '" aria-label="Mi piace"'
        . ($titolo !== '' ? ' title="' . h($titolo) . '"' : ' title="Mi piace"') . ' data-ps-cuore>' . '<i aria-hidden="true">' . ($messo ? '♥' : '♡') . '</i>' . $etichetta . '</button></form>';
}

// Scheda del libro allegato (dentro un messaggio)
function ps_scheda_libro($id, $titolo_salvato)
{
    $b = ps_libro($id);
    if (!$b) {
        return '<div class="ps-libro assente">' . ps_icona('book', 18) . '<span><b>' . h($titolo_salvato !== '' ? $titolo_salvato : 'Libro') . '</b><small>Non è più nella libreria</small></span></div>';
    }
    return '<a class="ps-libro" href="libro.php?id=' . (int)$b['id'] . '">' . book_cover_html($b, 'ps-cop') . '<span><b>' . h($b['title']) . '</b>'
        . ((string)$b['authors'] !== '' ? '<small>' . h($b['authors']) . '</small>' : '') . '<em>Apri la scheda →</em></span></a>';
}

// Riquadro degli allegati scelti (immagine e libro) e ricerca del libro
function ps_allegati_html($plugin, $lib, $img, $bid)
{
    $h = '<div class="ps-allegati" data-ps-allegati>';
    $h .= '<div class="ps-chip ps-chip-img"' . ($img !== '' ? '' : ' hidden') . ' data-ps-img-chip>'
        . ($img !== '' && $bid ? '<img src="' . h($plugin->site_url('img', array('b' => $bid))) . '" alt="" data-ps-img-prev>' : '<img src="data:," alt="" data-ps-img-prev>')
        . '<span data-ps-img-nome>Immagine</span><button type="button" class="ps-chip-x" aria-label="Togli l\'immagine" data-ps-img-togli>' . ps_icona('x', 14) . '</button>'
        . '<input type="hidden" name="togli_img" value="0" data-ps-img-togli-campo></div>';
    $h .= '<div class="ps-chip ps-chip-libro"' . ($lib ? '' : ' hidden') . ' data-ps-libro-chip>' . ps_icona('book', 16) . '<span data-ps-libro-nome>' . ($lib ? h($lib['title']) : '') . '</span>'
        . '<button type="button" class="ps-chip-x" aria-label="Togli il libro" data-ps-libro-togli>' . ps_icona('x', 14) . '</button>'
        . '<input type="hidden" name="libro" value="' . ($lib ? (int)$lib['id'] : 0) . '" data-ps-libro-id></div>';
    $h .= '</div><div class="ps-cerca-libro" hidden data-ps-libro-box><input class="input" type="search" placeholder="Cerca un libro della libreria (titolo, autore, ISBN)" data-ps-libro-q aria-label="Cerca un libro">'
        . '<div class="ps-libri" data-ps-libri></div></div>';
    return $h;
}

/* ================= Nuovo messaggio ================= */

function ps_pagina_scrivi($plugin)
{
    $uid = current_uid();
    $bz = get('b') ? ps_bozza($plugin, (int)get('b'), $uid) : null;
    if ($bz && $bz['conv_id'] && ps_conv($plugin, $bz['conv_id'])) {
        redirect($plugin->site_url('leggi', array('c' => (int)$bz['conv_id'])));
    }
    $possibili = ps_destinatari_possibili($uid);
    $multi = can_edit();
    $sel = $bz ? array_values(array_filter(array_map('intval', explode(',', (string)$bz['destinatari'])))) : (get('a') ? array((int)get('a')) : array());
    $sel = array_values(array_filter($sel, function ($x) use ($possibili) { return isset($possibili[$x]); }));
    $tutti = $bz && $bz['modo'] === 'tutti' && $multi;
    $modo = $bz && $bz['modo'] === 'gruppo' ? 'gruppo' : 'separati';
    $lib = $bz && $bz['libro_id'] ? ps_libro($bz['libro_id']) : (get('libro') ? ps_libro((int)get('libro')) : null);
    $ogg = $bz ? (string)$bz['oggetto'] : ($lib && !$bz ? 'Ti consiglio «' . $lib['title'] . '»' : '');
    $testo = $bz ? (string)$bz['testo'] : '';

    ps_inizio($plugin, $bz ? 'bozze' : '');
    echo '<div class="ps-head"><h1 class="h1">' . ($lib && !$bz ? 'Consiglia un libro' : 'Nuovo messaggio') . '</h1></div>';
    if (!$possibili) {
        echo '<div class="ps-vuoto">' . ps_icona('users', 40) . '<p>Non ci sono altri utenti a cui scrivere.</p></div>';
        ps_fine();
        return;
    }
    echo $plugin->form_start('class="card stack ps-scrivi-form" enctype="multipart/form-data" data-ps-form data-ps-nuovo')
        . '<input type="hidden" name="op" value="invia"><input type="hidden" name="back" value="' . h($plugin->site_url('scrivi')) . '">'
        . '<input type="hidden" name="bozza" value="' . ($bz ? (int)$bz['id'] : 0) . '" data-ps-bozza-id>';

    echo '<div><span class="lab">A</span>';
    if ($multi) {
        echo '<div class="ps-dest" data-ps-dest><label class="check ps-dest-tutti"><input type="checkbox" name="tutti" value="1" data-ps-dest-tutti' . ($tutti ? ' checked' : '') . '> <span><b>Tutti</b> (' . count($possibili) . ' persone)</span></label>'
            . '<input class="input ps-dest-filtro" type="search" placeholder="Cerca una persona" data-ps-dest-filtro aria-label="Cerca una persona"' . (count($possibili) < 8 ? ' hidden' : '') . '>'
            . '<div class="ps-dest-lista" data-ps-dest-lista>';
        foreach ($possibili as $id => $nome) {
            echo '<label class="ps-dest-u" data-nome="' . h(mb_strtolower($nome, 'UTF-8')) . '"><input type="checkbox" name="a[]" value="' . (int)$id . '"' . (in_array($id, $sel, true) || $tutti ? ' checked' : '') . '>'
                . ps_avatar($id, 26) . '<span>' . h($nome) . '</span></label>';
        }
        echo '</div></div>';
        echo '<div class="ps-modo" data-ps-modo hidden><span class="lab">Con più destinatari</span><div class="seg">'
            . '<label><input type="radio" name="modo" value="separati"' . ($modo === 'separati' ? ' checked' : '') . '><span>Un messaggio a ciascuno</span></label>'
            . '<label><input type="radio" name="modo" value="gruppo"' . ($modo === 'gruppo' ? ' checked' : '') . '><span>Conversazione di gruppo</span></label></div>'
            . '<p class="hint" data-ps-modo-hint></p></div>';
    } else {
        echo '<select class="input" name="a[]" required aria-label="Destinatario"><option value="">Scegli a chi scrivere…</option>';
        foreach ($possibili as $id => $nome) {
            echo '<option value="' . (int)$id . '"' . (in_array($id, $sel, true) ? ' selected' : '') . '>' . h($nome) . '</option>';
        }
        echo '</select>';
    }
    echo '</div>';
    echo '<div><label class="lab" for="ps-ogg">Oggetto</label><input class="input" id="ps-ogg" name="oggetto" maxlength="' . PS_MAX_OGGETTO . '" value="' . h($ogg) . '" placeholder="Di cosa si parla" data-ps-oggetto></div>'
        . '<div><label class="lab" for="ps-testo">Messaggio</label><textarea class="input" id="ps-testo" name="testo" rows="7" maxlength="' . PS_MAX_TESTO . '" data-ps-testo>' . h($testo) . '</textarea></div>';
    echo ps_allegati_html($plugin, $lib, $bz ? (string)$bz['immagine'] : '', $bz ? (int)$bz['id'] : 0);
    echo '<div class="ps-allega"><label class="btn ghost small">' . ps_icona('image', 16) . ' Allega un\'immagine<input type="file" name="immagine" accept="image/jpeg,image/png,image/webp,image/gif" data-ps-file hidden></label>'
        . '<button class="btn ghost small" type="button" data-ps-libro-apri>' . ps_icona('book', 16) . ' Allega un libro</button></div>';
    echo '<div class="row-btn ps-invia"><button class="btn primary" type="submit">' . ps_icona('send', 18) . ' Invia</button>'
        . '<button class="btn ghost small" type="submit" name="op" value="bozza" formnovalidate>Salva bozza</button>'
        . '<span class="ps-salvata" data-ps-salvata hidden>Bozza salvata</span></div>';
    echo '</form>';
    ps_fine();
}

/* ================= Salvataggi ================= */

function ps_dati_form()
{
    return array(
        'oggetto' => str_cut(trim(preg_replace('/\s+/u', ' ', (string)post('oggetto'))), PS_MAX_OGGETTO),
        'testo' => str_cut(rtrim(str_replace("\r\n", "\n", (string)post('testo'))), PS_MAX_TESTO),
        'libro' => (int)post('libro'),
    );
}

function ps_salva($plugin)
{
    if (!is_user()) {
        return;
    }
    $uid = current_uid();
    $op = post('op');
    $ids = isset($_POST['c']) ? (array)$_POST['c'] : array();
    switch ($op) {
        case 'archivia':
        case 'arrivo':
        case 'ripristina':
        case 'cestino':
        case 'letto':
        case 'da_leggere':
        case 'elimina':
            $n = ps_sposta($plugin, $uid, $ids, $op);
            $t = array(
                'archivia' => array('archiviata', 'archiviate'), 'arrivo' => array('spostata in arrivo', 'spostate in arrivo'),
                'ripristina' => array('ripristinata', 'ripristinate'), 'cestino' => array('spostata nel cestino', 'spostate nel cestino'),
                'letto' => array('segnata come letta', 'segnate come lette'), 'da_leggere' => array('segnata da leggere', 'segnate da leggere'),
                'elimina' => array('eliminata per sempre', 'eliminate per sempre'));
            if ($n) {
                flash(($n === 1 ? '1 conversazione ' . $t[$op][0] : $n . ' conversazioni ' . $t[$op][1]) . '.');
            }
            return;
        case 'svuota':
            $n = ps_svuota_cestino($plugin, $uid);
            flash($n ? 'Cestino svuotato.' : 'Il cestino era già vuoto.');
            return;
        case 'bozze_elimina':
            $n = 0;
            foreach (isset($_POST['b']) ? (array)$_POST['b'] : array() as $bid) {
                if (ps_bozza($plugin, (int)$bid, $uid)) {
                    ps_bozza_elimina($plugin, (int)$bid, $uid);
                    $n++;
                }
            }
            flash($n === 1 ? 'Bozza eliminata.' : $n . ' bozze eliminate.');
            return;
        case 'rispondi':
            $r = ps_salva_risposta($plugin, $uid);
            if (!$r[0]) {
                flash($r[1], 'error');
            }
            return;
        case 'mipiace':
            $r = ps_mipiace_cambia($plugin, $uid, (int)post('mid'));
            if (!$r[0]) {
                flash($r[1], 'error');
            }
            return;
        case 'invia':
        case 'bozza':
            ps_salva_nuovo($plugin, $uid, $op === 'bozza');
            return;
    }
}

// Immagine: caricata adesso, oppure quella della bozza (se non e' stata tolta)
function ps_immagine_da_form($plugin, $bz)
{
    list($img, $err) = ps_salva_immagine($plugin, isset($_FILES['immagine']) ? $_FILES['immagine'] : null);
    if ($img === '' && $err === '' && $bz && $bz['immagine'] && post('togli_img') !== '1') {
        $img = (string)$bz['immagine'];
    }
    return array($img, $err);
}

// Esito: array(ok, id del messaggio o testo dell'errore)
function ps_salva_risposta($plugin, $uid)
{
    $cid = (int)post('cid');
    $c = ps_conv($plugin, $cid);
    $p = $c ? ps_part($plugin, $cid, $uid) : null;
    if (!$c || !$p || in_array($p['cartella'], array('eliminata', 'cestino'), true)) {
        return array(false, 'Non puoi rispondere a questa conversazione.');
    }
    $altri = array_values(array_filter(array_diff(ps_partecipanti($plugin, $cid), array($uid)), 'ps_utente'));
    if (!$altri) {
        return array(false, 'Non ci sono più persone a cui rispondere.');
    }
    $bz = ps_bozza_risposta($plugin, $cid, $uid);
    $d = ps_dati_form();
    list($img, $err) = ps_immagine_da_form($plugin, $bz);
    if ($err !== '') {
        ps_bozza_salva($plugin, $uid, $bz ? $bz['id'] : 0, array('conv_id' => $cid, 'oggetto' => '', 'testo' => $d['testo'], 'libro_id' => $d['libro']));
        return array(false, $err);
    }
    $lib = ps_libro($d['libro']);
    if (trim($d['testo']) === '' && $img === '' && !$lib) {
        return array(false, 'Scrivi qualcosa prima di inviare.');
    }
    if (!can_edit() && ps_inviati_ora($plugin, $uid) >= PS_MAX_ORA) {
        return array(false, 'Hai mandato troppi messaggi nell\'ultima ora: riprova più tardi.');
    }
    $mid = ps_aggiungi($plugin, $cid, $uid, $d['testo'], $lib ? $lib['id'] : 0, $lib ? $lib['title'] : '', $img);
    if ($bz) {
        ps_bozza_elimina($plugin, $bz['id'], $uid, $img !== '' && $img === (string)$bz['immagine']);
    }
    ps_avvisa($plugin, $cid, $mid, $uid, $c['oggetto'], $d['testo']);
    return array(true, $mid);
}

function ps_salva_nuovo($plugin, $uid, $solo_bozza)
{
    $possibili = ps_destinatari_possibili($uid);
    $tutti = can_edit() && post('tutti') === '1';
    $dest = array();
    foreach (isset($_POST['a']) ? (array)$_POST['a'] : array() as $x) {
        if (isset($possibili[(int)$x]) && !in_array((int)$x, $dest, true)) {
            $dest[] = (int)$x;
        }
    }
    if ($tutti) {
        $dest = array_keys($possibili);
    }
    $modo = $tutti ? 'tutti' : (post('modo') === 'gruppo' ? 'gruppo' : 'separati');
    $gruppo = post('modo') === 'gruppo';
    $d = ps_dati_form();
    $bid = (int)post('bozza');
    $bz = $bid ? ps_bozza($plugin, $bid, $uid) : null;
    list($img, $err) = ps_immagine_da_form($plugin, $bz);
    $salva_bozza = function ($msg, $tipo = 'success') use ($plugin, $uid, $bz, $dest, $modo, $d, $img, $gruppo) {
        $m = $modo === 'tutti' ? 'tutti' : ($gruppo ? 'gruppo' : 'separati');
        $id = ps_bozza_salva($plugin, $uid, $bz ? $bz['id'] : 0, array('destinatari' => $modo === 'tutti' ? array() : $dest, 'modo' => $m,
            'oggetto' => $d['oggetto'], 'testo' => $d['testo'], 'libro_id' => $d['libro'], 'immagine' => $img));
        flash($msg, $tipo);
        $_POST['back'] = $id ? $plugin->site_url('scrivi', array('b' => $id)) : $plugin->site_url('scrivi');
    };
    if ($err !== '') {
        $salva_bozza($err . ' Il messaggio è stato salvato nelle bozze.', 'error');
        return;
    }
    if ($solo_bozza) {
        $salva_bozza('Bozza salvata.');
        return;
    }
    $lib = ps_libro($d['libro']);
    $errore = '';
    if (!$dest) {
        $errore = 'Scegli a chi mandare il messaggio.';
    } elseif (!can_edit() && count($dest) > 1) {
        $errore = 'Puoi scrivere a una persona per volta.';
    } elseif (trim($d['testo']) === '' && $img === '' && !$lib) {
        $errore = 'Il messaggio è vuoto.';
    } elseif (!can_edit() && ps_inviati_ora($plugin, $uid) >= PS_MAX_ORA) {
        $errore = 'Hai mandato troppi messaggi nell\'ultima ora: riprova più tardi.';
    }
    if ($errore !== '') {
        $salva_bozza($errore, 'error');
        return;
    }
    $oggetto = $d['oggetto'] !== '' ? $d['oggetto'] : ($lib ? 'Ti consiglio «' . str_cut($lib['title'], 120) . '»' : '(senza oggetto)');
    $insieme = count($dest) === 1 || $gruppo;
    $convs = array();
    if ($insieme) {
        $cid = ps_nuova_conv($plugin, $uid, $dest, $oggetto, $gruppo && count($dest) > 1);
        $mid = ps_aggiungi($plugin, $cid, $uid, $d['testo'], $lib ? $lib['id'] : 0, $lib ? $lib['title'] : '', $img);
        $convs[] = array($cid, $mid);
    } else {
        foreach ($dest as $i => $a) {
            $f = $img;
            if ($img !== '' && $i > 0) {
                // ogni conversazione ha la sua copia: chi la elimina non toglie l'immagine agli altri
                $f = bin2hex(random_bytes(16)) . '.' . pathinfo($img, PATHINFO_EXTENSION);
                @copy(ps_dir_img($plugin) . '/' . $img, ps_dir_img($plugin) . '/' . $f);
            }
            $cid = ps_nuova_conv($plugin, $uid, array($a), $oggetto, false);
            $mid = ps_aggiungi($plugin, $cid, $uid, $d['testo'], $lib ? $lib['id'] : 0, $lib ? $lib['title'] : '', $f);
            $convs[] = array($cid, $mid);
        }
    }
    if ($bz) {
        ps_bozza_elimina($plugin, $bz['id'], $uid, $img !== '' && $img === (string)$bz['immagine']);
    }
    foreach ($convs as $x) {
        ps_avvisa($plugin, $x[0], $x[1], $uid, $oggetto, $d['testo']);
    }
    if (count($convs) === 1) {
        flash(count($dest) > 1 ? 'Messaggio inviato al gruppo.' : 'Messaggio inviato.');
        $_POST['back'] = $plugin->site_url('leggi', array('c' => $convs[0][0]));
    } else {
        flash('Messaggio inviato a ' . count($convs) . ' persone, ognuna con la sua conversazione.');
        $_POST['back'] = $plugin->site_url('posta', array('f' => 'inviati'));
    }
}

/* ================= Immagini ================= */

function ps_img($plugin)
{
    $uid = current_uid();
    $f = '';
    if (get('m')) {
        $m = ps_messaggio($plugin, (int)get('m'));
        $p = $m ? ps_part($plugin, $m['conv_id'], $uid) : null;
        if ($m && $p && $p['cartella'] !== 'eliminata' && (int)$m['id'] > (int)$p['nascosti_fino']) {
            $f = (string)$m['immagine'];
        }
    } elseif (get('b')) {
        $b = ps_bozza($plugin, (int)get('b'), $uid);
        $f = $b ? (string)$b['immagine'] : '';
    }
    $path = ps_nome_file_ok($f) ? ps_dir_img($plugin) . '/' . $f : '';
    if ($path === '' || !is_file($path)) {
        header('HTTP/1.1 404 Not Found');
        return;
    }
    header('Content-Type: ' . (substr($f, -4) === '.png' ? 'image/png' : 'image/jpeg'));
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: private, max-age=86400');
    header('X-Content-Type-Options: nosniff');
    header('Content-Disposition: inline; filename="immagine' . substr($f, -4) . '"');
    readfile($path);
}

/* ================= Pannello di gestione ================= */

function ps_pannello($plugin)
{
    $g = (int)$plugin->setting('cestino_giorni', '30');
    $C = ps_t($plugin, 'conversazioni');
    $M = ps_t($plugin, 'messaggi');
    $nc = (int)db()->query('SELECT COUNT(*) FROM ' . $C)->fetchColumn();
    $nm = (int)db()->query('SELECT COUNT(*) FROM ' . $M)->fetchColumn();
    $spazio = 0;
    foreach ((array)glob(ps_dir_img($plugin) . '/*.{jpg,png}', GLOB_BRACE) as $f) {
        $spazio += (int)@filesize($f);
    }
    $ne = ps_email_plugin();
    $st = ps_stile($plugin);
    echo '<div class="adm-grid2">';
    echo $plugin->form_start('class="card stack"') . '<div class="ct">' . icon('layout', 18) . ' Stile della posta</div>'
        . '<p class="sub">Come si leggono le conversazioni. Vale per tutti e si può cambiare quando vuoi: i messaggi restano gli stessi.</p>'
        . '<label class="check ps-stile"><input type="radio" name="stile" value="chat"' . ($st === 'chat' ? ' checked' : '') . '> <span><b>Chat</b><br><small>Bolle a destra e a sinistra, divise per giorno; si risponde dalla casella in fondo, come su WhatsApp.</small></span></label>'
        . '<label class="check ps-stile"><input type="radio" name="stile" value="classica"' . ($st === 'classica' ? ' checked' : '') . '> <span><b>Posta classica</b><br><small>Un riquadro per messaggio con mittente, destinatari e data; i messaggi già letti si chiudono su una riga; risposta in un riquadro ampio, come nelle email.</small></span></label>'
        . '<div class="ct" style="margin-top:8px">' . icon('trash', 18) . ' Cestino</div>'
        . '<label class="lab" for="ps-g">Le conversazioni nel cestino si eliminano da sole dopo</label><select class="input" id="ps-g" name="cestino_giorni">';
    foreach (array(0 => 'mai: si svuota solo a mano', 7 => '7 giorni', 15 => '15 giorni', 30 => '30 giorni', 60 => '60 giorni', 90 => '90 giorni') as $k => $t) {
        echo '<option value="' . $k . '"' . ($g === $k ? ' selected' : '') . '>' . h($t) . '</option>';
    }
    echo '</select><p class="hint">Vale per tutti. Ognuno può comunque svuotare il proprio cestino quando vuole. Il controllo si fa una volta al giorno.</p>'
        . '<div class="ct" style="margin-top:8px">' . icon('bell', 18) . ' Avvisi via email</div>'
        . '<label class="check"><input type="checkbox" name="email" value="1"' . ($plugin->setting('email', '1') === '1' ? ' checked' : '') . '> <span>Manda un\'email a chi riceve un messaggio</span></label>'
        . '<label class="check"><input type="checkbox" name="email_testo" value="1"' . ($plugin->setting('email_testo', '0') === '1' ? ' checked' : '') . '> <span>Metti nell\'email anche l\'inizio del messaggio</span></label>'
        . '<p class="hint">' . ($ne ? '<span class="ok-text">Plugin «Notifiche email» pronto.</span>' : '<span class="err-text">Serve il plugin «Notifiche email» attivo e configurato (server e mittente).</span>')
        . ' L\'email arriva solo a chi ha un indirizzo nel profilo e non ha spento le email del sito, e una sola per conversazione finché non la legge.</p>'
        . '<button class="btn primary small" type="submit">Salva</button></form>';
    echo '<div class="card"><div class="ct">' . icon('chart', 18) . ' In numeri</div>'
        . '<div class="fr row"><span>Conversazioni</span><span>' . $nc . '</span></div><div class="fr row"><span>Messaggi</span><span>' . $nm . '</span></div>'
        . '<div class="fr row"><span>Immagini allegate</span><span>' . h($spazio >= 1048576 ? round($spazio / 1048576, 1) . ' MB' : max(1, round($spazio / 1024)) . ' KB') . (($ni = count((array)glob(ps_dir_img($plugin) . '/*.{jpg,png}', GLOB_BRACE))) ? ' · ' . $ni . ($ni === 1 ? ' file' : ' file') : '') . '</span></div>'
        . '<p class="hint">I messaggi sono privati: da qui non si leggono. Un messaggio sparisce dal database quando l\'hanno eliminato tutti i partecipanti.</p>'
        . '<p class="hint"><b>Chi può scrivere a chi:</b> tutti possono scrivere a una persona; Admin e Gestori anche a più persone insieme o a tutti.</p></div>';
    echo '</div>';
}

function ps_pannello_salva($plugin)
{
    $plugin->save_setting('stile', post('stile') === 'classica' ? 'classica' : 'chat');
    $g = (int)post('cestino_giorni');
    $plugin->save_setting('cestino_giorni', (string)(in_array($g, array(0, 7, 15, 30, 60, 90), true) ? $g : 30));
    $plugin->save_setting('email', post('email') === '1' ? '1' : '0');
    $plugin->save_setting('email_testo', post('email_testo') === '1' ? '1' : '0');
    flash('Impostazioni della Posta salvate.');
}
