<?php
/*
 * Feste e stagioni — motore: feste predefinite, date (anche Pasqua, Carnevale e Festa della mamma, che cambiano ogni anno),
 * compleanni degli utenti e scelta di cosa mostrare oggi. Prefisso: fs_
 */

// Effetti animati, decorazioni della testata e ornamenti (gli stessi nomi usati da file/feste.js)
function fs_effetti()
{
    return array('' => 'Nessuno', 'neve' => 'Neve che cade', 'coriandoli' => 'Coriandoli', 'fuochi' => 'Fuochi d\'artificio', 'stelle' => 'Stelle cadenti',
        'cuori' => 'Cuori', 'foglie' => 'Foglie che cadono', 'fiori' => 'Petali e fiori', 'bolle' => 'Bolle di sapone', 'pipistrelli' => 'Pipistrelli in volo',
        'palloncini' => 'Palloncini che salgono', 'immagine' => 'La mia immagine che cade');
}

function fs_testate()
{
    return array('' => 'Nessuna', 'luci' => 'Fila di lucine', 'festone' => 'Festone con palline', 'bandierine' => 'Bandierine', 'stelle' => 'Stelle appese',
        'cuori' => 'Cuori appesi', 'foglie' => 'Foglie d\'autunno', 'zucche' => 'Zucche appese', 'uova' => 'Ovetti appesi', 'fiori' => 'Ghirlanda di fiori', 'onde' => 'Onde e sole');
}

function fs_ornamenti()
{
    return array('' => 'Nessuno', 'agrifoglio' => 'Agrifoglio e palline', 'stella' => 'Stella', 'cometa' => 'Stella cometa', 'cuore' => 'Cuore', 'foglie' => 'Foglie',
        'zucca' => 'Zucca', 'uova' => 'Uova di Pasqua', 'fiori' => 'Fiori', 'sole' => 'Sole', 'torta' => 'Torta di compleanno', 'maschera' => 'Maschera',
        'regalo' => 'Pacchetto regalo', 'calice' => 'Brindisi', 'immagine' => 'La mia immagine');
}

function fs_stili()
{
    return array('acquerello' => 'Acquerello', 'pastello' => 'Pastelli a cera', 'olio' => 'Pittura a olio');
}

function fs_regole()
{
    return array('fissa' => 'Stesse date ogni anno', 'date' => 'Solo una volta (date precise)', 'pasqua' => 'Intorno a Pasqua', 'carnevale' => 'Carnevale (giovedì grasso – martedì grasso)',
        'mamma' => 'Festa della mamma (seconda domenica di maggio)');
}

// Feste pronte. Colori: c1 = colore principale del sito durante la festa, c2 = colore di accento
function fs_predefinite()
{
    $f = function ($nome, $regola, $dal, $al, $eff, $test, $orn, $testo, $c1, $c2, $pri, $extra = array()) {
        return array_merge(array('nome' => $nome, 'attiva' => 1, 'regola' => $regola, 'dal' => $dal, 'al' => $al, 'prima' => 0, 'dopo' => 0,
            'effetto' => $eff, 'testata' => $test, 'angoli' => $orn, 'banner' => 1, 'testo' => $testo, 'colore' => 0, 'c1' => $c1, 'c2' => $c2,
            'priorita' => $pri, 'img_effetto' => 0, 'img_angoli' => 0, 'stile' => '', 'predefinita' => 1), $extra);
    };
    return array(
        'natale' => $f('Natale', 'fissa', '12-08', '12-26', 'neve', 'luci', 'agrifoglio', 'Buon Natale! 🎄', '#b3262e', '#1f6f43', 5),
        'capodanno' => $f('Capodanno', 'fissa', '12-31', '01-01', 'fuochi', 'stelle', 'calice', 'Buon anno nuovo! 🥂', '#1d2b53', '#c9a227', 6),
        'epifania' => $f('Epifania', 'fissa', '01-05', '01-06', 'stelle', 'stelle', 'cometa', 'Buona Epifania! ⭐', '#4b3a8c', '#d9a520', 6),
        'carnevale' => $f('Carnevale', 'carnevale', '', '', 'coriandoli', 'bandierine', 'maschera', 'A Carnevale ogni libro vale! 🎭', '#8e2a8b', '#f2a900', 5),
        'sanvalentino' => $f('San Valentino', 'fissa', '02-14', '02-14', 'cuori', 'cuori', 'cuore', 'Buon San Valentino! ❤️', '#c2185b', '#e57373', 6),
        'papa' => $f('Festa del papà', 'fissa', '03-19', '03-19', 'stelle', 'bandierine', 'regalo', 'Auguri a tutti i papà! 💙', '#1f5fa8', '#f0b429', 6),
        'pasqua' => $f('Pasqua', 'pasqua', '', '', 'fiori', 'uova', 'uova', 'Buona Pasqua! 🐣', '#5d8f3a', '#e8a33d', 5, array('prima' => 2, 'dopo' => 1)),
        'mamma' => $f('Festa della mamma', 'mamma', '', '', 'fiori', 'fiori', 'fiori', 'Auguri a tutte le mamme! 🌷', '#c2457e', '#7cb342', 6),
        'estate' => $f('Vacanze estive', 'fissa', '07-01', '08-31', 'bolle', 'onde', 'sole', 'Buone vacanze e buone letture sotto l\'ombrellone! ☀️', '#0f7fb3', '#f5a623', 3),
        'autunno' => $f('Autunno', 'fissa', '09-23', '10-31', 'foglie', 'foglie', 'foglie', 'È arrivato l\'autunno: tempo di libri e coperte 🍂', '#a0522d', '#d4a017', 2,
            array('banner' => 0)),
        'halloween' => $f('Halloween', 'fissa', '10-30', '11-01', 'pipistrelli', 'zucche', 'zucca', 'Buon Halloween! 🎃', '#d35400', '#4a235a', 6),
    );
}

function fs_compleanno_pred()
{
    return array('attivo' => 1, 'chi' => 'tutti', 'effetto' => 'palloncini', 'testata' => 'bandierine', 'angoli' => 'torta', 'banner' => 1,
        'testo' => 'Oggi è il compleanno di {nome}! Tanti auguri 🎂', 'testo_suo' => 'Buon compleanno, {nome}! 🎉 Tanti auguri da tutta la libreria',
        'colore' => 0, 'c1' => '#d6336c', 'c2' => '#f59f00', 'campanella' => 1, 'sopra_feste' => 1, 'img_effetto' => 0, 'img_angoli' => 0, 'stile' => '');
}

function fs_generale_pred()
{
    return array('attivo' => 1, 'pannello' => 'tutto', 'accesso' => 1, 'durata' => 10, 'quantita' => 'normale', 'ripeti' => 'sempre', 'stile' => 'acquerello');
}

/* ---------------- Lettura e salvataggio ---------------- */

function fs_json($plugin, $k)
{
    $v = json_decode((string)$plugin->setting($k, ''), true);
    return is_array($v) ? $v : array();
}

function fs_feste($plugin)
{
    $salvate = fs_json($plugin, 'feste');
    $out = array();
    foreach (fs_predefinite() as $id => $f) {
        $out[$id] = isset($salvate[$id]) && is_array($salvate[$id]) ? array_merge($f, $salvate[$id], array('predefinita' => 1)) : $f;
    }
    foreach ($salvate as $id => $f) {
        if (!isset($out[$id]) && is_array($f) && strpos($id, 'p_') === 0) {
            $out[$id] = array_merge(fs_predefinite()['natale'], array('predefinita' => 0), $f);
        }
    }
    return $out;
}

function fs_salva_feste($plugin, $feste)
{
    $plugin->save_setting('feste', json_encode($feste, JSON_UNESCAPED_UNICODE));
}

function fs_generale($plugin)
{
    return array_merge(fs_generale_pred(), fs_json($plugin, 'generale'));
}

function fs_compleanno($plugin)
{
    return array_merge(fs_compleanno_pred(), fs_json($plugin, 'compleanno'));
}

// Date dei compleanni: id utente => "MM-GG"
function fs_date_compleanni($plugin)
{
    $out = array();
    foreach (fs_json($plugin, 'compleanni') as $uid => $md) {
        if (preg_match('/^(\d{2})-(\d{2})$/', (string)$md, $m) && checkdate((int)$m[1], (int)$m[2], 2024)) {
            $out[(int)$uid] = $md;
        }
    }
    return $out;
}

/* ---------------- Date ---------------- */

// Domenica di Pasqua (calendario gregoriano, algoritmo di Meeus/Jones/Butcher): non serve l'estensione calendar di PHP
function fs_pasqua($anno)
{
    $a = $anno % 19;
    $b = intdiv($anno, 100);
    $c = $anno % 100;
    $d = intdiv($b, 4);
    $e = $b % 4;
    $f = intdiv($b + 8, 25);
    $g = intdiv($b - $f + 1, 3);
    $h = (19 * $a + $b - $d - $g + 15) % 30;
    $i = intdiv($c, 4);
    $k = $c % 4;
    $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7;
    $m = intdiv($a + 11 * $h + 22 * $l, 451);
    $mese = intdiv($h + $l - 7 * $m + 114, 31);
    $giorno = (($h + $l - 7 * $m + 114) % 31) + 1;
    return sprintf('%04d-%02d-%02d', $anno, $mese, $giorno);
}

function fs_sposta($data, $giorni)
{
    return date('Y-m-d', strtotime($data . ' ' . ($giorni >= 0 ? '+' : '') . (int)$giorni . ' day'));
}

// Periodo di una festa nell'anno $anno: array(inizio, fine) in "AAAA-MM-GG", oppure null
function fs_periodo($f, $anno)
{
    switch ($f['regola']) {
        case 'pasqua':
            $p = fs_pasqua($anno);
            return array(fs_sposta($p, -(int)$f['prima']), fs_sposta($p, (int)$f['dopo']));
        case 'carnevale':
            $p = fs_pasqua($anno);
            return array(fs_sposta($p, -52 - (int)$f['prima']), fs_sposta($p, -47 + (int)$f['dopo']));
        case 'mamma':
            $d = date('Y-m-d', strtotime('second sunday of may ' . $anno));
            return array(fs_sposta($d, -(int)$f['prima']), fs_sposta($d, (int)$f['dopo']));
        case 'date':
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$f['dal']) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$f['al'])) {
                return null;
            }
            return substr($f['dal'], 0, 4) == $anno ? array($f['dal'], max($f['dal'], $f['al'])) : null;
        default:
            if (!preg_match('/^\d{2}-\d{2}$/', (string)$f['dal']) || !preg_match('/^\d{2}-\d{2}$/', (string)$f['al'])) {
                return null;
            }
            // a cavallo dell'anno (es. 31 dicembre – 1 gennaio): finisce l'anno dopo
            return array($anno . '-' . $f['dal'], ($f['al'] < $f['dal'] ? $anno + 1 : $anno) . '-' . $f['al']);
    }
}

// Periodo che contiene $oggi (anche iniziato l'anno prima), oppure null
function fs_periodo_attivo($f, $oggi)
{
    $y = (int)substr($oggi, 0, 4);
    foreach (array($y - 1, $y) as $anno) {
        $p = fs_periodo($f, $anno);
        if ($p && $oggi >= $p[0] && $oggi <= $p[1]) {
            return $p;
        }
    }
    return null;
}

// Prossimo periodo (in corso o futuro) da $oggi
function fs_prossimo($f, $oggi)
{
    $y = (int)substr($oggi, 0, 4);
    foreach (array($y - 1, $y, $y + 1) as $anno) {
        $p = fs_periodo($f, $anno);
        if ($p && $p[1] >= $oggi) {
            return $p;
        }
    }
    return null;
}

function fs_data_breve($d)
{
    $mesi = array(1 => 'gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic');
    $t = strtotime($d);
    return (int)date('j', $t) . ' ' . $mesi[(int)date('n', $t)];
}

function fs_periodo_testo($p)
{
    if (!$p) {
        return '—';
    }
    return $p[0] === $p[1] ? fs_data_breve($p[0]) . ' ' . substr($p[0], 0, 4) : fs_data_breve($p[0]) . ' – ' . fs_data_breve($p[1]) . ' ' . substr($p[1], 0, 4);
}

// La festa di oggi: array(id, festa, periodo) oppure null. A pari priorita' vince la festa piu' corta (la piu' precisa)
function fs_festa_di_oggi($plugin, $oggi = null)
{
    $oggi = $oggi ?: date('Y-m-d');
    $scelta = null;
    foreach (fs_feste($plugin) as $id => $f) {
        if (empty($f['attiva'])) {
            continue;
        }
        $p = fs_periodo_attivo($f, $oggi);
        if (!$p) {
            continue;
        }
        $durata = strtotime($p[1]) - strtotime($p[0]);
        if (!$scelta || (int)$f['priorita'] > (int)$scelta[1]['priorita'] || ((int)$f['priorita'] === (int)$scelta[1]['priorita'] && $durata < $scelta[3])) {
            $scelta = array($id, $f, $p, $durata);
        }
    }
    return $scelta;
}

// Chi compie gli anni oggi: id => nome (il 29 febbraio si festeggia il 28 negli anni non bisestili)
function fs_festeggiati($plugin, $oggi = null)
{
    $oggi = $oggi ?: date('Y-m-d');
    $md = substr($oggi, 5);
    $bisestile = (bool)date('L', strtotime($oggi));
    $ids = array();
    foreach (fs_date_compleanni($plugin) as $uid => $d) {
        if ($d === $md || (!$bisestile && $d === '02-29' && $md === '02-28')) {
            $ids[] = (int)$uid;
        }
    }
    if (!$ids) {
        return array();
    }
    $st = db()->prepare('SELECT id, username, display_name FROM users WHERE active = 1 AND id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY display_name, username');
    $st->execute($ids);
    $out = array();
    foreach ($st->fetchAll() as $u) {
        $out[(int)$u['id']] = trim((string)$u['display_name']) !== '' ? $u['display_name'] : $u['username'];
    }
    return $out;
}

function fs_elenco_nomi($nomi)
{
    $nomi = array_values($nomi);
    if (count($nomi) <= 1) {
        return (string)($nomi ? $nomi[0] : '');
    }
    $ult = array_pop($nomi);
    return implode(', ', $nomi) . ' e ' . $ult;
}

/* ---------------- Colori ---------------- */

function fs_colore_ok($c, $def)
{
    return preg_match('/^#[0-9a-fA-F]{6}$/', (string)$c) ? strtolower($c) : $def;
}

function fs_testo_su($hex)
{
    $r = hexdec(substr($hex, 1, 2));
    $g = hexdec(substr($hex, 3, 2));
    $b = hexdec(substr($hex, 5, 2));
    return (0.299 * $r + 0.587 * $g + 0.114 * $b) > 160 ? '#1b1b1b' : '#ffffff';
}

function fs_rgba($hex, $a)
{
    return 'rgba(' . hexdec(substr($hex, 1, 2)) . ',' . hexdec(substr($hex, 3, 2)) . ',' . hexdec(substr($hex, 5, 2)) . ',' . $a . ')';
}

/* ---------------- Immagini (da Media) ---------------- */

function fs_img_url($id)
{
    $id = (int)$id;
    if (!$id || !is_file(APP_ROOT . '/inc/media.php')) {
        return '';
    }
    require_once APP_ROOT . '/inc/media.php';
    if (!media_ready()) {
        return '';
    }
    $m = media_get($id);
    return $m && $m['kind'] === 'image' ? media_url($m['filename']) : '';
}

function fs_cartella_media()
{
    $st = db()->prepare('SELECT id FROM media_folders WHERE name = ?');
    $st->execute(array('Feste e stagioni'));
    $id = (int)$st->fetchColumn();
    $st->closeCursor();
    if (!$id) {
        $ord = (int)db()->query('SELECT COALESCE(MAX(sort_order), 0) FROM media_folders')->fetchColumn() + 1;
        db()->prepare('INSERT INTO media_folders (name, sort_order, created_at) VALUES (?,?,?)')->execute(array('Feste e stagioni', $ord, now()));
        $id = (int)db()->lastInsertId();
    }
    return $id;
}

/* ---------------- Cosa mostrare in questa pagina ---------------- */

// Anteprima per l'Admin (10 minuti): 'festa:<id>' oppure 'compleanno'
function fs_anteprima()
{
    if (!is_admin() || empty($_SESSION['fs_anteprima']) || !is_array($_SESSION['fs_anteprima'])) {
        return '';
    }
    if ((int)$_SESSION['fs_anteprima']['scade'] < time()) {
        unset($_SESSION['fs_anteprima']);
        return '';
    }
    return (string)$_SESSION['fs_anteprima']['cosa'];
}

/*
 * Configurazione per file/feste.js (null = niente decorazioni). $dove: 'sito' | 'pannello'
 */
function fs_config($plugin, $dove)
{
    $gen = fs_generale($plugin);
    $prev = fs_anteprima();
    if ((empty($gen['attivo']) && $prev === '') || ($dove === 'pannello' && $gen['pannello'] === 'no' && $prev === '')) {
        return null;
    }
    $oggi = date('Y-m-d');
    $uid = function_exists('current_uid') ? current_uid() : 0;
    $loggato = function_exists('is_logged') && is_logged();
    if (!$loggato && empty($gen['accesso'])) {
        return null;
    }
    $sorgente = null; // array(tipo, dati, id per lo striscione, testo)
    $cmp = fs_compleanno($plugin);

    if ($prev === 'compleanno') {
        $u = function_exists('current_user') ? current_user() : null;
        $nome = $u ? (trim((string)$u['display_name']) !== '' ? $u['display_name'] : $u['username']) : 'Admin';
        $sorgente = array('compleanno', $cmp, 'prova-compleanno', str_replace('{nome}', $nome, $cmp['testo_suo']));
    } elseif (strpos($prev, 'festa:') === 0) {
        $feste = fs_feste($plugin);
        $id = substr($prev, 6);
        if (isset($feste[$id])) {
            $sorgente = array('festa', $feste[$id], 'prova-' . $id, $feste[$id]['testo']);
        }
    }
    if (!$sorgente && !empty($gen['attivo'])) {
        // compleanni (solo per chi ha fatto l'accesso)
        if (!empty($cmp['attivo']) && $loggato) {
            $fest = fs_festeggiati($plugin, $oggi);
            if ($fest) {
                $mio = isset($fest[$uid]);
                if ($mio || $cmp['chi'] === 'tutti') {
                    $altri = $fest;
                    unset($altri[$uid]);
                    $testo = $mio ? str_replace('{nome}', $fest[$uid], $cmp['testo_suo']) . ($altri ? ' · Oggi festeggia anche ' . fs_elenco_nomi($altri) . '.' : '')
                        : str_replace('{nome}', fs_elenco_nomi($fest), $cmp['testo']);
                    $cand = array('compleanno', $cmp, 'compleanno-' . $oggi . ($mio ? '-mio' : ''), $testo);
                    $festa = fs_festa_di_oggi($plugin, $oggi);
                    if (!$festa || !empty($cmp['sopra_feste']) || $mio) {
                        $sorgente = $cand;
                    }
                }
            }
        }
        if (!$sorgente) {
            $festa = isset($festa) ? $festa : fs_festa_di_oggi($plugin, $oggi);
            if ($festa) {
                $sorgente = array('festa', $festa[1], $festa[0] . '-' . substr($festa[2][0], 0, 4), $festa[1]['testo']);
            }
        }
    }
    if (!$sorgente) {
        return null;
    }
    $d = $sorgente[1];
    $leggero = $dove === 'pannello' && $gen['pannello'] === 'leggero';
    $quant = array('poca' => 0.5, 'normale' => 1, 'tanta' => 1.8);
    $c1 = fs_colore_ok($d['c1'], '#7a1f2b');
    $c2 = fs_colore_ok($d['c2'], '#c9a227');
    $cfg = array(
        'tema' => $sorgente[0] === 'compleanno' ? 'compleanno' : $sorgente[2],
        'effetto' => $leggero ? '' : (string)$d['effetto'],
        'img_effetto' => $d['effetto'] === 'immagine' && $loggato ? fs_img_url($d['img_effetto']) : '',
        'testata' => (string)$d['testata'],
        'angoli' => (string)$d['angoli'],
        'img_angoli' => $d['angoli'] === 'immagine' && $loggato ? fs_img_url($d['img_angoli']) : '',
        'banner' => !empty($d['banner']) && !$leggero && trim((string)$sorgente[3]) !== '' ? array('id' => $sorgente[2], 'testo' => (string)$sorgente[3]) : null,
        'durata' => max(3, min(60, (int)$gen['durata'])),
        'quantita' => isset($quant[$gen['quantita']]) ? $quant[$gen['quantita']] : 1,
        'ripeti' => $gen['ripeti'] === 'mezzora' ? 'mezzora' : 'sempre',
        'c1' => $c1, 'c2' => $c2,
        'pannello' => $dove === 'pannello',
        'anteprima' => $prev !== '' ? array('testo' => 'Anteprima per l\'Admin: finisce da sola tra 10 minuti.', 'url' => $plugin->admin_url('feste')) : null,
    );
    if ($cfg['effetto'] === 'immagine' && $cfg['img_effetto'] === '') {
        $cfg['effetto'] = '';
    }
    if ($cfg['angoli'] === 'immagine' && $cfg['img_angoli'] === '') {
        $cfg['angoli'] = '';
    }
    $cfg['colore'] = !empty($d['colore']);
    // i disegni: un'immagine per stile con tutte le illustrazioni, e la mappa delle posizioni
    $stile = isset($d['stile']) && isset(fs_stili()[$d['stile']]) ? $d['stile'] : (isset(fs_stili()[$gen['stile']]) ? $gen['stile'] : 'acquerello');
    $mappa = fs_mappa_arte($plugin);
    $cfg['arte'] = $mappa ? array('url' => $plugin->url('file/arte-' . $stile . '.webp'), 'mappa' => $mappa) : null;
    return $cfg;
}

function fs_mappa_arte($plugin)
{
    static $m = null;
    if ($m === null) {
        $m = json_decode((string)@file_get_contents(__DIR__ . '/file/arte.json'), true);
        $m = is_array($m) && isset($m['celle'], $m['w'], $m['h']) ? $m : false;
    }
    return $m ?: null;
}

// Colori del sito durante la festa (le variabili del tema: pulsanti, testata, link)
function fs_css_colori($cfg)
{
    if (!$cfg || empty($cfg['colore'])) {
        return '';
    }
    $c1 = $cfg['c1'];
    return '<style id="fs-colori">:root{--primary:' . $c1 . ';--on-primary:' . fs_testo_su($c1) . ';--accent:' . $cfg['c2'] . ';--primary-shadow:' . fs_rgba($c1, .35) . '}</style>';
}

function fs_testa($plugin, $dove)
{
    $cfg = fs_config($plugin, $dove);
    if (!$cfg) {
        return '';
    }
    $GLOBALS['FS_CFG'] = $cfg;
    return $plugin->css('file/feste.css') . fs_css_colori($cfg)
        . '<script type="application/json" id="fs-config">' . json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>'
        // nella testa con "defer": cosi' funziona anche nelle pagine che non hanno il fondo comune (es. la pagina di accesso)
        . '<script defer src="' . h($plugin->url('file/feste.js')) . '"></script>';
}

function fs_fondo($plugin)
{
    return '';
}

/* ---------------- Avvisi del compleanno nella campanella (una volta al giorno) ---------------- */

function fs_avvisi_compleanni($plugin)
{
    $cmp = fs_compleanno($plugin);
    $gen = fs_generale($plugin);
    $oggi = date('Y-m-d');
    if (empty($gen['attivo']) || empty($cmp['attivo']) || empty($cmp['campanella']) || $plugin->setting('avvisi_del', '') === $oggi || (int)date('G') < 8) {
        return;
    }
    $plugin->save_setting('avvisi_del', $oggi);
    $fest = fs_festeggiati($plugin, $oggi);
    if (!$fest) {
        return;
    }
    foreach ($fest as $uid => $nome) {
        $plugin->notifica(str_replace('{nome}', $nome, $cmp['testo_suo']), 'libreria.php',
            array('to' => array($uid), 'gruppo' => 'auguri-' . $oggi . '-' . $uid));
    }
    if ($cmp['chi'] === 'tutti') {
        $st = db()->query('SELECT id FROM users WHERE active = 1');
        $tutti = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        $st->closeCursor();
        foreach ($fest as $uid => $nome) {
            $a = array_values(array_diff($tutti, array_keys($fest), array($uid)));
            if ($a) {
                $plugin->notifica(str_replace('{nome}', $nome, $cmp['testo']), 'libreria.php', array('to' => $a, 'gruppo' => 'compleanno-' . $oggi . '-' . $uid));
            }
        }
    }
    $plugin->log('Compleanni di oggi: ' . fs_elenco_nomi($fest));
}
