/* Feste e stagioni — pannello: interruttori che salvano da soli, campi che compaiono secondo le scelte */
(function () {
  'use strict';
  var root = document.querySelector('.fs-pan');
  if (!root) { return; }
  Array.prototype.forEach.call(root.querySelectorAll('[data-fs-auto]'), function (c) {
    c.addEventListener('change', function () { c.form.submit(); });
  });
  Array.prototype.forEach.call(root.querySelectorAll('form'), function (f) {
    var reg = f.querySelector('[data-fs-regola]');
    var per = function () {
      if (!reg) { return; }
      Array.prototype.forEach.call(f.querySelectorAll('[data-fs-per]'), function (d) { d.hidden = d.getAttribute('data-fs-per') !== reg.value; });
    };
    if (reg) { reg.addEventListener('change', per); per(); }
    Array.prototype.forEach.call(f.querySelectorAll('[data-fs-sel]'), function (s) {
      var box = f.querySelector('[data-fs-img="img_' + s.getAttribute('data-fs-sel') + '"]');
      var mostra = function () { if (box) { box.hidden = s.value !== 'immagine'; } };
      s.addEventListener('change', mostra); mostra();
    });
  });
})();
