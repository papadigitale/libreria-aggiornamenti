/*
 * Feste e stagioni — decorazioni: testata appesa, ornamenti negli angoli, striscione degli auguri ed effetto animato.
 * I disegni sono illustrazioni dipinte (acquerello, pastelli a cera o olio) raccolte in un'unica immagine per stile
 * (file/arte-<stile>.webp); qui si ritagliano e si dispongono. Gli elementi non ricevono i tocchi: la pagina resta usabile.
 * L'animazione dura pochi secondi; con "riduci movimento" non parte.
 */
(function () {
  'use strict';
  var nodo = document.getElementById('fs-config');
  if (!nodo) { return; }
  var C;
  try { C = JSON.parse(nodo.textContent); } catch (e) { return; }
  var ridotto = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var ARTE = C.arte || null, ATL = null;

  function leggi(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } }
  function scrivi(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* niente */ } }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function scegli(l) { return l[Math.floor(Math.random() * l.length)]; }
  function cella(n) { return ARTE && ARTE.mappa.celle[n] ? ARTE.mappa.celle[n] : null; }
  function serie(pref) { return Object.keys(ARTE ? ARTE.mappa.celle : {}).filter(function (k) { return k.indexOf(pref) === 0; }); }

  // un disegno dell'atlante come elemento HTML (sfondo ritagliato)
  function sprite(nome, lato) {
    var c = cella(nome);
    if (!c) { return null; }
    var k = lato / c[2], d = document.createElement('span');
    d.className = 'fs-sprite';
    d.style.width = lato + 'px';
    d.style.height = Math.round(c[3] * k) + 'px';
    d.style.backgroundImage = 'url("' + ARTE.url + '")';
    d.style.backgroundSize = Math.round(ARTE.mappa.w * k) + 'px ' + Math.round(ARTE.mappa.h * k) + 'px';
    d.style.backgroundPosition = Math.round(-c[0] * k) + 'px ' + Math.round(-c[1] * k) + 'px';
    return d;
  }
  // un disegno dell'atlante sul canvas, centrato in 0,0, largo "lato"
  function disegna(ctx, nome, lato) {
    var c = cella(nome);
    if (!c || !ATL) { return; }
    var h = lato * c[3] / c[2];
    ctx.drawImage(ATL, c[0], c[1], c[2], c[3], -lato / 2, -h / 2, lato, h);
  }

  /* ---------------- Decorazione appesa in testata ---------------- */
  function testata(tipo) {
    var largo = Math.max(320, document.documentElement.clientWidth), k = largo < 700 ? 0.68 : 1;
    var H = Math.round(46 * k), dpr = Math.min(2, window.devicePixelRatio || 1);
    var cv = document.createElement('canvas');
    cv.className = 'fs-testata' + (C.pannello ? ' fs-pann' : '');
    cv.setAttribute('aria-hidden', 'true');
    cv.width = largo * dpr; cv.height = H * dpr;
    cv.style.width = largo + 'px'; cv.style.height = H + 'px';
    var ctx = cv.getContext('2d');
    if (!ctx) { return null; }
    ctx.scale(dpr * k, dpr * k);
    var W = largo / k, n = Math.max(4, Math.round(W / 96)), L = W / n;
    var yFilo = function (x) { var t = (x % L) / L; return 4 + 13 * 4 * t * (1 - t) * 0.6 + Math.sin(x * 0.05) * 0.6; };
    var filo = function (col, spess) {
      ctx.beginPath(); ctx.moveTo(0, yFilo(0));
      for (var x = 4; x <= W; x += 4) { ctx.lineTo(x, yFilo(x)); }
      ctx.strokeStyle = col || 'rgba(96,78,60,.75)'; ctx.lineWidth = spess || 1.4; ctx.stroke();
    };
    var appesi = function (nomi, passo, lato, pendente, giro) {
      var i = 0;
      for (var x = passo / 2; x < W; x += passo, i++) {
        var y = yFilo(x), dy = pendente ? 3 + (i % 3) * 5 : 0;
        if (dy) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + dy); ctx.strokeStyle = 'rgba(96,78,60,.6)'; ctx.lineWidth = 0.9; ctx.stroke(); }
        ctx.save(); ctx.translate(x, y + dy + lato * 0.42); ctx.rotate((giro || 0) * (Math.random() - 0.5)); disegna(ctx, nomi[i % nomi.length], lato); ctx.restore();
      }
    };
    switch (tipo) {
      case 'luci': filo(); appesi(serie('lampadina_'), 40, 26, false, 0.4); break;
      case 'festone':
        for (var x = 0; x < W + 20; x += 15) { ctx.save(); ctx.translate(x, yFilo(x) + 6); ctx.rotate(rnd(-0.6, 0.6)); disegna(ctx, 'rametto', 34); ctx.restore(); }
        appesi(serie('pallina_'), L, 24, true, 0.2);
        break;
      case 'bandierine':
        filo();
        for (var b = 14, q = 0, bs = serie('bandierina_'); b < W; b += 27, q++) { ctx.save(); ctx.translate(b, yFilo(b) + 11); disegna(ctx, bs[q % bs.length], 28); ctx.restore(); }
        break;
      case 'stelle': filo(); appesi(['stella_oro', 'stella_argento', 'stella_oro'], 50, 24, true, 0.6); break;
      case 'cuori': filo(); appesi(serie('cuore_'), 48, 24, true, 0.5); break;
      case 'zucche': filo(); appesi(['zucca'], 62, 30, true, 0.3); break;
      case 'uova': filo(); appesi(serie('uovo_'), 46, 24, true, 0.5); break;
      case 'fiori':
        filo('rgba(85,139,47,.8)', 2.2);
        for (var f = 10, j = 0, fs = serie('fiore_'); f < W; f += 24, j++) { ctx.save(); ctx.translate(f, yFilo(f) + 2); ctx.rotate(rnd(-1, 1)); disegna(ctx, fs[j % fs.length], 22); ctx.restore(); }
        break;
      case 'foglie':
        for (var g = 8, z = 0, fg = serie('foglia_'); g < W; g += 20, z++) { ctx.save(); ctx.translate(g, rnd(8, 18)); ctx.rotate(rnd(-1.4, 1.4)); disegna(ctx, fg[z % fg.length], 26); ctx.restore(); }
        break;
      case 'onde':
        var o = cella('onda'), lh = 30, lw = lh * o[2] / o[3];
        for (var w = 0; w < W; w += lw - 2) { ctx.save(); ctx.translate(w + lw / 2, lh / 2); disegna(ctx, 'onda', lw); ctx.restore(); }
        for (var s = 70; s < W; s += 300) { ctx.save(); ctx.translate(s, 26); disegna(ctx, 'sole', 30); ctx.restore(); }
        break;
      default: return null;
    }
    return cv;
  }

  /* ---------------- Ornamenti negli angoli ---------------- */
  function angoli() {
    ['dx', 'sx'].forEach(function (lato) {
      var d = document.createElement('div');
      d.className = 'fs-angolo fs-' + lato;
      d.setAttribute('aria-hidden', 'true');
      if (C.img_angoli) {
        var im = document.createElement('img'); im.src = C.img_angoli; im.alt = ''; d.appendChild(im);
      } else {
        var s = sprite('a_' + C.angoli, 130);
        if (!s) { return; }
        d.appendChild(s);
      }
      document.body.appendChild(d);
    });
  }

  /* ---------------- Striscione degli auguri e avviso di anteprima ---------------- */
  function striscione() {
    var main = document.querySelector('main') || document.body;
    if (C.anteprima) {
      var a = document.createElement('div');
      a.className = 'fs-anteprima';
      a.innerHTML = '<span></span> <a></a>';
      a.querySelector('span').textContent = C.anteprima.testo;
      a.querySelector('a').textContent = 'Torna alle impostazioni';
      a.querySelector('a').href = C.anteprima.url;
      main.insertBefore(a, main.firstChild);
    }
    if (!C.banner) { return; }
    var chiave = 'fs-chiuso-' + C.banner.id;
    if (!C.anteprima && leggi(chiave)) { return; }
    var b = document.createElement('div');
    b.className = 'fs-banner';
    b.setAttribute('role', 'status');
    b.innerHTML = '<span class="fs-banner-ic"></span><span class="fs-banner-t"></span><button type="button" class="fs-banner-x" aria-label="Chiudi gli auguri">&times;</button>';
    var orn = C.angoli && C.angoli !== 'immagine' ? C.angoli : (C.tema === 'compleanno' ? 'torta' : '');
    var ic = orn ? sprite('a_' + orn, 46) : null;
    if (ic) { b.querySelector('.fs-banner-ic').appendChild(ic); } else { b.querySelector('.fs-banner-ic').remove(); }
    b.querySelector('.fs-banner-t').textContent = C.banner.testo;
    b.querySelector('.fs-banner-x').addEventListener('click', function () { scrivi(chiave, '1'); b.classList.add('via'); setTimeout(function () { b.remove(); }, 300); });
    var dopo = main.querySelector('.fs-anteprima');
    main.insertBefore(b, dopo ? dopo.nextSibling : main.firstChild);
  }

  /* ---------------- Effetto animato (canvas) ---------------- */
  var NOMI = {
    neve: ['neve'], coriandoli: 'coriandolo_', stelle: ['stella_oro', 'stella_argento', 'stella_oro'], cuori: 'cuore_', foglie: 'foglia_',
    fiori: ['fiore_rosa', 'fiore_bianco', 'fiore_lilla', 'fiore_giallo', 'petalo_rosa', 'petalo_bianco', 'petalo_rosa'], bolle: ['bolla'],
    palloncini: 'palloncino_', pipistrelli: ['pipistrello_su']
  };
  var MISURE = { neve: [9, 22], coriandoli: [11, 17], stelle: [12, 24], cuori: [14, 28], foglie: [18, 32], fiori: [13, 24], bolle: [18, 42], palloncini: [36, 58], pipistrelli: [26, 42], immagine: [26, 46] };

  function effetto(tipo) {
    if (!tipo || ridotto) { return; }
    if (tipo !== 'fuochi' && tipo !== 'immagine' && !ATL) { return; }
    if (C.ripeti === 'mezzora' && !C.anteprima) {
      var k = 'fs-visto-' + C.tema, t = parseInt(leggi(k) || '0', 10);
      if (Date.now() - t < 30 * 60 * 1000) { return; }
      scrivi(k, String(Date.now()));
    }
    var cv = document.createElement('canvas');
    cv.className = 'fs-canvas';
    cv.setAttribute('aria-hidden', 'true');
    document.body.appendChild(cv);
    var ctx = cv.getContext('2d');
    if (!ctx) { cv.remove(); return; }
    var W = 0, H = 0, dpr = Math.min(2, window.devicePixelRatio || 1);
    function misura() { W = window.innerWidth; H = window.innerHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
    misura();
    window.addEventListener('resize', misura);
    var peso = { pipistrelli: 0.16, palloncini: 0.3, bolle: 0.4, cuori: 0.55, foglie: 0.55, fiori: 0.65, stelle: 0.55, immagine: 0.4 }[tipo] || 1;
    var quanti = Math.max(6, Math.min(140, Math.round(W * H / 9000 * (C.quantita || 1) * peso)));
    var nomi = typeof NOMI[tipo] === 'string' ? serie(NOMI[tipo]) : (NOMI[tipo] || []);
    var mis = MISURE[tipo] || [14, 26];
    var img = null;
    if (tipo === 'immagine' && C.img_effetto) { img = new Image(); img.src = C.img_effetto; }
    var P = [], durata = (C.durata || 10) * 1000, tempo = 0, ultimo = 0, finito = false, prossimoRazzo = 0;

    function nuovo(inizio) {
      var su = tipo === 'bolle' || tipo === 'palloncini';
      var p = { x: rnd(0, W), y: inizio ? rnd(-H * 0.9, H * 0.9) : rnd(-70, -20), rot: rnd(-0.6, 0.6), vr: rnd(-1.2, 1.2), ph: rnd(0, 6.28),
        s: rnd(mis[0], mis[1]), n: scegli(nomi.length ? nomi : ['']), amp: rnd(10, 35), vy: rnd(35, 80), vx: 0 };
      if (su) { p.vy = -rnd(35, 80); p.y = inizio ? rnd(H * 0.25, H + 60) : H + rnd(40, 90); p.rot = rnd(-0.15, 0.15); p.vr = 0; }
      if (tipo === 'neve') { p.vy = rnd(25, 60); p.vr = rnd(-0.6, 0.6); }
      if (tipo === 'coriandoli') { p.vy = rnd(70, 140); p.vx = rnd(-25, 25); p.vr = rnd(-5, 5); p.rot = rnd(0, 6.28); }
      if (tipo === 'foglie') { p.amp = rnd(25, 60); p.vr = rnd(-1.6, 1.6); p.rot = rnd(0, 6.28); }
      if (tipo === 'pipistrelli') { p.dir = Math.random() < 0.5 ? 1 : -1; p.x = p.dir > 0 ? rnd(-140, -40) : W + rnd(40, 140); p.y = rnd(H * 0.08, H * 0.6); p.vx = p.dir * rnd(90, 160); }
      return p;
    }
    function razzo() {
      return { razzo: true, x: rnd(W * 0.1, W * 0.9), y: H + 5, vy: -rnd(H * 0.55, H * 0.8), cima: rnd(H * 0.12, H * 0.42), c: scegli(['#ffd54f', '#ff5252', '#69f0ae', '#40c4ff', '#e040fb', '#ffab40', C.c2]) };
    }
    function scoppio(r) {
      var n = Math.round(rnd(40, 64)), v = rnd(110, 190);
      for (var i = 0; i < n; i++) {
        var a = Math.PI * 2 * i / n + rnd(-0.05, 0.05), vv = v * rnd(0.55, 1);
        P.push({ scintilla: true, x: r.x, y: r.y, vx: Math.cos(a) * vv, vy: Math.sin(a) * vv, c: Math.random() < 0.15 ? '#fff' : r.c, vita: rnd(1.1, 1.9), eta: 0 });
      }
    }
    if (tipo !== 'fuochi') { for (var i = 0; i < quanti; i++) { P.push(nuovo(true)); } }

    function dipingi(p) {
      ctx.save();
      ctx.translate(p.x, p.y);
      if (tipo === 'palloncini') {
        ctx.rotate(Math.sin(p.ph) * 0.1);
        ctx.beginPath(); ctx.moveTo(0, p.s * 0.42); ctx.quadraticCurveTo(p.s * 0.18 * Math.sin(p.ph * 2), p.s * 0.95, 0, p.s * 1.45);
        ctx.strokeStyle = 'rgba(110,100,90,.65)'; ctx.lineWidth = 1; ctx.stroke();
        disegna(ctx, p.n, p.s);
      } else if (tipo === 'pipistrelli') {
        ctx.scale(p.dir, 1);
        disegna(ctx, Math.sin(p.ph * 9) > 0 ? 'pipistrello_su' : 'pipistrello_giu', p.s);
      } else if (tipo === 'coriandoli') {
        ctx.rotate(p.rot); ctx.scale(1, Math.max(0.15, Math.abs(Math.cos(p.ph * 3)))); disegna(ctx, p.n, p.s);
      } else if (tipo === 'immagine') {
        if (img && img.complete && img.naturalWidth) { ctx.rotate(p.rot); var q = img.naturalHeight / img.naturalWidth; ctx.drawImage(img, -p.s / 2, -p.s * q / 2, p.s, p.s * q); }
      } else {
        ctx.rotate(tipo === 'cuori' || tipo === 'stelle' ? Math.sin(p.ph) * 0.35 + p.rot : p.rot);
        if (tipo === 'stelle') { ctx.globalAlpha = 0.6 + 0.4 * Math.abs(Math.sin(p.ph * 2)); }
        disegna(ctx, p.n, p.s);
      }
      ctx.restore();
    }

    function passo(ora) {
      if (!ultimo) { ultimo = ora; }
      var dt = Math.min(0.05, (ora - ultimo) / 1000);
      ultimo = ora;
      if (document.hidden) { requestAnimationFrame(passo); return; }
      tempo += dt * 1000;
      if (!finito && tempo > durata) { finito = true; cv.classList.add('fs-via'); setTimeout(function () { cv.remove(); window.removeEventListener('resize', misura); }, 1600); }
      ctx.clearRect(0, 0, W, H);
      if (tipo === 'fuochi' && !finito) {
        prossimoRazzo -= dt;
        if (prossimoRazzo <= 0) { P.push(razzo()); if (Math.random() < 0.35) { P.push(razzo()); } prossimoRazzo = rnd(0.5, 1.1) / (C.quantita || 1); }
      }
      for (var i = P.length - 1; i >= 0; i--) {
        var p = P[i];
        if (p.razzo) {
          p.y += p.vy * dt;
          ctx.beginPath(); ctx.arc(p.x, p.y, 2.2, 0, 6.283); ctx.fillStyle = p.c; ctx.fill();
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x, p.y + 16); ctx.strokeStyle = 'rgba(255,220,150,.5)'; ctx.lineWidth = 1.5; ctx.stroke();
          if (p.y <= p.cima) { scoppio(p); P.splice(i, 1); }
          continue;
        }
        if (p.scintilla) {
          p.eta += dt; p.vx *= 0.985; p.vy = p.vy * 0.985 + 90 * dt; p.x += p.vx * dt; p.y += p.vy * dt;
          var al = Math.max(0, 1 - p.eta / p.vita);
          if (al <= 0) { P.splice(i, 1); continue; }
          ctx.globalAlpha = al; ctx.beginPath(); ctx.arc(p.x, p.y, 2.1, 0, 6.283); ctx.fillStyle = p.c; ctx.fill(); ctx.globalAlpha = 1;
          continue;
        }
        p.ph += dt;
        if (tipo === 'pipistrelli') { p.x += p.vx * dt; p.y += Math.sin(p.ph * 2) * p.amp * dt; }
        else { p.y += p.vy * dt; p.x += Math.sin(p.ph * 1.3) * p.amp * dt + p.vx * dt; p.rot += p.vr * dt; }
        var fuori = tipo === 'pipistrelli' ? (p.x < -180 || p.x > W + 180) : (p.vy < 0 ? p.y < -p.s * 2 : p.y > H + 40);
        if (fuori) { if (finito) { P.splice(i, 1); continue; } P[i] = nuovo(false); continue; }
        dipingi(p);
      }
      if ((!finito || P.length) && cv.isConnected) { requestAnimationFrame(passo); }
    }
    requestAnimationFrame(passo);
  }

  function avvia() {
    striscione();
    var t = C.testata ? testata(C.testata) : null;
    if (t) {
      document.body.appendChild(t);
      var largo = document.documentElement.clientWidth;
      window.addEventListener('resize', function () {
        if (Math.abs(document.documentElement.clientWidth - largo) < 40) { return; }
        largo = document.documentElement.clientWidth;
        var n = testata(C.testata); if (n) { t.replaceWith(n); t = n; }
      });
    }
    if (C.angoli && !C.pannello) { angoli(); } // nel pannello gli angoli coprirebbero tabelle e numeri
    effetto(C.effetto);
  }
  function quandoPronto(fn) { if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', fn); } else { fn(); } }
  function senzaDisegni() { quandoPronto(function () { striscione(); effetto(C.effetto === 'fuochi' || C.effetto === 'immagine' ? C.effetto : ''); }); }

  if (!ARTE) { senzaDisegni(); return; }
  ATL = new Image();
  ATL.onload = function () { quandoPronto(avvia); };
  ATL.onerror = function () { ATL = null; ARTE = null; senzaDisegni(); };
  ATL.src = ARTE.url;
})();
