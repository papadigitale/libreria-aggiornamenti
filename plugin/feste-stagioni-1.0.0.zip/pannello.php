<?php
/*
 * Feste e stagioni — pannello (Gestione → Plugin → Feste e stagioni): Feste · Compleanni · Impostazioni
 */

function fs_url($plugin, $tab, $extra = array())
{
    return $plugin->admin_url('feste', array_merge(array('tab' => $tab), $extra));
}

function fs_sel($name, $opzioni, $val, $attr = '')
{
    $h = '<select class="input" name="' . h($name) . '"' . ($attr !== '' ? ' ' . $attr : '') . '>';
    foreach ($opzioni as $k => $t) {
        $h .= '<option value="' . h($k) . '"' . ((string)$k === (string)$val ? ' selected' : '') . '>' . h($t) . '</option>';
    }
    return $h . '</select>';
}

function fs_mesi()
{
    return array(1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre');
}

// Giorno e mese ("MM-GG") con due tendine
function fs_giorno_mese($pref, $md, $vuoto = false)
{
    $g = $m = 0;
    if (preg_match('/^(\d{2})-(\d{2})$/', (string)$md, $x)) {
        $m = (int)$x[1];
        $g = (int)$x[2];
    }
    $gg = $vuoto ? array(0 => '—') : array();
    for ($i = 1; $i <= 31; $i++) {
        $gg[$i] = $i;
    }
    $mm = $vuoto ? array(0 => '—') : array();
    foreach (fs_mesi() as $k => $t) {
        $mm[$k] = $t;
    }
    return '<span class="fs-gm">' . fs_sel($pref . '_g', $gg, $g, 'aria-label="Giorno"') . fs_sel($pref . '_m', $mm, $m, 'aria-label="Mese"') . '</span>';
}

function fs_leggi_gm($pref)
{
    $g = (int)post($pref . '_g');
    $m = (int)post($pref . '_m');
    return $g && $m && checkdate($m, $g, 2024) ? sprintf('%02d-%02d', $m, $g) : '';
}

function fs_pannello($plugin)
{
    $schede = array('feste' => 'Feste', 'compleanni' => 'Compleanni', 'impostazioni' => 'Impostazioni');
    $tab = isset($schede[(string)get('tab')]) ? (string)get('tab') : 'feste';
    echo '<div class="fs-pan">';
    echo '<nav class="fs-tabs" aria-label="Schede">';
    foreach ($schede as $k => $t) {
        echo '<a href="' . h(fs_url($plugin, $k)) . '"' . ($k === $tab ? ' class="on" aria-current="page"' : '') . '>' . h($t) . '</a>';
    }
    echo '</nav>';
    $prev = fs_anteprima();
    if ($prev !== '') {
        echo $plugin->form_start('class="alert warn fs-prev"') . '<input type="hidden" name="op" value="fine_anteprima"><input type="hidden" name="back" value="' . h(fs_url($plugin, $tab)) . '">'
            . '<span>Anteprima in corso: la vedi solo tu, finisce da sola tra pochi minuti.</span> <button class="btn link small" type="submit">Termina l\'anteprima</button></form>';
    }
    if ($tab === 'feste') {
        if (get('modifica') !== '' || get('nuova') === '1') {
            fs_scheda_modifica($plugin);
        } else {
            fs_scheda_feste($plugin);
        }
    } elseif ($tab === 'compleanni') {
        fs_scheda_compleanni($plugin);
    } else {
        fs_scheda_impostazioni($plugin);
    }
    echo '</div>';
}

/* ================= Feste ================= */

function fs_quando_testo($f)
{
    switch ($f['regola']) {
        case 'pasqua':
            return 'Pasqua' . ((int)$f['prima'] || (int)$f['dopo'] ? ' (da ' . (int)$f['prima'] . ' giorni prima a ' . (int)$f['dopo'] . ' dopo)' : '');
        case 'carnevale':
            return 'Carnevale (dal giovedì al martedì grasso)';
        case 'mamma':
            return 'Seconda domenica di maggio';
        case 'date':
            return 'Solo una volta';
        default:
            return 'Ogni anno';
    }
}

function fs_scheda_feste($plugin)
{
    $oggi = date('Y-m-d');
    $gen = fs_generale($plugin);
    $feste = fs_feste($plugin);
    $ora = fs_festa_di_oggi($plugin, $oggi);
    $fest = fs_festeggiati($plugin, $oggi);
    echo '<div class="card fs-oggi"><div class="ct">' . admin_icon('gift', 18) . ' Oggi, ' . h(fs_data_breve($oggi)) . '</div>';
    if (empty($gen['attivo'])) {
        echo '<p class="sub"><b>Le decorazioni sono spente</b> per tutto il sito (scheda Impostazioni).</p>';
    } elseif ($fest && fs_compleanno($plugin)['attivo']) {
        echo '<p class="sub">🎂 Oggi è il compleanno di <b>' . h(fs_elenco_nomi($fest)) . '</b>' . ($ora ? ' (e c\'è anche ' . h($ora[1]['nome']) . ')' : '') . '.</p>';
    } elseif ($ora) {
        echo '<p class="sub">Sul sito c\'è <b>' . h($ora[1]['nome']) . '</b>, fino al ' . h(fs_data_breve($ora[2][1])) . '.</p>';
    } else {
        $pross = null;
        foreach ($feste as $id => $f) {
            $p = !empty($f['attiva']) ? fs_prossimo($f, $oggi) : null;
            if ($p && (!$pross || $p[0] < $pross[1][0])) {
                $pross = array($f, $p);
            }
        }
        echo '<p class="sub">Oggi niente decorazioni.' . ($pross ? ' La prossima festa è <b>' . h($pross[0]['nome']) . '</b>, dal ' . h(fs_data_breve($pross[1][0])) . '.' : '') . '</p>';
    }
    echo '</div>';

    echo '<div class="card"><div class="ct">' . admin_icon('chart', 18) . ' Calendario delle feste</div>'
        . '<p class="sub">Ogni festa si accende e si spegne da sola alle sue date. Se due feste capitano negli stessi giorni vince quella con la priorità più alta (a pari priorità, la più breve).</p>';
    echo '<table class="tbl fs-tbl"><thead><tr><th>Festa</th><th>Quando</th><th>Prossima volta</th><th>Accesa</th><th class="act"></th></tr></thead><tbody>';
    uasort($feste, function ($a, $b) use ($oggi) {
        $pa = fs_prossimo($a, $oggi);
        $pb = fs_prossimo($b, $oggi);
        return strcmp($pa ? $pa[0] : '9999', $pb ? $pb[0] : '9999');
    });
    foreach ($feste as $id => $f) {
        $p = fs_prossimo($f, $oggi);
        $incorso = $p && $p[0] <= $oggi;
        echo '<tr' . (empty($f['attiva']) ? ' class="fs-spenta"' : '') . '><td><b>' . h($f['nome']) . '</b><br><small class="muted">' . h(fs_effetti()[$f['effetto']] ?? '') . ($f['testata'] ? ' · ' . h(fs_testate()[$f['testata']] ?? '') : '')
            . (!empty($f['colore']) ? ' · <span class="fs-pall" style="background:' . h(fs_colore_ok($f['c1'], '#888888')) . '"></span><span class="fs-pall" style="background:' . h(fs_colore_ok($f['c2'], '#888888')) . '"></span> colori' : '') . '</small></td>'
            . '<td>' . h(fs_quando_testo($f)) . '</td><td>' . ($incorso && !empty($f['attiva']) ? '<span class="ok-text">in corso</span> ' : '') . h(fs_periodo_testo($p)) . '</td>'
            . '<td>' . $plugin->form_start('class="fs-inline"') . '<input type="hidden" name="op" value="accendi"><input type="hidden" name="id" value="' . h($id) . '">'
            . '<input type="hidden" name="back" value="' . h(fs_url($plugin, 'feste')) . '"><label class="check switch" title="Accesa o spenta"><input type="checkbox" name="attiva" value="1" data-fs-auto' . (!empty($f['attiva']) ? ' checked' : '') . '><span class="sr-only">Accesa</span></label>'
            . '<noscript><button class="btn link small" type="submit">Salva</button></noscript></form></td>'
            . '<td class="act"><span class="fs-act"><a class="btn link small" href="' . h(fs_url($plugin, 'feste', array('modifica' => $id))) . '">Modifica</a>'
            . $plugin->form_start('class="fs-inline"') . '<input type="hidden" name="op" value="anteprima"><input type="hidden" name="cosa" value="festa:' . h($id) . '"><button class="btn link small" type="submit">Anteprima</button></form></span></td></tr>';
    }
    echo '</tbody></table><a class="btn ghost small" href="' . h(fs_url($plugin, 'feste', array('nuova' => '1'))) . '">' . admin_icon('plus', 15) . ' Aggiungi una festa</a></div>';
}

// Campi comuni a feste e compleanno: effetto, testata, angoli (con le immagini), striscione, colori
function fs_campi_aspetto($d, $con_testo = true)
{
    $img = function ($campo, $id) {
        $u = fs_img_url($id);
        return '<div class="fs-img" data-fs-img="' . h($campo) . '">' . ($u !== '' ? '<img src="' . h($u) . '" alt="" width="48" height="48"><label class="check"><input type="checkbox" name="togli_' . h($campo) . '" value="1"> <span>togli</span></label>' : '')
            . '<input class="input" type="file" name="' . h($campo) . '_file" accept="image/png,image/jpeg,image/webp" aria-label="Immagine">'
            . '<p class="hint">PNG (meglio se con lo sfondo trasparente), JPG o WEBP, fino a 2 MB. Finisce anche in Media, cartella «Feste e stagioni».</p></div>';
    };
    $h = '<div class="fs-grid">';
    $h .= '<fieldset><legend>Stile dei disegni</legend>' . fs_sel('stile', array('' => 'Come in Impostazioni') + fs_stili(), isset($d['stile']) ? $d['stile'] : '')
        . '<p class="hint">Illustrazioni ad acquerello, a pastelli a cera o a olio.</p></fieldset>';
    $h .= '<fieldset><legend>Effetto animato</legend>' . fs_sel('effetto', fs_effetti(), $d['effetto'], 'data-fs-sel="effetto"') . $img('img_effetto', $d['img_effetto']) . '</fieldset>';
    $h .= '<fieldset><legend>Decorazione in testata</legend>' . fs_sel('testata', fs_testate(), $d['testata']) . '<p class="hint">Appesa in cima alla pagina, non copre i pulsanti.</p></fieldset>';
    $h .= '<fieldset><legend>Ornamenti negli angoli</legend>' . fs_sel('angoli', fs_ornamenti(), $d['angoli'], 'data-fs-sel="angoli"') . $img('img_angoli', $d['img_angoli'])
        . '<p class="hint">Si vedono sugli schermi larghi (computer e tablet), solo sul sito.</p></fieldset>';
    $h .= '<fieldset><legend>Colori del sito</legend><label class="check"><input type="checkbox" name="colore" value="1"' . (!empty($d['colore']) ? ' checked' : '') . '> <span>Cambia i colori del sito durante la festa</span></label>'
        . '<div class="fs-colori"><label>Principale <input type="color" name="c1" value="' . h(fs_colore_ok($d['c1'], '#7a1f2b')) . '"></label>'
        . '<label>Accento <input type="color" name="c2" value="' . h(fs_colore_ok($d['c2'], '#c9a227')) . '"></label></div>'
        . '<p class="hint">Pulsanti, testata e link; alla fine della festa tornano quelli di Aspetto.</p></fieldset>';
    $h .= '</div>';
    if ($con_testo) {
        $h .= '<label class="check"><input type="checkbox" name="banner" value="1"' . (!empty($d['banner']) ? ' checked' : '') . '> <span>Striscione con gli auguri in cima alla pagina (ognuno può chiuderlo)</span></label>'
            . '<input class="input" name="testo" maxlength="160" value="' . h($d['testo']) . '" placeholder="es. Buone feste dalla nostra libreria! 🎄" aria-label="Testo dello striscione">';
    }
    return $h;
}

function fs_scheda_modifica($plugin)
{
    $feste = fs_feste($plugin);
    $id = (string)get('modifica');
    $nuova = !isset($feste[$id]);
    $f = $nuova ? array_merge(fs_predefinite()['natale'], array('nome' => '', 'predefinita' => 0, 'regola' => 'fissa', 'dal' => '', 'al' => '', 'effetto' => 'coriandoli',
        'testata' => 'bandierine', 'angoli' => 'regalo', 'testo' => '', 'priorita' => 7, 'c1' => '#2b7a78', 'c2' => '#f2a900')) : $feste[$id];
    echo '<div class="card">' . $plugin->form_start('class="stack fs-form" enctype="multipart/form-data"')
        . '<input type="hidden" name="op" value="festa_salva"><input type="hidden" name="id" value="' . h($nuova ? '' : $id) . '">'
        . '<input type="hidden" name="back" value="' . h(fs_url($plugin, 'feste')) . '">';
    echo '<div class="ct">' . admin_icon('gift', 18) . ' ' . ($nuova ? 'Nuova festa' : h($f['nome'])) . '</div>';
    echo '<div class="row2"><div><label class="lab" for="fs-nome">Nome</label><input class="input" id="fs-nome" name="nome" maxlength="60" required value="' . h($f['nome']) . '" placeholder="es. Compleanno della libreria"></div>'
        . '<div><label class="lab" for="fs-pri">Priorità</label>' . fs_sel('priorita', array_combine(range(1, 10), range(1, 10)), (int)$f['priorita'], 'id="fs-pri"') . '</div></div>';
    echo '<label class="check switch"><input type="checkbox" name="attiva" value="1"' . (!empty($f['attiva']) ? ' checked' : '') . '><span><b>Festa accesa</b></span></label>';
    $regole = fs_regole();
    if ($nuova || empty($f['predefinita']) || in_array($f['regola'], array('fissa', 'date'), true)) {
        $regole = array_intersect_key($regole, array('fissa' => 1, 'date' => 1));
    } else {
        $regole = array_intersect_key($regole, array($f['regola'] => 1, 'fissa' => 1));
    }
    $y = (int)date('Y');
    echo '<fieldset class="fs-quando"><legend>Quando</legend>' . fs_sel('regola', $regole, $f['regola'], 'data-fs-regola');
    echo '<div data-fs-per="fissa"><span class="lab">Dal</span>' . fs_giorno_mese('dal', $f['regola'] === 'fissa' ? $f['dal'] : '') . '<span class="lab">al</span>' . fs_giorno_mese('al', $f['regola'] === 'fissa' ? $f['al'] : '')
        . '<p class="hint">Ogni anno. Se la fine viene prima dell\'inizio (es. dal 31 dicembre al 1 gennaio) la festa scavalca l\'anno.</p></div>';
    echo '<div data-fs-per="date"><span class="lab">Dal</span><input class="input" type="date" name="dal_data" value="' . h($f['regola'] === 'date' ? $f['dal'] : '') . '">'
        . '<span class="lab">al</span><input class="input" type="date" name="al_data" value="' . h($f['regola'] === 'date' ? $f['al'] : '') . '"></div>';
    if (in_array($f['regola'], array('pasqua', 'carnevale', 'mamma'), true)) {
        $p = fs_periodo($f, $y);
        echo '<div data-fs-per="' . h($f['regola']) . '"><div class="row2"><div><label class="lab">Giorni prima</label><input class="input" type="number" min="0" max="60" name="prima" value="' . (int)$f['prima'] . '"></div>'
            . '<div><label class="lab">Giorni dopo</label><input class="input" type="number" min="0" max="60" name="dopo" value="' . (int)$f['dopo'] . '"></div></div>'
            . '<p class="hint">La data cambia ogni anno e il sito la calcola da solo: quest\'anno ' . h(fs_periodo_testo($p)) . ', il prossimo ' . h(fs_periodo_testo(fs_periodo($f, $y + 1))) . '.</p></div>';
    }
    echo '</fieldset>';
    echo fs_campi_aspetto($f);
    echo '<div class="row-btn"><button class="btn primary small" type="submit">Salva</button><button class="btn ghost small" type="submit" name="dopo" value="anteprima">Salva e guarda l\'anteprima</button>'
        . '<a class="btn link small" href="' . h(fs_url($plugin, 'feste')) . '">Annulla</a></div></form>';
    if (!$nuova) {
        echo $plugin->form_start('class="fs-inline" data-confirm="' . (!empty($f['predefinita']) ? 'Rimettere questa festa com\'era all\'inizio?' : 'Eliminare questa festa?') . '"')
            . '<input type="hidden" name="op" value="' . (!empty($f['predefinita']) ? 'festa_ripristina' : 'festa_elimina') . '"><input type="hidden" name="id" value="' . h($id) . '">'
            . '<input type="hidden" name="back" value="' . h(fs_url($plugin, 'feste')) . '"><button class="btn link small" type="submit">'
            . (!empty($f['predefinita']) ? 'Ripristina le impostazioni iniziali' : admin_icon('trash', 14) . ' Elimina la festa') . '</button></form>';
    }
    echo '</div>';
}

/* ================= Compleanni ================= */

function fs_scheda_compleanni($plugin)
{
    $c = fs_compleanno($plugin);
    $date = fs_date_compleanni($plugin);
    $oggi = date('Y-m-d');
    $back = fs_url($plugin, 'compleanni');
    echo '<div class="card">' . $plugin->form_start('class="stack fs-form" enctype="multipart/form-data"') . '<input type="hidden" name="op" value="compleanno_salva"><input type="hidden" name="back" value="' . h($back) . '">';
    echo '<div class="ct">🎂 Il giorno del compleanno</div>';
    echo '<label class="check switch"><input type="checkbox" name="attivo" value="1"' . (!empty($c['attivo']) ? ' checked' : '') . '><span><b>Festeggia i compleanni degli utenti</b></span></label>';
    echo '<div class="fs-grid"><fieldset><legend>Chi vede le decorazioni</legend>'
        . '<label class="check"><input type="radio" name="chi" value="tutti"' . ($c['chi'] === 'tutti' ? ' checked' : '') . '> <span>Tutti gli utenti (il festeggiato vede i suoi auguri)</span></label>'
        . '<label class="check"><input type="radio" name="chi" value="festeggiato"' . ($c['chi'] === 'festeggiato' ? ' checked' : '') . '> <span>Solo chi compie gli anni</span></label></fieldset>'
        . '<fieldset><legend>Se c\'è anche una festa</legend><label class="check"><input type="checkbox" name="sopra_feste" value="1"' . (!empty($c['sopra_feste']) ? ' checked' : '') . '> <span>Il compleanno ha la precedenza (per il festeggiato vale sempre)</span></label></fieldset>'
        . '<fieldset><legend>Campanella</legend><label class="check"><input type="checkbox" name="campanella" value="1"' . (!empty($c['campanella']) ? ' checked' : '') . '> <span>Dalle 8 del mattino, auguri al festeggiato e (con «Tutti gli utenti») avviso agli altri</span></label></fieldset></div>';
    echo fs_campi_aspetto($c, false);
    echo '<label class="check"><input type="checkbox" name="banner" value="1"' . (!empty($c['banner']) ? ' checked' : '') . '> <span>Striscione con gli auguri</span></label>'
        . '<label class="lab" for="fs-t1">Per chi compie gli anni</label><input class="input" id="fs-t1" name="testo_suo" maxlength="160" value="' . h($c['testo_suo']) . '">'
        . '<label class="lab" for="fs-t2">Per gli altri</label><input class="input" id="fs-t2" name="testo" maxlength="160" value="' . h($c['testo']) . '">'
        . '<p class="hint"><code>{nome}</code> diventa il nome del festeggiato (o «Marta e Luca» se sono più di uno).</p>';
    echo '<div class="row-btn"><button class="btn primary small" type="submit">Salva</button><button class="btn ghost small" type="submit" name="dopo" value="anteprima">Salva e guarda l\'anteprima</button></div></form></div>';

    // date dei compleanni
    $st = db()->query('SELECT id, username, display_name, role FROM users WHERE active = 1 ORDER BY display_name, username');
    $utenti = $st->fetchAll();
    $st->closeCursor();
    echo '<div class="card">' . $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="date_salva"><input type="hidden" name="back" value="' . h($back) . '">';
    echo '<div class="ct">' . admin_icon('user', 18) . ' Date dei compleanni</div><p class="sub">Solo giorno e mese: l\'età non si chiede e non si mostra. Lascia «—» per chi non vuoi festeggiare.</p>';
    // prossimi compleanni
    $pross = array();
    foreach ($date as $uid => $md) {
        $d = date('Y') . '-' . $md;
        if ($md === '02-29' && !date('L')) {
            $d = date('Y') . '-02-28';
        }
        if ($d < $oggi) {
            $d = (date('Y') + 1) . '-' . ($md === '02-29' && !date('L', strtotime((date('Y') + 1) . '-01-01')) ? '02-28' : $md);
        }
        $pross[$uid] = $d;
    }
    asort($pross);
    $nomi = array();
    foreach ($utenti as $u) {
        $nomi[(int)$u['id']] = trim((string)$u['display_name']) !== '' ? $u['display_name'] : $u['username'];
    }
    $prime = array();
    foreach (array_slice($pross, 0, 4, true) as $uid => $d) {
        if (isset($nomi[$uid])) {
            $prime[] = '<b>' . h($nomi[$uid]) . '</b> ' . ($d === $oggi ? '<span class="ok-text">oggi 🎂</span>' : h(fs_data_breve($d)));
        }
    }
    if ($prime) {
        echo '<p class="sub">Prossimi: ' . implode(' · ', $prime) . '</p>';
    }
    echo '<table class="tbl fs-tbl"><thead><tr><th>Utente</th><th>Compleanno</th></tr></thead><tbody>';
    foreach ($utenti as $u) {
        $uid = (int)$u['id'];
        echo '<tr><td><b>' . h($nomi[$uid]) . '</b><br><small class="muted">' . h($u['username']) . ' · ' . h(role_label($u['role'])) . '</small></td>'
            . '<td>' . fs_giorno_mese('u' . $uid, isset($date[$uid]) ? $date[$uid] : '', true) . '</td></tr>';
    }
    echo '</tbody></table><button class="btn primary small" type="submit">Salva le date</button></form></div>';
}

/* ================= Impostazioni ================= */

function fs_scheda_impostazioni($plugin)
{
    $g = fs_generale($plugin);
    echo '<div class="card">' . $plugin->form_start('class="stack"') . '<input type="hidden" name="op" value="generale_salva"><input type="hidden" name="back" value="' . h(fs_url($plugin, 'impostazioni')) . '">';
    echo '<div class="ct">' . admin_icon('gear', 18) . ' Impostazioni</div>';
    echo '<label class="check switch"><input type="checkbox" name="attivo" value="1"' . (!empty($g['attivo']) ? ' checked' : '') . '><span><b>Decorazioni accese</b> (spegnendo qui si fermano tutte, feste e compleanni)</span></label>';
    echo '<div class="fs-grid"><fieldset><legend>Stile dei disegni</legend>' . fs_sel('stile', fs_stili(), $g['stile'])
        . '<p class="hint">Vale per tutte le feste; ogni festa (e il compleanno) può averne uno suo.</p><div class="fs-stili">';
    foreach (fs_stili() as $k => $t) {
        echo '<figure><img src="' . h($plugin->url('file/stile-' . $k . '.webp')) . '" alt="' . h($t) . '" width="150" height="50" loading="lazy"><figcaption>' . h($t) . '</figcaption></figure>';
    }
    echo '</div></fieldset>';
    echo '<fieldset><legend>Nel pannello di gestione</legend>'
        . fs_sel('pannello', array('tutto' => 'Tutto, come sul sito', 'leggero' => 'Solo la testata e i colori (niente animazioni né striscione)', 'no' => 'Niente'), $g['pannello']) . '</fieldset>';
    echo '<fieldset><legend>Pagina di accesso e ospiti</legend><label class="check"><input type="checkbox" name="accesso" value="1"' . (!empty($g['accesso']) ? ' checked' : '') . '> <span>Decorazioni delle feste anche prima dell\'accesso</span></label>'
        . '<p class="hint">I compleanni si vedono solo dopo l\'accesso.</p></fieldset>';
    echo '<fieldset><legend>Animazioni</legend><label class="lab">Durata</label>' . fs_sel('durata', array(5 => '5 secondi', 8 => '8 secondi', 10 => '10 secondi', 15 => '15 secondi', 20 => '20 secondi', 30 => '30 secondi'), (int)$g['durata'])
        . '<label class="lab">Quantità</label>' . fs_sel('quantita', array('poca' => 'Poca', 'normale' => 'Normale', 'tanta' => 'Tanta'), $g['quantita'])
        . '<label class="lab">Quando</label>' . fs_sel('ripeti', array('sempre' => 'A ogni pagina aperta', 'mezzora' => 'Al massimo una volta ogni mezz\'ora'), $g['ripeti'])
        . '<p class="hint">Dopo la durata l\'animazione sparisce piano. Chi sul telefono o sul computer ha scelto «riduci movimento» non la vede.</p></fieldset></div>';
    echo '<button class="btn primary small" type="submit">Salva</button></form></div>';
}

/* ================= Salvataggi ================= */

// Immagine caricata per un campo: id di Media, 0 se tolta, null se non cambia
function fs_carica_img($campo, $attuale)
{
    if (post('togli_' . $campo) === '1') {
        $attuale = 0;
    }
    $k = $campo . '_file';
    if (empty($_FILES[$k]) || !is_array($_FILES[$k]) || (int)$_FILES[$k]['error'] === UPLOAD_ERR_NO_FILE) {
        return (int)$attuale;
    }
    $f = $_FILES[$k];
    $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, array('png', 'jpg', 'jpeg', 'webp'), true) || (int)$f['size'] > 2 * 1048576) {
        flash('Immagine non accettata: usa PNG, JPG o WEBP fino a 2 MB.', 'error');
        return (int)$attuale;
    }
    require_once APP_ROOT . '/inc/media.php';
    if (!media_ready()) {
        flash('Media non è pronto: aggiorna il sito.', 'error');
        return (int)$attuale;
    }
    list($ok, $r) = media_store($f, fs_cartella_media());
    if (!$ok) {
        flash('Immagine non salvata: ' . $r, 'error');
        return (int)$attuale;
    }
    return (int)$r;
}

function fs_leggi_aspetto($d)
{
    $d['effetto'] = array_key_exists(post('effetto'), fs_effetti()) ? post('effetto') : '';
    $d['testata'] = array_key_exists(post('testata'), fs_testate()) ? post('testata') : '';
    $d['angoli'] = array_key_exists(post('angoli'), fs_ornamenti()) ? post('angoli') : '';
    $d['img_effetto'] = fs_carica_img('img_effetto', isset($d['img_effetto']) ? $d['img_effetto'] : 0);
    $d['img_angoli'] = fs_carica_img('img_angoli', isset($d['img_angoli']) ? $d['img_angoli'] : 0);
    $d['colore'] = post('colore') === '1' ? 1 : 0;
    $d['c1'] = fs_colore_ok(post('c1'), '#7a1f2b');
    $d['c2'] = fs_colore_ok(post('c2'), '#c9a227');
    $d['banner'] = post('banner') === '1' ? 1 : 0;
    $d['stile'] = isset(fs_stili()[post('stile')]) ? post('stile') : '';
    return $d;
}

function fs_vai_anteprima($cosa)
{
    $_SESSION['fs_anteprima'] = array('cosa' => $cosa, 'scade' => time() + 600);
    redirect('libreria.php');
}

function fs_salva($plugin)
{
    $op = post('op');
    if ($op === 'anteprima') {
        $cosa = (string)post('cosa');
        if ($cosa === 'compleanno' || (strpos($cosa, 'festa:') === 0 && isset(fs_feste($plugin)[substr($cosa, 6)]))) {
            fs_vai_anteprima($cosa);
        }
        return;
    }
    if ($op === 'fine_anteprima') {
        unset($_SESSION['fs_anteprima']);
        flash('Anteprima terminata.');
        return;
    }
    if ($op === 'accendi') {
        $feste = fs_feste($plugin);
        $id = (string)post('id');
        if (isset($feste[$id])) {
            $feste[$id]['attiva'] = post('attiva') === '1' ? 1 : 0;
            fs_salva_feste($plugin, $feste);
            flash($feste[$id]['nome'] . ($feste[$id]['attiva'] ? ' accesa.' : ' spenta.'));
        }
        return;
    }
    if ($op === 'festa_salva') {
        $feste = fs_feste($plugin);
        $id = (string)post('id');
        if ($id !== '' && !isset($feste[$id])) {
            return;
        }
        $nuova = $id === '';
        if ($nuova) {
            $id = 'p_' . substr(bin2hex(random_bytes(4)), 0, 8);
        }
        $f = $nuova ? array_merge(fs_predefinite()['natale'], array('predefinita' => 0)) : $feste[$id];
        $f['nome'] = str_cut(trim(post('nome')), 60) ?: 'Festa';
        $f['attiva'] = post('attiva') === '1' ? 1 : 0;
        $f['priorita'] = max(1, min(10, (int)post('priorita')));
        $reg = (string)post('regola');
        $ammesse = $nuova || empty($f['predefinita']) ? array('fissa', 'date') : array('fissa', 'date', fs_predefinite()[$id]['regola']);
        $f['regola'] = in_array($reg, $ammesse, true) ? $reg : 'fissa';
        if ($f['regola'] === 'fissa') {
            $dal = fs_leggi_gm('dal');
            $al = fs_leggi_gm('al');
            if ($dal === '' || $al === '') {
                flash('Scegli giorno e mese di inizio e di fine.', 'error');
                redirect(fs_url($plugin, 'feste', $nuova ? array('nuova' => '1') : array('modifica' => $id)));
            }
            $f['dal'] = $dal;
            $f['al'] = $al;
        } elseif ($f['regola'] === 'date') {
            $dal = (string)post('dal_data');
            $al = (string)post('al_data');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dal) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $al) || $al < $dal) {
                flash('Scegli le date di inizio e di fine (la fine non può venire prima).', 'error');
                redirect(fs_url($plugin, 'feste', $nuova ? array('nuova' => '1') : array('modifica' => $id)));
            }
            $f['dal'] = $dal;
            $f['al'] = $al;
        } else {
            $f['prima'] = max(0, min(60, (int)post('prima')));
            $f['dopo'] = max(0, min(60, (int)post('dopo')));
        }
        $f = fs_leggi_aspetto($f);
        $f['testo'] = str_cut(trim(post('testo')), 160);
        $feste[$id] = $f;
        fs_salva_feste($plugin, $feste);
        flash('Festa «' . $f['nome'] . '» salvata.');
        if (post('dopo') === 'anteprima') {
            fs_vai_anteprima('festa:' . $id);
        }
        return;
    }
    if ($op === 'festa_ripristina' || $op === 'festa_elimina') {
        $salvate = fs_json($plugin, 'feste');
        $id = (string)post('id');
        unset($salvate[$id]);
        $plugin->save_setting('feste', json_encode($salvate, JSON_UNESCAPED_UNICODE));
        flash($op === 'festa_elimina' ? 'Festa eliminata.' : 'Festa rimessa com\'era all\'inizio.');
        return;
    }
    if ($op === 'compleanno_salva') {
        $c = fs_compleanno($plugin);
        $c['attivo'] = post('attivo') === '1' ? 1 : 0;
        $c['chi'] = post('chi') === 'festeggiato' ? 'festeggiato' : 'tutti';
        $c['sopra_feste'] = post('sopra_feste') === '1' ? 1 : 0;
        $c['campanella'] = post('campanella') === '1' ? 1 : 0;
        $c = fs_leggi_aspetto($c);
        $c['testo_suo'] = str_cut(trim(post('testo_suo')), 160) ?: fs_compleanno_pred()['testo_suo'];
        $c['testo'] = str_cut(trim(post('testo')), 160) ?: fs_compleanno_pred()['testo'];
        $plugin->save_setting('compleanno', json_encode($c, JSON_UNESCAPED_UNICODE));
        flash('Impostazioni dei compleanni salvate.');
        if (post('dopo') === 'anteprima') {
            fs_vai_anteprima('compleanno');
        }
        return;
    }
    if ($op === 'date_salva') {
        $out = array();
        $st = db()->query('SELECT id FROM users WHERE active = 1');
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $uid) {
            $md = fs_leggi_gm('u' . (int)$uid);
            if ($md !== '') {
                $out[(int)$uid] = $md;
            }
        }
        $st->closeCursor();
        // chi non e' piu' attivo resta com'era (se torna attivo, ritrova la sua data)
        foreach (fs_date_compleanni($plugin) as $uid => $md) {
            if (!isset($out[$uid])) {
                $chk = db()->prepare('SELECT active FROM users WHERE id = ?');
                $chk->execute(array($uid));
                $a = $chk->fetchColumn();
                $chk->closeCursor();
                if ($a !== false && (int)$a !== 1) {
                    $out[$uid] = $md;
                }
            }
        }
        $plugin->save_setting('compleanni', json_encode($out));
        flash(count($out) === 1 ? 'Salvato: 1 compleanno.' : 'Salvati: ' . count($out) . ' compleanni.');
        return;
    }
    if ($op === 'generale_salva') {
        $g = array('attivo' => post('attivo') === '1' ? 1 : 0, 'pannello' => in_array(post('pannello'), array('tutto', 'leggero', 'no'), true) ? post('pannello') : 'tutto',
            'accesso' => post('accesso') === '1' ? 1 : 0, 'durata' => max(3, min(60, (int)post('durata'))),
            'quantita' => in_array(post('quantita'), array('poca', 'normale', 'tanta'), true) ? post('quantita') : 'normale',
            'ripeti' => post('ripeti') === 'mezzora' ? 'mezzora' : 'sempre', 'stile' => isset(fs_stili()[post('stile')]) ? post('stile') : 'acquerello');
        $plugin->save_setting('generale', json_encode($g));
        flash('Impostazioni salvate.');
    }
}
