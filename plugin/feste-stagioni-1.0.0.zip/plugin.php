<?php
/*
 * Feste e stagioni — decorazioni del sito per le feste e i compleanni.
 *  - Natale, Capodanno, Epifania, Carnevale, San Valentino, Festa del papà, Pasqua, Festa della mamma, vacanze estive, autunno, Halloween
 *    e feste personalizzate: effetto animato leggero, decorazione in testata, ornamenti negli angoli, striscione con gli auguri,
 *    colori del sito in tema (facoltativi). Si accendono e si spengono da sole alle date impostate (Pasqua e Carnevale calcolati ogni anno).
 *  - Compleanni degli utenti: data impostata dall'Admin, decorazioni e auguri il giorno del compleanno, avviso nella campanella.
 *  - Sul sito e, a scelta, nel pannello di gestione. Decide solo l'Admin: Gestione → Plugin → Feste e stagioni.
 */
require_once __DIR__ . '/motore.php';
require_once __DIR__ . '/pannello.php';

$plugin->admin_page('feste', 'Feste e stagioni', function ($plugin) {
    fs_pannello($plugin);
}, array('salva' => function ($plugin) {
    fs_salva($plugin);
}));

$plugin->on('html_testa', function ($html) use ($plugin) {
    return $html . fs_testa($plugin, 'sito');
});
$plugin->on('html_fondo', function ($html) use ($plugin) {
    return $html . fs_fondo($plugin);
});
$plugin->on('admin_testa', function ($html) use ($plugin) {
    $sez = isset($_GET['sez']) ? (string)$_GET['sez'] : '';
    $mia = $sez === 'plg-' . $plugin->id . '-feste';
    return $html . ($mia ? $plugin->css('file/pannello.css') : '') . fs_testa($plugin, 'pannello');
});
$plugin->on('admin_fondo', function ($html) use ($plugin) {
    $sez = isset($_GET['sez']) ? (string)$_GET['sez'] : '';
    return $html . fs_fondo($plugin) . ($sez === 'plg-' . $plugin->id . '-feste' ? $plugin->js('file/pannello.js') : '');
});

// gli auguri nella campanella, dalle 8 del mattino: con i lavori periodici (dalla 1.9.19, ogni 10-15 minuti) o con quelli giornalieri
$plugin->on('lavori_periodici', function () use ($plugin) {
    fs_avvisi_compleanni($plugin);
});
$plugin->on('ogni_giorno', function () use ($plugin) {
    fs_avvisi_compleanni($plugin);
});
